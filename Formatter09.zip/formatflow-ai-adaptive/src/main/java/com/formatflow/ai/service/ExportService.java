package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.poi.sl.usermodel.ShapeType;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ExportService {

    private static final String GREEN = "008542";
    private static final String GREEN_DARK = "006B36";
    private static final String GREEN_SOFT = "EEF8F2";

    private final DocumentRenderer renderer;
    private final IconCatalog iconCatalog;
    private final PdfFontResolver pdfFontResolver;

    public ExportService(DocumentRenderer renderer, IconCatalog iconCatalog, PdfFontResolver pdfFontResolver) {
        this.renderer = renderer;
        this.iconCatalog = iconCatalog;
        this.pdfFontResolver = pdfFontResolver;
    }

    public ExportedFile export(ExportRequest request) {
        String format = request.format().toUpperCase(Locale.ROOT);
        String baseName = sanitizeFilename(request.filename() == null || request.filename().isBlank()
                ? "formatflow-output" : request.filename());
        FormattedDocument document = request.document();

        try {
            return switch (format) {
                case "WORD" -> new ExportedFile(baseName + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", word(document));
                case "POWERPOINT" -> new ExportedFile(baseName + ".pptx",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        powerpoint(request.htmlContent(), document));
                case "PDF" -> new ExportedFile(baseName + ".pdf", "application/pdf", pdf(document));
                case "CONFLUENCE" -> new ExportedFile(baseName + "-confluence.html", "text/html; charset=UTF-8",
                        renderer.confluenceHtml(document).getBytes(StandardCharsets.UTF_8));
                case "EMAIL" -> new ExportedFile(baseName + "-email.html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, true).getBytes(StandardCharsets.UTF_8));
                case "MARKDOWN" -> new ExportedFile(baseName + ".md", "text/markdown; charset=UTF-8",
                        renderer.markdown(document).getBytes(StandardCharsets.UTF_8));
                case "HTML" -> new ExportedFile(baseName + ".html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, false).getBytes(StandardCharsets.UTF_8));
                default -> throw new IllegalArgumentException("Unsupported export format: " + request.format());
            };
        } catch (Exception ex) {
            throw new IllegalStateException("Export failed for " + format + ": " + ex.getMessage(), ex);
        }
    }

    private byte[] word(FormattedDocument document) throws Exception {
        try (XWPFDocument doc = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            addWordAccent(doc);
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) addWordSectionTitle(doc, section);
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> addWordTable(doc, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> addWordFlow(doc, section);
                        case TIMELINE -> addWordTimeline(doc, section);
                        case STATUS, KPI -> addWordCardsTable(doc, section);
                        case CHECKLIST -> addWordChecklist(doc, section);
                        case CALLOUT -> addWordCallouts(doc, section);
                        case TEXT, CODE_GROUP -> addWordBlocks(doc, referencedBlocks(section, blocks));
                    }
                }
            } else {
                addWordBlocks(doc, document.blocks());
            }

            doc.write(out);
            return out.toByteArray();
        }
    }

    private void addWordAccent(XWPFDocument doc) {
        XWPFParagraph accentP = doc.createParagraph();
        XWPFRun accent = accentP.createRun();
        accent.setText(" ");
        accent.setFontSize(4);
        CTShd shading = accent.getCTR().addNewRPr().addNewShd();
        shading.setVal(STShd.CLEAR);
        shading.setFill(GREEN);
    }

    private void addWordSectionTitle(XWPFDocument doc, SemanticSection section) {
        if (section.title() == null || section.title().isBlank()) return;
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingBefore(160); p.setSpacingAfter(80);
        XWPFRun run = p.createRun();
        String icon = iconCatalog.symbol(section.iconKey());
        run.setText((icon.isBlank() ? "" : icon + "  ") + section.title());
        run.setBold(true); run.setColor(GREEN_DARK); run.setFontSize(14); run.setFontFamily("Arial");
    }

    private void addWordTable(XWPFDocument doc, SemanticSection section) {
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        XWPFTable table = doc.createTable(Math.max(1, section.rows().size()) + 1, cols);
        for (int c = 0; c < cols; c++) {
            XWPFTableCell cell = table.getRow(0).getCell(c);
            cell.setColor(GREEN_DARK);
            setCellText(cell, headers.get(c), true, "FFFFFF");
        }
        for (int r = 0; r < section.rows().size(); r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String value = c < cells.size() ? cells.get(c).text() : "";
                XWPFTableCell cell = table.getRow(r + 1).getCell(c);
                if (r % 2 == 1) cell.setColor("F7FBF8");
                setCellText(cell, value, false, "1F2D25");
            }
        }
        doc.createParagraph().setSpacingAfter(80);
    }

    private void addWordFlow(XWPFDocument doc, SemanticSection section) {
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingAfter(100);
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        for (int i = 0; i < nodes.size(); i++) {
            SemanticNode node = nodes.get(i);
            XWPFRun nodeRun = p.createRun();
            String icon = iconCatalog.symbol(node.iconKey());
            nodeRun.setText((icon.isBlank() ? "" : icon + " ") + node.text());
            nodeRun.setBold(true); nodeRun.setColor(GREEN_DARK); nodeRun.setFontFamily("Arial"); nodeRun.setFontSize(10);
            if (i < nodes.size() - 1) {
                SemanticEdge edge = edgeMap.get(node.id());
                XWPFRun arrow = p.createRun();
                String label = edge == null || edge.label() == null || edge.label().isBlank() ? "" : "  " + edge.label() + "  ";
                arrow.setText(label + "  →  ");
                arrow.setColor(GREEN); arrow.setBold(true);
            }
        }
    }

    private void addWordTimeline(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun marker = p.createRun(); marker.setText("●  "); marker.setColor(GREEN); marker.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCardsTable(XWPFDocument doc, SemanticSection section) {
        XWPFTable table = doc.createTable(Math.max(1, section.items().size()), 3);
        int r = 0;
        for (SemanticItem item : safe(section.items())) {
            setCellText(table.getRow(r).getCell(0), item.label(), true, GREEN_DARK);
            setCellText(table.getRow(r).getCell(1), item.value(), false, "1F2D25");
            setCellText(table.getRow(r).getCell(2), item.status(), true, GREEN);
            if (r % 2 == 1) {
                for (XWPFTableCell cell : table.getRow(r).getTableCells()) cell.setColor("F7FBF8");
            }
            r++;
        }
    }

    private void addWordChecklist(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setColor(GREEN); tick.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCallouts(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            applyParagraphShading(p, GREEN_SOFT);
            XWPFRun run = p.createRun();
            String icon = iconCatalog.symbol(item.iconKey());
            run.setText((icon.isBlank() ? "" : icon + "  ") + joinItem(item));
            run.setFontFamily("Arial"); run.setFontSize(10);
        }
    }

    private void addWordBlocks(XWPFDocument doc, List<DocumentBlock> blocks) {
        for (DocumentBlock block : blocks) {
            if (block.type() == BlockType.SPACER) { doc.createParagraph(); continue; }
            XWPFParagraph p = doc.createParagraph();
            XWPFRun run = p.createRun();
            String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
            switch (block.type()) {
                case TITLE -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(20); p.setSpacingAfter(180); }
                case HEADING -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(14); p.setSpacingBefore(160); p.setSpacingAfter(80); }
                case BULLET -> {
                    XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setBold(true); tick.setColor(GREEN);
                    run.setText(stripBullet(block.text())); run.setFontFamily("Arial"); run.setFontSize(10); p.setIndentationLeft(240);
                }
                case CODE -> { run.setText(block.text()); run.setFontFamily("Consolas"); run.setFontSize(9); applyParagraphShading(p, "F3F6F4"); }
                case CALLOUT -> { run.setText(icon + block.text()); run.setFontFamily("Arial"); run.setFontSize(10); applyParagraphShading(p, GREEN_SOFT); }
                default -> { run.setText(block.text()); run.setFontFamily("Arial"); run.setFontSize(10); }
            }
            applyEmphasis(run, block.emphasis());
        }
    }

    private void setCellText(XWPFTableCell cell, String text, boolean bold, String color) {
        XWPFParagraph p = cell.getParagraphs().isEmpty() ? cell.addParagraph() : cell.getParagraphs().get(0);
        p.setSpacingAfter(0);
        XWPFRun run = p.createRun();
        run.setText(text == null ? "" : text);
        run.setBold(bold); run.setColor(color); run.setFontFamily("Arial"); run.setFontSize(9);
    }


    private byte[] powerpoint(String htmlContent, FormattedDocument document) throws Exception {
        if (htmlContent != null && !htmlContent.isBlank()) {
            return powerpointFromHtml(htmlContent, document);
        }
        return powerpoint(document);
    }

    /**
     * Converts the LLM's slide-oriented semantic HTML fragment into a real .pptx.
     * The model decides the editorial slide structure; Java applies a stable
     * PowerPoint design system with professional slide splitting, agenda creation,
     * two-column topic layouts, process layouts, table slides and keynote-style
     * slides.  This keeps the LLM focused on story and coverage while Java owns
     * visual consistency and readability.
     */
    private byte[] powerpointFromHtml(String htmlContent, FormattedDocument document) throws Exception {
        List<PptSlideModel> models = preparePresentationSlides(htmlToSlides(htmlContent, document));
        try (XMLSlideShow ppt = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ppt.setPageSize(new Dimension(960, 540));
            String deckTitle = models.isEmpty() ? "Formatted Presentation" : models.get(0).title();
            int contentSlideCount = Math.max(0, (int) models.stream().filter(s -> !s.titleSlide()).count());
            addGeneratedTitleSlide(ppt, deckTitle, document, contentSlideCount);
            int slideNumber = 1;
            for (int i = 1; i < models.size(); i++) {
                if (!models.get(i).titleSlide()) addGeneratedContentSlide(ppt, models.get(i), slideNumber++);
            }
            if (ppt.getSlides().size() == 1) {
                addGeneratedContentSlide(ppt,
                        new PptSlideModel("📌 Key Points", List.of(nonBlank(document.plainContent(), "Generated content is ready.")), List.of(), List.of(), false, "bullets"),
                        1);
            }
            ppt.write(out);
            return out.toByteArray();
        }
    }

    private List<PptSlideModel> htmlToSlides(String htmlContent, FormattedDocument document) {
        Document doc = Jsoup.parseBodyFragment(htmlContent == null ? "" : htmlContent);
        List<PptSlideModel> slides = new ArrayList<>();
        String deckTitle = firstText(doc.select("h1"));
        if (deckTitle.isBlank()) deckTitle = firstText(doc.select("h2"));
        if (deckTitle.isBlank()) deckTitle = nonBlank(document.emailSubject(), document.title(), "Formatted Presentation");
        slides.add(new PptSlideModel(cleanPptText(deckTitle, 86), List.of(), List.of(), List.of(), true, "title"));

        MutablePptSlide current = null;
        for (Element child : doc.body().children()) {
            String tag = child.tagName();
            if ("h1".equals(tag)) {
                if (slides.size() == 1 && slides.get(0).title().equals("Formatted Presentation")) {
                    slides.set(0, new PptSlideModel(cleanPptText(child.text(), 86), List.of(), List.of(), List.of(), true, "title"));
                }
                continue;
            }
            if ("h2".equals(tag)) {
                if (current != null) slides.add(current.freeze());
                current = new MutablePptSlide(cleanPptText(child.text(), 86));
                continue;
            }
            if (current == null) current = new MutablePptSlide("📌 Overview");

            switch (tag) {
                case "h3", "h4" -> current.startSubsection(cleanPptText(child.text(), 80));
                case "p" -> current.addBullet(cleanPptText(child.text(), 150));
                case "blockquote" -> current.addTakeaway(cleanPptText(child.text(), 150));
                case "pre" -> current.addBullet("⚙️ " + cleanPptText(child.text(), 135));
                case "ul", "ol" -> {
                    if ("ol".equals(tag) && current.layoutHint.isBlank()) current.layoutHint = "process";
                    for (Element li : child.select("li")) current.addBullet(cleanPptText(li.text(), 140));
                }
                case "table" -> current.addTable(extractTableRows(child));
                case "hr" -> current.layoutHint = "divider";
                default -> {
                    String text = child.text();
                    if (text != null && !text.isBlank()) current.addBullet(cleanPptText(text, 145));
                }
            }
        }
        if (current != null) slides.add(current.freeze());

        if (slides.size() == 1) {
            String plain = nonBlank(document.plainContent(), doc.body().text());
            slides.addAll(plainTextFallbackSlides(plain));
        }
        return slides;
    }

    private List<PptSlideModel> preparePresentationSlides(List<PptSlideModel> original) {
        List<PptSlideModel> slides = splitOverloadedSlides(original == null ? List.of() : original);
        if (slides.size() <= 1) return slides;
        long contentSlides = slides.stream().filter(s -> !s.titleSlide()).count();
        boolean hasAgenda = slides.stream().anyMatch(s -> normalizedTitle(s.title()).contains("agenda") || normalizedTitle(s.title()).contains("contents"));
        if (contentSlides >= 5 && !hasAgenda) {
            List<String> agenda = slides.stream()
                    .filter(s -> !s.titleSlide())
                    .map(s -> stripLeadingPresentationIcon(s.title()))
                    .filter(t -> !t.isBlank())
                    .limit(7)
                    .map(t -> cleanPptText(t, 78))
                    .toList();
            if (!agenda.isEmpty()) {
                List<PptSlideModel> withAgenda = new ArrayList<>();
                withAgenda.add(slides.get(0));
                withAgenda.add(new PptSlideModel("📋 Agenda", agenda, List.of(), List.of(), false, "agenda"));
                withAgenda.addAll(slides.subList(1, slides.size()));
                slides = withAgenda;
            }
        }
        return slides;
    }

    private List<PptSlideModel> splitOverloadedSlides(List<PptSlideModel> slides) {
        List<PptSlideModel> result = new ArrayList<>();
        for (PptSlideModel slide : slides) {
            if (slide.titleSlide()) {
                result.add(slide);
                continue;
            }
            if (!slide.subSections().isEmpty() && slide.subSections().size() > 4) {
                int part = 1;
                for (int i = 0; i < slide.subSections().size(); i += 4) {
                    String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                    List<PptSubsection> subset = slide.subSections().subList(i, Math.min(i + 4, slide.subSections().size()));
                    List<String> bullets = part == 1 ? slide.bullets() : List.of();
                    result.add(new PptSlideModel(title, bullets, List.of(), subset, false, "two-column"));
                    part++;
                }
                continue;
            }
            if (slide.tableRows().isEmpty() && slide.subSections().isEmpty() && slide.bullets().size() > 6) {
                List<String> bullets = slide.bullets();
                int part = 1;
                for (int i = 0; i < bullets.size(); i += 5) {
                    String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                    result.add(new PptSlideModel(title, bullets.subList(i, Math.min(i + 5, bullets.size())), List.of(), List.of(), false, slide.layoutHint()));
                    part++;
                }
                continue;
            }
            result.add(slide);
        }
        return result;
    }

    private List<PptSlideModel> plainTextFallbackSlides(String plain) {
        List<PptSlideModel> slides = new ArrayList<>();
        List<String> items = Arrays.stream((plain == null ? "" : plain).split("\\R+"))
                .map(String::trim)
                .filter(v -> !v.isBlank())
                .map(v -> cleanPptText(v, 135))
                .toList();
        for (int i = 0; i < items.size(); i += 5) {
            slides.add(new PptSlideModel(i == 0 ? "📌 Overview" : "📌 Overview (continued)",
                    items.subList(i, Math.min(i + 5, items.size())), List.of(), List.of(), false, "bullets"));
        }
        if (slides.isEmpty()) slides.add(new PptSlideModel("📌 Overview", List.of("Generated content is ready."), List.of(), List.of(), false, "bullets"));
        return slides;
    }

    private List<List<String>> extractTableRows(Element table) {
        List<List<String>> rows = new ArrayList<>();
        for (Element tr : table.select("tr")) {
            List<String> cells = new ArrayList<>();
            for (Element cell : tr.select("th,td")) cells.add(cleanPptText(cell.text(), 84));
            if (!cells.isEmpty()) rows.add(cells);
            if (rows.size() >= 10) break;
        }
        return rows;
    }

    private void addGeneratedTitleSlide(XMLSlideShow ppt, String title, FormattedDocument document, int slideCount) {
        XSLFSlide slide = ppt.createSlide();
        addPptRect(slide, 0, 0, 960, 540, new Color(247, 251, 248), null);
        addPptRect(slide, 0, 0, 960, 18, new Color(0, 133, 66), null);
        addPptRect(slide, 0, 512, 960, 28, new Color(0, 85, 45), null);
        addPptRect(slide, 54, 92, 96, 8, new Color(0, 133, 66), null);
        addPptText(slide, 54, 122, 760, 106, cleanPptText(title, 92), 36, true, new Color(0, 85, 45), null);
        String subtitle = nonBlank(document.purpose(), "Professional Presentation") + " • " + nonBlank(document.audience(), "General audience");
        addPptText(slide, 58, 238, 760, 34, subtitle, 15, false, new Color(81, 103, 91), null);
        if (slideCount > 0) addPptText(slide, 58, 296, 420, 28, slideCount + " focused slide" + (slideCount == 1 ? "" : "s"), 13, true, new Color(0, 107, 54), new Color(238, 248, 242));
        addPptRect(slide, 735, 300, 132, 132, new Color(238, 248, 242), new Color(185, 223, 202));
        addPptText(slide, 766, 333, 70, 60, "✦", 44, true, new Color(0, 133, 66), null);
        addPptText(slide, 58, 516, 340, 18, "Generated by FormatFlow AI", 9, false, Color.WHITE, null);
    }

    private void addGeneratedContentSlide(XMLSlideShow ppt, PptSlideModel model, int slideNumber) {
        XSLFSlide slide = newSlide(ppt, cleanPptText(model.title(), 84), "NONE");
        addPptText(slide, 850, 38, 60, 26, String.valueOf(slideNumber), 12, true, new Color(0, 133, 66), null);
        String layout = chooseSlideLayout(model);
        switch (layout) {
            case "agenda" -> addAgendaSlide(slide, model);
            case "table" -> addTableContentSlide(slide, model);
            case "two-column" -> addTwoColumnTopicSlide(slide, model);
            case "process" -> addProcessSlide(slide, model);
            case "key-message" -> addKeyMessageSlide(slide, model);
            default -> addBulletContentSlide(slide, model);
        }
        addPptRect(slide, 55, 498, 850, 1.5, new Color(207, 228, 215), null);
    }

    private String chooseSlideLayout(PptSlideModel model) {
        String hint = model.layoutHint() == null ? "" : model.layoutHint().toLowerCase(Locale.ROOT);
        String title = normalizedTitle(model.title());
        if (hint.contains("agenda") || title.contains("agenda") || title.contains("contents")) return "agenda";
        if (!model.tableRows().isEmpty()) return "table";
        if (!model.subSections().isEmpty()) return "two-column";
        if (hint.contains("process") || title.contains("process") || title.contains("workflow") || title.contains("steps") || title.contains("flow")) return "process";
        if (model.bullets().size() <= 3 && model.bullets().stream().mapToInt(String::length).sum() <= 260) return "key-message";
        return "bullets";
    }

    private void addAgendaSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets().isEmpty() ? List.of("Overview", "Key topics", "Next steps") : model.bullets();
        double y = 108;
        for (int i = 0; i < Math.min(7, bullets.size()); i++) {
            addPptText(slide, 82, y + i * 48, 34, 34, String.valueOf(i + 1), 13, true, Color.WHITE, new Color(0, 133, 66));
            addPptText(slide, 126, y + i * 48, 720, 34, cleanPptText(bullets.get(i), 92), 17, false, new Color(31, 45, 37), null);
        }
    }

    private void addTableContentSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets();
        if (!bullets.isEmpty()) addGeneratedBullets(slide, bullets.subList(0, Math.min(2, bullets.size())), 62, 88, 835, 72);
        addGeneratedTable(slide, model.tableRows(), 62, bullets.isEmpty() ? 98 : 176, 835, bullets.isEmpty() ? 365 : 285);
    }

    private void addTwoColumnTopicSlide(XSLFSlide slide, PptSlideModel model) {
        if (!model.bullets().isEmpty()) {
            addPptText(slide, 66, 88, 820, 38, cleanPptText(model.bullets().get(0), 138), 14, true, new Color(0, 107, 54), new Color(238, 248, 242));
        }
        List<PptSubsection> sections = model.subSections();
        int cols = sections.size() <= 2 ? 2 : 2;
        double cardW = 390, cardH = sections.size() <= 2 ? 145 : 126, gapX = 38, gapY = 22;
        double startX = 66, startY = model.bullets().isEmpty() ? 104 : 146;
        for (int i = 0; i < Math.min(4, sections.size()); i++) {
            int row = i / cols, col = i % cols;
            PptSubsection s = sections.get(i);
            double x = startX + col * (cardW + gapX), y = startY + row * (cardH + gapY);
            addPptRect(slide, x, y, cardW, cardH, new Color(247, 251, 248), new Color(185, 223, 202));
            addPptText(slide, x + 12, y + 8, cardW - 24, 26, cleanPptText(s.title(), 58), 14, true, new Color(0, 107, 54), null);
            List<String> points = s.bullets().isEmpty() ? List.of("Key point captured from the source content.") : s.bullets();
            double py = y + 42;
            for (int j = 0; j < Math.min(3, points.size()); j++) {
                addPptText(slide, x + 18, py + j * 26, cardW - 36, 24, "• " + cleanPptText(points.get(j), 76), 10.5, false, new Color(31, 45, 37), null);
            }
        }
    }

    private void addProcessSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> steps = model.bullets().isEmpty() ? List.of("Understand", "Prepare", "Execute", "Review") : model.bullets();
        int count = Math.min(5, steps.size());
        double startX = 66, y = 176, boxW = count <= 4 ? 168 : 145, gap = count <= 4 ? 40 : 24;
        for (int i = 0; i < count; i++) {
            double x = startX + i * (boxW + gap);
            addPptText(slide, x, y - 44, 40, 34, String.valueOf(i + 1), 14, true, Color.WHITE, new Color(0, 133, 66));
            addPptRect(slide, x, y, boxW, 116, new Color(247, 251, 248), new Color(185, 223, 202));
            addPptText(slide, x + 10, y + 16, boxW - 20, 72, cleanPptText(steps.get(i), 82), 12, true, new Color(31, 45, 37), null);
            if (i < count - 1) addPptText(slide, x + boxW + 2, y + 34, gap - 4, 38, "→", 22, true, new Color(0, 133, 66), null);
        }
    }

    private void addKeyMessageSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets().isEmpty() ? List.of("Key information captured from the source content.") : model.bullets();
        addPptText(slide, 72, 122, 790, 110, cleanPptText(bullets.get(0), 165), 26, true, new Color(0, 85, 45), null);
        if (bullets.size() > 1) {
            List<String> secondary = bullets.subList(1, Math.min(4, bullets.size()));
            addGeneratedBullets(slide, secondary, 86, 260, 760, 130);
        }
        addPptRect(slide, 72, 238, 92, 5, new Color(0, 133, 66), null);
    }

    private void addBulletContentSlide(XSLFSlide slide, PptSlideModel model) {
        addGeneratedBullets(slide, model.bullets(), 74, 108, 800, 342);
    }

    private void addGeneratedBullets(XSLFSlide slide, List<String> bullets, double x, double y, double w, double h) {
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(x, y, w, h));
        box.setTopInset(4); box.setBottomInset(4); box.setLeftInset(4); box.setRightInset(4);
        box.clearText();
        List<String> safeBullets = bullets == null || bullets.isEmpty() ? List.of("Key information captured from the source content.") : bullets;
        int shown = Math.min(6, safeBullets.size());
        double size = shown <= 3 ? 18 : shown <= 5 ? 15.5 : 14;
        for (int i = 0; i < shown; i++) {
            XSLFTextParagraph p = box.addNewTextParagraph();
            p.setSpaceAfter(8d);
            XSLFTextRun run = p.addNewTextRun();
            run.setText("• " + cleanPptText(safeBullets.get(i), 145));
            run.setFontFamily("Arial");
            run.setFontSize(size);
            run.setFontColor(new Color(31, 45, 37));
        }
    }

    private void addGeneratedTable(XSLFSlide slide, List<List<String>> rows, double x, double y, double w, double h) {
        if (rows == null || rows.isEmpty()) return;
        int cols = rows.stream().mapToInt(List::size).max().orElse(2);
        cols = Math.max(1, Math.min(cols, 5));
        int rowCount = Math.min(rows.size(), 9);
        double cellW = w / cols;
        double rowH = Math.min(39, h / Math.max(2, rowCount));
        for (int r = 0; r < rowCount; r++) {
            List<String> row = rows.get(r);
            for (int c = 0; c < cols; c++) {
                String value = c < row.size() ? row.get(c) : "";
                boolean header = r == 0;
                XSLFTextBox cell = addPptText(slide, x + c * cellW, y + r * rowH, cellW, rowH,
                        value, header ? 11.5 : 10.2, header, header ? Color.WHITE : new Color(31, 45, 37),
                        header ? new Color(0, 107, 54) : (r % 2 == 0 ? Color.WHITE : new Color(247, 251, 248)));
                cell.setLineColor(new Color(185, 215, 197));
            }
        }
    }

    private void addPptRect(XSLFSlide slide, double x, double y, double w, double h, Color fill, Color line) {
        XSLFAutoShape shape = slide.createAutoShape();
        shape.setShapeType(ShapeType.RECT);
        shape.setAnchor(new Rectangle2D.Double(x, y, w, h));
        if (fill != null) shape.setFillColor(fill);
        shape.setLineColor(line == null ? fill : line);
    }

    private String firstText(Elements elements) {
        for (Element element : elements) {
            String text = element.text();
            if (text != null && !text.isBlank()) return text.trim();
        }
        return "";
    }

    private String nonBlank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value.trim();
        return "";
    }

    private String cleanPptText(String value, int maxChars) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        if (text.length() <= maxChars) return text;
        int cut = Math.max(20, text.lastIndexOf(' ', maxChars - 1));
        if (cut < maxChars / 2) cut = maxChars;
        return text.substring(0, Math.min(cut, text.length())).trim() + "…";
    }

    private String normalizedTitle(String value) {
        return stripLeadingPresentationIcon(value).toLowerCase(Locale.ROOT);
    }

    private String stripLeadingPresentationIcon(String value) {
        String text = value == null ? "" : value.trim();
        return text.replaceFirst("^[\\p{So}\\p{Cn}\\p{Sk}\\p{Sm}\\uFE0F\\s]+", "").trim();
    }

    private boolean hasLeadingPresentationIcon(String value) {
        if (value == null || value.isBlank()) return false;
        int cp = value.trim().codePointAt(0);
        int type = Character.getType(cp);
        return type == Character.OTHER_SYMBOL || type == Character.MATH_SYMBOL || type == Character.MODIFIER_SYMBOL;
    }

    private record PptSubsection(String title, List<String> bullets) {}

    private record PptSlideModel(String title,
                                 List<String> bullets,
                                 List<List<String>> tableRows,
                                 List<PptSubsection> subSections,
                                 boolean titleSlide,
                                 String layoutHint) {}

    private static final class MutablePptSubsection {
        private final String title;
        private final List<String> bullets = new ArrayList<>();
        private MutablePptSubsection(String title) { this.title = title == null || title.isBlank() ? "Topic" : title; }
        private PptSubsection freeze() { return new PptSubsection(title, List.copyOf(bullets)); }
    }

    private static final class MutablePptSlide {
        private final String title;
        private final List<String> bullets = new ArrayList<>();
        private final List<MutablePptSubsection> subSections = new ArrayList<>();
        private MutablePptSubsection currentSubsection;
        private List<List<String>> tableRows = List.of();
        private String layoutHint = "";

        private MutablePptSlide(String title) { this.title = title == null || title.isBlank() ? "📌 Topic" : title; }
        private void startSubsection(String value) {
            currentSubsection = new MutablePptSubsection(value);
            subSections.add(currentSubsection);
            if (layoutHint.isBlank()) layoutHint = "two-column";
        }
        private void addBullet(String value) {
            if (value == null || value.isBlank()) return;
            if (currentSubsection != null) currentSubsection.bullets.add(value);
            else bullets.add(value);
        }
        private void addTakeaway(String value) {
            if (value == null || value.isBlank()) return;
            bullets.add(0, "💡 " + value);
        }
        private void addTable(List<List<String>> rows) {
            if (rows != null && !rows.isEmpty()) {
                tableRows = rows;
                currentSubsection = null;
                if (layoutHint.isBlank()) layoutHint = "table";
            }
        }
        private PptSlideModel freeze() {
            return new PptSlideModel(title, List.copyOf(bullets), tableRows,
                    subSections.stream().map(MutablePptSubsection::freeze).toList(), false, layoutHint);
        }
    }

    private byte[] powerpoint(FormattedDocument document) throws Exception {
        try (XMLSlideShow ppt = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ppt.setPageSize(new Dimension(960, 540));
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    switch (layout(section)) {
                        case TABLE, COMPARISON -> pptTableSlide(ppt, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> pptFlowSlide(ppt, section);
                        case STATUS, KPI -> pptCardsSlide(ppt, section);
                        case TIMELINE -> pptTimelineSlide(ppt, section);
                        case CHECKLIST, CALLOUT -> pptItemsSlide(ppt, section);
                        case TEXT, CODE_GROUP -> pptTextSlides(ppt, referencedBlocks(section, blocks), "");
                    }
                }
            } else {
                pptTextSlides(ppt, document.blocks(), document.title());
            }

            if (ppt.getSlides().isEmpty()) pptTextSlides(ppt, document.blocks(), document.title());
            ppt.write(out);
            return out.toByteArray();
        }
    }

    private XSLFSlide newSlide(XMLSlideShow ppt, String title, String iconKey) {
        XSLFSlide slide = ppt.createSlide();
        XSLFAutoShape accent = slide.createAutoShape();
        accent.setShapeType(ShapeType.RECT);
        accent.setAnchor(new Rectangle2D.Double(0, 0, 960, 12));
        accent.setFillColor(new Color(0, 133, 66)); accent.setLineColor(new Color(0, 133, 66));
        if (title != null && !title.isBlank()) {
            String icon = hasLeadingPresentationIcon(title) ? "" : iconCatalog.symbol(iconKey);
            addPptText(slide, 54, 32, 850, 42, (icon.isBlank() ? "" : icon + "  ") + title,
                    23, true, new Color(0, 107, 54), null);
        }
        return slide;
    }

    private void pptTableSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        int rows = Math.min(10, section.rows().size());
        double left = 55, top = section.title().isBlank() ? 48 : 92, width = 850;
        double cellW = width / cols;
        double rowH = Math.min(42, 360.0 / Math.max(2, rows + 1));

        for (int c = 0; c < cols; c++) {
            addPptText(slide, left + c * cellW, top, cellW, rowH, headers.get(c), 12, true, Color.WHITE, new Color(0, 107, 54));
        }
        for (int r = 0; r < rows; r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String text = c < cells.size() ? cells.get(c).text() : "";
                addPptText(slide, left + c * cellW, top + (r + 1) * rowH, cellW, rowH, text,
                        11, false, new Color(31, 45, 37), r % 2 == 0 ? Color.WHITE : new Color(247, 251, 248));
            }
        }
    }

    private void pptFlowSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        int perRow = Math.min(4, Math.max(2, nodes.size()));
        double nodeW = 165, nodeH = 70, gapX = 45, startX = 60, startY = section.title().isBlank() ? 80 : 125;

        for (int i = 0; i < nodes.size(); i++) {
            int row = i / perRow, col = i % perRow;
            double x = startX + col * (nodeW + gapX);
            double y = startY + row * 140;
            SemanticNode node = nodes.get(i);
            String icon = iconCatalog.symbol(node.iconKey());
            addPptText(slide, x, y, nodeW, nodeH, (icon.isBlank() ? "" : icon + "  ") + node.text(),
                    12, true, new Color(0, 107, 54), new Color(238, 248, 242));
            if (i < nodes.size() - 1 && (i + 1) % perRow != 0) {
                SemanticEdge edge = edgeMap.get(node.id());
                String label = edge == null || edge.label() == null ? "" : edge.label();
                addPptText(slide, x + nodeW + 4, y + 14, gapX - 8, 42, (label.isBlank() ? "" : label + "\n") + "→",
                        12, true, new Color(0, 133, 66), null);
            }
        }
    }

    private void pptCardsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticItem> items = safe(section.items());
        int cols = 3;
        double cardW = 250, cardH = 105, gapX = 28, gapY = 22, startX = 62, startY = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(items.size(), 9); i++) {
            int row = i / cols, col = i % cols;
            SemanticItem item = items.get(i);
            String icon = iconCatalog.symbol(item.iconKey());
            addPptText(slide, startX + col * (cardW + gapX), startY + row * (cardH + gapY), cardW, cardH,
                    (icon.isBlank() ? "" : icon + "  ") + joinItem(item), 12, i < 3, new Color(31, 45, 37), new Color(247, 251, 248));
        }
    }

    private void pptTimelineSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double x = 105, y = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(section.items().size(), 8); i++) {
            SemanticItem item = section.items().get(i);
            addPptText(slide, x, y + i * 48, 40, 35, "●", 16, true, new Color(0, 133, 66), null);
            addPptText(slide, x + 46, y + i * 48, 730, 40, joinItem(item), 12, false, new Color(31, 45, 37), null);
        }
    }

    private void pptItemsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double y = section.title().isBlank() ? 70 : 112;
        for (int i = 0; i < Math.min(section.items().size(), 10); i++) {
            SemanticItem item = section.items().get(i);
            String prefix = layout(section) == SemanticLayoutType.CHECKLIST ? "✓  " : iconCatalog.symbol(item.iconKey()) + "  ";
            addPptText(slide, 78, y + i * 38, 800, 34, prefix + joinItem(item), 12, false,
                    new Color(31, 45, 37), layout(section) == SemanticLayoutType.CALLOUT ? new Color(238, 248, 242) : null);
        }
    }

    private void pptTextSlides(XMLSlideShow ppt, List<DocumentBlock> blocks, String sectionTitle) {
        List<List<DocumentBlock>> chunks = slides(blocks);
        for (int index = 0; index < chunks.size(); index++) {
            XSLFSlide slide = newSlide(ppt, index == 0 ? sectionTitle : "", "DOCUMENT");
            XSLFTextBox box = slide.createTextBox();
            box.setAnchor(new Rectangle2D.Double(58, sectionTitle != null && !sectionTitle.isBlank() && index == 0 ? 92 : 45, 845, 420));
            box.setTopInset(0); box.setBottomInset(0); box.setLeftInset(0); box.setRightInset(0); box.clearText();
            for (DocumentBlock block : chunks.get(index)) {
                if (block.type() == BlockType.SPACER) continue;
                XSLFTextParagraph p = box.addNewTextParagraph(); p.setSpaceAfter(5d);
                XSLFTextRun run = p.addNewTextRun();
                String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
                String text = switch (block.type()) {
                    case BULLET -> "✓  " + stripBullet(block.text());
                    case TITLE, HEADING, CALLOUT -> icon + block.text();
                    default -> block.text();
                };
                run.setText(text); run.setFontFamily(block.type() == BlockType.CODE ? "Consolas" : "Arial");
                if (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) {
                    run.setFontSize(block.type() == BlockType.TITLE ? 22d : 17d); run.setBold(true); run.setFontColor(new Color(0, 110, 55));
                } else {
                    run.setFontSize(block.type() == BlockType.CODE ? 10d : 12d); run.setFontColor(new Color(32, 45, 38));
                }
            }
        }
    }

    private XSLFTextBox addPptText(XSLFSlide slide, double x, double y, double w, double h, String text,
                                   double size, boolean bold, Color textColor, Color fill) {
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(x, y, w, h));
        box.setTopInset(6); box.setBottomInset(4); box.setLeftInset(7); box.setRightInset(7);
        if (fill != null) box.setFillColor(fill);
        XSLFTextParagraph p = box.addNewTextParagraph();
        XSLFTextRun run = p.addNewTextRun();
        run.setText(text == null ? "" : text); run.setFontFamily("Arial"); run.setFontSize(size); run.setBold(bold); run.setFontColor(textColor);
        return box;
    }

    private byte[] pdf(FormattedDocument document) throws Exception {
        try (PDDocument doc = new PDDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            PdfFontResolver.FontPair fonts = pdfFontResolver.resolve(doc);
            PdfCanvas canvas = new PdfCanvas(doc, fonts.regular(), fonts.bold());
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) canvas.sectionTitle(section.title(), section.iconKey());
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> canvas.table(section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> canvas.flow(section);
                        case STATUS, KPI, TIMELINE, CHECKLIST, CALLOUT -> canvas.items(section);
                        case TEXT, CODE_GROUP -> canvas.blocks(referencedBlocks(section, blocks));
                    }
                    canvas.gap(8);
                }
            } else {
                canvas.blocks(document.blocks());
            }
            canvas.close();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private final class PdfCanvas {
        private final PDDocument doc;
        private final PDFont regular;
        private final PDFont bold;
        private PDPage page;
        private PDPageContentStream stream;
        private final float margin = 48;
        private float y;

        private PdfCanvas(PDDocument doc, PDFont regular, PDFont bold) throws Exception {
            this.doc = doc; this.regular = regular; this.bold = bold; newPage();
        }

        private void newPage() throws Exception {
            if (stream != null) stream.close();
            page = new PDPage(PDRectangle.A4); doc.addPage(page); stream = new PDPageContentStream(doc, page);
            y = page.getMediaBox().getHeight() - 48;
            stream.setNonStrokingColor(new Color(0, 133, 66)); stream.addRect(0, page.getMediaBox().getHeight() - 10, page.getMediaBox().getWidth(), 10); stream.fill();
        }

        private void ensure(float height) throws Exception { if (y - height < margin) newPage(); }
        private void gap(float value) { y -= value; }

        private void sectionTitle(String title, String iconKey) throws Exception {
            if (title == null || title.isBlank()) return;
            ensure(30);
            String icon = iconCatalog.pdfSymbol(iconKey);
            line((icon.isBlank() ? "" : icon + "  ") + title, bold, 13, true, margin, 18);
            gap(5);
        }

        private void table(SemanticSection section) throws Exception {
            int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
            List<String> headers = paddedColumns(section.columns(), cols);
            float totalW = page.getMediaBox().getWidth() - 2 * margin;
            float cellW = totalW / cols;
            float rowH = 25;
            ensure(rowH * 2);
            drawTableRow(headers, cols, cellW, rowH, true);
            for (SemanticRow row : safe(section.rows())) {
                ensure(rowH);
                List<String> values = safe(row.cells()).stream().map(SemanticValue::text).toList();
                drawTableRow(values, cols, cellW, rowH, false);
            }
            gap(6);
        }

        private void drawTableRow(List<String> values, int cols, float cellW, float rowH, boolean header) throws Exception {
            for (int c = 0; c < cols; c++) {
                float x = margin + c * cellW;
                if (header) {
                    stream.setNonStrokingColor(new Color(0, 107, 54)); stream.addRect(x, y - rowH, cellW, rowH); stream.fill();
                }
                stream.setStrokingColor(new Color(207, 228, 215)); stream.addRect(x, y - rowH, cellW, rowH); stream.stroke();
                String value = c < values.size() ? values.get(c) : "";
                drawAt(fit(value, header ? bold : regular, 9, cellW - 10), header ? bold : regular, 9,
                        header ? Color.WHITE : new Color(31, 45, 37), x + 5, y - 16);
            }
            y -= rowH;
        }

        private void flow(SemanticSection section) throws Exception {
            List<SemanticNode> nodes = safe(section.nodes());
            for (int i = 0; i < nodes.size(); i++) {
                if (i > 0) line("↓", bold, 12, true, margin + 35, 16);
                ensure(38);
                stream.setNonStrokingColor(new Color(238, 248, 242)); stream.addRect(margin, y - 28, 260, 28); stream.fill();
                stream.setStrokingColor(new Color(0, 133, 66)); stream.addRect(margin, y - 28, 260, 28); stream.stroke();
                String icon = iconCatalog.pdfSymbol(nodes.get(i).iconKey());
                drawAt(fit((icon.isBlank() ? "" : icon + "  ") + nodes.get(i).text(), bold, 10, 248), bold, 10,
                        new Color(0, 107, 54), margin + 6, y - 18);
                y -= 32;
            }
        }

        private void items(SemanticSection section) throws Exception {
            SemanticLayoutType type = layout(section);
            for (SemanticItem item : safe(section.items())) {
                String prefix = switch (type) {
                    case CHECKLIST -> "✓  ";
                    case TIMELINE -> "●  ";
                    default -> {
                        String symbol = iconCatalog.pdfSymbol(item.iconKey());
                        yield symbol.isBlank() ? "•  " : symbol + "  ";
                    }
                };
                line(prefix + joinItem(item), regular, 10, false, margin, 14);
            }
        }

        private void blocks(List<DocumentBlock> blocks) throws Exception {
            for (DocumentBlock block : blocks) {
                if (block.type() == BlockType.SPACER) { gap(7); continue; }
                boolean heading = block.type() == BlockType.TITLE || block.type() == BlockType.HEADING;
                PDFont font = heading ? bold : regular;
                float size = block.type() == BlockType.TITLE ? 17 : (block.type() == BlockType.HEADING ? 12 : 9.5f);
                String prefix = switch (block.type()) {
                    case BULLET -> "✓  ";
                    case TITLE, HEADING, CALLOUT -> {
                        String symbol = iconCatalog.pdfSymbol(block.iconKey()); yield symbol.isBlank() ? "" : symbol + "  ";
                    }
                    default -> "";
                };
                line(prefix + (block.type() == BlockType.BULLET ? stripBullet(block.text()) : block.text()), font, size, heading, margin, heading ? 18 : 13);
                if (heading) gap(4);
            }
        }

        private void line(String text, PDFont font, float size, boolean green, float x, float leading) throws Exception {
            List<String> lines = wrap(text, font, size, page.getMediaBox().getWidth() - x - margin);
            for (String value : lines) {
                ensure(leading + 2);
                drawAt(value, font, size, green ? new Color(0, 107, 54) : new Color(31, 45, 37), x, y);
                y -= leading;
            }
        }

        private void drawAt(String text, PDFont font, float size, Color color, float x, float yPos) throws Exception {
            stream.beginText(); stream.setFont(font, size); stream.setNonStrokingColor(color); stream.newLineAtOffset(x, yPos); stream.showText(safeForFont(font, text)); stream.endText();
        }

        private String fit(String value, PDFont font, float size, float maxWidth) throws Exception {
            String safe = safeForFont(font, value == null ? "" : value);
            if (font.getStringWidth(safe) / 1000f * size <= maxWidth) return safe;
            String suffix = "...";
            while (!safe.isEmpty() && font.getStringWidth(safe + suffix) / 1000f * size > maxWidth) safe = safe.substring(0, safe.length() - 1);
            return safe + suffix;
        }

        private void close() throws Exception { if (stream != null) stream.close(); }
    }

    private List<String> wrap(String text, PDFont font, float size, float width) throws Exception {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) { result.add(""); return result; }
        for (String hardLine : text.split("\\R", -1)) {
            String[] words = hardLine.split("\\s+");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String candidate = line.isEmpty() ? word : line + " " + word;
                float w = font.getStringWidth(safeForFont(font, candidate)) / 1000f * size;
                if (!line.isEmpty() && w > width) { result.add(line.toString()); line = new StringBuilder(word); }
                else line = new StringBuilder(candidate);
            }
            result.add(line.toString());
        }
        return result;
    }

    private String safeForFont(PDFont font, String text) {
        StringBuilder out = new StringBuilder();
        text.codePoints().forEach(cp -> {
            String s = new String(Character.toChars(cp));
            try { font.getStringWidth(s); out.append(s); }
            catch (Exception ex) { out.append('?'); }
        });
        return out.toString();
    }

    private List<List<DocumentBlock>> slides(List<DocumentBlock> blocks) {
        List<List<DocumentBlock>> slides = new ArrayList<>();
        List<DocumentBlock> current = new ArrayList<>();
        int weight = 0;
        for (DocumentBlock block : blocks) {
            int blockWeight = Math.max(1, (block.text().length() / 85) + 1);
            boolean headingBreak = (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) && !current.isEmpty() && weight >= 7;
            if (headingBreak || weight + blockWeight > 13) { slides.add(List.copyOf(current)); current.clear(); weight = 0; }
            current.add(block); weight += blockWeight;
        }
        if (!current.isEmpty()) slides.add(List.copyOf(current));
        if (slides.isEmpty()) slides.add(List.of());
        return slides;
    }

    private boolean hasSemantic(FormattedDocument document) {
        return document.semanticSections() != null && !document.semanticSections().isEmpty();
    }

    private SemanticLayoutType layout(SemanticSection section) {
        try { return SemanticLayoutType.valueOf(section.layoutType().toUpperCase(Locale.ROOT)); }
        catch (Exception ex) { return SemanticLayoutType.TEXT; }
    }

    private Map<String, DocumentBlock> blockMap(FormattedDocument document) {
        return document.blocks().stream().collect(Collectors.toMap(DocumentBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    private List<DocumentBlock> referencedBlocks(SemanticSection section, Map<String, DocumentBlock> blocks) {
        List<DocumentBlock> result = new ArrayList<>();
        for (String id : safe(section.sourceIds())) if (blocks.containsKey(id)) result.add(blocks.get(id));
        return result;
    }

    private List<String> paddedColumns(List<String> columns, int count) {
        List<String> result = new ArrayList<>(safe(columns));
        while (result.size() < count) result.add(result.isEmpty() ? "Item" : "Details");
        return result.subList(0, count);
    }

    private String joinItem(SemanticItem item) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank()) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank()) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank()) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private <T> List<T> safe(List<T> values) { return values == null ? List.of() : values; }

    private void applyParagraphShading(XWPFParagraph p, String fill) {
        CTShd shd = p.getCTP().getPPr() == null ? p.getCTP().addNewPPr().addNewShd() : p.getCTP().getPPr().addNewShd();
        shd.setVal(STShd.CLEAR); shd.setFill(fill);
    }

    private void applyEmphasis(XWPFRun run, String emphasis) {
        if ("STRONG".equalsIgnoreCase(emphasis)) run.setBold(true);
        if ("MUTED".equalsIgnoreCase(emphasis)) run.setColor("6F7F76");
    }

    private String stripBullet(String text) {
        return text == null ? "" : text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "");
    }

    private String sanitizeFilename(String value) {
        String sanitized = value.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return sanitized.isBlank() ? "formatflow-output" : sanitized;
    }

    public record ExportedFile(String filename, String contentType, byte[] bytes) {}
}
