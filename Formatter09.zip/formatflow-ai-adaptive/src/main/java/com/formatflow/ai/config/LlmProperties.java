package com.formatflow.ai.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "formatflow.llm")
public class LlmProperties {

    private String baseUrl;
    private String model;
    private String chatPath = "/chat/completions";
    private String authHeader = "Authorization";
    private String authPrefix = "Bearer ";
    private boolean authAutoDetect = true;
    private int connectTimeoutSeconds = 15;
    private int requestTimeoutSeconds = 90;
    private int maxCompletionTokens = 4096;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getChatPath() {
        return chatPath;
    }

    public void setChatPath(String chatPath) {
        this.chatPath = chatPath;
    }

    public String getAuthHeader() {
        return authHeader;
    }

    public void setAuthHeader(String authHeader) {
        this.authHeader = authHeader;
    }

    public String getAuthPrefix() {
        return authPrefix;
    }

    public void setAuthPrefix(String authPrefix) {
        this.authPrefix = authPrefix == null ? "" : authPrefix;
    }

    public boolean isAuthAutoDetect() {
        return authAutoDetect;
    }

    public void setAuthAutoDetect(boolean authAutoDetect) {
        this.authAutoDetect = authAutoDetect;
    }

    public int getConnectTimeoutSeconds() {
        return connectTimeoutSeconds;
    }

    public void setConnectTimeoutSeconds(int connectTimeoutSeconds) {
        this.connectTimeoutSeconds = connectTimeoutSeconds;
    }

    public int getRequestTimeoutSeconds() {
        return requestTimeoutSeconds;
    }

    public void setRequestTimeoutSeconds(int requestTimeoutSeconds) {
        this.requestTimeoutSeconds = requestTimeoutSeconds;
    }

    public int getMaxCompletionTokens() {
        return maxCompletionTokens;
    }

    public void setMaxCompletionTokens(int maxCompletionTokens) {
        this.maxCompletionTokens = Math.max(256, maxCompletionTokens);
    }
}
