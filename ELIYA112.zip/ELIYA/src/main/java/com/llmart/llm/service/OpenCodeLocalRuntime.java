package com.llmart.llm.service;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * A Java-17-only OpenCode 2 launcher. Users need an installed OpenCode 2 binary,
 * but do not need npm, a terminal, a fixed port or a manually configured password
 * when ELIYA is started from its JAR.
 *
 * Never binds beyond 127.0.0.1; each ELIYA instance owns its own child process.
 */
public final class OpenCodeLocalRuntime {
    private static final Pattern V2 = Pattern.compile("(?i)(?:^|\\s)(?:opencode\\s*)?v?2\\.[0-9]+(?:\\.[0-9]+)?(?:\\s|$)");
    private static final SecureRandom RANDOM = new SecureRandom();
    private final boolean windows;
    private final Map<String,String> env;
    private final Deque<String> recentOutput = new ArrayDeque<>();
    private volatile String activePassword = "";
    private volatile String activeProviderKey = "";
    private volatile String activeProxyUrl = "";
    private volatile String activeHttpProxyUrl = "";

    /** Small scrubbed in-memory diagnostic tail; never persist raw OpenCode output. */
    public synchronized String lastOutput() {
        return recentOutput.isEmpty() ? "No OpenCode process messages recorded" : String.join(" | ", recentOutput);
    }
    private synchronized void recordOutput(String line) {
        if (line == null || line.isBlank()) return;
        String cleaned = line.replace(activePassword.isBlank() ? "\u0000" : activePassword, "[REDACTED]")
            .replace(activeProviderKey.isBlank() ? "\u0000" : activeProviderKey, "[REDACTED]")
            .replace(activeProxyUrl.isBlank() ? "\u0000" : activeProxyUrl, "[REDACTED PROXY]")
            .replace(activeHttpProxyUrl.isBlank() ? "\u0000" : activeHttpProxyUrl, "[REDACTED PROXY]")
            .replaceAll("(?i)((?:bearer|basic)\\s+)[^\\s]+", "$1[REDACTED]")
            .replaceAll("(?i)((?:token|password|apikey|api_key|secret)[=:\"\\s]+)[^\\s]+", "$1[REDACTED]");
        recentOutput.addLast(cleaned.length() > 300 ? cleaned.substring(0, 300) : cleaned);
        while (recentOutput.size() > 15) recentOutput.removeFirst();
    }

    public OpenCodeLocalRuntime() { this(System.getProperty("os.name", ""), System.getenv()); }

    // Allows deterministic discovery tests on every development platform.
    OpenCodeLocalRuntime(String os, Map<String,String> env) {
        this.windows = os.toLowerCase(Locale.ROOT).contains("win");
        this.env = env;
    }

    public record Command(List<String> prefix, String location) {
        public List<String> withArgs(String... args) {
            List<String> result = new ArrayList<>(prefix);
            if (prefix.size() > 1 && "cmd.exe".equalsIgnoreCase(prefix.get(0))) {
                // Safe for a discovered, local batch launcher. Do not use untrusted prompt text here.
                StringBuilder line = new StringBuilder("\"\"").append(location).append('"');
                for (String arg : args) line.append(' ').append(arg);
                line.append('"');
                result.add(line.toString());
            } else result.addAll(List.of(args));
            return result;
        }
    }

    public Command findV2(String preferred) throws IOException {
        LinkedHashSet<Path> candidates = new LinkedHashSet<>();
        String configured = preferred == null || preferred.isBlank() ? "opencode" : preferred.trim();
        Path named = Path.of(configured);
        if (named.isAbsolute() || configured.contains("/") || configured.contains("\\")) {
            candidates.add(named.toAbsolutePath().normalize());
        } else {
            String path = env.getOrDefault("PATH", env.getOrDefault("Path", ""));
            for (String dir : path.split(Pattern.quote(System.getProperty("path.separator")))) {
                if (!dir.isBlank()) appendCandidates(candidates, Path.of(dir), configured);
            }
            if (windows) {
                appendCandidates(candidates, Path.of(env.getOrDefault("APPDATA", ""), "npm"), configured);
                String appData = env.getOrDefault("APPDATA", "");
                if (!appData.isBlank()) {
                    candidates.add(Path.of(appData, "npm", "node_modules", "@opencode", "cli", "bin", "opencode.exe"));
                }
                String local = env.getOrDefault("LOCALAPPDATA", "");
                if (!local.isBlank()) candidates.add(Path.of(local, "Programs", "opencode", "opencode.exe"));
            } else {
                String home = System.getProperty("user.home", "");
                for (String dir : List.of("/usr/local/bin", "/usr/bin", "/opt/homebrew/bin",
                        home + "/.local/bin", home + "/.bun/bin", home + "/.opencode/bin")) {
                    appendCandidates(candidates, Path.of(dir), configured);
                }
            }
        }
        for (Path candidate : candidates) {
            try {
                if (!Files.isRegularFile(candidate)) continue;
                Command command = commandFor(candidate);
                Process check = new ProcessBuilder(command.withArgs("--version"))
                        .redirectErrorStream(true).start();
                boolean finished = check.waitFor(5, TimeUnit.SECONDS);
                if (!finished) { check.destroyForcibly(); continue; }
                String version = new String(check.getInputStream().readNBytes(1024));
                if (check.exitValue() == 0 && V2.matcher(version.trim()).find()) return command;
            } catch (Exception ignored) { /* old or broken binary; examine next candidate */ }
        }
        throw new IOException("OpenCode 2 executable was not found. Install OpenCode 2 and check 'opencode --version' in a new terminal; then restart ELIYA. The legacy engine remains an optional manual setting.");
    }

    private void appendCandidates(LinkedHashSet<Path> out, Path directory, String name) {
        if (windows) {
            out.add(directory.resolve(name + ".exe"));
            out.add(directory.resolve(name + ".cmd"));
            out.add(directory.resolve(name + ".bat"));
        } else out.add(directory.resolve(name));
    }

    private Command commandFor(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (windows && (name.endsWith(".cmd") || name.endsWith(".bat")))
            return new Command(List.of("cmd.exe", "/d", "/s", "/c"), file.toString());
        return new Command(List.of(file.toString()), file.toString());
    }

    public int availableLoopbackPort() throws IOException {
        try (ServerSocket socket = new ServerSocket()) {
            socket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            return socket.getLocalPort();
        }
    }

    public String randomPassword() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    static String mergeNoProxy(String existing) {
        LinkedHashSet<String> entries = new LinkedHashSet<>();
        if (existing != null) for (String item : existing.split(",")) {
            String trimmed = item.trim();
            if (!trimmed.isBlank()) entries.add(trimmed);
        }
        // Required for Java -> OpenCode loopback traffic, without losing existing entries.
        entries.add("localhost");
        entries.add("127.0.0.1");
        entries.add("::1");
        return String.join(",", entries);
    }

    public Process start(Command command, int port, String password) throws IOException {
        return start(command, port, password, Map.of(), null);
    }

    /** Give the dedicated OpenCode child a per-ELIYA provider config, never global user config. */
    public Process start(Command command, int port, String password, Map<String,String> extraEnvironment, String jsonConfig) throws IOException {
        ProcessBuilder pb = new ProcessBuilder(command.withArgs("serve", "--hostname", "127.0.0.1",
                "--port", Integer.toString(port)));
        // OpenCode v2 officially documents OPENCODE_SERVER_PASSWORD; retain the
        // earlier variable for compatibility with previous 2.x releases.
        pb.environment().put("OPENCODE_SERVER_PASSWORD", password);
        pb.environment().put("OPENCODE_PASSWORD", password);
        if (extraEnvironment != null) pb.environment().putAll(extraEnvironment);
        if (jsonConfig != null && !jsonConfig.isBlank()) {
            // OpenCode v2 supports inline config; OPENCODE_CONFIG is a compatibility fallback.
            // Some early v2 builds ignore OPENCODE_CONFIG, so always set CONFIG_CONTENT.
            // Keep API keys OUT of both JSON config representations.
            Path config = Files.createTempFile("eliya-opencode-v2-", ".json");
            Files.writeString(config, jsonConfig, StandardCharsets.UTF_8);
            config.toFile().deleteOnExit();
            pb.environment().put("OPENCODE_CONFIG", config.toAbsolutePath().toString());
            pb.environment().put("OPENCODE_CONFIG_CONTENT", jsonConfig);
        }
        // JAR launches do not inherit npm CLI settings automatically. Use approved
        // proxy entries from the user's existing ~/.npmrc only when no process proxy
        // is configured, preserving explicit process env as the highest priority.
        OpenCodeProxyConfig.apply(pb.environment(),
                Path.of(System.getProperty("user.home", "."), ".npmrc"));
        // Preserve the user's corporate NO_PROXY exclusions. Overwriting them can
        // break access to internal LLM gateways / artifact servers on company PCs.
        String currentBypass = pb.environment().getOrDefault("NO_PROXY",
                pb.environment().getOrDefault("no_proxy", ""));
        String mergedBypass = mergeNoProxy(currentBypass);
        pb.environment().put("NO_PROXY", mergedBypass);
        pb.environment().put("no_proxy", mergedBypass);
        // OpenCode 2 supports these environment variables for server-side error logs.
        // ERROR avoids detailed prompt/tool dumps; output is never persisted raw.
        pb.environment().put("OPENCODE_PRINT_LOGS", "1");
        pb.environment().put("OPENCODE_LOG_LEVEL", "ERROR");
        // OpenCode documents this environment flag on all supported platforms.
        // ELIYA owns indexing; an OpenCode file watcher must not retain user
        // workspace handles once a task has completed.
        pb.environment().put("OPENCODE_EXPERIMENTAL_DISABLE_FILEWATCHER", "true");
        // Discarding stderr used to erase startup/provider failures. Drain the process
        // output into a *scrubbed*, bounded memory tail, never a public log file.
        synchronized (this) {
            recentOutput.clear(); activePassword = password;
            activeProviderKey = extraEnvironment == null ? ""
                    : extraEnvironment.getOrDefault(OpenCodeUiProviderConfig.KEY_ENV, "");
            activeProxyUrl = pb.environment().getOrDefault("HTTPS_PROXY",
                    pb.environment().getOrDefault("https_proxy", ""));
            activeHttpProxyUrl = pb.environment().getOrDefault("HTTP_PROXY",
                    pb.environment().getOrDefault("http_proxy", ""));
        }
        pb.redirectErrorStream(true);
        Process process = pb.start();
        Thread drain = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) recordOutput(line);
            } catch (IOException ignored) { /* terminated process */ }
        }, "eliya-opencode-process-diagnostics");
        drain.setDaemon(true);
        drain.start();
        return process;
    }
}
