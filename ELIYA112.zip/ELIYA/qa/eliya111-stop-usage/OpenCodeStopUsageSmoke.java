import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeTokenLedger;
import com.sun.net.httpserver.HttpServer;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Executable regression for folder-only completion, honest Stop and provider aggregate usage. */
public final class OpenCodeStopUsageSmoke {
    static void check(boolean ok,String message) {if(!ok)throw new AssertionError(message);}
    static Field field(Class<?> c,String name) throws Exception {Field f=c.getDeclaredField(name);f.setAccessible(true);return f;}
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        ObjectMapper json=new ObjectMapper();
        OpenCodeTokenLedger ledger=new OpenCodeTokenLedger();
        ledger.nextTask(json.readTree("{\"input\":100,\"output\":20,\"reasoning\":3,\"cache\":{\"read\":50,\"write\":0}}"),false);
        ledger.record("asst_one","model","OpenCode model call",json.readTree("{}"));
        ledger.acceptSessionAggregate(json.readTree("{\"input\":140,\"output\":35,\"reasoning\":5,\"cache\":{\"read\":58,\"write\":2}}"));
        Map<String,Object> usage=ledger.taskSnapshot(1000,"opencode","model");
        check(Boolean.TRUE.equals(usage.get("providerReported")),"Aggregate provider tokens must be available");
        check(((Number)usage.get("providerTotalTokens")).intValue()==65,"Task delta should be 40+15+8+2 =65, no double counting");
        check("aggregate_delta".equals(usage.get("usageStatus")),"Token source should be labelled aggregate delta");
        OpenCodeTokenLedger restored=new OpenCodeTokenLedger();
        restored.restoreCalls(json.readTree(json.writeValueAsString(ledger.exportCalls())));
        restored.restoreAggregate(json.readTree(json.writeValueAsString(ledger.exportAggregate())));
        check(((Number)restored.taskSnapshot(2000,"opencode","model").get("providerTotalTokens")).intValue()==65,
                "Aggregate-only token accounting must persist across JAR restarts");
        ledger.record("asst_one","model","OpenCode model call",json.readTree("{\"input\":40,\"output\":15,\"reasoning\":2,\"cache\":{\"read\":8,\"write\":2}}"));
        check(((Number)ledger.taskSnapshot(1000,"opencode","model").get("providerTotalTokens")).intValue()==65,
                "Per-model reconciliation must not add the same aggregate twice");
        System.out.println("PASS: OpenCode token delta, per-call deduplication, restart persistence");

        Path temp=Files.createTempDirectory("eliya111-");
        Path workspace=Files.createDirectories(temp.resolve("workspace"));
        System.setProperty("eliya.qa.workspace",workspace.toString());
        System.setProperty("eliya.opencode.sessionStore",temp.resolve("store").toString());
        AtomicBoolean active=new AtomicBoolean(false);
        HttpServer mock=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        mock.createContext("/api",exchange->{
            try {
                String url=exchange.getRequestURI().toString();
                String body = "{\"data\":{}}";
                if (url.equals("/api/session/active"))
                    body=active.get()?"{\"data\":{\"ses111\":{\"status\":\"busy\"}}}":"{\"data\":{}}";
                else if (url.startsWith("/api/session/ses111/message"))
                    body="{\"data\":[{\"id\":\"asst_111\",\"type\":\"assistant\",\"tokens\":{\"input\":2,\"output\":3,\"reasoning\":0,\"cache\":{\"read\":0,\"write\":0}},\"content\":[{\"type\":\"text\",\"text\":\"Created the folder\"}]},{\"id\":\"usr_111\",\"type\":\"user\",\"text\":\"Create folder demo\"}]}";
                else if(url.startsWith("/api/session/ses111/diff")) body="{\"data\":[]}";
                else if(url.contains("/interrupt")) body="{\"data\":{\"interrupted\":true}}";
                byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type","application/json");
                exchange.sendResponseHeaders(200,bytes.length);
                try(var os=exchange.getResponseBody()){os.write(bytes);}
            } catch(Exception e){throw new RuntimeException(e);}
        });
        mock.start();
        OpenCodeExecutionService service=null;
        try {
            service=new OpenCodeExecutionService(json,new com.llmart.llm.service.ProjectService(),"opencode",
                    "http://127.0.0.1:"+mock.getAddress().getPort(),"","opencode",false);
            Class<?> cls=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
            Constructor<?> ctor=cls.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
            ctor.setAccessible(true);
            String id="oc-eeeeeeee-0000-4000-8000-000000000111";
            Object session=ctor.newInstance(id,"ses111","conversation","project111","model","Create folder demo");
            field(cls,"status").set(session,"running");
            field(cls,"lastPromptId").set(session,"usr_111");
            Map<String,Object> sessions=(Map<String,Object>)field(OpenCodeExecutionService.class,"sessions").get(service);
            sessions.put(id,session);
            Method scan=OpenCodeExecutionService.class.getDeclaredMethod("workspaceDirectories",String.class);
            scan.setAccessible(true);
            Set<String> baseline=(Set<String>)scan.invoke(service,"project111");
            check(baseline!=null && baseline.isEmpty(),"Blank workspace baseline should be available");
            field(cls,"directoryBaseline").set(session,baseline);
            Files.createDirectories(workspace.resolve("demo"));
            Method verify=OpenCodeExecutionService.class.getDeclaredMethod("reconcileCompletion",cls);
            verify.setAccessible(true);
            verify.invoke(service,session);
            Map<String,Object> completed=service.get(id);
            check("completed".equals(completed.get("status")),"Empty folder creation should be verifiable without a file diff");
            Map<String,Object> report=(Map<String,Object>)completed.get("changeReport");
            check(((Number)report.get("createdDirectories")).intValue()==1,"Directory delta should be present in report");
            System.out.println("PASS: directory-only task can complete with physically verified folder");

            field(cls,"status").set(session,"running");
            active.set(true);
            Map<String,Object> noStop=service.cancel(id);
            check("stalled".equals(noStop.get("status")),"External server still ACTIVE must not be claimed cancelled");
            active.set(false);
            Map<String,Object> stopped=service.cancel(id);
            check("cancelled".equals(stopped.get("status")),"Stop succeeds only after IDLE is observed");
            System.out.println("PASS: Stop does not falsely report cancellation before remote exits");

            // A dedicated managed child is safe to release after the last task is completed.
            Process owned=new ProcessBuilder("sleep","90").start();
            field(OpenCodeExecutionService.class,"managedProcess").set(service,owned);
            field(cls,"status").set(session,"completed");
            Method cleanup=OpenCodeExecutionService.class.getDeclaredMethod("releaseManagedProcessWhenIdle");
            cleanup.setAccessible(true);
            cleanup.invoke(service);
            Thread.sleep(2700);
            check(!owned.isAlive(),"JAR-owned OpenCode child must be terminated after a finished task");
            System.out.println("PASS: idle dedicated subprocess cleanup and workspace-handle release");
        } finally {if(service!=null)service.shutdown();mock.stop(0);}
    }
}
