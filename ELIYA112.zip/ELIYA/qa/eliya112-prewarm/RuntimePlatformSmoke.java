import com.llmart.llm.service.OpenCodeLocalRuntime;
import java.lang.reflect.Constructor;
import java.nio.file.*;
import java.util.*;

/** Simulates executable discovery rules for Windows, macOS, and Linux. */
public final class RuntimePlatformSmoke {
    private static void check(boolean ok, String reason) { if (!ok) throw new AssertionError(reason); }
    public static void main(String[] args) throws Exception {
        Constructor<OpenCodeLocalRuntime> make=OpenCodeLocalRuntime.class
                .getDeclaredConstructor(String.class,Map.class);
        make.setAccessible(true);
        Path dir=Files.createTempDirectory("eliya-platform-");
        for (String os : List.of("Windows 11", "Mac OS X", "Linux")) {
            String filename=os.startsWith("Windows") ? "opencode.exe" : "opencode";
            Path executable=dir.resolve(filename);
            Files.writeString(executable,"#!/bin/sh\necho '2.2.2'\n");
            executable.toFile().setExecutable(true);
            OpenCodeLocalRuntime runtime=make.newInstance(os,Map.of("PATH",dir.toString()));
            OpenCodeLocalRuntime.Command command=runtime.findV2("opencode");
            check(executable.toString().equals(command.location()), os + " PATH lookup failed");
            List<String> invocation=command.withArgs("serve", "--hostname", "127.0.0.1");
            check(invocation.contains("serve") && invocation.contains("127.0.0.1"),
                    os + " ProcessBuilder command must include arguments");
        }
        System.out.println("PASS: simulated Windows, macOS and Linux executable discovery and portable command assembly");
    }
}
