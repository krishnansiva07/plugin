#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya101-ui-provider/MockOpenCodeV2.java \
  qa/eliya112-prewarm/OpenCodePrewarmSmoke.java \
  qa/eliya112-prewarm/RuntimePlatformSmoke.java
cat > "$TMP/opencode-mock" <<'SCRIPT'
#!/bin/sh
if [ "${1:-}" = '--version' ]; then echo '2.2.2'; exit 0; fi
printf '%s' "${OPENCODE_EXPERIMENTAL_DISABLE_FILEWATCHER:-}" > "$ELIYA_QA_ENV_FILE"
exec "$ELIYA_QA_JAVA" -cp "$ELIYA_QA_CLASSPATH" MockOpenCodeV2 "$@"
SCRIPT
chmod +x "$TMP/opencode-mock"
export ELIYA_QA_JAVA="$(command -v java)" ELIYA_QA_CLASSPATH="$TMP" \
  ELIYA_QA_MOCK_BINARY="$TMP/opencode-mock" ELIYA_QA_ENV_FILE="$TMP/env.txt"
java -cp "$TMP" OpenCodePrewarmSmoke
java -cp "$TMP" RuntimePlatformSmoke
node --check src/main/resources/static/app.js
