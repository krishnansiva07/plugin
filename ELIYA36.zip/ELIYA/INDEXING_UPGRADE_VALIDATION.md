# ELIYA Scalable Flow-Aware Indexing Upgrade

## Implemented
- Removed the default 40,000 indexed-file and 150,000 scanned-file ceilings. Repository size no longer truncates indexing by itself.
- Optional positive safety caps remain supported with `eliya.index.maxFiles` and `eliya.index.maxScannedFiles`; `0`/unset means unlimited by count.
- Promoted index/stat counters to 64-bit values so large repository counts are reported safely through Chat/Agent project status.
- Reduced retained per-file source excerpts (default 6k source / 16k document characters) while keeping live-file reads authoritative for returned evidence. This lowers heap/checkpoint growth for large repositories.
- Kept full-file streaming lexical term indexing for source files larger than the cached sample, avoiding full large-file string allocation during term indexing.
- Added bounded lazy posting lists for repeated query terms so Chat and Agent do not repeatedly scan every indexed file for the same search terms.
- Retained changed-path incremental refresh, persisted checkpoints, semantic reranking/fallback, secret exclusions, and live-file verification.
- Retained flow-aware retrieval: frontend, controller, service, calculation, data, model, config and test layer classification; Java/TypeScript route relationships; business aliases for alert/KPI/histogram/calculation/data-flow questions; bounded 2-hop relationship expansion.
- Natural-language Chat questions such as “How is alert calculated?” trigger workspace retrieval without requiring words such as class, method or source code.

## Large-scale validation completed
- `bash qa/unbounded-indexing-smoke/run.sh` — PASS.
  - 40,250 eligible files indexed in one workspace (deliberately above the previous 40,000 ceiling).
  - `scanIncomplete=false`; no count-based truncation occurred.
  - Cross-layer Alert Dashboard -> controller -> service -> KPI/calculation -> repository flow was retrieved from the same 40,250-file workspace.
  - Version 5 checkpoint-assisted restart/rescan retained all 40,250 files and retrieval remained functional.
  - Validation ran with a 768 MB Java heap.
- `bash qa/intelligence-smoke/run.sh` — PASS.
  - 2,000-file flow scenario, Java AST, TypeScript route discovery, Cucumber mapping, semantic-vector persistence, incremental updates and secret exclusions passed.
  - Production Java syntax scan passed for 86 source files.
- `bash qa/offline-smoke/run.sh` — PASS.
- `node --check src/main/resources/static/app.js` — PASS.
- `node --test src/test/js/*.test.js` — 18/18 PASS.

## Capacity semantics
“Unlimited” means **no artificial file-count cutoff in Eliya**. The practical maximum is still bounded by the host machine (filesystem, available heap/disk, per-file size settings and the amount of searchable metadata in the repository). Generated/dependency folders and secret/unsupported files remain intentionally excluded.

## Build environment limitation
A complete Maven/Spring Boot JAR cannot be rebuilt in this container because Maven is not installed and the environment cannot resolve Maven Central. The included Maven wrapper attempts to bootstrap Maven but network/DNS access is unavailable. Run `mvn -Pfull-tests clean package` (or `./mvnw -Pfull-tests clean package`) in a connected Java 17 build environment before distributing the final JAR.
