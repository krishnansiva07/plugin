package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;

public final class UnboundedIndexingSmoke {
    public static void main(String[] args) throws Exception {
        System.clearProperty("eliya.index.maxFiles");
        System.clearProperty("eliya.index.maxScannedFiles");
        Path root = Files.createTempDirectory("eliya-unbounded-index-");
        try {
            final int count = 40_250; // deliberately above the old 40,000-file ceiling
            Path files = Files.createDirectories(root.resolve("src/generated"));
            for (int i = 0; i < count - 5; i++) {
                Files.writeString(files.resolve("f" + i + ".txt"), "shared index fixture " + i);
            }
            Path frontend = Files.createDirectories(root.resolve("src/frontend"));
            Path backend = Files.createDirectories(root.resolve("src/backend"));
            Files.writeString(frontend.resolve("AlertDashboard.ts"),
                    "export async function loadAlertHistogram(){ return fetch('/api/alerts'); }\n");
            Files.writeString(backend.resolve("AlertController.java"),
                    "import org.springframework.web.bind.annotation.*; @RestController @RequestMapping(\"/api\") " +
                            "class AlertController { AlertService alertService; @GetMapping(\"/alerts\") Object alerts(){ return alertService.calculateAlert(); } }");
            Files.writeString(backend.resolve("AlertService.java"),
                    "class AlertService { KpiCalculator kpiCalculator; double calculateAlert(){ return kpiCalculator.calculateKpi(); } }");
            Files.writeString(backend.resolve("KpiCalculator.java"),
                    "class KpiCalculator { AlertRepository repository; double calculateKpi(){ double histogram = repository.histogramBuckets(); return histogram * 0.75; } }");
            Files.writeString(backend.resolve("AlertRepository.java"),
                    "class AlertRepository { double histogramBuckets(){ return 12.0; } }");

            WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
            var stats = index.warmRoot("unbounded", root);
            check(stats.indexedFiles() == count, "all files indexed beyond old 40k ceiling: " + stats.indexedFiles());
            check(!stats.scanIncomplete(), "scan is complete without configured count cap");

            String answer = index.retrieveRoot("unbounded", root,
                    "How is alert calculated and how are histogram and KPI values calculated and displayed?", 20, 30_000);
            check(answer.contains("AlertDashboard.ts"), "frontend flow retrieved");
            check(answer.contains("AlertController.java"), "controller flow retrieved");
            check(answer.contains("KpiCalculator.java"), "calculation flow retrieved");
            check(answer.contains("AlertRepository.java"), "data flow retrieved");

            // Verify the persisted v5 checkpoint also reloads a workspace above the old ceiling.
            WorkspaceRetrievalIndexService restarted = new WorkspaceRetrievalIndexService(null);
            var restartedStats = restarted.warmRoot("unbounded", root);
            check(restartedStats.indexedFiles() == count, "checkpoint-assisted rescan keeps all files");
            String afterRestart = restarted.retrieveRoot("unbounded", root, "calculateAlert KPI histogram", 12, 16_000);
            check(afterRestart.contains("AlertService.java"), "checkpoint reload above old ceiling works");
            System.out.println("PASS: " + count + " files indexed with no default file-count truncation; deep-flow retrieval and checkpoint reload verified");
        } finally {
            delete(root);
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new IllegalStateException("FAIL: " + message);
    }

    private static void delete(Path root) throws Exception {
        if (root == null || !Files.exists(root)) return;
        try (var walk = Files.walk(root)) {
            for (Path path : walk.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
        }
    }
}
