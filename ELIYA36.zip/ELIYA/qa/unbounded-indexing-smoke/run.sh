#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
find "$BASE/qa/unbounded-indexing-smoke/src" -name '*.java' > "$TEMP/source-list"
cat >> "$TEMP/source-list" <<SOURCES
$BASE/src/main/java/com/llmart/llm/service/WorkspaceCodeIntelligence.java
$BASE/src/main/java/com/llmart/llm/service/WorkspaceEmbeddingStore.java
$BASE/src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
SOURCES
javac -encoding UTF-8 -d "$TEMP/classes" @"$TEMP/source-list"
java -Xmx768m -Dapp.data-dir="$TEMP/data" -cp "$TEMP/classes" com.llmart.llm.service.UnboundedIndexingSmoke
