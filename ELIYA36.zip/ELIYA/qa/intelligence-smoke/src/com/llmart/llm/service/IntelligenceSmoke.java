package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
import com.llmart.llm.dto.ChatSettings;
public class IntelligenceSmoke {
 private static void check(boolean pass, String message) { if (!pass) throw new AssertionError(message); }
 public static void main(String[] argv) throws Exception {
  Path home = Files.createTempDirectory("eliya-intelligence-home-");
  Path root = Files.createTempDirectory("eliya-intelligence-project-");
  System.setProperty("app.data-dir", home.toString());
  Files.createDirectories(root.resolve("src/pages"));
  Files.createDirectories(root.resolve("src/tests"));
  Files.writeString(root.resolve("src/pages/LoginPage.java"),
      "package pages; public class LoginPage { private String apiKey = \"SUPERSECRET123\"; public boolean verifyCredentials(String user) { return user != null; } }");
  Files.writeString(root.resolve("src/tests/LoginTest.java"),
      "package tests; import pages.LoginPage; public class LoginTest { LoginPage page = new LoginPage(); }");
  Files.writeString(root.resolve("src/pages/login.page.ts"),
      "export class LoginPage {\n  async login(user: string) { return user; }\n}");
  Files.writeString(root.resolve("src/tests/login.spec.ts"),
      "import {LoginPage} from '../pages/login.page'; test('login', async () => {});");
  Files.writeString(root.resolve("src/tests/login.feature"),
      "Feature: Login\n Scenario: Valid login\n Given I enter valid credentials\n When I click login\n Then I reach the dashboard");
  Files.writeString(root.resolve("src/tests/LoginSteps.java"),
      "package tests; import io.cucumber.java.en.Given; import io.cucumber.java.en.When;" +
      "public class LoginSteps { @Given(\"I enter valid credentials\") public void credentials() {} " +
      "@When(\"I click login\") public void clickLogin() {} }");
  OpenAiCompatibleClient llm = new OpenAiCompatibleClient();
  WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(llm);
  var ws = AgentWorkspaceService.Workspace.forIndex("smoke", root);
  check(index.refresh(ws).indexedFiles() == 6, "six code and feature files indexed");
  String symbols = index.retrieve(ws, "verifyCredentials", 5, 6000);
  check(symbols.contains("LoginPage.java") && symbols.contains("method:verifyCredentials"), "Java AST method indexed and searchable");
  check(index.retrieve(ws, "login(user", 5, 6000).contains("method:login"), "TypeScript method declared and indexed");
  String impact = index.impactReport(ws, "LoginPage.java verifyCredentials", 5000);
  check(impact.contains("LoginTest.java") && impact.contains("open the CURRENT"), "Java import graph and evidence requirement");
  String tsImpact = index.impactReport(ws, "login.page.ts", 5000);
  check(tsImpact.contains("login.spec.ts"), "TypeScript relative import graph");
  String steps = index.impactReport(ws, "LoginSteps.java", 5000);
  check(steps.contains("login.feature"), "Cucumber feature maps to annotated Java step definitions");
  var settings = new ChatSettings("http://example.invalid", "stub-embedding", true);
  check(index.retrieveHybrid(ws, "verifyCredentials", 5, 6_000, "key", settings, () -> false).contains("LoginPage.java"), "hybrid retrieves code");
  check(llm.mostRecentInputs.stream().noneMatch(v -> v.contains("SUPERSECRET123")),
          "credential-shaped values redacted before embedding");
  int first = llm.embeddedInputs;
  index.retrieveHybrid(ws, "verifyCredentials?", 5, 6_000, "key", settings, () -> false);
  check(llm.embeddedInputs - first == 1, "only new query embedded: candidate vectors reused");
  llm.fail = true;
  check(index.retrieveHybrid(ws, "verifyCredentials fallback", 5, 6000, "key", settings, () -> false).contains("LoginPage.java"),
      "embedding provider failure falls back to local retrieval");
  var restarted = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
  check(restarted.refresh(ws).indexedFiles() == 6, "index checkpoint reused after restart");
  var secondLlm = new OpenAiCompatibleClient();
  var second = new WorkspaceRetrievalIndexService(secondLlm);
  second.refresh(ws);
  second.retrieveHybrid(ws, "verifyCredentials after restart", 5, 6_000, "key", settings, () -> false);
  check(secondLlm.embeddedInputs == 1, "document vectors persisted after restart");
  check(second.retrieveHybrid(ws, "authentication", 5, 6_000, "key", settings, () -> false).contains("LoginPage.java"),
      "persisted semantic neighbors can be retrieved without keyword matches");
  Files.writeString(root.resolve("src/pages/LoginPage.java"),
      "package pages; public class LoginPage { public boolean checkNewCredentials(String user) { return user != null; } }");
  second.refreshPaths(ws, List.of("src/pages/LoginPage.java"));
  check(second.retrieve(ws, "checkNewCredentials", 5, 6_000).contains("method:checkNewCredentials"), "incremental symbol updates");
  check(!second.impactReport(ws, "checkNewCredentials", 3_000).contains("method:verifyCredentials"), "old symbols evicted");
  second.retrieveHybrid(ws, "checkNewCredentials", 5, 6_000, "key", settings, () -> false);
  check(secondLlm.embeddedInputs > 1, "changed file gets a fresh vector");
  Files.delete(root.resolve("src/tests/LoginTest.java"));
  second.refreshPaths(ws, List.of("src/tests/LoginTest.java"));
  check(!second.impactReport(ws, "LoginTest.java", 3_000).contains("Candidate: src/tests/LoginTest.java"), "deleted file removed from graph/index");
  Files.writeString(root.resolve(".env"), "API_KEY=should-never-leak");
  check(second.refresh(ws).indexedFiles() == 5, "secrets excluded from index");
  check(!second.retrieve(ws, "should-never-leak", 5, 6000).contains("should-never-leak"), "no secret retrieval");
  Files.createDirectories(root.resolve("src/fixtures"));
  for (int i = 0; i < 1094; i++) Files.writeString(root.resolve("src/fixtures/sample" + i + ".txt"),
          "Test fixture " + i);
  check(second.refresh(ws).indexedFiles() == 1099, "1099 file incremental workspace scenario");

  // Scale target: 2,000 supported files while preserving cross-layer application-flow retrieval.
  for (int i = 1094; i < 1990; i++) Files.writeString(root.resolve("src/fixtures/sample" + i + ".txt"),
          "Additional bounded fixture " + i);
  Path frontend = Files.createDirectories(root.resolve("src/frontend"));
  Path backend = Files.createDirectories(root.resolve("src/backend"));
  Files.writeString(frontend.resolve("AlertDashboard.ts"),
          "export async function loadAlertHistogram(){ return fetch('/api/alerts'); }\n");
  Files.writeString(backend.resolve("AlertController.java"),
          "import org.springframework.web.bind.annotation.*; @RestController @RequestMapping(\"/api\") " +
          "class AlertController { AlertService alertService; @GetMapping(\"/alerts\") Object alerts(){ return alertService.calculateAlert(); } }");
  Files.writeString(backend.resolve("AlertService.java"),
          "class AlertService { KpiCalculator kpiCalculator; double calculateAlert(){ return kpiCalculator.calculateKpi(); } }");
  Files.writeString(backend.resolve("KpiCalculator.java"),
          "class KpiCalculator { AlertRepository repository; double calculateKpi(){ double histogram = repository.histogramBuckets(); return histogram * 0.75; } }");
  Files.writeString(backend.resolve("AlertRepository.java"),
          "class AlertRepository { double histogramBuckets(){ return 12.0; } }");
  var scaled = second.refresh(ws);
  check(scaled.indexedFiles() == 2000, "2,000-file workspace indexed without truncation");
  check(!scaled.scanIncomplete(), "2,000-file workspace scan complete");
  String flow = second.retrieve(ws,
          "How is alert calculated and how are different histograms and KPI values calculated and displayed?", 20, 30_000);
  check(flow.contains("AlertDashboard.ts"), "deep flow includes frontend");
  check(flow.contains("AlertController.java"), "deep flow includes controller");
  check(flow.contains("AlertService.java"), "deep flow includes service");
  check(flow.contains("KpiCalculator.java"), "deep flow includes calculation layer");
  check(flow.contains("AlertRepository.java"), "deep flow includes data layer");
  check(flow.contains("deep application/data flow"), "deep flow intent reported");
  System.out.println("PASS: 2000-file workspace, cross-layer deep-flow retrieval, Java AST, TS routes, Cucumber steps, vector persistence, incremental updates, secret exclusions");
 }
}
