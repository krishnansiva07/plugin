package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class WorkspaceRetrievalIndexScaleFlowTest {
    @TempDir Path workspace;

    @Test
    void indexesTwoThousandFilesAndRetrievesFrontendToDataCalculationFlow() throws Exception {
        Path fixtures = Files.createDirectories(workspace.resolve("fixtures"));
        for (int i = 0; i < 1_995; i++)
            Files.writeString(fixtures.resolve("f" + i + ".txt"), "bounded fixture " + i);

        Path frontend = Files.createDirectories(workspace.resolve("src/frontend"));
        Path backend = Files.createDirectories(workspace.resolve("src/backend"));
        Files.writeString(frontend.resolve("AlertDashboard.ts"),
                "export async function loadAlertHistogram(){ return fetch('/api/alerts'); }\n");
        Files.writeString(backend.resolve("AlertController.java"),
                "import org.springframework.web.bind.annotation.*; @RestController @RequestMapping(\"/api\") " +
                        "class AlertController { AlertService alertService; @GetMapping(\"/alerts\") Object alerts(){ return alertService.calculateAlert(); } }");
        Files.writeString(backend.resolve("AlertService.java"),
                "class AlertService { KpiCalculator kpiCalculator; double calculateAlert(){ return kpiCalculator.calculateKpi(); } }");
        Files.writeString(backend.resolve("KpiCalculator.java"),
                "class KpiCalculator { AlertRepository repository; double calculateKpi(){ double histogram = repository.histogramBuckets(); return histogram * 0.75; } }");
        Files.writeString(backend.resolve("AlertRepository.java"),
                "class AlertRepository { double histogramBuckets(){ return 12.0; } }");

        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        var stats = index.warmRoot("scale-flow", workspace);
        assertEquals(2_000, stats.indexedFiles());
        assertFalse(stats.scanIncomplete());

        String flow = index.retrieveRoot("scale-flow", workspace,
                "How is alert calculated and how are different histograms and KPI values calculated and displayed?",
                20, 30_000);
        assertTrue(flow.contains("deep application/data flow"));
        assertTrue(flow.contains("AlertDashboard.ts"));
        assertTrue(flow.contains("AlertController.java"));
        assertTrue(flow.contains("AlertService.java"));
        assertTrue(flow.contains("KpiCalculator.java"));
        assertTrue(flow.contains("AlertRepository.java"));
        assertTrue(flow.contains("layer=frontend"));
        assertTrue(flow.contains("layer=calculation"));
        assertTrue(flow.contains("layer=data"));
    }
}
