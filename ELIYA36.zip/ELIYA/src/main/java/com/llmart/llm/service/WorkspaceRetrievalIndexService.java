package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;

import org.apache.tika.Tika;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.security.MessageDigest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Hybrid workspace retrieval for Agent mode.
 *
 * A deterministic local lexical index is always available as the zero-dependency baseline. When semantic retrieval
 * is enabled and an embedding model is configured, the strongest lexical candidates are reranked semantically.
 * Provider/embedding failures never block the agent: retrieval falls back to lexical results automatically.
 * The live filesystem remains authoritative; returned snippets are retrieval hints only.
 */
@Service
public class WorkspaceRetrievalIndexService {
    // File-count limits are disabled by default. A deployment may still set a positive safety cap,
    // but repository size alone never truncates indexing. Practical capacity is therefore governed
    // by the machine's disk/heap and the configured per-file size/exclusion rules rather than an
    // arbitrary 40k/150k ceiling.
    private static final long FILE_LIMIT = optionalLongProperty("eliya.index.maxFiles", 0L);
    private static final long SCAN_LIMIT = optionalLongProperty("eliya.index.maxScannedFiles", 0L);
    private static final int MAX_INDEXED_FILE_BYTES = positiveIntProperty("eliya.index.maxFileBytes", 1_500_000, 32_000, 8_000_000);
    // Office/PDF files are compressed containers, not UTF-8 text. Keep a separate, bounded
    // binary document limit rather than excluding legitimate requirements documents.
    private static final int MAX_INDEXED_DOCUMENT_BYTES = positiveIntProperty("eliya.index.maxDocumentBytes", 8_000_000, 192_000, 32_000_000);
    private static final int MAX_SAMPLED_CHARS_PER_FILE = 48_000;
    // Persist much smaller excerpts than the transient parse sample. Retrieval re-opens the live file
    // for evidence, so retaining 24k for every source file only wastes heap on very large repositories.
    private static final int MAX_CACHED_SOURCE_CHARS = positiveIntProperty("eliya.index.cachedSourceChars", 6_000, 1_500, 24_000);
    private static final int MAX_CACHED_DOCUMENT_CHARS = positiveIntProperty("eliya.index.cachedDocumentChars", 16_000, 4_000, 48_000);
    private static final int MAX_TERMS_PER_FILE = positiveIntProperty("eliya.index.maxTermsPerFile", 1_100, 300, 6_000);
    private static final int DEFAULT_RESULT_LIMIT = 8;
    private static final int DEFAULT_MAX_CHARS = 8_000;
    private static final int DEEP_FLOW_MAX_RESULTS = positiveIntProperty("eliya.index.deepFlowMaxResults", 32, 12, 64);
    private static final Pattern SPLIT = Pattern.compile("[^A-Za-z0-9_.$-]+");
    private static int positiveIntProperty(String name, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(System.getProperty(name, Integer.toString(fallback)));
            return Math.max(min, Math.min(max, value));
        } catch (Exception ignored) {
            return fallback;
        }
    }
    private static long optionalLongProperty(String name, long fallback) {
        try {
            long value = Long.parseLong(System.getProperty(name, Long.toString(fallback)));
            return Math.max(0L, value);
        } catch (Exception ignored) {
            return fallback;
        }
    }
    private static boolean reached(long value, long configuredLimit) {
        return configuredLimit > 0L && value >= configuredLimit;
    }

    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".idea", ".vscode", "node_modules", "target", "build", "dist", "out", ".gradle",
            ".next", "coverage", ".venv", "venv", "env", "vendor", ".terraform", ".dart_tool", ".cache", "bin", "obj",
            ".advanced-ai-chat-backup", ".agent-build", ".agent-home", "__pycache__", ".pytest_cache", ".tox",
            ".mypy_cache", ".ruff_cache", ".svn", ".hg", ".build", "pods", "deriveddata"
    );
    private static final Set<String> INDEX_EXTENSIONS = Set.of(
            "java", "kt", "kts", "groovy", "scala", "xml", "properties", "yml", "yaml", "json", "jsonc",
            "js", "jsx", "ts", "tsx", "mjs", "cjs", "py", "go", "rs", "rb", "php", "cs", "fs", "fsx",
            "swift", "dart", "c", "h", "cc", "cpp", "cxx", "hpp", "sql", "sh", "bash", "zsh", "ps1",
            "md", "adoc", "rst", "txt", "html", "htm", "css", "scss", "sass", "less", "vue", "svelte", "tf", "tfvars", "hcl", "toml",
            "feature", "robot", "csv", "tsv", "jsonl", "ini", "conf", "config", "gradle", "mvn", "bat", "cmd",
            "graphql", "gql", "proto", "thrift", "jsp", "ftl", "mustache", "bzl", "sbt", "r", "lua", "pl",
            "pm", "ex", "exs", "clj", "cljs", "vb", "zig", "nim", "jl", "hs", "lhs", "erl", "hrl", "elm", "sol", "cabal"
    );
    private static final Set<String> DOCUMENT_EXTENSIONS = Set.of("docx", "pdf", "xlsx", "pptx");
    private static final Set<String> IMPORTANT_NAMES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json",
            "pyproject.toml", "requirements.txt", "go.mod", "cargo.toml", "composer.json", "gemfile", "makefile",
            "cmakelists.txt", "build.xml", "jenkinsfile", "dockerfile", "compose.yml", "compose.yaml", "agents.md",
            "claude.md", "readme.md", ".gitignore", ".dockerignore", ".editorconfig",
            "yarn.lock", "gradlew", "mvnw", "workspace", "workspace.bazel", "module.bazel", "cabal.project",
            "application.properties", "application.yml", "application.yaml"
    );
    private static final Set<String> STOP = Set.of(
            "the", "and", "for", "that", "this", "with", "from", "have", "will", "would", "could", "should",
            "into", "about", "your", "you", "are", "was", "were", "how", "can", "use", "using", "file", "files",
            "project", "agent", "step", "plan", "task", "work", "working", "issue", "issues", "test", "tests",
            "then", "when", "where", "what", "which", "there", "their", "them", "need", "needs", "make"
    );

    private static final Set<String> SECRET_NAMES = Set.of(".env", "credentials", "secrets", "id_rsa", "id_ed25519");
    private final Map<String, WorkspaceIndex> cache = new ConcurrentHashMap<>();
    private final Map<String, String> semanticResultCache = new ConcurrentHashMap<>();
    private final Map<String, Long> semanticFailureUntil = new ConcurrentHashMap<>();
    private final Map<String,Set<String>> embeddingScopes = new ConcurrentHashMap<>();
    private final Map<String,GraphSnapshot> dependencyCache = new ConcurrentHashMap<>();
    // Query-time posting lists are built lazily from the compact per-file term maps and cached.
    // This avoids rescanning every indexed file for common Chat/Agent terms on each request.
    private final Map<String,PostingSnapshot> postingCache = new ConcurrentHashMap<>();
    private final OpenAiCompatibleClient llm;
    private final Path indexHome = Path.of(System.getProperty("app.data-dir", "./data"), "indexes").toAbsolutePath().normalize();
    private final WorkspaceEmbeddingStore vectors = new WorkspaceEmbeddingStore(indexHome);

    public WorkspaceRetrievalIndexService(OpenAiCompatibleClient llm) {
        this.llm = llm;
    }

    /** Index a user-selected folder immediately, without starting an Agent run. */
    public IndexStats warmRoot(String projectId, Path root) {
        return refresh(AgentWorkspaceService.Workspace.forIndex(projectId, root));
    }

    /** Never trigger a filesystem walk from a user-facing Chat or status request. */
    public IndexStats cachedStats(String projectId, Path root) {
        WorkspaceIndex cached = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        return cached == null ? null : cached.stats();
    }

    public String retrieveCachedRoot(String projectId, Path root, String query, int limit, int maxChars) {
        if (query == null || query.isBlank()) return "";
        WorkspaceIndex idx = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        if (idx == null) return "";
        var ws = AgentWorkspaceService.Workspace.forIndex(projectId, root);
        Set<String> queryTerms = terms(query);
        List<ScoredFile> matched = expandDependencies(idx, score(idx, query), query);
        // A question like "how does the attached project work?" is NOT a request for a file
        // whose contents contain "attached". Always supply a real manifest and useful entry
        // points for overview/no-match requests instead of claiming that no project was provided.
        if (isOverviewRequest(query) || queryTerms.isEmpty() || matched.isEmpty())
            return projectOverview(idx, maxChars, !matched.isEmpty() ? matched : List.of());
        return render(ws, query, queryTerms, matched, limit, maxChars, "local cached lexical index");
    }

    private boolean isOverviewRequest(String query) {
        String q = query.toLowerCase(Locale.ROOT);
        boolean workspace = q.matches("(?s).*\\b(project|codebase|repository|repo|workspace|application|app)\\b.*");
        boolean overview = q.matches("(?s).*\\b(overview|architecture|structure|walkthrough|explain|describe|understand)\\b.*")
                || q.matches("(?s).*\\b(how|what)\\b.*\\b(works|work|does|built)\\b.*");
        return workspace && overview;
    }

    private String projectOverview(WorkspaceIndex idx, int maxChars, List<ScoredFile> matches) {
        int budget = Math.max(1_000, Math.min(maxChars, 24_000));
        StringBuilder out = new StringBuilder("ACTIVE LOCAL PROJECT: indexed codebase evidence (not a chat attachment).\n");
        out.append("Indexed source/config files: ").append(idx.files().size()).append(".\nFile tree:\n");
        List<IndexedFile> sorted = new ArrayList<>(idx.files());
        sorted.sort(Comparator.comparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        int treeLimit = Math.min(6_000, budget / 3);
        for (IndexedFile file : sorted) {
            String line = "- " + file.path() + "\n";
            if (out.length() + line.length() > treeLimit) { out.append("... [file tree truncated]\n"); break; }
            out.append(line);
        }

        // Use only already-cached, bounded samples. No directory walk, network call or DB load
        // is allowed during Chat context construction. Prioritise documented entry points.
        LinkedHashMap<String, IndexedFile> selected = new LinkedHashMap<>();
        for (ScoredFile match : matches) selected.put(match.file().path(), match.file());
        sorted.sort(Comparator.comparingInt((IndexedFile file) -> overviewPriority(file.path()))
                .thenComparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        for (IndexedFile file : sorted) selected.putIfAbsent(file.path(), file);
        out.append("\nRelevant project entry points / cached source excerpts:\n");
        int included = 0;
        for (IndexedFile file : selected.values()) {
            if (included >= 10 || out.length() >= budget - 300) break;
            if (file.sample().isBlank()) continue;
            int room = Math.min(1_700, budget - out.length() - file.path().length() - 100);
            if (room < 120) break;
            String snippet = redact(clip(file.sample().replace("\r", ""), room));
            out.append("\n--- ").append(file.path()).append(" ---\n").append(snippet).append('\n');
            included++;
        }
        out.append("\nThis is a bounded overview. For detailed implementation questions, retrieve matching files; ")
                .append("do not infer behavior unsupported by the excerpts.\n");
        return clip(out.toString(), budget);
    }

    private int overviewPriority(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("readme.md") || name.equals("agents.md")) return 0;
        if (name.equals("pom.xml") || name.equals("package.json") || name.equals("build.gradle") || name.equals("pyproject.toml")) return 1;
        if (name.equals("application.yml") || name.equals("application.yaml") || name.equals("application.properties")) return 2;
        if (name.equals("app.java") || name.equals("main.java") || name.equals("main.py") || name.equals("index.ts")
                || name.equals("index.js") || name.equals("app.ts") || name.equals("app.js") || name.equals("server.js")) return 3;
        if (name.endsWith("application.java") || name.endsWith("controller.java") || name.endsWith("service.java")) return 4;
        if (isImportant(path)) return 5;
        return 6;
    }

    public String retrieveRoot(String projectId, Path root, String query, int limit, int maxChars) {
        return retrieve(AgentWorkspaceService.Workspace.forIndex(projectId, root), query, limit, maxChars);
    }

    public IndexStats warm(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        // Agent can inspect live files with its tools while the independent background
        // worker builds the index. Never run a duplicate directory walk in Agent startup.
        return idx == null ? new IndexStats(0, 0, "pending") : idx.stats();
    }

    public IndexStats refresh(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = index(ws, true);
        return idx.stats();
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query) {
        return retrieve(ws, query, DEFAULT_RESULT_LIMIT, DEFAULT_MAX_CHARS);
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars) {
        return retrieveInternal(ws, query, limit, maxChars, null);
    }

    /**
     * Hybrid retrieval: keep the deterministic lexical index as the safety baseline, then semantically rerank
     * the strongest live candidates with the configured embedding model. Any embedding/provider failure silently
     * falls back to lexical retrieval so repository work never depends on a secondary model.
     */
    public String retrieveHybrid(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars,
                                 String apiKey, ChatSettings settings, java.util.function.BooleanSupplier cancelled) {
        if (ws == null || query == null || query.isBlank() || settings == null || !settings.semanticRetrievalEnabled())
            return retrieve(ws, query, limit, maxChars);
        String embeddingModel = settings.embeddingModelName();
        if (embeddingModel.isBlank() || apiKey == null || apiKey.isBlank()) return retrieve(ws, query, limit, maxChars);
        String failureKey = settings.baseUrl() + "|" + embeddingModel;
        Long blockedUntil = semanticFailureUntil.get(failureKey);
        if (blockedUntil != null && blockedUntil > System.nanoTime()) return retrieve(ws, query, limit, maxChars);

        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        String cacheKey = cacheKey(ws) + "|" + idx.stats().generatedAt() + "|" + embeddingModel + "|" +
                Integer.toHexString(query.strip().toLowerCase(Locale.ROOT).hashCode()) + "|" + limit + "|" + maxChars;
        String cached = semanticResultCache.get(cacheKey);
        if (cached != null) return cached;

        try {
            List<ScoredFile> lexical = expandDependencies(idx, score(idx, query), query);
            int candidateCount = Math.min(48, lexical.size());
            List<ScoredFile> candidates = new ArrayList<>(lexical.subList(0, candidateCount));
            String scope = WorkspaceEmbeddingStore.scope(cacheKey(ws), settings.baseUrl(), embeddingModel);
            embeddingScopes.computeIfAbsent(cacheKey(ws), key -> ConcurrentHashMap.newKeySet()).add(scope);
            Map<String,WorkspaceEmbeddingStore.Entry> fresh = new LinkedHashMap<>();
            List<String> missing = new ArrayList<>();
            List<Integer> missingIndexes = new ArrayList<>();
            List<double[]> candidateVectors = new ArrayList<>(Collections.nCopies(candidateCount, null));
            for (int i = 0; i < candidates.size(); i++) {
                IndexedFile file = candidates.get(i).file();
                String fingerprint = WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt());
                double[] stored = vectors.get(scope, file.path(), fingerprint);
                if (stored == null) {
                    missingIndexes.add(i);
                    missing.add("path: " + file.path() + "\n" + redact(clip(file.sample(), 5_000)));
                } else candidateVectors.set(i, stored);
            }
            // Request the query embedding every time; document vectors are generated only once
            // per unchanged file, model and endpoint. No embedding request is ever mandatory.
            List<String> inputs = new ArrayList<>(missing.size() + 1);
            inputs.add(query); inputs.addAll(missing);
            List<double[]> resultVectors = llm.embed(apiKey, settings.baseUrl(), embeddingModel, inputs,
                    cancelled == null ? () -> false : cancelled);
            if (resultVectors.size() != inputs.size()) return retrieve(ws, query, limit, maxChars);
            double[] queryVector = resultVectors.get(0);
            for (int i = 0; i < missingIndexes.size(); i++) {
                int index = missingIndexes.get(i);
                double[] vector = resultVectors.get(i + 1);
                if (vector == null || vector.length != queryVector.length) return retrieve(ws, query, limit, maxChars);
                IndexedFile file = candidates.get(index).file();
                candidateVectors.set(index, vector);
                fresh.put(file.path(), WorkspaceEmbeddingStore.entry(
                        WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt()), vector));
            }
            vectors.putAll(scope, fresh);
            semanticFailureUntil.remove(failureKey);
            double maxLexical = candidates.stream().mapToDouble(ScoredFile::score).max().orElse(1.0);
            LinkedHashMap<String,ScoredFile> fusedByPath = new LinkedHashMap<>();
            for (int i = 0; i < candidates.size(); i++) {
                ScoredFile candidate = candidates.get(i);
                double semantic = Math.max(-1.0, Math.min(1.0, cosine(queryVector, candidateVectors.get(i))));
                double semantic01 = (semantic + 1.0) / 2.0;
                double lexical01 = Math.min(1.0, candidate.score() / Math.max(1.0, maxLexical));
                double fused = (lexical01 * 0.48) + (semantic01 * 0.52);
                fusedByPath.put(candidate.file().path(), new ScoredFile(candidate.file(), fused * 100.0));
            }
            // Previously indexed semantic neighbors can surface even when none of the query's
            // words appear in a file. Only live, fingerprint-matching cache entries qualify.
            Map<String,IndexedFile> live = new HashMap<>();
            for (IndexedFile file : idx.files()) live.put(file.path(), file);
            for (var stored : vectors.snapshot(scope).entrySet()) {
                IndexedFile file = live.get(stored.getKey());
                if (file == null || fusedByPath.containsKey(file.path())) continue;
                WorkspaceEmbeddingStore.Entry vector = stored.getValue();
                if (!WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt()).equals(vector.fingerprint())) continue;
                if (vector.vector().length != queryVector.length) continue;
                double proximity = cosine(queryVector, vector.vector());
                if (proximity >= 0.38) fusedByPath.put(file.path(), new ScoredFile(file, proximity * 52.0));
            }
            List<ScoredFile> reranked = new ArrayList<>(fusedByPath.values());
            reranked.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
            String result = render(ws, query, terms(query), reranked, limit, maxChars,
                    "hybrid lexical + semantic reranking via " + embeddingModel);
            if (!result.isBlank()) {
                if (semanticResultCache.size() > 400) semanticResultCache.clear();
                semanticResultCache.put(cacheKey, result);
            }
            return result;
        } catch (Exception ignored) {
            // A missing/unsupported embedding endpoint must not add latency to every subsequent request.
            semanticFailureUntil.put(failureKey, System.nanoTime() + java.util.concurrent.TimeUnit.MINUTES.toNanos(2));
            return retrieve(ws, query, limit, maxChars);
        }
    }

    private String retrieveInternal(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars, String mode) {
        if (ws == null || query == null || query.isBlank()) return "";
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return "";
        return render(ws, query, terms, expandDependencies(idx, score(idx, query), query), limit, maxChars, mode == null ? "local structural + lexical index" : mode);
    }

    private List<ScoredFile> score(WorkspaceIndex idx, String query) {
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return List.of();

        PostingSnapshot snapshot = postings(idx, terms);
        BitSet candidateIds = new BitSet(idx.files().size());
        for (String term : terms) {
            int[] ids = snapshot.postings().get(term);
            if (ids != null) for (int id : ids) candidateIds.set(id);
        }
        if (candidateIds.isEmpty()) return List.of();

        // BM25 rewards rare matching symbols and normalises repetitive large files. Filename and
        // exact-symbol boosts keep entry points discoverable without scanning unrelated files.
        String queryLower = query == null ? "" : query.strip().toLowerCase(Locale.ROOT);
        List<ScoredFile> scored = new ArrayList<>(Math.min(candidateIds.cardinality(), 512));
        int corpusSize = Math.max(1, idx.files().size());
        double avgLength = snapshot.avgLength();
        for (int id = candidateIds.nextSetBit(0); id >= 0; id = candidateIds.nextSetBit(id + 1)) {
            IndexedFile file = idx.files().get(id);
            double score = 0.0;
            int hits = 0;
            int length = snapshot.lengths()[id];
            String lowPath = file.path().toLowerCase(Locale.ROOT);
            String baseName = Path.of(file.path()).getFileName().toString().toLowerCase(Locale.ROOT);
            for (String term : terms) {
                if (lowPath.contains(term)) { score += baseName.contains(term) ? 8.0 : 3.0; hits++; }
                int tf = file.termFrequency().getOrDefault(term, 0);
                if (tf <= 0) continue;
                hits++;
                int[] posting = snapshot.postings().get(term);
                int df = posting == null ? 0 : posting.length;
                double idf = Math.log(1.0 + (corpusSize - df + 0.5) / (df + 0.5));
                score += 2.0 * idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / avgLength));
            }
            // Exact symbol matching is stronger than an incidental token occurrence in a large file.
            for (String symbol : file.structure().symbols().keySet()) {
                String name = symbol.substring(symbol.indexOf(':') + 1).toLowerCase(Locale.ROOT);
                if (exactSymbolMention(queryLower, name)) score += 14.0;
                else if (terms.contains(name)) score += 9.0;
            }
            score += layerAffinity(file.layer(), queryLower);
            if (score > 0) {
                score *= (1.0 + Math.min(0.6, 0.6 * hits / Math.max(1, terms.size() * 2)));
                if (isImportant(file.path())) score += 1.5;
                if (queryLower.length() > 4 && file.sample().toLowerCase(Locale.ROOT).contains(queryLower)) score += 12.0;
                scored.add(new ScoredFile(file, score));
            }
        }
        scored.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return scored;
    }

    private PostingSnapshot postings(WorkspaceIndex idx, Set<String> requestedTerms) {
        String key = idx.root();
        PostingSnapshot snapshot = postingCache.get(key);
        if (snapshot == null || snapshot.index() != idx) {
            synchronized (postingCache) {
                snapshot = postingCache.get(key);
                if (snapshot == null || snapshot.index() != idx) {
                    int[] lengths = new int[idx.files().size()];
                    long total = 0L;
                    for (int i = 0; i < idx.files().size(); i++) {
                        int length = idx.files().get(i).termFrequency().values().stream().mapToInt(Integer::intValue).sum();
                        lengths[i] = length;
                        total += length;
                    }
                    snapshot = new PostingSnapshot(idx, new ConcurrentHashMap<>(), lengths,
                            Math.max(1.0, total / (double) Math.max(1, idx.files().size())));
                    postingCache.put(key, snapshot);
                }
            }
        }

        LinkedHashSet<String> missing = new LinkedHashSet<>();
        for (String term : requestedTerms) if (!snapshot.postings().containsKey(term)) missing.add(term);
        if (!missing.isEmpty()) {
            synchronized (snapshot) {
                missing.removeIf(snapshot.postings()::containsKey);
                if (!missing.isEmpty()) {
                    Map<String,IntAccumulator> builders = new HashMap<>();
                    for (String term : missing) builders.put(term, new IntAccumulator());
                    for (int id = 0; id < idx.files().size(); id++) {
                        Map<String,Integer> frequency = idx.files().get(id).termFrequency();
                        for (String term : missing) if (frequency.containsKey(term)) builders.get(term).add(id);
                    }
                    for (String term : missing) snapshot.postings().put(term, builders.get(term).toArray());
                    // Keep the posting cache bounded when a user asks thousands of unrelated questions.
                    if (snapshot.postings().size() > 4_096) {
                        Map<String,int[]> keep = new HashMap<>();
                        for (String term : requestedTerms) keep.put(term, snapshot.postings().getOrDefault(term, new int[0]));
                        snapshot.postings().clear();
                        snapshot.postings().putAll(keep);
                    }
                }
            }
        }
        return snapshot;
    }

    private String render(AgentWorkspaceService.Workspace ws, String query, Set<String> terms, List<ScoredFile> scored,
                          int limit, int maxChars, String mode) {
        int wanted = Math.max(1, Math.min(limit, 20));
        int budget = Math.max(1_000, Math.min(maxChars, 48_000));
        StringBuilder out = new StringBuilder();
        out.append("WORKSPACE RETRIEVAL HINTS — ").append(mode).append("; live files/tools are authoritative.\n");
        if (isDeepFlowQuery(query)) out.append("Retrieval intent: deep application/data flow; related layers are expanded up to two hops.\n");
        out.append("queryTerms: ").append(String.join(", ", terms)).append('\n');
        int emitted = 0;
        for (ScoredFile match : scored) {
            if (emitted >= wanted || out.length() >= budget) break;
            Path file = ws.root().resolve(match.file().path()).normalize();
            if (!file.startsWith(ws.root()) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
            // Files.readAllLines on Office/PDF containers yields binary garbage or a
            // decoding error. Use the text extracted into the bounded cache instead.
            String snippet = isDocument(file) ? excerptAroundTerms(match.file().sample(), terms, 1_700) : currentSnippet(file, terms, 1_700);
            if (snippet.isBlank()) snippet = clip(match.file().sample().replace("\r", "").strip(), 1_300);
            snippet = redact(snippet);
            WorkspaceCodeIntelligence.Structure structure = match.file().structure();
            String symbols = structure.symbols().entrySet().stream().limit(12)
                    .map(entry -> entry.getKey() + "@" + entry.getValue()).reduce((a, b) -> a + ", " + b).orElse("");
            if (!symbols.isBlank()) snippet = "Symbols (type:name@line): " + symbols + "\n" + snippet;
            if (!structure.references().isEmpty()) snippet = "Direct references: " + clip(String.join(", ", structure.references()), 360) + "\n" + snippet;
            String block = "\n- " + match.file().path() + " [layer=" + match.file().layer() + "] (score=" + String.format(Locale.ROOT, "%.1f", match.score()) + ")" +
                    (snippet.isBlank() ? "" : "\n  " + snippet.replace("\n", "\n  "));
            if (out.length() + block.length() > budget) break;
            out.append(block);
            emitted++;
        }
        return emitted == 0 ? "" : out.toString();
    }

    private boolean codeFile(String rel) {
        return rel.matches("(?i).*\\.(java|js|jsx|ts|tsx|mjs|cjs|feature)$");
    }

    private WorkspaceCodeIntelligence.Structure structure(Path file, String rel, String sample) {
        if (!codeFile(rel)) return WorkspaceCodeIntelligence.Structure.EMPTY;
        try {
            // Parse the entire small/medium source file, not a truncated prefix/suffix.
            String text = Files.size(file) <= 350_000 ? Files.readString(file, StandardCharsets.UTF_8) : sample;
            return WorkspaceCodeIntelligence.analyse(rel, text);
        } catch (Exception ignored) { return WorkspaceCodeIntelligence.analyse(rel, sample); }
    }

    private boolean exactSymbolMention(String query, String symbol) {
        if (symbol.length() < 3) return false;
        int offset = query.indexOf(symbol);
        while (offset >= 0) {
            int end = offset + symbol.length();
            if ((offset == 0 || !Character.isLetterOrDigit(query.charAt(offset - 1))) &&
                    (end == query.length() || !Character.isLetterOrDigit(query.charAt(end)))) return true;
            offset = query.indexOf(symbol, offset + 1);
        }
        return false;
    }

    private Map<String,Set<String>> dependencies(WorkspaceIndex idx) {
        GraphSnapshot previous = dependencyCache.get(idx.root());
        if (previous != null && previous.index() == idx) return previous.graph();
        synchronized (dependencyCache) {
            previous = dependencyCache.get(idx.root());
            if (previous != null && previous.index() == idx) return previous.graph();
            Map<String,Set<String>> built = buildDependencies(idx);
            if (dependencyCache.size() > 32) dependencyCache.clear();
            dependencyCache.put(idx.root(), new GraphSnapshot(idx, built));
            return built;
        }
    }

    /**
     * Infer bounded application relationships from imports, unique symbols, method calls, BDD steps and HTTP routes.
     * The graph is intentionally conservative: ambiguous symbols are not linked unless a shared HTTP route gives
     * stronger evidence. This keeps a 2,000-file workspace useful without turning retrieval into an all-to-all graph.
     */
    private Map<String,Set<String>> buildDependencies(WorkspaceIndex idx) {
        Map<String,Set<String>> byName = new HashMap<>();
        Map<String,Set<String>> byQualified = new HashMap<>();
        Map<String,Set<String>> byStep = new HashMap<>();
        Map<String,Set<String>> byRoute = new HashMap<>();
        for (IndexedFile file : idx.files()) {
            String qualified = file.path().replace('\\', '/').toLowerCase(Locale.ROOT);
            byQualified.computeIfAbsent(qualified, key -> new LinkedHashSet<>()).add(file.path());
            for (int slash = qualified.indexOf('/'); slash >= 0; slash = qualified.indexOf('/', slash + 1))
                byQualified.computeIfAbsent(qualified.substring(slash + 1), key -> new LinkedHashSet<>()).add(file.path());
            String base = file.path().replace('\\', '/');
            base = base.substring(base.lastIndexOf('/') + 1).replaceFirst("\\.[^.]+$", "").toLowerCase(Locale.ROOT);
            byName.computeIfAbsent(base, key -> new LinkedHashSet<>()).add(file.path());
            for (String symbol : file.structure().symbols().keySet()) {
                String name = symbol.substring(symbol.indexOf(':') + 1).toLowerCase(Locale.ROOT);
                byName.computeIfAbsent(name, key -> new LinkedHashSet<>()).add(file.path());
            }
            for (String step : file.structure().steps())
                byStep.computeIfAbsent(step, key -> new LinkedHashSet<>()).add(file.path());
            for (String ref : file.structure().references()) {
                if (!ref.startsWith("route:")) continue;
                for (String alias : routeAliases(ref.substring("route:".length())))
                    byRoute.computeIfAbsent(alias, key -> new LinkedHashSet<>()).add(file.path());
            }
        }
        Map<String,Set<String>> graph = new HashMap<>();
        for (IndexedFile file : idx.files()) {
            if (file.path().toLowerCase(Locale.ROOT).endsWith(".feature")) {
                for (String step : file.structure().steps()) {
                    for (String matching : byStep.getOrDefault(step, Set.of())) {
                        if (!matching.equals(file.path())) link(graph, file.path(), matching);
                    }
                }
            }
            for (String ref : file.structure().references()) {
                if (ref.startsWith("route:")) {
                    LinkedHashSet<String> routeMatches = new LinkedHashSet<>();
                    for (String alias : routeAliases(ref.substring("route:".length())))
                        routeMatches.addAll(byRoute.getOrDefault(alias, Set.of()));
                    if (routeMatches.size() <= 12) {
                        for (String target : routeMatches) if (!target.equals(file.path())) link(graph, file.path(), target);
                    }
                    continue;
                }
                String clean = ref.replace('\\', '/').replaceFirst("\\.(?:java|ts|tsx|js|jsx)$", "");
                String base = clean.substring(clean.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
                Set<String> matches = Set.of();
                if (!ref.startsWith(".") && !ref.startsWith("/") && ref.contains("."))
                    matches = byQualified.getOrDefault(ref.replace('.', '/').toLowerCase(Locale.ROOT) + ".java", Set.of());
                if (matches.isEmpty()) matches = byName.getOrDefault(base, Set.of());
                if (matches.isEmpty()) {
                    String simple = base.substring(base.lastIndexOf('.') + 1);
                    matches = byName.getOrDefault(simple, Set.of());
                }
                if (matches.size() == 1) {
                    String target = matches.iterator().next();
                    if (!target.equals(file.path())) link(graph, file.path(), target);
                }
            }
        }
        Map<String,Set<String>> frozen = new HashMap<>();
        for (var entry : graph.entrySet()) frozen.put(entry.getKey(), Set.copyOf(entry.getValue()));
        return Map.copyOf(frozen);
    }

    private void link(Map<String,Set<String>> graph, String left, String right) {
        graph.computeIfAbsent(left, k -> new LinkedHashSet<>()).add(right);
        graph.computeIfAbsent(right, k -> new LinkedHashSet<>()).add(left);
    }

    private Set<String> routeAliases(String raw) {
        if (raw == null || raw.isBlank()) return Set.of();
        String route = raw.strip().toLowerCase(Locale.ROOT).replaceAll("/{2,}", "/");
        if (!route.startsWith("/")) route = "/" + route;
        LinkedHashSet<String> aliases = new LinkedHashSet<>();
        aliases.add(route);
        String[] parts = Arrays.stream(route.split("/")).filter(v -> !v.isBlank()).toArray(String[]::new);
        if (parts.length >= 1) aliases.add("/" + parts[parts.length - 1]);
        if (parts.length >= 2) aliases.add("/" + parts[parts.length - 2] + "/" + parts[parts.length - 1]);
        return aliases;
    }

    private List<ScoredFile> expandDependencies(WorkspaceIndex idx, List<ScoredFile> ranking) {
        return expandDependencies(idx, ranking, "");
    }

    private List<ScoredFile> expandDependencies(WorkspaceIndex idx, List<ScoredFile> ranking, String query) {
        if (ranking.isEmpty()) return ranking;
        boolean deep = isDeepFlowQuery(query);
        int maxSeeds = deep ? 6 : 3;
        int hops = deep ? 2 : 1;
        int neighborsPerNode = deep ? 5 : 3;
        int maxResults = deep ? DEEP_FLOW_MAX_RESULTS : Math.max(12, DEFAULT_RESULT_LIMIT * 2);

        Map<String,IndexedFile> lookup = new HashMap<>();
        for (IndexedFile file : idx.files()) lookup.put(file.path(), file);
        Map<String,Set<String>> graph = dependencies(idx);
        LinkedHashMap<String,ScoredFile> selected = new LinkedHashMap<>();
        int initialLimit = deep ? Math.min(ranking.size(), Math.max(12, maxResults / 2)) : Math.min(ranking.size(), maxResults);
        for (int i = 0; i < initialLimit; i++) {
            ScoredFile match = ranking.get(i);
            selected.put(match.file().path(), match);
        }

        ArrayDeque<GraphNode> queue = new ArrayDeque<>();
        for (int i = 0; i < Math.min(maxSeeds, ranking.size()); i++)
            queue.add(new GraphNode(ranking.get(i).file().path(), ranking.get(i).score(), 0));
        Set<String> traversed = new HashSet<>();
        while (!queue.isEmpty() && selected.size() < maxResults) {
            GraphNode node = queue.removeFirst();
            if (!traversed.add(node.path() + "|" + node.depth()) || node.depth() >= hops) continue;
            int count = 0;
            for (String related : graph.getOrDefault(node.path(), Set.of())) {
                if (++count > neighborsPerNode || selected.size() >= maxResults) break;
                IndexedFile file = lookup.get(related);
                if (file == null) continue;
                double decay = node.depth() == 0 ? 0.72 : 0.55;
                double relatedScore = Math.max(0.1, node.score() * decay + flowLayerBonus(file.layer(), query));
                ScoredFile previous = selected.get(related);
                if (previous == null || relatedScore > previous.score()) selected.put(related, new ScoredFile(file, relatedScore));
                queue.addLast(new GraphNode(related, relatedScore, node.depth() + 1));
            }
        }
        ArrayList<ScoredFile> result = new ArrayList<>(selected.values());
        result.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return result;
    }

    private boolean isDeepFlowQuery(String query) {
        if (query == null || query.isBlank()) return false;
        String q = query.toLowerCase(Locale.ROOT);
        boolean action = q.matches("(?s).*(?:how|flow|trace|calculated|calculate|computed|compute|derived|derive|aggregated|aggregate|populated|displayed|comes from|data flow|end[- ]to[- ]end|formula|logic).*" );
        boolean subject = q.matches("(?s).*(?:alert|kpi|metric|histogram|bucket|chart|dashboard|score|threshold|indicator|measure|aggregation|calculation|data|value).*" );
        return action && subject;
    }

    private double flowLayerBonus(String layer, String query) {
        if (!isDeepFlowQuery(query)) return 0.0;
        return switch (layer) {
            case "frontend", "controller", "service", "calculation", "data" -> 1.5;
            default -> 0.2;
        };
    }

    private double layerAffinity(String layer, String queryLower) {
        if (layer == null || queryLower == null) return 0.0;
        return switch (layer) {
            case "frontend" -> queryLower.matches("(?s).*(frontend|front end|ui|screen|page|component|dashboard|display|chart|histogram).*" ) ? 3.0 : 0.0;
            case "controller" -> queryLower.matches("(?s).*(api|endpoint|controller|request|response|backend|back end).*" ) ? 3.0 : 0.0;
            case "service" -> queryLower.matches("(?s).*(service|business logic|process|flow|backend|back end).*" ) ? 2.5 : 0.0;
            case "calculation" -> queryLower.matches("(?s).*(calculate|calculated|computation|formula|kpi|metric|histogram|score|threshold|aggregate).*" ) ? 4.0 : 0.0;
            case "data" -> queryLower.matches("(?s).*(data|repository|database|sql|query|elasticsearch|kafka|storage|dao).*" ) ? 3.5 : 0.0;
            default -> 0.0;
        };
    }

    /** Deterministic read-only task-scope gate: hints do not constitute proof of implementation. */
    public String impactReport(AgentWorkspaceService.Workspace ws, String task, int maxChars) {
        if (ws == null || task == null || task.isBlank()) return "";
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "INDEX NOT READY: inspect actual files using glob, grep and read before editing.";
        List<ScoredFile> ranked = score(idx, task);
        StringBuilder out = new StringBuilder("TASK EVIDENCE / IMPACT CHECK (index hints, not permission to edit):\n");
        if (idx.stats().scanIncomplete()) out.append("WARNING: scan incomplete; use live discovery tools for missing files.\n");
        if (ranked.isEmpty()) out.append("No matching indexed symbols or files. Use glob/grep/read before editing; do not invent filenames or APIs.\n");
        else {
            Map<String,Set<String>> graph = dependencies(idx);
            for (int i = 0; i < Math.min(5, ranked.size()); i++) {
                ScoredFile candidate = ranked.get(i);
                out.append("- Candidate: ").append(candidate.file().path());
                if (!candidate.file().structure().symbols().isEmpty())
                    out.append("; symbols ").append(clip(String.join(", ", candidate.file().structure().symbols().keySet()), 250));
                out.append("; inferred related files ")
                        .append(clip(String.join(", ", graph.getOrDefault(candidate.file().path(), Set.of())), 250)).append('\n');
            }
        }
        out.append("REQUIRED: open the CURRENT source of each file to change; confirm called methods, imports, dependent tests and configuration; " +
                "expand discovery if evidence is insufficient; compile/run targeted tests and report actual results. " +
                "Do not modify a file solely on the basis of a cached excerpt.\n");
        return clip(out.toString(), Math.max(600, Math.min(maxChars, 7_000)));
    }

    private double cosine(double[] a, double[] b) {
        if (a == null || b == null || a.length == 0 || a.length != b.length) return 0.0;
        double dot = 0.0, aa = 0.0, bb = 0.0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        if (aa <= 0.0 || bb <= 0.0) return 0.0;
        return dot / (Math.sqrt(aa) * Math.sqrt(bb));
    }

    public void invalidate(AgentWorkspaceService.Workspace ws) {
        if (ws != null) {
            String prefix = cacheKey(ws);
            WorkspaceIndex removed = cache.remove(prefix);
            if (removed != null) { dependencyCache.remove(removed.root()); postingCache.remove(removed.root()); }
            clearSemanticCache(prefix);
        }
    }

    /**
     * Refresh only files the runtime already knows were changed. This keeps the local retrieval index hot across
     * normal edit/write/patch operations instead of walking the whole repository again after every mutation.
     * If the index has not been built yet, this is intentionally a no-op; the first retrieval will build it once.
     */
    public void refreshPaths(AgentWorkspaceService.Workspace ws, Collection<String> changedPaths) {
        if (ws == null || changedPaths == null || changedPaths.isEmpty()) return;
        String key = cacheKey(ws);
        WorkspaceIndex existing = cache.get(key);
        if (existing == null) return;

        LinkedHashSet<String> normalized = new LinkedHashSet<>();
        for (String raw : changedPaths) {
            if (raw == null || raw.isBlank()) continue;
            try {
                Path supplied = Path.of(raw.strip());
                Path resolved = supplied.isAbsolute() ? supplied.normalize() : ws.root().resolve(supplied).normalize();
                if (!resolved.startsWith(ws.root())) continue;
                String rel = ws.root().relativize(resolved).toString().replace('\\', '/');
                if (!rel.isBlank()) normalized.add(rel);
            } catch (Exception ignored) { }
        }
        if (normalized.isEmpty()) return;

        cache.computeIfPresent(key, (ignored, current) -> {
            LinkedHashMap<String, IndexedFile> byPath = new LinkedHashMap<>();
            for (IndexedFile file : current.files()) byPath.put(file.path(), file);
            for (String rel : normalized) {
                byPath.remove(rel);
                Path file = ws.root().resolve(rel).normalize();
                try {
                    if (!file.startsWith(ws.root()) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
                    long size = Files.size(file);
                    if (!indexable(file, size)) continue;
                    String sample = sample(file);
                    byPath.put(rel, new IndexedFile(rel, indexTerms(file, rel, sample), cachedExcerpt(file, sample), size, Files.getLastModifiedTime(file).toMillis(), structure(file, rel, sample)));
                } catch (Exception ignoredFailure) {
                    if (Files.isRegularFile(file) && !Files.isSymbolicLink(file) && supportedAndSafe(file)) {
                        try { byPath.put(rel, new IndexedFile(rel, frequencies(rel), "", Files.size(file),
                                Files.getLastModifiedTime(file).toMillis())); }
                        catch (IOException missing) { /* File changed while indexing; retry on rescan. */ }
                    }
                }
            }
            List<IndexedFile> files = new ArrayList<>(byPath.values());
            return new WorkspaceIndex(current.root(), List.copyOf(files),
                    new IndexStats(files.size(), current.stats().visitedFiles(), Instant.now().toString(),
                            files.stream().mapToLong(f -> f.sample().length()).sum(),
                            current.stats().skippedTooLarge(), current.stats().skippedUnsupported(),
                            current.stats().skippedUnreadable(), current.stats().skippedDirectories(),
                            current.stats().scanIncomplete()));
        });
        dependencyCache.remove(ws.root().toString());
        postingCache.remove(ws.root().toString());
        clearSemanticCache(key);
        embeddingScopes.getOrDefault(key, Set.of()).forEach(scope -> vectors.invalidate(scope, normalized));
        WorkspaceIndex updated = cache.get(key);
        if (updated != null) persist(ws, updated);
    }

    private void clearSemanticCache(String prefix) {
        semanticResultCache.keySet().removeIf(key -> key.startsWith(prefix + "|"));
    }

    private WorkspaceIndex index(AgentWorkspaceService.Workspace ws, boolean force) {
        String key = cacheKey(ws);
        if (!force) {
            WorkspaceIndex existing = cache.get(key);
            if (existing != null && Objects.equals(existing.root(), ws.root().toString())) return existing;
        }
        WorkspaceIndex previous = cache.get(key);
        if (previous == null) previous = load(ws);
        if (!force && previous != null) {
            cache.put(key, previous);
            return previous;
        }
        WorkspaceIndex built = build(ws, previous);
        cache.put(key, built);
        dependencyCache.remove(built.root());
        postingCache.remove(built.root());
        persist(ws, built);
        return built;
    }

    private WorkspaceIndex build(AgentWorkspaceService.Workspace ws, WorkspaceIndex previous) {
        Map<String, IndexedFile> old = new HashMap<>();
        if (previous != null && Objects.equals(previous.root(), ws.root().toString()))
            for (IndexedFile f : previous.files()) old.put(f.path(), f);
        List<IndexedFile> files = new ArrayList<>();
        long[] scanned = {0L};
        long[] indexed = {0L};
        long[] oversized = {0L}, unsupported = {0L}, unreadable = {0L}, excludedDirectories = {0L};
        boolean[] incomplete = {false};
        try {
            Files.walkFileTree(ws.root(), EnumSet.noneOf(FileVisitOption.class), 48, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(ws.root())) {
                        String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) {
                            excludedDirectories[0]++;
                            return FileVisitResult.SKIP_SUBTREE;
                        }
                    }
                    if (reached(scanned[0], SCAN_LIMIT) || reached(indexed[0], FILE_LIMIT)) {
                        incomplete[0] = true;
                        return FileVisitResult.TERMINATE;
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (reached(scanned[0], SCAN_LIMIT) || reached(indexed[0], FILE_LIMIT)) {
                        incomplete[0] = true;
                        return FileVisitResult.TERMINATE;
                    }
                    scanned[0]++;
                    if (!attrs.isRegularFile() || Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                    if (!supportedAndSafe(file)) { unsupported[0]++; return FileVisitResult.CONTINUE; }
                    if (attrs.size() > maxSize(file)) { oversized[0]++; return FileVisitResult.CONTINUE; }
                    indexed[0]++;
                    String rel = ws.root().relativize(file).toString().replace('\\', '/');
                    IndexedFile cached = old.get(rel);
                    if (cached != null && cached.size() == attrs.size() &&
                            cached.modifiedAt() == attrs.lastModifiedTime().toMillis() &&
                            (!codeFile(rel) || !cached.structure().equals(WorkspaceCodeIntelligence.Structure.EMPTY))) {
                        files.add(cached); return FileVisitResult.CONTINUE;
                    }
                    try {
                        String sample = sample(file);
                        files.add(new IndexedFile(rel, indexTerms(file, rel, sample), cachedExcerpt(file, sample),
                                attrs.size(), attrs.lastModifiedTime().toMillis(), structure(file, rel, sample)));
                    } catch (Exception ignored) {
                        unreadable[0]++;
                        files.add(new IndexedFile(rel, frequencies(rel), "", attrs.size(), attrs.lastModifiedTime().toMillis()));
                    }
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFileFailed(Path file, IOException error) {
                    unreadable[0]++;
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException failure) {
            incomplete[0] = true;
        }
        return new WorkspaceIndex(ws.root().toString(), List.copyOf(files),
                new IndexStats(files.size(), scanned[0], Instant.now().toString(),
                        files.stream().mapToLong(f -> f.sample().length()).sum(),
                        oversized[0], unsupported[0], unreadable[0], excludedDirectories[0], incomplete[0]));
    }

    private boolean indexable(Path file, long size) {
        return size >= 0 && size <= maxSize(file) && supportedAndSafe(file);
    }

    private long maxSize(Path file) {
        return isDocument(file) ? MAX_INDEXED_DOCUMENT_BYTES : MAX_INDEXED_FILE_BYTES;
    }

    private boolean supportedAndSafe(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (SECRET_NAMES.contains(name) || name.startsWith(".env.") ||
                name.matches(".*\\.(pem|p12|pfx|jks|keystore|key|crt|cer)$")) return false;
        if (IMPORTANT_NAMES.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && (INDEX_EXTENSIONS.contains(name.substring(dot + 1))
                || DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1)));
    }

    private String sample(Path file) throws IOException {
        if (isDocument(file)) {
            // Reuse the application's already-bundled Tika parsers. This is text-only
            // background indexing: visual evidence remains the Agent's responsibility.
            Tika parser = new Tika();
            // Allow Tika to finish parsing normal documents before clipping the
            // indexed excerpt. Too low a parser limit can reject longer DOCX.
            parser.setMaxStringLength(600_000);
            try (InputStream input = Files.newInputStream(file)) {
                return clip(parser.parseToString(input).replace('\u0000', ' '), MAX_SAMPLED_CHARS_PER_FILE);
            } catch (Exception error) {
                throw new IOException("Cannot extract text from " + file.getFileName() + ": " + error.getMessage(), error);
            }
        }
        byte[] bytes = Files.readAllBytes(file);
        if (bytes.length == 0) return "";
        int n = Math.min(bytes.length, MAX_SAMPLED_CHARS_PER_FILE);
        String head = new String(bytes, 0, n, StandardCharsets.UTF_8);
        if (bytes.length <= n) return head;
        int tailBytes = Math.min(8_000, bytes.length - n);
        String tail = new String(bytes, bytes.length - tailBytes, tailBytes, StandardCharsets.UTF_8);
        return head + "\n" + tail;
    }

    private boolean isDocument(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        return dot > 0 && DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1));
    }

    // Score complete supported text files, not just cached excerpts, so a symbol located
    // far from the first page of a large source file remains discoverable in Chat.
    // Keep the LLM-bound excerpt bounded independently of the searchable term index.
    private Map<String,Integer> indexTerms(Path file, String rel, String sample) throws IOException {
        if (isDocument(file) || Files.size(file) <= MAX_SAMPLED_CHARS_PER_FILE)
            return frequencies(rel + "\n" + sample);
        // Large source files are tokenised as a stream. This keeps peak memory bounded when a workspace
        // contains thousands of medium/large files while still indexing terms from the complete file.
        Map<String,Integer> frequency = new HashMap<>();
        accumulateFrequencies(frequency, rel);
        try (java.io.BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) accumulateFrequencies(frequency, line);
        }
        return Map.copyOf(frequency);
    }

    private Map<String,Integer> frequencies(String text) {
        Map<String,Integer> frequency = new HashMap<>();
        if (text == null) return Map.of();
        accumulateFrequencies(frequency, text);
        return Map.copyOf(frequency);
    }

    private void accumulateFrequencies(Map<String,Integer> frequency, String text) {
        if (text == null || text.isBlank()) return;
        for (String raw : SPLIT.split(splitIdentifiers(text).toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            if (!frequency.containsKey(term) && frequency.size() >= MAX_TERMS_PER_FILE) continue;
            frequency.merge(term, 1, Integer::sum);
        }
    }

    private Set<String> terms(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        String lower = splitIdentifiers(text).toLowerCase(Locale.ROOT);
        for (String raw : SPLIT.split(lower)) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            out.add(term);
            if (out.size() >= 80) break;
        }
        // Business-flow aliases make natural questions find implementation terminology without a remote model.
        if (lower.matches("(?s).*(calculate|calculated|computed|derive|derived|formula).*"))
            addTerms(out, "calculate", "calculation", "compute", "computed", "derive", "derived", "formula", "score", "aggregate", "aggregation");
        if (lower.contains("kpi")) addTerms(out, "kpi", "metric", "indicator", "measure", "score");
        if (lower.contains("histogram")) addTerms(out, "histogram", "bucket", "bins", "distribution", "aggregation", "chart");
        if (lower.contains("alert")) addTerms(out, "alert", "alarm", "threshold", "severity", "score", "notification");
        if (lower.matches("(?s).*(front end|frontend|ui|screen|dashboard|display).*"))
            addTerms(out, "frontend", "component", "page", "view", "dashboard", "display", "react", "angular");
        if (lower.matches("(?s).*(back end|backend|api|endpoint).*"))
            addTerms(out, "backend", "controller", "service", "endpoint", "request", "response");
        if (lower.matches("(?s).*(data layer|repository|database|sql|query|elasticsearch|kafka).*"))
            addTerms(out, "data", "repository", "dao", "database", "sql", "query", "elasticsearch", "kafka");
        return out;
    }

    private void addTerms(Set<String> out, String... values) {
        for (String value : values) if (out.size() < 96) out.add(value);
    }

    // Index snake_case and camelCase symbols as both full identifiers and searchable words.
    private String splitIdentifiers(String text) {
        return text.replaceAll("([a-z0-9])([A-Z])", "$1 $2").replace('_', ' ');
    }

    // Keep bounded evidence from the beginning and end. The live source is re-opened when a result
    // is rendered, so this cache is for ranking/semantic hints rather than a second copy of the repo.
    private String cachedExcerpt(Path file, String sample) {
        int max = isDocument(file) ? MAX_CACHED_DOCUMENT_CHARS : MAX_CACHED_SOURCE_CHARS;
        if (sample == null || sample.length() <= max) return sample == null ? "" : sample;
        int tail = Math.max(500, max / 3);
        int head = Math.max(500, max - tail);
        return sample.substring(0, head) + "\n...[middle omitted from cache]...\n"
                + sample.substring(sample.length() - tail);
    }

    private static String excerptAroundTerms(String text, Set<String> terms, int limit) {
        if (text == null || text.isBlank()) return "";
        String lower = text.toLowerCase(Locale.ROOT);
        int position = -1;
        for (String term : terms) {
            int match = lower.indexOf(term);
            if (match >= 0 && (position < 0 || match < position)) position = match;
        }
        int start = position < 0 ? 0 : Math.max(0, position - 350);
        return clip(text.substring(start, Math.min(text.length(), start + limit)), limit);
    }

    private String currentSnippet(Path file, Set<String> terms, int maxChars) {
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            StringBuilder matches = new StringBuilder();
            int last = -1;
            int blocks = 0;
            for (int i = 0; i < lines.size() && blocks < 3; i++) {
                String low = lines.get(i).toLowerCase(Locale.ROOT);
                boolean hit = false;
                for (String term : terms) if (low.contains(term)) { hit = true; break; }
                if (!hit || i <= last) continue;
                int start = Math.max(last + 1, i - 3);
                int end = Math.min(lines.size(), i + 5);
                if (!matches.isEmpty()) matches.append("\n...\n");
                for (int line = start; line < end; line++) {
                    String value = lines.get(line).strip();
                if (value.length() > 240) {
                    int offset = -1;
                    String lowerValue = value.toLowerCase(Locale.ROOT);
                    for (String term : terms) {
                        int found = lowerValue.indexOf(term);
                        if (found >= 0 && (offset < 0 || found < offset)) offset = found;
                    }
                    int from = offset < 0 ? 0 : Math.max(0, offset - 60);
                    value = clip(value.substring(from), 240);
                }
                matches.append(line + 1).append(": ").append(value).append('\n');
                }
                last = end - 1;
                blocks++;
            }
            return clip(matches.toString(), maxChars);
        } catch (Exception ignored) { return ""; }
    }

    private String redact(String text) {
        if (text == null || text.isBlank()) return "";
        return text.replaceAll("(?im)(\\b[\\w.-]*(?:api[_-]?key|token|password|secret)[\\w.-]*\\s*[=:]\\s*[\"']?)([^\\s#;\"']{4,})", "$1[REDACTED]")
                .replaceAll("(?i)(Bearer\\s+)[A-Za-z0-9._~+/-]{16,}", "$1[REDACTED]");
    }

    private boolean isImportant(String path) {
        return IMPORTANT_NAMES.contains(Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT));
    }

    /** Versioned compressed checkpoint outside source folders. A rescan stats changed files only. */
    private Path checkpoint(AgentWorkspaceService.Workspace ws) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(cacheKey(ws).getBytes(StandardCharsets.UTF_8));
            return indexHome.resolve(HexFormat.of().formatHex(digest) + ".idx.gz");
        } catch (Exception failure) { throw new IllegalStateException(failure); }
    }
    private static void writeText(DataOutputStream out, String value) throws IOException {
        byte[] data = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(data.length); out.write(data);
    }
    private static String readText(DataInputStream in, int maxBytes) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > maxBytes) throw new IOException("Invalid index string length: " + length);
        return new String(in.readNBytes(length), StandardCharsets.UTF_8);
    }
    private void persist(AgentWorkspaceService.Workspace ws, WorkspaceIndex idx) {
        try {
            Files.createDirectories(indexHome);
            Path target = checkpoint(ws), temp = target.resolveSibling(target.getFileName() + ".tmp");
            try (DataOutputStream out = new DataOutputStream(new GZIPOutputStream(Files.newOutputStream(temp)))) {
                out.writeInt(5);
                writeText(out, idx.root());
                out.writeInt(idx.files().size());
                for (IndexedFile file : idx.files()) {
                    writeText(out, file.path()); writeText(out, file.sample()); writeText(out, file.layer());
                    out.writeLong(file.size()); out.writeLong(file.modifiedAt());
                    out.writeInt(file.termFrequency().size());
                    for (var term : file.termFrequency().entrySet()) { writeText(out, term.getKey()); out.writeInt(term.getValue()); }
                    out.writeInt(file.structure().symbols().size());
                    for (var symbol : file.structure().symbols().entrySet()) { writeText(out, symbol.getKey()); out.writeInt(symbol.getValue()); }
                    out.writeInt(file.structure().references().size());
                    for (String ref : file.structure().references()) writeText(out, ref);
                    out.writeInt(file.structure().steps().size());
                    for (String step : file.structure().steps()) writeText(out, step);
                }
                IndexStats st = idx.stats();
                out.writeLong(st.visitedFiles()); out.writeLong(st.indexedCharacters());
                out.writeLong(st.skippedTooLarge()); out.writeLong(st.skippedUnsupported());
                out.writeLong(st.skippedUnreadable()); out.writeLong(st.skippedDirectories());
                out.writeBoolean(st.scanIncomplete());
            }
            try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unavailable) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { /* Index is an optimisation; live files remain authoritative. */ }
    }
    private WorkspaceIndex load(AgentWorkspaceService.Workspace ws) {
        Path path = checkpoint(ws);
        if (!Files.isRegularFile(path)) return null;
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(Files.newInputStream(path)))) {
            int version = in.readInt();
            if (version != 2 && version != 3 && version != 4 && version != 5) return null;
            String root = readText(in, 16_384);
            if (!root.equals(ws.root().toString())) return null;
            int count = in.readInt();
            if (count < 0) return null;
            List<IndexedFile> files = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                String relative = readText(in, 16_384), sample = readText(in, 150_000);
                String layer = version >= 4 ? readText(in, 64) : "";
                long size = in.readLong(), modified = in.readLong();
                int termCount = in.readInt();
                if (termCount < 0 || termCount > MAX_TERMS_PER_FILE) return null;
                Map<String,Integer> frequency = new HashMap<>();
                for (int t = 0; t < termCount; t++) frequency.put(readText(in, 1_024), in.readInt());
                WorkspaceCodeIntelligence.Structure structure = WorkspaceCodeIntelligence.Structure.EMPTY;
                if (version >= 3) {
                    int symbolCount = in.readInt();
                    if (symbolCount < 0 || symbolCount > 240) return null;
                    Map<String,Integer> symbols = new LinkedHashMap<>();
                    for (int n = 0; n < symbolCount; n++) symbols.put(readText(in, 512), in.readInt());
                    int refCount = in.readInt();
                    if (refCount < 0 || refCount > 240) return null;
                    Set<String> refs = new LinkedHashSet<>();
                    for (int n = 0; n < refCount; n++) refs.add(readText(in, 512));
                    int stepCount = in.readInt();
                    if (stepCount < 0 || stepCount > 180) return null;
                    Set<String> steps = new LinkedHashSet<>();
                    for (int n = 0; n < stepCount; n++) steps.add(readText(in, 512));
                    structure = new WorkspaceCodeIntelligence.Structure(symbols, refs, steps);
                }
                files.add(new IndexedFile(relative, Map.copyOf(frequency), sample, size, modified, structure,
                        layer.isBlank() ? classifyLayer(relative, sample, structure) : layer));
            }
            long visited = version >= 5 ? in.readLong() : in.readInt();
            long indexedChars = in.readLong();
            long tooLarge = version >= 5 ? in.readLong() : in.readInt();
            long unsupported = version >= 5 ? in.readLong() : in.readInt();
            long unreadable = version >= 5 ? in.readLong() : in.readInt();
            long skippedDirs = version >= 5 ? in.readLong() : in.readInt();
            IndexStats st = new IndexStats(files.size(), visited, Instant.now().toString(), indexedChars,
                    tooLarge, unsupported, unreadable, skippedDirs, in.readBoolean());
            return new WorkspaceIndex(root, List.copyOf(files), st);
        } catch (Exception invalid) { return null; }
    }

    private static String classifyLayer(String path, String sample, WorkspaceCodeIntelligence.Structure structure) {
        String p = path == null ? "" : path.replace('\\', '/').toLowerCase(Locale.ROOT);
        String body = sample == null ? "" : sample.substring(0, Math.min(sample.length(), 12_000)).toLowerCase(Locale.ROOT);
        if (p.matches(".*(?:/test/|/tests/|/e2e/|/spec/|\\.spec\\.|\\.test\\.).*") || body.contains("@test")) return "test";
        if (p.matches(".*(?:controller|resource|endpoint|rest|api)[^/]*\\.(?:java|kt|cs|ts|js)$") || body.contains("@restcontroller") || body.contains("@controller")) return "controller";
        if (p.matches(".*(?:repository|dao|mapper|persistence)[^/]*\\.(?:java|kt|cs|ts|js)$") || body.contains("@repository") || body.contains("jparepository") || p.endsWith(".sql")) return "data";
        if (p.matches(".*(?:calculator|calculation|metric|kpi|histogram|aggregation|scoring|score|rule|engine)[^/]*\\.(?:java|kt|cs|ts|js|py)$")) return "calculation";
        if (p.matches(".*(?:service|manager|processor|handler|usecase)[^/]*\\.(?:java|kt|cs|ts|js|py)$") || body.contains("@service")) return "service";
        if (p.matches(".*(?:/frontend/|/ui/|/web/|/client/|/components?/|/pages?/|/views?/).*") || p.matches(".*\\.(?:tsx|jsx|vue|svelte|html|css|scss)$")) return "frontend";
        if (p.matches(".*(?:dto|model|entity|domain|schema)[^/]*\\.(?:java|kt|cs|ts|js)$")) return "model";
        if (p.matches(".*(?:application\\.(?:properties|ya?ml)|\\.config\\.|pom\\.xml|build\\.gradle|package\\.json|dockerfile|compose\\.).*")) return "config";
        return "other";
    }

    private String cacheKey(AgentWorkspaceService.Workspace ws) {
        return ws.projectId() + "|" + ws.root().toAbsolutePath().normalize();
    }

    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, Math.max(0, max - 18)) + " …[clipped]";
    }

    private record IndexedFile(String path, Map<String,Integer> termFrequency, String sample, long size, long modifiedAt,
                               WorkspaceCodeIntelligence.Structure structure, String layer) {
        IndexedFile(String path, Map<String,Integer> frequency, String sample, long size, long modifiedAt,
                    WorkspaceCodeIntelligence.Structure structure) {
            this(path, frequency, sample, size, modifiedAt, structure, classifyLayer(path, sample, structure));
        }
        IndexedFile(String path, Map<String,Integer> frequency, String sample, long size, long modifiedAt) {
            this(path, frequency, sample, size, modifiedAt, WorkspaceCodeIntelligence.Structure.EMPTY,
                    classifyLayer(path, sample, WorkspaceCodeIntelligence.Structure.EMPTY));
        }
    }
    private static final class IntAccumulator {
        private int[] values = new int[16];
        private int size;
        void add(int value) {
            if (size == values.length) values = Arrays.copyOf(values, values.length * 2);
            values[size++] = value;
        }
        int[] toArray() { return Arrays.copyOf(values, size); }
    }
    private record PostingSnapshot(WorkspaceIndex index, ConcurrentHashMap<String,int[]> postings,
                                   int[] lengths, double avgLength) { }

    private record ScoredFile(IndexedFile file, double score) { }
    private record GraphNode(String path, double score, int depth) { }
    private record GraphSnapshot(WorkspaceIndex index, Map<String,Set<String>> graph) { }
    private record WorkspaceIndex(String root, List<IndexedFile> files, IndexStats stats) { }
    public record IndexStats(long indexedFiles, long visitedFiles, String generatedAt, long indexedCharacters,
                             long skippedTooLarge, long skippedUnsupported, long skippedUnreadable,
                             long skippedDirectories, boolean scanIncomplete) {
        public IndexStats(long indexedFiles, long visitedFiles, String generatedAt) {
            this(indexedFiles, visitedFiles, generatedAt, 0L);
        }
        public IndexStats(long indexedFiles, long visitedFiles, String generatedAt, long indexedCharacters) {
            this(indexedFiles, visitedFiles, generatedAt, indexedCharacters, 0L, 0L, 0L, 0L, false);
        }
    }
}
