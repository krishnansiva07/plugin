#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya95-progress-tabs/OpenCodeTelemetrySmoke.java
java -cp "$TMP" OpenCodeTelemetrySmoke
node qa/eliya95-progress-tabs/verify.cjs
node --check src/main/resources/static/app.js
