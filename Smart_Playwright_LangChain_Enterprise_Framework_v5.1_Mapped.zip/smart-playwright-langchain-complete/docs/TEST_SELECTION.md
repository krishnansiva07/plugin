# Test selection and mapping

The framework uses `config/test-catalog.json` as the authoritative mapping between a test case and its Playwright script.

Each catalog entry maps:

- `testId`
- `testName`
- `tags`
- `suite`
- `priority`
- `spec`
- `dataFile`

## Commands

Run all enabled tests:

```powershell
npm test
```

Run by Test ID:

```powershell
npm test -- --testId=TC_ORDER_001
```

Run multiple Test IDs:

```powershell
npm test -- --testIds=TC_LOGIN_001,TC_ORDER_001
```

Run by tag:

```powershell
npm test -- --tag=smoke
```

Run by partial test name:

```powershell
npm test -- --testName="Place order"
```

Run by suite:

```powershell
npm test -- --suite=order
```

Combine filters:

```powershell
npm test -- --tag=smoke --suite=order
```

List without executing:

```powershell
npm test -- --testId=TC_ORDER_001 --list
```

## Execution mapping flow

1. `run-with-cacert.ts` parses custom filters.
2. `TestCatalog` searches `config/test-catalog.json`.
3. Matching catalog entries provide the exact spec paths.
4. Only mapped specs are passed to Playwright.
5. The runner passes the matching IDs through `TEST_IDS`.
6. `TestDataService` loads only those JSON rows.
7. Each Playwright test title is `[TEST_ID] Test name`.

The suite-level description remains readable, for example:

```typescript
test.describe('ORDER_SauceDemoPlaceOrder', () => { ... });
```

The exact test mapping is retained in the individual title:

```typescript
test(`[${row.testId}] ${row.testName}`, ...);
```
