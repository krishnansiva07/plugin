import fs from 'node:fs';
import path from 'node:path';

export interface TestCatalogEntry {
  testId: string;
  testName: string;
  suite: string;
  tags: string[];
  priority?: string;
  spec: string;
  dataFile: string;
}

export interface CatalogSelection {
  entries: TestCatalogEntry[];
  specs: string[];
  testIds: string[];
}

const csv = (value?: string): string[] =>
  (value ?? '')
    .split(',')
    .map(item => item.trim())
    .filter(Boolean);

export class TestCatalog {
  private readonly entries: TestCatalogEntry[];

  constructor(catalogPath = 'config/test-catalog.json') {
    const resolved = path.resolve(catalogPath);
    if (!fs.existsSync(resolved)) {
      throw new Error(`Test catalog not found: ${resolved}`);
    }

    const parsed: unknown = JSON.parse(fs.readFileSync(resolved, 'utf8'));
    if (!Array.isArray(parsed)) {
      throw new Error(`Test catalog must contain an array: ${resolved}`);
    }

    this.entries = parsed as TestCatalogEntry[];
    this.validate();
  }

  select(options: {
    testIds?: string;
    tags?: string;
    testName?: string;
    suite?: string;
    priority?: string;
  }): CatalogSelection {
    const requestedIds = csv(options.testIds).map(value => value.toLowerCase());
    const requestedTags = csv(options.tags).map(value => value.toLowerCase());
    const requestedName = options.testName?.trim().toLowerCase();
    const requestedSuite = options.suite?.trim().toLowerCase();
    const requestedPriority = options.priority?.trim().toLowerCase();

    const entries = this.entries.filter(entry => {
      if (requestedIds.length && !requestedIds.includes(entry.testId.toLowerCase())) return false;
      if (requestedName && !entry.testName.toLowerCase().includes(requestedName)) return false;
      if (requestedSuite && entry.suite.toLowerCase() !== requestedSuite) return false;
      if (requestedPriority && entry.priority?.toLowerCase() !== requestedPriority) return false;

      if (requestedTags.length) {
        const entryTags = entry.tags.map(tag => tag.toLowerCase());
        if (!requestedTags.every(tag => entryTags.includes(tag))) return false;
      }

      return true;
    });

    return {
      entries,
      specs: [...new Set(entries.map(entry => entry.spec))],
      testIds: entries.map(entry => entry.testId)
    };
  }

  private validate(): void {
    const seen = new Set<string>();

    for (const entry of this.entries) {
      if (!entry.testId?.trim()) throw new Error('Catalog entry is missing testId');
      if (!entry.testName?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing testName`);
      if (!entry.spec?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing spec`);
      if (!entry.dataFile?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing dataFile`);

      const key = entry.testId.toLowerCase();
      if (seen.has(key)) throw new Error(`Duplicate testId in catalog: ${entry.testId}`);
      seen.add(key);

      if (!fs.existsSync(path.resolve(entry.spec))) {
        throw new Error(`Spec mapped for ${entry.testId} does not exist: ${entry.spec}`);
      }
      if (!fs.existsSync(path.resolve(entry.dataFile))) {
        throw new Error(`Data file mapped for ${entry.testId} does not exist: ${entry.dataFile}`);
      }
    }
  }
}
