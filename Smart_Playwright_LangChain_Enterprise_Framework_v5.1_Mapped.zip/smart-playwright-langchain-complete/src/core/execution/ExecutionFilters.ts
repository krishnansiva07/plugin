export interface ExecutionFilters {
  testIds: string[];
}

const csv = (value?: string): string[] =>
  (value ?? '')
    .split(',')
    .map(value => value.trim())
    .filter(Boolean);

export function getExecutionFilters(): ExecutionFilters {
  return {
    testIds: csv(process.env.TEST_IDS)
  };
}
