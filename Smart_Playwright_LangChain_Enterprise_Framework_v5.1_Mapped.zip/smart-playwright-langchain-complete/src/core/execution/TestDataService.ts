import fs from 'node:fs';
import path from 'node:path';
import { getExecutionFilters } from './ExecutionFilters';

export interface BaseTestData {
  run?: boolean;
  testId: string;
  testName: string;
  suite?: string;
  priority?: string;
  tags?: string[];
}

export class TestDataService {
  static load<T extends BaseTestData>(filePath: string, defaultSuite?: string): T[] {
    const resolved = path.resolve(filePath);
    if (!fs.existsSync(resolved)) {
      throw new Error(`JSON test-data file not found: ${resolved}`);
    }

    const parsed: unknown = JSON.parse(fs.readFileSync(resolved, 'utf8'));
    if (!Array.isArray(parsed)) {
      throw new Error(`JSON test-data must contain an array: ${resolved}`);
    }

    const filters = getExecutionFilters();
    const rows = parsed as T[];
    const selected = rows.filter(row => {
      if (row.run === false) return false;
      if (filters.testIds.length && !filters.testIds.includes(row.testId)) return false;
      return true;
    });

    console.log(
      `[TEST DATA] ${path.basename(filePath)} (${defaultSuite ?? 'default'}): ` +
      `${selected.length}/${rows.length} selected`
    );

    return selected;
  }
}
