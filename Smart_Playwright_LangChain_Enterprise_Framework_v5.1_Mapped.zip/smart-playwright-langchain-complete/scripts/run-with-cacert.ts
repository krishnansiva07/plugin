import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { TestCatalog } from '../src/core/execution/TestCatalog';

const root = path.resolve(__dirname, '..');
const candidates = ['generated-ca-bundle.pem', 'corporate-ca.pem', 'cacert.pem', 'cacert', 'cacerts']
  .map(name => path.join(root, 'certificates', name));
const certificate = candidates.find(existsSync);
const childEnvironment: NodeJS.ProcessEnv = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not a PEM certificate bundle.`);
    process.exit(2);
  }
  childEnvironment.NODE_EXTRA_CA_CERTS = certificate;
}

type CustomKey =
  | 'testIds'
  | 'tags'
  | 'testName'
  | 'suite'
  | 'priority'
  | 'browser';

const aliases: Record<string, CustomKey> = {
  '--testid': 'testIds',
  '--testids': 'testIds',
  '--tag': 'tags',
  '--tags': 'tags',
  '--testname': 'testName',
  '--name': 'testName',
  '--suite': 'suite',
  '--priority': 'priority',
  '--browser': 'browser'
};

const custom: Partial<Record<CustomKey, string>> = {};
const input = process.argv.slice(2);
const playwrightArgs: string[] = [];

for (let index = 0; index < input.length; index++) {
  const raw = input[index];
  const equalsIndex = raw.indexOf('=');
  const option = (equalsIndex >= 0 ? raw.slice(0, equalsIndex) : raw).toLowerCase();
  const key = aliases[option];

  if (!key) {
    playwrightArgs.push(raw);
    continue;
  }

  const value = equalsIndex >= 0
    ? raw.slice(equalsIndex + 1).trim()
    : input[++index]?.trim();

  if (!value || value.startsWith('--')) {
    throw new Error(`Missing value for ${option}`);
  }

  custom[key] = value;
}

const hasSelection = Boolean(
  custom.testIds || custom.tags || custom.testName || custom.suite || custom.priority
);

if (hasSelection) {
  const catalog = new TestCatalog();
  const selection = catalog.select({
    testIds: custom.testIds,
    tags: custom.tags,
    testName: custom.testName,
    suite: custom.suite,
    priority: custom.priority
  });

  if (!selection.entries.length) {
    console.error('[TEST MAPPER] No catalog entry matched the supplied filter.');
    process.exit(3);
  }

  childEnvironment.TEST_IDS = selection.testIds.join(',');
  playwrightArgs.unshift(...selection.specs);

  console.log('\nSMART PLAYWRIGHT TEST MAPPER');
  console.log(`Matched tests : ${selection.testIds.join(', ')}`);
  console.log(`Mapped specs  : ${selection.specs.join(', ')}`);
} else {
  delete childEnvironment.TEST_IDS;
}

if (custom.browser) childEnvironment.BROWSER = custom.browser;

console.log(`Test IDs      : ${childEnvironment.TEST_IDS ?? 'All enabled tests'}`);
console.log(`Tags          : ${custom.tags ?? 'All'}`);
console.log(`Test name     : ${custom.testName ?? 'All'}`);
console.log(`Suite         : ${custom.suite ?? 'All'}`);
console.log(`Priority      : ${custom.priority ?? 'All'}`);
console.log(`Browser       : ${childEnvironment.BROWSER ?? 'From .env'}`);
console.log(`PW Arguments  : ${playwrightArgs.join(' ') || 'None'}\n`);

const cli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const result = spawnSync(process.execPath, [cli, 'test', ...playwrightArgs], {
  cwd: root,
  env: childEnvironment,
  stdio: 'inherit',
  windowsHide: false
});

if (result.error) {
  console.error(result.error);
  process.exit(1);
}

process.exit(result.status ?? 1);
