@echo off
setlocal
cd /d "%~dp0"
echo Building React UI...
cd frontend
call npm install
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1
cd ..
if exist backend\src\main\resources\static rmdir /s /q backend\src\main\resources\static
mkdir backend\src\main\resources\static
xcopy /e /i /y frontend\dist\* backend\src\main\resources\static\ >nul

echo Building Spring Boot application...
cd backend
call mvn clean test package
if errorlevel 1 exit /b 1
echo.
echo Build completed: backend\target\cashpooling-flat-file-generator.jar
endlocal
