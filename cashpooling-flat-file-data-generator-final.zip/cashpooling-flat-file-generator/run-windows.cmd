@echo off
cd /d "%~dp0backend"
java -jar target\cashpooling-flat-file-generator.jar
