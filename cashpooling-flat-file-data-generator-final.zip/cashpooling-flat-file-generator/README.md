# CASHPOOLING FLAT FILE DATA GENERATOR

Java 17, Spring Boot and React application for generating fixed-width flat-file test data. It uses no database and does not upload files.

## What is included

- BNP green React interface with no version displayed in the UI.
- Header, detail and footer designers with independent maximum line widths.
- Dynamic fields: entering 20 creates 20 editable field rows.
- Automatic contiguous positions, fixed-width padding and overlap/overflow validation.
- Download using the exact file name with no extension; compatible with Notepad++.
- Footer detail-record count with numeric padding: 1000 with width 6 becomes `001000`.
- Static, empty, random numeric, random alpha, random alphanumeric, sequence, current date/time, random date/time range, date sequence, dependent date, copy, substring, conditional and expression rules.
- Prefix and suffix support for generated values.
- Optional LLM assistant. The token is used only for the request and is never stored by the application.

## Date examples

- Current timestamp: `DATE_TIME`, output format `yyyyMMddHHmmss`.
- Random date between two dates: `RANDOM_DATE_TIME`, start/end plus output format `yyyyMMdd`.
- One date per row: `DATE_SEQUENCE`, start date, step and unit.
- Settlement date based on transaction date: `DEPENDENT_DATE`, source format `yyyyMMdd`, offset `2 DAYS`, output format `yyyyMMdd`.

## Build on Windows

1. Install Java 17, Maven 3.9+, Node.js 20+ and npm.
2. Run `build-windows.cmd`.
3. Run `run-windows.cmd`.
4. Open `http://localhost:8080`.

## LLM prompt example

```text
Create 1000 detail records with line width 80.
Header width 20: DERIVATIVE followed by current date in yyMMdd and fill remaining positions with spaces.
Field 1 Account, width 16, starts with ACC followed by 13 random digits.
Field 2 TransactionDate, width 8, random date between 2026-01-01 and 2026-12-31, format yyyyMMdd.
Field 3 SettlementDate, width 8, TransactionDate plus 2 days, format yyyyMMdd.
Field 4 Reserved, width 20, empty.
Footer starts with FTR and then detail record count width 6 with zero padding.
Download with no extension and use CRLF.
```

LLM base URL and model defaults are in `backend/src/main/resources/application.properties`; the UI permits an optional override.
