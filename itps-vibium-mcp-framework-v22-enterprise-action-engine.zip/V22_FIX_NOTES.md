# V22 Enterprise Action Engine

Execution date: 21-Jul-2026

## Problem corrected

Angular dropdown overlays were visible but their options were intermittently not selectable. Supplied XPath values also failed when the XPath represented an option rather than the dropdown trigger. Earlier JavaScript fallbacks could emit more than one click and generic DOM/screenshot changes could create false passes.

## Implemented

- Added `EnterpriseBrowserActionScript` as a deterministic transaction engine.
- Runtime distinction between dropdown trigger XPath and option XPath.
- Named locator support: `triggerXPath`, `fieldXPath`, `optionXPath`, `verificationXPath`.
- Exact visible/enabled option lookup inside the active overlay.
- Angular Material/CDK, ng-select, PrimeNG, native select and ARIA listbox handling.
- Search-input filtering, lazy option retries and virtual-scroll traversal.
- Same-origin iframe and open-shadow-root query traversal.
- Single semantic click only; duplicate JavaScript click dispatches removed.
- Hit-test failure is now a failure rather than a successful fallback.
- Reacquisition of controls after Angular detaches/re-renders nodes.
- Exact selected-value postcondition before pass.
- Composite/select MCP call chains are no longer stopped after opening the dropdown.
- Option elements in active overlays are ranked above duplicate text elsewhere on the page.
- Broader prompt parsing for select, choose, pick, set, change and visible-option instructions.
- Fixed field-label parsing so `MF dropdown` resolves to label `MF`.
- Added parser/action-engine unit tests.
- Corrected an existing checked-exception compile issue in deterministic XPath healing.

## Compatibility

The existing base execution flow, browser startup, LLM planning, healing, screenshots, HTML/JSON/Excel reporting and fresh DOM capture remain unchanged. The deterministic action engine is used for supplied XPath and recognized custom-dropdown selection flows.

## Validation performed in this environment

- Java 17 syntax/type compilation of the changed runner and action engine using dependency-compatible stubs.
- Generated browser JavaScript validated with Node.js `--check`.
- Prompt and XPath parsing checks executed successfully.
- A full Maven dependency build was not possible because Maven and external dependency download access were unavailable in the execution container.
