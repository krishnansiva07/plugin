package com.itps.vibium.service;

/**
 * Produces one browser-side transaction for deterministic enterprise actions.
 *
 * <p>The script intentionally performs a single semantic click, scopes dropdown
 * options to the active overlay, supports common Angular/Material/PrimeNG/ng-select
 * controls, retries dynamic and virtualized option rendering, and returns an exact
 * postcondition result that the Java runner can use instead of a generic DOM-change
 * pass.</p>
 */
final class EnterpriseBrowserActionScript {
    private EnterpriseBrowserActionScript() { }

    static String build(String action,
                        String value,
                        String label,
                        String genericXPath,
                        String triggerXPath,
                        String optionXPath,
                        String verificationXPath,
                        int timeoutMs) {
        return SCRIPT.formatted(
                js(action), js(value), js(label), js(genericXPath), js(triggerXPath),
                js(optionXPath), js(verificationXPath), Math.max(3000, timeoutMs));
    }

    private static String js(String value) {
        if (value == null) return "null";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n") + "\"";
    }

    private static final String SCRIPT = """
        (async () => {
          const cfg = {
            action: %s,
            value: %s,
            label: %s,
            genericXPath: %s,
            triggerXPath: %s,
            optionXPath: %s,
            verificationXPath: %s,
            timeoutMs: %d
          };
          const started = Date.now();
          const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
          const norm = value => String(value ?? '').replace(/\\xA0/g, ' ').replace(/\\s+/g, ' ').trim().toLowerCase();
          const rawText = element => String(element?.innerText || element?.textContent || element?.getAttribute?.('aria-label') || element?.getAttribute?.('title') || '');
          const exact = (actual, expected) => norm(actual) === norm(expected);
          const containsValue = (actual, expected) => {
            const a = norm(actual), e = norm(expected);
            if (!e) return false;
            if (a === e) return true;
            if (a.split(/[\\n,;|]+/).some(part => norm(part) === e)) return true;
            const escaped = e.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
            return new RegExp('(^|[^a-z0-9])' + escaped + '([^a-z0-9]|$)', 'i').test(a);
          };
          const isElement = node => !!node && node.nodeType === 1;
          const visible = element => {
            if (!isElement(element) || !element.isConnected) return false;
            const rect = element.getBoundingClientRect();
            const style = element.ownerDocument.defaultView.getComputedStyle(element);
            return rect.width > 1 && rect.height > 1 && style.display !== 'none' &&
                   style.visibility !== 'hidden' && Number(style.opacity || 1) > 0;
          };
          const enabled = element => !!element && !element.disabled && element.getAttribute?.('aria-disabled') !== 'true' &&
                                   !element.classList?.contains('disabled') && !element.classList?.contains('mat-mdc-option-disabled');
          const ownerWindow = element => element?.ownerDocument?.defaultView || window;
          let cachedRoots = null;
          const allRoots = () => {
            if (cachedRoots) return cachedRoots;
            const roots = [];
            const seen = new Set();
            const visit = root => {
              if (!root || seen.has(root) || roots.length > 250) return;
              seen.add(root); roots.push(root);
              let elements = [];
              try { elements = [...root.querySelectorAll('*')]; } catch (_) { }
              for (const element of elements) {
                if (element.shadowRoot) visit(element.shadowRoot);
                if (element.tagName === 'IFRAME' || element.tagName === 'FRAME') {
                  try { if (element.contentDocument) visit(element.contentDocument); } catch (_) { }
                }
              }
            };
            visit(document);
            cachedRoots = roots;
            return cachedRoots;
          };
          const deepQueryAll = selector => {
            const output = [];
            for (const root of allRoots()) {
              try { output.push(...root.querySelectorAll(selector)); } catch (_) { }
            }
            return [...new Set(output)];
          };
          const evaluateXPath = xpath => {
            if (!xpath) return [];
            const output = [];
            for (const root of allRoots()) {
              try {
                const evaluator = new XPathEvaluator();
                const result = evaluator.evaluate(xpath, root, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                for (let i = 0; i < result.snapshotLength; i++) output.push(result.snapshotItem(i));
              } catch (_) { }
            }
            return [...new Set(output)].filter(isElement);
          };
          const waitFor = async (supplier, description, timeout = cfg.timeoutMs) => {
            let last;
            while (Date.now() - started < timeout) {
              try {
                last = supplier();
                if (last && (!(Array.isArray(last)) || last.length)) return last;
              } catch (_) { }
              await delay(120);
            }
            throw new Error('WAIT_TIMEOUT: ' + description);
          };
          const stableSelector = element => {
            if (!element) return '';
            const escape = value => (window.CSS?.escape ? CSS.escape(value) : String(value).replace(/[^a-zA-Z0-9_-]/g, '\\\\$&'));
            if (element.id) return '#' + escape(element.id);
            for (const attr of ['data-testid','data-test','data-cy','name']) {
              const value = element.getAttribute?.(attr);
              if (value) { const safe = window.CSS?.escape ? CSS.escape(value) : String(value).replace(/"/g, ''); return element.tagName.toLowerCase() + '[' + attr + '="' + safe + '"]'; }
            }
            return '';
          };
          const optionSelector = '[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-item,.p-multiselect-item,.dropdown-item,li[role="option"],option';
          const selectedOptionSelector = optionSelector.split(',').flatMap(selector => [selector + '[aria-selected="true"]', selector + '[aria-checked="true"]']).join(',');
          const panelSelector = '[role="listbox"],[role="menu"],.cdk-overlay-pane,.cdk-overlay-container,.mat-mdc-select-panel,.mat-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.p-multiselect-panel,.dropdown-menu,.listbox,.select-panel';
          const triggerSelector = 'select,[role="combobox"],[aria-haspopup="listbox"],ng-select,.ng-select,mat-select,.mat-mdc-select,.mat-select,.p-dropdown,.p-select,.p-multiselect,.p-autocomplete,input[aria-autocomplete="list"],input[role="combobox"]';
          const isOption = element => !!element?.matches?.(optionSelector) || !!element?.closest?.(optionSelector);
          const optionNode = element => element?.closest?.(optionSelector) || element;
          const controlRoot = element => element?.closest?.('ng-select,.ng-select,mat-select,.mat-mdc-select,.mat-select,.p-dropdown,.p-select,.p-multiselect,.p-autocomplete,[role="combobox"],select,[class*="form-field"],[class*="field"]') || element;
          const accessibleName = element => {
            if (!element) return '';
            const values = [element.getAttribute?.('aria-label'), element.getAttribute?.('placeholder'), element.getAttribute?.('name')];
            const labelledBy = element.getAttribute?.('aria-labelledby');
            if (labelledBy) values.push(...labelledBy.split(/\\s+/).map(id => element.ownerDocument.getElementById(id)?.textContent));
            if (element.labels?.length) values.push(...[...element.labels].map(item => item.textContent));
            if (element.id) { const safeId = window.CSS?.escape ? CSS.escape(element.id) : String(element.id).replace(/"/g, ''); values.push(element.ownerDocument.querySelector('label[for="' + safeId + '"]')?.textContent); }
            values.push(element.closest?.('label')?.textContent);
            return values.filter(Boolean).join(' ');
          };
          const selectedValue = element => {
            const root = controlRoot(element);
            if (!root) return '';
            if (root.tagName === 'SELECT') return [...root.selectedOptions].map(option => option.textContent || option.value).join(' | ');
            const input = root.matches?.('input,textarea') ? root : root.querySelector?.('input,textarea');
            const values = [
              input?.value,
              root.getAttribute?.('aria-valuetext'),
              root.querySelector?.('.ng-value-label,.ng-value,.mat-mdc-select-value-text,.mat-select-value-text,.p-dropdown-label,.p-select-label,.p-multiselect-label,[class*="single-value"],[class*="singleValue"],[class*="value-label"],[class*="selected-value"]')?.textContent,
              [...(root.querySelectorAll?.('[role="option"][aria-selected="true"],[aria-checked="true"],.ng-value,.p-chip,.mat-mdc-chip') || [])].map(item => item.textContent).join(' | '),
              root.innerText
            ];
            return values.filter(Boolean).join(' | ');
          };
          const clickable = element => {
            if (!element) return null;
            if (isOption(element)) return optionNode(element);
            return element.closest?.('button,a,[role="button"],[role="menuitem"],[role="tab"],input,summary,li') || element;
          };
          const clickOnce = async element => {
            element = clickable(element);
            if (!visible(element)) throw new Error('TARGET_NOT_VISIBLE');
            if (!enabled(element)) throw new Error('TARGET_DISABLED');
            element.scrollIntoView({block:'center', inline:'nearest'});
            await delay(40);
            const rect = element.getBoundingClientRect();
            const doc = element.ownerDocument;
            const x = Math.max(0, Math.min(doc.defaultView.innerWidth - 1, rect.left + rect.width / 2));
            const y = Math.max(0, Math.min(doc.defaultView.innerHeight - 1, rect.top + rect.height / 2));
            const hit = doc.elementFromPoint(x, y);
            if (!hit || !(hit === element || element.contains(hit))) {
              throw new Error('TARGET_NOT_HIT_TESTABLE: top=' + (hit?.tagName || 'none'));
            }
            const eventTarget = hit;
            const win = ownerWindow(element);
            const mouse = {bubbles:true,cancelable:true,composed:true,view:win,clientX:x,clientY:y,button:0,buttons:1};
            const pointer = {...mouse,pointerId:1,pointerType:'mouse',isPrimary:true};
            for (const type of ['pointerover','mouseover','mouseenter','pointermove','mousemove','pointerdown','mousedown','pointerup','mouseup']) {
              try { eventTarget.dispatchEvent(type.startsWith('pointer') && win.PointerEvent ? new win.PointerEvent(type, pointer) : new win.MouseEvent(type, mouse)); } catch (_) { }
            }
            element.click(); // exactly one click event
            return {tag:element.tagName, role:element.getAttribute('role') || '', text:rawText(element).trim().slice(0,180), hitTestPassed:true};
          };
          const hoverOnce = async element => {
            element = clickable(element);
            if (!visible(element)) throw new Error('TARGET_NOT_VISIBLE');
            if (!enabled(element)) throw new Error('TARGET_DISABLED');
            element.scrollIntoView({block:'center', inline:'nearest'});
            await delay(40);
            const rect = element.getBoundingClientRect();
            const doc = element.ownerDocument, win = doc.defaultView;
            const x = Math.max(0, Math.min(win.innerWidth - 1, rect.left + rect.width / 2));
            const y = Math.max(0, Math.min(win.innerHeight - 1, rect.top + rect.height / 2));
            const hit = doc.elementFromPoint(x, y);
            if (!hit || !(hit === element || element.contains(hit))) throw new Error('TARGET_NOT_HIT_TESTABLE');
            const mouse = {bubbles:true,cancelable:true,composed:true,view:win,clientX:x,clientY:y,button:0,buttons:0};
            const pointer = {...mouse,pointerId:1,pointerType:'mouse',isPrimary:true};
            for (const type of ['pointerover','mouseover','mouseenter','pointermove','mousemove']) {
              hit.dispatchEvent(type.startsWith('pointer') && win.PointerEvent ? new win.PointerEvent(type,pointer) : new win.MouseEvent(type,mouse));
            }
            return {tag:element.tagName,role:element.getAttribute('role') || '',text:rawText(element).trim().slice(0,180),hitTestPassed:true};
          };
          const setInputValue = (element, value) => {
            const win = ownerWindow(element);
            const prototype = element.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement?.prototype : win.HTMLInputElement?.prototype;
            const setter = prototype ? Object.getOwnPropertyDescriptor(prototype, 'value')?.set : null;
            element.focus();
            if (setter) setter.call(element, value); else element.value = value;
            const InputCtor = win.InputEvent || win.Event;
            element.dispatchEvent(new InputCtor('input',{bubbles:true,inputType:'insertText',data:value}));
            element.dispatchEvent(new win.Event('change',{bubbles:true}));
          };
          const findByXPath = xpath => evaluateXPath(xpath).filter(visible)[0] || null;
          const findControlByLabel = label => {
            const controls = deepQueryAll(triggerSelector).filter(visible);
            if (!controls.length) return null;
            if (!norm(label)) return controls.length === 1 ? controls[0] : null;
            const wanted = norm(label);
            const scored = controls.map(control => {
              const root = controlRoot(control);
              const name = norm(accessibleName(control) + ' ' + accessibleName(root));
              const context = norm(root?.parentElement?.innerText || root?.parentElement?.textContent || '');
              let score = 0;
              if (name === wanted) score += 500;
              else if (name.includes(wanted)) score += 300;
              if (context === wanted) score += 250;
              else if (context.includes(wanted)) score += 120;
              if (control.getAttribute?.('aria-expanded') === 'true' || root?.getAttribute?.('aria-expanded') === 'true') score += 20;
              return {control, score};
            }).filter(item => item.score > 0).sort((a,b) => b.score - a.score);
            if (!scored.length) return null;
            if (scored.length > 1 && scored[0].score === scored[1].score) throw new Error('AMBIGUOUS_DROPDOWN_LABEL: ' + label);
            return scored[0].control;
          };
          const resolveTrigger = () => {
            if (cfg.triggerXPath) return findByXPath(cfg.triggerXPath);
            if (cfg.genericXPath) {
              const generic = findByXPath(cfg.genericXPath);
              if (generic && !isOption(generic)) return generic;
            }
            return findControlByLabel(cfg.label);
          };
          const activePanels = trigger => {
            const output = [];
            const root = controlRoot(trigger);
            const ids = [trigger, root].flatMap(node => [node?.getAttribute?.('aria-controls'), node?.getAttribute?.('aria-owns')])
              .filter(Boolean).flatMap(value => value.split(/\\s+/));
            for (const id of ids) {
              for (const candidate of deepQueryAll('#' + (window.CSS?.escape ? CSS.escape(id) : id))) if (visible(candidate)) output.push(candidate);
            }
            for (const panel of deepQueryAll(panelSelector).filter(visible)) output.push(panel);
            return [...new Set(output)].map(panel => {
              const style = panel.ownerDocument.defaultView.getComputedStyle(panel);
              const z = Number.parseInt(style.zIndex, 10) || 0;
              const controlled = ids.includes(panel.id) ? 10000 : 0;
              const listbox = panel.matches('[role="listbox"]') || panel.querySelector?.('[role="listbox"]') ? 1000 : 0;
              const options = panel.querySelectorAll?.(optionSelector).length || 0;
              return {panel, score:controlled + listbox + options * 10 + z};
            }).sort((a,b) => b.score - a.score).map(item => item.panel);
          };
          const optionCandidates = (trigger, explicitXPath) => {
            if (explicitXPath) return evaluateXPath(explicitXPath).map(optionNode).filter(item => visible(item) && enabled(item));
            const panels = activePanels(trigger);
            const scoped = [];
            for (const panel of panels) {
              if (panel.matches?.(optionSelector)) scoped.push(panel);
              try { scoped.push(...panel.querySelectorAll(optionSelector)); } catch (_) { }
            }
            return [...new Set(scoped)].map(optionNode).filter(item => visible(item) && enabled(item));
          };
          const findExactOption = (trigger, explicitXPath) => {
            const options = optionCandidates(trigger, explicitXPath);
            return options.find(option => exact(rawText(option), cfg.value)) ||
                   options.find(option => exact(option.getAttribute?.('aria-label'), cfg.value)) || null;
          };
          const findScrollers = trigger => {
            const panels = activePanels(trigger);
            const selectors = 'cdk-virtual-scroll-viewport,.cdk-virtual-scroll-viewport,.ng-dropdown-panel-items,.p-virtualscroller,.p-virtualscroller-content,[class*="virtual-scroll"],[class*="virtualscroll"],[role="listbox"]';
            const output = [];
            for (const panel of panels) {
              if (panel.matches?.(selectors)) output.push(panel);
              try { output.push(...panel.querySelectorAll(selectors)); } catch (_) { }
            }
            return [...new Set(output)].filter(visible);
          };
          const openDropdown = async trigger => {
            const root = controlRoot(trigger);
            if (root?.tagName === 'SELECT') return;
            const expanded = trigger.getAttribute?.('aria-expanded') === 'true' || root?.getAttribute?.('aria-expanded') === 'true';
            if (!expanded && !activePanels(trigger).some(panel => panel.querySelector?.(optionSelector))) {
              const preferred = root?.querySelector?.('[role="combobox"],.ng-select-container,.mat-mdc-select-trigger,.mat-select-trigger,.p-dropdown-trigger,.p-select-dropdown,input') || trigger;
              await clickOnce(preferred);
            }
            await waitFor(() => activePanels(trigger).find(panel => visible(panel)) || optionCandidates(trigger, cfg.optionXPath).length, 'dropdown overlay/options');
          };
          const verifyValue = async (trigger, expected) => {
            let verifiedNode = null;
            while (Date.now() - started < cfg.timeoutMs) {
              if (cfg.verificationXPath) {
                verifiedNode = findByXPath(cfg.verificationXPath);
                if (verifiedNode && containsValue(('value' in verifiedNode ? verifiedNode.value : '') + ' ' + rawText(verifiedNode), expected)) {
                  return {verified:true, selectedValue:(('value' in verifiedNode ? verifiedNode.value : '') || rawText(verifiedNode)).trim(), verification:'verification-xpath'};
                }
              }
              let current = trigger;
              if (!current?.isConnected) current = resolveTrigger();
              const currentValue = selectedValue(current);
              if (containsValue(currentValue, expected)) return {verified:true, selectedValue:currentValue.trim(), verification:'control-value'};
              const selectedOption = deepQueryAll(selectedOptionSelector).find(option => exact(rawText(option), expected));
              if (selectedOption) return {verified:true, selectedValue:rawText(selectedOption).trim(), verification:'aria-selected-option'};
              await delay(120);
            }
            return {verified:false, selectedValue:selectedValue(trigger), verification:'value-not-applied'};
          };
          const selectFromDropdown = async trigger => {
            if (!trigger) throw new Error('DROPDOWN_TRIGGER_NOT_FOUND: label=' + cfg.label + '; xpath=' + (cfg.triggerXPath || cfg.genericXPath));
            const root = controlRoot(trigger);
            if (root?.tagName === 'SELECT' || trigger.tagName === 'SELECT') {
              const select = root?.tagName === 'SELECT' ? root : trigger;
              const option = [...select.options].find(item => exact(item.textContent || item.label || item.value, cfg.value));
              if (!option) throw new Error('NATIVE_OPTION_NOT_FOUND: ' + cfg.value);
              select.value = option.value;
              select.dispatchEvent(new Event('input',{bubbles:true}));
              select.dispatchEvent(new Event('change',{bubbles:true}));
              const evidence = await verifyValue(select, cfg.value);
              if (!evidence.verified) throw new Error('NATIVE_OPTION_NOT_APPLIED: ' + cfg.value);
              return {strategy:'native-select', optionText:option.textContent?.trim() || option.value, ...evidence};
            }
            const before = selectedValue(trigger);
            if (containsValue(before, cfg.value)) return {strategy:'already-selected', verified:true, selectedValue:before, verification:'control-value', alreadySatisfied:true};
            await openDropdown(trigger);
            const filterInput = controlRoot(trigger)?.querySelector?.('input:not([type="hidden"])') ||
                                activePanels(trigger).flatMap(panel => [...panel.querySelectorAll?.('input:not([type="hidden"])') || []]).find(visible);
            if (filterInput && cfg.value) {
              try { setInputValue(filterInput, cfg.value); await delay(180); } catch (_) { }
            }
            let option = null;
            const scrollers = findScrollers(trigger);
            for (const scroller of scrollers) {
              scroller.scrollTop = 0;
              scroller.dispatchEvent(new Event('scroll',{bubbles:true}));
            }
            if (scrollers.length) await delay(120);
            for (let attempt = 0; attempt < 45 && !option; attempt++) {
              option = findExactOption(trigger, cfg.optionXPath);
              if (option) break;
              for (const scroller of scrollers) {
                const step = Math.max(scroller.clientHeight * 0.8, 120);
                scroller.scrollTop = Math.min(scroller.scrollHeight, scroller.scrollTop + step);
                scroller.dispatchEvent(new Event('scroll',{bubbles:true}));
              }
              await delay(120);
            }
            if (!option) throw new Error('DROPDOWN_OPTION_NOT_FOUND: value=' + cfg.value + '; activePanels=' + activePanels(trigger).length);
            const optionText = rawText(option).trim();
            const optionClick = await clickOnce(option);
            const evidence = await verifyValue(trigger, cfg.value);
            if (!evidence.verified) throw new Error('DROPDOWN_VALUE_NOT_APPLIED: expected=' + cfg.value + '; actual=' + evidence.selectedValue);
            return {strategy:'overlay-dropdown', optionText, optionClick, beforeValue:before, ...evidence};
          };

          const action = norm(cfg.action);
          if (action === 'select') {
            const genericTarget = cfg.genericXPath ? findByXPath(cfg.genericXPath) : null;
            const labelTrigger = cfg.label ? findControlByLabel(cfg.label) : null;
            const visibleOptionCandidate = !cfg.triggerXPath && !genericTarget ? findExactOption(null, cfg.optionXPath) : null;
            const visibleOption = visibleOptionCandidate && (!labelTrigger || activePanels(labelTrigger).some(panel => panel.contains(visibleOptionCandidate)))
              ? visibleOptionCandidate : null;
            if (visibleOption) {
              const expanded = deepQueryAll(triggerSelector).filter(item => visible(item) &&
                (item.getAttribute?.('aria-expanded') === 'true' || activePanels(item).some(panel => panel.contains(visibleOption))));
              const trigger = labelTrigger || (expanded.length === 1 ? expanded[0] : null);
              const optionText = rawText(visibleOption).trim();
              const optionClick = await clickOnce(visibleOption);
              const evidence = await verifyValue(trigger, cfg.value || optionText);
              if (!evidence.verified) throw new Error('VISIBLE_OPTION_CLICKED_BUT_VALUE_NOT_VERIFIED: ' + (cfg.value || optionText));
              return JSON.stringify({ok:true,verified:true,action:'select',locatorSource:cfg.optionXPath ? 'USER_XPATH' : 'ACTIVE_OVERLAY',strategy:'direct-visible-option',optionText,optionClick,...evidence});
            }
            if (genericTarget && isOption(genericTarget) && !cfg.triggerXPath) {
              const expanded = deepQueryAll(triggerSelector).filter(item => visible(item) && (item.getAttribute?.('aria-expanded') === 'true' || activePanels(item).some(panel => panel.contains(genericTarget))));
              const trigger = expanded.length === 1 ? expanded[0] : findControlByLabel(cfg.label);
              const option = optionNode(genericTarget);
              const optionText = rawText(option).trim();
              const optionClick = await clickOnce(option);
              const evidence = await verifyValue(trigger, cfg.value || optionText);
              if (!evidence.verified) throw new Error('OPTION_XPATH_CLICKED_BUT_VALUE_NOT_VERIFIED: ' + (cfg.value || optionText));
              return JSON.stringify({ok:true,verified:true,action:'select',locatorSource:'USER_XPATH',strategy:'direct-option-xpath',optionText,optionClick,...evidence});
            }
            const trigger = resolveTrigger();
            const result = await selectFromDropdown(trigger);
            return JSON.stringify({ok:true,verified:true,action:'select',locatorSource:(cfg.genericXPath || cfg.triggerXPath || cfg.optionXPath) ? 'USER_XPATH' : 'DOM_DROPDOWN',label:cfg.label,value:cfg.value,...result});
          }

          const xpath = cfg.genericXPath || cfg.triggerXPath || cfg.verificationXPath;
          if (!xpath) throw new Error('ACTION_XPATH_MISSING');
          const target = await waitFor(() => findByXPath(xpath), 'xpath visible: ' + xpath);
          if (action === 'verify') {
            return JSON.stringify({ok:true,verified:true,action:'verify',locatorSource:'USER_XPATH',matchedText:rawText(target).trim(),matchedTag:target.tagName});
          }
          if (action === 'set') {
            const root = controlRoot(target);
            const dropdownLike = target.matches?.(triggerSelector) || root?.matches?.(triggerSelector) ||
              target.getAttribute?.('aria-haspopup') === 'listbox' || root?.getAttribute?.('aria-haspopup') === 'listbox';
            if (dropdownLike) {
              const result = await selectFromDropdown(target);
              return JSON.stringify({ok:true,verified:true,action:'select',locatorSource:'USER_XPATH',label:cfg.label,value:cfg.value,...result});
            }
          }
          if (action === 'hover') {
            const beforeExpanded = target.getAttribute?.('aria-expanded');
            const beforePanels = deepQueryAll(panelSelector).filter(visible).length;
            const hover = await hoverOnce(target);
            await delay(180);
            const afterExpanded = target.getAttribute?.('aria-expanded');
            const afterPanels = deepQueryAll(panelSelector).filter(visible).length;
            const verified = beforeExpanded !== afterExpanded || afterPanels > beforePanels;
            return JSON.stringify({ok:true,verified,action:'hover',locatorSource:'USER_XPATH',verification:verified?'hover-state-change':'closed-loop-evidence-required',hover});
          }
          if (action === 'check' || action === 'uncheck') {
            let control = target.matches?.('input[type="checkbox"],input[type="radio"],[role="checkbox"],[role="radio"],[role="switch"]') ? target :
              target.querySelector?.('input[type="checkbox"],input[type="radio"],[role="checkbox"],[role="radio"],[role="switch"]');
            if (!control && target.matches?.('label')) {
              const forId = target.getAttribute('for');
              control = forId ? target.ownerDocument.getElementById(forId) : target.querySelector('input');
            }
            if (!control) control = target;
            const desired = action === 'check';
            const state = () => control.matches?.('input') ? !!control.checked : control.getAttribute?.('aria-checked') === 'true';
            if (state() === desired) return JSON.stringify({ok:true,verified:true,alreadySatisfied:true,action,locatorSource:'USER_XPATH',checked:desired,verification:'checked-state'});
            await clickOnce(target.matches?.('label') ? target : control);
            await waitFor(() => state() === desired, 'checked state=' + desired, Math.min(cfg.timeoutMs, 5000));
            return JSON.stringify({ok:true,verified:true,action,locatorSource:'USER_XPATH',checked:state(),verification:'checked-state'});
          }
          if (action === 'fill' || action === 'clear' || action === 'set') {
            const input = target.matches?.('input,textarea,[contenteditable="true"]') ? target : target.querySelector?.('input,textarea,[contenteditable="true"]');
            if (!input) throw new Error('XPATH_FILL_TARGET_NOT_EDITABLE');
            const desired = action === 'clear' ? '' : cfg.value;
            const before = input.isContentEditable ? input.textContent : input.value;
            if (exact(before, desired)) return JSON.stringify({ok:true,verified:true,alreadySatisfied:true,action,value:desired,currentValue:before,locatorSource:'USER_XPATH'});
            if (input.isContentEditable) {
              const win = ownerWindow(input);
              input.focus(); input.textContent = desired;
              const InputCtor = win.InputEvent || win.Event;
              input.dispatchEvent(new InputCtor('input',{bubbles:true,inputType:'insertText',data:desired}));
              input.dispatchEvent(new win.Event('change',{bubbles:true}));
            } else setInputValue(input, desired);
            await delay(100);
            const actual = input.isContentEditable ? input.textContent : input.value;
            if (!exact(actual, desired)) throw new Error('XPATH_FILL_NOT_APPLIED: expected=' + desired + '; actual=' + actual);
            return JSON.stringify({ok:true,verified:true,action,value:desired,currentValue:actual,locatorSource:'USER_XPATH',verification:'input-value'});
          }
          if (action === 'press') {
            const win = ownerWindow(target);
            const key = cfg.value || 'Enter';
            target.focus?.();
            const options = {bubbles:true,cancelable:true,composed:true,key,code:key,view:win};
            target.dispatchEvent(new win.KeyboardEvent('keydown',options));
            target.dispatchEvent(new win.KeyboardEvent('keypress',options));
            target.dispatchEvent(new win.KeyboardEvent('keyup',options));
            return JSON.stringify({ok:true,verified:false,action:'press',key,locatorSource:'USER_XPATH'});
          }
          if (isOption(target)) {
            const option = optionNode(target);
            const optionText = rawText(option).trim();
            const expanded = deepQueryAll(triggerSelector).filter(item => visible(item) &&
              (item.getAttribute?.('aria-expanded') === 'true' || activePanels(item).some(panel => panel.contains(option))));
            const trigger = expanded.length === 1 ? expanded[0] : findControlByLabel(cfg.label);
            const optionClick = await clickOnce(option);
            const evidence = await verifyValue(trigger, cfg.value || optionText);
            if (!evidence.verified) throw new Error('OPTION_CLICKED_BUT_VALUE_NOT_VERIFIED: ' + (cfg.value || optionText));
            return JSON.stringify({ok:true,verified:true,action:'select',locatorSource:'USER_XPATH',strategy:'click-option-xpath',optionText,optionClick,...evidence});
          }
          const beforeChecked = target.matches?.('input[type="checkbox"],input[type="radio"]') ? !!target.checked : null;
          const beforeExpanded = target.getAttribute?.('aria-expanded');
          const beforePressed = target.getAttribute?.('aria-pressed');
          const click = await clickOnce(target);
          await delay(100);
          const stateChanged = beforeChecked !== null && beforeChecked !== !!target.checked ||
            beforeExpanded !== target.getAttribute?.('aria-expanded') || beforePressed !== target.getAttribute?.('aria-pressed');
          return JSON.stringify({ok:true,verified:stateChanged,action:'click',locatorSource:'USER_XPATH',xpathResult:'success',verification:stateChanged?'control-state-change':'closed-loop-evidence-required',click});
        })()
        """;
}
