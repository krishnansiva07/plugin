package com.itps.vibium.service;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class ItpsMcpRunnerActionParsingTest {

    private final ItpsMcpRunner runner = new ItpsMcpRunner(
            new LlmClient(), new ReportService(), new RunStore(), "target/test-runs", 90, true);

    @Test
    void parsesAngularDropdownPromptsWithoutIncludingDropdownSuffixInLabel() throws Exception {
        assertParsed("Select BCEF from MF dropdown", "BCEF", "MF");
        assertParsed("Select \"BCEF\" in dropdown \"MF\"", "BCEF", "MF");
        assertParsed("Set value: \"BCEF\" in combo box \"MF\"", "BCEF", "MF");
        assertParsed("Click \"BCEF\" from visible text", "BCEF", "");
        assertParsed("Set BCEF to using xpath=//*[@id='mf']", "BCEF", "");
    }

    @Test
    void parsesKeyboardActionWithoutReadingQuotesInsideXPath() throws Exception {
        assertEquals("Enter", invoke("extractKeyValue", "Press Enter using xpath=//*[@id='search']"));
        assertEquals("Escape", invoke("extractKeyValue", "Press ESC following xpath=//*[@id='dialog']"));
    }

    @Test
    void supportsGenericAndNamedXPathMetadata() throws Exception {
        Object generic = invoke("extractXPathLocators",
                "Select BCEF from MF using xpath=//*[@id='mf']");
        assertTrue(generic.toString().contains("genericXPath=//*[@id='mf']"));

        Object named = invoke("extractXPathLocators",
                "Select BCEF from MF triggerXPath=\"//*[@id='mf']\" " +
                        "optionXPath=\"//*[@role='option' and normalize-space(.)='BCEF']\" " +
                        "verificationXPath=\"//*[@id='mf-selected']\"");
        assertTrue(named.toString().contains("triggerXPath=//*[@id='mf']"));
        assertTrue(named.toString().contains("optionXPath=//*[@role='option'"));
        assertTrue(named.toString().contains("verificationXPath=//*[@id='mf-selected']"));
    }

    @Test
    void generatedEnterpriseActionScriptUsesExactPostconditionAndSingleClick() {
        String script = EnterpriseBrowserActionScript.build(
                "select", "BCEF", "MF", "", "//*[@id='mf']",
                "//*[@role='option' and normalize-space(.)='BCEF']", "", 15000);

        assertTrue(script.contains("DROPDOWN_VALUE_NOT_APPLIED"));
        assertTrue(script.contains("element.click(); // exactly one click event"));
        assertTrue(script.contains("selectedOptionSelector"));
        assertFalse(script.contains("dispatchEvent(new MouseEvent('click'"));
    }

    private void assertParsed(String instruction, String expectedValue, String expectedLabel) throws Exception {
        assertEquals(expectedValue, invoke("extractQuotedOrSelectionValue", instruction));
        assertEquals(expectedLabel, invoke("extractDropdownLabel", instruction));
    }

    private Object invoke(String methodName, String instruction) throws Exception {
        Method method = ItpsMcpRunner.class.getDeclaredMethod(methodName, String.class);
        method.setAccessible(true);
        return method.invoke(runner, instruction);
    }
}
