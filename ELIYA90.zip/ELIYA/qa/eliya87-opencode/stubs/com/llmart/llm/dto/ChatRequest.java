package com.llmart.llm.dto;
public record ChatRequest(String projectId,String message,java.util.List<String> attachmentIds,ChatMode chatMode,Settings settings) {public String conversationId(){return null;} public record Settings(String model){} }
