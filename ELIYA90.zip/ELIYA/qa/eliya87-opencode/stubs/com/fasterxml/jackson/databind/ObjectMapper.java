package com.fasterxml.jackson.databind;
import java.io.*; import java.util.*; import java.util.regex.*; import java.nio.file.*;
/** Narrow fake JSON implementation ONLY for the zero-dependency OpenCode HTTP contract smoke. */
public class ObjectMapper {
 public JsonNode readTree(File f) throws IOException{return readTree(Files.readString(f.toPath()));}
 public JsonNode readTree(String s){
   if(s.startsWith("\""))return new JsonNode(s.substring(1,s.length()-1).replace("\\\"","\""));
   if(s.contains("\"version\""))return new JsonNode(Map.of("data",Map.of("version",match(s,"version"))));
   if(s.contains("\"id\""))return new JsonNode(Map.of("data",Map.of("id",match(s,"id"))));
   if(s.contains("\"type\""))return new JsonNode(Map.of("type",match(s,"type"),"properties",Map.of()));
   return new JsonNode();
 }
 private String match(String s,String key){
   Matcher m=Pattern.compile("\\\""+key+"\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").matcher(s);
   return m.find()?m.group(1):"";
 }
 public String writeValueAsString(Object o){return json(o);}
 private String json(Object o){
  if(o==null)return "null";
  if(o instanceof Map<?,?> m){List<String> list=new ArrayList<>();m.forEach((k,v)->list.add(json(String.valueOf(k))+":"+json(v)));return "{"+String.join(",",list)+"}";}
  if(o instanceof Iterable<?> list){List<String> l=new ArrayList<>();for(Object x:list)l.add(json(x));return "["+String.join(",",l)+"]";}
  if(o instanceof Number || o instanceof Boolean)return String.valueOf(o);
  return "\""+String.valueOf(o).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\"";
 }
 public void writeValue(File f,Object o) throws IOException{Files.writeString(f.toPath(),json(o));}
 @SuppressWarnings("unchecked") public <T> T convertValue(Object value,Class<T> cls){return (T)Map.of();}
 public JsonNode createObjectNode(){return new JsonNode();}
}
