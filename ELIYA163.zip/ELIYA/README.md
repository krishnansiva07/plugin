# ELIYA

ELIYA is a local Java/Spring Boot AI development assistant with browser Chat/Analyse/Agent,
terminal sessions, mapped workspaces, reference projects, lexical and semantic retrieval,
change verification, cancellation, and durable run history.

## Release/certification status

**This is a source stabilization package, not a production-certified executable.** Do not
replace a running installation until the full Maven verification and live-model end-to-end
acceptance succeed on the intended host. A passing source-level test is not proof that a
live provider/tool/browser workflow is correct.

## Agent stop / planning stabilization — validation evidence (19 Nov 2026)

This checkpoint fixes a reproducible Agent planning failure and hardens cancellation:

- The `AgentToolPalettePolicy` code-tool `Set.of` formerly contained duplicate `artifact_status`, `artifact_pending`, and `artifact_check` entries. Java threw `IllegalArgumentException` during static initialization, preventing the Agent tool selection policy from loading. Duplicate entries were removed.
- The tracked Agent worker is now registered early (before expensive workspace and context preparation). Explicit Stop interrupts the worker, signals waiting approval/question handlers, stops run-owned subprocesses, and records a `cancelling` state until the worker actually exits. Repeated Stop requests are idempotent. A race with late completion cannot change a cancelled run to `completed`.
- The browser Stop control prefers the active message's run ID, does not discard the stream if the backend refuses or cannot acknowledge cancellation, and distinguishes **Stop accepted** from **backend worker finished**.
- A cancelled Agent attempts to persist a visible conversation outcome, allowing conversation reload to recover the cancellation result. A database failure is disclosed, not silently reported as success.
- Three legacy isolated Java/shell test harnesses were updated so their compile stubs include newly required production types.

**Executed offline regression:** 217/217 JavaScript checks; 21/21 live Java lifecycle assertions for the real `AgentRunService` compiled in isolation; and 22/22 focused shell QA suites, including tool-policy initialization, source parsing, terminal cancellation/typechecking, large artifact staging, and prompt-deliverable checks. See `validation/positive-negative-test-cases.csv` and `validation/positive-negative-test-matrix.xlsx` for **134 positive and negative cases spanning 67 modules**. Each scenario distinguishes isolated coverage from unexecuted integration acceptance.

**Remaining release gates:** Maven dependencies were not accessible in the validation environment, so the complete Spring Boot application/JAR could not be compiled or launched here. Before replacing a running deployment, execute `./mvnw -Pfull-tests clean verify` on the intended host, launch the packaged JAR, and run the P0 browser/provider/Windows terminal acceptance cases (especially Stop during planning, model network stall, question/approval, subprocess execution, and recovery after reload). The ZIP is a complete corrected **source** package, not a certified binary.

## Workspace analysis and rollback safety limits

- **Indexing** limits (indexed/scanned files and source read bounds) remain independent of
  **Agent rollback protection**. Neither setting is a guarantee that all code was reviewed.
- `Settings → Workspace indexing & large source files` persists index settings locally.
- `Settings → Agent rollback protection` persists the maximum baseline file count,
  total byte size (entered in MiB), and snapshot deadline. These apply to the next Agent
  run without JVM launch flags or an index rescan. Changing them never disables rollback.
- Read-only analysis of attached source documents, including `.md` inputs, skips the
  backup and is restricted to read/search tools. Explicit file creation, implementation,
  migration or test execution remains subject to the protected rollback baseline.
- The rollback baseline includes the primary writable workspace and any **explicitly
  writable** reference/secondary workspace. Ordinary read-only reference repositories
  are excluded from snapshots. Do not widen protection limits just to copy an enormous
  legacy reference that is only being read for a migration.
- Snapshot preparation must fit the configured file, size and deadline limits and
  available local disk. A failed baseline stops before modifications and reports which
  independent safety limit was exceeded.

## What changed in this checkpoint

- **Human-readable task outcomes:** completed, blocked and failed Agent tasks now include a grounded account of finished steps, tracked changes, unfinished work, verification, improvement opportunities and the next action. Operational exceptions are saved as assistant turns instead of only emitting a transient stream error.
- **Correct failure-stage display:** the durable backend preserves the stage where a run stopped, including across restarts. The UI uses that stage instead of falsely coloring Plan red; if no stage is known, it avoids inventing one. Blocked/failed progress is clearly labeled as *not complete* even if activity reached a high percentage.
- **Recovered conversation outcomes:** saved runs with empty/generic responses reconstruct a cautious summary from their recorded evidence, and detailed reports load automatically after the run ends.
- **Autonomous run recovery:** every unfinished queued/running/cancelling/waiting state is
  marked interrupted after service restart; terminal states are finalized. Retains durable
  original task contract across resumed large tasks, together with work items and verification
  history. Does not silently resume an interrupted command.
- **Execution monitor:** terminal and browser runs are aggregated by run ID. An active browser
  SSE stream awaiting backend confirmation is shown as `connecting`, not falsely as `0 running`
  or asserted as a verified backend execution.
- **Index recovery:** a restored project index-status request can initiate the single bounded
  background index worker even if no earlier project GET occurred. Failed scans do not cause
  an infinite auto-retry on subsequent status polls.
- **Incomplete indexes:** scans hitting filesystem/file-count limits are explicitly marked
  failed, not falsely advertised as a complete index. Previous results stay fenced.
- **Semantic retrieval:** credential-free embedding requests are allowed only to HTTP
  loopback endpoints; external endpoints still require credentials. Semantic failures keep
  lexical search available and are not treated as verified semantic success.
- **Large repositories:** graph enrichment is bounded to the top-scoring 1,600 nearby files
  above 10,000 indexed files; large-workspace overviews avoid an unbounded series of fresh
  filesystem-stat calls and clearly mark the cached file manifest as not fully rechecked.
- **Build discipline:** build scripts now run `clean verify` with the Maven full-test profile;
  compilation/test failure and missing/non-executable JAR fail the build instead of claiming
  release success.
- **Regression:** updated outdated source and UI assertions, preserving complete long-prompt
  handoffs and testing honest active-run reporting.

## Workspace indexing and source-read settings

In the browser, open **Settings → Workspace indexing & large source files**. The
controls are stored under the per-user application data directory as
`workspace-indexing.properties`; they do not depend on `-D` flags or browser storage.
Use **Apply indexing limits & rescan** independently of model/provider settings.

| Limit | Default | Allowed range |
| --- | ---: | ---: |
| Maximum indexed files | 150,000 | 2,000–200,000 |
| Maximum files scanned | 300,000 | indexed-file cap–500,000 |
| Indexed source file size | 1,500,000 bytes | 32,000–8,000,000 bytes |
| Indexed source sample | 48,000 characters | 8,000–200,000 characters |
| Source lines per read request | 2,500 | 100–10,000 |
| Full-file read size | 256 KB | 64–8,192 KB |

File-count/size/sample changes invalidate the saved index fingerprint and queue a
background rebuild of currently tracked primary and reference projects. The browser
shows indexing status while the scan is in progress. Source-read settings take
effect immediately, without a full index rebuild. Source reads that reach the line
limit provide an explicit next-line continuation. These controls do not increase
model context/output token capacity and are not a cure for interrupted long-form
model generation or partial file writes. Large repositories may still hit memory,
filesystem, document parsing or embedding constraints.

The Verified Learning Memory editor was removed from Settings, but existing
learning records, their approval protections and the underlying service remain
unchanged. No learning data is deleted by this UI cleanup.

**Additional offline checks:** 202/202 JavaScript tests; three indexing-settings UI
contract tests; compiled Java persistence and REST-controller smoke tests;
12,051-file synthetic indexing/restart smoke; intelligence/rescan/watch smoke;
Chromium Settings save/reopen and long-output rendering checks. Maven/JAR startup
and a real 125,000-file reference workspace were not tested here.

## Offline validation evidence

For these completion-reporting changes, Java 17 syntax parsing of the modified Java files and an executable narrator harness passed. Offline checks of verification, stage restoration, rollback gating, browser rendering, and source safety passed. **The new JUnit tests have been added but have not been run using Maven** because the dependency repository is unavailable here.

See `validation/acceptance-results.txt` for the repeatable verification commands and results.
The executed checks included:

- JavaScript tests, including QA test files: **200 passed, 0 failed**.
- Chromium browser tests for 5,000-line Markdown/HTML exports, mobile rendering, UI progress,
  approvals, chat history and client-side recovery: **passed**.
- Agent policies, protected snapshot checks, cancellation/deadline, strict completion,
  autonomous artifact verification and token comparison policy: **passed**.
- An executable offline Java test compiling the real indexing, retrieval, checkpoint,
  token-ledger and agent-run persistence classes with isolated annotation/provider stubs:
  **12,051 synthetic TypeScript files indexed**; recent isolated replay approximately 922 ms indexing and 99 ms retrieval
  in one recorded run at a 768 MB heap limit. Incremental deletion, persisted-index refresh,
  live source filtering, restart recovery and large-task contract preservation passed.
  Synthetic throughput must not be extrapolated to a production workspace.

## Read-only test inventory in Analyse

- Plain questions such as "How many test cases are present?" automatically use the currently
  mapped workspace; the user does not need to say "workspace". A named reference alias
  selects that reference instead.
- The system reads **actual test source files**, selected from the already loaded workspace
  index, without running tests or changing code. It counts Playwright/Jest-style
  `test()`/`it()` declarations, Java JUnit/TestNG annotations, Cucumber scenario
  declarations, and Python `test_` functions, and supplies file-path evidence. README
  descriptions and the number of spec files are not used to invent a count.
- This is a **static declaration count**, not the full runner-expanded number of cases.
  `test.each`, Java data providers, Cucumber Example rows, loops, configuration projects,
  skips, and other dynamic expansion may change the runtime count. Use
  `npx playwright test --list` on a suitable host for Playwright's actual discovery.
- A missing/incomplete index, unreadable/oversized tests or inventory safety limit
  produces an **explicit incomplete/lower-bound** result, not a false confirmed count.
  The operation is read-only, bounded and cancellation-aware; it does not start a full
  workspace filesystem rescan. This fixes this count workflow, not every possible
  Analyse source-retrieval question.
- The UI treats a test-count inventory question as an inventory, not as an assertion
  about test execution or migration success; a true verification question retains
  the evidence warning.

**Validation for this additional change:** 202/202 JavaScript and QA tests passed;
Java source inventory compiled and a 5-assertion standalone Java harness passed.
The new JUnit test source is included, but JUnit/Maven execution and a full JAR build
remain unverified on this offline host (Maven is not installed).

## Still required for full release certification

1. **Maven and JAR:** the build could not run here because Maven is not installed and the
   environment cannot resolve `repo.maven.apache.org`. A full Spring Boot compile, test,
   packaged `target/eliya.jar` and start-up check remain unverified. Build on a network-enabled
   host with Java 17+ and Maven, using `./build-jar.sh` or `build-jar-windows.cmd`.
2. **Live Agent and Analyse:** verify successful and failed tasks through both terminal and
   browser, including cancellation, retries, file changes and final evidence after completion.
3. **Model and MCP:** test real LLM, embedding and explicitly requested MCP endpoints with
   valid credentials; source-policy tests do not substitute for live integrations.
4. **Performance:** benchmark actual same-prompt, same-model, same-provider tasks against
   OpenCode using provider-reported tokens and verified output equivalence. Existing
   token-comparison QA runs contain synthetic fixture records.
5. **Actual JVM restart:** verify session recovery by stopping and starting the production JAR
   mid-task, restoring the browser conversation and checking that interrupted work is not
   misrepresented as completed.
6. **Large real repository:** run 10k-100k files on the target OS with its symlinks, document
   formats, ignore rules, memory profile and embedding model. The synthetic test isolates the
   indexing implementation, not real-world variability.

**No claim of complete implementation or production readiness is made for these unverified items.**

## Reproduce

```bash
bash qa/stabilization/run.sh
node --test src/test/js/*.test.js qa/*.test.js
bash qa/agent-reliability/run.sh
bash qa/eliya145-validate.sh
bash qa/eliya68-autonomous-verification.sh
bash qa/eliya65-verification-smoke.sh
bash qa/eliya83-token-economy/run.sh
./build-jar.sh
```

On Windows use `build-jar-windows.cmd` to invoke a full Maven verification. Starting the
resulting Spring Boot application is done with `java -jar target/eliya.jar`, normally served
at `http://localhost:8090` unless port settings are changed. Keep model keys out of logs
and packages. Workspace configuration and agent permissions belong to the running instance.

## Large-artifact generation and recovery

Agent's new large-file workflow is **file-first** rather than one long chat response:

1. Resolve the writable primary workspace and references. Read-only analysis does not write.
2. Call `artifact_start` for **each** requested output, specifying a relative filename,
   number of initial chunks, and user-grounded content constraints. Unspecified plural
   prompt counts are determined from the requirements; an explicit count remains binding.
3. Use numbered `artifact_append` calls. Each chunk is persisted separately outside
   the workspace; re-sending identical content is safe, conflicting content fails.
4. Use `artifact_status` to inspect missing chunks, `artifact_pending` to find
   interrupted sessions, and `artifact_extend` when more chunks are required.
5. Call `artifact_finalize` only with the **original** destination path. Missing
   chunks, required content, malformed structure or unauthorized overwrites are
   blocking errors. On success, data is committed using the normal protected workspace
   baseline and an integrity receipt is persisted. Repeated finalization is safe.
6. Call `artifact_check` for an independent checksum and native-format recheck; a
   structural check is **not** proof the content satisfies every requirement.

Supported staged outputs: `.md`, `.txt`, `.html`, `.htm`, `.json`, `.xml`, `.csv`,
`.tsv`, `.docx`, `.xlsx`. Word files are native Office files built from Markdown
headings, paragraphs, bullets and pipe tables; Excel workbooks are native `.xlsx`
files from Markdown tables, or a line-based fallback. Advanced layout, formula
logic, charts and workbook-specific structures require separate workflows and
end-to-end tests. No text file is merely renamed to an Office extension.

Stages default to `~/.eliya/artifact-staging` and allow 64 MiB of UTF-8 source
and up to 1,024 numbered chunks;
these are resource protections, **not** line-count truncation rules.
The staging path, byte budget and maximum chunks are configurable through
`eliya.artifacts.staging`, `eliya.artifacts.generationMaxBytes`, and
`eliya.artifacts.maxChunks`. A chunk may
contain up to 100,000 characters. Excel's 32,767-character cell limit is enforced
with an error instead of silently shortening content; callers must split oversized
cells. Generated files can be downloaded from their sealed Agent completion record
without loading their entire content into the browser preview (configured download
limit defaults to 128 MiB). Overwrite/rollback protections remain mandatory.

Validation in this source package:

```bash
bash qa/large-artifacts/run.sh
bash qa/prompt-deliverable/run.sh
node --test src/test/js/*.test.js
```

`qa/large-artifacts` tests Java generation, 5,000-line Markdown/HTML round-trips,
checkpoint recovery, idempotency and incomplete-content failures **using stubs** for
Spring, Jackson and Apache POI. It does **not** validate the real `.docx`/`.xlsx`
serialization libraries or full application execution. These remain mandatory
for release acceptance, along with live LLM generation, an intentional interruption,
Word/Excel open/reopen, and browser file download on the target machine.

## Prompt generation and Agent completion contract

- **Prompt generation is a deliverable, not a plan preview.** An explicit request for one or more prompts is executed as a prompt-output task. It does not authorize implementation of the instructions inside those prompts.
- **Prompt counts are binding.** For example, "5 different prompts" must produce five individually headed, independently executable prompts. Chat/Analyse continuation checks that all five sections were produced before accepting the generated completion marker.
- **Output location matters.** A chat-only prompt request is read-only. A request to save prompts in the mapped workspace uses protected Agent file writes; completion requires separate Markdown files to exist and pass read-back content checks.
- **Independent final outcomes.** A generated prompt file is not substituted for an analysis result, and the Agent does not append an execution receipt to the end of a conversational prompt. Incomplete deliverables cannot be labelled completed.
- **Recovery UI is scoped.** Incomplete prompt sets have one retry action from the original request. Individual complete prompts can be downloaded or handed off to Agent one at a time. The old recursive "generate complete prompt/file" actions are removed.

Run the focused regression checks with `bash qa/prompt-deliverable/run.sh` (Java and Node.js) and UI checks with `node --test qa/*.test.js qa/prompt-deliverable/prompt-deliverable.test.js`. The complete Spring Boot executable still requires an available Maven installation, resolved dependencies and live-model integration tests. Do not treat the focused checks as full application certification.
