# V10 Enterprise Update

## Root-cause analysis of the click failure

The screenshot shows Vibium reporting that the target element is **obscured** and therefore does not receive pointer events. This is normally not a locator-not-found problem. The likely causes are:

1. A menu animation, loader, tooltip, sticky header, transparent overlay, or another element is physically covering the target at the click point.
2. The test plan contains a hover followed by a click, but the menu closes or changes between those actions.
3. The locator resolves to the correct DOM node, but it is not the topmost event-receiving element.
4. The previous framework treated a successful MCP response as sufficient and did not consistently handle click interception.

This is mainly a framework synchronization and interaction-resilience problem rather than a Vibium installation problem. Vibium correctly refused an unsafe physical click.

## Implemented corrections

- Added pre-click scrolling and hit-test preparation.
- Added controlled retry for obscured/intercepted/not-clickable/detached click failures.
- Added a final DOM click fallback only for a unique, visible, enabled selector and only after Vibium explicitly reports obstruction.
- Preserved closed-loop evidence validation so a tool response cannot create a false pass.
- Corrected the completion message from V9 to V10.
- Added UI selection checkboxes for executed tests.
- Added **Select failed** and **Rerun selected** actions.
- Added backend rerun API that reuses the original scenario definitions and execution configuration.
- A rerun creates a new run ID and new reports, keeping the original run auditable.

## Enterprise recommendations

For a fully enterprise deployment, the next infrastructure-level controls should be applied:

- Persist runs and encrypted configuration snapshots in a database instead of in-memory storage.
- Do not retain raw LLM tokens beyond the active run; use a secrets vault or short-lived token provider.
- Add authentication and role-based access to execution and artifact endpoints.
- Use a bounded Spring `TaskExecutor` instead of the common `CompletableFuture` pool.
- Add run cancellation, queue limits, concurrency limits, and browser-process cleanup watchdogs.
- Add structured JSON logging with correlation IDs and redact secrets.
- Add health/readiness endpoints and MCP/browser dependency checks.
- Add unit tests for parser, selection, rerun, evidence validation, and click fallback; add contract tests against the exact Vibium MCP version used in production.
- Package environment-specific paths outside `application.properties` through environment variables or deployment profiles.
- Define retention and cleanup rules for reports, screenshots, transcripts, and process logs.
