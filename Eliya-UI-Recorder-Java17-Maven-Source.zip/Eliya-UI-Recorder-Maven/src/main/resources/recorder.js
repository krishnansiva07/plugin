(() => {
  'use strict';
  if (window.__eliyaRecorderInit) return;
  Object.defineProperty(window, '__eliyaRecorderInit', { value: true, configurable: false });

  const MAX_TEXT = 180;
  const MAX_VALUE = 3000;
  const send = (type, properties = {}) => {
    try {
      if (typeof window.__eliyaRecorderSend !== 'function') return;
      window.__eliyaRecorderSend(JSON.stringify({
        type, timestamp: new Date().toISOString(),
        pageUrl: location.href, frameUrl: location.href,
        title: document.title || '', ...properties
      }));
    } catch (_) { /* Recording must never interfere with the tested application. */ }
  };

  const trim = (value, max = MAX_TEXT) => String(value ?? '').trim().slice(0, max);
  const sensitive = (el) => {
    const value = [el?.type, el?.name, el?.id, el?.getAttribute?.('autocomplete'),
      el?.getAttribute?.('aria-label'), el?.getAttribute?.('placeholder')].join(' ');
    return /password|passwd|secret|token|authenticat|api[_-]?key|credit.?card|cvv|cvc|pin.?code|one.?time.?pass|otp|ssn|social.?security|private.?key/i.test(value);
  };
  const escapeCss = (s) => {
    if (window.CSS && CSS.escape) return CSS.escape(String(s));
    return String(s).replace(/[^a-zA-Z0-9_-]/g, c => '\\' + c);
  };
  const attr = (name, value) => `[${name}="${String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"]`;
  const isUnique = (root, selector) => {
    try { return root.querySelectorAll(selector).length === 1; } catch (_) { return false; }
  };
  const localSelector = (el, root) => {
    for (const name of ['data-testid', 'data-test', 'data-qa', 'data-cy']) {
      const value = el.getAttribute(name);
      if (value) { const s = attr(name, value); if (isUnique(root, s)) return s; }
    }
    if (el.id) { const id = '#' + escapeCss(el.id); if (isUnique(root, id)) return id; }
    const tag = el.tagName.toLowerCase();
    if (el.getAttribute('name')) {
      const s = tag + attr('name', el.getAttribute('name'));
      if (isUnique(root, s)) return s;
    }
    if (el.getAttribute('aria-label')) {
      const s = tag + attr('aria-label', el.getAttribute('aria-label'));
      if (isUnique(root, s)) return s;
    }
    if (el.getAttribute('placeholder')) {
      const s = tag + attr('placeholder', el.getAttribute('placeholder'));
      if (isUnique(root, s)) return s;
    }
    const chain = [];
    let current = el;
    while (current && current.nodeType === 1) {
      const t = current.tagName.toLowerCase();
      if (current.id) { chain.unshift('#' + escapeCss(current.id)); break; }
      let piece = t;
      const parent = current.parentElement;
      if (parent) {
        const same = [...parent.children].filter(c => c.tagName === current.tagName);
        if (same.length > 1) piece += ':nth-of-type(' + (same.indexOf(current) + 1) + ')';
      }
      chain.unshift(piece);
      if (isUnique(root, chain.join(' > '))) break;
      current = parent;
    }
    return chain.join(' > ');
  };
  const selectors = (el) => {
    let root = el.getRootNode();
    const parts = [];
    while (root && root.nodeType === 11 && root.host) {
      parts.unshift(localSelector(el, root));
      el = root.host;
      root = el.getRootNode();
    }
    parts.unshift(localSelector(el, root || document));
    return parts;
  };
  const details = (el) => {
    if (!(el instanceof Element)) return {};
    const isSecret = sensitive(el);
    let cssPath = [];
    try { cssPath = selectors(el); } catch (_) { /* fallback metadata below */ }
    const testId = el.getAttribute('data-testid') || el.getAttribute('data-test') ||
      el.getAttribute('data-qa') || el.getAttribute('data-cy');
    const role = el.getAttribute('role') || ({BUTTON: 'button', A: 'link', SELECT: 'combobox'}[el.tagName] || '');
    const accessibleName = el.getAttribute('aria-label') || el.getAttribute('title') ||
      ((el.matches('button,a,[role="button"],[role="link"]')) ? trim(el.innerText) : '');
    const labels = el.labels ? Array.from(el.labels).map(label => trim(label.innerText)).filter(Boolean) : [];
    const locator = {
      css: cssPath.join(' >>> '), shadowPath: cssPath.length > 1 ? cssPath : [],
      testId: trim(testId), role: trim(role), accessibleName: trim(accessibleName),
      label: trim(labels[0]), name: trim(el.getAttribute('name')),
      placeholder: isSecret ? '[REDACTED]' : trim(el.getAttribute('placeholder')),
      id: trim(el.id)
    };
    return {
      tag: el.tagName.toLowerCase(), inputType: trim(el.type),
      selector: locator.css, locators: locator,
      text: isSecret ? '[REDACTED]' : trim(el.innerText || el.textContent),
      sensitive: isSecret
    };
  };
  const eventElement = (event) => {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    return path.find(item => item instanceof Element) || (event.target instanceof Element ? event.target : null);
  };
  const actionEl = (event) => {
    const el = eventElement(event);
    if (!el) return null;
    return el.closest('button,a,input,textarea,select,summary,option,label,[role="button"],[role="link"],[role="tab"],[role="menuitem"],[role="checkbox"],[role="radio"],[contenteditable="true"],[onclick]') || el;
  };
  document.addEventListener('click', event => {
    const el = actionEl(event);
    if (!el) return;
    if (el.matches('input:not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]),textarea,select,option')) return;
    send('click', { button: event.button, ...details(el) });
  }, true);
  document.addEventListener('dblclick', event => { const el = actionEl(event); if (el) send('doubleClick', details(el)); }, true);
  document.addEventListener('contextmenu', event => { const el = actionEl(event); if (el) send('rightClick', details(el)); }, true);
  // Record settled input values, including cases where the user stops while a field
  // is still focused. Deduplication prevents change + blur + input double records.
  const inputTimers = new Map();
  const priorInput = new WeakMap();
  const inputElement = (event) => {
    const el = eventElement(event);
    return el && el.matches('input,textarea,select,[contenteditable="true"]') ? el : null;
  };
  const captureInput = (el) => {
    if (!el) return;
    const type = (el.type || '').toLowerCase();
    let actionType = 'fill';
    const values = {};
    if (type === 'checkbox' || type === 'radio') { actionType = 'check'; values.checked = !!el.checked; }
    else if (el.tagName === 'SELECT') {
      actionType = 'select';
      values.value = sensitive(el) ? '[REDACTED]' : trim(el.value, MAX_VALUE);
      if (el.multiple) values.selected = sensitive(el) ? ['[REDACTED]'] :
        [...el.selectedOptions].map(option => trim(option.value, MAX_VALUE));
    } else if (type === 'file') {
      actionType = 'fileSelected';
      values.files = [...(el.files || [])].map(file => trim(file.name));
    } else {
      values.value = sensitive(el) ? '[REDACTED]' : trim(el.isContentEditable ? el.innerText : el.value, MAX_VALUE);
    }
    const signature = actionType + JSON.stringify(values);
    if (priorInput.get(el) === signature) return;
    priorInput.set(el, signature);
    send(actionType, { ...details(el), ...values });
  };
  const flushInput = (el) => {
    const timer = inputTimers.get(el);
    if (timer) { clearTimeout(timer); inputTimers.delete(el); }
    captureInput(el);
  };
  document.addEventListener('input', event => {
    const el = inputElement(event);
    if (!el) return;
    const existing = inputTimers.get(el);
    if (existing) clearTimeout(existing);
    inputTimers.set(el, setTimeout(() => flushInput(el), 650));
  }, true);
  document.addEventListener('change', event => flushInput(inputElement(event)), true);
  document.addEventListener('focusout', event => {
    const el = inputElement(event);
    if (el && inputTimers.has(el)) flushInput(el);
  }, true);
  window.__eliyaRecorderFlush = () => {
    for (const el of [...inputTimers.keys()]) flushInput(el);
    const focused = document.activeElement;
    if (focused instanceof Element && focused.matches('input,textarea,select,[contenteditable=\"true\"]')) captureInput(focused);
  };
  window.addEventListener('blur', window.__eliyaRecorderFlush);
  document.addEventListener('keydown', event => {
    const key = event.key;
    if (!['Enter', 'Escape', 'Tab'].includes(key) && !(event.ctrlKey || event.metaKey || event.altKey)) return;
    const el = actionEl(event);
    send('key', { key, ctrl: event.ctrlKey, alt: event.altKey, shift: event.shiftKey,
      meta: event.metaKey, ...(el ? details(el) : {}) });
  }, true);
  document.addEventListener('submit', event => {
    const el = event.target;
    if (el instanceof Element) send('submit', details(el));
  }, true);
  document.addEventListener('drop', event => {
    const el = actionEl(event);
    if (el) send('drop', details(el));
  }, true);

  let scrollTimer = 0;
  document.addEventListener('scroll', event => {
    const now = Date.now();
    if (now - scrollTimer < 600) return;
    scrollTimer = now;
    const target = event.target === document ? document.scrollingElement : event.target;
    if (!(target instanceof Element)) return;
    send('scroll', { ...details(target), scrollX: target.scrollLeft, scrollY: target.scrollTop });
  }, true);

  const navigation = () => send('navigate', { url: location.href });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', navigation, { once: true });
  else navigation();
  window.addEventListener('popstate', navigation);
  window.addEventListener('hashchange', navigation);
  for (const name of ['pushState', 'replaceState']) {
    try {
      const original = history[name];
      history[name] = function(...args) { const result = original.apply(this, args); navigation(); return result; };
    } catch (_) { /* Some environments disallow history patching. */ }
  }
})();
