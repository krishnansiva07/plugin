package com.eliya.recorder;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.stream.Stream;

/** Chromium DevTools integration using only the Java 17 standard library. */
final class BrowserRecorder implements AutoCloseable {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final ExecutorService tasks = Executors.newCachedThreadPool(r -> {
        Thread thread = new Thread(r, "recorder-cdp"); thread.setDaemon(true); return thread;
    });
    private final ConcurrentMap<String, CdpSocket> pages = new ConcurrentHashMap<>();
    private final Set<String> connecting = ConcurrentHashMap.newKeySet();
    private final BiConsumer<String, Map<String, Object>> onAction;
    private final String script;
    private volatile boolean closed;
    private volatile int port;
    private Process browserProcess;
    private Path profile;
    private CdpSocket browser;
    private String browserName;

    BrowserRecorder(String script, BiConsumer<String, Map<String, Object>> onAction) {
        this.script = script;
        this.onAction = onAction;
    }

    String launch(String url, String requestedBrowser) throws Exception {
        Path executable = findBrowser(requestedBrowser);
        browserName = executable.getFileName().toString().toLowerCase(Locale.ROOT).contains("edge") ? "Edge" :
            executable.getFileName().toString().toLowerCase(Locale.ROOT).contains("chrom") ? "Chrome / Chromium" : "Chromium-based browser";
        profile = Files.createTempDirectory("eliya-recorder-profile-");
        Path log = profile.resolve("browser.log");
        List<String> command = new ArrayList<>(List.of(
            executable.toString(), "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0",
            "--user-data-dir=" + profile.toAbsolutePath(), "--no-first-run", "--no-default-browser-check",
            "--new-window"));
        if (Boolean.getBoolean("recorder.headless")) command.add("--headless=new"); // CI / automated smoke tests only
        if (Boolean.getBoolean("recorder.disableSandbox")) command.add("--no-sandbox"); // CI containers ONLY; never recommended for desktop use
        command.add(url);
        browserProcess = new ProcessBuilder(command).redirectErrorStream(true)
            .redirectOutput(ProcessBuilder.Redirect.to(log.toFile())).start();

        Path activePort = profile.resolve("DevToolsActivePort");
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(20);
        while (System.nanoTime() < deadline) {
            if (closed) throw new IOException("Recording was cancelled");
            if (Files.exists(activePort)) {
                List<String> lines = Files.readAllLines(activePort);
                if (lines.size() >= 2) {
                    port = Integer.parseInt(lines.get(0).trim());
                    browser = new CdpSocket("browser", "ws://127.0.0.1:" + port + lines.get(1).trim());
                    browser.send("Target.setDiscoverTargets", Json.map("discover", true)).get(5, TimeUnit.SECONDS);
                    Map<String, Object> targets = browser.send("Target.getTargets", Json.map()).get(5, TimeUnit.SECONDS);
                    for (Object target : Json.array(Json.object(targets.get("result")).get("targetInfos"))) {
                        attachIfPage(Json.object(target));
                    }
                    return browserName;
                }
            }
            if (!browserProcess.isAlive()) {
                String diagnostic = Files.exists(log) ? Files.readString(log) : "No browser log available";
                if (diagnostic.length() > 1000) diagnostic = diagnostic.substring(0, 1000);
                throw new IOException("Browser exited before DevTools was available: " + diagnostic.replaceAll("\\s+", " "));
            }
            Thread.sleep(150);
        }
        throw new IOException("Could not connect to Chrome/Edge DevTools after 20 seconds. Browser log: " + log);
    }

    private void attachIfPage(Map<String, Object> target) {
        if (closed || !"page".equals(Json.str(target.get("type")))) return;
        String id = Json.str(target.get("targetId"));
        String url = Json.str(target.get("url"));
        if (id.isBlank() || url.startsWith("devtools://") || url.startsWith("chrome://") ||
            pages.containsKey(id) || !connecting.add(id)) return;
        tasks.execute(() -> {
            try {
                for (int attempt = 0; attempt < 12 && !closed; attempt++) {
                    try {
                        CdpSocket page = new CdpSocket(id, "ws://127.0.0.1:" + port + "/devtools/page/" + id);
                        if (closed) { page.close(); return; }
                        CdpSocket previous = pages.putIfAbsent(id, page);
                        if (previous != null) { page.close(); return; }
                        try {
                            page.send("Page.enable", Json.map()).get(5, TimeUnit.SECONDS);
                            page.send("Runtime.enable", Json.map()).get(5, TimeUnit.SECONDS);
                            page.send("Runtime.addBinding", Json.map("name", "__eliyaRecorderSend")).get(5, TimeUnit.SECONDS);
                            page.send("Page.addScriptToEvaluateOnNewDocument", Json.map("source", script)).get(5, TimeUnit.SECONDS);
                            page.send("Runtime.evaluate", Json.map("expression", script)).get(5, TimeUnit.SECONDS);
                        } catch (Exception ex) { pages.remove(id, page); page.close(); throw ex; }
                        return;
                    } catch (Exception e) {
                        if (attempt == 11) System.err.println("Recorder could not attach to page " + id + ": " + e.getMessage());
                        else Thread.sleep(200);
                    }
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            finally { connecting.remove(id); }
        });
    }

    private final class CdpSocket implements WebSocket.Listener, AutoCloseable {
        private final String id;
        private final WebSocket websocket;
        private final AtomicInteger sequence = new AtomicInteger();
        private final ConcurrentMap<Integer, CompletableFuture<Map<String, Object>>> pending = new ConcurrentHashMap<>();
        private final StringBuilder received = new StringBuilder();

        CdpSocket(String id, String address) throws Exception {
            this.id = id;
            websocket = http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(4))
                .buildAsync(URI.create(address), this).get(6, TimeUnit.SECONDS);
        }

        CompletableFuture<Map<String, Object>> send(String method, Map<String, Object> params) {
            int requestId = sequence.incrementAndGet();
            CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
            pending.put(requestId, future);
            websocket.sendText(Json.stringify(Json.map("id", requestId, "method", method, "params", params)), true)
                .whenComplete((sent, error) -> { if (error != null) {
                    pending.remove(requestId); future.completeExceptionally(error);
                }});
            return future;
        }

        @Override public void onOpen(WebSocket webSocket) { webSocket.request(1); }
        @Override public CompletionStage<?> onText(WebSocket ws, CharSequence data, boolean last) {
            String message = null;
            synchronized (received) {
                received.append(data);
                if (last) { message = received.toString(); received.setLength(0); }
            }
            if (message != null) {
                try { handle(Json.object(Json.parse(message))); }
                catch (Exception ex) { System.err.println("Ignoring invalid CDP message: " + ex.getMessage()); }
            }
            ws.request(1);
            return null;
        }

        private void handle(Map<String, Object> message) {
            if (message.containsKey("id")) {
                int n = ((Number) message.get("id")).intValue();
                CompletableFuture<Map<String, Object>> future = pending.remove(n);
                if (future != null) {
                    if (message.containsKey("error")) future.completeExceptionally(new IOException(Json.stringify(message.get("error"))));
                    else future.complete(message);
                }
                return;
            }
            String method = Json.str(message.get("method"));
            Map<String, Object> params = Json.object(message.get("params"));
            if ("Target.targetCreated".equals(method) || "Target.targetInfoChanged".equals(method)) {
                attachIfPage(Json.object(params.get("targetInfo")));
            } else if ("Target.targetDestroyed".equals(method)) {
                String removedId = Json.str(params.get("targetId"));
                CdpSocket page = pages.remove(removedId);
                if (page != null) page.close();
            } else if ("Runtime.bindingCalled".equals(method) && "__eliyaRecorderSend".equals(params.get("name"))) {
                try { onAction.accept(id, Json.object(Json.parse(Json.str(params.get("payload"))))); }
                catch (Exception e) { System.err.println("Recorder action processing error: " + e.getMessage()); }
            }
        }

        @Override public CompletionStage<?> onClose(WebSocket ws, int status, String reason) {
            IOException error = new IOException("DevTools connection closed: " + status + " " + reason);
            for (var future : pending.values()) future.completeExceptionally(error);
            pending.clear();
            return null;
        }
        @Override public void onError(WebSocket ws, Throwable ex) {
            for (var future : pending.values()) future.completeExceptionally(ex);
            pending.clear();
        }
        @Override public void close() {
            try { websocket.sendClose(WebSocket.NORMAL_CLOSURE, "done"); } catch (Exception ignored) { }
            websocket.abort();
        }
    }

    /** Forces pending typed text to be emitted before Stop freezes the journal. */
    void flushPendingInputs() {
        List<CompletableFuture<Map<String, Object>>> requests = new ArrayList<>();
        for (CdpSocket page : pages.values()) {
            requests.add(page.send("Runtime.evaluate", Json.map("expression",
                "window.__eliyaRecorderFlush && window.__eliyaRecorderFlush()")));
        }
        if (requests.isEmpty()) return;
        try { CompletableFuture.allOf(requests.toArray(CompletableFuture[]::new))
                .orTimeout(2, TimeUnit.SECONDS).join(); }
        catch (Exception ignored) { /* Stop must work even if a tab is unresponsive. */ }
    }

    static Path findBrowser(String choice) throws IOException {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        List<String> names = new ArrayList<>();
        String chrome = System.getProperty("recorder.chromePath", "");
        String edge = System.getProperty("recorder.edgePath", "");
        if ("chrome".equals(choice) || "auto".equals(choice)) {
            if (!chrome.isBlank()) names.add(chrome);
            if (os.contains("win")) {
                String[] dirs = { System.getenv("PROGRAMFILES"), System.getenv("PROGRAMFILES(X86)"), System.getenv("LOCALAPPDATA") };
                for (String dir : dirs) if (dir != null) names.add(Path.of(dir, "Google", "Chrome", "Application", "chrome.exe").toString());
            } else if (os.contains("mac")) {
                names.add("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome");
                names.add(System.getProperty("user.home") + "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome");
            } else names.addAll(List.of("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"));
        }
        if ("edge".equals(choice) || "auto".equals(choice)) {
            if (!edge.isBlank()) names.add(edge);
            if (os.contains("win")) {
                String[] dirs = { System.getenv("PROGRAMFILES(X86)"), System.getenv("PROGRAMFILES"), System.getenv("LOCALAPPDATA") };
                for (String dir : dirs) if (dir != null) names.add(Path.of(dir, "Microsoft", "Edge", "Application", "msedge.exe").toString());
            } else if (os.contains("mac")) {
                names.add("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge");
                names.add(System.getProperty("user.home") + "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge");
            } else names.addAll(List.of("microsoft-edge", "microsoft-edge-stable", "microsoft-edge-beta"));
        }
        for (String candidate : names) {
            Path path = candidate.contains("/") || candidate.contains("\\") ? Path.of(candidate) : locateOnPath(candidate);
            if (path != null && Files.isRegularFile(path) && Files.isExecutable(path)) return path;
        }
        throw new IOException("No installed " + ("auto".equals(choice) ? "Chrome / Chromium / Edge" : choice) +
            " browser found. Install Chrome/Edge or specify -Drecorder.chromePath=... / -Drecorder.edgePath=...");
    }

    private static Path locateOnPath(String name) {
        String path = System.getenv("PATH");
        if (path == null) return null;
        for (String directory : path.split(java.io.File.pathSeparator)) {
            if (directory.isBlank()) continue;
            try {
                Path file = Path.of(directory).resolve(name);
                if (Files.isRegularFile(file) && Files.isExecutable(file)) return file;
            } catch (Exception ignored) { }
        }
        return null;
    }

    @Override public void close() {
        if (closed) return;
        closed = true;
        if (browser != null) browser.close();
        for (CdpSocket page : pages.values()) page.close();
        pages.clear();
        tasks.shutdownNow();
        if (browserProcess != null) {
            try {
                // Dedicated browser profile: only processes created for this recorder are terminated.
                try (Stream<ProcessHandle> children = browserProcess.descendants()) {
                    children.forEach(ph -> { try { ph.destroy(); } catch (Exception ignored) { } });
                }
                browserProcess.destroy();
                if (!browserProcess.waitFor(2, TimeUnit.SECONDS)) browserProcess.destroyForcibly();
            } catch (Exception ignored) { }
        }
        if (profile != null) {
            try (Stream<Path> files = Files.walk(profile)) {
                files.sorted(Comparator.reverseOrder()).forEach(file -> {
                    try { Files.deleteIfExists(file); } catch (Exception ignored) { }
                });
            } catch (Exception ignored) { }
        }
    }
}
