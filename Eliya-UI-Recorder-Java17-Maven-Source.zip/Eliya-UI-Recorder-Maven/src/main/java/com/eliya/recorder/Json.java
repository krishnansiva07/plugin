package com.eliya.recorder;

import java.util.*;

/** Dependency-free JSON parser / serializer, compatible with Java 17. */
final class Json {
    private Json() { }

    static String stringify(Object value) {
        StringBuilder out = new StringBuilder();
        write(out, value);
        return out.toString();
    }

    static String pretty(Object value) {
        StringBuilder out = new StringBuilder();
        writePretty(out, value, 0);
        return out.toString();
    }

    private static void write(StringBuilder out, Object value) {
        if (value == null) { out.append("null"); return; }
        if (value instanceof String s) { quote(out, s); return; }
        if (value instanceof Number || value instanceof Boolean) { out.append(value); return; }
        if (value instanceof Map<?, ?> map) {
            out.append('{'); boolean first = true;
            for (var entry : map.entrySet()) {
                if (!first) out.append(','); first = false;
                quote(out, String.valueOf(entry.getKey())); out.append(':'); write(out, entry.getValue());
            }
            out.append('}'); return;
        }
        if (value instanceof Iterable<?> items) {
            out.append('['); boolean first = true;
            for (Object item : items) { if (!first) out.append(','); first = false; write(out, item); }
            out.append(']'); return;
        }
        if (value.getClass().isArray()) {
            out.append('['); int n = java.lang.reflect.Array.getLength(value);
            for (int i = 0; i < n; i++) { if (i > 0) out.append(','); write(out, java.lang.reflect.Array.get(value, i)); }
            out.append(']'); return;
        }
        quote(out, String.valueOf(value));
    }

    private static void quote(StringBuilder out, String s) {
        out.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                case '\b' -> out.append("\\b");
                case '\f' -> out.append("\\f");
                default -> { if (c < 0x20) out.append(String.format("\\u%04x", (int)c)); else out.append(c); }
            }
        }
        out.append('"');
    }

    private static void writePretty(StringBuilder out, Object value, int depth) {
        if (value instanceof Map<?, ?> map) {
            out.append('{');
            int i = 0;
            for (var entry : map.entrySet()) {
                if (i++ > 0) out.append(',');
                out.append('\n'); out.append("  ".repeat(depth + 1));
                quote(out, String.valueOf(entry.getKey())); out.append(": ");
                writePretty(out, entry.getValue(), depth + 1);
            }
            if (!map.isEmpty()) { out.append('\n'); out.append("  ".repeat(depth)); }
            out.append('}');
        } else if (value instanceof Iterable<?> iterable) {
            out.append('[');
            int i = 0;
            for (Object item : iterable) {
                if (i++ > 0) out.append(',');
                out.append('\n'); out.append("  ".repeat(depth + 1));
                writePretty(out, item, depth + 1);
            }
            if (i > 0) { out.append('\n'); out.append("  ".repeat(depth)); }
            out.append(']');
        } else write(out, value);
    }

    static Object parse(String text) {
        Parser parser = new Parser(text);
        Object result = parser.value(); parser.ws();
        if (parser.p != text.length()) throw new IllegalArgumentException("Trailing characters in JSON");
        return result;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> object(Object value) {
        return value instanceof Map<?, ?> ? (Map<String, Object>) value : Collections.emptyMap();
    }

    @SuppressWarnings("unchecked")
    static List<Object> array(Object value) {
        return value instanceof List<?> ? (List<Object>) value : Collections.emptyList();
    }

    static String str(Object value) { return value == null ? "" : String.valueOf(value); }

    static Map<String, Object> map(Object... values) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (int i = 0; i < values.length; i += 2) result.put((String) values[i], values[i + 1]);
        return result;
    }

    private static final class Parser {
        private final String s;
        private int p;
        private Parser(String s) { this.s = s; }
        private void ws() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }
        private char peek() { ws(); if (p >= s.length()) throw new IllegalArgumentException("Unexpected end of JSON"); return s.charAt(p); }
        private boolean take(char c) { ws(); if (p < s.length() && s.charAt(p) == c) { p++; return true; } return false; }
        private Object value() {
            char c = peek();
            if (c == '"') return string();
            if (c == '{') return object();
            if (c == '[') return array();
            if (c == 't' && s.startsWith("true", p)) { p += 4; return true; }
            if (c == 'f' && s.startsWith("false", p)) { p += 5; return false; }
            if (c == 'n' && s.startsWith("null", p)) { p += 4; return null; }
            if (c == '-' || Character.isDigit(c)) return number();
            throw new IllegalArgumentException("Unexpected character at " + p);
        }
        private String string() {
            if (!take('"')) throw new IllegalArgumentException("Expected quote");
            StringBuilder result = new StringBuilder();
            while (p < s.length()) {
                char c = s.charAt(p++);
                if (c == '"') return result.toString();
                if (c != '\\') { result.append(c); continue; }
                if (p >= s.length()) break;
                char escaped = s.charAt(p++);
                switch (escaped) {
                    case '"', '\\', '/' -> result.append(escaped);
                    case 'n' -> result.append('\n');
                    case 'r' -> result.append('\r');
                    case 't' -> result.append('\t');
                    case 'b' -> result.append('\b');
                    case 'f' -> result.append('\f');
                    case 'u' -> {
                        if (p + 4 > s.length()) throw new IllegalArgumentException("Invalid Unicode escape");
                        result.append((char) Integer.parseInt(s.substring(p, p + 4), 16)); p += 4;
                    }
                    default -> throw new IllegalArgumentException("Invalid JSON escape");
                }
            }
            throw new IllegalArgumentException("Unterminated JSON string");
        }
        private Map<String, Object> object() {
            take('{'); Map<String, Object> result = new LinkedHashMap<>();
            if (take('}')) return result;
            do {
                if (peek() != '"') throw new IllegalArgumentException("Expected property name");
                String key = string(); if (!take(':')) throw new IllegalArgumentException("Expected colon");
                result.put(key, value());
                if (take('}')) return result;
            } while (take(','));
            throw new IllegalArgumentException("Malformed JSON object");
        }
        private List<Object> array() {
            take('['); List<Object> result = new ArrayList<>();
            if (take(']')) return result;
            do { result.add(value()); if (take(']')) return result; } while (take(','));
            throw new IllegalArgumentException("Malformed JSON array");
        }
        private Number number() {
            int start = p;
            if (s.charAt(p) == '-') p++;
            while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
            if (p < s.length() && s.charAt(p) == '.') { p++; while (p < s.length() && Character.isDigit(s.charAt(p))) p++; }
            if (p < s.length() && (s.charAt(p) == 'e' || s.charAt(p) == 'E')) {
                p++; if (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) p++;
                while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
            }
            String raw = s.substring(start, p);
            if (raw.indexOf('.') >= 0 || raw.indexOf('e') >= 0 || raw.indexOf('E') >= 0) return Double.valueOf(raw);
            return Long.valueOf(raw);
        }
    }
}
