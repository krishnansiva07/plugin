package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        McpClient mcp = null;
        try {
            Files.createDirectories(screenshotDir);
            List<String> args = mcpArgsWithScreenshotDir(config.getMcpArgs(), screenshotDir);
            mcp = new McpClient(config.getMcpCommand(), args, Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);
            startBrowserOnce(mcp, catalog, config);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                results.add(executeScenario(mcp, catalog, scenario, config, screenshotDir));
            }

            status.setScenarios(results);
            status.setTotal(results.size());
            int passed = (int) results.stream().filter(s -> "PASSED".equals(s.getStatus())).count();
            status.setPassed(passed);
            status.setFailed(results.size() - passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("V5 MCP execution completed. Summary and searchable technical logs were generated separately.");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.close(); } catch (Exception ignored) {}
            }
            status.setFinishedAt(Instant.now());
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) {}
            }
        }
    }

    private List<String> mcpArgsWithScreenshotDir(String rawArgs, Path screenshotDir) {
        List<String> args = new ArrayList<>(splitArgs(rawArgs));
        boolean hasScreenshotDir = args.stream().anyMatch(a -> a.equalsIgnoreCase("--screenshot-dir"));
        if (!hasScreenshotDir) {
            args.add("--screenshot-dir");
            args.add(screenshotDir.toAbsolutePath().toString());
        }
        return args;
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> start = catalog.startTool();
        if (start.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(start.get(), "headless")) args.put("headless", config.isHeadless());
        if (config.getBrowserId() != null && !"vibium-managed-chrome".equalsIgnoreCase(config.getBrowserId())) {
            String executable = config.getBrowserExecutable();
            boolean applied = false;
            for (String key : List.of("executablePath", "browserExecutable", "browserPath", "binary", "executable")) {
                if (schemaContains(start.get(), key) && executable != null && !executable.isBlank()) { args.put(key, executable); applied = true; break; }
            }
            if (!applied) {
                for (String key : List.of("browser", "channel", "browserName")) {
                    if (schemaContains(start.get(), key)) { args.put(key, config.getBrowserId()); applied = true; break; }
                }
            }
            if (!applied) throw new IllegalStateException("Selected browser '" + config.getBrowserName() + "' is installed, but this Vibium MCP version does not expose browser/channel/executablePath in browser_start. Select Vibium Managed Chrome for Testing.");
        }
        JsonNode result = mcp.callTool(start.get().getName(), args);
        assertMcpToolSuccess(start.get().getName(), result);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult out = new ScenarioResult();
        out.setId(scenario.getId());
        out.setName(scenario.getName());
        out.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        out.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (notBlank(out.getUrl())) steps.add("Navigate to " + out.getUrl());
        steps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) steps.add("Verify " + applyData(scenario.getExpected(), scenario.getData()) + " is displayed");

        boolean failed = false;
        int stepNo = 1;
        for (String raw : steps) {
            StepResult sr = executeStep(mcp, catalog, scenario, config, raw, stepNo, screenshotDir);
            out.getSteps().add(sr);
            if (!"PASSED".equals(sr.getStatus())) {
                failed = true;
                out.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        out.setStatus(failed ? "FAILED" : "PASSED");
        out.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return out;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String instruction = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(instruction);

        String beforeFingerprint = "";
        String beforeShot = "";
        try {
            beforeFingerprint = pageFingerprint(mcp, catalog);
            if (config.isStrictEvidence() && requiresPostEvidence(expectedIntent(instruction))) {
                beforeShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_before");
            }
            PlannedStep plan = planStep(mcp, catalog, instruction, scenario, config, null);
            sr.setPlanSource(plan.source());
            sr.setActionJson(plan.plan().toString());
            sr.setPageInventory(plan.observation() == null ? "" : compact(plan.observation().toString(), 60000));
            executeValidatedPlan(mcp, catalog, plan.plan(), sr, instruction, config, plan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
            sr.setStatus("PASSED");
            if (shouldScreenshot(config, true) && (sr.getScreenshot() == null || sr.getScreenshot().isBlank())) {
                sr.setScreenshot(captureScreenshot(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } catch (Exception first) {
            Exception finalError = first;
            for (int retry = 0; retry < config.getRetryCount(); retry++) {
                try {
                    Thread.sleep(config.getRetryDelayMs());
                    PlannedStep replan = planStep(mcp, catalog, instruction, scenario, config, finalError.getMessage());
                    sr.setPlanSource(replan.source());
                    sr.setActionJson(replan.plan().toString());
                    sr.setPageInventory(replan.observation() == null ? "" : compact(replan.observation().toString(), 60000));
                    executeValidatedPlan(mcp, catalog, replan.plan(), sr, instruction, config, replan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
                    sr.setStatus("PASSED");
                    finalError = null;
                    break;
                } catch (Exception retryError) {
                    finalError = retryError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } finally {
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config, String failure) throws Exception {
        JsonNode direct = parseDirectJson(instruction);
        if (direct != null) return new PlannedStep("EXPLICIT_JSON", normalizePlan(direct), null);
        if (isNavigate(instruction)) return new PlannedStep("DIRECT_NAVIGATE", directNavigatePlan(catalog, instruction), null);
        if (isWait(instruction)) return new PlannedStep("DIRECT_WAIT", directWaitPlan(catalog), null);

        if (!config.isUseLlm()) {
            throw new IllegalStateException("Natural-language step requires LLM planning in V5 MCP mode. Enable Use LLM or provide explicit JSON MCP calls. Step: " + instruction);
        }
        if (!llmClient.isConfigured(config)) {
            throw new IllegalStateException("LLM Base URL/token/model are required for natural-language UI action planning. Step: " + instruction);
        }

        JsonNode observation = observePage(mcp, catalog);
        String prompt = buildAgentPrompt(instruction, scenario, catalog, observation, failure);
        JsonNode planned = mapper.readTree(llmClient.planMcpCall(prompt, config));
        return new PlannedStep("LLM_MAP_DOM_CLOSED_LOOP", normalizePlan(planned), observation);
    }

    private JsonNode observePage(McpClient mcp, McpToolCatalog catalog) {
        ObjectNode out = mapper.createObjectNode();
        out.set("url", safeToolResult(mcp, catalog.urlTool(), Map.of()));
        out.set("title", safeToolResult(mcp, catalog.titleTool(), Map.of()));
        out.set("text", safeToolResult(mcp, catalog.textTool(), Map.of()));
        out.set("map", safeMap(mcp, catalog));
        out.set("domProbe", safeDomProbe(mcp, catalog));
        return out;
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr,
                                      String instruction, RunConfig config, JsonNode observation, String beforeFingerprint,
                                      String beforeScreenshot, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        JsonNode plan = removeNoOpStart(originalPlan);
        if (plan == null || flattenCalls(plan).isEmpty()) throw new IllegalStateException("No executable MCP tool calls returned. Plan=" + originalPlan);
        String expectedIntent = expectedIntent(instruction);
        if (requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner did not return a real MCP action for instruction='" + instruction + "'. Plan=" + originalPlan);
        }

        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> argsList = new ArrayList<>();
        List<String> results = new ArrayList<>();
        boolean executedAction = false;

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;
            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            Map<String, Object> args = normalizeArgsForTool(tool, call.path("arguments"));
            JsonNode result = mcp.callTool(tool.getName(), args);
            assertMcpToolSuccess(tool.getName(), result);
            tools.add(tool.getName());
            argsList.add(args);
            results.add(compact(result.toString(), 4000));
            if (!isNoOpTool(tool.getName())) executedAction = true;
            if (isActionTool(tool.getName())) {
                sleep(250);
            }
        }

        sr.setToolName(String.join(" → ", tools));
        sr.setToolArguments(mapper.writeValueAsString(argsList));
        sr.setMcpResult(String.join("\n---\n", results));

        String afterScreenshot = shouldScreenshot(config, true) ? captureScreenshotQuietly(mcp, catalog, screenshotDir, scenarioId, String.valueOf(stepNo)) : "";
        if (notBlank(afterScreenshot)) sr.setScreenshot(afterScreenshot);

        JsonNode afterObservation = observePage(mcp, catalog);
        if (isAssert(expectedIntent)) {
            assertInstruction(instruction, sr.getMcpResult(), afterObservation);
            sr.setEvidence("Assertion validated against Vibium map/text/DOM probe.");
        } else if (config.isStrictEvidence() && executedAction && requiresPostEvidence(expectedIntent)) {
            String afterFingerprint = pageFingerprint(mcp, catalog);
            boolean changed = !Objects.equals(beforeFingerprint, afterFingerprint);
            boolean screenshotChanged = screenshotsDifferent(screenshotDir, beforeScreenshot, afterScreenshot);
            if (!changed && !screenshotChanged) {
                throw new IllegalStateException("MCP tool returned success but no DOM/text/URL/screenshot evidence changed. This prevents fake pass. Step='" + instruction + "'. Tools=" + tools + ". Try a more descriptive step or check mcp-transcript.json and screenshots.");
            }
            sr.setEvidence("Closed-loop evidence passed: " + (changed ? "DOM/text/url changed" : "visual screenshot changed") + ".");
        } else {
            sr.setEvidence("MCP tool completed without error; strict visual evidence not required for this step.");
        }
    }

    private Map<String, Object> normalizeArgsForTool(McpTool tool, JsonNode argsNode) {
        Map<String, Object> args = toMap(argsNode);
        if (args.containsKey("selector") && args.get("selector") instanceof Collection<?> c && !c.isEmpty()) {
            args.put("selector", String.valueOf(c.iterator().next()));
        }
        if (!args.containsKey("selector")) {
            for (String k : List.of("ref", "target", "locator")) {
                if (args.containsKey(k) && schemaContains(tool, "selector")) {
                    args.put("selector", args.get(k));
                    break;
                }
            }
        }
        if (schemaContains(tool, "timeout") && !args.containsKey("timeout")) args.put("timeout", 15000);
        return args;
    }

    private String buildAgentPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation, String failure) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the execution brain for ITPS VIBIUM Framework V5. Plan browser actions using Vibium MCP only.\n");
        sb.append("The browser is already started. Never call browser_start.\n");
        sb.append("Instruction: ").append(instruction).append("\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Test data: ").append(mapper.writeValueAsString(scenario.getData())).append("\n");
        sb.append("Critical rules:\n");
        sb.append("- Use the Vibium map refs like @e1/@e2 whenever present. Ref selectors are preferred over text=... selectors.\n");
        sb.append("- Do not guess visible text. If the exact text is not in map/domProbe/text, do not use text=...\n");
        sb.append("- For icons such as search/calendar/filter, prefer @ref from map, aria-label, title, data-testid, role/name, or DOM cssSelector from domProbe.\n");
        sb.append("- For a search flow, return full chain: click search control, fill/type search value, press Enter if needed, click/select result, wait/map.\n");
        sb.append("- If the instruction says click/select a tab/capsule/card, choose the actual mapped interactive element/ref, not plain words.\n");
        sb.append("- For click/fill/select, return at least one real action tool such as browser_click/browser_fill/browser_press/browser_select.\n");
        sb.append("- Return only minified JSON: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{\"selector\":\"@e3\"}}],\"why\":\"reason based on map/domProbe\"}.\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current observation from Vibium MCP map + text + DOM probe:\n").append(compact(observation == null ? "" : observation.toString(), 42000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed: ").append(failure).append("\nReturn a corrected plan using different evidence.\n");
        return sb.toString();
    }

    private JsonNode safeDomProbe(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("note", "No browser_evaluate/eval MCP tool available");
        String script = "(() => {" +
                "const out=[];const seen=new Set();" +
                "const css=(el)=>{try{if(el.id)return '#'+CSS.escape(el.id);if(el.getAttribute&&el.getAttribute('data-testid'))return '[data-testid=\\\"'+el.getAttribute('data-testid')+'\\\"]';if(el.getAttribute&&el.getAttribute('data-test'))return '[data-test=\\\"'+el.getAttribute('data-test')+'\\\"]';let p=[];for(let n=el;n&&n.nodeType===1&&p.length<7;n=n.parentElement){let x=n.tagName.toLowerCase();if(n.getAttribute('name'))x+='[name=\\\"'+n.getAttribute('name')+'\\\"]';else{x+=':nth-of-type('+(Array.from(n.parentElement?.children||[]).filter(v=>v.tagName===n.tagName).indexOf(n)+1)+')';}p.unshift(x);}return p.join(' > ');}catch(e){return ''}};" +
                "const visible=(e)=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>0&&r.height>0&&c.display!=='none'&&c.visibility!=='hidden'}catch(x){return true}};" +
                "const add=(e,scope)=>{if(!e||seen.has(e))return;seen.add(e);const tag=(e.tagName||'').toLowerCase();const text=((e.innerText||e.value||e.textContent||'')+'').trim().replace(/\\s+/g,' ').slice(0,240);out.push({scope,tag,text,id:e.id||'',name:e.getAttribute?.('name')||'',role:e.getAttribute?.('role')||'',type:e.getAttribute?.('type')||'',placeholder:e.getAttribute?.('placeholder')||'',aria:e.getAttribute?.('aria-label')||'',title:e.getAttribute?.('title')||'',testid:e.getAttribute?.('data-testid')||e.getAttribute?.('data-test')||'',value:(e.value||'').toString().slice(0,160),checked:!!e.checked,disabled:!!e.disabled,visible:visible(e),cssSelector:css(e),rect:(()=>{try{const r=e.getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)}}catch(x){return {}}})()});};" +
                "const walk=(root,scope)=>{let all=[];try{all=[...root.querySelectorAll('*')]}catch(e){};for(const e of all){add(e,scope);if(e.shadowRoot)walk(e.shadowRoot,scope+' > shadow('+((e.id||e.tagName||'host'))+')');if(e.tagName==='IFRAME'){try{if(e.contentDocument)walk(e.contentDocument,scope+' > iframe('+((e.name||e.id||'same-origin'))+')')}catch(x){out.push({scope,tag:'iframe',text:'cross-origin iframe not inspectable',cssSelector:css(e)})}}}};" +
                "walk(document,'document');return JSON.stringify({count:out.length,elements:out.slice(0,2500),truncated:out.length>2500});" +
                "})()";
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(eval.get(), "expression")) args.put("expression", script);
        else if (schemaContains(eval.get(), "script")) args.put("script", script);
        else args.put("code", script);
        return safeToolResult(mcp, eval, args);
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> mapTool = catalog.mapTool();
        if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No browser_map/snapshot tool available");
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
        return safeToolResult(mcp, mapTool, args);
    }

    private JsonNode safeToolResult(McpClient mcp, Optional<McpTool> tool, Map<String, Object> args) {
        try {
            if (tool.isEmpty()) return mapper.createObjectNode().put("note", "tool not available");
            return mcp.callTool(tool.get().getName(), args == null ? Map.of() : args);
        } catch (Exception e) {
            return mapper.createObjectNode().put("error", e.getMessage());
        }
    }

    private String pageFingerprint(McpClient mcp, McpToolCatalog catalog) {
        JsonNode obs = observePage(mcp, catalog);
        String text = compact(extractText(obs), 50000);
        return Integer.toHexString(Objects.hash(text));
    }

    private boolean screenshotsDifferent(Path screenshotDir, String before, String after) {
        if (!notBlank(before) || !notBlank(after)) return false;
        try {
            Path b = screenshotDir.resolve(before);
            Path a = screenshotDir.resolve(after);
            if (!Files.exists(b) || !Files.exists(a)) return false;
            byte[] bb = Files.readAllBytes(b);
            byte[] aa = Files.readAllBytes(a);
            return !Arrays.equals(bb, aa);
        } catch (Exception e) { return false; }
    }

    private void assertInstruction(String instruction, String mcpResult, JsonNode observation) {
        String expected = instruction.replaceFirst("(?i)^(verify|assert|check)\\s+", "").trim();
        expected = expected.replaceFirst("(?i)\\s+(is|should be)\\s+(displayed|visible|present).*$", "").trim();
        if (expected.isBlank()) return;
        String haystack = ((mcpResult == null ? "" : mcpResult) + "\n" + (observation == null ? "" : observation.toString())).toLowerCase(Locale.ROOT);
        if (!haystack.contains(expected.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Expected Vibium map/text/DOM to contain: " + expected);
        }
    }

    private void assertMcpToolSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException("MCP tool returned isError=true for " + toolName + ": " + compact(result.toString(), 2000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        String[] fatal = {"element not found", "not found", "timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot", "invalid selector"};
        for (String f : fatal) if (text.contains(f)) throw new IllegalStateException("MCP tool result indicates failure for " + toolName + ": " + compact(text, 2000));
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigation MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\\s+to\\s+", "").trim();
        ArrayNode calls = mapper.createArrayNode();
        calls.add(simpleCall(navigate.getName(), argBySchema(navigate, "url", url, "href")));
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        catalog.waitTool().ifPresent(tool -> calls.add(simpleCall(tool.getName(), Map.of())));
        return plan;
    }

    private JsonNode removeNoOpStart(JsonNode plan) {
        ObjectNode out = mapper.createObjectNode();
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode c : flattenCalls(plan)) {
            String tool = firstText(c, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(c);
        }
        out.set("calls", calls);
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> out = new ArrayList<>();
        if (plan == null || plan.isMissingNode() || plan.isNull()) return out;
        if (plan.has("calls") && plan.path("calls").isArray()) plan.path("calls").forEach(out::add);
        else out.add(plan);
        return out;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode c : flattenCalls(plan)) {
            String t = Optional.ofNullable(firstText(c, "tool", "name", "mcpTool", "toolName")).orElse("").toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go", "open")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "tap", "press", "evaluate")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press", "evaluate")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type", "evaluate")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) { return Set.of("NAVIGATE", "CLICK", "FILL", "SELECT", "ASSERT", "OTHER").contains(intent); }
    private boolean requiresPostEvidence(String intent) { return Set.of("CLICK", "SELECT", "FILL").contains(intent); }
    private boolean isActionTool(String tool) { return containsAny(tool, "click", "fill", "type", "select", "press", "navigate", "evaluate"); }
    private boolean isNoOpTool(String tool) { return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait", "text", "title", "url") && !containsAny(tool, "click", "fill", "type", "navigate", "select", "press", "evaluate"); }
    private boolean isBrowserStart(String tool) { return tool != null && tool.toLowerCase(Locale.ROOT).contains("start"); }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT).trim();
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("click") || l.startsWith("tap") || l.startsWith("open")) return "CLICK";
        if (l.startsWith("enter") || l.startsWith("type") || l.startsWith("fill") || l.startsWith("search for")) return "FILL";
        if (l.startsWith("select") || l.contains("drop down") || l.contains("dropdown")) return "SELECT";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) throws Exception {
        Optional<McpTool> tool = catalog.screenshotTool();
        if (tool.isEmpty()) return "";
        Files.createDirectories(screenshotDir);
        String safeScenario = scenarioId == null ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeStep = stepNo == null ? "step" : stepNo.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + safeStep + ".png";
        Path out = screenshotDir.resolve(fileName).toAbsolutePath();
        long before = System.currentTimeMillis();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool.get(), "path")) args.put("path", out.toString());
        else if (schemaContains(tool.get(), "file")) args.put("file", out.toString());
        else if (schemaContains(tool.get(), "output")) args.put("output", out.toString());
        if (schemaContains(tool.get(), "annotate")) args.put("annotate", true);
        JsonNode result = mcp.callTool(tool.get().getName(), args);
        assertMcpToolSuccess(tool.get().getName(), result);
        if (Files.exists(out) && Files.size(out) > 0) return fileName;
        Optional<byte[]> png = findImageBytes(result);
        if (png.isPresent()) { Files.write(out, png.get()); return fileName; }
        Optional<Path> pathFromResult = findPngPath(result);
        if (pathFromResult.isPresent() && Files.exists(pathFromResult.get())) { Files.copy(pathFromResult.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        Optional<Path> newest = newestPng(screenshotDir, before - 1000);
        if (newest.isPresent()) { Files.copy(newest.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        return "";
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<Path> newestPng(Path dir, long afterMs) {
        try (var stream = Files.list(dir)) {
            return stream.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .filter(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis() >= afterMs; } catch (Exception e) { return false; }
                    })
                    .max(Comparator.comparingLong(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis(); } catch (Exception e) { return 0L; }
                    }));
        } catch (Exception e) { return Optional.empty(); }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(data))); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) { Optional<byte[]> found = findImageBytes(it.next().getValue()); if (found.isPresent()) return found; }
        } else if (node.isArray()) {
            for (JsonNode c : node) { Optional<byte[]> found = findImageBytes(c); if (found.isPresent()) return found; }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(text))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private Optional<Path> findPngPath(JsonNode node) {
        String text = extractText(node);
        Matcher m = Pattern.compile("([A-Za-z]:\\\\[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        m = Pattern.compile("(/[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        return Optional.empty();
    }

    private String cleanBase64(String s) { return s == null ? "" : s.replace("data:image/png;base64,", "").replaceAll("\\s+", ""); }

    private Map<String, Object> toMap(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return new LinkedHashMap<>();
        return mapper.convertValue(n, new TypeReference<Map<String, Object>>() {});
    }

    private Map<String, Object> argBySchema(McpTool tool, String primary, String value, String fallback) {
        Map<String, Object> args = new LinkedHashMap<>();
        args.put(schemaContains(tool, primary) ? primary : fallback, value);
        return args;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode c = mapper.createObjectNode();
        c.put("tool", tool);
        c.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return c;
    }

    private JsonNode normalizePlan(JsonNode plan) {
        if (plan == null) return mapper.createObjectNode();
        if (plan.isArray()) { ObjectNode p = mapper.createObjectNode(); p.set("calls", plan); return p; }
        if (plan.has("tool") || plan.has("calls") || plan.has("name") || plan.has("mcpTool")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step) throws Exception {
        String t = step == null ? "" : step.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null;
        return mapper.readTree(t);
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String out = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{{" + e.getKey() + "}}", value);
            out = out.replace("${" + e.getKey() + "}", value);
        }
        return out;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String t = url.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (!notBlank(base)) return t;
        if (base.endsWith("/") && t.startsWith("/")) return base.substring(0, base.length() - 1) + t;
        if (!base.endsWith("/") && !t.startsWith("/")) return base + "/" + t;
        return base + t;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "ALL" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isTextual()) return node.asText();
        if (node.isNumber() || node.isBoolean()) return node.asText();
        StringBuilder sb = new StringBuilder();
        if (node.isObject()) node.fields().forEachRemaining(e -> sb.append(' ').append(e.getKey()).append(' ').append(extractText(e.getValue())));
        else if (node.isArray()) for (JsonNode c : node) sb.append(' ').append(extractText(c));
        return sb.toString();
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private record PlannedStep(String source, JsonNode plan, JsonNode observation) {}
}
