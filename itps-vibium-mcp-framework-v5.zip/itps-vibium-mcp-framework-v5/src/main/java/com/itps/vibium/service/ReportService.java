package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.zip.*;

@Service
public class ReportService {
    private final ObjectMapper mapper = new ObjectMapper();

    public void writeReports(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("report.json").toFile(), status);
        writeSummaryHtml(status, runDir.resolve("report.html"));
        writeLogsHtml(status, runDir.resolve("logs.html"));
        writeExcel(status, runDir.resolve("report.xlsx"));
        zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip"));
    }

    public void writeFallbackHtml(RunStatus status, Path runDir, Exception error) throws Exception {
        Files.createDirectories(runDir);
        String body = "<h1>Report generation problem</h1><p>Run: " + esc(status == null ? "" : status.getRunId()) + "</p><pre>" + esc(error == null ? "Unknown error" : error.toString()) + "</pre>";
        Files.writeString(runDir.resolve("report.html"), shell("Execution Report", body), StandardCharsets.UTF_8);
        Files.writeString(runDir.resolve("logs.html"), shell("Technical Logs", body), StandardCharsets.UTF_8);
    }

    private void writeSummaryHtml(RunStatus s, Path file) throws Exception {
        StringBuilder rows = new StringBuilder();
        for (ScenarioResult r : s.getScenarios()) {
            rows.append("<tr data-status='").append(esc(r.getStatus())).append("'><td>").append(esc(r.getId())).append("</td><td>")
                    .append(esc(r.getName())).append("</td><td><span class='pill ").append("PASSED".equalsIgnoreCase(r.getStatus()) ? "pass" : "fail")
                    .append("'>").append(esc(r.getStatus())).append("</span></td><td>").append(r.getDurationMs()).append("</td><td>")
                    .append(esc(r.getErrorMessage())).append("</td></tr>");
        }
        String body = header(s, "Consolidated Execution Report") +
                "<section class='filters'><input id='q' placeholder='Filter by test ID, test name, status or error'><select id='statusFilter'><option value=''>All statuses</option><option>PASSED</option><option>FAILED</option></select><a class='btn' href='logs.html'>Open searchable technical logs</a></section>" +
                "<section class='panel'><table id='summary'><thead><tr><th>Test ID</th><th>Test name</th><th>Status</th><th>Duration ms</th><th>Error</th></tr></thead><tbody>" + rows + "</tbody></table></section>" +
                "<section class='links'><a href='report.xlsx'>Excel report</a><a href='report.json'>JSON report</a><a href='screenshots.zip'>Screenshots ZIP</a><a href='mcp-transcript.json'>MCP transcript</a><a href='mcp-process.log'>MCP process log</a></section>" + filterScript("summary");
        Files.writeString(file, shell("ITPS VIBIUM Execution Report", body), StandardCharsets.UTF_8);
    }

    private void writeLogsHtml(RunStatus s, Path file) throws Exception {
        StringBuilder rows = new StringBuilder();
        for (ScenarioResult r : s.getScenarios()) {
            for (StepResult st : r.getSteps()) {
                rows.append("<tr data-status='").append(esc(st.getStatus())).append("'><td>").append(esc(r.getId())).append("</td><td>").append(esc(r.getName())).append("</td><td>")
                        .append(st.getStepNo()).append("</td><td>").append(esc(st.getInstruction())).append("</td><td>").append(esc(st.getPlanSource())).append("</td><td>")
                        .append(esc(st.getToolName())).append("</td><td><pre>").append(esc(st.getToolArguments())).append("</pre></td><td><pre class='inventory'>")
                        .append(esc(st.getPageInventory())).append("</pre></td><td>").append(esc(st.getEvidence())).append("</td><td><span class='pill ")
                        .append("PASSED".equalsIgnoreCase(st.getStatus()) ? "pass" : "fail").append("'>").append(esc(st.getStatus())).append("</span></td><td>")
                        .append(st.getDurationMs()).append("</td><td>").append(shot(st)).append("</td><td>").append(esc(st.getErrorMessage())).append("</td></tr>");
            }
        }
        String body = header(s, "Searchable Technical Logs") +
                "<section class='filters'><input id='q' placeholder='Filter any column: ID, instruction, MCP tool, selector, status, error'><select id='statusFilter'><option value=''>All statuses</option><option>PASSED</option><option>FAILED</option></select><a class='btn' href='report.html'>Back to consolidated report</a></section>" +
                "<section class='panel wide'><table id='logs'><thead><tr><th>Test ID</th><th>Test name</th><th>#</th><th>Instruction</th><th>Plan</th><th>MCP tool</th><th>Arguments</th><th>Page inventory</th><th>Evidence</th><th>Status</th><th>ms</th><th>Screenshot</th><th>Error</th></tr></thead><tbody>" + rows + "</tbody></table></section>" + filterScript("logs");
        Files.writeString(file, shell("ITPS VIBIUM Technical Logs", body), StandardCharsets.UTF_8);
    }

    private String header(RunStatus s, String title) {
        return "<header><div class='brand'>ITPS VIBIUM Framework</div><h1>" + esc(title) + "</h1><p>Run " + esc(s.getRunId()) + " · " + esc(s.getStatus()) + " · " + fmt(s.getStartedAt()) + "</p></header>" +
                "<section class='kpis'><div><span>Total</span><b>" + s.getTotal() + "</b></div><div><span>Passed</span><b>" + s.getPassed() + "</b></div><div><span>Failed</span><b>" + s.getFailed() + "</b></div><div><span>Status</span><b>" + esc(s.getStatus()) + "</b></div></section>";
    }

    private String shell(String title, String body) {
        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>"+esc(title)+"</title><style>" + css() + "</style></head><body><main>" + body + "</main></body></html>";
    }

    private String css() {
        return ":root{--g:#007a53;--d:#003f2d;--bg:#f3f7f5;--line:#d8e5df;--red:#b42318;--ok:#027a48}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Segoe UI,Arial;color:#14251f}main{padding:28px;max-width:1800px;margin:auto}header{background:linear-gradient(135deg,var(--d),var(--g));color:white;padding:25px 28px;border-radius:20px}.brand{font-size:12px;letter-spacing:.18em;text-transform:uppercase}h1{margin:7px 0 3px}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}.kpis div,.panel,.filters,.links{background:white;border:1px solid var(--line);border-radius:15px;padding:15px}.kpis span{display:block;color:#65746f;font-size:12px;text-transform:uppercase}.kpis b{font-size:25px}.filters{display:flex;gap:10px;align-items:center;margin-bottom:15px}.filters input{flex:1;padding:11px;border:1px solid var(--line);border-radius:9px}.filters select,.btn{padding:10px;border:1px solid var(--line);border-radius:9px;background:white}.btn,a{color:var(--g);font-weight:700;text-decoration:none}.panel{overflow:auto;padding:0}.wide{max-height:75vh}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:13px}th{position:sticky;top:0;background:#f8fbfa;z-index:1;font-size:11px;text-transform:uppercase}.pill{padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800}.pass{background:#e7f8ef;color:var(--ok)}.fail{background:#fee4e2;color:var(--red)}pre{white-space:pre-wrap;word-break:break-word;max-width:420px;max-height:180px;overflow:auto;margin:0;font:11px Consolas}.inventory{max-width:520px}.links{display:flex;gap:18px;margin-top:15px}@media(max-width:800px){.kpis{grid-template-columns:1fr 1fr}.filters{flex-direction:column;align-items:stretch}}";
    }

    private String filterScript(String tableId) {
        return "<script>const q=document.getElementById('q'),sf=document.getElementById('statusFilter');function f(){const x=q.value.toLowerCase(),s=sf.value;document.querySelectorAll('#"+tableId+" tbody tr').forEach(r=>{r.style.display=(!x||r.innerText.toLowerCase().includes(x))&&(!s||r.dataset.status===s)?'':'none'})}q.addEventListener('input',f);sf.addEventListener('change',f)</script>";
    }

    private String shot(StepResult st) { return st.getScreenshot() == null || st.getScreenshot().isBlank() ? "" : "<a href='screenshots/"+esc(st.getScreenshot())+"' target='_blank'>view</a>"; }

    private void writeExcel(RunStatus status, Path path) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sh = wb.createSheet("Consolidated Results");
            String[] h = {"Test ID","Test Name","Status","Duration ms","Error"}; Row hr=sh.createRow(0); for(int i=0;i<h.length;i++)hr.createCell(i).setCellValue(h[i]);
            int n=1; for(ScenarioResult r:status.getScenarios()){Row row=sh.createRow(n++);row.createCell(0).setCellValue(r.getId());row.createCell(1).setCellValue(r.getName());row.createCell(2).setCellValue(r.getStatus());row.createCell(3).setCellValue(r.getDurationMs());row.createCell(4).setCellValue(nullSafe(r.getErrorMessage()));}
            Sheet logs=wb.createSheet("Technical Logs"); String[] lh={"Test ID","Test Name","Step","Instruction","Plan","MCP Tool","Arguments","Page Inventory","Evidence","Status","Duration ms","Screenshot","Error"}; Row lhr=logs.createRow(0);for(int i=0;i<lh.length;i++)lhr.createCell(i).setCellValue(lh[i]);n=1;
            for(ScenarioResult r:status.getScenarios())for(StepResult st:r.getSteps()){Row row=logs.createRow(n++);row.createCell(0).setCellValue(r.getId());row.createCell(1).setCellValue(r.getName());row.createCell(2).setCellValue(st.getStepNo());row.createCell(3).setCellValue(nullSafe(st.getInstruction()));row.createCell(4).setCellValue(nullSafe(st.getPlanSource()));row.createCell(5).setCellValue(nullSafe(st.getToolName()));row.createCell(6).setCellValue(nullSafe(st.getToolArguments()));row.createCell(7).setCellValue(excelSafe(st.getPageInventory()));row.createCell(8).setCellValue(nullSafe(st.getEvidence()));row.createCell(9).setCellValue(nullSafe(st.getStatus()));row.createCell(10).setCellValue(st.getDurationMs());row.createCell(11).setCellValue(nullSafe(st.getScreenshot()));row.createCell(12).setCellValue(nullSafe(st.getErrorMessage()));}
            for(int i=0;i<5;i++)sh.autoSizeColumn(i); for(int i=0;i<13;i++)logs.setColumnWidth(i,Math.min(16000, i==7?16000:7000));
            try(OutputStream os=Files.newOutputStream(path)){wb.write(os);}
        }
    }

    private void zipScreenshots(Path dir, Path zip) throws Exception { try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(zip))){if(Files.isDirectory(dir))try(var w=Files.walk(dir)){for(Path p:w.filter(Files::isRegularFile).toList()){z.putNextEntry(new ZipEntry(dir.relativize(p).toString().replace('\\','/')));Files.copy(p,z);z.closeEntry();}}} }
    private String excelSafe(String s){String v=nullSafe(s);return v.length()>32000?v.substring(0,32000):v;} private String fmt(java.time.Instant i){return i==null?"":DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss").withZone(ZoneId.systemDefault()).format(i);} private String nullSafe(String s){return s==null?"":s;} private String esc(String s){return nullSafe(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
}
