const $ = (id) => document.getElementById(id);
let pollHandle = null;
let browsers = [];

async function loadBrowsers(){
  try{
    const r=await fetch('/api/browsers'); browsers=await r.json();
    $('browserId').innerHTML=browsers.filter(b=>b.detected || b.id==='vibium-managed-chrome').map(b=>`<option value="${esc(b.id)}">${esc(b.name)}${b.detected?' · detected':''}</option>`).join('');
    updateBrowserSelection();
  }catch(e){$('browserNote').textContent='Unable to detect browsers: '+e.message;}
}
function updateBrowserSelection(){
  const b=browsers.find(x=>x.id===$('browserId').value)||browsers[0]; if(!b)return;
  $('browserName').value=b.name||''; $('browserExecutable').value=b.executable||'';
  $('browserNote').textContent=(b.executable?`Path: ${b.executable}. `:'')+(b.note||'');
}
$('browserId').addEventListener('change',updateBrowserSelection);
loadBrowsers();

$('scenarioFile').addEventListener('change', () => {
  const file = $('scenarioFile').files[0];
  $('fileName').textContent = file ? `${file.name} (${Math.round(file.size/1024)} KB)` : 'No file selected';
});

$('runBtn').addEventListener('click', async () => {
  const file = $('scenarioFile').files[0];
  if (!file) { setStatus('Please choose an Excel or JSON file.'); return; }
  const form = new FormData(); form.append('scenarioFile', file);
  for (const id of ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','browserId','browserName','browserExecutable','screenshotMode','stepTimeoutSeconds','retryCount']) form.append(id, $(id).value || '');
  for (const id of ['useLlm','headless','continueOnFailure','strictEvidence']) form.append(id, $(id).checked);
  $('runBtn').disabled = true; setStatus('Starting Vibium MCP execution...');
  try { const res=await fetch('/api/runs',{method:'POST',body:form}); const data=await res.json(); if(!res.ok)throw new Error(data.error||'Unable to start run'); renderRun(data); poll(data.runId); }
  catch(e){setStatus(e.message);$('runBtn').disabled=false;}
});
function poll(runId){clearInterval(pollHandle);pollHandle=setInterval(async()=>{const res=await fetch(`/api/runs/${runId}`);const data=await res.json();renderRun(data);if(!['QUEUED','RUNNING'].includes(data.status)){clearInterval(pollHandle);$('runBtn').disabled=false;setStatus('Run completed. Open the consolidated or technical logs report.');}},1800);}
function renderRun(run){window.currentRunId=run.runId;$('resultPanel').classList.remove('hidden');$('runTitle').textContent=`${run.runId} - ${run.status}`;$('runMessage').textContent=run.message||'';$('total').textContent=run.total??0;$('passed').textContent=run.passed??0;$('failed').textContent=run.failed??0;$('status').textContent=run.status||'-';const base=`/api/runs/${run.runId}`;$('htmlReport').href=`${base}/report.html`;$('logsReport').href=`${base}/logs.html`;$('jsonReport').href=`${base}/report.json`;$('excelReport').href=`${base}/report.xlsx`;$('screenshotsZip').href=`${base}/screenshots.zip`;$('mcpTools').href=`${base}/mcp-tools.json`;$('mcpTranscript').href=`${base}/mcp-transcript.json`;$('mcpLog').href=`${base}/mcp-process.log`;$('scenarioResults').innerHTML=(run.scenarios||[]).map(s=>`<tr><td>${esc(s.id)}</td><td>${esc(s.name)}</td><td><span class="pill ${s.status==='PASSED'?'pass':'fail'}">${esc(s.status)}</span></td><td>${s.durationMs||0}</td><td class="err">${esc(s.errorMessage||'')}</td></tr>`).join('');}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function setStatus(t){$('statusLine').textContent=t;}
