# ITPS VIBIUM Framework – MCP Edition V5

Production-oriented Java Spring Boot runner that orchestrates **Vibium MCP only**. There is no Selenium dependency or fallback.

## V5 changes

- Professional UI with a detected-browser selector.
- Consolidated post-run UI and `report.html`: Test ID, Test name, Status, Duration, Error.
- Separate searchable `logs.html` containing every step, MCP tool, arguments, evidence, screenshot and captured page inventory.
- DOM inventory recursively scans the main document, open shadow roots and same-origin iframes, up to 2,500 elements per observation.
- Screenshots can be captured for all steps, failures only or disabled.
- Browser selection is capability-aware: Vibium Managed Chrome for Testing is guaranteed; Chrome/Edge/Chromium are used only when the current Vibium MCP `browser_start` schema exposes a supported browser/channel/executable-path argument. The framework fails clearly rather than silently using another browser.

## Run

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

Configure the MCP command in `src/main/resources/application.properties`:

```properties
itps.vibium.mcp.command=C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
itps.vibium.mcp.args=mcp
```

## Reports

Each run writes under `target/itps-vibium-runs/<run-id>/`:

- `report.html` – consolidated, filterable business report
- `logs.html` – filterable technical logs and page inventory
- `report.xlsx` – two sheets: consolidated results and technical logs
- `report.json`
- `screenshots/` and `screenshots.zip`
- `mcp-tools.json`, `mcp-transcript.json`, `mcp-process.log`

## Element-capture limitation

No browser automation tool can guarantee access to literally every element. Closed shadow roots, cross-origin iframes, canvas-rendered controls and virtualized rows outside the DOM are not fully inspectable. V5 captures all normal DOM elements, open shadow DOM and same-origin iframe elements available to the page, and combines that inventory with Vibium's MCP page map/accessibility information.
