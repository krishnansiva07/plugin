# ELIYA149 — Compilation Hotfix

## Issue reproduced from user Maven screenshot (2026-11-16)

Maven compilation reported three Java errors:

1. `ContextService.java:276` — local variable `budget` already defined in `includeReferences(...)`.
2. `AgentService.java:5307` — non-static `clipHeadTail(String, int, String)` called from static `artifactAnswerFallback(...)`.
3. `AgentService.java:5309` — same static-context call as above.

## Changes

- `ContextService.java`: keep one enclosing reference retrieval `budget` and remove the redundant inner declaration, preserving the 24,000-character limit.
- `AgentService.java`: make `artifactAnswerFallback` an instance method. It is called only by an instance method, and it uses the existing instance `clipHeadTail` logic. No changes to clipping behavior or agent results.
- Added `qa/eliya149-build-hotfix-smoke.sh` to guard these two failure patterns.

## Validation in this environment

- Targeted hotfix smoke: passed.
- Java 17 compiler parser over both changed Java files: passed (syntax only).
- ELIYA149 workspace/alias intent: 34 passed.
- ELIYA146 Planner evidence and ELIYA147/148 outcome regression smokes: passed.
- Available Node test suite: 62 passed, 0 failed.
- Full Maven compilation / executable JAR: **NOT VERIFIED** (Maven and dependencies are unavailable in this environment).

## Validate on Windows

From the unzipped `ELIYA149` directory, run:

```cmd
build-jar-windows.cmd
```

Or:

```cmd
mvn -DskipTests clean package
```

Successful compilation is required before attempting live Analyse/Agent workspace or reference alias acceptance tests.
