const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../../main/resources/static');
test('modern shell assets are loaded after existing application',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 assert.match(html,/modern153\.css\?v=153/);
 assert.match(html,/modern153\.js\?v=153/);
 assert.ok(html.indexOf('/modern153.js')>html.indexOf('/app.js'));
});
test('modern shell has reversible feature flag and legacy escape',()=>{
 const code=fs.readFileSync(path.join(root,'modern153.js'),'utf8');
 assert.match(code,/eliya\.ui\.modern\.enabled/);
 assert.match(code,/classList\.toggle/);
 assert.match(code,/Classic UI/);
 assert.match(code,/Modern UI/);
});
