/* ELIYA153 opt-in, reversible UI layer. Never touches the backend or intercepts chat. */
(function(root){
 'use strict';
 const KEY='eliya.ui.modern.enabled';
 function read(){try{return root.localStorage.getItem(KEY)!=='false';}catch(_){return true;}}
 function write(value){try{root.localStorage.setItem(KEY,String(value));}catch(_){} }
 function initialize(doc){
  if(!doc||!doc.body)return;
  const modern=read(); doc.body.classList.toggle('eliya-modern153',modern);
  const actions=doc.querySelector('.top-actions');
  if(!actions||doc.getElementById('eliya153Toggle'))return;
  const toggle=doc.createElement('button');toggle.type='button';toggle.id='eliya153Toggle';
  toggle.className='eliya153-switch';toggle.title='Switch between modern and legacy layouts';
  function update(){const active=doc.body.classList.contains('eliya-modern153');toggle.textContent=active?'Classic UI':'Modern UI';toggle.setAttribute('aria-pressed',String(active));}
  toggle.addEventListener('click',function(){const active=!doc.body.classList.contains('eliya-modern153');doc.body.classList.toggle('eliya-modern153',active);write(active);update();});
  actions.appendChild(toggle);update();
 }
 const api={initialize};if(typeof module==='object'&&module.exports)module.exports=api;
 if(root&&root.document){if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',()=>initialize(root.document));else initialize(root.document);}
})(typeof window!=='undefined'?window:undefined);
