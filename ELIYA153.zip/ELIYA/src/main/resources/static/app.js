'use strict';

const MAX_AGENT_EVENTS_RETAINED = 5000;
const AGENT_RENDER_THROTTLE_MS = 120;

// Browser storage can be disabled by enterprise/privacy policies. A storage exception used to
// abort app.js during startup, which left model controls empty and every button unwired. Keep a
// small in-memory fallback so the UI remains fully usable even when persistence is unavailable.
const volatileStorage = new Map();
function storageKey(scope, key) { return `${scope}:${key}`; }
function storageGet(scope, key) {
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    const value = store.getItem(key);
    if (value !== null) return value;
  } catch (_) { /* enterprise/private browser may block storage */ }
  return volatileStorage.has(storageKey(scope, key)) ? volatileStorage.get(storageKey(scope, key)) : null;
}
function storageSet(scope, key, value) {
  volatileStorage.set(storageKey(scope, key), String(value));
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    store.setItem(key, String(value));
  } catch (_) { /* memory fallback already holds the value */ }
}
function storageRemove(scope, key) {
  volatileStorage.delete(storageKey(scope, key));
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    store.removeItem(key);
  } catch (_) { /* ignore */ }
}

const DEFAULT_MODEL_CATALOG = [
  { id:'qwen3.8-27b', type:'chat', context:262144 },
  { id:'gpt-oss-120b-ITG', type:'chat', context:131072 },
  { id:'mistral-small-4-ITG', type:'chat', context:262144 },
  { id:'qwen3.6-27b', type:'chat', context:262144 },
  { id:'qwen3.6-35b-a3b', type:'chat', context:262144 },
  { id:'qwen-latest', type:'chat', context:262144 },
  { id:'mistral-medium-2508-ITG', type:'chat', context:128000 },
  { id:'mistral-small-2506-ITG', type:'chat', context:128000 },
  { id:'gemma-4-31b-ITG', type:'chat', context:262144 },
  { id:'mistral-ocr-2512-ITG', type:'ocr', context:128000 },
  { id:'mistral-ocr-4-ITG', type:'ocr', context:128000 },
  { id:'qwen3-embedding-8b', type:'embedding', context:32768 },
  { id:'bge-m3-ITG', type:'embedding', context:8192 },
  { id:'bge-large-en-v1.5-ITG', type:'embedding', context:512 },
  { id:'multilingual-e5-large-ITG', type:'embedding', context:512 }
];

function loadModelCatalog() {
  try {
    const saved = JSON.parse(storageGet('local', 'llm.modelCatalog') || 'null');
    if (Array.isArray(saved) && saved.length) return saved.filter(item => item && String(item.id || '').trim()).map(item => ({
      id:String(item.id).trim(), type:['chat','embedding','vision','ocr'].includes(item.type) ? item.type : 'chat',
      context:Math.max(0, Number(item.context || 0))
    }));
  } catch (_) { /* reset to defaults */ }
  return DEFAULT_MODEL_CATALOG.map(item => ({...item}));
}

function saveModelCatalog() {
  storageSet('local', 'llm.modelCatalog', JSON.stringify(state.modelCatalog));
}

function modelContextWindowsSetting() {
  return state.modelCatalog.filter(item => Number(item.context) > 0).map(item => `${item.id}=${Math.round(Number(item.context))}`).join('\n');
}

function modelTypesSetting() {
  return state.modelCatalog.filter(item => item && item.id).map(item => `${item.id}=${item.type || 'chat'}`).join('\n');
}

function storedSetting(key, defaultValue = '') {
  const value = storageGet('local', key);
  return value === null ? defaultValue : value;
}

const DEFAULT_FALLBACK_MODELS = ''; // optional fallbacks are disabled by default

const EXISTING_PROMPT_LIBRARY = [
  {
    title: 'Write JUnit 5 Tests for Existing Code',
    category: 'Java / JUnit',
    prompt: `Project path: <path>
Target class/package: <class, package or file>

Read the project instructions, pom.xml/build.gradle, target implementation and nearby tests first. Follow the existing JUnit version, mocking library, naming, fixtures and assertion style. Create meaningful JUnit tests for normal paths, boundaries, null/invalid input and important failure paths without changing production behavior just to make tests pass.

Finish all required test-code changes first. Then run one final targeted compile/test command for the affected module or test class, fix any failures caused by the change, rerun, and review the final diff.`
  },
  {
    title: 'Generate JUnit Tests from Requirement',
    category: 'Java / JUnit',
    prompt: `Project path: <path>
Requirement / acceptance criteria: <paste requirement>

Trace the production code that implements this requirement and inspect the repository's existing JUnit conventions. Build a compact coverage map from acceptance criteria to test cases, then add only the required JUnit tests and reusable test data/helpers.

Do not compile after every edit. Complete the coherent test changes first, then run the smallest final compile/test scope that proves the new tests work. Fix failures and rerun until verified or a genuine environment blocker is proven.`
  },
  {
    title: 'Fix an Issue from Error or Stack Trace',
    category: 'Debugging',
    prompt: `Project path: <path>
Error / stack trace / reproduction: <paste here>
Expected behavior: <expected result>

Read project instructions and inspect the exact failing path before editing. Use the error, logs and current code as evidence; identify the first real root cause instead of patching symptoms. Make the smallest maintainable fix and add/update a regression test when practical.

Complete all related edits first. Then run the final targeted compile/test/execution that best reproduces the user's failure, fix any remaining issue, rerun, and review the final diff.`
  },
  {
    title: 'Fix Using a Reference Project',
    category: 'Reference project',
    prompt: `Target project: <target path>
Reference project: <reference path>
Issue / behavior to match: <describe>

Treat the reference project as read-only unless I explicitly say otherwise. Compare the relevant architecture, configuration, implementation and tests. Identify the smallest transferable pattern that fixes the target while respecting the target project's own conventions; do not blindly copy unrelated files or dependencies.

Apply all coherent target-project changes first, then compile/test/execute the target once at final verification based on the requested behavior. Fix failures and rerun as needed.`
  },
  {
    title: 'Migrate Feature from Reference Project',
    category: 'Migration',
    prompt: `Target project: <target path>
Reference/source project: <reference path>
Feature/module to migrate: <feature>

Read instructions and build files in both projects. Treat the source as reference/read-only. Map behavior, public interfaces, dependencies, configuration, tests and data from source to target, then implement the feature using the target project's architecture rather than performing a line-by-line copy.

Complete the migration changes as a coherent set. After all changes are in place, run the target project's final compile/test/execution required by the user, fix failures, rerun, and report any deliberate differences from the source.`
  },
  {
    title: 'Implement or Modify a Feature',
    category: 'Development',
    prompt: `Project path: <path>
Requirement: <paste requirement>

Read project instructions, build configuration, relevant implementation and existing tests. Trace the current design, make the smallest coherent implementation that follows repository conventions, and update focused tests/documentation only where needed.

Batch the implementation edits before verification. Do not compile after each plan step. When all requested changes are complete, run the final compile/test/execution appropriate to the user's request and project type, fix failures, rerun, then review the final diff.`
  },
  {
    title: 'Refactor Without Changing Behavior',
    category: 'Refactoring',
    prompt: `Project path: <path>
Refactor goal/scope: <describe>

Inspect the current design, callers and tests. Preserve observable behavior and public contracts unless I explicitly request an API change. Remove duplication or improve structure only inside the requested scope; avoid speculative cleanup.

Make the full coherent refactor first. Then run the final targeted compile/tests for the affected module, fix regressions, rerun and summarize the structural changes and behavior-preservation evidence.`
  },
  {
    title: 'Summarise a Project or Module',
    category: 'Analysis',
    prompt: `Project path: <path>
Scope: <whole project, module, package or feature>

Read the relevant instructions, build files, entry points, main packages, configuration and representative tests. Produce a concise developer summary covering purpose, architecture, request/data flow, important classes/modules, dependencies, build/run/test commands, extension points, risks and any obvious technical debt. Distinguish confirmed facts from assumptions. Do not modify files unless I explicitly ask.`
  },
  {
    title: 'Review Code and Find Improvement Gaps',
    category: 'Code review',
    prompt: `Project path: <path>
Review scope: <module/files/whole project>

Inspect the current code and tests as a senior developer. Prioritize correctness, reliability, maintainability, security, performance, testability and unnecessary complexity. Give evidence-backed findings with file/class references and severity. If I ask you to implement the improvements, make the coherent changes first and perform one final compile/test verification after the edits are complete.`
  },
  {
    title: 'Playwright MCP + Java Selenium/TestNG/Cucumber',
    category: 'Browser diagnosis',
    prompt: `Workspace [workspace]: configured using Enter path

Keep Java + Selenium + TestNG + Cucumber as the test runner. Read AGENTS.md, relevant .agents/skills/*/SKILL.md, pom.xml, runner, hooks, page objects and .agents/mcp.json first. Determine the active Cucumber tag expression from the framework instead of asking me to repeat it.

Run the smallest affected scope. If browser evidence is required, use Playwright MCP only to inspect the live DOM/accessibility tree, frames, overlays, redirects, visibility and stable locator state. Do not add Playwright to pom.xml just for MCP.

Apply the smallest maintainable Selenium/framework fix, rerun and verify the current revision. If this reveals a reusable convention, update AGENTS.md or a focused .agents/skills/playwright-mcp-testing/SKILL.md without storing secrets or temporary incident details.`
  },
  {
    title: 'Playwright Framework Improvement',
    category: 'Testing',
    prompt: `Workspace [workspace]: configured using Enter path

Read AGENTS.md, relevant skills, package.json, playwright.config.*, fixtures, page/component objects, reporters and CI configuration. Improve this framework for: <goal>.

Prefer Playwright-native auto-waiting, role/test-id locators, fixtures, isolated state and useful failure artifacts. Remove redundant sleeps/retries instead of adding more. Run lint/typecheck if configured plus targeted tests, fix real failures and review the final diff.

Persist only reusable conventions in AGENTS.md or a focused .agents/skills/<name>/SKILL.md.`
  },
  {
    title: 'Migrate Java Selenium to Playwright TypeScript',
    category: 'Migration',
    prompt: `Workspace [workspace]: target configured using Enter path
Reference [<alias>]: read-only Selenium source configured using Reference path

Treat the Selenium source as read-only. Read AGENTS.md and skills in both projects. Map runner/tags, scenarios, page objects, waits, data, auth/session handling, assertions, reports and CI to the target architecture.

Migrate: <feature/module/tag>. Preserve business behavior but do not translate Selenium APIs line by line. Use Playwright-native fixtures, auto-waiting, resilient locators and parallel-safe data. Migrate the requested coherent scope, keep an explicit source-to-target coverage mapping, and defer compile/test execution until the requested migration edits are complete unless an intermediate command is required to resolve a concrete blocker.

Create/update reusable migration guidance in AGENTS.md and .agents/skills/selenium-to-playwright/SKILL.md when useful.`
  },
  {
    title: 'Add Tests to Existing Java Automation Framework',
    category: 'Testing',
    prompt: `Workspace [workspace]: configured using Enter path
Requirement: <paste requirement>

Read AGENTS.md and relevant skills. Inspect the existing Cucumber/TestNG runner, hooks, page objects, step definitions, test-data pattern and reporting. Reuse the framework instead of creating a parallel design.

Add focused business-readable scenarios and only the required implementation. Prefer stable locators and existing abstractions. Run the smallest relevant tag/scope, fix compile/runtime/test failures, then review the final diff. Save reusable testing conventions to AGENTS.md or a focused skill only when they will help future tasks.`
  },
  {
    title: 'Implement a Feature',
    category: 'Development',
    prompt: `Project path: <path>
Feature: <requirement>

Read AGENTS.md, relevant skills, project structure, build configuration and nearest implementation/tests. Trace the current architecture first, reuse established patterns and preserve public behavior outside the requested scope.

Implement the smallest coherent change and add/update focused tests. After all requested edits are complete, run the smallest high-signal final build/test/check, fix failures caused by the change and review the final diff. Do not claim completion without real verification. Record only stable reusable conventions in AGENTS.md or a focused skill.`
  },
  {
    title: 'Diagnose and Fix a Bug',
    category: 'Development',
    prompt: `Project path: <path>
Failure/error: <paste failure or reproduction>

Read AGENTS.md and relevant skills. Reproduce or trace the failure with the smallest relevant command/test and identify the first evidence-backed root cause. Do not patch symptoms blindly.

Implement the smallest correct fix, add a regression test when practical, rerun the failing scope and review the final diff. Continue until verified or a genuine external blocker is proven. Capture a reusable diagnostic convention in AGENTS.md/skills only if it will prevent repeated future work.`
  },
  {
    title: 'Stabilize a Flaky Regression Suite',
    category: 'Testing',
    prompt: `Project path: <path>
Scope/tag: <scope>

Read AGENTS.md, skills, runner, waits, locators, fixtures/hooks, test data, retries, parallel settings and failure artifacts. Run the smallest representative failing scope and classify failures from evidence: product defect, locator, synchronization, shared state/data, environment or framework.

Fix root causes; do not hide failures with arbitrary sleeps, global retries or weaker assertions. Rerun enough to verify the current revision and document only stable anti-flakiness conventions in AGENTS.md or a focused testing skill.`
  },
  {
    title: 'Create AGENTS.md and Reusable Skills',
    category: 'Agent guidance',
    prompt: `Project path: <path>

Analyze the repository deeply. Read existing AGENTS.md, CLAUDE.md, .agents/skills, build/test configuration, architecture docs and representative implementation/tests.

Identify stable architecture boundaries, validated commands, coding/testing conventions, safety constraints and recurring workflows future agents must know. Create or improve a concise root AGENTS.md and only the focused .agents/skills/<name>/SKILL.md files that materially improve future work. Keep them evidence-based, non-duplicative and free of secrets or temporary incident details. Validate the guidance against the repository before finishing.`
  }
];
const PRESENTATION_PROMPTS = [
  {
    title: 'Create Editable PowerPoint from Reference Design and Source Content',
    category: 'Presentation / PowerPoint',
    prompt: `Workspace path: <existing writable output folder>
Reference path: <folder containing design-model .pptx>; alias: SlidesDesign
Design file inside reference: <model.pptx>
Reference path: <folder containing content .docx/.pdf/.md>; alias: SlidesContent
Content file inside reference: <content.docx>
Output file: presentation.pptx
Requested slide count: <number>

Use resource_catalog first to resolve the real aliases. Use presentation_source_extract on SlidesContent (sourceAlias and sourcePath set to the source filename) to read Word/PDF/PPTX/text content; use the existing vision/document analysis workflow when embedded diagrams/images matter. Use presentation_inspect with templateAlias SlidesDesign and templatePath set to the model PPTX filename to inspect reference layouts. Plan a slide-by-slide narrative and map each planned slide to a suitable 1-based templateSlide from the reference. Keep the original theme, branding, layout and relevant decorative components. Do not copy obsolete figures, screenshots, tables or charts from the reference as new facts. Use presentation_create to generate native editable slide text and shapes. If a reference layout is complex or rejected, choose a text-based reference layout instead of silently reusing old data. Run presentation_validate then presentation_preview and inspect every available rendered image for spacing, hierarchy, clipping and fidelity. If preview is unavailable, explicitly report that manual visual review in PowerPoint is required. Deliver the .pptx and its .quality.json report; do not claim visual perfection without inspection. Do not change the source content or reference files.`
  },
  {
    title: 'Validate and Repair an Editable PowerPoint Presentation',
    category: 'Presentation / PowerPoint',
    prompt: `Workspace path: <folder containing the generated presentation>
PowerPoint file: <relative file name>.pptx
Reference path: <optional design reference .pptx>; alias: SlidesDesign

Call presentation_validate on the existing PPTX, then presentation_preview to render slide-by-slide images when LibreOffice is installed. Review readability, completeness, overlap, clipping, margins, colours, fonts, footer consistency and stale reference content. Compare the deck with SlidesDesign through presentation_inspect if supplied. If you must regenerate, preserve the prior output and use a new file name unless I explicitly approve overwriting. Explain any unresolved warnings and whether visual rendering was available.`
  }
];
const CONFLUENCE_PROMPTS = [
  {
    title: 'Create Complete Confluence Documentation from Entire Workspace',
    category: 'Confluence / documentation', mode: 'Agent',
    purpose: 'Agentically inspect an entire codebase and produce traceable Confluence-ready pages.',
    prompt: `Workspace [workspace]: use the selected local writable workspace.
Document scope: entire repository.
Output folder: docs/confluence
Theme: bnp-green

Inventory all modules with documentation_inventory; distinguish indexed, read and verified coverage. Agree on the execution plan, then inspect relevant code, configuration, tests and build/CI definitions in bounded batches using workspace tools and knowledge search. Record file-path and symbol evidence for each documented behavior. Describe overview, architecture, components, data flows, integrations, test framework, configuration, CI/CD, operations and gaps, only where present. Do not invent facts. If the result exceeds a Confluence page, create multiple focused Markdown pages. For each page, write .md then run confluence_compose (sourcePath, outputPath, theme) and confluence_validate. Validate documentation coverage, report any unexamined areas, and return all relative .md/.html paths. Users open an .md through Confluence Composer and click Copy for Confluence. No automatic publication.`
  },
  {
    title: 'Create Confluence Test Execution Report from Workspace Evidence',
    category: 'Confluence / documentation', mode: 'Agent',
    purpose: 'Create an evidence-based test report in paste-ready Confluence format.',
    prompt: `Workspace [workspace]: inspect the relevant existing test reports and results; do not fabricate test totals or statuses.
Input report paths or module: <scope>
Output source: docs/confluence/test-execution.md
Output HTML: docs/confluence/test-execution.html

Produce factual Markdown with scope, environment, run date, passed/failed/skipped counts, failure analysis, risks and source-file evidence. Mark missing data as unavailable; do not guess. Use write to create the Markdown, confluence_compose to generate HTML, then confluence_validate for source-content consistency. Deliver relative paths and disclose any unverified data. Use Confluence Composer to copy and paste; do not publish through MCP.`
  },
  {
    title: 'Format Existing Markdown for Confluence Without Rewriting Facts',
    category: 'Confluence / documentation', mode: 'Agent',
    purpose: 'Apply Confluence-safe structure to an existing Markdown file.',
    prompt: `Workspace [workspace]:
Source file: <docs/source.md>
Output HTML: <docs/confluence/output.html>
Theme: bnp-green

Treat the source Markdown as authoritative. Do not paraphrase, summarize, amend identifiers or alter counts. Call confluence_compose with sourcePath and outputPath; then run confluence_validate using the same source and theme. Report warnings and the result paths. For rich clipboard copy, open the source Markdown using Confluence Composer. Do not edit the source or publish to Confluence.`
  }
];
// Prioritise actionable, task-scoped workflows over generic planning or prompt-engineering entries.
const HIGH_VALUE_PROMPT_TITLES = new Set([
  'Map Repository Architecture and Module Responsibilities',
  'Trace a Request from UI to Database', 'Identify API Endpoints and Their Consumers',
  'Generate Functional Test Cases from Word Section Including Images',
  'Generate Test Cases from PDF with Diagrams', 'Create Requirement-to-Test Traceability Matrix',
  'Diagnose Jenkins Pipeline Test Failures', 'Validate Selenium Grid Connectivity from Jenkins',
  'Generate Parameterized JSON Test Events', 'Check Data Consistency Across Kafka, Flink and Elasticsearch',
  'Create Test Report with Failure Grouping', 'Create Functional Documentation for an Existing Application',
  'Create Detailed Technical Documentation from Code', 'Document APIs with Example Requests and Responses',
  'Build an Incident Root Cause Analysis Report', 'Create a Change Impact and Regression Scope Report',
  'Compare Confluence Design with Current Repository', 'Investigate a Jira Bug Using Workspace Evidence',
  'Prepare Release Test Scope from Jira', 'Create a Source-Cited Analysis Across MCP and Documents'
]);
const ELIYA125_BUILDER_PROMPTS = [
  {
    title: 'Create Custom MCP Server', category: 'Agentic builders', mode: 'Agent',
    purpose: 'Scaffold and verify a custom local MCP stdio server without enabling remote MCP connections.',
    prompt: `Create a custom MCP server called <project-name> inside the currently mapped workspace. Use the mcp_scaffold tool to generate a safe, tested Python 3 starter. Customize tools/list, tool schemas, tools/call, data access and error handling for the business requirements I provide. Keep all credentials in environment variables. Run the generated unittest suite, verify output files and report exact paths. Do NOT connect to or invoke any external MCP server unless I explicitly request that separate action.
Business requirements: <describe MCP tools>`
  },
  {
    title: 'Create Custom RAG Application', category: 'Agentic builders', mode: 'Agent',
    purpose: 'Build a standalone RAG pipeline and validate ingestion, hybrid retrieval and citation behavior.',
    prompt: `Create a standalone RAG application called <project-name> in the mapped workspace. Use rag_scaffold for the initial Python 3 implementation. Customize allowed document types, chunking, incremental reindex, semantic embeddings when explicitly configured, hybrid BM25/vector retrieval and citation-grounded answers for my use case. Include local API and unit tests; verify actual changed and deleted documents are handled. Do not send private documents to a remote provider until credentials and data-owner permission are explicitly configured. Run generated tests, report exact file paths and distinguish offline hashed lexical vectors from real semantic embeddings.
Use case: <describe knowledge sources and query tasks>`
  }
];
const PROMPT_LIBRARY = [...ELIYA_REAL_WORLD_PROMPTS,
  ...ELIYA_PROMPT_CATALOG.filter(item => HIGH_VALUE_PROMPT_TITLES.has(item.title)),
  ...PRESENTATION_PROMPTS, ...CONFLUENCE_PROMPTS, ...ELIYA125_BUILDER_PROMPTS];

// Stable prompt names are deliberately restricted to simple identifiers: easy to type and
// safe to pass to the agent's resource catalog without prompt or alias injection.
function validReferenceName(value) { return typeof value === 'string' && /^[A-Za-z][A-Za-z0-9_-]{0,39}$/.test(value); }
function defaultReferenceName(path) {
  const parts = String(path || '').replace(/[\\/]+$/, '').split(/[\\/]/);
  let name = (parts[parts.length - 1] || 'Reference').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 40);
  if (!/^[A-Za-z]/.test(name)) name = `Ref_${name}`.slice(0, 40);
  return name || 'Reference';
}
function referenceNameInUse(name, currentId = null, path = null) {
  return state.referenceProjects.some(ref => ref.id !== currentId && ref.path !== path && ref.name.toLowerCase() === name.toLowerCase());
}

function loadSharedReferences() {
  try {
    const value = JSON.parse(storageGet('local', 'llm.sharedReferenceProjects') || '[]');
    return Array.isArray(value) ? value.filter(item => item && item.id && item.path).slice(0, 5)
      .map(item => ({...item, name: validReferenceName(item.name) ? item.name : defaultReferenceName(item.path), writable: item.writable === true})) : [];
  } catch (_) { return []; }
}

const state = {
  conversationId: null,
  conversations: [],
  messages: [],
  attachments: [],
  filesById: new Map(),
  uploadingCount: 0,
  project: null,
  projectRootHandle: null,
  projectFallbackFiles: null,
  referenceProjects: loadSharedReferences(),
  workspaceFoldersVisible: storageGet('local', 'llm.workspaceFoldersVisible') === 'true',
  pendingProjectChanges: null,
  mode: 'chat', // Backend mode of the active turn.
  workflowMode: 'analyse', // Explicit user choice: Analyse (read-only) or Agent (execution).
  pendingHandoff: null, // Saved Chat response selected for an explicit, reviewable handoff.
  streaming: false,
  abortController: null,
  activeAgentRunId: null,
  agentWatchTimer: null,
  agentWatchdogCompleted: false,
  agentRenderTimer: null,
  renderTimer: null,
  editingIndex: null,
  historyMenuId: null,
  renameId: null,
  userScrolledUp: false,
  historyLoadSeq: 0,
  visibleMessageStart: 0, // bounded initial DOM; history remains fully available in state/backend
  modelCatalog: loadModelCatalog(),
  mcp: {
    loaded: false,
    name: 'itg-devops',
    enabled: false,
    type: 'remote',
    url: '',
    timeoutMillis: 100000,
    configuredHeaders: []
  },
  config: {
    apiKey: storageGet('session', 'llm.apiKey') || storageGet('local', 'llm.apiKey') || '',
    baseUrl: storageGet('local', 'llm.baseUrl') || '',
    model: storageGet('local', 'llm.model') || '',
    chatModel: storedSetting('llm.chatModel', storageGet('local', 'llm.model') || 'mistral-small-4-ITG'),
    chatModels: storedSetting('llm.chatModels', storedSetting('llm.chatModel', storageGet('local', 'llm.model') || 'mistral-small-4-ITG')),
    visionModel: storageGet('local', 'llm.visionModel') || '',
    chatVisionModel: storageGet('local', 'llm.chatVisionModel') || '',
    visionBaseUrl: storageGet('local', 'llm.visionBaseUrl') || '',
    visionApiKey: storageGet('session', 'llm.visionApiKey') || storageGet('local', 'llm.visionApiKey') || '',
    analysisModel: '',
    plannerModel: '',
    planValidatorModel: '',
    criticModel: '',
    embeddingModel: storedSetting('llm.embeddingModel', 'qwen3-embedding-8b'),
    smartModelRouting: false,
    semanticRetrieval: storageGet('local', 'llm.semanticRetrieval') !== 'false',
    temperature: Number(storageGet('local', 'llm.temperature') || 0.7),
    maxTokens: Number(storageGet('local', 'llm.maxTokens') || 0),
    contextChars: 0,
    contextWindowTokens: Number(storageGet('local', 'llm.contextWindowTokens') || (Number(storageGet('local', 'llm.contextChars') || 0) > 0 ? Math.floor(Number(storageGet('local', 'llm.contextChars')) / 4) : 0)),
    autoCompact: storageGet('local', 'llm.autoCompact') !== 'false',
    compactionKeepTokens: Number(storageGet('local', 'llm.compactionKeepTokens') || 8000),
    compactionBufferTokens: Number(storageGet('local', 'llm.compactionBufferTokens') || 20000),
    oldToolOutputChars: Number(storageGet('local', 'llm.oldToolOutputChars') || 1200),
    systemPrompt: storageGet('local', 'llm.systemPrompt') || '',
    useFileContext: storageGet('local', 'llm.useFileContext') !== 'false',
    agentAllowCommands: storageGet('local', 'llm.agentAllowCommands') !== 'false',
    agentEditPermission: storageGet('local', 'llm.agentEditPermission') || 'allow',
    agentShellPermission: storageGet('local', 'llm.agentShellPermission') || 'allow',
    agentReviewPermission: storageGet('local', 'llm.agentReviewPermission') || storageGet('local', 'llm.agentGitPermission') || 'allow',
    agentMcpPermission: storageGet('local', 'llm.agentMcpPermission') || 'allow',
    agentTaskPermission: storageGet('local', 'llm.agentTaskPermission') || 'allow',
    agentLspPermission: storageGet('local', 'llm.agentLspPermission') || 'allow',
    agentParallelReadTools: storageGet('local', 'llm.agentParallelReadTools') !== 'false',
    agentAutoApprove: storageGet('local', 'llm.agentAutoApprove') !== 'false',
    agentConfirmFileDeletion: storageGet('local', 'llm.agentConfirmFileDeletion') !== 'false',
    agentPlanApproval: false, // Conversational Agent: direct work never waits at a generic plan gate.
    agentFallbackModels: storedSetting('llm.agentFallbackModels', ''),
    agentFallbackEnabled: storageGet('local', 'llm.agentFallbackEnabled') === 'true',
    agentRecoveryAttempts: Math.max(1, Math.min(50, Number(storageGet('local', 'llm.agentRecoveryAttempts') || 3))),
    agentExtraCommands: storageGet('local', 'llm.agentExtraCommands') || '',
    rememberKey: Boolean(storageGet('local', 'llm.apiKey'))
  }
};

const $ = id => document.getElementById(id);
// ELIYA121: one resilient chat composer, transient per-conversation drafts and safe
// read-only previews. Drafts never enter localStorage or backend storage.
const CHAT_UX = window.EliyaChatUiCore;
let chatDraftSaveTimer = null;
let composerPreviewOpen = false;
let codeInspectorSource = null;
let codeInspectorFocusReturn = null;
function chatDraftStorage() {
  try { return window.sessionStorage; } catch (_) { return null; }
}
function saveCurrentChatDraft() {
  if (chatDraftSaveTimer) { clearTimeout(chatDraftSaveTimer); chatDraftSaveTimer = null; }
  const text = $('messageInput')?.value || ''; // Preserve edited handoff instructions too.
  CHAT_UX.saveDraft(chatDraftStorage(), state.conversationId, text);
}
function restoreChatDraft(id) {
  const input = $('messageInput');
  if (!input) return;
  input.value = CHAT_UX.readDraft(chatDraftStorage(), id);
  autoGrow();
}
function refreshChatComposer() {
  const input = $('messageInput');
  if (!input) return;
  const chars = input.value.length;
  if ($('composerCount')) $('composerCount').textContent = `${chars.toLocaleString()} chars`;
  if ($('draftIndicator')) $('draftIndicator').textContent = state.streaming ? 'Running' : chars ? 'Unsaved draft · this tab' : '';
  if ($('clearComposerBtn')) $('clearComposerBtn').disabled = chars === 0 || Boolean(state.streaming);
  if ($('composerPreviewBtn')) $('composerPreviewBtn').disabled = chars === 0;
  if ($('composerModeCaption')) $('composerModeCaption').textContent = state.workflowMode === 'execute'
    ? 'Agent mode · instructions may edit workspace files' : 'Analyse mode · read-only investigation';
  if (composerPreviewOpen && $('composerPreviewContent')) {
    const visible = input.value.slice(0, 100000);
    $('composerPreviewContent').innerHTML = MarkdownRenderer.render(visible) + (input.value.length > visible.length
      ? '<p class="composer-preview-limit">Preview shortened for responsiveness. Full prompt is unchanged.</p>' : '');
  }
}
function chatComposerChanged() {
  refreshChatComposer();
  if (chatDraftSaveTimer) clearTimeout(chatDraftSaveTimer);
  chatDraftSaveTimer = setTimeout(saveCurrentChatDraft, 220);
}
function toggleComposerPreview(force) {
  composerPreviewOpen = typeof force === 'boolean' ? force : !composerPreviewOpen;
  $('composerPreview')?.classList.toggle('hidden', !composerPreviewOpen);
  $('composerPreviewBtn')?.setAttribute('aria-pressed', String(composerPreviewOpen));
  refreshChatComposer();
}
function closeCodeInspector() {
  $('codeInspectorBackdrop')?.classList.add('hidden');
  codeInspectorSource = null;
  if (codeInspectorFocusReturn?.isConnected) codeInspectorFocusReturn.focus();
  codeInspectorFocusReturn = null;
}
function openCodeInspector(block, trigger) {
  if (!block || !$('codeInspectorBackdrop')) return;
  const content = block.querySelector('pre code')?.textContent ?? block.querySelector('code')?.textContent ?? '';
  const language = block.dataset.lang || 'text';
  const extension = block.dataset.ext || 'txt';
  codeInspectorSource = {content,language,extension};
  codeInspectorFocusReturn = trigger || null;
  $('codeInspectorTitle').textContent = language.toUpperCase() + ' · Code viewer';
  $('codeInspectorMeta').textContent = `${content.split('\n').length} lines · ${content.length.toLocaleString()} characters · read only`;
  $('codeInspectorContent').textContent = content;
  $('codeInspectorPre').classList.remove('wrapped');
  $('codeInspectorWrap').setAttribute('aria-pressed','false');
  $('codeInspectorBackdrop').classList.remove('hidden');
  $('codeInspectorClose').focus();
}

const workflowByTab = (() => {
  try { const stored=JSON.parse(storageGet('local','llm.workflowByConversation120') || '{}');
    return stored && typeof stored==='object' && !Array.isArray(stored) ? stored : {};
  } catch (_) { return {}; }
})();
function saveWorkflowChoice() {
  const key=String(state.conversationId || 'draft');
  workflowByTab[key]=state.workflowMode;
  storageSet('local','llm.workflowByConversation120',JSON.stringify(workflowByTab));
}
function clearHandoffNotice({restoreDraft=false}={}) {
  const previous=state.pendingHandoff;
  state.pendingHandoff=null;
  if ($('handoffNotice')) $('handoffNotice').classList.add('hidden');
  if (restoreDraft && previous && previous.conversationId===state.conversationId) {
    $('messageInput').value=previous.previousDraft || '';
    autoGrow();
    $('messageInput').focus();
  }
}
function showHandoffNotice() {
  const banner=$('handoffNotice');
  if (!banner) return;
  const source=state.pendingHandoff;
  banner.classList.toggle('hidden',!source);
  if (source) $('handoffNoticeText').textContent = source.scopeText
    ? `Selected prompt: ${source.title || 'Prompt'} · Analyse #${source.messageId} → Agent · ${state.project?.name || 'current workspace'}. Only this scope is queued. Review, then Send.`
    : `Saved Analyse #${source.messageId} → Agent · ${state.project?.name || 'current workspace'}. Edit the instructions if needed, then press Send. Cancel restores your earlier draft.`;
}
function prepareAnalysisHandoff(index) {
  if (state.streaming) return toast('Finish the current response before handing off');
  const selected=state.messages[Number(index)];
  if (!window.EliyaWorkflowHandoff?.canHandoff?.(selected)) return toast('A saved Analyse response is required');
  if (!state.conversationId) return toast('Open the original conversation before handing off');
  if (!String(selected.content || '').trim()) return toast('The selected analysis has no content');
  const proposed=window.EliyaWorkflowHandoff.makePrompt(selected.id);
  const oldDraft=$('messageInput').value;
  if (oldDraft.trim() && oldDraft.trim()!==proposed.trim() &&
      !confirm('You have an unsent draft. Prepare the Agent handoff instead?\n\nYour draft can be restored with Cancel handoff.')) return;
  const originalDraft=state.pendingHandoff?.previousDraft ?? oldDraft;
  chooseWorkflowMode('execute');
  state.pendingHandoff={conversationId:state.conversationId,messageId:Number(selected.id),
    projectId:state.project?.id||null,previousDraft:originalDraft};
  $('messageInput').value=proposed;
  autoGrow(); showHandoffNotice();
  $('messageInput').focus();
  toast('Agent selected. Review the prepared handoff and press Send to implement.',5500);
}


// ELIYA132: prompt-level handoff, not a whole-analysis handoff.
function prepareScopedPromptHandoff(index, promptNumber) {
  if (state.streaming) return toast('Finish the current response before handing off');
  const selected = state.messages[Number(index)];
  if (!window.EliyaWorkflowHandoff?.canHandoff?.(selected) || !state.conversationId)
    return toast('A completed and saved Analyse prompt is required');
  const question = previousUserMessage(Number(index))?.content || '';
  const prompts = window.EliyaResponseArtifacts.promptSections(question, stripProjectMarkers(selected.content || ''));
  const scope = prompts[Number(promptNumber)];
  if (!scope) return toast('Selected prompt is unavailable');
  if (!scope.ready) return toast('This prompt or prompt set is incomplete. Regenerate the missing sections before implementing.',7000);
  let proposed;
  try { proposed = window.EliyaResponseArtifacts.handoffMessage(selected.id, scope.content, scope.title,
      selected.content || ''); }
  catch (error) { return toast(error.message,7000); }
  const oldDraft = $('messageInput').value;
  if (oldDraft.trim() && oldDraft.trim() !== proposed.trim() &&
      !confirm('You have an unsent draft. Prepare the selected prompt instead?\n\nCancel handoff restores your draft.')) return;
  const originalDraft = state.pendingHandoff?.previousDraft ?? oldDraft;
  chooseWorkflowMode('execute');
  state.pendingHandoff = {conversationId:state.conversationId,messageId:Number(selected.id),
    projectId:state.project?.id||null,previousDraft:originalDraft,
    scopeText:scope.content,title:scope.title,
    scopeReference:proposed.match(/--- BEGIN SELECTED PROMPT SOURCE REFERENCE ---\n[^\n]+\n--- END SELECTED PROMPT SOURCE REFERENCE ---/)?.[0]||''};
  $('messageInput').value = proposed;
  autoGrow(); showHandoffNotice(); $('messageInput').focus();
  toast('Only the selected prompt is prepared for Agent. Review and press Send.',6000);
}

const esc = value => MarkdownRenderer.escapeHtml(value);
// ELIYA88: one browser-like tab strip for independent chat conversations and
// durable Agent sessions. Closing a tab hides it; it never cancels a running task.
const eliyaTabState = { chats: [], active: 'chat:draft' };
try {
  const persisted = JSON.parse(storageGet('local', 'llm.eliyaTabs88') || '[]');
  if (Array.isArray(persisted)) eliyaTabState.chats = persisted.filter(x => typeof x === 'string').slice(-24);
} catch (_) { /* invalid old tab state is harmless */ }
// Execution selection is independent per conversation. Auto chooses OpenCode when
// available, otherwise the original ELIYA agent. This never overrides Analyse.
const eliyaEngineByTab = (() => {
  try { const data = JSON.parse(storageGet('local','llm.executionEngineByTab92') || '{}');
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
  } catch (_) { return {}; }
})();
function engineTabId() { return String(state.conversationId || 'draft'); }
function currentExecutionEngine() {
  // OpenCode paused in ELIYA119. Ignore stale stored per-tab OpenCode selections.
  return 'legacy';
}
function syncExecutionEnginePicker() {
  const selector = $('eliyaExecutionEngine');
  if (selector) selector.value = currentExecutionEngine();
}
$('eliyaExecutionEngine')?.addEventListener('change', event => {
  const choice = String(event.target.value || 'auto');
  if (!['auto','legacy','opencode'].includes(choice)) return;
  eliyaEngineByTab[engineTabId()] = choice;
  storageSet('local','llm.executionEngineByTab92',JSON.stringify(eliyaEngineByTab));
  toast(choice === 'legacy' ? 'This tab will use Eliya for agent actions.' :
    choice === 'opencode' ? (terminalEngineInfo.status === 'unsupported'
      ? 'OpenCode not supported: OpenCode 2 is not installed. Select Eliya or install OpenCode.'
      : 'This tab will use OpenCode for agent actions.') :
    'Auto uses OpenCode when ready; otherwise Eliya.');
});
// An SSE stream is only a view of a durable server-side task. Switching tabs must
// never send a cancellation request. The server keeps running and saves the result.
function detachConversationStreamForTab() {
  stopRecoveringChat();
  if (!state.streaming) {
    // Restored tasks can have a status watcher even without an active SSE request.
    stopAgentWatch();
    state.activeAgentRunId = null;
    return;
  }
  if (state.activeStreamToken) state.activeStreamToken.detached = true;
  stopAgentWatch();
  const controller = state.abortController;
  state.abortController = null;
  state.activeAgentRunId = null;
  state.activeStreamToken = null;
  setStreaming(false);
  // Abort only the browser's streaming HTTP transport. ChatService and the
  // OpenCode bridge intentionally continue execution after SSE disconnect.
  controller?.abort();
}
function persistEliyaTabs() { storageSet('local', 'llm.eliyaTabs88', JSON.stringify(eliyaTabState.chats.slice(-24))); }
function rememberEliyaChat(id) {
  if (!id) return;
  storageSet('session','llm.lastSelectedChat144',String(id));
  // ID only: restoring the tab after a browser restart never resends a prompt.
  storageSet('local','llm.lastSelectedChat145',String(id));
  eliyaTabState.chats = [...eliyaTabState.chats.filter(x => x !== id), id].slice(-24);
  eliyaTabState.active = 'chat:' + id;
  persistEliyaTabs(); renderUnifiedTabs(); syncExecutionEnginePicker();
}
function renderUnifiedTabs() {
  const root = $('unifiedTabs'); if (!root) return;
  const conversations = new Map((state.conversations || []).map(c => [String(c.id), c]));
  const chats = eliyaTabState.chats.filter(id => conversations.has(String(id)) || id === state.conversationId);
  let markup = chats.map(id => {
    const title = conversations.get(String(id))?.title || 'New chat';
    const active = eliyaTabState.active === 'chat:' + id;
    const bg=eliyaTabState.executionIndicators?.[String(id)];
    const badge=bg ? `<small class="eliya-tab-running" title="${bg.running} active Agent/Terminal execution(s) · ${bg.actions} observed tool actions">● ${bg.running}</small>` : '';
    return `<div class="eliya-browser-tab ${active ? 'active' : ''}" role="presentation"><button type="button" role="tab" aria-selected="${active}" data-eliya-chat-tab="${esc(id)}" title="${esc(title)}">✦ <span>${esc(title)}</span>${badge}</button><button type="button" class="eliya-browser-tab-close" data-eliya-close-chat="${esc(id)}" title="Close tab, keep history">×</button></div>`;
  }).join('');
  if (!chats.length) markup += `<div class="eliya-browser-tab active"><button role="tab" aria-selected="true" type="button">✦ <span>New chat</span></button></div>`;
  // Every visible tab is an identical intelligent conversation. Legacy Terminal
  // sessions remain available to the backend for compatibility, never a second UI.
  root.innerHTML = markup;
}
async function openEliyaChatTab(id) {
  detachConversationStreamForTab();
  eliyaTabState.active = 'chat:' + id;
  if (id !== state.conversationId) { await openConversation(id); syncExecutionEnginePicker(); }
  else { renderUnifiedTabs(); syncExecutionEnginePicker(); }
}
$('unifiedNewTab')?.addEventListener('click', async () => {
  detachConversationStreamForTab();
  newChat();
  try { await ensureConversation(); rememberEliyaChat(state.conversationId); syncExecutionEnginePicker(); }
  catch (error) { toast('New tab: ' + error.message, 5000); }
});
$('unifiedTabs')?.addEventListener('click', async event => {
  const closeChat = event.target.closest('[data-eliya-close-chat]');
  if (closeChat) {
    if (state.streaming && closeChat.dataset.eliyaCloseChat === state.conversationId) detachConversationStreamForTab();
    const id = closeChat.dataset.eliyaCloseChat;
    eliyaTabState.chats = eliyaTabState.chats.filter(x => x !== id); persistEliyaTabs();
    if (eliyaTabState.active === 'chat:' + id) {
      const next = eliyaTabState.chats[eliyaTabState.chats.length-1];
      if (next) await openEliyaChatTab(next); else { newChat(); eliyaTabState.active='chat:draft'; }
    }
    renderUnifiedTabs(); return;
  }
  const closeAgent = event.target.closest('[data-eliya-close-agent]');
  if (closeAgent) {
    const id = closeAgent.dataset.eliyaCloseAgent;
    if (id !== 'draft') {
      terminalUi.closedTabs.add(id);
      storageSet('local', 'llm.terminalClosedTabs', JSON.stringify([...terminalUi.closedTabs]));
    }
    closeTerminalDock();
    renderUnifiedTabs();
    toast('Agent tab closed; running work continues in the execution monitor.'); return;
  }
  const chat = event.target.closest('[data-eliya-chat-tab]');
  if (chat) { try { await openEliyaChatTab(chat.dataset.eliyaChatTab); } catch (err) {toast(err.message);} return; }
  const agent = event.target.closest('[data-eliya-agent-tab]');
  if (agent) { terminalUi.selected=agent.dataset.eliyaAgentTab;terminalUi.detail=null;terminalUi.draft=null;openTerminalDock(); }
});


function activeModelForMode() {
  return state.mode === 'chat' ? (state.config.chatModel || state.config.model) : state.config.model;
}

function isConfigured() {
  return Boolean(state.config.apiKey && state.config.baseUrl && activeModelForMode());
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const body = await response.json();
        message = body.message || body.error || message;
      } else {
        const body = await response.text();
        if (body.trim()) message = body.trim().slice(0, 1200);
      }
    } catch (_) { /* ignore parse failure */ }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function mcpHeaderConfigured(name) {
  return (state.mcp.configuredHeaders || []).some(value => String(value).toLowerCase() === String(name).toLowerCase());
}

function setMcpStatus(message, kind = '') {
  const node = $('mcpStatus');
  if (!node) return;
  node.textContent = String(message || '');
  node.classList.remove('connected', 'error');
  if (kind) node.classList.add(kind);
}

function applyMcpConfigView(view) {
  if (!view) return;
  state.mcp = {
    loaded: true,
    name: view.name || 'itg-devops',
    enabled: Boolean(view.enabled),
    type: view.type || 'remote',
    url: view.url || '',
    timeoutMillis: Math.max(1000, Number(view.timeoutMillis || 100000)),
    configuredHeaders: Array.isArray(view.configuredHeaders) ? view.configuredHeaders : []
  };
  if ($('mcpEnabled')) $('mcpEnabled').checked = state.mcp.enabled;
  if ($('mcpName')) $('mcpName').value = state.mcp.name;
  if ($('mcpUrl')) $('mcpUrl').value = state.mcp.url;
  if ($('mcpTimeout')) $('mcpTimeout').value = state.mcp.timeoutMillis;
  const headerInputs = {
    'user-id':'mcpUserId',
    'jira-token':'mcpJiraToken',
    'confluence-token':'mcpConfluenceToken',
    'gitlab-token':'mcpGitlabToken',
    'sonarqube-token':'mcpSonarqubeToken'
  };
  Object.entries(headerInputs).forEach(([header, id]) => {
    const input = $(id);
    if (!input) return;
    input.value = '';
    input.placeholder = mcpHeaderConfigured(header) ? 'Configured · leave blank to keep' : (header === 'user-id' ? 'uid' : 'Not configured');
  });
  const summary = !state.mcp.enabled
    ? 'MCP master OFF · no MCP config discovery, connection, tool listing or action is allowed.'
    : state.mcp.url
      ? `MCP master ON · ${state.mcp.name} · ${state.mcp.configuredHeaders.length} header(s) configured`
      : 'MCP master ON · no manual remote server; enabled workspace/user MCP configurations are allowed.';
  setMcpStatus(summary, state.mcp.enabled && state.mcp.url ? 'connected' : '');
}

async function loadMcpConfig() {
  setMcpStatus('Loading MCP configuration…');
  const view = await api('/api/mcp/config');
  applyMcpConfigView(view);
  return view;
}

function mcpPayloadFromUi() {
  const headers = {};
  const values = {
    'user-id': $('mcpUserId')?.value || '',
    'jira-token': $('mcpJiraToken')?.value || '',
    'confluence-token': $('mcpConfluenceToken')?.value || '',
    'gitlab-token': $('mcpGitlabToken')?.value || '',
    'sonarqube-token': $('mcpSonarqubeToken')?.value || ''
  };
  Object.entries(values).forEach(([name, value]) => { if (String(value).trim()) headers[name] = String(value).trim(); });
  return {
    name: ($('mcpName')?.value || 'itg-devops').trim() || 'itg-devops',
    enabled: Boolean($('mcpEnabled')?.checked),
    url: ($('mcpUrl')?.value || '').trim(),
    timeoutMillis: Math.max(1000, Math.min(1800000, Number($('mcpTimeout')?.value || 100000))),
    headers
  };
}

async function saveMcpConfigFromUi({quiet = false} = {}) {
  const payload = mcpPayloadFromUi();
  const view = await api('/api/mcp/config', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  applyMcpConfigView(view);
  if (!quiet) toast('MCP configuration saved');
  return view;
}

/** Explicit JSON import never triggers an MCP connection or starts OpenCode. */
async function importOpenCodeConfigFile(file) {
  const status = $('openCodeImportStatus');
  if (!file) return;
  if (file.size > 1_048_576) throw new Error('OpenCode JSON must be smaller than 1 MB');
  const raw = await file.text();
  let config;
  try { config = JSON.parse(raw); } catch (_) { throw new Error('OpenCode config must be valid JSON (JSONC comments are not supported by this importer)'); }
  if (!config || Array.isArray(config) || typeof config !== 'object') throw new Error('Expected a JSON configuration object');
  const imported = await api('/api/opencode/config/import', {
    method:'POST', headers:{'Content-Type':'application/json'}, body:raw
  });
  const modelReference = String(config.model || '').trim();
  const providerId = modelReference.includes('/') ? modelReference.split('/')[0] : '';
  const provider = (config.provider || config.providers || {})[providerId] || {};
  const options = provider.options || provider.settings || {};
  const baseUrl = String(options.baseURL || options.baseUrl || '').trim();
  const key = String(options.apiKey || '').trim();
  if (modelReference) {
    // ELIYA uses one selected Agent model per run. Provider prefix is OpenCode's
    // namespace; the upstream model ID is the final component after the first slash.
    const modelId = providerId ? modelReference.substring(providerId.length + 1) : modelReference;
    if ($('modelName')) $('modelName').value = modelId;
    if ($('chatModel')) $('chatModel').value = modelId;
  }
  if (baseUrl && !/\{env:/.test(baseUrl) && $('baseUrl')) $('baseUrl').value = baseUrl;
  // Never inject unresolved secret placeholders into a live model request.
  if (key && !/\{env:/.test(key) && $('apiKey')) $('apiKey').value = key;
  const missing = [];
  if (providerId && !baseUrl) missing.push('provider Base URL');
  if (key.includes('{env:')) missing.push('API key from your environment');
  status.textContent = `Imported ${imported.mcpServers} MCP server(s), ${imported.providers} provider(s)` +
    (imported.selectedModel ? `; model ${imported.selectedModel}` : '') +
    '. Review the model settings and click Save settings to apply them. MCP stays off until explicitly enabled and requested.' +
    (missing.length ? ` Supply ${missing.join(' and ')} manually.` : '');
  status.classList.remove('error');
  status.classList.add('connected');
  toast('OpenCode configuration imported · review and save model settings', 5200);
}
async function loadOpenCodeImportStatus() {
  const status = $('openCodeImportStatus');
  if (!status) return;
  const summary = await api('/api/opencode/config');
  status.textContent = summary.mcpServers || summary.providers || summary.selectedModel
    ? `Saved OpenCode configuration: ${summary.mcpServers} MCP server(s), ${summary.providers} provider(s)` +
      (summary.selectedModel ? `, default ${summary.selectedModel}` : '') + '. MCP still requires explicit permission and request.'
    : 'No OpenCode JSON imported. Import does not enable MCP or execute commands.';
}

/** v125: reviewed learning evidence only. There is no invisible automatic promotion. */
async function loadVerifiedLearning() {
  const status = $('learningStatus');
  const picker = $('learningCandidate');
  const list = $('learningLessons');
  if (!status || !picker || !list) return;
  list.replaceChildren();
  picker.replaceChildren();
  picker.add(new Option('Select a verified Agent run', ''));
  if (!state.project?.localWorkspace || !state.project?.id) {
    status.textContent = 'Select an active local workspace to view verified learning.';
    return;
  }
  const projectId = encodeURIComponent(state.project.id);
  const [candidates, lessons] = await Promise.all([
    api(`/api/learning/candidates?projectId=${projectId}`),
    api(`/api/learning/lessons?projectId=${projectId}`)
  ]);
  for (const candidate of candidates || []) {
    picker.add(new Option(`Verified run ${String(candidate.runId).slice(0, 12)} · ${candidate.verificationAttempts} verifier(s)`, candidate.runId));
  }
  status.textContent = `${(candidates || []).length} verified run(s); ${(lessons || []).length} approved lesson(s). Stale lessons are never injected into the Agent.`;
  for (const lesson of lessons || []) {
    const row = document.createElement('div');
    row.className = 'learning-lesson-row';
    const content = document.createElement('div');
    const header = document.createElement('strong');
    header.textContent = `${lesson.category} · ${lesson.stale ? 'STALE · excluded' : 'Current evidence'}`;
    const body = document.createElement('p');
    body.textContent = String(lesson.summary || '');
    const meta = document.createElement('small');
    meta.textContent = `Sources: ${(lesson.sources || []).join(', ')}`;
    content.append(header, body, meta);
    const remove = document.createElement('button');
    remove.type = 'button'; remove.className = 'secondary-btn danger-outline';
    remove.textContent = 'Revoke';
    remove.onclick = async () => {
      if (!window.confirm('Revoke this approved lesson for this workspace?')) return;
      try {
        await api(`/api/learning/lessons/${encodeURIComponent(lesson.id)}?projectId=${projectId}`, {method:'DELETE'});
        await loadVerifiedLearning(); toast('Approved lesson revoked');
      } catch (error) { status.textContent = `Revoke failed: ${error.message}`; }
    };
    row.append(content, remove);
    list.append(row);
  }
}

async function approveVerifiedLearning() {
  const status = $('learningStatus');
  if (!state.project?.localWorkspace || !state.project?.id) return toast('Select a local workspace first', 4500);
  const payload = {
    projectId: state.project.id,
    runId: $('learningCandidate')?.value || '',
    category: $('learningCategory')?.value || 'general',
    summary: $('learningSummary')?.value || '',
    sourcePaths: String($('learningSources')?.value || '').split(',').map(v=>v.trim()).filter(Boolean),
    approved: Boolean($('learningApproved')?.checked)
  };
  if (!payload.approved || !payload.runId || !payload.sourcePaths.length) {
    if (status) status.textContent = 'Select a verified run, include evidence source paths and tick explicit approval.';
    return;
  }
  try {
    await api('/api/learning/lessons', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    if ($('learningSummary')) $('learningSummary').value = '';
    if ($('learningSources')) $('learningSources').value = '';
    if ($('learningApproved')) $('learningApproved').checked = false;
    await loadVerifiedLearning();
    toast('Lesson saved with verified source fingerprints', 4800);
  } catch (error) { if (status) status.textContent = `Learning not saved: ${error.message}`; }
}

async function testMcpConnection() {
  const button = $('testMcpConnection');
  if (button) button.disabled = true;
  try {
    await saveMcpConfigFromUi({quiet:true});
    setMcpStatus('Connecting to MCP server and discovering tools…');
    const result = await api('/api/mcp/test', {method:'POST'});
    if (result.connected) {
      const toolPreview = (result.tools || []).slice(0, 18);
      const more = Number(result.toolCount || 0) > toolPreview.length ? `\n… +${Number(result.toolCount) - toolPreview.length} more` : '';
      const chatCount = Number(result.chatReadToolCount || 0);
      const chatPreview = (result.chatReadTools || []).slice(0, 12);
      setMcpStatus(`Server connected ✓\nTotal MCP methods: ${result.toolCount || 0}\nAutomatic read/search methods: ${chatCount}${chatPreview.length ? `\n${chatPreview.join(', ')}` : ''}${more}\nChat can use other discovered MCP methods when the original user request explicitly asks for that external action.`, 'connected');
      toast(`MCP ready · ${result.toolCount || 0} methods discovered`, 5000);
    } else {
      setMcpStatus(`Connection failed: ${result.message || 'Unknown MCP error'}`, 'error');
      toast('MCP connection failed', 4500);
    }
  } catch (error) {
    setMcpStatus(`Connection failed: ${error.message}`, 'error');
    toast(error.message, 5000);
  } finally {
    if (button) button.disabled = false;
  }
}

async function testEmbeddingModel() {
  const button = $('testEmbeddingModel');
  const status = $('embeddingStatus');
  const apiKey = String($('apiKey')?.value || state.config.apiKey || '').trim();
  const baseUrl = String($('baseUrl')?.value || state.config.baseUrl || '').trim();
  const model = String($('embeddingModel')?.value || state.config.embeddingModel || '').trim();
  if (!apiKey || !baseUrl || !model) return toast('Enter API key, Base URL and embedding model before testing.', 4500);
  if (button) { button.disabled = true; button.textContent = 'Testing…'; }
  if (status) status.textContent = `Testing ${model}…`;
  try {
    const response = await fetch('/api/chat/model-probe', {
      method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`},
      body:JSON.stringify({baseUrl, model, type:'embedding'})
    });
    if (!response.ok) throw new Error(await readHttpError(response));
    const result = await response.json();
    if (status) { status.textContent = `Semantic model ready ✓ · ${model} · ${result.elapsedMs || '?'} ms`; status.classList.add('connected'); status.classList.remove('error'); }
    toast(`${model} ready for semantic retrieval`, 4500);
  } catch (error) {
    if (status) { status.textContent = `Semantic model unavailable · lexical retrieval will continue automatically · ${error.message}`; status.classList.add('error'); status.classList.remove('connected'); }
    toast(`Embedding test failed: ${error.message}`, 5500);
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Test embedding model'; }
  }
}

async function clearMcpConfiguration() {
  if (!window.confirm('Clear the ELIYA-managed MCP URL and saved MCP credentials from this OS user?')) return;
  try {
    await api('/api/mcp/config', {method:'DELETE'});
    await loadMcpConfig();
    setMcpStatus('MCP configuration cleared.');
    toast('MCP configuration cleared');
  } catch (error) {
    setMcpStatus(`Unable to clear MCP configuration: ${error.message}`, 'error');
    toast(error.message, 5000);
  }
}

function toast(text, duration = 2300) {
  const node = $('toast');
  node.textContent = text;
  node.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add('hidden'), duration);
}

// Browser-to-terminal settings bridge. This is a same-origin POST to the running localhost
// server; the API key remains in process memory, not in any terminal config or bridge file.
async function syncTerminalSettings(clear = false) {
  const config = state.config;
  // An additional browser tab with a session-only key may start without credentials.
  // It must not erase the configuration already synced by a different valid tab.
  if (!clear && (!config.apiKey || !config.baseUrl || !config.model)) return;
  const settings = {
    baseUrl: config.baseUrl || '', model: config.model || '',
    chatModel: config.chatModel || config.model || '',
    visionModel: config.visionModel || '', visionBaseUrl: config.visionBaseUrl || '',
    visionApiKey: config.visionApiKey || '',
    temperature: config.temperature, maxTokens: config.maxTokens,
    contextWindowTokens: config.contextWindowTokens,
    modelContextWindows: modelContextWindowsSetting(), modelTypes: modelTypesSetting(),
    embeddingModel: config.embeddingModel || '', semanticRetrieval: Boolean(config.semanticRetrieval),
    systemPrompt: config.systemPrompt || '', useFileContext: config.useFileContext,
    agentAllowCommands: config.agentAllowCommands,
    agentEditPermission: config.agentEditPermission,
    agentShellPermission: config.agentShellPermission,
    agentReviewPermission: config.agentReviewPermission,
    agentMcpPermission: config.agentMcpPermission,
    agentTaskPermission: config.agentTaskPermission,
    agentLspPermission: config.agentLspPermission,
    agentParallelReadTools: config.agentParallelReadTools,
    agentAutoApprove: config.agentAutoApprove,
    agentConfirmFileDeletion: config.agentConfirmFileDeletion,
    agentPlanApproval: false,
    agentFallbackModels: config.agentFallbackEnabled ? currentFallbackModels().join('\n') : '',
    agentRecoveryAttempts: config.agentRecoveryAttempts || 3
  };
  try {
    await fetch('/api/cli/browser-settings', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-Eliya-Local-UI':'settings-sync'},
      body:JSON.stringify({apiKey:config.apiKey || '', settings})
    });
  } catch (_) { /* Browser use must stay functional if terminal bridge is unavailable. */ }
}

function saveConfig() {
  storageSet('local', 'llm.baseUrl', state.config.baseUrl);
  storageSet('local', 'llm.model', state.config.model);
  storageSet('local', 'llm.chatModel', state.config.chatModel || state.config.model || '');
  storageSet('local', 'llm.chatModels', configuredChatModels().join(', '));
  storageSet('local', 'llm.visionModel', state.config.visionModel || '');
  storageSet('local', 'llm.chatVisionModel', state.config.chatVisionModel || '');
  storageSet('local', 'llm.visionBaseUrl', state.config.visionBaseUrl || '');
  // Agent uses one primary model for the whole workflow. Clear legacy per-role routing.
  storageRemove('local', 'llm.analysisModel');
  storageRemove('local', 'llm.plannerModel');
  storageRemove('local', 'llm.planValidatorModel');
  storageRemove('local', 'llm.criticModel');
  storageSet('local', 'llm.embeddingModel', state.config.embeddingModel || '');
  storageSet('local', 'llm.smartModelRouting', 'false');
  storageSet('local', 'llm.semanticRetrieval', String(Boolean(state.config.semanticRetrieval)));
  storageSet('local', 'llm.temperature', String(state.config.temperature));
  storageSet('local', 'llm.maxTokens', String(state.config.maxTokens));
  storageRemove('local', 'llm.contextChars');
  storageSet('local', 'llm.contextWindowTokens', String(state.config.contextWindowTokens));
  storageSet('local', 'llm.autoCompact', String(state.config.autoCompact));
  storageSet('local', 'llm.compactionKeepTokens', String(state.config.compactionKeepTokens));
  storageSet('local', 'llm.compactionBufferTokens', String(state.config.compactionBufferTokens));
  storageSet('local', 'llm.oldToolOutputChars', String(state.config.oldToolOutputChars));
  storageSet('local', 'llm.systemPrompt', state.config.systemPrompt);
  storageSet('local', 'llm.useFileContext', String(state.config.useFileContext));
  storageSet('local', 'llm.agentAllowCommands', String(state.config.agentAllowCommands));
  storageSet('local', 'llm.agentEditPermission', state.config.agentEditPermission);
  storageSet('local', 'llm.agentShellPermission', state.config.agentShellPermission);
  storageSet('local', 'llm.agentReviewPermission', state.config.agentReviewPermission);
  storageSet('local', 'llm.agentMcpPermission', state.config.agentMcpPermission);
  storageSet('local', 'llm.agentTaskPermission', state.config.agentTaskPermission);
  storageSet('local', 'llm.agentLspPermission', state.config.agentLspPermission);
  storageSet('local', 'llm.agentParallelReadTools', String(state.config.agentParallelReadTools));
  storageSet('local', 'llm.agentAutoApprove', String(state.config.agentAutoApprove));
  storageSet('local', 'llm.agentConfirmFileDeletion', String(state.config.agentConfirmFileDeletion));
  storageSet('local', 'llm.agentPlanApproval', String(state.config.agentPlanApproval));
  storageSet('local', 'llm.agentFallbackModels', state.config.agentFallbackModels || '');
  storageSet('local', 'llm.agentFallbackEnabled', String(Boolean(state.config.agentFallbackEnabled && state.config.agentFallbackModels)));
  storageSet('local', 'llm.agentRecoveryAttempts', String(state.config.agentRecoveryAttempts || 3));
  storageSet('local', 'llm.agentExtraCommands', state.config.agentExtraCommands || '');
  storageSet('local', 'llm.mode', state.mode);
  saveModelCatalog();

  if (state.config.rememberKey) {
    storageSet('local', 'llm.apiKey', state.config.apiKey);
    storageRemove('session', 'llm.apiKey');
  } else {
    storageRemove('local', 'llm.apiKey');
    if (state.config.apiKey) storageSet('session', 'llm.apiKey', state.config.apiKey);
    else storageRemove('session', 'llm.apiKey');
  }

  if (state.config.rememberKey) {
    storageSet('local', 'llm.visionApiKey', state.config.visionApiKey || '');
    storageRemove('session', 'llm.visionApiKey');
  } else {
    storageRemove('local', 'llm.visionApiKey');
    storageSet('session', 'llm.visionApiKey', state.config.visionApiKey || '');
  }
  void syncTerminalSettings();
  updateModelBadge();
  updateWelcomeMode();
  if (document.getElementById('attachmentTray')) renderAttachmentTray();
  refreshAgentModelStrip();
  refreshChatModelPicker();
  refreshChatVisionPicker();
}

function syncSettingsUi() {
  $('apiKey').value = state.config.apiKey;
  $('baseUrl').value = state.config.baseUrl;
  $('modelName').value = state.config.model || '';
  if ($('visionModelName')) $('visionModelName').value = state.config.visionModel || '';
  if ($('chatVisionModelName')) $('chatVisionModelName').value = state.config.chatVisionModel || '';
  if ($('visionBaseUrl')) $('visionBaseUrl').value = state.config.visionBaseUrl || '';
  if ($('visionApiKey')) $('visionApiKey').value = state.config.visionApiKey || '';
  if ($('chatModel')) $('chatModel').value = state.config.chatModel || state.config.model || '';
  refreshEditableSettingsModels();
  $('analysisModel').value = state.config.model || '';
  $('plannerModel').value = state.config.model || '';
  $('planValidatorModel').value = state.config.model || '';
  $('criticModel').value = state.config.model || '';
  $('embeddingModel').value = state.config.embeddingModel || '';
  $('smartModelRouting').checked = false;
  $('semanticRetrieval').checked = Boolean(state.config.semanticRetrieval);
  $('temperature').value = state.config.temperature;
  $('maxTokens').value = state.config.maxTokens;
  $('contextWindowTokens').value = state.config.contextWindowTokens;
  $('autoCompact').checked = state.config.autoCompact;
  $('compactionKeepTokens').value = state.config.compactionKeepTokens;
  $('compactionBufferTokens').value = state.config.compactionBufferTokens;
  $('oldToolOutputChars').value = state.config.oldToolOutputChars;
  $('systemPrompt').value = state.config.systemPrompt;
  $('useFileContext').checked = state.config.useFileContext;
  $('agentAllowCommands').checked = state.config.agentAllowCommands;
  $('agentEditPermission').value = state.config.agentEditPermission;
  $('agentShellPermission').value = state.config.agentShellPermission;
  $('agentReviewPermission').value = state.config.agentReviewPermission;
  $('agentMcpPermission').value = state.config.agentMcpPermission;
  $('agentTaskPermission').value = state.config.agentTaskPermission;
  $('agentLspPermission').value = state.config.agentLspPermission;
  $('agentParallelReadTools').checked = state.config.agentParallelReadTools;
  $('agentAutoApprove').checked = state.config.agentAutoApprove;
  $('agentConfirmFileDeletion').checked = state.config.agentConfirmFileDeletion;
  $('agentPlanApproval').checked = state.config.agentPlanApproval;
  $('agentFallbackModels').value = state.config.agentFallbackModels || '';
  if ($('agentFallbackEnabled')) $('agentFallbackEnabled').checked = Boolean(state.config.agentFallbackEnabled);
  renderFallbackModels();
  $('agentRecoveryAttempts').value = 3;
  $('agentExtraCommands').value = state.config.agentExtraCommands || '';
  $('rememberKey').checked = state.config.rememberKey;

  $('homeApiKey').value = state.config.apiKey;
  $('homeBaseUrl').value = state.config.baseUrl;
  $('homeModel').value = state.config.model || '';
  if ($('homeChatModel')) $('homeChatModel').value = configuredChatModels().join(', ');
  $('homeRemember').checked = state.config.rememberKey;
  renderModelCatalog();
}


function parseModelList(value) {
  return String(value || '').split(/[,\n]/).map(item => item.trim()).filter(Boolean);
}

function uniqueModelList(value) {
  const seen = new Set();
  return parseModelList(value).filter(model => {
    const key = model.toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function configuredChatModels() {
  const values = uniqueModelList(state.config.chatModels || state.config.chatModel || '');
  if (!values.length && state.config.chatModel) values.push(state.config.chatModel);
  return values;
}

function configuredAgentModels() {
  return state.config.model ? [state.config.model] : [];
}

function ensureModelsInCatalog(models, type = 'chat') {
  for (const raw of models || []) {
    const id = String(raw || '').trim();
    if (!id) continue;
    const existing = state.modelCatalog.find(item => item.id.toLowerCase() === id.toLowerCase());
    if (!existing) state.modelCatalog.push({id, type, context:0});
  }
}

function applyChatModelsText(value) {
  const models = uniqueModelList(value);
  state.config.chatModels = models.join(', ');
  state.config.chatModel = models[0] || '';
  ensureModelsInCatalog(models, 'chat');
  return models;
}

function applyAgentModelsText(value) {
  const model = String(value || '').trim();
  state.config.model = model;
  ensureModelsInCatalog(model ? [model] : [], 'chat');
  return model ? [model] : [];
}

function fallbackPrimaryModel() {
  const settingsOpen = !$('modalBackdrop')?.classList.contains('hidden');
  return String(settingsOpen ? ($('modelName')?.value || state.config.model || '') : (state.config.model || '')).trim();
}

function currentFallbackModels() {
  const raw = $('agentFallbackModels') ? $('agentFallbackModels').value : state.config.agentFallbackModels;
  const primary = fallbackPrimaryModel().toLowerCase();
  const seen = new Set();
  return parseModelList(raw).filter(model => {
    const key = model.toLowerCase();
    if (!key || key === primary || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 2);
}

function fallbackModelsEnabled() {
  const checkbox = $('agentFallbackEnabled');
  return checkbox ? checkbox.checked : Boolean(state.config.agentFallbackEnabled);
}

function writeFallbackModels(models) {
  const primary = fallbackPrimaryModel().toLowerCase();
  const values = [];
  const seen = new Set();
  for (const raw of models || []) {
    const model = String(raw || '').trim();
    const key = model.toLowerCase();
    if (!model || key === primary || seen.has(key)) continue;
    seen.add(key); values.push(model);
    if (values.length >= 2) break;
  }
  if ($('agentFallbackModels')) $('agentFallbackModels').value = values.join('\n');
  renderFallbackModels();
}

function renderFallbackModels() {
  const list = $('fallbackModelList');
  const select = $('fallbackModelSelect');
  const manager = $('fallbackManager');
  if (!list && !select && !manager) return;
  const enabled = fallbackModelsEnabled();
  if (manager) {
    manager.classList.toggle('hidden', !enabled);
    manager.setAttribute('aria-hidden', enabled ? 'false' : 'true');
  }
  const values = currentFallbackModels();
  if (list) {
    list.innerHTML = values.length ? values.map((model, index) => `<div class="fallback-model-row" data-fallback-index="${index}"><span class="fallback-order">${index + 1}</span><strong>${esc(model)}</strong><div class="fallback-row-actions"><button type="button" class="plan-icon-btn" data-fallback-action="up" title="Move up" aria-label="Move ${esc(model)} up">↑</button><button type="button" class="plan-icon-btn" data-fallback-action="down" title="Move down" aria-label="Move ${esc(model)} down">↓</button><button type="button" class="plan-icon-btn danger" data-fallback-action="remove" title="Remove fallback" aria-label="Remove ${esc(model)} fallback">×</button></div></div>`).join('')
      : '<div class="fallback-model-empty">Fallbacks are optional. Add up to two models.</div>';
  }
  if (select) {
    const used = new Set(values.map(v => v.toLowerCase()));
    const primary = fallbackPrimaryModel().toLowerCase();
    const available = state.modelCatalog.filter(item => item.type === 'chat' && item.id.toLowerCase() !== primary && !used.has(item.id.toLowerCase()));
    const atLimit = values.length >= 2;
    select.innerHTML = !atLimit && available.length
      ? '<option value="">Choose model…</option>' + available.map(item => `<option value="${esc(item.id)}">${esc(item.id)}</option>`).join('')
      : `<option value="">${atLimit ? 'Maximum 2 fallbacks selected' : 'No additional models'}</option>`;
    select.disabled = !enabled || atLimit || !available.length;
    if ($('addFallbackModelBtn')) $('addFallbackModelBtn').disabled = !enabled || atLimit || !available.length;
  }
}

function updateFallbackAt(index, action) {
  const values = currentFallbackModels();
  if (index < 0 || index >= values.length) return;
  if (action === 'remove') values.splice(index, 1);
  else if (action === 'up' && index > 0) [values[index - 1], values[index]] = [values[index], values[index - 1]];
  else if (action === 'down' && index + 1 < values.length) [values[index + 1], values[index]] = [values[index], values[index + 1]];
  writeFallbackModels(values);
}

function configuredModelPool() {
  return configuredAgentModels();
}

function refreshAgentModelStrip() {
  const input = $('agentModelSelect');
  if (!input) return;
  if (document.activeElement !== input) input.value = state.config.model || '';
  input.disabled = state.streaming;
  const vision = $('agentVisionSelect');
  if (vision) {
    if (document.activeElement !== vision) vision.value = state.config.visionModel || '';
    vision.disabled = state.streaming;
  }
}

function chooseAgentVisionModel(selected) {
  const next = String(selected || '').trim();
  state.config.visionModel = next;
  if (next && !state.modelCatalog.some(item => item.id.toLowerCase() === next.toLowerCase()))
    ensureModelsInCatalog([next], 'vision');
  saveConfig();
  syncSettingsUi();
  refreshAgentModelStrip();
  renderAttachmentTray();
  toast(next ? `Agent Vision model: ${next}` : 'Agent Vision disabled');
}

function autoRoleModel(role, pool) {
  const values = pool || configuredModelPool();
  if (role === 'critic' || role === 'validator' || role === 'analysis') return values.find(m => /gpt-oss/i.test(m)) || values.find(m => /qwen3\.8|mistral-small-4/i.test(m)) || '';
  if (role === 'planner') return values.find(m => /gpt-oss|qwen3\.8|mistral-small-4/i.test(m)) || '';
  return '';
}

function shortModel(model) {
  const value = String(model || 'primary');
  return value.length > 24 ? value.slice(0, 22) + '…' : value;
}

function chooseAgentPrimaryModel(selected) {
  const next = String(selected || '').trim();
  if (!next) return;
  state.config.model = next;
  ensureModelsInCatalog([next], 'chat');
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  saveConfig();
  syncSettingsUi();
  refreshAgentModelStrip();
  toast(`Agent model: ${next}`);
  void prewarmOpenCode();
}

function chooseChatModel(selected) {
  const next = String(selected || '').trim();
  if (!next) return;
  const pool = uniqueModelList([next, ...configuredChatModels()].join(','));
  state.config.chatModel = next;
  state.config.chatModels = pool.join(', ');
  ensureModelsInCatalog([next], isVisionCapableModel(next) ? 'vision' : 'chat');
  saveConfig();
  refreshChatModelPicker();
  updateContextBadge();
  renderAttachmentTray();
  toast(`Chat model: ${next}`);
}

function updateModelBadge() {
  const pool = configuredModelPool();
  const active = activeModelForMode();
  $('modelBadge').textContent = active ? `Eliya · ${state.workflowMode === 'execute' ? 'Agent' : 'Analyse'}` : 'Configure Eliya models';
}

function chatCapableModels() {
  return state.modelCatalog.filter(item => ['chat','vision'].includes(item.type));
}

function agentCapableModels() {
  return state.modelCatalog.filter(item => item.type === 'chat');
}

function fillModelSelect(control, models, selected, emptyLabel) {
  if (!control) return;
  const wanted = String(selected || '').trim();
  if (control.tagName !== 'SELECT') {
    if (document.activeElement !== control) control.value = wanted;
    control.placeholder = control.placeholder || emptyLabel || 'Enter model';
    return;
  }
  const values = [...models];
  if (wanted && !values.some(item => item.id.toLowerCase() === wanted.toLowerCase())) {
    values.unshift({id:wanted, type:'chat', context:0});
  }
  control.innerHTML = values.length
    ? values.map(item => `<option value="${esc(item.id)}"${item.id === wanted ? ' selected' : ''}>${esc(item.id)}${isVisionCapableModel(item.id) ? ' · image' : ''}</option>`).join('')
    : `<option value="">${esc(emptyLabel || 'No model configured')}</option>`;
  if (wanted) control.value = wanted;
}

function refreshConfigurationModelSelectors() {
  const chatText = configuredChatModels().join(', ');
  const agentText = state.config.model || '';
  for (const id of ['chatModel','homeChatModel']) {
    const input = $(id);
    if (input && document.activeElement !== input) input.value = chatText;
  }
  if ($('visionModelName') && document.activeElement !== $('visionModelName')) $('visionModelName').value = state.config.visionModel || '';
  if ($('chatVisionModelName') && document.activeElement !== $('chatVisionModelName')) $('chatVisionModelName').value = state.config.chatVisionModel || '';
  for (const id of ['modelName','homeModel']) {
    const input = $(id);
    if (input && document.activeElement !== input) input.value = agentText;
  }
}

function isVisionCapableModel(model) {
  const id = String(model || '').trim().toLowerCase();
  const item = state.modelCatalog.find(entry => String(entry.id).toLowerCase() === id);
  if (item?.type === 'vision') return true;
  return /mistral-small-4|gemma-4|vision|vl|multimodal/i.test(id);
}

function refreshChatModelPicker() {
  const input = $('chatModelSelect');
  if (!input) return;
  if (document.activeElement !== input) input.value = state.config.chatModel || state.config.model || '';
  input.disabled = state.streaming;
}


// ELIYA59: a compact real dropdown plus a plain editable model field.
function refreshEditableSettingsModels() {
  const fields = [
    ['chatModelDropdown','chatModel', false],
    ['agentModelDropdown','modelName', false],
    ['chatVisionDropdown','chatVisionModelName', true],
    ['agentVisionDropdown','visionModelName', true]
  ];
  for (const [selectId,inputId,optional] of fields) {
    const select=$(selectId), input=$(inputId);
    if (!select || !input) continue;
    const active=input.value.trim();
    const catalog=[...new Set([active,...state.modelCatalog.map(m=>m.id)].filter(Boolean))];
    select.replaceChildren(new Option(optional ? 'Off / select model' : 'Select a model', ''));
    for (const value of catalog) select.add(new Option(value,value));
    select.add(new Option('Custom ID (type below)…','__custom__'));
    select.value = active && catalog.includes(active) ? active : '';
  }
}
for (const [selectId,inputId] of [['chatModelDropdown','chatModel'],['agentModelDropdown','modelName'],['chatVisionDropdown','chatVisionModelName'],['agentVisionDropdown','visionModelName']]) {
  $(selectId)?.addEventListener('change',()=>{
    const value=$(selectId).value;
    if (value==='__custom__') {$(inputId).focus();$(inputId).select();}
    else {$(inputId).value=value;}
  });
  $(inputId)?.addEventListener('input',()=>{
    const dropdown=$(selectId);
    dropdown.value=[...dropdown.options].some(o=>o.value===$(inputId).value) ? $(inputId).value : '__custom__';
  });
}
function refreshChatVisionPicker() {
  const picker=$('chatVisionSelect');
  if (!picker) return;
  if (document.activeElement!==picker) picker.value=state.config.chatVisionModel || '';
  picker.disabled=state.streaming;
}
function chooseChatVisionModel(selected) {
  const next=String(selected || '').trim();
  state.config.chatVisionModel=next;
  if (next) ensureModelsInCatalog([next],'vision');
  saveConfig();syncSettingsUi();refreshChatVisionPicker();renderAttachmentTray();
  toast(next ? `Chat Vision: ${next} extracts; Chat model answers` : 'Chat Vision off · direct Chat vision if supported');
}
$('chatVisionSelect')?.addEventListener('change', event=>chooseChatVisionModel(event.target.value));
$('chatVisionSelect')?.addEventListener('keydown', event=>{
  if(event.key==='Enter'){event.preventDefault();chooseChatVisionModel(event.target.value);event.target.blur();}
});
function setMode(mode, persist = true) {
  const next = ['chat', 'agent'].includes(String(mode)) ? String(mode) : 'chat';
  if (state.streaming) return toast('Stop the current response before changing mode');
  if (next === 'agent' && !state.config.visionModel && state.attachments.some(file => String(file.mimeType || '').startsWith('image/'))) return toast('Select an optional Vision model for image-based Execute requests.', 6000);
  state.mode = next;
  // Preserve the user-selected Analyse/Execute control. Internal route changes are per-turn.
  updateModeUi();
}
function chooseWorkflowMode(next) {
  if (state.streaming) return toast('Finish the active response before switching modes');
  if (next !== 'analyse' && next !== 'execute') return;
  state.workflowMode = next;
  state.mode = next === 'execute' ? 'agent' : 'chat';
  saveWorkflowChoice();
  if (next === 'analyse') clearHandoffNotice();
  updateModeUi();
  $('messageInput')?.focus();
}
function updateModeUi() {
  document.querySelectorAll('[data-workflow]').forEach(button => {
    const active = button.dataset.workflow === state.workflowMode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  if ($('modeHint')) $('modeHint').textContent = state.workflowMode === 'execute'
    ? 'Agent · uses live tools and saved analysis; edits require explicit instructions'
    : 'Analyse · read-only investigation, assumptions, questions and implementation plan';
  if ($('messageInput')) $('messageInput').placeholder = state.workflowMode === 'execute'
    ? 'Implement the agreed changes or ask Agent to investigate…'
    : 'Describe a problem, ask a question, or refine an implementation plan…';
  document.body.dataset.chatMode = state.mode;
  document.body.dataset.workflowMode = state.workflowMode;
  document.body.dataset.conversationUi = 'unified';
  if ($('conversationSubline')) $('conversationSubline').textContent = state.workflowMode === 'execute'
    ? 'Agent · implement, run and verify · native Eliya engine'
    : 'Analyse · investigate, clarify and plan · no edits';
  refreshChatComposer();
  updateWorkspaceVisibility();
  // Keep a visible, independently editable Vision model beside the active Chat/Agent model.
  // ELIYA121 hid BOTH vision controls, even when they were configured in Settings.
  for (const [id, visible] of [
    ['agentModelPicker', state.workflowMode === 'execute'],
    ['agentVisionPicker', state.workflowMode === 'execute'],
    ['chatModelPicker', state.workflowMode === 'analyse'],
    ['chatVisionPicker', state.workflowMode === 'analyse']
  ]) {
    $(id)?.classList.toggle('hidden', !visible);
  }
  refreshAgentModelStrip();
  refreshChatModelPicker();
  refreshChatVisionPicker();
  updateModelBadge();
}

function updateWelcomeMode() {
  const setup = document.querySelector('.setup-card');
  const configured = isConfigured();
  setup.classList.toggle('hidden', configured);
  $('welcomeText').textContent = configured
    ? 'Connected. Ask a question, investigate your workspace or request implementation.'
    : 'Connect your endpoint and configure your conversation and execution models.';
}

function updateContextBadge() {
  const chars = state.messages.reduce((sum, item) => sum + String(item.content || '').length, 0);
  const estimatedTokens = Math.ceil(chars / 3);
  const configured = state.config.contextWindowTokens || 0;
  const limit = configured || detectedContextWindow(activeModelForMode());
  $('contextBadge').textContent = limit > 0
    ? `~${formatCompact(estimatedTokens)} / ${formatCompact(limit)} tokens${configured ? '' : ' · auto'}`
    : `~${formatCompact(estimatedTokens)} tokens`;
}

function detectedContextWindow(model) {
  const exact = state.modelCatalog.find(item => String(item.id).toLowerCase() === String(model || '').toLowerCase());
  if (exact && Number(exact.context) > 0) return Number(exact.context);
  const m = String(model || '').toLowerCase();
  if (/mistral-small-4|qwen3\.8|qwen3\.6|qwen-latest|gemma-4-31b/.test(m)) return 262144;
  if (m.includes('gpt-oss')) return 131072;
  if (m.includes('claude')) return 200000;
  if (m.includes('mistral-small-2506') || m.includes('mistral-medium-2508')) return 128000;
  return 128000;
}


function ensureRecommendedModels() {
  const known = new Set(state.modelCatalog.map(item => String(item.id).toLowerCase()));
  for (const item of DEFAULT_MODEL_CATALOG) {
    if (!known.has(item.id.toLowerCase())) state.modelCatalog.push({...item});
  }
  saveModelCatalog();
  renderModelCatalog();
}

function renderModelCatalog() {
  const list = $('modelCatalogList');
  const options = $('modelCatalogOptions');
  const sorted = [...state.modelCatalog].sort((a,b) => a.type.localeCompare(b.type) || a.id.localeCompare(b.id));
  if (options) options.innerHTML = sorted.map(item => `<option value="${esc(item.id)}"></option>`).join('');
  refreshConfigurationModelSelectors();
  refreshChatModelPicker();
  if (!list) return;
  if (!sorted.length) {
    list.innerHTML = '<div class="model-catalog-empty">No models in the library. Add a model below.</div>';
    renderFallbackModels();
    return;
  }
  list.innerHTML = sorted.map(item => `<div class="model-catalog-row" data-model-id="${esc(item.id)}">
      <div class="model-catalog-name"><input data-model-name value="${esc(item.id)}" aria-label="Model ID" title="Edit model ID" /><span>${esc(item.type)}</span></div>
      <select data-model-type aria-label="Type for ${esc(item.id)}">
        ${['chat','vision','embedding','ocr'].map(type => `<option value="${type}"${item.type === type ? ' selected' : ''}>${type === 'chat' ? 'Chat / Agent' : type === 'vision' ? 'Vision (Chat image)' : type[0].toUpperCase()+type.slice(1)}</option>`).join('')}
      </select>
      <input data-model-context type="number" min="0" value="${esc(String(item.context || 0))}" title="Context window tokens; 0 = auto" aria-label="Context window for ${esc(item.id)}" />
      <button type="button" class="secondary-btn compact-btn model-test-btn" data-test-model="${esc(item.id)}" title="Run a lightweight connection probe">Test</button>
      <button type="button" class="plan-icon-btn danger" data-remove-model="${esc(item.id)}" title="Remove model" aria-label="Remove ${esc(item.id)}">×</button>
    </div>`).join('');
  renderFallbackModels();
}

function addModelFromUi() {
  const id = String($('newModelId')?.value || '').trim();
  if (!id) return toast('Enter a model ID');
  if (state.modelCatalog.some(item => item.id.toLowerCase() === id.toLowerCase())) return toast('That model is already in the library');
  const type = String($('newModelType')?.value || 'chat');
  const context = Math.max(0, Number($('newModelContext')?.value || 0));
  state.modelCatalog.push({id, type, context});
  saveModelCatalog(); renderModelCatalog();
  $('newModelId').value = ''; $('newModelContext').value = '';
  toast(`Added ${id}`);
}

async function testModelFromLibrary(id, button) {
  const item = state.modelCatalog.find(entry => entry.id === id);
  if (!item) return;
  // A model reused for Chat/Agent Vision must receive an image probe even if its
  // library type is still "Chat / Agent" from an older configuration.
  const selectedVisionModels = [
    $('chatVisionModelName')?.value, $('visionModelName')?.value,
    state.config.chatVisionModel, state.config.visionModel
  ].map(value => String(value || '').trim().toLowerCase());
  const isVisual = ['vision', 'ocr'].includes(item.type) ||
    selectedVisionModels.includes(String(item.id).toLowerCase());
  // Respect a dedicated Vision provider's endpoint and key when probing Vision models.
  const apiKey = String((isVisual && ($('visionApiKey')?.value || state.config.visionApiKey))
    || $('apiKey')?.value || state.config.apiKey || '').trim();
  const baseUrl = String((isVisual && ($('visionBaseUrl')?.value || state.config.visionBaseUrl))
    || $('baseUrl')?.value || state.config.baseUrl || '').trim();
  if (!apiKey || !baseUrl) return toast('Enter API key and Base URL before testing a model.', 4500);
  const original = button?.textContent || 'Test';
  if (button) { button.disabled = true; button.textContent = 'Testing…'; }
  try {
    const response = await fetch('/api/chat/model-probe', {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`},
      body:JSON.stringify({baseUrl, model:item.id, type:item.type || 'chat'})
    });
    if (!response.ok) throw new Error(await readHttpError(response));
    const result = await response.json();
    toast(`${item.id} ready · ${result.capability || 'connection'} · ${result.elapsedMs || '?'} ms`, 5000);
  } catch (error) {
    toast(`${item.id} test failed: ${error.message}`, 6000);
  } finally {
    if (button) { button.disabled = false; button.textContent = original; }
  }
}

function removeModelFromLibrary(id) {
  const model = String(id || '').trim();
  if (!model) return;
  const executionValues = uniqueModelList($('modelName')?.value || configuredAgentModels().join(','));
  const executionValue = executionValues[0] || state.config.model || '';
  if (executionValue.toLowerCase() === model.toLowerCase()) {
    return toast('Choose another execution model before removing this model.');
  }
  const roleFields = ['chatModel'];
  const assignedRoles = roleFields.filter(field => uniqueModelList($(field)?.value || configuredChatModels().join(',')).some(value => value.toLowerCase() === model.toLowerCase()));
  const fallbackValues = parseModelList($('agentFallbackModels')?.value || state.config.agentFallbackModels || '');
  const inFallback = fallbackValues.some(value => value.toLowerCase() === model.toLowerCase());
  const assignmentText = [...assignedRoles.map(field => field.replace(/Model$/, '')), ...(inFallback ? ['fallback'] : [])];
  if (assignmentText.length && !confirm(`${model} is assigned to ${assignmentText.join(', ')}. Remove it and clear those assignments?`)) return;

  for (const field of assignedRoles) if ($(field)) $(field).value = '';
  const nextFallbacks = fallbackValues.filter(value => value.toLowerCase() !== model.toLowerCase());
  if ($('agentFallbackModels')) $('agentFallbackModels').value = nextFallbacks.join('\n');
  state.modelCatalog = state.modelCatalog.filter(item => item.id.toLowerCase() !== model.toLowerCase());
  saveModelCatalog(); renderModelCatalog();
  toast(`Removed ${model}. Save settings to apply routing changes.`);
}

function updateModelLibraryEntry(id, patch) {
  const item = state.modelCatalog.find(entry => entry.id === id);
  if (!item) return;
  Object.assign(item, patch);
  saveModelCatalog(); renderModelCatalog();
}

function renameModelInLibrary(id, nextId) {
  const oldId = String(id || '').trim();
  const renamed = String(nextId || '').trim();
  if (!oldId || !renamed) { renderModelCatalog(); return toast('Model ID cannot be empty'); }
  if (oldId === renamed) return;
  if (state.modelCatalog.some(item => item.id.toLowerCase() === renamed.toLowerCase() && item.id !== oldId)) {
    renderModelCatalog();
    return toast('That model ID already exists');
  }
  const item = state.modelCatalog.find(entry => entry.id === oldId);
  if (!item) return;
  item.id = renamed;

  const fields = ['chatModel','modelName','homeChatModel','homeModel'];
  for (const field of fields) {
    const input = $(field);
    if (!input) continue;
    const values = uniqueModelList(input.value).map(value => value.toLowerCase() === oldId.toLowerCase() ? renamed : value);
    if (values.length) input.value = values.join(', ');
  }
  const fallbacks = parseModelList($('agentFallbackModels')?.value || state.config.agentFallbackModels || '')
    .map(value => value.toLowerCase() === oldId.toLowerCase() ? renamed : value);
  if ($('agentFallbackModels')) $('agentFallbackModels').value = [...new Set(fallbacks)].join('\n');
  saveModelCatalog(); renderModelCatalog();
  toast(`Renamed ${oldId} to ${renamed}. Save settings to apply routing changes.`);
}

function ensureConfiguredModelsInCatalog() {
  const candidates = [
    ...configuredChatModels().map(id => [id, isVisionCapableModel(id) ? 'vision' : 'chat']),
    ...configuredAgentModels().map(id => [id, 'chat']),
    ...(state.config.visionModel ? [[state.config.visionModel, 'vision']] : [])
  ];
  let changed = false;
  for (const [rawId, type] of candidates) {
    const id = String(rawId || '').trim();
    if (!id || state.modelCatalog.some(item => item.id.toLowerCase() === id.toLowerCase())) continue;
    state.modelCatalog.push({id, type, context:0});
    changed = true;
  }
  if (changed) { saveModelCatalog(); renderModelCatalog(); }
}


function formatCompact(n) {
  const value = Number(n || 0);
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}m`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1)}k`;
  return String(value);
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}

async function loadConversations() {
  state.conversations = await api('/api/conversations');
  renderHistory($('historySearch').value || '');
  renderUnifiedTabs();
}

function renderHistory(filter = '') {
  const q = filter.trim().toLowerCase();
  const list = state.conversations.filter(c => !q || String(c.title || '').toLowerCase().includes(q));
  if (!list.length) {
    $('historyList').innerHTML = `<div class="history-empty">${q ? 'No matching chats' : 'Your chats will appear here'}</div>`;
    return;
  }
  $('historyList').innerHTML = list.map(c => `
    <div class="history-item ${c.id === state.conversationId ? 'active' : ''}" data-id="${esc(c.id)}" title="${esc(c.title)}">
      <span class="history-title">${esc(c.title || 'New chat')}</span>
      <button class="history-menu" type="button" data-menu="${esc(c.id)}" aria-label="Chat options">⋯</button>
    </div>`).join('');
}

function newChat() {
  saveCurrentChatDraft();
  const persistentLocalWorkspace = state.project?.localWorkspace ? state.project : null;
  detachConversationStreamForTab();
  state.activeAgentRunId = null;
  state.conversationId = null;
  state.messages = [];
  state.visibleMessageStart = 0;
  expandedSourceKeys.clear();
  stopRecoveringChat();
  storageRemove('session','llm.lastSelectedChat144');
  storageRemove('local','llm.lastSelectedChat145');
  state.workflowMode = 'analyse';
  state.mode = 'chat';
  delete workflowByTab.draft;
  storageSet('local','llm.workflowByConversation120',JSON.stringify(workflowByTab));
  clearHandoffNotice();
  state.attachments = [];
  state.filesById = new Map();
  state.project = persistentLocalWorkspace;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  state.pendingProjectChanges = null;
  state.editingIndex = null;
  state.userScrolledUp = false;
  $('conversationTitle').textContent = 'New chat';
  $('historySearch').value = '';
  closeHistoryMenu();
  renderHistory();
  renderAttachmentTray();
  renderTerminalAttachments();
  renderProjectBar();
  renderMessages();
  updateModeUi();
  updateWelcomeMode();
  restoreChatDraft(null);
  $('messageInput').focus();
  eliyaTabState.active='chat:draft'; renderUnifiedTabs(); syncExecutionEnginePicker();
}

async function ensureConversation() {
  if (state.conversationId) return state.conversationId;
  const created = await api('/api/conversations', { method: 'POST' });
  CHAT_UX.transferDraft(chatDraftStorage(), null, created.id);
  state.conversationId = created.id;
  if (workflowByTab.draft) { workflowByTab[created.id]=workflowByTab.draft; delete workflowByTab.draft; saveWorkflowChoice(); }
  $('conversationTitle').textContent = created.title || 'New chat';
  await loadConversations();
  rememberEliyaChat(created.id);
  return created.id;
}

async function openConversation(id) {
  saveCurrentChatDraft();
  stopRecoveringChat();
  detachConversationStreamForTab();
  const loadSeq = ++state.historyLoadSeq;
  const previousConversationId = state.conversationId;
  const previousTitle = $('conversationTitle').textContent;
  closeHistoryMenu();
  state.conversationId = id;
  state.editingIndex = null;
  $('conversationTitle').textContent = 'Loading chat…';
  $('messages').innerHTML = '<div class="history-loading"><span class="history-loading-dot"></span>Loading conversation…</div>';

  // Messages are authoritative. Optional attachments/projects/run history must never prevent an old chat from opening.
  let messages = [];
  try { messages = await api(`/api/conversations/${encodeURIComponent(id)}/messages`); }
  catch (error) {
    if (loadSeq === state.historyLoadSeq) {
      state.conversationId = previousConversationId;
      $('conversationTitle').textContent = previousTitle || 'Chat';
      renderMessages();
      renderHistory($('historySearch').value || '');
    }
    throw error;
  }
  const [filesResult, projectsResult, runsResult, openCodeResult] = await Promise.allSettled([
    api(`/api/files?conversationId=${encodeURIComponent(id)}`),
    api(`/api/projects?conversationId=${encodeURIComponent(id)}`),
    api(`/api/agent/conversations/${encodeURIComponent(id)}/runs`),
    Promise.resolve([]) // OpenCode is disabled; do not slow every Chat load with a legacy provider call.
  ]);
  if (loadSeq !== state.historyLoadSeq) return;
  const files = filesResult.status === 'fulfilled' ? filesResult.value : [];
  const projects = projectsResult.status === 'fulfilled' ? projectsResult.value : [];
  const conversationRuns = runsResult.status === 'fulfilled' ? runsResult.value : [];

  // Each conversation retains its own user-selected mode. A new/unknown conversation is read-only by default.
  state.workflowMode = workflowByTab[id] === 'execute' ? 'execute' : 'analyse';
  state.mode = state.workflowMode === 'execute' ? 'agent' : 'chat';
  clearHandoffNotice();
  restoreChatDraft(id);
  state.messages = Array.isArray(messages) ? messages : [];
  loadSourceExpansion(id);
  const pendingWorkbook = activeWorkbookJobs.get(id);
  // The backend persists its final answer. Only revive a pending progress card;
  // never duplicate a completed document-generation message.
  if (pendingWorkbook && ['queued','running'].includes(pendingWorkbook.testCaseJob?.status)) {
    state.messages.push(pendingWorkbook);
  }
  const usedAssistantIds = new Set();
  const assistantKey = message => message?.id != null ? `id:${message.id}` : `idx:${state.messages.indexOf(message)}`;
  const openCodeSessions = openCodeResult.status === 'fulfilled' && Array.isArray(openCodeResult.value)
    ? openCodeResult.value.filter(session => session.engine === 'opencode' && String(session.conversationId) === String(id)) : [];
  const snapshots = [...(Array.isArray(conversationRuns) ? conversationRuns : []), ...openCodeSessions.map(session => ({
    ...session, finalAnswer:session.answer || '', progressPercent:session.progress?.progressPercent, progressPhase:session.progress?.progressPhase,
    progressDetail:session.progress?.progressDetail, progressIndeterminate:session.progress?.indeterminate,
    activityEvents:(session.events||[]).filter(item=>item.type==='agent_step').map(item=>({...item.data,at:session.updatedAt,seq:item.seq})),
    finishedAt:['completed','failed','cancelled','interrupted','stalled'].includes(session.status) ? session.finishedAt || session.updatedAt : null
  }))].sort((a,b) => Date.parse(a.createdAt || '') - Date.parse(b.createdAt || ''));
  for (const runSnapshot of snapshots) {
    if (!runSnapshot?.id) continue;
    let assistant = null;
    if (runSnapshot.assistantMessageId) {
      assistant = state.messages.find(message => String(message.id) === String(runSnapshot.assistantMessageId) && message.role === 'assistant');
    }
    // Backward-compatible recovery for older durable runs written before assistantMessageId was persisted.
    if (!assistant) {
      const created = Date.parse(runSnapshot.createdAt || '');
      assistant = state.messages.find(message => {
        if (message.role !== 'assistant' || usedAssistantIds.has(assistantKey(message))) return false;
        const messageAt = Date.parse(message.createdAt || '');
        return Number.isFinite(created) && Number.isFinite(messageAt) && messageAt >= created;
      });
      // Very old conversations may not have message timestamps. Preserve order rather than dropping run history.
      if (!assistant) assistant = state.messages.find(message => message.role === 'assistant' && !usedAssistantIds.has(assistantKey(message)));
    }
    if (!assistant) {
      const status = String(runSnapshot.status || 'interrupted');
      const syntheticContent = String(runSnapshot.finalAnswer || '').trim()
        || (status === 'failed'
          ? 'Agent run failed before a final response was saved. The persisted execution history is shown below.'
          : status === 'cancelled'
            ? 'Agent run was cancelled before a final response was saved. The persisted execution history is shown below.'
            : 'Agent run ended before a final response was saved. The persisted execution history is shown below.');
      assistant = {
        id: `agent-run-${runSnapshot.id}`,
        role: 'assistant',
        content: syntheticContent,
        createdAt: runSnapshot.createdAt || runSnapshot.finishedAt || new Date().toISOString(),
        attachmentIds: [],
        syntheticAgentRun: true,
        mode: 'agent'
      };
      const created = Date.parse(assistant.createdAt || '');
      let insertAt = state.messages.length;
      if (Number.isFinite(created)) {
        const later = state.messages.findIndex(message => {
          const at = Date.parse(message?.createdAt || '');
          return Number.isFinite(at) && at > created;
        });
        if (later >= 0) insertAt = later;
      }
      state.messages.splice(insertAt, 0, assistant);
    }
    usedAssistantIds.add(assistantKey(assistant));
    assistant.agentRunId = runSnapshot.id;
    assistant.startedAt = runSnapshot.startedAt || runSnapshot.createdAt || assistant.startedAt;
    assistant.finishedAt = runSnapshot.finishedAt || assistant.finishedAt;
    if (runSnapshot.engine === 'opencode') assistant.executionEngine = 'opencode';
    if (runSnapshot.finishedAt && typeof runSnapshot.finalAnswer === 'string' && runSnapshot.finalAnswer.trim()) {
      applyCompletedChatMessage(assistant, {content:runSnapshot.finalAnswer});
    }
    assistant.agentProgress = agentProgressFromSnapshot(runSnapshot, assistant.agentProgress);
    assistant.agentBackendStatus = runSnapshot.status || assistant.agentProgress.status || 'unknown';
    assistant.agentBackendReachable = true;
    assistant.agentBackendPolledAt = new Date().toISOString();
    assistant.agentConnectionStatus = runSnapshot.finishedAt ? 'closed' : 'recovering';
    assistant.agentSteps = Array.isArray(runSnapshot.activityEvents) ? runSnapshot.activityEvents.map(event => ({...event})) : (assistant.agentSteps || []);
    assistant.agentEventTotal = assistant.agentSteps.length;
    assistant.mode = 'agent';
    assistant.streaming = !runSnapshot.finishedAt && ['running','queued','cancelling','waiting_workspace'].includes(runSnapshot.status);
    if (assistant.streaming) {
      // Reconnect only to durable status for either execution engine. The run
      // itself stays on the server; opening the tab never resubmits a prompt.
      state.activeAgentRunId = runSnapshot.id;
      startAgentWatch(runSnapshot.id, assistant, state.messages.indexOf(assistant));
    }
  }
  // Keep the initial DOM bounded even for years of conversation history. Loading
  // older turns is explicit, while all messages remain in state and are exportable.
  state.visibleMessageStart = Math.max(0, state.messages.length - 85);
  // Avoid loading hundreds of old diff reports during history navigation.
  // The newest reports appear automatically; older ones remain available on demand.
  for (const oldRun of snapshots.filter(run => run.finishedAt).slice(-3)) {
    const match = state.messages.find(message => message.agentRunId === oldRun.id);
    if (match) void fetchAgentCompletionReport(match);
  }
  state.filesById = new Map((Array.isArray(files) ? files : []).map(file => [file.id, file]));
  state.attachments = [];
  const conversationProject = Array.isArray(projects) && projects.length ? projects[0] : null;
  // The explicitly selected local workspace is application-level state. Opening an older chat must not
  // silently replace it with that conversation's historical workspace. Only an explicit project path in a
  // new Agent prompt changes the active workspace.
  if (!state.project?.localWorkspace) {
    const rememberedWorkspacePath = storageGet('local', 'llm.activeLocalWorkspacePath');
    await restoreActiveLocalWorkspace();
    if (loadSeq !== state.historyLoadSeq) return;
    // If a persistent path is remembered but its backend record is temporarily unavailable, keep that
    // path authoritative and remap it on the next Agent send instead of adopting an old chat's workspace.
    if (!state.project?.localWorkspace && !rememberedWorkspacePath && conversationProject) {
      state.project = conversationProject;
      if (conversationProject.localWorkspace) {
        rememberActiveLocalWorkspace(conversationProject);
        void api(`/api/projects/${encodeURIComponent(conversationProject.id)}`)
          .then(project => watchFolderIndex(project, false)).catch(() => {});
      }
    }
  }
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  const conversation = state.conversations.find(c => String(c.id) === String(id));
  $('conversationTitle').textContent = conversation?.title || 'Chat';
  rememberEliyaChat(id);
  renderMessages();
  const pendingChat = pendingChatRecovery(id);
  if (pendingChat && window.EliyaChatExperience144?.shouldRecover(pendingChat,state.messages)) {
    const unresolved = {role:'assistant',mode:'chat',content:'',streaming:true,
      recoveringChat:true,chatLoadingStatus:'Checking for saved server response…',
      chatLastProgressAt:Date.now(),startedAt:new Date(pendingChat.createdAt).toISOString()};
    state.messages.push(unresolved);
    renderMessages();
    watchRecoveringChat(id, pendingChat, unresolved);
  } else if (pendingChat) clearPendingChatRecovery(id);
  renderAttachmentTray();
  renderProjectBar();
  updateModeUi();
  renderHistory($('historySearch').value || '');
  $('sidebar').classList.remove('open');
  state.userScrolledUp = false;
  scrollBottom(true);
  if (filesResult.status === 'rejected' || projectsResult.status === 'rejected' || runsResult.status === 'rejected') {
    toast('Chat loaded. Some older workspace/run metadata could not be restored.', 4500);
  }
}

function attachmentHtml(ids) {
  if (!Array.isArray(ids) || !ids.length) return '';
  const cards = ids.map(id => {
    const file = state.filesById.get(id);
    if (!file) return `<span class="message-file"><span class="file-icon">📎</span><span class="file-text"><span class="file-name">Attachment</span></span></span>`;
    const image = String(file.mimeType || '').toLowerCase().startsWith('image/');
    const visual = image
      ? `<img class="attachment-thumb" src="/api/files/${encodeURIComponent(id)}/view" alt="${esc(file.name)}" />`
      : `<span class="file-icon">${fileIcon(file.mimeType, file.name)}</span>`;
    return `<a class="message-file" href="/api/files/${encodeURIComponent(id)}/download" title="Download ${esc(file.name)}">
      ${visual}
      <span class="file-text"><span class="file-name">${esc(file.name)}</span><span class="file-meta">${esc(formatBytes(file.size))}${Number(file.extractedCharacters || 0) > 0 ? ` · ${esc(formatCompact(file.extractedCharacters))} text chars` : ''}</span></span>
    </a>`;
  }).join('');
  return `<div class="attachment-list">${cards}</div>`;
}

function fileIcon(mime, name) {
  const m = String(mime || '').toLowerCase();
  const n = String(name || '').toLowerCase();
  if (m.startsWith('image/')) return '🖼';
  if (m.includes('pdf') || n.endsWith('.pdf')) return 'PDF';
  if (m.includes('spreadsheet') || m.includes('excel') || /\.(xlsx?|csv)$/.test(n)) return 'XLS';
  if (m.includes('word') || /\.docx?$/.test(n)) return 'DOC';
  if (m.includes('presentation') || /\.pptx?$/.test(n)) return 'PPT';
  if (/\.(java|js|ts|py|json|xml|html|css|sql|yml|yaml|sh)$/.test(n)) return '&lt;/&gt;';
  return '📎';
}

function parsePlanTextForUi(text) {
  const lines = String(text || '').split(/\r?\n/);
  const items = [];
  let current = null;
  for (const raw of lines) {
    const line = String(raw || '').trim();
    if (!line) continue;
    const numbered = line.match(/^(\d+)[.)]\s*(?:\[[^\]]+\]\s*)?(.*)$/);
    if (numbered) {
      if (current?.text) items.push(current);
      current = { index: Number(numbered[1]) || items.length + 1, text: numbered[2].replace(/\s+—\s+.*$/, '').trim(), status: 'pending', note: '' };
      continue;
    }
    // Structured planner fields belong to the previous numbered plan step; do not render them as separate steps.
    if (current && /^(Objective|Files|Validate|Depends on|Risk):\s*/i.test(line)) {
      current.text += `\n${line}`;
      continue;
    }
    // Backward-compatible unnumbered plan text: each meaningful line is a step.
    if (current?.text) { items.push(current); current = null; }
    const cleaned = line.replace(/^\[[^\]]+\]\s*/, '').replace(/\s+—\s+.*$/, '').trim();
    if (cleaned) items.push({ index: items.length + 1, text: cleaned, status: 'pending', note: '' });
  }
  if (current?.text) items.push(current);
  return items.map((item, index) => ({...item, index: index + 1}));
}

function structuredPlanStepHtml(text) {
  const lines = String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) return '';
  const title = lines[0];
  const fields = [];
  let objective = '';
  for (const line of lines.slice(1)) {
    const match = line.match(/^(Objective|Files|Validate|Depends on|Risk):\s*(.*)$/i);
    if (!match) { fields.push(['Detail', line]); continue; }
    const label = match[1].toLowerCase();
    const value = match[2];
    if (label === 'objective') objective = value;
    else fields.push([match[1], value]);
  }
  return `<div class="plan-step-structure"><strong class="plan-step-title">${esc(title)}</strong>${objective ? `<span class="plan-step-objective">${esc(objective)}</span>` : ''}${fields.length ? `<div class="plan-step-fields">${fields.map(([label,value]) => `<span class="plan-step-field"><b>${esc(label)}</b><em>${esc(value)}</em></span>`).join('')}</div>` : ''}</div>`;
}

function planEditorHtml(runId, planItems, validationStatus = 'not_run', validationSummary = '') {
  if (!runId || !Array.isArray(planItems) || !planItems.length) return '';
  const rows = planItems.map((item, idx) => {
    const rowCount = Math.max(2, Math.min(7, String(item.text || '').split(/\r?\n/).length));
    return `<div class="plan-edit-row" data-plan-row>
      <label class="plan-select" title="Include this step"><input type="checkbox" data-plan-enabled checked /></label>
      <span class="plan-edit-index">${idx + 1}</span>
      <textarea class="plan-edit-text" rows="${rowCount}" data-plan-text aria-label="Plan step ${idx + 1}">${esc(item.text || '')}</textarea>
      <div class="plan-row-actions"><button type="button" class="plan-icon-btn" data-plan-move="up" title="Move up">↑</button><button type="button" class="plan-icon-btn" data-plan-move="down" title="Move down">↓</button><button type="button" class="plan-icon-btn danger" data-plan-remove title="Remove step">×</button></div>
    </div>`;
  }).join('');
  const approved = String(validationStatus) === 'approved';
  const badge = approved ? 'VALIDATED' : String(validationStatus) === 'needs_review' ? 'REVIEW' : 'DRAFT';
  const validatorNote = validationSummary ? `<div class="plan-quality-inline ${approved ? 'approved' : 'review'}"><span>${approved ? '✓' : '!'}</span><span>${esc(validationSummary)}</span></div>` : '';
  return `<div class="agent-plan-editor" data-plan-editor data-run-id="${esc(runId)}">
      <div class="plan-editor-head"><div><strong>Review execution plan</strong><span>${approved ? 'Independently validated. You can still edit, reorder, add or remove steps.' : 'Edit, reorder, add, remove, or unselect steps before approval.'}</span></div><span class="plan-draft-badge ${approved ? 'validated' : ''}">${badge}</span></div>${validatorNote}
      <div class="plan-edit-list" data-plan-list>${rows}</div>
      <div class="plan-editor-actions"><button type="button" class="secondary-btn" data-plan-add>＋ Add step</button><button type="button" class="secondary-btn" data-plan-save>Save plan</button></div>
    </div>`;
}


function agentStageHtml(progress, waiting) {
  const phase = String(progress?.phase || 'starting').toLowerCase();
  const status = String(progress?.status || 'running').toLowerCase();
  const stages = [
    ['index','Index'], ['analyse','Analyse'], ['plan','Plan'], ['validate','Validate'],
    ['review','Review'], ['execute','Execute'], ['verify','Verify'], ['complete','Complete']
  ];
  let active = 0;
  if (phase.includes('index')) active = 0;
  else if (phase.includes('analys')) active = 1;
  else if (phase.includes('plan_validation')) active = 3;
  else if (phase.includes('plan_review') || waiting) active = 4;
  else if (phase.includes('plan')) active = 2;
  else if (phase.includes('protected_snapshot') || phase.includes('snapshot')) active = 5;
  else if (phase.includes('verify')) active = 6;
  else if (phase.includes('final') || phase.includes('tasks_complete')) active = 7;
  else if (phase.includes('execut') || phase.includes('working') || phase.includes('recover')) active = 5;
  const failed = ['blocked','failed','cancelled','interrupted','stalled'].includes(status);
  if (status === 'completed') active = 7;
  if (failed) {
    // Terminal backend status is NOT stage-completion evidence. A failed snapshot
    // previously painted Index through Verify with false success checkmarks.
    const events = Array.isArray(progress?.activityEvents) ? progress.activityEvents : [];
    const snapshotFailure = events.some(event => /protected[_ ]snapshot|rollback snapshot/i.test(
      `${event?.phase || ''} ${event?.tool || ''} ${event?.detail || ''} ${event?.output || ''}`));
    if (snapshotFailure) active = 5;
    else if (phase === status) active = Number(progress?.activePlanIndex || 0) > 0 ? 5 : 2;
  }
  return `<div class="agent-stage-strip">${stages.map((stage, index) => {
    const cls = failed
      ? (index === active ? 'failed' : index < active ? 'reached' : 'pending')
      : index < active ? 'done' : index === active ? 'active' : 'pending';
    const symbol = failed ? (index === active ? '!' : index < active ? '·' : index + 1)
      : (index < active ? '✓' : index + 1);
    return `<span class="agent-stage ${cls}"><i>${symbol}</i><b>${stage[1]}</b></span>`;
  }).join('')}</div>`;
}

function activityAgeText(iso, running) {
  if (!iso) return running ? 'Live' : '';
  const seconds = Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 1000));
  if (!Number.isFinite(seconds)) return running ? 'Live' : '';
  if (running && seconds < 3) return 'Live now';
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  return minutes < 60 ? `${minutes}m ago` : `${Math.floor(minutes / 60)}h ago`;
}

function durableAgentArgsText(step) {
  if (!step || step.args == null || step.args === '') return '';
  if (typeof step.args !== 'string') {
    try { return JSON.stringify(step.args, null, 2); } catch (_) { return String(step.args); }
  }
  try { return JSON.stringify(JSON.parse(step.args), null, 2); }
  catch (_) { return step.args; }
}

function agentActivityRowHtml(step) {
  const status = ['success', 'error', 'running', 'approval', 'done', 'blocked'].includes(step.status) ? step.status : 'running';
  const icon = status === 'success' || status === 'done' ? '✓' : status === 'error' || status === 'blocked' ? '!' : status === 'approval' ? '?' : '↻';
  const args = durableAgentArgsText(step);
  const details = (args || step.output) ? `<details class="agent-step-details"><summary>Details</summary>${args ? `<div class="agent-detail-label">Input</div><pre>${esc(args)}</pre>` : ''}${step.output ? `<div class="agent-detail-label">Output</div><pre>${esc(step.output)}</pre>` : ''}</details>` : '';
  const isDeletionApproval = step.approvalType === 'file_deletion' || String(step.detail || '').startsWith('FILE DELETION APPROVAL REQUIRED:');
  const approval = status === 'approval' && step.approvalId
    ? (isDeletionApproval
      ? `<div class="agent-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="deny">Keep files / deny</button><button type="button" class="primary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="once">Approve these file changes once</button></div>`
      : `<div class="agent-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="deny">Deny</button><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="once">Approve once</button><button type="button" class="primary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="run">Allow this run</button></div>`) : '';
  const at = step.at ? `<span class="agent-step-time">${esc(new Date(step.at).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'}))}</span>` : '';
  return `<div class="agent-step ${status}"><div class="agent-step-line"><span class="agent-step-icon">${icon}</span><span class="agent-step-tool">${esc(step.tool || 'agent')}</span><span class="agent-step-detail">${esc(step.detail || '')}</span>${at}</div>${approval}${details}</div>`;
}

function agentRuntimeStatusHtml(message, progress, runId, detail, runningNow) {
  const backendRaw = String(message.agentBackendStatus || progress?.status || (runningNow ? 'running' : 'unknown')).trim().toLowerCase();
  const backendStatus = backendRaw || 'unknown';
  const backendReachable = message.agentBackendReachable;
  const streamState = String(message.agentConnectionStatus || (runningNow ? 'connecting' : 'closed')).trim().toLowerCase();
  const lastActivity = activityAgeText(progress?.lastActivityAt, runningNow) || 'Unknown';
  const runText = runId ? String(runId) : 'Pending';
  const shortRun = runText.length > 18 ? `${runText.slice(0, 8)}…${runText.slice(-6)}` : runText;
  const backendLabel = backendStatus.replaceAll('_', ' ');
  let connectionLabel;
  if (streamState === 'connected') connectionLabel = backendReachable === false ? 'Stream connected · backend status unavailable' : 'Stream connected · backend reachable';
  else if (streamState === 'disconnected') connectionLabel = backendReachable === false ? 'Stream disconnected · retrying backend status' : 'Stream disconnected · polling backend';
  else if (streamState === 'recovering') connectionLabel = backendReachable === false ? 'Recovering · backend unreachable' : 'Recovering · backend reachable';
  else if (streamState === 'connecting') connectionLabel = backendReachable === false ? 'Connecting · backend status unavailable' : 'Connecting';
  else connectionLabel = backendReachable === false ? 'Closed · backend status unavailable' : 'Closed';
  const reachabilityClass = backendReachable === false ? 'unreachable' : backendReachable === true ? 'reachable' : 'checking';
  const transportNote = message.agentTransportError && streamState === 'disconnected'
    ? `<div class="agent-runtime-warning">Frontend stream interrupted: ${esc(message.agentTransportError)}. Backend polling remains active.</div>`
    : '';
  return `<div class="agent-runtime-status ${esc(reachabilityClass)}" data-agent-runtime-status>
    <div class="agent-runtime-status-item"><span>Backend</span><strong data-agent-backend-status>${esc(backendLabel.toUpperCase())}</strong></div>
    <div class="agent-runtime-status-item wide"><span>Connection</span><strong data-agent-connection-status>${esc(connectionLabel)}</strong></div>
    <div class="agent-runtime-status-item wide"><span>Current step</span><strong data-agent-current-step title="${esc(detail || '')}">${esc(detail || 'Preparing agent run')}</strong></div>
    <div class="agent-runtime-status-item"><span>Last backend activity</span><strong data-agent-last-activity>${esc(lastActivity)}</strong></div>
    <div class="agent-runtime-status-item"><span>Run ID</span><strong data-agent-run-id title="${esc(runText)}">${esc(shortRun)}</strong></div>
  </div>${transportNote}`;
}

// A finished task has its own report. It is based on the saved plan and sealed
// local file changes, not on model-generated guesses about files it may have edited.
function completionReportMarkdown(report) {
  const files = Array.isArray(report.files) ? report.files : [];
  const steps = Array.isArray(report.steps) ? report.steps : [];
  const out = [`# ELIYA Agent task report`, '', `Run: ${report.runId || ''}`, `Status: ${report.status || 'unknown'}`];
  if (report.objective) out.push(`Task: ${report.objective}`);
  if (report.finishedAt) out.push(`Finished: ${report.finishedAt}`);
  const counts=executionUsageNumbers(report.tokenUsage);
  out.push('', '## Provider token usage', `Engine: ${String(report.engine || counts.engine || 'legacy')==='opencode'?'OpenCode':'Eliya'}`,
    `Model: ${report.model || counts.model || 'Not reported'}`, `Usage source: ${counts.status}`,
    `Model calls observed: ${counts.calls}`,
    `Total reported tokens: ${counts.reported ? counts.total : 'Not reported'}`,
    `Input: ${counts.reported ? counts.input : 'Not reported'}`,
    `Output: ${counts.reported ? counts.output : 'Not reported'}`,
    `Cached input read: ${counts.reported ? counts.read : 'Not reported'}`,
    `Cache write: ${counts.reported ? counts.write : 'Not reported'}`,
    `Reasoning (subset of output): ${counts.reported ? counts.reasoning : 'Not reported'}`,
    `Unreported model calls: ${counts.missing}`,
    'OpenCode v2 input excludes its cache-read/write buckets; Eliya OpenAI-compatible input generally includes cached tokens.',
    'Missing provider usage is never guessed or presented as zero.');
  out.push('', '## Plan execution');
  if (!steps.length) out.push('No approved plan steps were recorded.');
  for (const item of steps) {
    out.push(`${item.index || '-'}. [${item.status || 'unknown'}] ${item.text || ''}`);
    if (item.note) out.push(`   ${item.note}`);
    for (const evidence of Array.isArray(item.evidence) ? item.evidence : []) out.push(`   - ${evidence}`);
  }
  out.push('', '## Verification', report.verification ? String(report.verification) : 'No recorded verification result.');
  out.push('', '## File changes');
  if (report.filesVerified) out.push(`${report.created || 0} created · ${report.modified || 0} modified · ${report.deleted || 0} deleted`);
  else out.push('No verified file-change manifest available.');
  if (report.rolledBack) out.push('This task was rolled back.');
  for (const file of files) {
    out.push('', `### ${file.action || 'changed'}: ${file.relativePath || file.name || ''}`, `Path: ${file.path || ''}`, file.detail || '');
    if (file.excerpt) out.push('```diff', file.excerpt, '```');
  }
  if (report.fileReportWarning) out.push('', `Note: ${report.fileReportWarning}`);
  return out.join('\n');
}

async function fetchAgentCompletionReport(message, quiet = true) {
  if (!message?.agentRunId || message.agentCompletionReport || message.agentReportLoading) return;
  message.agentReportLoading = true;
  try {
    if (message.executionEngine === 'opencode') {
      const session = await api(`/api/terminal/sessions/${encodeURIComponent(message.agentRunId)}`);
      message.agentCompletionReport = { ...(session.changeReport || {}), status: session.status, objective: session.prompt,
        verification: session.changeReport?.verification || 'OpenCode session diff is the available file-change evidence.',
        tokenUsage: session.usage, engine:'opencode', model:session.model, elapsedMs:session.elapsedMs };
    } else {
      message.agentCompletionReport = await api(`/api/agent/runs/${encodeURIComponent(message.agentRunId)}/completion-report`);
      message.agentCompletionReport.tokenUsage = message.agentProgress?.tokenUsage || {};
      message.agentCompletionReport.engine = 'legacy';
    }
    message.agentReportError = '';
  } catch (error) {
    message.agentReportError = error.message || 'Completion report unavailable';
    if (!quiet) toast(message.agentReportError, 5000);
  } finally {
    message.agentReportLoading = false;
    if (state.messages.includes(message)) renderMessages();
  }
}

function agentCompletionReportHtml(message) {
  const runId = message.agentRunId || '';
  const progress = message.agentProgress || {};
  const finished = !message.streaming && ['completed', 'failed', 'blocked', 'cancelled', 'interrupted', 'stalled'].includes(
    String(message.agentBackendStatus || progress.status || '').toLowerCase());
  if (!finished || !runId) return '';
  const stalled = String(message.agentBackendStatus || progress.status || '').toLowerCase() === 'stalled';
  const recovery = stalled && message.executionEngine === 'opencode'
    ? `<div class="agent-runtime-warning"><strong>OpenCode progress unverified.</strong> The remote agent may still be running; stop it before retrying on Eliya.
         <button type="button" class="secondary-btn" data-stop-stalled-opencode="${esc(runId)}">Stop remote OpenCode run</button></div>`
    : '';
  const report = message.agentCompletionReport;
  if (!report) {
    return `${recovery}<div class="agent-report-actions"><button type="button" data-load-agent-report="${esc(runId)}" ${message.agentReportLoading ? 'disabled' : ''}>${message.agentReportLoading ? 'Loading task report…' : 'View detailed task report'}</button></div>`;
  }
  const steps = Array.isArray(report.steps) ? report.steps : [];
  const files = Array.isArray(report.files) ? report.files : [];
  const counts = report.filesVerified
    ? `<span>${Number(report.created || 0)} created</span><span>${Number(report.modified || 0)} modified</span><span>${Number(report.deleted || 0)} deleted</span>`
    : '<span>File changes not verified</span>';
  const isOpenCodeReport = message.executionEngine === 'opencode';
  const stepsHtml = steps.length ? `<ol class="agent-report-steps">${steps.map(item => {
    const evidence = Array.isArray(item.evidence) ? item.evidence.filter(Boolean) : [];
    return `<li><strong>${esc(item.status || 'pending')}</strong> · ${esc(item.text || '')}${item.note ? `<small>${esc(item.note)}</small>` : ''}${evidence.length ? `<details><summary>${evidence.length} recorded evidence item(s)</summary><small>${evidence.map(esc).join('<br>')}</small></details>` : ''}</li>`;
  }).join('')}</ol>` : `<div class="agent-report-warning">${isOpenCodeReport ? 'No tool actions have been observed from OpenCode yet. This does not prove that the remote process did no work.' : 'No approved plan steps were recorded.'}</div>`;
  const filesHtml = files.length ? `<div class="agent-report-files">${files.map((file, index) => `<div class="agent-report-file"><div class="agent-report-file-head"><span class="agent-report-action">${esc(file.action || 'changed')}</span><code>${esc(file.relativePath || file.name || '')}</code><button type="button" class="agent-copy-path" data-copy-file-path="${esc(file.path || '')}" title="Copy full file path">Copy path</button>${/\.(md|markdown|html?|json|jsonl|ya?ml|xml|java|jsx?|tsx?|css|txt|py|sql|properties|sh|ps1|bat|cmd|feature|svg)$/i.test(String(file.relativePath || file.name || '')) && file.action !== 'deleted' ? `<button type="button" class="agent-file-preview-btn" data-preview-agent-md="${esc(runId)}" data-preview-agent-md-index="${index}" title="Read the current artifact from this Agent run">Preview</button>` : ''}</div><small>${esc(file.detail || '')}</small>${file.excerpt ? `<details><summary>See changed lines</summary><pre>${esc(file.excerpt)}</pre></details>` : ''}<small title="Full location">${esc(file.path || '')}</small></div>`).join('')}</div>`
    : `<div class="agent-report-warning">${report.filesVerified ? 'No tracked local workspace files changed in this task.' : 'No verified file details available for this run.'}</div>`;
  return `${recovery}<details class="agent-completion-report" open><summary>✓ Detailed ${String(report.status || '').toLowerCase() === 'completed' ? 'completion' : 'execution'} report · ${files.length} file(s)</summary>
    <div class="agent-report-counts"><span>Status: ${esc(report.status || 'unknown')}</span><span>${isOpenCodeReport ? `${steps.length} observed OpenCode actions` : `${steps.filter(step => step.status === 'completed').length}/${steps.length} steps complete`}</span>${counts}${report.rolledBack ? '<span>Rolled back</span>' : ''}</div>
    ${report.objective ? `<div><strong>Task:</strong> ${esc(report.objective)}</div>` : ''}
    <div class="agent-report-section-title">${isOpenCodeReport ? 'Observed OpenCode actions' : 'Step-by-step results'}</div>${stepsHtml}
    <div class="agent-report-section-title">Token consumption</div>${executionTokenStripHtml(report.tokenUsage || message.agentProgress?.tokenUsage,true)}
    <div class="agent-report-section-title">Verification</div><div class="agent-report-warning">${esc(report.verification || 'No recorded verification result; check the step evidence above.')}</div>
    <div class="agent-report-section-title">What changed and why</div><p class="agent-report-warning">The task objective explains the overall reason. Individual file descriptions and diff evidence below are recorded changes; ELIYA does not invent per-file rationale.</p>${filesHtml}
    ${report.filesVerified ? '<div class="agent-report-warning">Only tracked local workspace files are included. Dependency/build/cache folders and external MCP effects are excluded.</div>' : ''}
    ${report.fileReportWarning ? `<div class="agent-report-warning">${esc(report.fileReportWarning)}</div>` : ''}
    <div class="agent-report-actions"><button type="button" data-copy-agent-report="${esc(runId)}">Copy report</button><button type="button" data-download-agent-report="${esc(runId)}">Download Markdown report</button></div>
  </details>`;
}

// Read-only preview of files actually verified in a completed Agent run.
let currentRunMarkdown = null;
let runMarkdownFocusReturn = null;
let markdownRawMode = false;
let markdownPreviewRequest = 0;
let artifactEditing = false;
let artifactEditPreviousRawMode = false;
function closeRunMarkdown() {
  markdownPreviewRequest++;
  $('runMarkdownBackdrop').classList.add('hidden');
  currentRunMarkdown = null;
  artifactEditing = false;
  if (runMarkdownFocusReturn?.isConnected) runMarkdownFocusReturn.focus();
  runMarkdownFocusReturn = null;
}
function showRunMarkdown() {
  if (!currentRunMarkdown) return;
  if (!runMarkdownFocusReturn) {
    runMarkdownFocusReturn=document.activeElement;
    $('runMarkdownClose')?.focus();
  }
  const raw = String(currentRunMarkdown.content || '');
  const preview = $('runMarkdownContent');
  const editable = ['chat_artifact','chat_prompt','chat_proposal','chat_inline','chat_response'].includes(currentRunMarkdown.source);
  $('runMarkdownEdit')?.classList.toggle('hidden', !editable || artifactEditing);
  $('runMarkdownSaveEdit')?.classList.toggle('hidden', !editable || !artifactEditing);
  $('runMarkdownCancelEdit')?.classList.toggle('hidden', !editable || !artifactEditing);
  $('runMarkdownToggle').disabled=artifactEditing;
  if ($('runMarkdownFootnote')) $('runMarkdownFootnote').textContent = artifactEditing
    ? 'Edits are local to this preview. Apply edits and download; the saved conversation and workspace are unchanged.'
    : editable ? 'Preview, edit or download. Edits do not silently change your workspace.'
      : 'Read-only preview of a current workspace file. Preview does not edit the workspace.';
  const ext = (currentRunMarkdown.relativePath || currentRunMarkdown.name || '').split('.').pop().toLowerCase();
  const isHtml = ['html','htm','svg'].includes(ext);
  const isMarkdown = ['md','markdown'].includes(ext);
  preview.classList.toggle('markdown-source', markdownRawMode || (!isMarkdown && !isHtml));
  preview.classList.toggle('eliya-dark-source', !artifactEditing && markdownRawMode && ['chat_prompt','chat_artifact','chat_inline'].includes(currentRunMarkdown.source));
  preview.classList.toggle('html-presentation-view', isHtml && !markdownRawMode);
  if (artifactEditing) {
    preview.innerHTML = '';
    const area = document.createElement('textarea');
    area.id = 'eliyaArtifactEditor'; area.className = 'eliya-artifact-editor';
    area.setAttribute('aria-label','Edit complete artifact source');
    area.spellcheck = false; area.value = raw;
    preview.appendChild(area);
  } else if (!raw.trim()) {
    preview.innerHTML = '<div class="run-markdown-empty"><strong>This Markdown content is empty.</strong><p>No document text was generated for this file. Review the source response or Agent step results and regenerate the missing content.</p></div>';
  } else if (isHtml && !markdownRawMode) {
    // No same-origin privileges, scripts, popups or form submission in generated HTML previews.
    preview.innerHTML = '';
    const frame = document.createElement('iframe');
    frame.className = 'artifact-preview-frame';
    // Inline slide navigation scripts work inside an opaque-origin sandbox, but cannot
    // access the parent application, submit forms, navigate it, or reach remote APIs.
    frame.setAttribute('sandbox', ext === 'svg' ? '' : 'allow-scripts');
    frame.setAttribute('referrerpolicy', 'no-referrer');
    frame.setAttribute('loading', 'lazy');
    frame.title = 'Isolated HTML artifact preview';
    const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline' https:; img-src data: blob: https:; font-src data: https:; connect-src 'none'; object-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'">`;
    frame.srcdoc = /<head[^>]*>/i.test(raw) ? raw.replace(/<head[^>]*>/i, match => match + csp) : csp + raw;
    preview.appendChild(frame);
  } else if (markdownRawMode || !isMarkdown) {
    preview.innerHTML = `<pre>${esc(raw)}</pre>`;
  } else {
    preview.innerHTML = MarkdownRenderer.render(raw);
  }
  const sourceText = currentRunMarkdown.source === 'chat_proposal' ? 'Chat proposal — not written to workspace'
    : currentRunMarkdown.source === 'chat_inline' ? 'Chat HTML · isolated preview'
    : currentRunMarkdown.source === 'chat_response' ? 'Unified Chat response · read-only'
    : 'Current workspace content';
  $('runMarkdownStatus').textContent = `${currentRunMarkdown.bytes} bytes · ${sourceText}${raw.trim() ? '' : ' · Empty file'}`;
  $('runMarkdownToggle').textContent = markdownRawMode ? (isHtml ? 'HTML preview' : isMarkdown ? 'Formatted view' : 'Source view') : 'Raw source';
  $('runMarkdownCopy').disabled = artifactEditing || !raw.trim();
  $('runMarkdownDownload').disabled = artifactEditing || !raw.trim();
}
function firstHtmlPresentation(text) {
  const raw = String(text || '');
  const fence = /```(?:html|htm)\s*\n([\s\S]*?)\n```/gi;
  let found;
  while ((found = fence.exec(raw)) !== null) {
    if (/<(?:!doctype\s+html|html|head|body|style|section|div)\b/i.test(found[1])) return found[1];
  }
  // Plain HTML files written directly into Chat can be previewed as well.
  if (/^\s*(?:<!doctype\s+html|<html\b)/i.test(raw)) return raw;
  return null;
}
function previewChatResponse(messageIndex, asHtml=false) {
  const message = state.messages[messageIndex];
  const text = asHtml ? firstHtmlPresentation(message?.content) : stripProjectMarkers(message?.content || '');
  if (!text) return toast('No previewable content in this response');
  markdownPreviewRequest++;
  markdownRawMode = !asHtml;
  const name = asHtml ? 'presentation.html' : 'complete-response.txt';
  currentRunMarkdown = {name,relativePath:name,content:text,
    bytes:new TextEncoder().encode(text).length,source:asHtml?'chat_inline':'chat_response'};
  $('runMarkdownTitle').textContent=asHtml?'HTML presentation preview':'Complete response · one continuous view';
  $('runMarkdownPath').textContent=asHtml?'Interactive HTML in an isolated frame':'Full source · without split code containers';
  $('runMarkdownBackdrop').classList.remove('hidden');
  showRunMarkdown();
}
function openProposedMarkdown(messageIndex, fileIndex) {
  const changes = extractProjectFileChanges(state.messages[messageIndex]?.content || '');
  const file = changes[fileIndex];
  if (!file || file.operation === 'delete') return toast('Artifact proposal is unavailable');
  markdownPreviewRequest++;
  markdownRawMode = false;
  currentRunMarkdown = {name: String(file.path).split('/').pop(), relativePath: file.path,
    content: String(file.content || ''), bytes: new TextEncoder().encode(String(file.content || '')).length,
    source: 'chat_proposal'};
  $('runMarkdownTitle').textContent = currentRunMarkdown.name;
  $('runMarkdownPath').textContent = currentRunMarkdown.relativePath;
  $('runMarkdownBackdrop').classList.remove('hidden');
  showRunMarkdown();
}

async function openRunMarkdown(runId, index) {
  const request = ++markdownPreviewRequest;
  currentRunMarkdown = null;
  markdownRawMode = false;
  artifactEditing=false;
  $('runMarkdownTitle').textContent = 'Generated artifact preview';
  $('runMarkdownStatus').textContent = 'Reading verified artifact from local workspace…';
  $('runMarkdownContent').textContent = 'Loading artifact…';
  $('runMarkdownCopy').disabled = true;
  $('runMarkdownDownload').disabled = true;
  $('runMarkdownBackdrop').classList.remove('hidden');
  try {
    const file = await api(`/api/agent/runs/${encodeURIComponent(runId)}/artifacts/${index}`);
    if (request !== markdownPreviewRequest) return;
    currentRunMarkdown = file;
    $('runMarkdownTitle').textContent = file.name || 'Markdown';
    $('runMarkdownPath').textContent = file.relativePath || '';
    showRunMarkdown();
  } catch (error) {
    if (request !== markdownPreviewRequest) return;
    $('runMarkdownStatus').textContent = 'Unable to read file';
    $('runMarkdownContent').textContent = error.message || 'The generated file could not be opened.';
  }
}

/** Common provider-reported execution usage, never inferred from message lengths or tool counts. */
function executionUsageNumbers(raw) {
  const usage = raw && typeof raw === 'object' ? raw : {};
  const numeric = key => Number.isFinite(Number(usage[key])) ? Math.max(0,Number(usage[key])) : 0;
  const reported = usage.providerReported === true || (usage.providerReported == null && Number(usage.reportedCalls || 0)>0);
  const input = numeric('providerInputTokens'), output=numeric('providerOutputTokens');
  const read=numeric('cachedInputTokens'), write=numeric('cacheWriteTokens');
  const total = numeric('providerTotalTokens') || (reported ? input+output+(usage.inputExcludesCache ? read+write : 0) : 0);
  const missing=numeric('unreportedCalls');
  const status = !reported ? 'Not reported' : missing ? 'Partial' : 'Provider reported';
  return {reported,status,input,output,read,write,total,reasoning:numeric('reasoningTokens'),
    calls:numeric('modelCalls'),missing,elapsedMs:numeric('elapsedMs'),model:String(usage.model||''),
    engine:String(usage.engine||''),inputExcludesCache:usage.inputExcludesCache===true};
}
function executionTokenStripHtml(raw, finalRun=false) {
  const value=executionUsageNumbers(raw);
  const number=value=>Number(value).toLocaleString('en-US');
  return `<section class="execution-token-strip" aria-label="${finalRun?'Final':'Live'} model token usage">
    <strong>${finalRun?'Final':'Live'} provider tokens</strong>
    <span class="execution-token-primary">${value.reported?esc(number(value.total)):'Not reported'}</span>
    <small>Input ${value.reported?esc(number(value.input)):'—'} · Output ${value.reported?esc(number(value.output)):'—'}
     · Cache read ${value.reported?esc(number(value.read)):'—'} · Cache write ${value.reported?esc(number(value.write)):'—'}
     · Calls ${esc(number(value.calls))}${value.missing?' · '+esc(number(value.missing))+' unreported':''}
     ${value.reasoning?' · Reasoning '+esc(number(value.reasoning))+' (included in output)':''}</small>
    <small class="execution-token-source">${esc(value.status)} · ${value.inputExcludesCache?'OpenCode input excludes cache':'Eliya input may include cache'} · ${finalRun?'Final available accounting':'Updated from OpenCode events and message history'}</small>
    ${raw?.usageDiagnostic ? `<small class="execution-token-source">${esc(String(raw.usageDiagnostic))}</small>` : ''}
  </section>`;
}
/** Measured stage wall times. Provider latency and elapsed time overlap other stages;
 * never sum them as if they were disjoint or claim they are time savings. */
function agentStageTimingsHtml(usage) {
  const raw = usage?.stageTimeMs;
  if (!raw || typeof raw !== 'object') return '';
  const stages = [['workspace','Workspace setup'],['planning','Planning/context'],
    ['retrieval','Evidence retrieval'],['tools','Tools/commands'],
    ['verification','Verification'],['answer','Analysis synthesis'],
    ['finalization','Completion/reporting']];
  const fmt = ms => ms >= 1000 ? `${(ms/1000).toFixed(2)} s` : `${Math.round(ms)} ms`;
  const rows = stages.map(([key,label]) => ({label,ms:Number(raw[key]||0)}))
    .filter(item => Number.isFinite(item.ms) && item.ms > 0);
  if (!rows.length) return '';
  const total = Number(usage.elapsedMs || 0);
  const provider = Number(usage.providerLatencyMs || 0);
  return `<details class="agent-token-call-details"><summary>Execution timing · ${total > 0 ? esc(fmt(total)) : 'in progress'}</summary>
  <div class="agent-token-table-wrap"><table class="agent-token-table"><thead><tr><th>Stage</th><th>Measured time</th></tr></thead><tbody>
  ${rows.map(item=>`<tr><td>${esc(item.label)}</td><td>${esc(fmt(item.ms))}</td></tr>`).join('')}
  ${provider > 0 ? `<tr><td>Provider latency (overlaps other stages)</td><td>${esc(fmt(provider))}</td></tr>` : ''}
  </tbody></table></div>
  ${Number(usage.initialToolSchemas || 0) ? `<p class="agent-efficiency-note">Initial tool schemas: ${esc(String(usage.initialToolSchemas))} of ${esc(String(usage.baselineToolSchemas || usage.initialToolSchemas))} defaults. Proactive evidence replay avoided on ${esc(String(usage.proactiveRetrievalDeferred || 0))} context preparation(s). Deferred tools remain accessible through tool search.</p>` : ''}
  <small>Stage totals measure known operations, not the entire run. Parallel work and provider latency overlap; approval waits and uninstrumented work may be outside these buckets. This is measured timing, not a performance benchmark.</small></details>`;
}

/** End-of-activity provider accounting; missing usage is NOT equivalent to zero tokens. */
function tokenActivityReportHtml(usage, finalRun = true) {
  if (!finalRun || !usage || typeof usage !== 'object') return '';
  const rows = Array.isArray(usage.activities) ? usage.activities : [];
  if (!rows.length && !usage.modelCalls) return '';
  const number = value => Number(value || 0).toLocaleString('en-US');
  const reported=rows.reduce((sum,row)=>sum+Number(row.reportedCalls||0),0);
  const missing=rows.reduce((sum,row)=>sum+Number(row.unreportedCalls||0),0);
  const input=rows.reduce((sum,row)=>sum+Number(row.inputTokens||0),0);
  const output=rows.reduce((sum,row)=>sum+Number(row.outputTokens||0),0);
  const total=rows.reduce((sum,row)=>sum+Number(row.totalTokens||0),0);
  const read=rows.reduce((sum,row)=>sum+Number(row.cachedInputTokens||0),0);
  const write=rows.reduce((sum,row)=>sum+Number(row.cacheWriteTokens||0),0);
  const shownTotal=number(total);
  return `<details class="agent-token-activities" open>
    <summary>Token usage by activity · ${esc(shownTotal)} reported tokens${missing?` · ${esc(number(missing))} unreported call(s)`:''}</summary>
    <div class="agent-token-table-wrap"><table class="agent-token-table"><thead><tr><th>Activity</th><th>Calls</th><th>Input</th><th>Output</th><th>Cache read</th><th>Cache write</th><th>Total</th></tr></thead><tbody>
    ${rows.map(row=>{const hasProviderData = Number(row.reportedCalls||0)>0 || row.reported===true; return `<tr><td>${esc(String(row.activity||'Agent execution'))}</td><td>${esc(number(row.calls))}</td>
      <td>${esc(hasProviderData?number(row.inputTokens):'Not reported')}</td>
      <td>${esc(hasProviderData?number(row.outputTokens):'Not reported')}</td>
      <td>${esc(hasProviderData?number(row.cachedInputTokens):'Not reported')}</td>
      <td>${esc(hasProviderData?number(row.cacheWriteTokens):'Not reported')}</td>
      <td>${esc(hasProviderData?number(row.totalTokens):'Not reported')}${Number(row.unreportedCalls||0)?'<small> + unreported call(s)</small>':''}</td></tr>`;}).join('')}
    </tbody><tfoot><tr><th>Total (reported)</th><th>${esc(number(reported+missing))}</th><th>${esc(number(input))}</th><th>${esc(number(output))}</th><th>${esc(number(read))}</th><th>${esc(number(write))}</th><th>${esc(shownTotal)}</th></tr></tfoot></table></div>
    ${Array.isArray(usage.modelCallBreakdown) && usage.modelCallBreakdown.length ? `<details class="agent-token-call-details"><summary>Inspect ${esc(number(usage.modelCallBreakdown.length))} individual model calls</summary><div class="agent-token-table-wrap"><table class="agent-token-table"><thead><tr><th>Call</th><th>Activity</th><th>Input</th><th>Output</th><th>Cache read</th><th>Cache write</th><th>Total</th></tr></thead><tbody>${usage.modelCallBreakdown.map(call=>`<tr><td>${esc(number(call.call))}</td><td>${esc(String(call.activity||'Model call'))}</td><td>${esc(call.reported?number(call.inputTokens):'Not reported')}</td><td>${esc(call.reported?number(call.outputTokens):'Not reported')}</td><td>${esc(call.reported?number(call.cachedInputTokens):'Not reported')}</td><td>${esc(call.reported?number(call.cacheWriteTokens):'Not reported')}</td><td>${esc(call.reported?number(call.totalTokens):'Not reported')}</td></tr>`).join('')}</tbody></table></div></details>` : ''}
    <div class="agent-token-note">${missing?`${esc(number(missing))} model call(s) did not supply token usage; the true total may be higher. `:''}Cached input is included in input tokens where reported by Eliya's OpenAI-compatible provider; OpenCode v2 reports cache read/write separately from input. Reasoning is a subset of output. Shell, Git and test commands do not independently consume LLM tokens. Context estimates are not billed usage.</div>
  </details>`;
}

function agentStepsHtml(message) {
  const steps = Array.isArray(message.agentSteps) ? message.agentSteps : [];
  const progress = message.agentProgress || null;
  if (!steps.length && !progress) return '';

  const progressPlan = Array.isArray(progress?.plan) ? progress.plan : [];
  const latestPlanApproval = [...steps].reverse().find(step => step.tool === 'plan_approval');
  const planApprovalStep = latestPlanApproval?.status === 'approval' ? latestPlanApproval : null;
  const draftPlan = progressPlan.length ? progressPlan : parsePlanTextForUi(planApprovalStep?.output || '');
  const runId = message.agentRunId || planApprovalStep?.runId || '';

  // Keep the recent activity visible, but preserve the full durable history behind an expandable section.
  const rawActivity = steps.filter(step => step.tool !== 'plan' && step.tool !== 'plan_approval');
  // For OpenCode, successive tool input/running/success events are one action,
  // not three independent commands. Keep the latest status and output visible.
  const activity = message.executionEngine === 'opencode' ? (() => {
    const result=[], positions=new Map();
    for(const step of rawActivity) {
      const key=String(step.actionId||'');
      if(key && positions.has(key)) {
        const at=positions.get(key);
        result[at]={...result[at],...step};
      } else {
        if(key) positions.set(key,result.length);
        result.push(step);
      }
    }
    return result;
  })() : rawActivity;
  const maxVisibleEvents = 55;
  const hiddenEventCount = Math.max(0, activity.length - maxVisibleEvents);
  const olderSteps = hiddenEventCount ? activity.slice(0, -maxVisibleEvents) : [];
  const visibleSteps = hiddenEventCount ? activity.slice(-maxVisibleEvents) : activity;
  const olderActivityRows = hiddenEventCount
    ? `<details class="agent-event-history"><summary>Show ${esc(String(hiddenEventCount))} earlier activity events</summary><div class="agent-event-history-body">${olderSteps.map(agentActivityRowHtml).join('')}</div></details>`
    : '';
  const activityRows = `${olderActivityRows}${visibleSteps.map(agentActivityRowHtml).join('')}`;

  const planApprovalHtml = planApprovalStep ? `${planEditorHtml(runId, draftPlan, progress?.planValidationStatus, progress?.planValidationSummary)}<div class="agent-approval-actions plan-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(planApprovalStep.approvalId)}" data-approval-action="deny">Cancel</button><button type="button" class="primary-btn" data-agent-approval="${esc(planApprovalStep.approvalId)}" data-approval-action="once" data-plan-approve>Approve plan & run step 1</button><button type="button" class="secondary-btn" data-agent-to-terminal="${esc(planApprovalStep.approvalId)}" data-source-run="${esc(runId)}">⌘ Execute in Terminal (no plan approval)</button></div>` : '';
  const waitingGenericApproval = visibleSteps.some((step, index) => step.status === 'approval' && !visibleSteps.slice(index + 1).some(next => next.tool === step.tool && next.step === step.step && next.status !== 'approval'));
  const waiting = Boolean(planApprovalStep) || waitingGenericApproval;
  const changed = Number(message.agentDirectChangeCount || 0);
  const completedPlans = progressPlan.filter(item => item.status === 'completed').length;
  const totalPlans = progressPlan.length;
  const eventTotal = Number(message.agentEventTotal || steps.length);
  const workSummary = progress?.workItemSummary || {};
  const workTotal = Number(workSummary.total || 0);
  const workCompleted = Number(workSummary.completed || 0);
  const workFailed = Number(workSummary.failed || 0);
  const summary = workTotal
    ? `${workCompleted}/${workTotal} work items completed${workFailed ? ` · ${workFailed} failed` : ''}`
    : (totalPlans ? `${completedPlans}/${totalPlans} planned steps completed` : (changed > 0 ? `${changed} file${changed === 1 ? '' : 's'} changed directly` : `${eventTotal} activity event${eventTotal === 1 ? '' : 's'}`));
  const pct = Math.max(0, Math.min(100, Number(progress?.percent ?? (message.streaming ? 2 : 100))));
  const phase = progress?.phase || (message.streaming ? 'starting' : 'completed');
  const detail = progress?.detail || (message.streaming ? 'Preparing agent run' : 'Task completed');
  const usage = progress?.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const compactionsNow = Number(usage.compactions || 0);
  const prunedNow = Number(usage.prunedObservations || 0);
  const savedNow = Number(usage.estimatedTokensSavedByPruning || 0) + Number(usage.estimatedTokensSavedByCompaction || 0);
  const cacheHitNow = Number(usage.cacheHitPercent || 0);
  const tokenLine = (providerTotal || contextNow || compactionsNow || prunedNow)
    ? `<div class="agent-token-line">${contextNow ? `Context ~${esc(formatCompact(contextNow))}${contextWindow ? ` / ${esc(formatCompact(contextWindow))}` : ''}` : ''}${providerTotal ? `${contextNow ? ' · ' : ''}Run tokens ${esc(formatCompact(providerTotal))}` : ''}${compactionsNow ? ` · ${esc(String(compactionsNow))} compaction${compactionsNow === 1 ? '' : 's'}` : ''}${prunedNow ? ` · ${esc(String(prunedNow))} pruned` : ''}${savedNow ? ` · ~${esc(formatCompact(savedNow))} active tokens saved` : ''}${cacheHitNow > 0 ? ` · cache ${esc(cacheHitNow.toFixed(0))}%` : ''}</div>`
    : '';

  const activeModel = progress?.activeModel || '';
  const modelPool = Array.isArray(progress?.modelPool) ? progress.modelPool : [];
  const failovers = Number(progress?.modelFailovers || 0);
  const recoveryReplans = Number(progress?.recoveryReplans || 0);
  const activePlanIndex = Number(progress?.activePlanIndex || 0);
  const documentationMode = Boolean(progress?.documentationMode);
  const documentationCoverageComplete = Boolean(progress?.documentationCoverageComplete);
  const documentationValidated = Boolean(progress?.documentationValidated);
  const runtimeMeta = activeModel || modelPool.length || activePlanIndex || recoveryReplans || workTotal || documentationMode
    ? `<div class="agent-runtime-meta">${activeModel ? `<span class="agent-runtime-pill">Model <strong>${esc(activeModel)}</strong></span>` : ''}${modelPool.length > 1 ? `<span class="agent-runtime-pill">Pool ${esc(String(modelPool.length))}</span>` : ''}${failovers ? `<span class="agent-runtime-pill">Failovers ${esc(String(failovers))}</span>` : ''}${recoveryReplans ? `<span class="agent-runtime-pill recovery">Recoveries ${esc(String(recoveryReplans))}</span>` : ''}${activePlanIndex ? `<span class="agent-runtime-pill">Active step ${esc(String(activePlanIndex))}</span>` : ''}${workTotal ? `<span class="agent-runtime-pill">Work ${esc(String(workCompleted))}/${esc(String(workTotal))}</span>` : ''}${workFailed ? `<span class="agent-runtime-pill recovery">Failed ${esc(String(workFailed))}</span>` : ''}${documentationMode ? `<span class="agent-runtime-pill ${documentationCoverageComplete ? '' : 'recovery'}">Docs ${documentationCoverageComplete ? 'coverage complete' : 'coverage pending'}</span><span class="agent-runtime-pill ${documentationValidated ? '' : 'recovery'}">Doc validation ${documentationValidated ? 'passed' : 'pending'}</span>` : ''}</div>`
    : '';
  const documentationStatus = documentationMode
    ? `<div class="agent-plan-quality ${documentationCoverageComplete && documentationValidated ? 'approved' : 'review'}"><span>${documentationCoverageComplete && documentationValidated ? '✓' : '!'}</span><div><strong>Documentation intelligence</strong><small>${esc(progress?.documentationCoverageSummary || 'Repository coverage not initialized')}${progress?.documentationValidationSummary ? ` · ${esc(progress.documentationValidationSummary)}` : ''}</small></div></div>`
    : '';

  const planBoard = progressPlan.length && !planApprovalStep ? `<div class="agent-plan-board">${progressPlan.map(item => {
    const status = ['pending','in_progress','completed','blocked'].includes(item.status) ? item.status : 'pending';
    const evidence = Array.isArray(item.evidence) ? item.evidence.filter(Boolean) : [];
    const evidenceHtml = evidence.length ? `<details class="agent-plan-evidence" ${status === 'in_progress' ? 'open' : ''}><summary>${status === 'completed' ? 'Completed details' : 'Live step details'} · ${evidence.length}</summary><ul>${evidence.map(line => `<li>${esc(line)}</li>`).join('')}</ul></details>` : '';
    return `<div class="agent-plan-item ${esc(status)}"><span class="agent-plan-index">${esc(String(item.index || ''))}</span><span class="agent-plan-text">${structuredPlanStepHtml(item.text || '')}${item.note ? `<small class="agent-plan-note">${esc(item.note)}</small>` : ''}${evidenceHtml}</span><span class="agent-plan-state">${esc(status.replaceAll('_',' '))}</span></div>`;
  }).join('')}</div>` : '';

  const activeProgress = message.streaming && pct < 100 ? ' active' : '';
  const runningNow = Boolean(message.streaming || String(progress?.status || '') === 'running');
  const liveAge = activityAgeText(progress?.lastActivityAt, runningNow);
  const liveStatus = `<div class="agent-live-status ${runningNow ? 'running' : 'finished'}"><span class="agent-live-dot"></span><strong>${runningNow ? 'Live status' : 'Last status'}</strong><span class="agent-live-age">${esc(liveAge)}</span><span class="agent-live-detail">${esc(detail)}</span></div>`;
  const runtimeStatus = agentRuntimeStatusHtml(message, progress, runId, detail, runningNow);
  const validationStatus = String(progress?.planValidationStatus || 'not_run');
  const validationSummary = String(progress?.planValidationSummary || '');
  const planQuality = validationStatus !== 'not_run' ? `<div class="agent-plan-quality ${validationStatus === 'approved' ? 'approved' : 'review'}"><span>${validationStatus === 'approved' ? '✓' : '!'}</span><div><strong>${validationStatus === 'approved' ? 'Plan ready' : 'Plan needs review'}</strong>${validationSummary ? `<small>${esc(validationSummary)}</small>` : ''}</div></div>` : '';
  const clarification = progress?.question || {};
  const clarificationHtml = clarification.kind === 'clarification' && clarification.id ?
    `<div class="agent-chat-question" data-agent-question-id="${esc(clarification.id)}" data-agent-run-id="${esc(runId)}" role="status"><strong>Eliya asks:</strong> ${esc(clarification.reason || 'Please clarify before I continue.')}<small>Reply in the message box below and press Enter. You can answer naturally.</small></div>` : '';
  const unknownOpenCode = Boolean(progress?.indeterminate || (message.executionEngine === 'opencode' && message.streaming && pct === 0));
  const percentLabel = unknownOpenCode ? 'Working · % unavailable' : `${Math.round(pct)}%${progress?.estimated && message.streaming ? ' est.' : ''}`;
  const durationLabel = eliRunTimeLabel(message, progress);
  const openCodeTokenLive = message.executionEngine==='opencode'
    ? executionTokenStripHtml(progress?.tokenUsage || {}, !message.streaming) : '';
  const progressHtml = `<div class="agent-progress">${agentStageHtml(progress, waiting)}<div class="agent-progress-top"><strong>${esc(String(phase).replaceAll('_',' '))}</strong><span class="agent-progress-percent">${esc(percentLabel)}</span></div><div class="agent-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" ${unknownOpenCode ? '' : `aria-valuenow="${esc(String(Math.round(pct)))}"`}><div class="agent-progress-fill${activeProgress}" style="width:${unknownOpenCode ? '15' : esc(String(pct))}%"></div></div>${durationLabel ? `<div class="agent-run-duration" data-agent-elapsed>${esc(durationLabel)}</div>` : ''}${liveStatus}${runtimeStatus}${planQuality}${documentationStatus}${tokenLine}${openCodeTokenLive}${runtimeMeta}${planBoard}${planApprovalHtml}</div>`;
  // Operational failures are not clarification questions. Actual user questions use
  // the shared composer; runtime faults belong in the expandable technical report.
  const recoveryHtml = !message.streaming && ['failed','blocked','interrupted','stalled'].includes(String(progress?.status || ''))
    ? '<div class="agent-run-warning">The run did not finish cleanly. Review recorded evidence and the stated limitation; existing changes are preserved.</div>' : '';
  const activityPanel = activityRows ? `<details class="agent-activity-panel" ${message.streaming && message.executionEngine!=='opencode' ? 'open' : ''}><summary><span>Full execution history</span><span>${eventTotal} events</span></summary><div class="agent-activity-list">${activityRows}</div></details>` : '';
  // ELIYA89+ uses a unified chat surface, not the old hidden Terminal dock.
  // Keep actual OpenCode actions visible outside collapsed technical details.
  const openCodeLive = message.executionEngine==='opencode' && message.streaming
    ? `<section class="opencode-live-console" aria-label="Live OpenCode terminal actions" role="log">
         <div class="opencode-console-head"><strong>▣ OpenCode execution · live actions</strong><span>${activity.length} observed</span></div>
         ${activity.length ? activity.slice(-24).map(step=>{
           const tool=String(step.tool||'OpenCode');
           const detail=String(step.detail||'');
           const status=String(step.status||'running');
           const output=String(step.output||'');
           const args=durableAgentArgsText(step);
           return `<div class="opencode-console-action">
             <div class="opencode-console-line"><span class="opencode-console-sigil">${status==='success'?'✓':status==='error'?'!':'›'}</span><strong>${esc(tool)}</strong><small class="opencode-console-status status-${esc(status)}">${esc(status)}</small></div>
             ${detail?`<div class="opencode-console-command">${esc(detail)}</div>`:''}
             ${args && args!==detail ? `<div class="opencode-console-command">${esc(args)}</div>`:''}
             ${output?`<pre class="opencode-console-output">${esc(output.slice(-2200))}</pre>`:''}
           </div>`;
         }).join('') : `<p class="opencode-console-await">Waiting for OpenCode tool events. Execution is running independently of this tab.</p>`}
       </section>` : '';
  // Completion is derived from durable backend state and outstanding plan/work-item
  // evidence, never from the assistant saying "done" or the progress bar reaching 100%.
  const sealedStatus=String(message.agentBackendStatus || progress?.status || '').toLowerCase();
  const outstanding=progressPlan.some(item=>item.status!=='completed') || workFailed>0 ||
    (Array.isArray(progress?.verificationFailures) && progress.verificationFailures.length>0);
  const isSealed=!message.streaming && ['completed','blocked','failed','cancelled','interrupted','stalled'].includes(sealedStatus);
  const previewAwaitingApproval = message.mode === 'agent' &&
    /^## Proposed execution plan\b/m.test(String(message.content || '')) &&
    /Awaiting explicit approval\./.test(String(message.content || ''));
  const outcomeName=previewAwaitingApproval ? 'Plan ready · awaiting approval' :
    sealedStatus==='completed' && !outstanding?'Completed' :
    sealedStatus==='completed'?'Partially completed': sealedStatus==='blocked'?'Blocked':
    sealedStatus==='failed'?'Failed': sealedStatus==='cancelled'?'Cancelled':'Interrupted';
  const outcomeClass=previewAwaitingApproval ? 'attention' : sealedStatus==='completed' && !outstanding?'completed':'attention';
  const outcomeDetail=previewAwaitingApproval ? 'Planning finished. No migration implementation or workspace edits were authorized.' : outstanding ? 'Outstanding plan steps, work items, or verification failures remain.' :
    sealedStatus==='completed'?'Backend completion gates passed. Inspect recorded checks for which tests actually ran.' :
    'Requested work was not verified complete. Preserve successful work and inspect the failure details.';
  const sealedOutcome=isSealed ? `<div class="eliya-agent-outcome ${outcomeClass}" role="status"><strong>${esc(outcomeName)}</strong><span>${esc(outcomeDetail)}</span></div>` : '';
  const showFullAgent = Boolean(message.streaming || waiting || clarificationHtml);
  const agentSummary = progress?.status === 'failed' ? 'Needs attention' : showFullAgent ? 'Live execution details' : 'View execution details';
  return `<div class="agent-run-card agent-run-secondary ${waiting ? 'waiting-approval' : ''}"><div class="agent-run-head"><span>${showFullAgent ? 'Investigating / executing' : 'Work record'}</span><span>${showFullAgent ? summary : (progress?.status === 'failed' ? 'Needs review' : 'Available on request')}${durationLabel ? `<small class="agent-head-duration" data-agent-elapsed>${esc(durationLabel)}</small>` : ''}</span></div>${sealedOutcome}${executionTokenStripHtml(usage,!message.streaming)}${openCodeLive}<details class="agent-run-disclosure" ${showFullAgent ? 'open' : ''}><summary>${agentSummary}</summary><div class="agent-run-inner">${progressHtml}${recoveryHtml}${agentCompletionReportHtml(message)}${tokenActivityReportHtml(usage, !message.streaming && !waiting)}${agentStageTimingsHtml(usage)}${activityPanel}</div></details>${clarificationHtml}</div>`;
}

// Keep a substantive answer in the conversation even if the stream and the saved
// completion diverge. The durable Agent result is authoritative *when it contains
// a real answer*; an empty or generic completion must not erase streamed analysis.
// Session-scoped view preferences do not duplicate source text or execute prompts.
const expandedSourceKeys=new Set();
function sourceExpandKey(message,index,promptNumber){
  return `${String(message?.id ?? `index-${index}`)}:${promptNumber == null?'html':String(promptNumber)}`;
}
function loadSourceExpansion(conversationId){
  expandedSourceKeys.clear();
  try { const saved=JSON.parse(storageGet('session',`llm.sourceExpansion144.${conversationId}`)||'[]');
    for(const key of Array.isArray(saved)?saved.slice(-60):[]) if(typeof key==='string' && key.length<140)expandedSourceKeys.add(key);
  }catch(_){};
}
function persistSourceExpansion(){
  if(!state.conversationId)return;
  storageSet('session',`llm.sourceExpansion144.${state.conversationId}`,
    JSON.stringify([...expandedSourceKeys].slice(-60)));
}
function showEarlierMessages(){
  if(!state.visibleMessageStart)return;
  const old=state.visibleMessageStart;
  state.visibleMessageStart=Math.max(0,old-65);
  renderMessages();
  const first=$('messages').querySelector(`[data-message-index="${state.visibleMessageStart}"]`);
  first?.scrollIntoView({block:'start',behavior:'instant'});
}
$('earlierMessagesBtn')?.addEventListener('click',showEarlierMessages);

function completedAnswerChoice(streamed, persisted, agentMode) {
  const live = String(streamed || '');
  const saved = String(persisted || '');
  if (!saved.trim()) return {content:live, warning:false};
  if (!live.trim() || saved === live || saved.startsWith(live)) return {content:saved, warning:false};
  if (!agentMode) return {content:live, warning:true};
  const boilerplate = /^(?:all approved plan steps completed|the requested workspace changes completed|agent run completed|task completed|completed successfully|done\b|the agent could not independently verify)/i;
  const meaningful = value => value.trim().length >= 90 && !boilerplate.test(value.trim());
  if (meaningful(saved)) return {content:saved, warning:false};
  if (meaningful(live)) return {content:live, warning:false};
  return {content:saved.length >= live.length ? saved : live, warning:false};
}
function applyCompletedChatMessage(message, saved) {
  const currentMode = message.mode;
  const streamed = String(message.content || '');
  const persisted = saved && typeof saved.content === 'string' ? saved.content : '';
  const choice = completedAnswerChoice(streamed, persisted, currentMode === 'agent');
  if (saved && typeof saved === 'object' && !Array.isArray(saved)) Object.assign(message, saved);
  message.content = choice.content;
  message.streaming = false;
  if (choice.warning) message.chatCompletionWarning = 'The server returned a different saved response. Your streamed Chat answer was retained.';
  else delete message.chatCompletionWarning;
  return message;
}

// Prompt drafts are displayed as one cohesive document rather than alternating code cards.
// Users can switch back to rich Markdown without changing the actual generated bytes.
const formattedPromptOverrides = new Set();
// Large completed artifacts stay as one black source panel, but only the initial
// viewport is inserted into the DOM. The actions always work from original bytes.
function inlineSourcePreview(text) {
  const result = window.EliyaSourceViewer?.preview?.(text);
  return result || {text:String(text||''),abbreviated:false,hiddenChars:0,hiddenLines:0};
}
function inlineSourceLabel(result) {
  return window.EliyaSourceViewer?.label?.(result) || 'Complete source';
}
function messageHtml(message, index) {
  const assistant = message.role === 'assistant';
  const isLastAssistant = assistant && index === state.messages.length - 1;

  if (!assistant && state.editingIndex === index) {
    return `<article class="message user" data-message-index="${index}">
      <div class="avatar">You</div>
      <div class="message-body">
        ${attachmentHtml(message.attachmentIds)}
        <div class="edit-panel">
          <textarea id="editMessageInput" class="edit-textarea" rows="4">${esc(message.content || '')}</textarea>
          <div class="edit-actions"><button class="secondary-btn" type="button" data-edit-cancel="${index}">Cancel</button><button class="primary-btn" type="button" data-edit-save="${index}">Save & submit</button></div>
        </div>
      </div>
    </article>`;
  }

  const displayContent = assistant ? stripProjectMarkers(message.content || '') : (message.content || '');
  const loadingIndicator = assistant && message.mode !== 'agent' && message.streaming && !displayContent.trim()
    ? chatLoadingHtml(message)
    : '';
  const continuation = assistant && message.mode === 'chat' && message.streaming && message.chatContinuationDetail
    ? `<div class="chat-continuation" role="status">↪ ${esc(message.chatContinuationDetail)}</div>` : '';
  const integrityNote = assistant && message.chatCompletionWarning
    ? `<div class="chat-integrity-warning" role="alert">${esc(message.chatCompletionWarning)}</div>` : '';
  const precedingText = String(state.messages[index-1]?.role === 'user' ? state.messages[index-1].content || '' : '');
  // ELIYA133: completed evidence (not a friendly acknowledgement) controls the actions.
  const experience = assistant ? window.EliyaResponseExperience?.result?.({
    question:precedingText, answer:displayContent, streaming:Boolean(message.streaming), mode:message.mode
  }) : null;
  const isVerification = experience?.intent === 'verification' && message.mode === 'chat';
  const verificationNote = isVerification && !message.streaming ? `<section class="eliya-verification-result ${experience.status === 'reported' ? 'evidence-reported' : 'not-established'}" role="status">
    <div><span class="eliya-result-symbol" aria-hidden="true">${experience.status === 'reported' ? '◉' : '!'}</span><strong>${experience.status === 'reported' ? 'Verification assessment' : 'Verification not established'}</strong></div>
    <p>${experience.status === 'reported'
       ? `Reported verdict: ${esc(experience.verdict || 'inconclusive')}. Review the cited evidence below; static inspection does not prove tests ran.`
       : 'This response does not establish a verdict backed by inspected evidence. No migration success or test result is being claimed.'}</p>
    ${experience.status === 'reported' ? '' : `<button class="secondary-btn" type="button" data-complete-verification="${index}">Complete verification in Analyse</button>`}
  </section>` : '';
  const missingPrompt = assistant && !message.streaming && experience?.intent === 'prompt' && experience.status === 'incomplete'
    ? `<section class="eliya-prompt-missing" role="status"><strong>Complete prompt not generated</strong><p>Only an introduction or incomplete answer was returned. There is nothing safe to implement or download yet.</p><button type="button" class="primary-btn" data-recover-prompt="${index}">Generate the full prompt</button></section>` : '';
  const requestIsPrompt = assistant && window.EliyaResponseArtifacts?.isPromptRequest?.(precedingText);
  const promptSuggestion = !requestIsPrompt && experience?.showPromptCta && !message.streaming && window.EliyaWorkflowHandoff?.canHandoff?.(message)
    ? `<button type="button" class="eliya-next-prompt" data-generate-implementation-prompt="${index}">✧ Generate implementation prompt from these findings</button>` : '';
  const promptSections = assistant && !message.streaming && requestIsPrompt
    ? (window.EliyaResponseArtifacts?.promptSections(precedingText, displayContent) || []) : [];
  const expectedPromptCount = requestIsPrompt ? (window.EliyaResponseArtifacts?.expectedPromptCount(precedingText) || 0) : 0;
  const completePromptSet = promptSections.length && promptSections.every(scope => scope.ready) && (!expectedPromptCount || promptSections.length === expectedPromptCount);
  const promptResponse = promptSections.length > 0;
  // Generated prompts are source documents, never ordinary chat Markdown.
  // The single-prompt request always yields exactly one dark .md viewer.
  const promptPreview = promptResponse;
  const promptCards = promptResponse ? `<section class="eliya-prompts" aria-label="Complete generated prompts">
    <div class="eliya-prompts-header"><div><strong>${expectedPromptCount ? `${promptSections.length} / ${expectedPromptCount} migration prompts` : (promptSections.length === 1 ? 'Generated prompt' : `${promptSections.length} generated prompts`)}</strong><span>Read and download each prompt separately. Only the prompt you select can be sent to Agent; generating prompts never runs them.</span></div>
    ${completePromptSet ? '' : `<button type="button" class="secondary-btn" data-prompt-regenerate-set="${index}">Regenerate separate prompts</button>`}</div>
    ${promptSections.map((prompt,n) => {const expanded=expandedSourceKeys.has(sourceExpandKey(message,index,n));const sourcePreview=expanded?{...inlineSourcePreview(prompt.content),text:prompt.content}:inlineSourcePreview(prompt.content);return `<article class="eliya-prompt-card${expanded?' eliya-source-expanded':''}"><header><strong>${esc(prompt.title)}</strong><span>${prompt.content.length.toLocaleString()} characters · ${prompt.content.split('\n').length.toLocaleString()} lines · ${prompt.ready ? 'Complete source' : 'Review required'}</span></header>
      <pre class="eliya-prompt-text" aria-label="Source preview; expand for complete source">${esc(sourcePreview.text)}</pre>
      ${sourcePreview.abbreviated ? `<div class="eliya-source-preview-note" role="status" ${expanded?'hidden':''}>${esc(inlineSourceLabel(sourcePreview))}</div>` : ''}
      ${prompt.ready ? '' : `<div class="eliya-prompt-warning" role="status">${esc(prompt.reason)} Implementation is disabled until the prompt meets the required scope and verification checks.</div>`}
      <div class="eliya-prompt-actions">${sourcePreview.abbreviated ? `<button type="button" class="mini-btn" data-inline-source="${index}" data-prompt-number="${n}" aria-expanded="${expanded}">${expanded?'Collapse preview':'Show all inline'}</button>` : ''}<button type="button" class="mini-btn" data-prompt-full="${index}" data-prompt-number="${n}">Open full view</button><button type="button" class="mini-btn" data-prompt-copy="${index}" data-prompt-number="${n}">Copy</button>
      ${window.EliyaResponseArtifacts?.promptSourceDownloadable?.(prompt) ? `<button type="button" class="mini-btn" data-prompt-download="${index}" data-prompt-number="${n}">Download ${prompt.ready ? 'complete' : 'partial'} .md</button>` : ''}
      ${prompt.ready && window.EliyaWorkflowHandoff?.canHandoff?.(message) ? `<button type="button" class="primary-btn eliya-scope-implement" data-prompt-implement="${index}" data-prompt-number="${n}">⚡ Implement with Agent · this prompt only</button>` :
       !prompt.ready ? `<button type="button" class="primary-btn" data-prompt-complete="${index}" data-prompt-number="${n}">Generate complete prompt</button>` : ''}</div>
    </article>`;}).join('')}</section>` : '';
  // If an unrelated UI state refresh occurs during a long generation,
  // preserve the same dark document viewer instead of reparsing thousands of
  // source lines into fragmented Markdown/code cards.
  const liveSource = assistant && message.streaming
    ? window.EliyaResponseArtifacts?.sourceView?.(precedingText,displayContent,true) : null;
  const liveDocument = liveSource?.kind === 'prompt' || liveSource?.kind === 'html';
  const liveViewer = liveDocument && displayContent.trim() ? `<section class="eliya-prompts eliya-source-flow"><article class="eliya-prompt-card eliya-stream-source"><header><strong>${liveSource.kind === 'prompt' ? 'Markdown prompt · generating' : 'HTML source · generating'}</strong><span class="eliya-stream-size">${displayContent.length.toLocaleString()} characters · streaming</span></header><pre class="eliya-prompt-text" aria-label="Streaming full source">${esc(liveSource.content)}</pre><div class="eliya-prompt-actions"><button type="button" class="mini-btn" data-live-source-full="${index}">Expand</button><button type="button" class="mini-btn" data-live-source-copy="${index}">Copy current text</button><button type="button" class="mini-btn" data-live-source-download="${index}">Save partial draft</button></div></article></section>` : '';
  const sourceFile = assistant && !message.streaming && !requestIsPrompt
    ? window.EliyaResponseArtifacts?.sourceView?.(precedingText,displayContent) : null;
  const htmlSource = sourceFile?.kind === 'html';
  const htmlExpanded=htmlSource && expandedSourceKeys.has(sourceExpandKey(message,index,null));
  const htmlPreview = htmlSource ? inlineSourcePreview(sourceFile.content) : null;
  const htmlViewer = htmlSource ? `<section class="eliya-prompts eliya-source-flow" aria-label="Complete HTML source viewer">
    <article class="eliya-prompt-card eliya-source-card${htmlExpanded?' eliya-source-expanded':''}"><header><strong>${esc(sourceFile.filename)}</strong><span>${sourceFile.content.length.toLocaleString()} characters · ${sourceFile.content.split('\n').length.toLocaleString()} lines · HTML source</span></header>
    <pre class="eliya-prompt-text" aria-label="HTML source preview; expand for complete source">${esc(htmlExpanded ? sourceFile.content : htmlPreview.text)}</pre>
    ${htmlPreview.abbreviated ? `<div class="eliya-source-preview-note" role="status" ${htmlExpanded?'hidden':''}>${esc(inlineSourceLabel(htmlPreview))}</div>` : ''}
    ${sourceFile.ready ? '' : `<div class="eliya-prompt-warning" role="status">${esc(sourceFile.reason || 'The HTML file is incomplete.')} Copy is available; a partial file cannot be downloaded as complete.</div>`}
    <div class="eliya-prompt-actions">${htmlPreview.abbreviated ? `<button type="button" class="mini-btn" data-inline-source="${index}" aria-expanded="${htmlExpanded}">${htmlExpanded?'Collapse preview':'Show all inline'}</button>` : ''}<button type="button" class="mini-btn" data-file-copy="${index}">Copy HTML</button>
      ${sourceFile.ready ? `<button type="button" class="mini-btn" data-file-download="${index}">Download .html</button><button type="button" class="mini-btn" data-file-preview="${index}">Preview HTML</button>`
        : `<button type="button" class="mini-btn" data-file-download-partial="${index}">Download partial .html</button><button type="button" class="secondary-btn" data-file-complete="${index}">Complete HTML</button>`}
      <button type="button" class="mini-btn" data-source-full="${index}">Open full source</button>
    </div></article></section>` : '';
  const rendered = (loadingIndicator || (liveViewer || (promptPreview ? promptCards : htmlSource ? htmlViewer
    : MarkdownRenderer.render(displayContent, { streaming: Boolean(message.streaming) })))) + continuation + integrityNote;
  const contentClass = assistant && message.streaming && !loadingIndicator ? 'message-content typing-cursor' : 'message-content';
  const workbookJob = assistant && message.testCaseJob;
  const workbookHtml = workbookJob ? `<section class="eliya-workbook-job" role="status" aria-live="polite">
    <strong>Excel test cases · ${esc(workbookJob.status || 'queued')}</strong>
    <div class="eliya-workbook-progress ${['queued','running'].includes(workbookJob.status) && !(workbookJob.processedChunks > 0) ? 'eliya-workbook-indeterminate' : ''}" aria-label="Document test-case generation progress"><span style="width:${Math.min(100, Math.round(100*(Number(workbookJob.processedChunks||0)/Math.max(1,Number(workbookJob.totalChunks||1)))))}%"></span></div>
    <p>${esc(workbookJob.detail || 'Preparing uploaded documents')}</p>
    <small>${workbookJob.processedChunks || 0}/${workbookJob.totalChunks || '?'} source sections · ${workbookJob.rowCount || 0} test cases${workbookJob.elapsedSeconds != null ? ` · ${workbookJob.elapsedSeconds}s elapsed` : ''}${workbookJob.failedChunks ? ` · ${workbookJob.failedChunks} sections need review` : ''}</small>
    ${workbookJob.downloadReady ? `<button type="button" class="primary-btn" data-workbook-download="${esc(workbookJob.id)}">Download Excel workbook</button>` : ''}
    ${workbookJob.error ? `<div class="chat-integrity-warning">${esc(workbookJob.error)}</div>` : ''}
  </section>` : '';
  const excelAction = assistant && !message.streaming && (hasMarkdownTable(message.content || '') || isExcelRequestedForAssistant(index))
    ? `<button class="mini-btn artifact-btn" type="button" data-excel-msg="${index}">▦ Excel</button>` : '';
  const projectChanges = assistant && !message.streaming ? extractProjectFileChanges(message.content || '') : [];
  // Structured Chat file proposals were previously stripped completely by
  // stripProjectMarkers(), leaving an apparently empty answer. Make them visible
  // and inspectable without silently writing anything to disk.
  const htmlPresentation = assistant && !message.streaming && firstHtmlPresentation(message.content || '');
  const projectFilesHtml = projectChanges.length ? `<section class="proposed-file-panel"><div class="proposed-file-header"><strong>${projectChanges.length} generated file proposal${projectChanges.length === 1 ? '' : 's'}</strong><span>Chat draft · not yet saved to the workspace</span></div><div class="proposed-file-list">${projectChanges.map((file, fileIndex) => `<div class="proposed-file-row"><code>${esc(file.path)}</code><span>${file.operation === 'delete' ? 'Delete proposed' : `${formatCompact(String(file.content || '').length)} chars`}</span>${file.operation !== 'delete' ? `<button type="button" class="agent-file-preview-btn" data-preview-proposed-md="${index}" data-preview-proposed-index="${fileIndex}">Preview</button><button type="button" class="agent-file-preview-btn" data-download-proposed="${index}" data-download-proposed-index="${fileIndex}">Download</button>` : ''}</div>`).join('')}</div><button type="button" class="secondary-btn" data-project-changes="${index}">Review all proposed files</button></section>` : '';
  const requestedFile = assistant && !message.streaming && !requestIsPrompt
    ? window.EliyaResponseArtifacts?.detect(precedingText, displayContent) : null;
  const filePanel = requestedFile?.requested && !htmlSource ? `<section class="eliya-artifact-panel" aria-label="Requested downloadable file">
    <div class="eliya-artifact-summary"><span class="eliya-artifact-icon">▤</span><div><strong>${esc(requestedFile.ready ? requestedFile.filename : `Complete ${requestedFile.requested.toUpperCase()} file required`)}</strong><small>${esc(requestedFile.ready ? 'Complete source · ready to preview or download' : requestedFile.reason)}</small></div></div>
    <div class="eliya-artifact-actions">${requestedFile.ready
      ? `<button type="button" class="mini-btn" data-file-preview="${index}">Preview</button><button type="button" class="primary-btn" data-file-download="${index}">↓ Download .${esc(requestedFile.extension)}</button>`
      : `<button type="button" class="secondary-btn" data-file-complete="${index}">Generate complete file</button>`}</div>
  </section>` : '';
  const archivedFiles = Array.isArray(message.archivedFiles) ? message.archivedFiles : [];
  const archivedIntegrity = Array.isArray(message.archivedIntegrity) ? message.archivedIntegrity : null;
  const archivedHtml = archivedFiles.length ? `<section class="proposed-file-panel"><div class="proposed-file-header"><strong>${archivedFiles.length} saved Chat artifact${archivedFiles.length === 1 ? '' : 's'}</strong><span>Persistent copies · workspace unchanged</span><button type="button" class="agent-file-preview-btn" data-saved-verify="${index}">Check file integrity</button></div><div class="proposed-file-list">${archivedFiles.map(file => {
    const integrity = archivedIntegrity?.find(item=>item.id===file.id);
    const status = integrity ? String(integrity.status||'unknown') : 'not_checked';
    const label = ({verified:'SHA-256 verified',missing:'Missing',size_mismatch:'Size mismatch',checksum_mismatch:'Checksum mismatch',legacy_length_only:'Legacy size-only',invalid_manifest:'Invalid manifest',not_checked:'Not checked'})[status] || 'Unknown';
    return `<div class="proposed-file-row"><code>${esc(file.path)}</code><span>${formatCompact(file.bytes)} bytes</span><span class="eliya-artifact-integrity" data-integrity="${esc(status)}">${esc(label)}</span><button type="button" class="agent-file-preview-btn" data-saved-preview="${index}" data-saved-id="${esc(file.id)}">Preview</button><button type="button" class="agent-file-preview-btn" data-saved-download="${index}" data-saved-id="${esc(file.id)}">Download</button></div>`;
  }).join('')}</div></section>` : '';
  // Contextual follow-up is presentation-only: it never overrides source evidence,
  // adds an approval modal, or triggers a tool. Users answer through the composer.
  const hasVerifiedAgentSuggestion = assistant && message.mode === 'agent' &&
    /\*\*Suggested next step:\*\*/.test(displayContent);
  const suggestion = isLastAssistant && !message.streaming && !isVerification && !requestIsPrompt && !promptResponse && displayContent.trim() && !hasVerifiedAgentSuggestion
    ? (window.EliyaConversationIntelligence?.suggest?.({
        prompt:precedingText, answer:displayContent,
        mode:message.mode === 'agent' ? 'execute' : 'analyse',
        success:!['failed','blocked','cancelled'].includes(String(message.agentProgress?.status||''))
      }) || '') : '';
  const suggestionHtml = suggestion
    ? `<div class="eliya-next-question" role="note"><span class="eliya-next-label">NEXT STEP</span><p>${esc(suggestion)}</p><small>Reply naturally in the message box below.</small></div>` : '';
  const emptyAnswerHtml = assistant && !message.streaming && !displayContent.trim() && !projectChanges.length && !archivedFiles.length
    ? '<div class="chat-integrity-warning" role="status">Eliya did not return an answer for this request. Execution details are preserved below; this is not a verified completion.</div>' : '';
  const projectAction = projectChanges.length
    ? `<button class="mini-btn artifact-btn" type="button" data-project-changes="${index}">⌘ Review ${projectChanges.length} file${projectChanges.length === 1 ? '' : 's'}</button>` : '';
  // A chat verification or acknowledgement is NEVER an implementation authorization.
  // Only the individual prompt cards expose Implement; analysis offers "Generate prompt".
  const handoffAction = '';
  // A plan preview is NOT an executed Agent run. Approval is a distinct user action,
  // sent as a new turn so the backend can consume the exact saved, single-use plan.
  const canApprovePreview = isLastAssistant && assistant && !message.streaming && message.mode === 'agent' &&
    /^## Proposed execution plan\b/m.test(displayContent) &&
    /Awaiting explicit approval\./.test(displayContent) &&
    !/One clarification before execution:/i.test(displayContent) &&
    !['failed','blocked','cancelled'].includes(String(message.agentBackendStatus || message.agentProgress?.status || '').toLowerCase());
  const planApprovalAction = canApprovePreview ? `<section class="eliya-plan-preview-approval" role="group" aria-label="Approve saved Agent plan"><div><strong>Plan awaiting your approval</strong><small>No files have been edited. Check the proposed scope before proceeding.</small></div><button type="button" class="primary-btn" data-approve-conversation-plan="${index}">Approve &amp; execute this plan</button></section>` : '';
  const followupAction = isLastAssistant && assistant && !message.streaming && message.mode === 'agent' &&
    /\*\*Suggested next step:\*\*/.test(displayContent) &&
    !['failed','blocked','cancelled'].includes(String(message.agentBackendStatus || message.agentProgress?.status || '').toLowerCase())
    ? `<button type="button" class="mini-btn agent-next-action" data-agent-next="${index}" title="Ask Agent to perform the exact suggested next action">Continue suggested next step</button>` : '';
  const actions = assistant
    ? `${followupAction}<button class="mini-btn eliya-quiet-copy" type="button" data-copy-msg="${index}" title="Copy answer">Copy</button>
       <details class="eliya-message-more"><summary class="mini-btn" aria-label="Other response actions">More</summary><div class="eliya-message-more-menu">
       
       ${requestedFile?.ready ? `<button class="mini-btn" type="button" data-file-download="${index}">Download ${esc(requestedFile.extension.toUpperCase())}</button>` : ''}
       <button class="mini-btn" type="button" data-full-preview="${index}">Open full response</button>
       <button class="mini-btn" type="button" data-download-msg="${index}">Export Markdown</button>
       <button class="mini-btn" type="button" data-pdf-msg="${index}">Export PDF</button>
       ${htmlPresentation ? `<button class="mini-btn" type="button" data-html-chat-preview="${index}">Preview HTML</button>` : ''}
       ${excelAction}${projectAction}
       ${!message.streaming && message.id ? `<button class="mini-btn" type="button" data-saved-artifacts="${index}">Saved files</button>` : ''}
       ${!message.streaming ? `<button class="mini-btn" type="button" data-confluence-msg="${index}">Confluence</button>` : ''}
       ${isLastAssistant && !message.streaming ? `<button class="mini-btn" type="button" data-regenerate="${index}">Regenerate</button>` : ''}
       </div></details>`
    : `<button class="mini-btn" type="button" data-edit-msg="${index}">Edit</button><button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button>`;

  return `<article class="message ${assistant ? 'assistant' : 'user'}" data-message-index="${index}">
    <div class="avatar">${assistant ? 'AI' : 'You'}</div>
    <div class="message-body">
      ${attachmentHtml(message.attachmentIds)}
      <div class="${contentClass}">${verificationNote}${missingPrompt}${rendered}${workbookHtml}${filePanel}${projectFilesHtml}${archivedHtml}${emptyAnswerHtml}${promptSuggestion}${suggestionHtml}${planApprovalAction}</div>
      ${assistant ? agentStepsHtml(message) : ''}
      <div class="message-actions">${actions}</div>
    </div>
  </article>`;
}

// Preserve disclosure state when status snapshots refresh. Recreating a card must
// never close a user's expanded evidence, plan or execution details.
function uiDisclosureSnapshot(root) {
  return root ? [...root.querySelectorAll('details')].map((node, index) => ({
    index, open: node.open, className: node.className, userToggled: node.dataset.userToggled === 'true'
  })) : [];
}
function uiRestoreDisclosures(root, snapshot) {
  if (!root || !snapshot?.length) return;
  const entries = root.querySelectorAll('details');
  snapshot.forEach(({index, open, className, userToggled}) => {
    const node = entries[index];
    if (!node || node.className !== className) return;
    // Live details opened automatically should close on completion so the answer
    // becomes visible. Explicit user toggles always survive a redraw.
    const isAutoExpansion = node.matches('.agent-run-disclosure,.terminal-execution-history');
    if (!isAutoExpansion || userToggled) node.open = open;
    if (userToggled) node.dataset.userToggled = 'true';
  });
}
document.addEventListener('click', event => {
  const summary = event.target.closest?.('summary');
  const details = summary?.parentElement;
  if (details?.matches('.agent-run-disclosure,.terminal-execution-history')) details.dataset.userToggled = 'true';
});
function uiTerminalAnswerKey(detail) {
  const count = Array.isArray(detail?.turns) ? detail.turns.filter(turn => turn.role === 'user').length : 0;
  return `${detail?.id || ''}:${detail?.runId || 'no-run'}:${count}`;
}
function uiRememberTerminalStream(detail) {
  if (!detail?.id || !detail.answer) return;
  const text = String(detail.answer);
  if (text.trim()) {
    terminalUi.lastVisibleAnswers.set(uiTerminalAnswerKey(detail), text.slice(-600000));
    // Keep at most eight full terminal answer fallbacks; history is saved on the server.
    while (terminalUi.lastVisibleAnswers.size > 8)
      terminalUi.lastVisibleAnswers.delete(terminalUi.lastVisibleAnswers.keys().next().value);
  }
}

// Compact lifecycle ribbon: Analyse and Agent use one truthful status language.
// Missing provider counters and uncertain backend outcomes never become success.
let lastRunAnnouncement='';
function renderRunStatusStrip(){
  const strip=$('runStatusStrip');if(!strip)return;
  const latest=[...state.messages].reverse().find(m=>m.role==='assistant');
  const view=window.EliyaChatExperience144?.stateFor(latest);
  strip.hidden=!view?.show;
  if(!view?.show){
    const dashboard=$('executionDashboard145');
    if(dashboard)dashboard.hidden=true;
    $('runStatusOpen')?.setAttribute('aria-expanded','false');
    return;
  }
  strip.dataset.status=view.status;
  $('runStatusTitle').textContent=view.title;
  $('runStatusPhase').textContent=view.phase;
  $('runStatusDetails').textContent=view.detail||view.stepLabel||(view.agent?'Working in the mapped workspace':'');
  const parts=[view.stepLabel,view.tool&&`Tool: ${view.tool}`,view.agent?view.tokens:''].filter(Boolean);
  $('runStatusMeta').textContent=parts.join(' · ');
  const stop=$('runStatusStop');
  stop.hidden=!view.streaming;
  $('runStatusRetry').hidden=!(latest?.recoveringChat && latest?.recoveryTimedOut);
  const phrase=`${view.title}: ${view.phase}`;
  if(phrase!==lastRunAnnouncement){$('runStatusAnnouncement').textContent=phrase;lastRunAnnouncement=phrase;}
  if(!$('executionDashboard145')?.hidden)renderExecutionDashboard145(latest);
}

// The detailed dashboard is one shared, accessible surface rather than a
// different hidden monitor for each execution mode. It only projects actual
// messages and durable run snapshots; approvals still use the existing gated
// approval handlers, and Analyse never invokes the Agent.
function renderExecutionDashboard145(message){
  const root=$('executionDashboard145'),body=$('executionDashboardBody');
  if(!root||root.hidden||!body)return;
  const data=window.EliyaExecutionDashboard145?.fromMessage(message,window.EliyaChatExperience144);
  if(!data){body.textContent='No current execution is available';return;}
  const chip=(name,value)=>`<div class="eliya-dashboard-metric"><small>${esc(name)}</small><strong>${esc(value)}</strong></div>`;
  const stageRows=data.stages.length?data.stages.map(x=>`<li><span>${esc(x.label)}</span><strong>${esc(x.duration)}</strong></li>`).join(''):
    '<li>Stage timings have not been reported by the backend.</li>';
  const planRows=data.plan.length?data.plan.map(item=>`<li><b>${esc(String(item.number))}.</b><span>${esc(item.title)}${item.note?` <small>${esc(item.note)}</small>`:''}</span><em>${esc(item.status)}</em></li>`).join(''):
    '<li>No persisted plan steps available.</li>';
  const eventRows=data.events.length?data.events.map(item=>`<li><strong>${esc(item.tool)}</strong><span>${esc(item.detail||item.status)}</span><small>${esc(item.status)}</small></li>`).join(''):
    '<li>No tool events recorded for this response.</li>';
  const approvals=data.approvals.map(a=>`<div class="eliya-dashboard-decision"><span>${esc(a.type)} · ${esc(a.detail)}</span><button type="button" class="eliya-run-btn" data-dashboard-approval="${esc(a.id)}">Review approval</button></div>`).join('');
  const question=data.question?`<div class="eliya-dashboard-decision"><span>${esc(data.question.reason)}</span><button type="button" class="eliya-run-btn" data-dashboard-question>Answer in chat</button></div>`:'';
  const markup=`<div class="eliya-dashboard-metrics">${chip('Mode',data.view.agent?'Agent (execution)':'Analyse (read-only)')}${chip('Backend status',data.view.title)}${chip('Elapsed',data.elapsedMs?window.EliyaExecutionDashboard145.duration(data.elapsedMs):'Not reported')}${chip('Provider tokens',data.tokens)}${chip('Artifact verification',data.artifacts)}</div>
  <section class="eliya-dashboard-section"><h3>Current activity</h3><p>${esc(data.view.phase)} · ${esc(data.view.detail||data.view.stepLabel||'No recent status')}</p>
  <p class="eliya-dashboard-caution">${data.view.disconnected?'Connection lost; checking durable backend status.':data.view.verified?'Backend reported completion; inspect the actual verification report for evidence.':data.view.streaming?'Execution is in progress; result is not yet verified.':'Only recorded backend evidence is shown.'}</p>
  ${approvals}${question}
  <p class="eliya-dashboard-hint">${esc(data.usageLabel)}${data.providerLatency?' · Provider latency '+esc(window.EliyaExecutionDashboard145.duration(data.providerLatency))+' (may overlap stages)':''}</p></section>
  <section class="eliya-dashboard-section"><h3>Stage timings</h3><ul class="eliya-dashboard-timings">${stageRows}</ul></section>
  <section class="eliya-dashboard-section"><h3>Plan progress <small>${data.plan.filter(x=>x.status==='completed').length}/${data.plan.length}</small></h3><ol class="eliya-dashboard-plan">${planRows}</ol></section>
  <section class="eliya-dashboard-section"><h3>Recent tool activity <small>${data.events.length} shown</small></h3><ol class="eliya-dashboard-events">${eventRows}</ol></section>
  ${data.failedChecks.length?`<section class="eliya-dashboard-section"><h3>Verification failures</h3><ul>${data.failedChecks.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section>`:''}
  ${data.fileIssues.length?`<section class="eliya-dashboard-section"><h3>Workspace integrity warnings</h3><ul>${data.fileIssues.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></section>`:''}`;
  // A 2-second status poll should not erase selection, keyboard focus or a
  // user's inspection of long tool output when nothing material has changed.
  if(body.__eliyaMarkup145!==markup){
    const active=document.activeElement;
    const focusedAction=body.contains(active)?active?.getAttribute('data-dashboard-approval'):null;
    body.innerHTML=markup;
    body.__eliyaMarkup145=markup;
    if(focusedAction){[...body.querySelectorAll('[data-dashboard-approval]')].find(b=>b.dataset.dashboardApproval===focusedAction)?.focus({preventScroll:true});}
  }
  $('executionDashboardFiles').hidden=!data.runId;
  $('executionDashboardRefresh').hidden=!data.runId&&!message.recoveringChat;
  $('executionDashboardRefresh').disabled=false;
  $('executionDashboardNotice').textContent=data.runId?`Run ${data.runId.slice(0,12)} · status sourced from backend`:
    'Analyse responses use saved conversation records; no model request is repeated.';
}
function showExecutionDashboard145(open){
  const panel=$('executionDashboard145');if(!panel)return;
  panel.hidden=!open;
  $('runStatusOpen')?.setAttribute('aria-expanded',String(open));
  $('runStatusOpen').textContent=open?'Hide dashboard':'Dashboard';
  if(open){renderExecutionDashboard145([...state.messages].reverse().find(m=>m.role==='assistant'));$('executionDashboardTitle')?.focus({preventScroll:true});}
}
$('executionDashboardClose')?.addEventListener('click',()=>{showExecutionDashboard145(false);$('runStatusOpen')?.focus();});
$('executionDashboard145')?.addEventListener('keydown',event=>{
  if(event.key==='Escape'){event.preventDefault();showExecutionDashboard145(false);$('runStatusOpen')?.focus();}
});
$('executionDashboardBody')?.addEventListener('click',event=>{
  const approval=event.target.closest?.('[data-dashboard-approval]');
  if(approval){
    const matching=[...$('messages').querySelectorAll('[data-agent-approval]')].find(btn=>btn.dataset.agentApproval===approval.dataset.dashboardApproval);
    showExecutionDashboard145(false);
    if(matching){const details=matching.closest('details');if(details)details.open=true;matching.scrollIntoView({block:'center'});matching.focus();}
    else toast('Approval is not visible in loaded history. Reopen the saved Agent run.',6000);
  }
  if(event.target.closest?.('[data-dashboard-question]')){
    showExecutionDashboard145(false);$('messageInput')?.focus();
  }
});
$('executionDashboardFiles')?.addEventListener('click',async()=>{
  const message=[...state.messages].reverse().find(m=>m.role==='assistant'&&m.agentRunId);
  if(!message)return;
  const button=$('executionDashboardFiles');button.disabled=true;
  $('executionDashboardNotice').textContent='Checking current workspace against saved file hashes…';
  try{
    message.agentFileIntegrity=await api(`/api/agent/runs/${encodeURIComponent(message.agentRunId)}/file-integrity`);
    renderExecutionDashboard145(message);
    const status=message.agentFileIntegrity?.status||'unknown';
    $('executionDashboardNotice').textContent=status==='intact'?'Workspace files match the sealed task report.':
      `Workspace file check: ${String(status).replaceAll('_',' ')}. Inspect warnings before relying on this run.`;
  }catch(error){
    $('executionDashboardNotice').textContent='Could not verify workspace files: '+String(error?.message||error).slice(0,125);
  }finally{button.disabled=false;}
});
$('executionDashboardRefresh')?.addEventListener('click',async()=>{
  const message=[...state.messages].reverse().find(m=>m.role==='assistant');
  if(!message)return;
  const runId=message.agentRunId;
  const button=$('executionDashboardRefresh');button.disabled=true;
  $('executionDashboardNotice').textContent='Checking saved backend state…';
  try{
    if(!runId){$('runStatusRetry')?.click();return;}
    const snapshot=await api(`/api/agent/runs/${encodeURIComponent(runId)}`);
    message.agentProgress=agentProgressFromSnapshot(snapshot,message.agentProgress);
    message.agentBackendReachable=true;
    message.agentBackendStatus=snapshot.status||'unknown';
    message.agentBackendPolledAt=new Date().toISOString();
    if(snapshot.finishedAt){message.finishedAt=snapshot.finishedAt;message.streaming=false;void fetchAgentCompletionReport(message,true);}
    if(Array.isArray(snapshot.activityEvents))message.agentSteps=mergeDurableAgentActivity(message.agentSteps,snapshot.activityEvents);
    renderMessages();
    $('executionDashboardNotice').textContent='Checked at '+new Date().toLocaleTimeString();
  }catch(error){
    message.agentBackendReachable=false;
    $('executionDashboardNotice').textContent='Cannot confirm server state: '+String(error?.message||error).slice(0,140);
    renderExecutionDashboard145(message);
  }finally{button.disabled=false;}
});
$('runStatusStop')?.addEventListener('click',()=>void stopCurrentRun());
$('runStatusOpen')?.addEventListener('click',()=>showExecutionDashboard145($('executionDashboard145')?.hidden));
$('runStatusRetry')?.addEventListener('click',()=>{
  const id=state.conversationId;
  const pending=id&&pendingChatRecovery(id);
  const placeholder=state.messages.find(m=>m.recoveringChat);
  if(pending&&placeholder)watchRecoveringChat(id,pending,placeholder,true);
});

// Recovery metadata carries only server IDs, never prompt text, model credentials,
// uploaded content or source files. Reopening does NOT re-run the model.
function pendingKey(conversationId){return `llm.pendingChat144.${conversationId}`;}
function pendingChatRecovery(conversationId){
  try{
    // Both stores contain identifiers only; the local mirror survives browser
    // restart. Never store prompts, attachment bytes or credentials here.
    return window.EliyaChatExperience144?.recoveryRecord(JSON.parse(
      storageGet('session',pendingKey(conversationId)) || storageGet('local',pendingKey(conversationId)) || 'null'));
  }
  catch(_){return null;}
}
function markPendingChatRecovery(conversationId,userMessageId){
  if(!conversationId||!userMessageId)return;
  const record={conversationId:String(conversationId),userMessageId:Number(userMessageId),createdAt:Date.now()};
  if(window.EliyaChatExperience144?.recoveryRecord(record)) {
    storageSet('session',pendingKey(conversationId),JSON.stringify(record));
    storageSet('local',pendingKey(conversationId),JSON.stringify(record));
  }
}
function clearPendingChatRecovery(conversationId){
  if(conversationId){storageRemove('session',pendingKey(conversationId));storageRemove('local',pendingKey(conversationId));}
}
let recoveringChatTimer=null;
let recoveringChatBusy=false;
function stopRecoveringChat(){
  if(recoveringChatTimer)clearInterval(recoveringChatTimer);
  recoveringChatTimer=null;
  recoveringChatBusy=false;
}
function watchRecoveringChat(conversationId,marker,placeholder,manual=false){
  stopRecoveringChat();
  placeholder.recoveryTimedOut=false;
  state.activeAgentRunId=null;
  setStreaming(true);
  const ownedMessages=state.messages;
  const started=Date.now();
  const tick=async()=>{
    if(recoveringChatBusy || state.conversationId!==conversationId || state.messages!==ownedMessages){return;}
    recoveringChatBusy=true;
    try{
      const saved=await api(`/api/conversations/${encodeURIComponent(conversationId)}/messages`);
      if(state.messages!==ownedMessages || state.conversationId!==conversationId)return;
      if(!window.EliyaChatExperience144.shouldRecover(marker,saved)){
        stopRecoveringChat();clearPendingChatRecovery(conversationId);setStreaming(false);
        // No new prompt, no duplicated side effects; history is authoritative.
        await openConversation(conversationId);
        return;
      }
      placeholder.chatLoadingStatus='Server response not saved yet · checking again';
      placeholder.chatHealthDetail='Browser reconnected. The server may still be working; completion is not verified.';
    }catch(error){
      if(state.messages!==ownedMessages)return;
      placeholder.chatHealthDetail='Cannot reach the server to confirm completion. Your original prompt will not be resent automatically.';
    }finally{
      recoveringChatBusy=false;
      if(state.messages===ownedMessages){
        updateChatHealthNotice(state.messages.indexOf(placeholder));
        renderRunStatusStrip();
      }
    }
    // A long-running task may be healthy but unobservable. Stop background polling
    // after ten minutes and let the user explicitly check again.
    if(Date.now()-started>=600_000){
      stopRecoveringChat();placeholder.recoveryTimedOut=true;
      placeholder.chatHealthDetail='No saved answer found after repeated checks. Outcome is unknown; check again or explicitly stop.';
      renderMessages();
    }
  };
  void tick();
  recoveringChatTimer=setInterval(()=>void tick(),manual?2500:3000);
}

function renderMessages() {
  const target = $('messages');
  // Diff reconciliation manages message nodes only. Remove the temporary
  // loading placeholder once durable history is available, or it leaves a
  // permanent empty gap above the conversation after refresh/navigation.
  target.querySelectorAll('.history-loading').forEach(node=>node.remove());
  const visibleStart = Math.max(0, Math.min(state.visibleMessageStart || 0, state.messages.length));
  const earlierWrap=$('earlierMessagesWrap');
  if (earlierWrap) {
    earlierWrap.hidden = visibleStart===0;
    $('earlierMessagesCount').textContent = visibleStart ? `${visibleStart} earlier message${visibleStart===1?'':'s'} available` : '';
  }
  const scrollArea = $('chatView');
  const awayFromBottom = scrollArea && scrollArea.scrollHeight - scrollArea.scrollTop - scrollArea.clientHeight > 140;
  const oldScroll = scrollArea?.scrollTop || 0;
  // An open code viewer or a resized earlier message must not yank readers
  // to the beginning of a long conversation after reconciliation.
  const viewportTop = scrollArea?.getBoundingClientRect().top || 0;
  const readingAnchor = awayFromBottom ? [...target.children].find(node =>
    node.classList?.contains('message') && node.getBoundingClientRect().bottom > viewportTop + 12) : null;
  const anchorIndex = readingAnchor?.dataset.messageIndex;
  const anchorTop = readingAnchor?.getBoundingClientRect().top - viewportTop;
  // Reconcile stable messages individually. Streaming appends no longer destroy
  // completed answers, text selection, open disclosures or unrelated DOM nodes.
  const visibleMessages=state.messages.slice(visibleStart);
  const display=(message,index)=>messageHtml(message,index+visibleStart);
  if (window.EliyaRenderDiff) window.EliyaRenderDiff.reconcile(target, visibleMessages, display);
  else target.innerHTML = visibleMessages.map(display).join('');
  if (awayFromBottom && scrollArea) {
    const nextAnchor=anchorIndex==null ? null : [...target.children].find(node => node.dataset.messageIndex === anchorIndex);
    if(nextAnchor && Number.isFinite(anchorTop))
      scrollArea.scrollTop += (nextAnchor.getBoundingClientRect().top - viewportTop) - anchorTop;
    else scrollArea.scrollTop = oldScroll;
  }
  for(let i=visibleStart;i<state.messages.length;i++)
    if(state.messages[i].chatHealthDetail) updateChatHealthNotice(i);
  $('welcome').classList.toggle('hidden', state.messages.length > 0);
  renderRunStatusStrip();
  updateContextBadge();
  refreshAgentQuestionComposer();
  refreshDeletionApprovalModal();
  if (state.editingIndex != null) {
    requestAnimationFrame(() => {
      const input = $('editMessageInput');
      if (input) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
    });
  }
}


function refreshAgentCard(index) {
  const article = $('messages')?.querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const html = agentStepsHtml(message);
  const existing = article.querySelector('.agent-run-card');
  const expandedState = uiDisclosureSnapshot(existing);
  if (!html) { existing?.remove(); return; }
  const holder = document.createElement('div');
  holder.innerHTML = html;
  const next = holder.firstElementChild;
  if (!next) return;
  if (existing) existing.replaceWith(next);
  else article.querySelector('.message-body')?.insertBefore(next, article.querySelector('.message-content'));
  uiRestoreDisclosures(next, expandedState);
  refreshDeletionApprovalModal();
  refreshAgentQuestionComposer();
}

function scheduleAgentRender(index) {
  if (state.agentRenderTimer) return;
  state.agentRenderTimer = setTimeout(() => {
    state.agentRenderTimer = null;
    refreshAgentCard(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, AGENT_RENDER_THROTTLE_MS);
}

function eliElapsedMs(startedAt, finishedAt, serverElapsedMs) {
  const server = Number(serverElapsedMs);
  const begin = Date.parse(startedAt || '');
  const end = finishedAt ? Date.parse(finishedAt) : Date.now();
  if (Number.isFinite(begin) && Number.isFinite(end)) return Math.max(0,end-begin);
  return Number.isFinite(server) ? Math.max(0,server) : 0;
}
function eliDuration(ms) {
  const seconds = Math.floor(Math.max(0,ms)/1000);
  const h = Math.floor(seconds/3600), m = Math.floor((seconds%3600)/60), s = seconds%60;
  return h ? `${h}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`
    : m ? `${m}m ${String(s).padStart(2,'0')}s` : `${s}s`;
}
function eliRunTimeLabel(record, progress = record.agentProgress || {}) {
  const start = progress.startedAt || record.startedAt || record.createdAt;
  const finish = progress.finishedAt || record.finishedAt;
  const active = record.streaming === true || ['running','queued','waiting_workspace','cancelling','needs_input','starting'].includes(String(record.status || progress.status || ''));
  return start ? `${!finish && active ? 'Elapsed' : 'Total time'} ${eliDuration(eliElapsedMs(start, finish, progress.elapsedMs))}` : '';
}
function agentProgressFromSnapshot(snapshot, existing = {}) {
  return {
    ...(existing || {}),
    percent: Number(snapshot?.progressPercent ?? existing?.percent ?? 0),
    indeterminate: Boolean(snapshot?.progressIndeterminate ?? existing?.indeterminate),
    estimated: Boolean(snapshot?.progressEstimated ?? existing?.estimated),
    observedActions: Number(snapshot?.observedActions ?? existing?.observedActions ?? 0),
    startedAt: snapshot?.startedAt || existing?.startedAt || '',
    finishedAt: snapshot?.finishedAt || existing?.finishedAt || '',
    elapsedMs: Number(snapshot?.elapsedMs ?? existing?.elapsedMs ?? 0),
    phase: snapshot?.progressPhase || snapshot?.status || existing?.phase || 'working',
    detail: snapshot?.progressDetail || existing?.detail || '',
    status: snapshot?.status || existing?.status || 'running',
    question: snapshot?.question || {},
    responsePersisted: Boolean(snapshot?.responsePersisted),
    tokenUsage: snapshot?.tokenUsage || existing?.tokenUsage || {},
    activeModel: snapshot?.activeModel || existing?.activeModel || '',
    modelPool: Array.isArray(snapshot?.modelPool) ? snapshot.modelPool : (existing?.modelPool || []),
    modelFailovers: Number(snapshot?.modelFailovers || 0),
    recoveryReplans: Number(snapshot?.recoveryReplans || 0),
    lastRecoveryAnalysis: snapshot?.lastRecoveryAnalysis || existing?.lastRecoveryAnalysis || '',
    activePlanIndex: Number(snapshot?.activePlanIndex || 0),
    planLocked: Boolean(snapshot?.planLocked),
    plan: Array.isArray(snapshot?.plan) ? snapshot.plan : (existing?.plan || []),
    lastActivityAt: snapshot?.lastActivityAt || existing?.lastActivityAt || '',
    totalToolActions: Number(snapshot?.totalToolActions || existing?.totalToolActions || 0),
    planValidationStatus: snapshot?.planValidationStatus || existing?.planValidationStatus || 'not_run',
    planValidationSummary: snapshot?.planValidationSummary || existing?.planValidationSummary || '',
    largeTaskMode: Boolean(snapshot?.largeTaskMode ?? existing?.largeTaskMode),
    workItemSummary: snapshot?.workItemSummary || existing?.workItemSummary || {},
    workItems: Array.isArray(snapshot?.workItems) ? snapshot.workItems : (existing?.workItems || []),
    verificationFailures: Array.isArray(snapshot?.verificationFailures) ? snapshot.verificationFailures : (existing?.verificationFailures || []),
    documentationMode: Boolean(snapshot?.documentationMode ?? existing?.documentationMode),
    documentationCoverageComplete: Boolean(snapshot?.documentationCoverageComplete ?? existing?.documentationCoverageComplete),
    documentationValidated: Boolean(snapshot?.documentationValidated ?? existing?.documentationValidated),
    documentationCoverageSummary: snapshot?.documentationCoverageSummary || existing?.documentationCoverageSummary || '',
    documentationValidationSummary: snapshot?.documentationValidationSummary || existing?.documentationValidationSummary || ''
  };
}

function chatLoadingHtml(message) {
  return `<div class="chat-loading" role="status" aria-live="polite"><span class="chat-loading-spinner" aria-hidden="true"></span><span class="chat-loading-label">${esc(message.chatLoadingStatus || 'Preparing your answer…')}</span><span class="chat-loading-dots" aria-hidden="true"><i></i><i></i><i></i></span></div>`;
}

function updateChatHealthNotice(index){
  const message=state.messages[index];
  const article=$('messages')?.querySelector(`[data-message-index="${index}"]`);
  const body=article?.querySelector('.message-body');
  if(!body)return;
  let notice=body.querySelector('.eliya-chat-health-warning');
  if(!message?.streaming || !message?.chatHealthDetail){notice?.remove();return;}
  if(!notice){
    notice=document.createElement('div');
    notice.className='eliya-chat-health-warning';
    notice.setAttribute('role','status');
    body.insertBefore(notice,body.querySelector('.message-actions'));
  }
  notice.replaceChildren();
  const summary=document.createElement('span');
  summary.textContent=message.chatHealthDetail;
  notice.appendChild(summary);
  if(Date.now()-(message.chatLastProgressAt||Date.now())>=180_000){
    const button=document.createElement('button');
    button.type='button';button.className='mini-btn';
    button.dataset.stopUnresponsiveChat='true';button.textContent='Stop and keep partial output';
    notice.appendChild(button);
  }
}

function updateStreamingMessage(index) {
  const article = $('messages').querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const content = article.querySelector('.message-content');
  if (!content) return;
  const text = stripProjectMarkers(message.content || '');
  const isLoading = message.mode !== 'agent' && message.streaming && !text.trim();
  const continuation = message.mode === 'chat' && message.streaming && message.chatContinuationDetail
    ? `<div class="chat-continuation" role="status">↪ ${esc(message.chatContinuationDetail)}</div>` : '';
  // ELIYA139: a prompt or generated HTML document is ONE dark source viewer
  // from the first chunk onward. Append to a text node without reparsing 1,000+
  // lines of Markdown or executing any HTML. Preserve the user's scroll location.
  const sourceQuestion=previousUserMessage(index)?.content || '';
  const source=window.EliyaResponseArtifacts?.sourceView?.(sourceQuestion,text,true);
  if(message.streaming && source && (source.kind==='prompt'||source.kind==='html') && !isLoading){
    let viewer=content.querySelector('.eliya-stream-source');
    if(!viewer){
      content.innerHTML=`<section class="eliya-prompts eliya-source-flow"><article class="eliya-prompt-card eliya-stream-source"><header><strong></strong><span class="eliya-stream-size" role="status"></span></header><pre class="eliya-prompt-text" aria-label="Streaming full source"></pre><div class="eliya-prompt-actions"><button type="button" class="mini-btn" data-live-source-full="${index}">Expand</button><button type="button" class="mini-btn" data-live-source-copy="${index}">Copy current text</button><button type="button" class="mini-btn" data-live-source-download="${index}">Save partial draft</button></div></article></section>`;
      viewer=content.querySelector('.eliya-stream-source');
    }
    const pre=viewer.querySelector('pre');
    // Initial streamed source is already in the <pre> from messageHtml().
    // Starting at zero used to append the ENTIRE answer to that existing text,
    // duplicating the initial chunk and making large prompts appear corrupted.
    const prior=pre.hasAttribute('data-rendered-chars')
      ? Number(pre.dataset.renderedChars) : pre.textContent.length;
    const atBottom=pre.scrollTop+pre.clientHeight>=pre.scrollHeight-36;
    const rawNode=pre.firstChild?.nodeType===3 ? pre.firstChild : null;
    const tailStart=Math.max(0,prior-128);
    const appendOnly=rawNode && rawNode.length===prior && prior<=source.content.length &&
      rawNode.data.slice(tailStart,prior)===source.content.slice(tailStart,prior);
    if(appendOnly){
      rawNode.appendData(source.content.slice(prior));
    }else pre.textContent=source.content;
    pre.dataset.renderedChars=String(source.content.length);
    viewer.querySelector('strong').textContent=source.kind==='prompt'?'Markdown prompt · generating':'HTML source · generating';
    viewer.querySelector('.eliya-stream-size').textContent=source.content.length.toLocaleString()+' characters · streaming';
    if(atBottom)pre.scrollTop=pre.scrollHeight;
    content.classList.add('typing-cursor');
    updateContextBadge();
    return;
  }
  // Long analyses should not reparse and rebuild 30k+ characters of Markdown on every token.
  // Use an incremental text node during streaming, then render the complete Markdown once on done.
  if (message.streaming && text.length > 24_000 && !continuation && !isLoading) {
    let node = content.querySelector('.streaming-plain');
    const previous = Number(content.dataset.streamingRenderedChars || 0);
    if (!node || previous > text.length || !text.startsWith(node.textContent || '')) {
      content.replaceChildren();
      node = document.createElement('div');
      node.className = 'streaming-plain';
      node.textContent = text;
      content.appendChild(node);
    } else {
      node.firstChild?.appendData(text.slice(previous));
    }
    content.dataset.streamingRenderedChars = String(text.length);
  } else {
    content.innerHTML = (isLoading ? chatLoadingHtml(message) : MarkdownRenderer.render(text, { streaming: true })) + continuation;
    delete content.dataset.streamingRenderedChars;
  }
  content.classList.toggle('typing-cursor', !isLoading);
  updateContextBadge();
  renderRunStatusStrip();
}


function updateAgentProgressUi(index) {
  const article = $('messages')?.querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return;
  const card = article.querySelector('.agent-run-card');
  if (!card) { renderMessages(); return; }
  const progress = message.agentProgress || {};
  const pct = Math.max(0, Math.min(100, Number(progress.percent ?? (message.streaming ? 2 : 100))));
  const phase = String(progress.phase || (message.streaming ? 'working' : 'completed')).replaceAll('_', ' ');
  const detail = progress.detail || (message.streaming ? 'Agent is working' : 'Task completed');
  const phaseEl = card.querySelector('.agent-progress-top strong');
  const pctEl = card.querySelector('.agent-progress-percent');
  const fillEl = card.querySelector('.agent-progress-fill');
  const detailEl = card.querySelector('.agent-progress-detail');
  const liveDetailEl = card.querySelector('.agent-live-detail');
  const liveAgeEl = card.querySelector('.agent-live-age');
  if (phaseEl) phaseEl.textContent = phase;
  const unknownOpenCode = Boolean(progress.indeterminate || (message.executionEngine === 'opencode' && message.streaming && pct === 0));
  if (pctEl) pctEl.textContent = unknownOpenCode ? 'Working · % unavailable' : `${Math.round(pct)}%${progress.estimated && message.streaming ? ' est.' : ''}`;
  for (const runtimeDuration of card.querySelectorAll('[data-agent-elapsed]'))
    runtimeDuration.textContent = eliRunTimeLabel(message,progress);
  if (fillEl) {
    fillEl.style.width = unknownOpenCode ? '15%' : `${pct}%`;
    fillEl.classList.toggle('active', Boolean(message.streaming && pct < 100));
  }
  if (detailEl) detailEl.textContent = detail;
  if (liveDetailEl) liveDetailEl.textContent = detail;
  if (liveAgeEl) liveAgeEl.textContent = activityAgeText(progress.lastActivityAt, Boolean(message.streaming || progress.status === 'running'));
  const backendStatusEl = card.querySelector('[data-agent-backend-status]');
  const connectionStatusEl = card.querySelector('[data-agent-connection-status]');
  const currentStepEl = card.querySelector('[data-agent-current-step]');
  const lastBackendActivityEl = card.querySelector('[data-agent-last-activity]');
  const runtimeStatusEl = card.querySelector('[data-agent-runtime-status]');
  const backendRaw = String(message.agentBackendStatus || progress.status || (message.streaming ? 'running' : 'unknown')).trim().toLowerCase();
  const streamState = String(message.agentConnectionStatus || (message.streaming ? 'connecting' : 'closed')).trim().toLowerCase();
  const backendReachable = message.agentBackendReachable;
  let connectionLabel;
  if (streamState === 'connected') connectionLabel = backendReachable === false ? 'Stream connected · backend status unavailable' : 'Stream connected · backend reachable';
  else if (streamState === 'disconnected') connectionLabel = backendReachable === false ? 'Stream disconnected · retrying backend status' : 'Stream disconnected · polling backend';
  else if (streamState === 'recovering') connectionLabel = backendReachable === false ? 'Recovering · backend unreachable' : 'Recovering · backend reachable';
  else if (streamState === 'connecting') connectionLabel = backendReachable === false ? 'Connecting · backend status unavailable' : 'Connecting';
  else connectionLabel = backendReachable === false ? 'Closed · backend status unavailable' : 'Closed';
  if (backendStatusEl) backendStatusEl.textContent = (backendRaw || 'unknown').replaceAll('_', ' ').toUpperCase();
  if (connectionStatusEl) connectionStatusEl.textContent = connectionLabel;
  if (currentStepEl) { currentStepEl.textContent = detail || 'Preparing agent run'; currentStepEl.title = detail || ''; }
  if (lastBackendActivityEl) lastBackendActivityEl.textContent = activityAgeText(progress.lastActivityAt, Boolean(message.streaming || progress.status === 'running')) || 'Unknown';
  if (runtimeStatusEl) {
    runtimeStatusEl.classList.toggle('reachable', backendReachable === true);
    runtimeStatusEl.classList.toggle('unreachable', backendReachable === false);
    runtimeStatusEl.classList.toggle('checking', backendReachable == null);
  }
  const track = card.querySelector('.agent-progress-track');
  if (track) {
    if (unknownOpenCode) track.removeAttribute('aria-valuenow');
    else track.setAttribute('aria-valuenow', String(Math.round(pct)));
  }
  const usage = progress.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const compactions = Number(usage.compactions || 0);
  const pruned = Number(usage.prunedObservations || 0);
  const saved = Number(usage.estimatedTokensSavedByPruning || 0) + Number(usage.estimatedTokensSavedByCompaction || 0);
  const cacheHit = Number(usage.cacheHitPercent || 0);
  let tokenText = '';
  if (contextNow) tokenText += `Context ~${formatCompact(contextNow)}${contextWindow ? ` / ${formatCompact(contextWindow)}` : ''}`;
  // Do not render an empty token line for OpenCode: a missing provider report
  // is operationally different from a measured zero-token execution.
  if (usage.providerReported === true) {
    tokenText += `${tokenText ? ' · ' : ''}Run tokens ${formatCompact(providerTotal)}`;
  } else if (message.executionEngine === 'opencode') {
    const status = message.streaming ? 'Awaiting provider token counters' : 'Provider tokens not reported';
    tokenText += `${tokenText ? ' · ' : ''}${status}`;
  } else if (providerTotal) tokenText += `${tokenText ? ' · ' : ''}Run tokens ${formatCompact(providerTotal)}`;
  if (compactions) tokenText += `${tokenText ? ' · ' : ''}${compactions} compaction${compactions === 1 ? '' : 's'}`;
  if (pruned) tokenText += `${tokenText ? ' · ' : ''}${pruned} pruned`;
  if (saved) tokenText += `${tokenText ? ' · ' : ''}~${formatCompact(saved)} active tokens saved`;
  if (cacheHit > 0) tokenText += `${tokenText ? ' · ' : ''}cache ${cacheHit.toFixed(0)}%`;
  let tokenEl = card.querySelector('.agent-token-line');
  if (tokenText && !tokenEl) {
    tokenEl = document.createElement('div');
    tokenEl.className = 'agent-token-line';
    card.querySelector('.agent-progress')?.appendChild(tokenEl);
  }
  if (tokenEl) { tokenEl.textContent = tokenText; tokenEl.classList.toggle('hidden', !tokenText); }
  renderRunStatusStrip();
}

const streamingRenderTimers = new Map();
function cancelStreamingRenders() {
  for (const timer of streamingRenderTimers.values()) clearTimeout(timer);
  streamingRenderTimers.clear();
  state.renderTimer = null;
}
function scheduleStreamingRender(index) {
  if (streamingRenderTimers.has(index)) return;
  // Rendering the entire Markdown document at 45ms intervals becomes increasingly expensive
  // for 20k-100k character analyses. Throttle progressively, but preserve the fast path for
  // normal short Chat replies and always render the final persisted answer on completion.
  const size = String(state.messages[index]?.content || '').length;
  const delay = size > 80_000 ? 650 : size > 32_000 ? 320 : size > 12_000 ? 140 : 45;
  const conversation=state.conversationId;
  const timer = setTimeout(() => {
    streamingRenderTimers.delete(index);
    if(state.conversationId!==conversation || !state.messages[index]?.streaming) return;
    updateStreamingMessage(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, delay);
  streamingRenderTimers.set(index,timer);
}

function nearBottom() {
  const view = $('chatView');
  return view.scrollHeight - view.scrollTop - view.clientHeight < 180;
}

let chatScrollFrame = 0;
let chatScrollForce = false;
function scrollBottom(force = false) {
  if (!force && state.userScrolledUp) return;
  chatScrollForce = chatScrollForce || force;
  if(chatScrollFrame) return; // at most one layout/scroll per animation frame
  chatScrollFrame = requestAnimationFrame(() => {
    chatScrollFrame = 0;
    const shouldForce = chatScrollForce;
    chatScrollForce = false;
    if (!shouldForce && state.userScrolledUp) return; // reader may have scrolled meanwhile
    const view=$('chatView');
    if(!view)return;
    view.scrollTop = view.scrollHeight;
    if (shouldForce) state.userScrolledUp = false;
    updateScrollButton();
  });
}

function updateScrollButton() {
  $('scrollBottomBtn').classList.toggle('hidden', nearBottom());
}

function setStreaming(value) {
  state.streaming = value;
  refreshChatComposer();
  refreshAgentQuestionComposer();
  $('attachBtn').disabled = value;
  refreshAgentModelStrip();
  refreshChatModelPicker();
  refreshChatVisionPicker();
  renderRunStatusStrip();
}

let stopRequestPending144=false;
async function stopCurrentRun() {
  if(stopRequestPending144)return;
  stopRequestPending144=true;
  const button=$('runStatusStop');
  if(button) {button.disabled=true; button.textContent='Requesting stop…';}
  const runId=state.activeAgentRunId;
  const chatConversation=state.conversationId;
  const activeMessage=[...state.messages].reverse().find(item => item.role==='assistant' && item.streaming);
  let confirmed=false;
  try {
    if(runId) {
      const runMessage=state.messages.find(item=>item.agentRunId===runId)||activeMessage;
      const openCode=runMessage?.executionEngine==='opencode';
      const endpoint=openCode
        ? `/api/terminal/sessions/${encodeURIComponent(runId)}/cancel`
        : `/api/agent/runs/${encodeURIComponent(runId)}/cancel`;
      const result=await api(endpoint,{method:'POST'});
      confirmed=openCode ? result?.status==='cancelled' : result?.cancelled===true;
      if(runMessage?.mode==='agent') {runMessage.agentStopRequested=true;runMessage.agentStopConfirmed=confirmed;}
      if(!confirmed)toast(result?.error||'Stop was requested but the Agent backend has not confirmed cancellation. Check run status.',8000);
      // The durable Agent monitor is authoritative; do not mark it completed or cancelled locally.
    } else if(activeMessage?.mode==='agent') {
      activeMessage.agentStopRequested=true;
      activeMessage.agentStopConfirmed=false;
      toast('The Agent run ID is not available yet. Local streaming will stop; reopen the conversation to check whether server execution continued.',8000);
    } else if(chatConversation) {
      const result=await api(`/api/chat/cancel?conversationId=${encodeURIComponent(chatConversation)}`,{method:'POST'});
      confirmed=result?.cancelled===true;
      if(activeMessage?.mode==='chat') {
        activeMessage.chatStopRequested=true;
        activeMessage.chatStopConfirmed=confirmed;
      }
      if(!confirmed)toast('The Chat backend did not confirm cancellation. The server may still finish. Reopen the conversation to check.',8000);
    }
  } catch(error) {
    if(activeMessage?.mode==='chat') {
      activeMessage.chatStopRequested=true;
      activeMessage.chatStopConfirmed=false;
    } else if(activeMessage?.mode==='agent') {
      activeMessage.agentStopRequested=true;
      activeMessage.agentStopConfirmed=false;
    }
    toast(`Stop could not be confirmed: ${error?.message||error}. Local streaming will close; check saved results later.`,8000);
  } finally {
    // Stop only the current client's stream. The Agent watcher (or saved-chat
    // recovery pointer) must remain available if backend cancellation is unverified.
    state.abortController?.abort();
    if(activeMessage?.recoveringChat) {
      // Stop repeated recovery checks, not the saved-data pointer. The user can
      // reopen the conversation later without replaying an already sent prompt.
      stopRecoveringChat();
      activeMessage.recoveringChat=false;
      activeMessage.streaming=false;
      setStreaming(false);
      renderMessages();
    }
    stopRequestPending144=false;
    if(button) {button.disabled=false;button.textContent='Stop';}
    renderRunStatusStrip();
  }
}

function stopAgentWatch() {
  if (state.agentWatchTimer) clearInterval(state.agentWatchTimer);
  state.agentWatchTimer = null;
}

function mergeDurableAgentActivity(existingSteps, durableSteps) {
  const existing = Array.isArray(existingSteps) ? existingSteps : [];
  const durable = Array.isArray(durableSteps) ? durableSteps : [];
  if (!durable.length) return existing;

  // Durable run state is authoritative for history, but live SSE can briefly be ahead of polling.
  // Preserve richer live metadata (especially approvalId) when the same event is present in both streams.
  const keyOf = step => [
    Number(step?.step || 0),
    String(step?.tool || ''),
    String(step?.status || ''),
    String(step?.detail || ''),
    String(step?.output || '')
  ].join('\u001f');
  const liveByKey = new Map();
  for (const step of existing) {
    const key = keyOf(step);
    const bucket = liveByKey.get(key) || [];
    bucket.push(step);
    liveByKey.set(key, bucket);
  }
  const merged = durable.map(step => {
    const bucket = liveByKey.get(keyOf(step));
    const live = bucket?.shift();
    if (!live) return {...step};
    return {
      ...live,
      ...step,
      approvalId: step.approvalId || live.approvalId || undefined,
      approvalType: step.approvalType || live.approvalType || undefined,
      approvalExpiresAt: step.approvalExpiresAt || live.approvalExpiresAt || undefined,
      args: step.args ?? live.args,
      output: step.output ?? live.output
    };
  });

  // If SSE delivered a newer event while this polling request was in flight, do not erase it.
  const durableCounts = new Map();
  for (const step of durable) {
    const key = keyOf(step);
    durableCounts.set(key, (durableCounts.get(key) || 0) + 1);
  }
  const seen = new Map();
  for (const step of existing) {
    const key = keyOf(step);
    const index = (seen.get(key) || 0) + 1;
    seen.set(key, index);
    if (index > (durableCounts.get(key) || 0)) merged.push({...step});
  }
  return merged;
}

function startAgentWatch(runId, assistant, assistantIndex) {
  stopAgentWatch();
  // A late polling response must never update a different tab after navigation.
  const ownedMessages = state.messages;
  const stillSelected = () => state.messages === ownedMessages && state.activeAgentRunId === runId;
  state.agentWatchdogCompleted = false;
  let polling = false;
  const tick = async () => {
    if (polling || !runId) return;
    polling = true;
    try {
      if (!stillSelected()) return;
      const isOpenCode = assistant.executionEngine === 'opencode';
      const raw = await api(isOpenCode ? `/api/terminal/sessions/${encodeURIComponent(runId)}`
        : `/api/agent/runs/${encodeURIComponent(runId)}`);
      if (!stillSelected()) return;
      const snapshot = isOpenCode ? { ...raw,
        progressPercent: raw.progress?.progressPercent ?? 0,
        progressPhase: raw.progress?.progressPhase || raw.status,
        progressDetail: ['failed','stalled','cancelled','interrupted'].includes(raw.status) && raw.error
          ? String(raw.error) : raw.progress?.progressDetail || 'OpenCode is working',
        lastActivityAt: raw.updatedAt,
        progressIndeterminate: Boolean(raw.progress?.indeterminate),
        progressEstimated: Boolean(raw.progress?.estimated),
        observedActions: raw.progress?.observedActions ?? 0,
        startedAt:raw.startedAt || raw.createdAt, finishedAt:raw.finishedAt,
        elapsedMs:raw.elapsedMs,
        tokenUsage: raw.usage || {},
        question: raw.question || {},
        activityEvents: (raw.events || []).filter(event => event.type === 'agent_step').map(event => ({
          ...(event.data || {}), timestamp: raw.updatedAt, step: event.data?.step || String(event.seq) })),
        finishedAt: ['completed','failed','cancelled','interrupted','stalled'].includes(raw.status) ? raw.updatedAt : null,
        finalAnswer: raw.answer || '',
        error: raw.error || '',
        lastRemoteStatus: raw.lastRemoteStatus || ''
      } : raw;
      assistant.agentBackendReachable = true;
      assistant.agentBackendStatus = snapshot.status || assistant.agentBackendStatus || 'running';
      assistant.agentBackendPolledAt = new Date().toISOString();
      assistant.agentProgress = agentProgressFromSnapshot(snapshot, assistant.agentProgress);
      assistant.startedAt = snapshot.startedAt || snapshot.createdAt || assistant.startedAt;
      if (snapshot.finishedAt) assistant.finishedAt = snapshot.finishedAt;
      if (Array.isArray(snapshot.activityEvents)) {
        assistant.agentSteps = mergeDurableAgentActivity(assistant.agentSteps, snapshot.activityEvents);
        assistant.agentEventTotal = assistant.agentSteps.length;
      }
      const orchestrationFingerprint = JSON.stringify([assistant.agentProgress.phase, assistant.agentProgress.planValidationStatus, assistant.agentProgress.activeModel, assistant.agentProgress.modelFailovers, assistant.agentProgress.recoveryReplans, assistant.agentProgress.activePlanIndex, assistant.agentProgress.workItemSummary, assistant.agentProgress.verificationFailures, assistant.agentProgress.question, assistant.agentProgress.plan.map(item => [item.index, item.status, item.note, item.evidence]), assistant.agentEventTotal, assistant.agentConnectionStatus, assistant.agentBackendReachable, assistant.agentBackendStatus,
        assistant.agentProgress.tokenUsage?.providerTotalTokens,assistant.agentProgress.tokenUsage?.usageStatus,
        assistant.agentProgress.tokenUsage?.modelCalls]);
      if (assistant.agentOrchestrationFingerprint !== orchestrationFingerprint) {
        assistant.agentOrchestrationFingerprint = orchestrationFingerprint;
        renderMessages();
      } else {
        updateAgentProgressUi(assistantIndex);
      }

      if (snapshot.finishedAt) {
        if (isOpenCode && snapshot.status === 'completed' && !assistant.serverDone
            && assistant.agentConnectionStatus === 'connected') {
          assistant.agentProgress.detail = 'OpenCode finished; collecting the final verified report';
          updateAgentProgressUi(assistantIndex);
          return;
        }
        const remoteFailure = isOpenCode && ['failed','stalled','cancelled','interrupted'].includes(snapshot.status);
        const remoteFailureReason = String(snapshot.error || snapshot.lastRemoteStatus || '').trim();
        if (typeof snapshot.finalAnswer === 'string' && snapshot.finalAnswer.trim()) {
          const answer = snapshot.finalAnswer;
          applyCompletedChatMessage(assistant, { content: remoteFailure && remoteFailureReason
            ? `${answer}\n\n**OpenCode ${snapshot.status}:** ${remoteFailureReason}` : answer });
        } else if (remoteFailure) {
          assistant.content = `**OpenCode ${String(snapshot.status).replaceAll('_',' ')}.**\n\n`
            + (remoteFailureReason || 'OpenCode did not provide a terminal explanation. Check its provider/model and backend session status.')
            + '\n\nNo workspace changes have been confirmed. You can inspect the detailed execution report.';
        } else if (!assistant.content.trim()) {
          assistant.content = `Agent run ended with backend status **${String(snapshot.status || 'finished').replaceAll('_', ' ')}** without a visible final response. Open the detailed report to inspect actual workspace changes.`;
        }
        assistant.streaming = false;
        void fetchAgentCompletionReport(assistant);
        state.agentWatchdogCompleted = true;
        renderMessages();
        stopAgentWatch();
        if (assistant.agentConnectionStatus === 'disconnected' || assistant.agentConnectionStatus === 'recovering') {
          setStreaming(false);
          if (state.activeAgentRunId === runId) state.activeAgentRunId = null;
          state.abortController = null;
          toast(`Backend run ${String(snapshot.status || 'completed').replaceAll('_', ' ')} after stream interruption`, 5000);
        } else {
          // The durable run state is authoritative. If the HTTP/SSE stream fails to close after the terminal
          // response was persisted, end only the stale transport; do not ask the user to press Stop.
          setTimeout(() => {
            if (state.streaming && !assistant.serverDone && state.activeAgentRunId === runId) state.abortController?.abort();
          }, 900);
        }
      }
    } catch (_) {
      if (stillSelected()) {
        assistant.agentBackendReachable = false;
        assistant.agentBackendPolledAt = new Date().toISOString();
        updateAgentProgressUi(assistantIndex);
      }
    }
    finally { polling = false; }
  };
  tick();
  state.agentWatchTimer = setInterval(tick, 850);
}

function activeAgentClarification() {
  if (state.mode !== 'agent') return null;
  for (let i = state.messages.length - 1; i >= 0; i--) {
    const message = state.messages[i];
    const question = message?.agentProgress?.question || {};
    if (message?.agentRunId && question.kind === 'clarification' && question.id &&
        !['completed','failed','blocked','interrupted','cancelled','stalled'].includes(String(message.agentProgress?.status || '')))
      return {runId:message.agentRunId, questionId:question.id, message};
  }
  return null;
}
function refreshAgentQuestionComposer() {
  const pending = activeAgentClarification();
  // Even while the current Agent stream is active, its question needs an ordinary
  // Send button and the same Enter key behavior as the rest of the conversation.
  $('sendBtn').classList.toggle('hidden', Boolean(state.streaming && !pending));
  $('stopBtn').classList.toggle('hidden', !state.streaming);
  $('messageInput').placeholder = pending ? 'Answer Eliya here and press Enter' : 'Message ELIYA';
  $('sendBtn').setAttribute('aria-label', pending ? 'Send answer to Eliya' : 'Send');
}
async function submitAgentChatAnswer(answer, pending) {
  const response = String(answer || '').trim();
  if (!response || !pending) return false;
  // The server records this reply in the conversation after accepting the question answer.
  const isOpenCode = pending.message?.executionEngine === 'opencode';
  const route = isOpenCode ? `/api/terminal/sessions/${encodeURIComponent(pending.runId)}/answer`
    : `/api/agent/runs/${encodeURIComponent(pending.runId)}/answer`;
  const result = await api(route, {
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({questionId:pending.questionId,
      choice:/^(?:cancel|stop|no,? cancel)$/i.test(response) ? 'Cancel' : 'Custom',detail:response})
  });
  if (!result?.answered) throw new Error('The question expired; check the latest Agent status.');
  $('messageInput').value=''; autoGrow();
  if (pending.message.agentProgress) pending.message.agentProgress.question = {};
  if (isOpenCode) {
    // OpenCode resumes the SAME remote run after answering. The SSE relay from
    // the paused request has finished, so restore the authoritative status
    // watcher instead of leaving the UI frozen on "needs input".
    const index = state.messages.indexOf(pending.message);
    if (index >= 0) {
      pending.message.streaming = true;
      pending.message.agentBackendStatus = 'running';
      pending.message.agentConnectionStatus = 'connected';
      pending.message.agentProgress = {...(pending.message.agentProgress || {}),
        phase:'executing',status:'running',question:{}, detail:'Answer accepted; OpenCode is continuing'};
      // No new SSE done event is coming after a direct /answer request; the
      // resumed watch owns final completion and the provider token snapshot.
      pending.message.serverDone = true;
      state.activeAgentRunId = pending.runId;
      startAgentWatch(pending.runId, pending.message, index);
    }
  }
  state.messages.push({role:'user',content:response,createdAt:new Date().toISOString()});
  renderMessages();scrollBottom(true);
  return true;
}
// ELIYA82: one optional, bounded classifier for ambiguous turns. The server independently
// checks that an Execute suggestion is authorized by the actual user instruction.
async function eliyaModelIntent(args) {
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.chatModel) return null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1600);
  try {
    const response = await fetch('/api/chat/intent', {
      method:'POST',signal:controller.signal,
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${state.config.apiKey}`},
      body:JSON.stringify({message:args.text,previousAssistant:args.previousAssistantText || '',
        selectedMode:args.selectedMode,baseUrl:state.config.baseUrl,
        model:state.config.chatModel || state.config.model})
    });
    if (!response.ok) return null;
    const result = await response.json();
    return result && ['chat','agent'].includes(result.engine) ? result : null;
  } catch (_) { return null; }
  finally { clearTimeout(timeout); }
}
async function downloadTestCaseWorkbook(jobId, conversationId = state.conversationId) {
  const response = await fetch(`/api/artifacts/testcases/${encodeURIComponent(jobId)}/download?conversationId=${encodeURIComponent(conversationId)}`);
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url;
  link.download = filenameFromDisposition(response, 'ELIYA_Test_Cases.xlsx');
  document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

// Keep live document jobs attached to their own conversation when users switch tabs.
// Server-side jobs continue even when this tab is no longer visible.
const activeWorkbookJobs = new Map();
async function generateDocumentTestCases(instruction, documents) {
  const conversationId = state.conversationId;
  const user = {role:'user',content:instruction,attachmentIds:documents.map(file=>file.id),createdAt:new Date().toISOString()};
  const answer = {role:'assistant',mode:'chat',content:'Preparing Excel test cases from your documents. Source coverage and progress appear below.',
    testCaseJob:{status:'queued',detail:'Submitting document sections',processedChunks:0,totalChunks:0,rowCount:0},createdAt:new Date().toISOString()};
  state.messages.push(user,answer);
  activeWorkbookJobs.set(conversationId, answer);
  state.attachments=[]; $('messageInput').value='';autoGrow();renderAttachmentTray();renderMessages();scrollBottom(true);
  try {
    const response = await api('/api/artifacts/testcases',{
      method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${state.config.apiKey}`},
      body:JSON.stringify({conversationId,attachmentIds:documents.map(file=>file.id),instruction,
        settings:{baseUrl:state.config.baseUrl, model:state.config.model, chatModel:state.config.chatModel || state.config.model,
          temperature:0.2,maxTokens:Math.max(5000,Number(state.config.maxTokens)||0)}})
    });
    answer.testCaseJob=response;
    answer.content='Document extraction completed. Generating structured test cases in parallel; the Coverage worksheet will identify any failed sections.';
    renderMessages();
    // UI polling is independent of the durable backend job and never triggers retries/replanning.
    while (['queued','running'].includes(answer.testCaseJob.status)) {
      await new Promise(resolve=>setTimeout(resolve,1300));
      try {answer.testCaseJob=await api(`/api/artifacts/testcases/${encodeURIComponent(response.id)}?conversationId=${encodeURIComponent(conversationId)}`);}
      catch(error){answer.content='Connection interrupted. Workbook generation continues on the server. Reopen the conversation to find its download link when ready.';break;}
      if (state.conversationId===conversationId && state.messages.includes(answer)) renderMessages();
    }
    const job=answer.testCaseJob;
    if (job.downloadReady) {
      answer.content=job.status==='completed' ? `Excel workbook generated: **${job.rowCount} test cases** from ${job.totalChunks} source sections. Review the Coverage worksheet.`
        : `Partial Excel workbook generated: ${job.rowCount} test cases. **${job.failedChunks} source sections need review.** The Coverage worksheet identifies the gaps.`;
      try { await downloadTestCaseWorkbook(job.id,conversationId); }
      catch(error){toast('Automatic download failed: ' + error.message, 6000);}
    } else if (job.status==='cancelled') {
      answer.content='Test-case generation cancelled. You can edit your request and resubmit.';
    } else if (job.status==='failed') {
      answer.content=`Test-case generation failed: ${job.error || 'Unknown error'}. The original documents remain unchanged.`;
    }
    activeWorkbookJobs.delete(conversationId);
    if (state.conversationId===conversationId && state.messages.includes(answer)) {renderMessages();await loadConversations();}
  } catch(error) {
    answer.testCaseJob={status:'failed',detail:'Unable to launch generation',error:error.message||'Unknown error'};
    answer.content=`Test-case generation could not start: ${error.message}`;
    activeWorkbookJobs.delete(conversationId);
    if (state.conversationId===conversationId) renderMessages();
  }
}
$('messages').addEventListener('click',async event=>{
  if(event.target.closest('[data-stop-unresponsive-chat]')) {await stopCurrentRun();return;}
  const download=event.target.closest('[data-workbook-download]');
  if (!download) return;
  download.disabled=true;
  try {await downloadTestCaseWorkbook(download.dataset.workbookDownload);}
  catch(error){toast('Workbook download failed: '+error.message,6000);}
  finally {download.disabled=false;}
});

async function sendMessage({ regenerate = false, overrideMessage = null } = {}) {
  if (!regenerate) {
    const waiting = activeAgentClarification();
    const reply = overrideMessage == null ? $('messageInput').value.trim() : String(overrideMessage).trim();
    if (waiting && reply) {
      try { await submitAgentChatAnswer(reply, waiting); }
      catch(error) { toast(`Could not send answer: ${error.message}`, 6500); }
      return;
    }
  }
  if (state.streaming) return;
  if (state.messages.some(m => m.agentRunId && m.streaming &&
      ['running','queued','starting','cancelling','waiting_workspace'].includes(String(m.agentBackendStatus || m.agentProgress?.status || 'running'))))
    return toast('This conversation already has a running task. Use + New Tab to start independent work.', 5500);
  if (state.uploadingCount > 0) return toast('Wait for the file upload to finish');
  // Route once per instruction, before workspace restoration, vision checks and payload
  // construction. All turns share the same durable conversation ID and attachments.
  // No extra LLM call, no UI toggle, no change to the backend Chat/Agent services.
  const incoming = regenerate ? '' : (overrideMessage == null ? $('messageInput').value.trim() : String(overrideMessage).trim());
  if (!regenerate && ELIYA_ROLLBACK_INTENT.test(incoming)) {
    $('messageInput').value=''; autoGrow();
    await performEliyaRollback(); return;
  }
  // ELIYA120: explicit user-selected mode is authoritative. No model-intent reroute and
  // no rewriting a natural 'yes' into permission to execute. Regenerate stays in original mode.
  const precedingResponse = [...state.messages].reverse().find(item => item.role === 'assistant' && !item.streaming);
  state.mode = window.EliyaWorkflowHandoff.resolveMode({workflowMode:state.workflowMode,
    regenerate,previousAssistantMode:precedingResponse?.mode});
  if (!window.EliyaWorkflowHandoff.validDraft({draft:state.pendingHandoff,
      conversationId:state.conversationId,projectId:state.project?.id||null,mode:state.mode,
      message:incoming})) {
    return toast('Analysis source, selected workspace or conversation changed. Select Implement in Agent again.',7000);
  }
  updateModeUi();
  if (!isConfigured()) {
    openSettings();
    return toast('Configure API key, base URL and model first');
  }
  await ensureConversation();
  // Both Analyse and Agent inherit the last explicitly selected primary workspace.
  // Do not force the user to type "workspace" or quietly drop the saved project after restart.
  if (!state.project?.localWorkspace && storageGet('local', 'llm.activeLocalWorkspacePath'))
    await ensurePersistentActiveWorkspace();
  if (state.mode === 'agent' && !state.project?.localWorkspace) {
    const rememberedPath = storageGet('local', 'llm.activeLocalWorkspacePath');
    // Never silently fall back to prompt-based auto-detection if the user already selected a folder.
    if (rememberedPath && !state.project?.localWorkspace) {
      return toast(`Selected workspace could not be restored: ${rememberedPath}. Reconnect the folder before starting Agent.`, 8500);
    }
  }
  if (!regenerate && state.pendingHandoff && state.pendingHandoff.projectId !== (state.project?.id || null)) {
    return toast('Selected workspace changed during restoration. Select Implement in Agent again.',7000);
  }
  let pendingAttachments = regenerate ? [] : [...state.attachments];
  const unsupportedMedia = pendingAttachments.find(file => {
    const mime = String(file.mimeType || '').toLowerCase();
    return mime.startsWith('audio/') || mime.startsWith('video/');
  });
  if (!regenerate && unsupportedMedia) {
    return toast(`Audio/video attachment reading is not enabled yet: ${unsupportedMedia.name}`, 6500);
  }
  // Document test-case requests start the artifact job immediately; file extraction
  // runs in the background on the server, not as a blocking chat preflight.
  const quickText = overrideMessage != null ? String(overrideMessage).trim() : $('messageInput').value.trim();
  if (!regenerate && state.mode === 'chat' && window.EliyaUnifiedRouting?.documentArtifactIntent?.(quickText, pendingAttachments, Boolean(state.project?.localWorkspace))) {
    state.mode = 'chat'; state.workflowMode = 'analyse'; updateModeUi();
    await generateDocumentTestCases(quickText, pendingAttachments);
    return;
  }
  if (!regenerate && pendingAttachments.length) {
    try { pendingAttachments = await ensureDocumentAttachmentsReady(pendingAttachments); }
    catch (error) { return toast(error.message, 8000); }
  }
  const hasImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
  if (!regenerate && hasImage && state.mode === 'agent' && !state.config.visionModel) {
    return toast('Select an optional Agent Vision model before sending images.', 6500);
  }
  if (!regenerate && hasImage && state.mode === 'chat' && !state.config.chatVisionModel && !isVisionCapableModel(state.config.chatModel || state.config.model)) {
    refreshChatModelPicker();
    $('chatModelSelect')?.focus();
    return toast('Select optional Chat Vision extraction, or an image-capable Chat model, before sending an image.', 6500);
  }
  let text = overrideMessage != null ? String(overrideMessage).trim() : $('messageInput').value.trim();
  const displayedUserText = text;
  if (!regenerate && text && overrideMessage == null && !state.pendingHandoff) {
    const lastUser=[...state.messages].reverse().find(item=>item.role==='user')?.content || '';
    const lastAssistant=[...state.messages].reverse().find(item=>item.role==='assistant' && !item.streaming)?.content || '';
    text=window.EliyaConversationIntelligence?.contextualize?.(text,{
      lastUser,lastAssistant,workspaceMapped:Boolean(state.project?.localWorkspace)
    })?.text || text;
  }
  if (!regenerate && !text && pendingAttachments.length) text = 'Please analyze the attached file(s).';
  if (!regenerate && !text) return;

  // Validate/recover alias-to-path mappings BEFORE constructing the Chat/Agent request.
  // A missing named reference is an explicit error, not an excuse to answer from other files.
  let selectedMappedReferences;
  try { selectedMappedReferences = await resolvedReferencesForMessage(text); }
  catch (error) { return toast(error.message, 8500); }

  if (!regenerate) {
    state.messages.push({
      role: 'user',
      content: displayedUserText,
      attachmentIds: pendingAttachments.map(file => file.id),
      createdAt: new Date().toISOString()
    });
    $('messageInput').value = '';
    toggleComposerPreview(false);
    state.attachments = [];
    clearHandoffNotice();
    autoGrow();
    renderAttachmentTray();
  }

  const assistantIndex = state.messages.length;
  const assistant = {
    role: 'assistant',
    content: '',
    streaming: true,
    attachmentIds: [],
    mode: state.mode,
    chatLoadingStatus: state.mode === 'chat' ? 'Connecting and preparing your answer…' : undefined,
    agentSteps: state.mode === 'agent' ? [] : undefined,
    agentConnectionStatus: state.mode === 'agent' ? 'connecting' : undefined,
    agentBackendReachable: state.mode === 'agent' ? null : undefined,
    agentBackendStatus: state.mode === 'agent' ? 'starting' : undefined,
    agentBackendPolledAt: state.mode === 'agent' ? '' : undefined,
    agentTransportError: '',
    executionEngine: state.mode === 'agent' && currentExecutionEngine() === 'legacy' ? 'legacy' : undefined,
    startedAt: new Date().toISOString()
  };
  state.messages.push(assistant);
  state.editingIndex = null;
  state.userScrolledUp = false;
  renderMessages();
  scrollBottom(true);
  setStreaming(true);
  const streamToken = { detached: false };
  state.activeStreamToken = streamToken;
  state.agentWatchdogCompleted = false;
  // A healthy HTTP/SSE socket does not prove the model is advancing. Heartbeats
  // are deliberately excluded from this progress clock. This is advisory only:
  // never cancel a legitimate slow server-side run without the user's action.
  assistant.chatLastProgressAt = Date.now();
  assistant.chatHealthDetail = '';
  let chatProgressWatch = null;
  if (assistant.mode === 'chat') {
    chatProgressWatch = setInterval(() => {
      if (streamToken.detached || !assistant.streaming) return;
      const quietMs = Date.now() - (assistant.chatLastProgressAt || Date.now());
      const next = quietMs >= 180_000
        ? `No new model output or status for ${Math.floor(quietMs / 1000)}s. The connection may be stalled; you can stop and preserve text generated so far.`
        : quietMs >= 90_000
          ? `Still waiting for meaningful model or retrieval progress (${Math.floor(quietMs / 1000)}s). A network heartbeat alone does not confirm progress.` : '';
      if (next !== assistant.chatHealthDetail) {
        assistant.chatHealthDetail = next;
        updateChatHealthNotice(assistantIndex);
      }
    }, 15_000);
  }

  const payload = {
    conversationId: state.conversationId,
    message: regenerate ? null : text,
    attachmentIds: pendingAttachments.map(file => file.id),
    projectId: state.project?.id || null,
    referenceProjectIds: selectedMappedReferences.map(reference => reference.id),
    referenceProjectNames: Object.fromEntries(selectedMappedReferences.map(reference => [reference.id, reference.name])),
    referenceProjectWriteAccess: Object.fromEntries(selectedMappedReferences.filter(reference => reference.writable).map(reference => [reference.id, true])),
    mode: state.mode,
    regenerate,
    settings: {
      baseUrl: state.config.baseUrl,
      model: state.config.model,
      chatModel: state.config.chatModel || state.config.model,
      visionModel: state.mode === 'chat' ? (state.config.chatVisionModel || '') : (state.config.visionModel || ''),
      visionBaseUrl: state.config.visionBaseUrl || '',
      visionApiKey: state.config.visionApiKey || '',
      temperature: state.config.temperature,
      maxTokens: state.config.maxTokens,
      contextWindowTokens: state.config.contextWindowTokens,
      modelContextWindows: modelContextWindowsSetting(),
      modelTypes: modelTypesSetting(),
      embeddingModel: state.config.embeddingModel || '',
      semanticRetrieval: Boolean(state.config.semanticRetrieval),
      systemPrompt: state.config.systemPrompt,
      useFileContext: state.config.useFileContext,
      agentAllowCommands: state.config.agentAllowCommands,
      agentEditPermission: state.config.agentEditPermission,
      agentShellPermission: state.config.agentShellPermission,
      agentReviewPermission: state.config.agentReviewPermission,
      agentMcpPermission: state.config.agentMcpPermission,
      agentTaskPermission: state.config.agentTaskPermission,
      agentLspPermission: state.config.agentLspPermission,
      agentParallelReadTools: state.config.agentParallelReadTools,
      agentAutoApprove: state.config.agentAutoApprove,
      agentConfirmFileDeletion: state.config.agentConfirmFileDeletion,
      agentPlanApproval: false,
      agentFallbackModels: state.config.agentFallbackEnabled ? currentFallbackModels().join('\n') : '',
      agentRecoveryAttempts: 3
    }
  };

  state.abortController = new AbortController();
  state.activeAgentRunId = null;
  let keepAgentWatchAfterTransportFailure = false;
  try {
    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      signal: state.abortController.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.config.apiKey}`,
        'X-ELIYA-Execution-Engine': currentExecutionEngine()
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error(await readHttpError(response));

    await consumeSse(response, (event, rawData) => {
      if (streamToken.detached) return;
      if (event === 'meta') {
        try {
          const meta = JSON.parse(rawData);
          state.conversationId = meta.conversationId || state.conversationId;
          if (meta.engine === 'opencode') assistant.executionEngine = 'opencode';
          else if (meta.engine === 'legacy') assistant.executionEngine = 'legacy';
          if (meta.agentRunId) {
            state.activeAgentRunId = meta.agentRunId;
            assistant.agentRunId = meta.agentRunId;
            assistant.agentConnectionStatus = 'connected';
            assistant.agentBackendStatus = 'running';
            assistant.agentBackendReachable = null;
            assistant.agentProgress = { percent: 2, phase: 'starting', detail: 'Preparing agent run', status: 'running', tokenUsage: {} };
            startAgentWatch(meta.agentRunId, assistant, assistantIndex);
            renderMessages();
          }
          // A delayed SSE meta or project lookup cannot override a workspace the user
          // selected before or during this request. The backend only infers a workspace
          // when the Agent request had none selected.
          if (meta.autoResolvedWorkspace && !payload.projectId && !state.project && meta.projectId) {
            api(`/api/projects/${encodeURIComponent(meta.projectId)}`).then(project => {
              if (state.project || !project) return; // user mapped a workspace while lookup was in flight
              state.project = project;
              state.projectRootHandle = null;
              state.projectFallbackFiles = null;
              if (project.localWorkspace) rememberActiveLocalWorkspace(project);
              renderProjectBar();
              updateModeUi();
              toast(`Workspace resolved from prompt: ${project.localPath || project.name}`, 4500);
            }).catch(() => {});
          }
          for (let i = state.messages.length - 1; i >= 0; i--) {
            if (state.messages[i].role === 'user' && !state.messages[i].id) {
              state.messages[i].id = meta.userMessageId;
              if(assistant.mode==='chat')markPendingChatRecovery(state.conversationId,meta.userMessageId);
              break;
            }
          }
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'chat_status' || event === 'mcp_activity') {
        if (assistant.mode === 'chat') {
          try {
            const update = JSON.parse(rawData);
            const detail = String(update.detail || '').trim();
            // Only a changed real phase/detail counts as progress; duplicate
            // status snapshots cannot hide a hung model indefinitely.
            const fingerprint = `${event}:${update.phase || update.status || ''}:${detail}`;
            if (fingerprint !== assistant.chatProgressFingerprint) {
              assistant.chatProgressFingerprint = fingerprint;
              assistant.chatLastProgressAt = Date.now();
              if (assistant.chatHealthDetail) { assistant.chatHealthDetail = ''; updateChatHealthNotice(assistantIndex); }
            }
            if (update.phase === 'continuing' || update.status === 'continuing') {
              assistant.chatContinuationDetail = detail || 'Continuing long response automatically…';
              scheduleStreamingRender(assistantIndex);
            } else if (!assistant.content.trim()) {
              if (detail) assistant.chatLoadingStatus = detail;
              scheduleStreamingRender(assistantIndex);
            }
          } catch (_) { /* ignore invalid progress event */ }
        }
        return;
      }

      if (event === 'agent_progress') {
        try {
          const update = JSON.parse(rawData);
          assistant.agentProgress = { ...(assistant.agentProgress || {}),
            percent: Number(update.percent ?? assistant.agentProgress?.percent ?? 2),
            phase: update.phase || assistant.agentProgress?.phase || 'starting',
            detail: update.detail || assistant.agentProgress?.detail || '',
            status: update.status || assistant.agentProgress?.status || 'running',
            estimated: update.estimated ?? assistant.agentProgress?.estimated ?? false,
            indeterminate: update.indeterminate ?? assistant.agentProgress?.indeterminate ?? false,
            elapsedMs: update.elapsedMs ?? assistant.agentProgress?.elapsedMs ?? 0,
            startedAt: update.startedAt || assistant.agentProgress?.startedAt || '',
            question: update.question ?? assistant.agentProgress?.question ?? {},
            tokenUsage: update.tokenUsage ?? assistant.agentProgress?.tokenUsage ?? {} };
          assistant.agentBackendStatus = update.status || assistant.agentBackendStatus;
          if (update.status === 'failed') assistant.agentConnectionStatus = 'closed';
          scheduleAgentRender(assistantIndex);
        } catch (_) { /* ignored malformed progress event */ }
        return;
      }

      if (event === 'agent_step') {
        try {
          const step = JSON.parse(rawData);
          if (step.runId) { state.activeAgentRunId = step.runId; assistant.agentRunId = step.runId; }
          if (!Array.isArray(assistant.agentSteps)) assistant.agentSteps = [];
          assistant.agentEventTotal = Number(assistant.agentEventTotal || assistant.agentSteps.length) + 1;
          const previous = assistant.agentSteps[assistant.agentSteps.length - 1];
          if (previous && previous.step === step.step && previous.tool === step.tool && previous.status === 'running') {
            assistant.agentSteps[assistant.agentSteps.length - 1] = step;
          } else {
            assistant.agentSteps.push(step);
          }
          if (assistant.agentSteps.length > MAX_AGENT_EVENTS_RETAINED) {
            assistant.agentSteps.splice(0, assistant.agentSteps.length - MAX_AGENT_EVENTS_RETAINED);
          }
          // Approval controls must appear immediately. High-volume tool activity is throttled and refreshes only
          // the Agent card instead of rebuilding the entire conversation DOM on every event.
          if (step.status === 'approval' || step.tool === 'plan_approval') renderMessages();
          else scheduleAgentRender(assistantIndex);
        } catch (_) { /* ignore malformed agent progress */ }
        return;
      }

      if (event === 'agent_changes' || event === 'agent_patch') {
        try {
          const patch = JSON.parse(rawData);
          assistant.agentDirectChangeCount = Number(patch.count || 0);
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'token') {
        let token = rawData;
        try {
          const parsed = JSON.parse(rawData);
          if (parsed && typeof parsed.text === 'string') token = parsed.text;
        } catch (_) { /* backward compatibility with raw token SSE */ }
        assistant.content += token;
        if (assistant.mode === 'chat' && token) {
          assistant.chatLastProgressAt = Date.now();
          if (assistant.chatHealthDetail) {assistant.chatHealthDetail = ''; updateChatHealthNotice(assistantIndex);}
        }
        scheduleStreamingRender(assistantIndex);
        return;
      }

      if (event === 'stopped') {
        // The backend explicitly stopped without a saved response. This is not
        // a successful completion and it must never be presented as one.
        assistant.serverDone=true;
        assistant.chatStopped=true;
        assistant.chatStopConfirmed=true;
        assistant.chatLoadingStatus='Generation cancelled';
        if(assistant.mode==='chat')clearPendingChatRecovery(state.conversationId);
        if(!assistant.content.trim())assistant.content='*Generation stopped by request.*';
        return;
      }

      if (event === 'done') {
        assistant.serverDone = true;
        if(assistant.mode==='chat')clearPendingChatRecovery(state.conversationId);
        assistant.finishedAt = assistant.finishedAt || new Date().toISOString();
        // SSE 'done' means the transport finished, not that verification passed.
        // Read durable run state below instead of inventing a green 100% completed status.
        assistant.agentConnectionStatus = assistant.mode === 'agent' ? 'closed' : assistant.agentConnectionStatus;
        stopAgentWatch();
        if (assistant.mode === 'agent' && assistant.agentRunId) {
          const ownedRun = assistant.agentRunId;
          const ownedMessages = state.messages;
          api(`/api/agent/runs/${encodeURIComponent(ownedRun)}`).then(snapshot => {
            if (state.messages !== ownedMessages || assistant.agentRunId !== ownedRun) return;
            assistant.agentBackendStatus = snapshot.status || 'unknown';
            assistant.agentProgress = agentProgressFromSnapshot(snapshot, assistant.agentProgress);
            assistant.finishedAt = snapshot.finishedAt || assistant.finishedAt;
            renderMessages();
          }).catch(() => {
            if (state.messages !== ownedMessages) return;
            assistant.agentBackendStatus = 'unknown';
            assistant.agentProgress = {...(assistant.agentProgress || {}), status:'unknown',
              detail:'Execution stream closed, but the backend outcome could not be confirmed'};
            renderMessages();
          });
        }
        try {
          const saved = JSON.parse(rawData);
          const steps = assistant.agentSteps;
          const directChangeCount = assistant.agentDirectChangeCount;
          // Never replace already-visible Agent text with a blank, truncated or
          // divergent final payload. Chat and Agent share the same integrity rule.
          applyCompletedChatMessage(assistant, saved);
          if (assistant.mode === 'agent') {
            assistant.agentSteps = steps;
            assistant.agentDirectChangeCount = directChangeCount;
            assistant.mode = 'agent';
          }
        } catch (_) {
          assistant.streaming = false;
        }
        return;
      }

      if (event === 'error') {
        let message = rawData;
        try { message = JSON.parse(rawData).message || message; } catch (_) { /* ignore */ }
        const serverError = new Error(message);
        serverError.isServerEvent = true;
        throw serverError;
      }
    });

    if (streamToken.detached) return; // backend continues; the former tab will reload durable history
    assistant.streaming = false;
    if (assistant.mode === 'agent' && assistant.agentRunId) void fetchAgentCompletionReport(assistant);
    renderMessages();
    await loadConversations();
    const conversation = state.conversations.find(c => c.id === state.conversationId);
    if (conversation) $('conversationTitle').textContent = conversation.title;
    if (!regenerate && wantsExcel(text) && assistant.content && !assistant.content.includes('**Error:**')) {
      try { await downloadAssistantExcel(assistantIndex, true); }
      catch (artifactError) { toast(`Excel export failed: ${artifactError.message}`, 5000); }
    }
    const sentImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
    if (!regenerate && sentImage && /(?:not (?:seeing|see)|no (?:image|file).{0,30}(?:attached|provided)|cannot (?:see|view))/i.test(assistant.content || '')) {
      toast('The configured model did not process the image. Use a vision-capable model if image analysis is required.', 6500);
    }
  } catch (error) {
    if (streamToken.detached) return; // deliberate tab change, not a failed/cancelled execution
    assistant.streaming = false;
    if (error.name === 'AbortError') {
      // A cancelled HTTP socket is not evidence the Agent process terminated.
      // Keep the durable watcher alive until the server reports a terminal status.
      if(assistant.mode==='agent' && assistant.agentRunId && !state.agentWatchdogCompleted) {
        keepAgentWatchAfterTransportFailure=true;
        assistant.streaming=true;
        assistant.agentConnectionStatus='recovering';
        assistant.agentTransportError='Stream closed after stop request. Awaiting authoritative server run status.';
        if(!state.agentWatchTimer)startAgentWatch(assistant.agentRunId,assistant,assistantIndex);
        renderMessages();
      } else if (state.agentWatchdogCompleted) {
        try { await loadConversations(); } catch (_) { /* durable answer is already shown */ }
      } else {
        const stoppedNote=assistant.mode==='chat' && assistant.chatStopRequested
          ? assistant.chatStopConfirmed
            ? '*Stop accepted by server. Check saved partial output after reopening this conversation.*'
            : '*Local stream stopped; server cancellation unconfirmed. Check this conversation for saved results.*'
          : '*Generation stopped locally. Server outcome unverified.*';
        if (!assistant.content.trim())assistant.content=stoppedNote;
        else assistant.content+=`\n\n${stoppedNote}`;
      }
    } else {
      const agentRunId = assistant.agentRunId || state.activeAgentRunId;
      const isAgentTransportFailure = assistant.mode === 'agent' && !assistant.serverDone && Boolean(agentRunId) && !error.isServerEvent;
      const isChatTransportFailure = assistant.mode === 'chat' && !assistant.serverDone;
      if (isAgentTransportFailure) {
        keepAgentWatchAfterTransportFailure = true;
        assistant.streaming = true;
        assistant.agentConnectionStatus = 'disconnected';
        assistant.agentTransportError = error.message || 'Network connection interrupted';
        if (!assistant.agentBackendStatus || assistant.agentBackendStatus === 'starting') assistant.agentBackendStatus = 'running';
        renderMessages();
        toast('Agent stream disconnected. Backend status polling is still active.', 6000);
      } else if (isChatTransportFailure) {
        const userMessage = [...state.messages.slice(0, assistantIndex)].reverse().find(m => m.role === 'user' && m.id);
        assistant.content += `${assistant.content ? '\n\n' : ''}*Connection interrupted. Recovering the server-side response…*`;
        renderMessages();
        const recovered = await recoverChatAfterStreamFailure(assistantIndex, userMessage?.id);
        if (!recovered) {
          assistant.content = assistant.content.replace(/\n?\n?\*Connection interrupted\. Recovering the server-side response…\*$/, '');
          assistant.content += `${assistant.content ? '\n\n' : ''}**Connection interrupted:** ${error.message}\n\nThe server may still finish and save this response. Reopen this conversation to recover it.`;
        }
      } else {
        assistant.content += `${assistant.content ? '\n\n' : ''}**Error:** ${error.message}`;
        if (assistant.mode === 'agent') {
          assistant.agentBackendStatus = 'failed';
          assistant.agentConnectionStatus = 'closed';
          assistant.agentProgress = { ...(assistant.agentProgress || {}), status:'failed',
            phase:'failed', detail:String(error.message || 'OpenCode startup failed'), percent:0 };
        }
      }
    }
    renderMessages();
  } finally {
    if (chatProgressWatch) clearInterval(chatProgressWatch);
    if (assistant.chatHealthDetail) { assistant.chatHealthDetail=''; updateChatHealthNotice(assistantIndex); }
    if (!streamToken.detached && state.activeStreamToken === streamToken && !keepAgentWatchAfterTransportFailure) {
      state.activeStreamToken = null;
      stopAgentWatch();
      setStreaming(false);
      state.activeAgentRunId = null;
    }
    if (!streamToken.detached) {
      state.abortController = null;
      cancelStreamingRenders();
      if (state.agentRenderTimer) { clearTimeout(state.agentRenderTimer); state.agentRenderTimer = null; }
      scrollBottom(false); // Preserve user's position when reading earlier output.
    }
  }
}


async function recoverChatAfterStreamFailure(assistantIndex, userMessageId) {
  if (!state.conversationId) return false;
  for (let attempt = 0; attempt < 12; attempt++) {
    await new Promise(resolve => setTimeout(resolve, attempt < 4 ? 750 : 1500));
    try {
      const serverMessages = await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/messages`);
      const userIndex = serverMessages.findIndex(m => Number(m.id) === Number(userMessageId));
      if (userIndex < 0) continue;
      const recovered = serverMessages.slice(userIndex + 1).find(m => m.role === 'assistant');
      if (!recovered) continue;
      const existingDraft = state.messages[assistantIndex] || { role: 'assistant', content: '' };
      applyCompletedChatMessage(existingDraft, recovered);
      existingDraft.mode = 'chat';
      state.messages[assistantIndex] = existingDraft;
      clearPendingChatRecovery(state.conversationId);
      renderMessages();
      toast('Chat response recovered after connection interruption', 4500);
      return true;
    } catch (_) { /* network may still be recovering */ }
  }
  return false;
}

async function readHttpError(response) {
  let message = `HTTP ${response.status}`;
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const body = await response.json();
      return body.message || body.error || message;
    }
    const text = await response.text();
    if (text.trim()) return text.trim().slice(0, 1200);
  } catch (_) { /* ignore */ }
  return message;
}

async function consumeSse(response, onEvent) {
  if (!response.body) throw new Error('Streaming response body is unavailable');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventName = 'message';
  let dataLines = [];

  const dispatch = () => {
    if (!dataLines.length) {
      eventName = 'message';
      return;
    }
    const data = dataLines.join('\n');
    dataLines = [];
    const currentEvent = eventName;
    eventName = 'message';
    onEvent(currentEvent, data);
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newline;
    while ((newline = buffer.indexOf('\n')) >= 0) {
      let line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);

      if (line === '') {
        dispatch();
        continue;
      }
      if (line.startsWith(':')) continue;
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
        continue;
      }
      if (line.startsWith('data:')) {
        let valuePart = line.slice(5);
        // SSE allows one optional transport separator space. Remove only that one space,
        // never trimStart(), because model tokens may intentionally start with whitespace.
        if (valuePart.startsWith(' ')) valuePart = valuePart.slice(1);
        dataLines.push(valuePart);
      }
    }
  }

  buffer += decoder.decode();
  if (buffer) {
    let line = buffer.endsWith('\r') ? buffer.slice(0, -1) : buffer;
    if (line.startsWith('data:')) {
      line = line.slice(5);
      if (line.startsWith(' ')) line = line.slice(1);
      dataLines.push(line);
    }
  }
  dispatch();
}

function isDocumentAttachment(file) {
  const mime = String(file?.mimeType || file?.type || '').toLowerCase();
  return !mime.startsWith('image/') && !mime.startsWith('audio/') && !mime.startsWith('video/');
}

async function ensureDocumentAttachmentsReady(files) {
  const refreshed = [];
  for (const file of files || []) {
    if (!isDocumentAttachment(file) || file.uploading) {
      refreshed.push(file);
      continue;
    }
    let current = file;
    const chars = Number(current.extractedCharacters || 0);
    const status = String(current.extractionStatus || '').toLowerCase();
    if (chars <= 0 || status !== 'ready') {
      current = await api(`/api/files/${encodeURIComponent(current.id)}/reextract?conversationId=${encodeURIComponent(state.conversationId)}`, { method: 'POST' });
      const existing = state.attachments.find(item => item.id === file.id);
      current = { ...current, previewUrl: existing?.previewUrl || file.previewUrl || null };
      state.filesById.set(current.id, current);
      const index = state.attachments.findIndex(item => item.id === file.id);
      if (index >= 0) state.attachments[index] = current;
    }
    if (Number(current.extractedCharacters || 0) <= 0 || String(current.extractionStatus || '').toLowerCase() !== 'ready') {
      const detail = current.extractionMessage || 'No readable text could be extracted';
      throw new Error(`Cannot read ${current.name}: ${detail}`);
    }
    refreshed.push(current);
  }
  renderAttachmentTray();
  return refreshed;
}

async function uploadFiles(fileList) {
  let files = Array.from(fileList || []).filter(Boolean);
  if (!files.length) return;
  // Allow users to attach screenshots before selecting a Vision model. Sending is guarded
  // separately; silently discarding image files made the user think an upload had succeeded.
  const images = files.filter(file => String(file.type || '').startsWith('image/'));
  if (state.mode === 'agent' && images.length && !state.config.visionModel) {
    toast('Images can be attached now. Select an Agent Vision model before sending.', 6500);
  }
  await ensureConversation();

  for (const file of files) {
    const tempId = `upload-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    const previewUrl = String(file.type || '').startsWith('image/') ? URL.createObjectURL(file) : null;
    state.attachments.push({ id: tempId, name: file.name, size: file.size, mimeType: file.type, uploading: true, previewUrl });
    state.uploadingCount++;
    renderAttachmentTray();

    const form = new FormData();
    form.append('conversationId', state.conversationId);
    form.append('file', file);

    try {
      const uploaded = await api('/api/files', { method: 'POST', body: form });
      const index = state.attachments.findIndex(item => item.id === tempId);
      if (index >= 0) state.attachments[index] = { ...uploaded, previewUrl };
      state.filesById.set(uploaded.id, uploaded);
      if (String(uploaded.mimeType || '').startsWith('image/')) {
        const selectedChatModel = state.config.chatModel || state.config.model || '';
        if (state.mode === 'agent') {
          toast(state.config.visionModel ? `Image ready · Agent Vision: ${state.config.visionModel}` : 'Image ready · choose Agent Vision before sending', 4500);
        } else if (state.config.chatVisionModel || isVisionCapableModel(selectedChatModel)) {
          toast(state.config.chatVisionModel ? `Image ready · ${state.config.chatVisionModel} extracts; ${selectedChatModel} answers` : `Image ready · Chat uses ${selectedChatModel}`, 4500);
        } else {
          refreshChatVisionPicker();
          $('chatVisionSelect')?.focus();
          toast('Image ready. Select Chat Vision (or a multimodal Chat model) before sending.', 6500);
        }
      } else {
        const chars = Number(uploaded.extractedCharacters || 0);
        const status = String(uploaded.extractionStatus || 'unknown');
        const extractionMessage = String(uploaded.extractionMessage || 'No readable text was extracted');
        if (chars > 0) toast(`${uploaded.name} ready · ${formatCompact(chars)} text chars extracted`, 4200);
        else toast(`${uploaded.name} uploaded, but document reading is ${status}: ${extractionMessage}`, 8000);
      }
      renderAttachmentTray();
    } catch (error) {
      state.attachments = state.attachments.filter(item => item.id !== tempId);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      renderAttachmentTray();
      toast(`Upload failed: ${error.message}`, 4000);
    } finally {
      state.uploadingCount = Math.max(0, state.uploadingCount - 1);
    }
  }
}

function renderAttachmentTray() {
  const hasImage = state.attachments.some(file => String(file.mimeType || '').startsWith('image/'));
  const chips = state.attachments.map(file => {
    const image = String(file.mimeType || '').startsWith('image/');
    const preview = image ? (file.previewUrl || (!file.uploading ? `/api/files/${encodeURIComponent(file.id)}/view` : '')) : '';
    const visual = preview ? `<img class="attachment-thumb" src="${preview}" alt="${esc(file.name)}" />` : `<span>${fileIcon(file.mimeType, file.name)}</span>`;
    const extractionStatus = String(file.extractionStatus || '').toLowerCase();
    const extractionChars = Number(file.extractedCharacters || 0);
    const documentStatus = !image && !file.uploading
      ? (extractionStatus === 'ready' && extractionChars > 0
          ? `<span class="chip-status chip-ready">Ready · ${formatCompact(extractionChars)} chars</span>`
          : `<span class="chip-status chip-warning" title="${esc(file.extractionMessage || 'Document text is not ready')}">${esc(extractionStatus || 'checking')}</span>`)
      : '';
    return `<div class="attachment-chip ${image ? 'image-chip' : ''}" title="${esc(file.name)}">
      ${visual}
      <span class="chip-name">${esc(file.name)}</span>
      ${file.uploading ? '<span class="chip-status">Uploading…</span>' : documentStatus}
      <button class="chip-remove" type="button" data-remove-file="${esc(file.id)}" ${file.uploading ? 'disabled' : ''} aria-label="Remove attachment">×</button>
    </div>`;
  }).join('');
  const note = hasImage
    ? state.mode === 'agent'
      ? `<div class="image-capability-note">Agent Vision: ${esc(state.config.visionModel || 'not selected')}. Images are analysed before Agentic planning when enabled.</div>`
      : `<div class="image-capability-note">${state.config.chatVisionModel
          ? `Chat Vision <strong>${esc(state.config.chatVisionModel)}</strong> extracts the images; Chat <strong>${esc(state.config.chatModel || state.config.model || 'not selected')}</strong> answers.`
          : isVisionCapableModel(state.config.chatModel || state.config.model)
            ? `The Chat model <strong>${esc(state.config.chatModel || state.config.model)}</strong> receives the images directly.`
            : 'Select a Chat Vision extraction model, or a multimodal Chat model, before sending.'}</div>`
    : '';
  $('attachmentTray').innerHTML = chips + note;
}

function openSettings() {
  syncSettingsUi();
  $('modalBackdrop').classList.remove('hidden');
  loadMcpConfig().catch(error => setMcpStatus(`Unable to load MCP configuration: ${error.message}`, 'error'));
  loadVerifiedLearning().catch(error => { if ($('learningStatus')) $('learningStatus').textContent = 'Learning unavailable: ' + error.message; });
  loadOpenCodeImportStatus().catch(error => { if ($('openCodeImportStatus')) $('openCodeImportStatus').textContent = 'Import status unavailable: ' + error.message; });
  setTimeout(() => $('apiKey').focus(), 0);
}

function closeSettings() { $('modalBackdrop').classList.add('hidden'); }

function togglePassword(inputId, buttonId) {
  const input = $(inputId);
  const button = $(buttonId);
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  button.textContent = show ? 'Hide' : 'Show';
}

function autoGrow() {
  const input = $('messageInput');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 240)}px`;
  chatComposerChanged();
}

async function copyText(text) {
  const value = String(text ?? '');
  try {
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); return; }
  } catch (_) { /* Clipboard permission restricted: fall back to explicit selection. */ }
  const area = document.createElement('textarea');
  area.value = value;
  area.style.cssText = 'position:fixed;top:0;left:-9999px;opacity:0;';
  document.body.appendChild(area);
  try {
    area.focus(); area.select();
    if (!document.execCommand?.('copy')) throw new Error('Browser clipboard access is unavailable');
  } finally { area.remove(); }
}

function artifactMime(extension) {
  return ({html:'text/html;charset=utf-8',htm:'text/html;charset=utf-8',json:'application/json;charset=utf-8',
    yml:'application/yaml;charset=utf-8',yaml:'application/yaml;charset=utf-8',md:'text/markdown;charset=utf-8'})[extension] || 'text/plain;charset=utf-8';
}

function downloadText(name, text, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([String(text || '')], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}


function wantsExcel(text) {
  return /\b(excel|xlsx|spreadsheet)\b/i.test(String(text || ''));
}


function previousUserMessage(index) {
  for (let i = Number(index) - 1; i >= 0; i--) {
    if (state.messages[i]?.role === 'user') return state.messages[i];
  }
  return null;
}

function isExcelRequestedForAssistant(index) {
  return wantsExcel(previousUserMessage(index)?.content || '');
}

function hasMarkdownTable(text) {
  return /^\s*\|?.+\|.+\s*\n\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+/m.test(String(text || ''));
}

function filenameFromDisposition(response, fallback) {
  const value = response.headers.get('content-disposition') || '';
  const match = value.match(/filename="?([^";]+)"?/i);
  return match?.[1] || fallback;
}

async function downloadAssistantExcel(index, automatic = false) {
  const message = state.messages[Number(index)];
  if (!message?.content) return;
  const title = `${$('conversationTitle').textContent || 'assistant-export'}-export`;
  const response = await fetch('/api/artifacts/excel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, markdown: message.content })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filenameFromDisposition(response, 'assistant-export.xlsx');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
  toast(automatic ? 'Excel file downloaded' : 'Excel downloaded');
}


async function downloadAssistantPdf(index) {
  const message = state.messages[Number(index)];
  if (!message?.content) return;
  const title = `${$('conversationTitle').textContent || 'assistant-export'}-assistant-${Number(index) + 1}`;
  const response = await fetch('/api/artifacts/pdf', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, markdown: stripProjectMarkers(message.content) })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filenameFromDisposition(response, 'assistant-export.pdf');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
  toast('PDF downloaded');
}

function stripProjectMarkers(text) {
  return String(text || '')
    .replace(/<!--\s*PROJECT_FILE_START:[^>]+-->[\s\S]*?<!--\s*PROJECT_FILE_END\s*-->/gi, '')
    .trim();
}

function extractProjectFileChanges(text) {
  const source = String(text || '');
  const changes = [];
  const marker = /<!--\s*PROJECT_FILE_START:([^\n>]+?)\s*-->([\s\S]*?)<!--\s*PROJECT_FILE_END\s*-->/gi;
  let match;
  while ((match = marker.exec(source)) !== null) {
    const rawMeta = match[1].trim();
    let path = '';
    let baselineHash = '';
    let operation = 'write';

    // Newer structured start-marker format, retained for compatibility.
    if (rawMeta.startsWith('{')) {
      try {
        const meta = JSON.parse(rawMeta);
        path = String(meta.path || '').trim().replace(/\\/g, '/');
        baselineHash = String(meta.baselineHash || '');
        operation = String(meta.operation || 'write').toLowerCase() === 'delete' ? 'delete' : 'write';
      } catch (_) { /* fall back to legacy path marker */ }
    }
    if (!path) path = rawMeta.replace(/^['"]|['"]$/g, '').replace(/\\/g, '/');

    let body = match[2].trim();
    // Agent metadata is a separate hidden comment so legacy Chat-mode patches still work.
    const metaMatch = body.match(/<!--\s*PROJECT_FILE_META:([^>]+?)\s*-->/i);
    if (metaMatch) {
      for (const token of metaMatch[1].split(';')) {
        const eq = token.indexOf('=');
        if (eq < 0) continue;
        const key = token.slice(0, eq).trim();
        const value = token.slice(eq + 1).trim();
        if (key === 'baselineHash') baselineHash = value;
        if (key === 'operation') operation = value.toLowerCase() === 'delete' ? 'delete' : 'write';
      }
      body = body.replace(metaMatch[0], '').trim();
    }

    const fence = body.match(/^```[^\n]*\n([\s\S]*?)\n```\s*$/);
    const content = operation === 'delete' ? null : (fence ? fence[1] : body);
    if (path) changes.push({ path, content, baselineHash, operation });
  }
  return changes;
}

const ACTIVE_LOCAL_WORKSPACE_KEY = 'llm.activeLocalWorkspaceId';

function updateWorkspaceVisibility() {
  const visible = state.mode === 'agent' ? Boolean(state.agentFoldersVisible) : state.workspaceFoldersVisible;
  $('workspaceConfiguration').hidden = !visible;
  $('workspaceVisibilityToggle').setAttribute('aria-expanded', String(visible));
  $('workspaceVisibilityToggle').textContent = visible ? '▾ Hide folders' : '▸ Show folders';
  const name = state.project?.name || state.project?.path?.replace(/[\\/]+$/, '').split(/[\\/]/).pop() || 'No folder selected';
  const refs = state.referenceProjects.length;
  $('workspaceCompactSummary').textContent = `Workspace · ${name}${refs ? ` · ${refs} reference${refs === 1 ? '' : 's'}` : ''}`;
}

$('workspaceVisibilityToggle').onclick = () => {
  if (state.mode === 'agent') {
    state.agentFoldersVisible = !state.agentFoldersVisible;
  } else {
    state.workspaceFoldersVisible = !state.workspaceFoldersVisible;
    storageSet('local', 'llm.workspaceFoldersVisible', String(state.workspaceFoldersVisible));
  }
  updateWorkspaceVisibility();
};
updateWorkspaceVisibility();

function sharedFolderStatus(message, error = false) {
  const node = $('sharedFolderStatus');
  if (!node) return;
  node.textContent = message;
  node.classList.toggle('folder-error', Boolean(error));
}

function renderReferenceFolders() {
  const node = $('referenceFolderList');
  if (!node) return;
  node.innerHTML = state.referenceProjects.map((ref, index) =>
    `<span class="reference-folder-chip" title="${ref.writable ? 'Writable' : 'Read-only'} reference: ${esc(ref.path)}"><span>↳ <strong>${esc(ref.name || ref.path)}</strong> · ${ref.unavailable ? 'unavailable — reconnect' : ref.writable ? 'read/write' : 'read-only'} · ${Number(ref.fileCount || 0)} indexed</span><button type="button" data-toggle-reference-write="${index}" aria-label="${ref.writable ? 'Make read-only' : 'Allow writing to'} reference ${esc(ref.name || ref.path)}" title="${ref.writable ? 'Disable reference edits' : 'Enable reference edits for migrations'}">${ref.writable ? '🔓' : '🔒'}</button><button type="button" data-rename-reference="${index}" aria-label="Rename reference ${esc(ref.name || ref.path)}" title="Rename reference">✎</button><button type="button" data-remove-reference="${index}" aria-label="Remove reference ${esc(ref.name || ref.path)}">×</button></span>`
  ).join('');
}

// ELIYA149: reference aliases are durable user configuration, not best-effort prompt words.
// Revalidate only once per browser session; after server DB reset, remap the SAME user-approved
// path. Never silently select an unrelated folder or grant write access to a new path.
const verifiedReferencePaths = new Map();
function sameMappedFolder(a, b) {
  const one = String(a || '').replace(/[\\/]+/g, '/').replace(/\/$/, '');
  const two = String(b || '').replace(/[\\/]+/g, '/').replace(/\/$/, '');
  const windows = /^[A-Za-z]:\//.test(one) && /^[A-Za-z]:\//.test(two);
  return windows ? one.toLowerCase() === two.toLowerCase() : one === two;
}
function promptUsesReferenceAlias(text, alias) {
  const escaped = String(alias || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return Boolean(escaped && new RegExp(`(^|[^A-Za-z0-9_-])${escaped}(?![A-Za-z0-9_-])`, 'i').test(text || ''));
}
async function resolvedReferencesForMessage(text) {
  const active = [];
  const missing = [];
  let changed = false;
  for (const ref of state.referenceProjects) {
    const verified = verifiedReferencePaths.get(ref.id);
    if (verified?.path === ref.path && Date.now() - verified.checkedAt < 30_000) {
      active.push(ref); continue;
    }
    try {
      let mapped;
      try { mapped = await api(`/api/projects/${encodeURIComponent(ref.id)}`); }
      catch (_) { mapped = null; }
      if (!mapped?.localWorkspace || !sameMappedFolder(mapped.localPath, ref.path)) {
        // A missing DB record may be remapped only to the previously configured path.
        // The server checks that it exists and is an allowed local project root.
        mapped = await api('/api/projects/local', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({conversationId:state.conversationId,path:ref.path})
        });
        if (!mapped?.localWorkspace || !sameMappedFolder(mapped.localPath, ref.path))
          throw new Error('Reference path did not match the saved mapping');
      }
      if (ref.id !== mapped.id) {
        verifiedReferencePaths.delete(ref.id);
        ref.id = mapped.id;
        changed = true;
        void watchFolderIndex(mapped, true);
      }
      ref.unavailable = false;
      verifiedReferencePaths.set(ref.id, {path:ref.path,checkedAt:Date.now()});
      active.push(ref);
    } catch (failure) {
      ref.unavailable = true;
      missing.push(ref);
    }
  }
  if (changed) saveReferenceFolders();
  if (missing.length) renderReferenceFolders();
  const requested = missing.filter(ref => promptUsesReferenceAlias(text, ref.name));
  const requestsReferences = /\b(?:all|configured|mapped)\s+references?\b|\breference\s+(?:projects?|folders?|codebases?)\b/i.test(text || '');
  if (requested.length || (requestsReferences && missing.length)) {
    throw new Error('Reference alias unavailable: ' + (requested.length ? requested : missing).map(ref => ref.name).join(', ') +
      '. The saved path could not be verified. Reconnect that reference in Settings; no other folder was substituted.');
  }
  return active;
}

function referenceWriteAccess() {
  return Object.fromEntries(state.referenceProjects.filter(ref => ref.writable === true).map(ref => [ref.id, true]));
}
function saveReferenceFolders() {
  if (typeof terminalUi !== 'undefined' && terminalUi.visible) void loadTerminalWorkspaces();
  updateWorkspaceVisibility();
  storageSet('local', 'llm.sharedReferenceProjects', JSON.stringify(state.referenceProjects));
  if (typeof terminalUi !== 'undefined' && terminalUi.draft)
    terminalUi.draft.referenceProjectWriteAccess = referenceWriteAccess();
  renderReferenceFolders();
}

const activeFolderIndexWatches = new Set();
const pendingFolderIndexWatches = new Set();
async function watchFolderIndex(project, isReference) {
  if (!project?.id) return;
  // A Rescan during an earlier watcher must not silently lose its UI refresh.
  if (activeFolderIndexWatches.has(project.id)) {
    pendingFolderIndexWatches.add(project.id);
    return;
  }
  activeFolderIndexWatches.add(project.id);
  try {
    // Indexing runs on the backend. The UI is not blocked, and indexing survives navigation.
    for (let attempt = 0; attempt < 120; attempt++) {
      const job = await api(`/api/projects/${encodeURIComponent(project.id)}/index-status`);
      const phase = String(job?.phase || 'queued');
      const count = Number(job?.fileCount || 0);
      if (phase === 'completed') {
        if (isReference) {
          const ref = state.referenceProjects.find(item => item.id === project.id);
          if (ref) { ref.fileCount = count; saveReferenceFolders(); }
        } else if (state.project?.id === project.id) {
          state.project.fileCount = count;
          state.project.indexedCharacters = Number(job?.indexedCharacters || 0);
          renderProjectBar();
        }
        // Older index-status responses omit indexedCharacters: don't mistake missing
        // telemetry for a verified zero-text/visual-only workspace.
        const excluded = Number(job?.skippedTooLarge || 0) + Number(job?.skippedUnsupported || 0)
          + Number(job?.skippedUnreadable || 0);
        const summary = count ? (job?.indexedCharacters == null || Number(job.indexedCharacters) > 0
            ? `${isReference ? 'Reference' : 'Project'} ready · ${count} files indexed · available in Chat and Agent`
            : `${count} files detected · no readable text extracted; use Agent document/vision analysis`)
          : 'No supported files indexed. Check folder path and file types.';
        sharedFolderStatus(`${summary}${excluded ? ` · ${excluded} skipped` : ''}${job?.scanIncomplete ? ' · scan incomplete' : ''}${job?.watchState === 'watching' ? ' · Automatic sync active' : job?.watchState === 'degraded_reconciling' ? ' · Periodic reconciliation fallback' : ''}. ${job.detail || ''}`,
          !count || Boolean(job?.scanIncomplete));
        return;
      }
      if (phase === 'failed') throw new Error(job.detail || 'Folder indexing failed. Try Rescan.');
      if ((!isReference && state.project?.id === project.id) ||
          (isReference && state.referenceProjects.some(ref => ref.id === project.id))) {
        sharedFolderStatus(`${isReference ? 'Reference' : 'Project'}: ${job?.detail || 'Indexing'} …`);
      } else return; // stop polling after the folder is disconnected
      await new Promise(resolve => setTimeout(resolve, 1500));
    }
    sharedFolderStatus('Indexing is continuing in the background. You can use the rest of ELIYA.');
  } catch (error) {
    sharedFolderStatus(`Folder indexing failed: ${error.message}`, true);
  } finally {
    activeFolderIndexWatches.delete(project.id);
    if (pendingFolderIndexWatches.delete(project.id))
      void watchFolderIndex(project, isReference);
  }
}

// Lightweight status-only polling. File changes are discovered by Java WatchService;
// this UI timer never performs a filesystem traversal or triggers a new index.
let workspaceFreshnessPollActive = false;
async function pollWorkspaceAutoSync() {
  const project = state.project;
  if (workspaceFreshnessPollActive || !project?.id || !project.localWorkspace ||
      activeFolderIndexWatches.has(project.id)) return;
  workspaceFreshnessPollActive = true;
  try {
    const job = await api(`/api/projects/${encodeURIComponent(project.id)}/index-status`);
    if (state.project?.id !== project.id) return;
    if (job?.phase === 'failed') {
      sharedFolderStatus(`Workspace index needs attention: ${job.detail || 'Please click Rescan'}`, true);
      return;
    }
    if (job?.phase !== 'completed' || job?.rescanPending) {
      sharedFolderStatus('Workspace changes detected · synchronizing index in the background…');
      if (job?.phase !== 'completed') void watchFolderIndex(project, false);
      return;
    }
    const count = Number(job.fileCount || 0);
    if (state.project.fileCount !== count || state.project.indexedCharacters !== Number(job.indexedCharacters || 0)) {
      state.project.fileCount = count;
      state.project.indexedCharacters = Number(job.indexedCharacters || 0);
      renderProjectBar();
    }
    const watching = job.watchState === 'watching';
    const fallback = job.watchState === 'degraded_reconciling' || job.watchState === 'polling_fallback';
    const last = job.lastAutoSyncAt ? new Date(job.lastAutoSyncAt).toLocaleTimeString() : null;
    const mode = watching ? 'Automatic sync active' : fallback ? 'Automatic sync · periodic reconciliation'
      : job.autoSyncEnabled ? 'Automatic sync · registering' : 'Automatic sync disabled';
    sharedFolderStatus(`${mode} · ${count} files indexed${last ? ` · last synchronized ${last}` : ''}${job.watchError ? ` · ${job.watchError}` : ''}`,
      Boolean(job.watchError) && !watching);
  } catch (error) {
    // Network blips should not hide Chat or reset the currently selected workspace.
    if (state.project?.id === project.id) sharedFolderStatus(`Workspace status unavailable: ${error.message}`, true);
  } finally { workspaceFreshnessPollActive = false; }
}
if (typeof window !== 'undefined' && typeof window.setInterval === 'function')
  window.setInterval(() => { void pollWorkspaceAutoSync(); }, 12000);

async function registerFolder(path, isReference, referenceName = null) {
  if (!path || !path.trim()) return;
  if (state.streaming) throw new Error('Stop the current generation before changing folders.');
  await ensureConversation();
  const buttonIds = ['enterProjectBtn', 'enterReferenceBtn'];
  buttonIds.forEach(id => { $(id).disabled = true; });
  sharedFolderStatus(`Registering ${isReference ? 'reference' : 'project'}: ${path} …`);
  try {
    const project = await api('/api/projects/local', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({conversationId: state.conversationId, path: path.trim()})
    });
    if (!project?.localWorkspace) throw new Error('The selected folder could not be mapped.');
    if (isReference) {
      const name = referenceName || defaultReferenceName(project.localPath);
      if (!validReferenceName(name) || name.toLowerCase() === 'workspace' || referenceNameInUse(name, project.id, project.localPath)) throw new Error('Invalid or duplicate reference name.');
      if (state.project?.id === project.id) throw new Error('The active project cannot also be a read-only reference.');
      state.referenceProjects = [...state.referenceProjects.filter(ref => ref.path !== project.localPath),
        {id: project.id, path: project.localPath, name, writable: false, fileCount: project.fileCount}].slice(-5);
      saveReferenceFolders();
    } else {
      state.project = project;
      rememberActiveLocalWorkspace(project);
      state.referenceProjects = state.referenceProjects.filter(ref => ref.id !== project.id);
      saveReferenceFolders();
      renderProjectBar();
    }
    sharedFolderStatus(`${isReference ? 'Reference' : 'Project'} added · indexing in the background …`);
    toast(`Folder added: ${project.name}. Indexing in the background.`, 3500);
    void watchFolderIndex(project, isReference);
  } catch (error) {
    sharedFolderStatus(`Folder indexing failed: ${error.message}`, true);
    throw error;
  } finally {
    buttonIds.forEach(id => { $(id).disabled = false; });
  }
}

// The path dialog replaces browser-native prompt/desktop picker popups.
let folderDialogMode = 'workspace';
let folderDialogRenameId = null;
function folderDialogError(message = '') {
  $('folderPathError').textContent = message;
  $('folderPathError').classList.toggle('hidden', !message);
}
function updateFolderExample() {
  const alias = ($('folderAliasInput').value || 'LegacySelenium').trim();
  $('folderPromptExample').textContent = folderDialogMode === 'workspace'
    ? 'Workspace [workspace]: ' + ($('folderPathInput').value.trim() || 'C:\\projects\\my-project') + '\nAnalyse the workspace architecture and identify its main modules.'
    : 'Reference [' + alias + '] (read-only): ' + ($('folderPathInput').value.trim() || 'C:\\projects\\legacy-framework') + '\nCompare Workspace [workspace] with Reference [' + alias + '].\nEnable write access on its reference chip before editing that reference.';
}
function openFolderDialog(isReference, reference = null) {
  folderDialogMode = isReference ? 'reference' : 'workspace';
  folderDialogRenameId = reference?.id || null;
  $('folderPathTitle').textContent = reference ? 'Rename reference alias' : isReference ? 'Add reference (read-only by default)' : 'Set main workspace';
  $('folderPathSubtitle').textContent = reference ? 'Update only the reference name used in prompts.' : 'Paths must exist on the computer running the Eliya Java server.';
  $('folderPathPurposeTitle').textContent = isReference ? 'Reference path — supporting source (writable when enabled)' : 'Workspace path — main working project';
  $('folderPathPurpose').textContent = isReference
    ? 'Use this folder for comparison, guidance, reuse or source-to-target migration. Eliya starts with read-only access; enable the lock icon on the reference chip to allow skills, agents or migration edits there. Give it a short alias so your prompts can identify the right reference. Up to 5 references.'
    : 'This is the main codebase or document folder. Eliya indexes it for Chat and Agent. Agent may create or modify files here according to your permissions; references remain read-only until explicitly enabled.';
  $('folderAliasRow').classList.toggle('hidden', !isReference);
  $('folderAliasInput').required = isReference;
  $('folderAliasInput').value = reference?.name || (isReference ? 'LegacySelenium' : '');
  $('folderPathInput').value = reference?.path || (isReference ? '' : state.project?.localPath || '');
  $('folderPathInput').readOnly = Boolean(reference);
  $('saveFolderPath').textContent = reference ? 'Save alias' : isReference ? 'Add reference' : 'Add workspace';
  folderDialogError();
  updateFolderExample();
  $('folderPathBackdrop').classList.remove('hidden');
  (reference ? $('folderAliasInput') : $('folderPathInput')).focus();
}
function closeFolderDialog() {
  if ($('saveFolderPath').disabled) return;
  $('folderPathBackdrop').classList.add('hidden');
  folderDialogRenameId = null;
}
async function submitFolderDialog(event) {
  event.preventDefault();
  const path = $('folderPathInput').value.trim();
  const isReference = folderDialogMode === 'reference';
  const name = $('folderAliasInput').value.trim();
  if (!path) return folderDialogError('Enter the absolute folder path first.');
  if (isReference && (!validReferenceName(name) || name.toLowerCase() === 'workspace'))
    return folderDialogError('Alias must start with a letter and contain only letters, numbers, _ or - (maximum 40 characters); workspace is reserved.');
  if (isReference && referenceNameInUse(name, folderDialogRenameId, path))
    return folderDialogError('Alias is already in use. Give each reference a unique name.');
  if (isReference && !folderDialogRenameId && state.referenceProjects.length >= 5 && !state.referenceProjects.some(ref => ref.path === path))
    return folderDialogError('Up to five references are supported. Remove one reference chip before adding another.');
  $('saveFolderPath').disabled = true;
  folderDialogError();
  try {
    if (folderDialogRenameId) {
      const ref = state.referenceProjects.find(item => item.id === folderDialogRenameId);
      if (!ref) throw new Error('Reference is no longer attached.');
      ref.name = name;
      saveReferenceFolders();
      sharedFolderStatus('Reference [' + name + '] is ready for both Chat and Agent.');
    } else {
      await registerFolder(path, isReference, isReference ? name : null);
    }
    $('folderPathBackdrop').classList.add('hidden');
    folderDialogRenameId = null;
  } catch (error) {
    folderDialogError(error.message);
  } finally {
    $('saveFolderPath').disabled = false;
  }
}

function rememberActiveLocalWorkspace(project) {
  if (!project?.localWorkspace || !project.id) return;
  storageSet('local', ACTIVE_LOCAL_WORKSPACE_KEY, project.id);
  if (project.localPath) storageSet('local', 'llm.activeLocalWorkspacePath', project.localPath);
  if (project.name) storageSet('local', 'llm.activeLocalWorkspaceName', project.name);
}

function forgetActiveLocalWorkspace() {
  storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
  storageRemove('local', 'llm.activeLocalWorkspacePath');
  storageRemove('local', 'llm.activeLocalWorkspaceName');
}

async function restoreActiveLocalWorkspace() {
  const id = storageGet('local', ACTIVE_LOCAL_WORKSPACE_KEY);
  if (!id) return null;
  try {
    const project = await api(`/api/projects/${encodeURIComponent(id)}`);
    if (!project?.localWorkspace) {
      // Keep the remembered path so the workspace can be remapped on the next Agent turn.
      storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
      return null;
    }
    state.project = project;
    state.projectRootHandle = null;
    state.projectFallbackFiles = null;
    rememberActiveLocalWorkspace(project);
    renderProjectBar();
    sharedFolderStatus('Project restored · checking the background index …');
    void watchFolderIndex(project, false);
    return project;
  } catch (_) {
    // Do not erase the remembered path on a transient backend/startup failure. The next Agent send can
    // recreate/reuse the local workspace record from the canonical path.
    storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
    return null;
  }
}

async function ensurePersistentActiveWorkspace() {
  if (state.project?.localWorkspace) return state.project;
  const restored = await restoreActiveLocalWorkspace();
  if (restored?.localWorkspace) return restored;
  const path = storageGet('local', 'llm.activeLocalWorkspacePath');
  if (!path || !state.conversationId) return null;
  try {
    const project = await api('/api/projects/local', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        conversationId: state.conversationId,
        path,
        name: storageGet('local', 'llm.activeLocalWorkspaceName') || 'Local workspace'
      })
    });
    if (!project?.localWorkspace) return null;
    state.project = project;
    state.projectRootHandle = null;
    state.projectFallbackFiles = null;
    rememberActiveLocalWorkspace(project);
    renderProjectBar();
    sharedFolderStatus('Project restored · checking the background index …');
    void watchFolderIndex(project, false);
    return project;
  } catch (_) {
    // A prompt may intentionally provide a new path. Let the server resolve that prompt instead of blocking send.
    return null;
  }
}

function renderProjectBar() {
  updateWorkspaceVisibility();
  const bar = $('projectBar');
  if (!state.project) {
    bar.classList.add('hidden');
    updateModeUi();
    return;
  }
  bar.classList.remove('hidden');
  $('projectName').textContent = state.project.name || 'Project';
  $('projectName').title = state.project.localPath || state.project.name || 'Project';
  const files = Number(state.project.fileCount || 0);
  const chars = Number(state.project.indexedCharacters || 0);
  const access = state.project.localWorkspace ? ' · local workspace · writable' : ' · indexed reference';
  if ($('knowledgeAnalyseBtn')) $('knowledgeAnalyseBtn').disabled = !state.project.localWorkspace;
  if ($('knowledgeViewBtn')) $('knowledgeViewBtn').disabled = !state.project.localWorkspace;
  $('projectStats').textContent = `${files} files · ${formatCompact(chars)} ${state.project.localWorkspace ? 'indexed sample chars' : 'indexed chars'}${access}${state.project.localPath ? ' · root: ' + state.project.localPath : ''}`;
  renderReferenceFolders();
  updateModeUi();
}

// Workspace knowledge uses the optional Agent Vision model and never persists credentials in the index.
function knowledgeSettings() {
  return {
    baseUrl: state.config.baseUrl, model: state.config.model,
    chatModel: state.config.chatModel || state.config.model,
    visionModel: state.config.visionModel || '', visionBaseUrl: state.config.visionBaseUrl || '',
    visionApiKey: state.config.visionApiKey || ''
  };
}
function setKnowledgeStatus(message, error = false) {
  const node = $('knowledgeStatus');
  if (!node) return;
  node.textContent = message || '';
  node.classList.toggle('hidden', !message);
  node.classList.toggle('error', error);
}
async function viewWorkspaceKnowledge() {
  if (!state.project?.localWorkspace) return toast('Choose a local workspace before viewing knowledge.', 4500);
  const node = $('knowledgePanel');
  if (!node) return;
  const docs = await api(`/api/knowledge/documents?projectId=${encodeURIComponent(state.project.id)}`);
  node.classList.remove('hidden');
  if (!Array.isArray(docs) || !docs.length) {
    node.innerHTML = '<strong>No indexed documents yet.</strong> Choose Analyse Workspace to build the index.';
    return;
  }
  node.innerHTML = `<div class="knowledge-panel-heading"><strong>Indexed documents (${docs.length})</strong><button type="button" class="secondary-btn" id="knowledgeCloseBtn">Close</button></div><div class="knowledge-entries">${docs.map(doc => `<article class="knowledge-document"><strong>${esc(doc.source)}</strong><span>${esc(doc.status)} · images ${Number(doc.analysedVisuals || 0)}/${Number(doc.detectedVisuals || 0)}</span>${Array.isArray(doc.warnings) && doc.warnings.length ? `<small>${esc(doc.warnings.join(' | '))}</small>` : ''}</article>`).join('')}</div>`;
  $('knowledgeCloseBtn').onclick = () => node.classList.add('hidden');
}
let knowledgeIndexing = false;
async function analyseWorkspaceKnowledge() {
  if (!state.project?.localWorkspace) return toast('Choose a local workspace before analysing documents.', 4500);
  if (knowledgeIndexing) return;
  knowledgeIndexing = true;
  $('knowledgeAnalyseBtn').disabled = true;
  const targetProject = state.project.id;
  try {
    setKnowledgeStatus('Starting workspace document analysis…');
    const result = await api('/api/knowledge/analyse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${state.config.apiKey || ''}` },
      body: JSON.stringify({projectId: targetProject, objective: 'Discover and analyse workspace documents including relevant screenshots and diagrams.', settings: knowledgeSettings()})
    });
    if (!result?.jobId) throw new Error('Knowledge indexing job was not created');
    // The server owns the job. Browser reconnects can still inspect completed index entries.
    while (true) {
      await new Promise(resolve => setTimeout(resolve, 1500));
      const job = await api(`/api/knowledge/jobs/${encodeURIComponent(result.jobId)}`);
      if (state.project?.id !== targetProject) break;
      setKnowledgeStatus(`${String(job.phase || 'running').toUpperCase()}: ${job.detail || ''}`, job.phase === 'failed' || job.phase === 'partial');
      if (['completed', 'partial', 'failed'].includes(job.phase)) {
        if (job.phase !== 'failed') await viewWorkspaceKnowledge();
        break;
      }
    }
  } catch (error) {
    setKnowledgeStatus(`Document analysis failed: ${error.message}`, true);
    toast(error.message, 5000);
  } finally {
    knowledgeIndexing = false;
    $('knowledgeAnalyseBtn').disabled = false;
  }
}

// File-deletion confirmations are conspicuous, time-bound, and independent of generic tool grants.
// Backend approval TTL and rollback are authoritative; the countdown never extends the deadline.
function pendingDeletionApproval() {
  for (let index = state.messages.length - 1; index >= 0; index--) {
    const message = state.messages[index];
    if (!message || message.role !== 'assistant' || !Array.isArray(message.agentSteps)) continue;
    if (['completed','failed','cancelled','blocked','interrupted','stalled'].includes(String(message.agentBackendStatus || '').toLowerCase())) continue;
    // Never resurrect historic approvals from an already closed chat. Only a live or
    // actively polled run can produce a modal confirmation.
    if (!(message.streaming || (message.agentRunId && state.activeAgentRunId === message.agentRunId))) continue;
    const steps = message.agentSteps;
    for (let n = steps.length - 1; n >= 0; n--) {
      const step = steps[n];
      if (step.status !== 'approval' || !step.approvalId) continue;
      if (!(step.approvalType === 'file_deletion' || String(step.detail || '').startsWith('FILE DELETION APPROVAL REQUIRED:'))) continue;
      const superseded = steps.slice(n + 1).some(next => next.tool === step.tool && next.step === step.step && next.status !== 'approval');
      if (!superseded) return step;
    }
  }
  return null;
}
function refreshDeletionApprovalModal() {
  const backdrop = $('deletionApprovalBackdrop');
  if (!backdrop) return;
  const step = pendingDeletionApproval();
  if (!step) { backdrop.classList.add('hidden'); backdrop.dataset.approvalId = ''; return; }
  if (backdrop.dataset.approvalId !== step.approvalId) {
    backdrop.dataset.approvalId = step.approvalId;
    $('deletionApprovalTargets').textContent = String(step.output || step.detail || 'Deletion targets are unavailable. Reject if targets are unclear.');
    $('deletionRejectBtn').disabled = false;
    $('deletionApproveBtn').disabled = false;
    backdrop.classList.remove('hidden');
  }
  const expiry = Date.parse(step.approvalExpiresAt || '') || (Date.parse(step.at || '') + 60000);
  const seconds = Number.isFinite(expiry) ? Math.max(0, Math.ceil((expiry - Date.now()) / 1000)) : 0;
  $('deletionApprovalCountdown').textContent = `${seconds}s`;
  if (seconds === 0) {
    $('deletionApproveBtn').disabled = true;
    $('deletionApprovalTargets').textContent += $('deletionApprovalTargets').textContent.includes('Approval expired') ? '' : '\nApproval expired; backend is stopping and restoring the workspace.';
  }
}
async function respondToDeletionApproval(action) {
  const approvalId = $('deletionApprovalBackdrop')?.dataset.approvalId;
  if (!approvalId) return;
  const reject = $('deletionRejectBtn'), approve = $('deletionApproveBtn');
  reject.disabled = true; approve.disabled = true;
  try {
    const result = await api(`/api/agent/approvals/${encodeURIComponent(approvalId)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({action})
    });
    if (!result?.resolved) throw new Error('Approval expired or has already been handled. The backend controls rollback.');
    for (const message of state.messages) for (const step of message.agentSteps || []) {
      if (step.approvalId !== approvalId || step.status !== 'approval') continue;
      step.status = action === 'once' ? 'running' : 'error';
      step.detail = action === 'once' ? 'Explicitly approved once' : 'Deletion rejected; stopping and restoring baseline';
    }
    $('deletionApprovalBackdrop').classList.add('hidden');
    $('deletionApprovalBackdrop').dataset.approvalId = '';
    renderMessages();
  } catch (error) {
    reject.disabled = false;
    toast(error.message, 5000);
    // Never re-enable a timed-out approval in the UI.
    refreshDeletionApprovalModal();
  }
}
window.setInterval(() => {
  if (!$('deletionApprovalBackdrop')?.classList.contains('hidden')) refreshDeletionApprovalModal();
}, 300);

async function rescanProject() {
  if (!state.project?.localWorkspace) {
    return toast('Supply the workspace path in an Agent prompt to activate a live local workspace.', 4500);
  }
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}/rescan-local`, { method: 'POST' });
  renderProjectBar();
  sharedFolderStatus('Project reindex queued; Chat and Agent stay responsive.');
  void watchFolderIndex(state.project, false);
  return toast('Project rescan queued in the background.', 3500);
}

function closeProjectWorkspace() {
  if (state.project?.localWorkspace) forgetActiveLocalWorkspace();
  state.project = null;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  renderProjectBar();
  sharedFolderStatus(state.referenceProjects.length
    ? 'Project disconnected. Read-only reference folders remain shared.'
    : 'Choose a workspace to enable indexed Analyse and context-aware Execute.');
  toast('Workspace disconnected. It will no longer be reused automatically.');
}

function openProjectChanges(index) {
  const message = state.messages[Number(index)];
  const changes = extractProjectFileChanges(message?.content || '');
  if (!changes.length) return toast('No structured project file changes found');
  state.pendingProjectChanges = { index: Number(index), changes };
  $('projectChangesSummary').textContent = `${changes.length} file${changes.length === 1 ? '' : 's'} proposed${state.project ? ` for ${state.project.name}` : ''}.`;
  $('projectChangesList').innerHTML = changes.map(change => `<div class="project-change-row"><span class="project-change-path">${change.operation === 'delete' ? '− ' : '+ '}${esc(change.path)}</span><span class="project-change-size">${change.operation === 'delete' ? 'delete' : `${formatCompact((change.content || '').length)} chars`}</span></div>`).join('');
  const canApply = Boolean(state.project?.localWorkspace) && state.workflowMode === 'execute';
  $('applyProjectChanges').disabled = !canApply;
  $('applyProjectChanges').textContent = canApply ? 'Apply reviewed changes' :
    'Switch to Execute to apply changes';
  $('projectChangesBackdrop').classList.remove('hidden');
}

function closeProjectChanges() {
  $('projectChangesBackdrop').classList.add('hidden');
}

async function downloadPendingProjectPatch() {
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  const response = await fetch('/api/artifacts/project-patch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project?.name || 'project', files: pending.changes })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filenameFromDisposition(response, 'project-fixes.zip');
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
}

async function applyPendingProjectChanges() {
  // Analyse is read-only, including proposal previews and direct patch application.
  if (state.workflowMode !== 'execute') return toast('Analyse is read-only. Select Execute before applying changes.', 6000);
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  if (!state.project?.localWorkspace) {
    return toast('No live local workspace is active. Supply its path in an Agent prompt or download the patch.', 5000);
  }
  const result = await api(`/api/projects/${encodeURIComponent(state.project.id)}/apply`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project.name || 'project', files: pending.changes })
  });
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}`);
  renderProjectBar(); closeProjectChanges();
  const totalApplied = Number(result.applied || 0) + Number(result.deleted || 0);
  toast(`Applied ${totalApplied} change(s); originals backed up`, 5000);
}

function beginEditMessage(index) {
  if (state.streaming) return toast('Finish or stop the active response before editing a previous message.', 4800);
  if (!state.messages[index] || state.messages[index].role !== 'user') return;
  if (state.editingIndex != null && state.messages[state.editingIndex])
    delete state.messages[state.editingIndex].__eliyaEditing;
  state.editingIndex = index;
  state.messages[index].__eliyaEditing = true;
  renderMessages();
  const editor = $('editMessageInput');
  editor?.focus(); editor?.setSelectionRange(editor.value.length, editor.value.length);
}

async function saveEditedMessage(index) {
  const input = $('editMessageInput');
  const edited = String(input?.value || '').trim();
  if (!edited) return toast('Message cannot be empty');
  const original = state.messages[index];
  if (!original || original.role !== 'user' || !state.conversationId) return toast('Unable to locate the original message');
  // A stopped/disconnected stream can leave the local message without its DB id.
  // Reconcile by ordinal rather than refusing to edit a visible saved message.
  let messageId = original.id;
  if (!messageId) {
    try {
      const persisted = await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/messages`);
      const usersBefore = state.messages.slice(0,index+1).filter(m => m.role === 'user').length;
      const stored = persisted.filter(m => m.role === 'user');
      const candidate = stored[usersBefore-1];
      // Never edit a different persisted prompt just because a live turn has no ID.
      if (candidate && String(candidate.content || '') === String(original.content || ''))
        messageId = candidate.id;
    } catch (error) { return toast('Could not load saved message: ' + error.message, 5500); }
  }
  if (!messageId) return toast('Message is not saved on the backend yet; retry after reconnecting.');
  // Stop the old artifact job before rewinding history so its late completion
  // cannot append a stale response after the edited instruction is sent.
  const runningWorkbook = activeWorkbookJobs.get(state.conversationId);
  if (runningWorkbook && ['queued','running'].includes(runningWorkbook.testCaseJob?.status)) {
    const jobId = runningWorkbook.testCaseJob?.id;
    if (!jobId) return toast('Document job is starting. Please retry editing when the progress card has an ID.', 5000);
    try {
      await api(`/api/artifacts/testcases/${encodeURIComponent(jobId)}/cancel?conversationId=${encodeURIComponent(state.conversationId)}`,{method:'POST'});
      activeWorkbookJobs.delete(state.conversationId);
    } catch(error) { return toast('Could not cancel the original test-case generation: '+error.message,6000); }
  }
  const attachments = (original.attachmentIds || []).map(id => state.filesById.get(id)).filter(Boolean);
  const button = document.querySelector('[data-edit-save]'); if (button) button.disabled = true;
  try {
    await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/rewind/${encodeURIComponent(messageId)}`, { method: 'POST' });
    state.messages = state.messages.slice(0, index);
    state.attachments = attachments;
    state.editingIndex = null;
    renderAttachmentTray();
    await sendMessage({ overrideMessage: edited });
  } catch (error) { toast('Could not edit message: ' + error.message, 6500); if (button) button.disabled = false; }
}

function openHistoryMenu(id, anchor) {
  state.historyMenuId = id;
  const menu = $('historyMenu');
  const rect = anchor.getBoundingClientRect();
  menu.style.left = `${Math.min(rect.left, window.innerWidth - 145)}px`;
  menu.style.top = `${Math.min(rect.bottom + 4, window.innerHeight - 100)}px`;
  menu.classList.remove('hidden');
}

function closeHistoryMenu() {
  state.historyMenuId = null;
  $('historyMenu').classList.add('hidden');
}

function openRename(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!conversation) return;
  state.renameId = id;
  $('renameInput').value = conversation.title || '';
  $('renameBackdrop').classList.remove('hidden');
  setTimeout(() => { $('renameInput').focus(); $('renameInput').select(); }, 0);
}

function closeRename() {
  state.renameId = null;
  $('renameBackdrop').classList.add('hidden');
}

async function saveRename() {
  if (!state.renameId) return;
  const title = $('renameInput').value.trim();
  if (!title) return toast('Enter a title');
  const id = state.renameId;
  await api(`/api/conversations/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  });
  closeRename();
  await loadConversations();
  if (state.conversationId === id) $('conversationTitle').textContent = title;
}

async function deleteConversation(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!confirm(`Delete “${conversation?.title || 'this chat'}”?`)) return;
  await api(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (state.conversationId === id) newChat();
  await loadConversations();
}

async function clearAllHistory() {
  if (state.streaming) return toast('Stop the current response before clearing history');
  const count = state.conversations.length;
  const scope = count
    ? `all ${count} chat${count === 1 ? '' : 's'} and saved agent-run history`
    : 'all saved chat and agent-run history';
  if (!confirm(`Clear ${scope}?\n\nModel settings, API details and the active local workspace will be kept.`)) return;
  const result = await api('/api/conversations', { method: 'DELETE' });
  state.conversations = [];
  newChat();
  renderHistory();
  toast(`History cleared (${Number(result?.clearedConversations || 0)} chats, ${Number(result?.clearedAgentRuns || 0)} agent runs)`);
}

function closeMenus() {
  closeHistoryMenu();
  $('exportMenu').classList.add('hidden');
}

function renderPromptLibrary() {
  const host = $('promptLibraryList');
  if (!host) return;
  const search = $('promptLibrarySearch').value.trim().toLowerCase();
  const category = $('promptLibraryCategory').value;
  const shown = PROMPT_LIBRARY.map((item, index) => ({item, index})).filter(({item}) =>
    (!category || item.category === category) && (!search || (item.title + ' ' + item.category + ' ' + (item.purpose || '') + ' ' + item.prompt).toLowerCase().includes(search)));
  $('promptLibraryCount').textContent = shown.length + ' / ' + PROMPT_LIBRARY.length + ' prompts';
  host.innerHTML = shown.length ? shown.map(({item, index}) => `<article class="prompt-library-card"><div class="prompt-library-card-head"><div><span>${esc(item.category)}${item.mode ? ' · ' + esc(item.mode) : ''}</span><strong>${esc(item.title)}</strong>${item.purpose ? `<small>${esc(item.purpose)}</small>` : ''}</div><div class="prompt-card-actions"><button class="secondary-btn" type="button" data-copy-prompt="${index}">Copy</button><button class="primary-btn" type="button" data-use-prompt="${index}">Use prompt</button></div></div><pre>${esc(item.prompt)}</pre></article>`).join('') : '<div class="empty-library">No prompts match this search. Try a broader category or keyword.</div>';
}
function openPromptLibrary() {
  const categories = [...new Set(PROMPT_LIBRARY.map(item => item.category))].sort((a, b) => a.localeCompare(b));
  $('promptLibraryCategory').innerHTML = '<option value="">All categories</option>' + categories.map(category => `<option value="${esc(category)}">${esc(category)}</option>`).join('');
  $('promptLibraryCategory').value = '';
  $('promptLibrarySearch').value = '';
  renderPromptLibrary();
  $('promptLibraryBackdrop').classList.remove('hidden');
  $('promptLibrarySearch').focus();
}
function promptWithCurrentFolders(prompt) {
  let text = prompt;
  if (state.project?.localPath) text = text.replace(/<path>|<target path>/gi, state.project.localPath);
  if (state.referenceProjects.length === 1) {
    const reference = state.referenceProjects[0];
    text = text.replace(/<alias>|<reference alias>/gi, reference.name).replace(/<reference path>|<source path>/gi, reference.path);
    // Practical Playwright migration templates have one illustrative source alias.
    text = text.replace(/\bLegacySelenium\b/g, reference.name);
  }
  return text;
}
function closePromptLibrary() { $('promptLibraryBackdrop').classList.add('hidden'); }

// ---- Event wiring ----
$('brandBtn').onclick = newChat;
$('newChatBtn').onclick = newChat;
$('sendBtn').onclick = () => sendMessage();
$('handoffDismissBtn')?.addEventListener('click',()=>clearHandoffNotice({restoreDraft:true}));
$('stopBtn').onclick = () => stopCurrentRun();
$('attachBtn').onclick = () => $('fileInput').click();
document.querySelectorAll('[data-workflow]').forEach(button => {
  button.addEventListener('click', () => chooseWorkflowMode(button.dataset.workflow));
});
document.querySelectorAll('[data-mode]').forEach(button => {
  button.addEventListener('click', () => { setMode(button.dataset.mode); updateWelcomeMode(); });
});
$('enterProjectBtn').onclick = () => openFolderDialog(false);
$('enterReferenceBtn').onclick = () => openFolderDialog(true);
$('folderPathForm').addEventListener('submit', submitFolderDialog);
$('folderPathInput').addEventListener('input', updateFolderExample);
$('folderAliasInput').addEventListener('input', updateFolderExample);
$('closeFolderPath').onclick = closeFolderDialog;
$('cancelFolderPath').onclick = closeFolderDialog;
$('folderPathBackdrop').addEventListener('click', event => { if (event.target === $('folderPathBackdrop')) closeFolderDialog(); });
$('referenceFolderList').onclick = event => {
  const toggle = event.target.closest('[data-toggle-reference-write]');
  if (toggle) {
    const ref = state.referenceProjects[Number(toggle.dataset.toggleReferenceWrite)];
    if (!ref) return;
    if (state.streaming) return toast('Finish the current response before changing reference permissions');
    if (!ref.writable && !confirm(`Enable read/write access to reference "${ref.name}"?\n\nMigration agents can now create or edit skills, agents and code under:\n${ref.path}\n\nOnly enable this for a trusted local folder.`)) return;
    ref.writable = !ref.writable;
    saveReferenceFolders();
    sharedFolderStatus(`Reference [${ref.name}] is now ${ref.writable ? 'writable for new execution sessions' : 'read-only for new execution sessions'}.`);
    return;
  }
  const rename = event.target.closest('[data-rename-reference]');
  if (rename) {
    const ref = state.referenceProjects[Number(rename.dataset.renameReference)];
    if (!ref) return;
    openFolderDialog(true, ref);
    return;
  }
  const button = event.target.closest('[data-remove-reference]');
  if (!button) return;
  state.referenceProjects.splice(Number(button.dataset.removeReference), 1);
  saveReferenceFolders();
  sharedFolderStatus('Reference disconnected. Chat and Agent now use the updated folder selection.');
};
$('projectRefreshBtn').onclick = () => rescanProject().catch(error => toast(error.message, 5000));
$('knowledgeAnalyseBtn').onclick = analyseWorkspaceKnowledge;
$('knowledgeViewBtn').onclick = () => viewWorkspaceKnowledge().catch(error => toast(error.message, 5000));
$('deletionApproveBtn').onclick = () => respondToDeletionApproval('once');
$('deletionRejectBtn').onclick = () => respondToDeletionApproval('deny');
$('projectCloseBtn').onclick = closeProjectWorkspace;
$('fileInput').onchange = event => { uploadFiles(event.target.files); event.target.value = ''; };
$('quickPromptBtn')?.addEventListener('click', openPromptLibrary);
$('composerPreviewBtn')?.addEventListener('click', () => toggleComposerPreview());
$('insertCodeBtn')?.addEventListener('click', () => {
  const input = $('messageInput');
  if (state.streaming) return toast('Complete or stop the current response before changing the draft');
  const result = CHAT_UX.insertFencedCode(input.value, input.selectionStart, input.selectionEnd, '');
  input.value = result.text;
  autoGrow();
  input.focus();
  input.setSelectionRange(result.cursor, result.cursor);
});
$('clearComposerBtn')?.addEventListener('click', () => {
  if (state.streaming || !$('messageInput').value) return;
  // Clear only the current draft, never a saved message.
  $('messageInput').value = '';
  clearHandoffNotice();
  toggleComposerPreview(false);
  autoGrow();
  $('messageInput').focus();
});
// Markdown is also shown in the composer preview and saved-artifact previews.
// Their code controls must work exactly like code controls in message bubbles.
document.addEventListener('click', async event => {
  const button = event.target.closest?.('[data-code-action]');
  if (!button || button.closest('#messages')) return; // Message handler owns its own actions.
  const block = button.closest('.code-block');
  if (!block) return;
  const action = button.dataset.codeAction;
  const content = block.querySelector('code')?.textContent || '';
  if (action === 'expand') return openCodeInspector(block, button);
  if (action === 'wrap') return void block.classList.toggle('wrap-code');
  if (action === 'copy') {
    try { await copyText(content); toast('Code copied'); }
    catch (error) { toast('Copy failed: ' + error.message, 5000); }
    return;
  }
  if (action === 'download') downloadText(CHAT_UX.safeFilename(block.dataset.ext), content);
});
$('codeInspectorClose')?.addEventListener('click', closeCodeInspector);
$('codeInspectorBackdrop')?.addEventListener('click', event => {
  if (event.target === $('codeInspectorBackdrop')) closeCodeInspector();
});
$('codeInspectorWrap')?.addEventListener('click', () => {
  const wrapped = $('codeInspectorPre').classList.toggle('wrapped');
  $('codeInspectorWrap').setAttribute('aria-pressed', String(wrapped));
});
$('codeInspectorCopy')?.addEventListener('click', async () => {
  if (!codeInspectorSource) return;
  try { await copyText(codeInspectorSource.content); toast('Code copied'); }
  catch (error) { toast('Clipboard unavailable: ' + error.message, 4500); }
});
$('codeInspectorDownload')?.addEventListener('click', () => {
  if (!codeInspectorSource) return;
  downloadText(CHAT_UX.safeFilename(codeInspectorSource.extension), codeInspectorSource.content);
});
$('messageInput').addEventListener('input', autoGrow);
$('messageInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing && !event.repeat) {
    event.preventDefault();
    sendMessage();
  }
});
$('messageInput').addEventListener('paste', event => {
  const files = Array.from(event.clipboardData?.files || []);
  if (files.length) uploadFiles(files);
});
$('historySearch').addEventListener('input', event => renderHistory(event.target.value));
$('promptLibraryBtn').onclick = openPromptLibrary;
const ELIYA_ROLLBACK_INTENT = /^(?:rollback|roll\s*back|undo(?:\s+(?:last|the last))?(?:\s+(?:task|operation|changes))?|revert\s+(?:last|the last)(?:\s+(?:task|changes))?)\s*[.!?]?$/i;
async function performEliyaRollback(sessionId = null) {
  if (state.streaming && !sessionId) return toast('Finish or stop the active task before rollback');
  const projectId = sessionId ? terminalUi.detail?.projectId : state.project?.id;
  const conversationId = sessionId ? terminalUi.detail?.conversationId : state.conversationId;
  if (!projectId || !conversationId) return toast('Select the conversation and workspace containing the task');
  try {
    toast('Checking the last task and its verified changes before rollback…',4500);
    let selectedId = sessionId;
    if (!selectedId) {
      const all = await api('/api/terminal/sessions');
      const candidates = (Array.isArray(all) ? all : []).filter(item => item.engine==='opencode'
        && item.projectId===projectId && item.conversationId===conversationId
        && ['completed','failed'].includes(item.status));
      candidates.sort((a,b)=>Date.parse(b.updatedAt||'')-Date.parse(a.updatedAt||''));
      if (candidates.length) selectedId=candidates[0].id;
    }
    if (selectedId && selectedId.startsWith('oc-')) {
      const preview = await api(`/api/terminal/sessions/${encodeURIComponent(selectedId)}/rollback/preview`);
      if (!preview.available || !preview.fileCount) return toast(preview.detail || 'This OpenCode task has no file changes to undo',6000);
      const paths=(preview.files||[]).slice(0,6).map(file=>` • ${file.relativePath}`).join('\n');
      const remaining=Number(preview.fileCount)>6 ? `\n…and ${Number(preview.fileCount)-6} more` : '';
      if (!confirm(`Undo ${preview.fileCount} verified OpenCode file change(s)?\n${paths}${remaining}\n\nOnly the last completed OpenCode task will be reverted.`)) return;
      const result = await api(`/api/terminal/sessions/${encodeURIComponent(selectedId)}/rollback`,{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({promptId:preview.promptId})});
      if(result.status!=='rolled_back') throw new Error('OpenCode did not confirm rollback');
      toast(`OpenCode rollback confirmed · ${preview.fileCount} file(s)`,6500);
      if (sessionId) await pollTerminalSessions();
      else await openConversation(conversationId);
      return;
    }
    // Eliya native tasks use their own protected snapshot, not a generated prompt.
    const preview = await api(`/api/agent/conversations/${encodeURIComponent(conversationId)}/rollback/latest?projectId=${encodeURIComponent(projectId)}`);
    if (!preview.available) return toast('No tracked Eliya changes are available for rollback',6000);
    if (!confirm('Undo tracked changes from the most recent Eliya task? Later edits are protected.')) return;
    await api(`/api/agent/conversations/${encodeURIComponent(conversationId)}/rollback/latest`,{
      method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({projectId})});
    toast('Eliya rollback completed',6500);
    await openConversation(conversationId);
  } catch(error) {toast('Rollback not completed: '+String(error.message||error),9000);}
}
$('rollbackLastBtn').onclick = () => void performEliyaRollback();
$('promptLibrarySearch').addEventListener('input', renderPromptLibrary);
$('promptLibraryCategory').addEventListener('change', renderPromptLibrary);
$('settingsBtn').onclick = openSettings;
$('topSettingsBtn').onclick = openSettings;
$('closeSettings').onclick = closeSettings;
$('cancelSettings').onclick = closeSettings;
$('modalBackdrop').addEventListener('click', event => { if (event.target === $('modalBackdrop')) closeSettings(); });
$('closePromptLibrary').onclick = closePromptLibrary;
$('promptLibraryBackdrop').addEventListener('click', event => { if (event.target === $('promptLibraryBackdrop')) closePromptLibrary(); });
$('promptLibraryList').addEventListener('click', event => {
  const copyButton = event.target.closest('[data-copy-prompt]');
  if (copyButton) {
    const selected = PROMPT_LIBRARY[Number(copyButton.dataset.copyPrompt)];
    if (selected) void copyText(promptWithCurrentFolders(selected.prompt)).then(() => toast('Prompt copied')).catch(error => toast('Copy failed: '+error.message,5000));
    return;
  }
  const button = event.target.closest('[data-use-prompt]');
  if (!button) return;
  const item = PROMPT_LIBRARY[Number(button.dataset.usePrompt)];
  if (!item) return;
  if (state.streaming) return toast('Finish or stop the current response before using a prompt');
  const nextPrompt = promptWithCurrentFolders(item.prompt);
  if ($('messageInput').value.trim() && $('messageInput').value.trim() !== nextPrompt.trim()
      && !confirm('Replace the current unsent draft with this Prompt Factory template?')) return;
  chooseWorkflowMode(item.mode === 'Chat' ? 'analyse' : 'execute');
  clearHandoffNotice(); // A new template cannot inherit the prior saved-analysis source.
  $('messageInput').value = nextPrompt;
  autoGrow();
  closePromptLibrary();
  $('messageInput').focus();
});
$('toggleKey').onclick = () => togglePassword('apiKey', 'toggleKey');
$('homeToggleKey').onclick = () => togglePassword('homeApiKey', 'homeToggleKey');
if ($('toggleMcpJiraToken')) $('toggleMcpJiraToken').onclick = () => togglePassword('mcpJiraToken', 'toggleMcpJiraToken');
if ($('toggleMcpConfluenceToken')) $('toggleMcpConfluenceToken').onclick = () => togglePassword('mcpConfluenceToken', 'toggleMcpConfluenceToken');
if ($('toggleMcpGitlabToken')) $('toggleMcpGitlabToken').onclick = () => togglePassword('mcpGitlabToken', 'toggleMcpGitlabToken');
if ($('toggleMcpSonarqubeToken')) $('toggleMcpSonarqubeToken').onclick = () => togglePassword('mcpSonarqubeToken', 'toggleMcpSonarqubeToken');
if ($('testMcpConnection')) $('testMcpConnection').onclick = testMcpConnection;
if ($('testEmbeddingModel')) $('testEmbeddingModel').onclick = testEmbeddingModel;
if ($('clearMcpConfig')) $('clearMcpConfig').onclick = clearMcpConfiguration;
if ($('refreshLearning')) $('refreshLearning').onclick = () => loadVerifiedLearning().catch(error => toast(error.message, 5000));
if ($('approveLearning')) $('approveLearning').onclick = approveVerifiedLearning;
if ($('importOpenCodeConfig')) $('importOpenCodeConfig').onclick = () => $('openCodeConfigFile')?.click();
if ($('openCodeConfigFile')) $('openCodeConfigFile').onchange = async event => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  try { await importOpenCodeConfigFile(file); }
  catch (error) {
    if ($('openCodeImportStatus')) { $('openCodeImportStatus').textContent = error.message; $('openCodeImportStatus').classList.add('error'); }
    toast('OpenCode import failed: ' + error.message, 5500);
  }
};
$('openSidebar').onclick = () => $('sidebar').classList.add('open');
$('closeSidebar').onclick = () => $('sidebar').classList.remove('open');
$('scrollBottomBtn').onclick = () => scrollBottom(true);

if ($('addModelBtn')) $('addModelBtn').onclick = addModelFromUi;
if ($('newModelId')) $('newModelId').addEventListener('keydown', event => {
  if (event.key === 'Enter') { event.preventDefault(); addModelFromUi(); }
});
if ($('modelCatalogList')) {
  $('modelCatalogList').addEventListener('click', event => {
    const testButton = event.target.closest('[data-test-model]');
    if (testButton) return testModelFromLibrary(testButton.dataset.testModel, testButton);
    const button = event.target.closest('[data-remove-model]');
    if (button) removeModelFromLibrary(button.dataset.removeModel);
  });
  $('modelCatalogList').addEventListener('change', event => {
    const row = event.target.closest('[data-model-id]');
    if (!row) return;
    const id = row.dataset.modelId;
    if (event.target.matches('[data-model-name]')) return renameModelInLibrary(id, event.target.value);
    if (event.target.matches('[data-model-type]')) return updateModelLibraryEntry(id, {type:event.target.value});
    if (event.target.matches('[data-model-context]')) return updateModelLibraryEntry(id, {context:Math.max(0, Number(event.target.value || 0))});
  });
}
if ($('agentFallbackEnabled')) $('agentFallbackEnabled').addEventListener('change', renderFallbackModels);
if ($('agentFallbackModels')) $('agentFallbackModels').addEventListener('input', renderFallbackModels);
if ($('modelName')) $('modelName').addEventListener('input', renderFallbackModels);
if ($('addFallbackModelBtn')) $('addFallbackModelBtn').onclick = () => {
  const model = String($('fallbackModelSelect')?.value || '').trim();
  if (!model) return;
  writeFallbackModels([...currentFallbackModels(), model]);
};
if ($('fallbackModelList')) $('fallbackModelList').addEventListener('click', event => {
  const button = event.target.closest('[data-fallback-action]');
  const row = event.target.closest('[data-fallback-index]');
  if (!button || !row) return;
  updateFallbackAt(Number(row.dataset.fallbackIndex), button.dataset.fallbackAction);
});

$('themeBtn').onclick = () => {
  const current = document.documentElement.dataset.theme || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  storageSet('local', 'theme', next);
};

if ($('clearHistoryBtn')) $('clearHistoryBtn').onclick = () => {
  clearAllHistory().catch(error => toast(error.message, 5000));
};

$('exportBtn').onclick = event => {
  event.stopPropagation();
  if (!state.conversationId) return toast('No chat to export');
  $('exportMenu').classList.toggle('hidden');
};
$('exportMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-export-format]');
  if (!button || !state.conversationId) return;
  const format = button.dataset.exportFormat;
  $('exportMenu').classList.add('hidden');
  window.location.href = `/api/conversations/${encodeURIComponent(state.conversationId)}/export?format=${encodeURIComponent(format)}`;
});


if ($('agentModelSelect')) {
  $('agentModelSelect').addEventListener('change', event => chooseAgentPrimaryModel(event.target.value));
  $('agentModelSelect').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); chooseAgentPrimaryModel(event.target.value); event.target.blur(); } });
}
if ($('agentVisionSelect')) {
  $('agentVisionSelect').addEventListener('change', event => chooseAgentVisionModel(event.target.value));
  $('agentVisionSelect').addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); chooseAgentVisionModel(event.target.value); event.target.blur(); }
  });
}
if ($('chatModelSelect')) {
  $('chatModelSelect').addEventListener('change', event => chooseChatModel(event.target.value));
  $('chatModelSelect').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); chooseChatModel(event.target.value); event.target.blur(); } });
}

if ($('applyCibProfile')) $('applyCibProfile').onclick = () => {
  ensureRecommendedModels();
  $('modelName').value = 'qwen3.8-27b';
  if ($('chatModel')) $('chatModel').value = 'mistral-small-4-ITG';
  $('contextWindowTokens').value = '0';
  writeFallbackModels(currentFallbackModels());
  toast('Recommended chat and agent models filled in. Save settings to apply.');
};

$('homeSave').onclick = () => {
  state.config.apiKey = $('homeApiKey').value.trim();
  state.config.baseUrl = $('homeBaseUrl').value.trim();
  const chatModels = applyChatModelsText($('homeChatModel')?.value || '');
  const agentModels = applyAgentModelsText($('homeModel')?.value || '');
  state.config.analysisModel = state.config.model;
  state.config.plannerModel = state.config.model;
  state.config.planValidatorModel = state.config.model;
  state.config.criticModel = state.config.model;
  state.config.smartModelRouting = false;
  state.config.rememberKey = $('homeRemember').checked;
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  if (!state.config.agentFallbackModels) state.config.agentFallbackEnabled = false;
  if (!state.config.apiKey || !state.config.baseUrl || !agentModels.length || !chatModels.length) return toast('Enter API key, base URL, one Chat model and one Agent model');
  saveModelCatalog();
  saveConfig();
  syncSettingsUi();
  $('messageInput').focus();
  toast('Model configuration saved');
  void prewarmOpenCode();
};

$('saveSettings').onclick = async () => {
  state.config.apiKey = $('apiKey').value.trim();
  state.config.baseUrl = $('baseUrl').value.trim();
  const chatModels = applyChatModelsText($('chatModel')?.value || '');
  const agentModels = applyAgentModelsText($('modelName')?.value || '');
  state.config.visionModel = ($('visionModelName')?.value || '').trim();
  state.config.chatVisionModel = ($('chatVisionModelName')?.value || '').trim();
  if (state.config.chatVisionModel) ensureModelsInCatalog([state.config.chatVisionModel], 'vision');
  state.config.visionBaseUrl = ($('visionBaseUrl')?.value || '').trim();
  state.config.visionApiKey = $('visionApiKey')?.value || '';
  state.config.analysisModel = state.config.model;
  state.config.plannerModel = state.config.model;
  state.config.planValidatorModel = state.config.model;
  state.config.criticModel = state.config.model;
  state.config.embeddingModel = ($('embeddingModel')?.value || '').trim();
  state.config.semanticRetrieval = Boolean($('semanticRetrieval')?.checked);
  state.config.smartModelRouting = false;
  state.config.temperature = Math.max(0, Math.min(2, Number($('temperature').value || 0.7)));
  state.config.maxTokens = Math.max(0, Number($('maxTokens').value || 0));
  state.config.contextWindowTokens = Math.max(0, Number($('contextWindowTokens').value || 0));
  state.config.autoCompact = $('autoCompact').checked;
  state.config.compactionKeepTokens = Math.max(2000, Number($('compactionKeepTokens').value || 8000));
  state.config.compactionBufferTokens = Math.max(4000, Number($('compactionBufferTokens').value || 20000));
  state.config.oldToolOutputChars = Math.max(400, Number($('oldToolOutputChars').value || 1200));
  state.config.systemPrompt = $('systemPrompt').value;
  state.config.useFileContext = $('useFileContext').checked;
  state.config.agentAllowCommands = $('agentAllowCommands').checked;
  state.config.agentEditPermission = $('agentEditPermission').value;
  state.config.agentShellPermission = $('agentShellPermission').value;
  state.config.agentReviewPermission = $('agentReviewPermission').value;
  state.config.agentMcpPermission = $('agentMcpPermission').value;
  state.config.agentTaskPermission = $('agentTaskPermission').value;
  state.config.agentLspPermission = $('agentLspPermission').value;
  state.config.agentParallelReadTools = $('agentParallelReadTools').checked;
  state.config.agentAutoApprove = $('agentAutoApprove').checked;
  state.config.agentConfirmFileDeletion = $('agentConfirmFileDeletion').checked;
  state.config.agentPlanApproval = $('agentPlanApproval').checked;
  state.config.agentFallbackEnabled = Boolean($('agentFallbackEnabled')?.checked);
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  if (!state.config.agentFallbackModels) state.config.agentFallbackEnabled = false;
  state.config.agentRecoveryAttempts = 3;
  state.config.agentExtraCommands = $('agentExtraCommands').value.trim();
  state.config.rememberKey = $('rememberKey').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !agentModels.length || !chatModels.length) return toast('API key, base URL, one Chat model and one Agent model are required');
  try {
    await saveMcpConfigFromUi({quiet:true});
  } catch (error) {
    setMcpStatus(`Unable to save MCP configuration: ${error.message}`, 'error');
    return toast(`MCP configuration was not saved: ${error.message}`, 5000);
  }
  ensureConfiguredModelsInCatalog();
  saveConfig();
  syncSettingsUi();
  closeSettings();
  updateContextBadge();
  toast('Settings saved');
  void prewarmOpenCode();
};

$('clearKey').onclick = () => {
  state.config.apiKey = '';
  state.config.rememberKey = false;
  storageRemove('session', 'llm.apiKey');
  storageRemove('local', 'llm.apiKey');
  $('apiKey').value = '';
  $('homeApiKey').value = '';
  $('rememberKey').checked = false;
  $('homeRemember').checked = false;
  void syncTerminalSettings(true);
  updateWelcomeMode();
  toast('API key cleared');
};

$('historyList').addEventListener('click', event => {
  const menuButton = event.target.closest('[data-menu]');
  if (menuButton) {
    event.stopPropagation();
    openHistoryMenu(menuButton.dataset.menu, menuButton);
    return;
  }
  const item = event.target.closest('.history-item');
  if (item) openConversation(item.dataset.id).catch(error => toast(error.message, 4000));
});

$('historyMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-history-action]');
  if (!button || !state.historyMenuId) return;
  const id = state.historyMenuId;
  const action = button.dataset.historyAction;
  closeHistoryMenu();
  if (action === 'rename') openRename(id);
  if (action === 'delete') deleteConversation(id).catch(error => toast(error.message, 4000));
});

$('closeRename').onclick = closeRename;
$('cancelRename').onclick = closeRename;
$('saveRename').onclick = () => saveRename().catch(error => toast(error.message, 4000));
$('renameBackdrop').addEventListener('click', event => { if (event.target === $('renameBackdrop')) closeRename(); });
$('renameInput').addEventListener('keydown', event => { if (event.key === 'Enter') saveRename().catch(error => toast(error.message, 4000)); });
$('closeProjectChanges').onclick = closeProjectChanges;
$('cancelProjectChanges').onclick = closeProjectChanges;
$('downloadProjectPatch').onclick = () => downloadPendingProjectPatch().catch(error => toast(error.message, 5000));
$('applyProjectChanges').onclick = () => applyPendingProjectChanges().catch(error => toast(error.message, 5000));
$('projectChangesBackdrop').addEventListener('click', event => { if (event.target === $('projectChangesBackdrop')) closeProjectChanges(); });

$('attachmentTray').addEventListener('click', event => {
  const button = event.target.closest('[data-remove-file]');
  if (!button || button.disabled) return;
  state.attachments = state.attachments.filter(file => file.id !== button.dataset.removeFile);
  renderAttachmentTray();
});

function renumberPlanEditor(editor) {
  editor?.querySelectorAll('[data-plan-row]').forEach((row, index) => {
    const badge = row.querySelector('.plan-edit-index');
    const text = row.querySelector('[data-plan-text]');
    if (badge) badge.textContent = String(index + 1);
    if (text) text.setAttribute('aria-label', `Plan step ${index + 1}`);
  });
}

function collectPlanEditorItems(editor) {
  if (!editor) return [];
  return [...editor.querySelectorAll('[data-plan-row]')]
    .filter(row => row.querySelector('[data-plan-enabled]')?.checked !== false)
    .map(row => String(row.querySelector('[data-plan-text]')?.value || '').trim())
    .filter(Boolean);
}

async function savePlanEditor(editor, quiet = false) {
  if (!editor) return null;
  const runId = editor.dataset.runId;
  const items = collectPlanEditorItems(editor);
  if (!runId) throw new Error('Agent run id is unavailable');
  if (!items.length) throw new Error('Select or add at least one plan step');
  const snapshot = await api(`/api/agent/runs/${encodeURIComponent(runId)}/plan`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items })
  });
  for (const message of state.messages) {
    if (message.agentRunId !== runId) continue;
    message.agentProgress = agentProgressFromSnapshot(snapshot, message.agentProgress);
  }
  if (!quiet) toast('Plan saved');
  return snapshot;
}

$('runMarkdownEdit').onclick = () => {
  if (!currentRunMarkdown || !['chat_artifact','chat_prompt','chat_proposal','chat_inline','chat_response'].includes(currentRunMarkdown.source)) return;
  artifactEditPreviousRawMode=markdownRawMode;
  artifactEditing=true;markdownRawMode=true;showRunMarkdown();$('eliyaArtifactEditor')?.focus();
};
$('runMarkdownSaveEdit').onclick = () => {
  if (!artifactEditing || !currentRunMarkdown) return;
  const edited=$('eliyaArtifactEditor')?.value ?? currentRunMarkdown.content;
  // An edit is a local, unsaved preview version; never overwrite the original chat or workspace.
  currentRunMarkdown.content=edited;
  currentRunMarkdown.bytes=new TextEncoder().encode(edited).length;
  artifactEditing=false;markdownRawMode=artifactEditPreviousRawMode;
  showRunMarkdown();toast('Edits applied to preview. Download to keep the file.');
};
$('runMarkdownCancelEdit').onclick = () => {artifactEditing=false;markdownRawMode=artifactEditPreviousRawMode;showRunMarkdown();};
$('runMarkdownClose').onclick = closeRunMarkdown;
$('runMarkdownBackdrop').addEventListener('click', event => { if (event.target === $('runMarkdownBackdrop')) closeRunMarkdown(); });
$('runMarkdownToggle').onclick = () => { if (!currentRunMarkdown) return; markdownRawMode = !markdownRawMode; showRunMarkdown(); };
$('runMarkdownCopy').onclick = async () => { if (!currentRunMarkdown) return; try { await copyText(currentRunMarkdown.content || ''); toast('Artifact copied'); } catch (error) { toast('Copy failed: '+error.message,5000); } }; 
$('runMarkdownDownload').onclick = () => { if (currentRunMarkdown) downloadText(currentRunMarkdown.name || 'generated-artifact.txt', currentRunMarkdown.content || '', artifactMime((currentRunMarkdown.name || '').split('.').pop().toLowerCase())); };

$('messages').addEventListener('click', async event => {
  const inlineSource=event.target.closest('[data-inline-source]');
  if(inlineSource) {
    const i=Number(inlineSource.dataset.inlineSource);
    const message=state.messages[i];
    if(!message)return;
    const question=previousUserMessage(i)?.content || '';
    const answer=stripProjectMarkers(message.content || '');
    const promptNumber=inlineSource.dataset.promptNumber;
    const full=promptNumber !== undefined
      ? window.EliyaResponseArtifacts?.promptSections(question,answer)?.[Number(promptNumber)]?.content
      : window.EliyaResponseArtifacts?.sourceView(question,answer)?.content;
    if(typeof full!=='string')return toast('Source unavailable');
    const card=inlineSource.closest('.eliya-prompt-card');
    const pre=card?.querySelector('.eliya-prompt-text');
    if(!pre)return;
    const expanded=inlineSource.getAttribute('aria-expanded')==='true';
    // Do not share, shrink or silently replace the complete source used by actions.
    pre.textContent=expanded ? inlineSourcePreview(full).text : full;
    pre.setAttribute('aria-label',expanded?'Source preview; expand for complete source':'Complete source');
    inlineSource.setAttribute('aria-expanded',String(!expanded));
    inlineSource.textContent=expanded?'Show all inline':'Collapse preview';
    card.classList.toggle('eliya-source-expanded',!expanded);
    const notice=card.querySelector('.eliya-source-preview-note');
    if(notice)notice.hidden=!expanded;
    const key=sourceExpandKey(message,i,promptNumber===undefined?null:Number(promptNumber));
    if(expanded) expandedSourceKeys.delete(key); else expandedSourceKeys.add(key);
    persistSourceExpansion();
    return;
  }
  const recoverPrompt=event.target.closest('[data-recover-prompt]');
  if(recoverPrompt){
    const i=Number(recoverPrompt.dataset.recoverPrompt), original=previousUserMessage(i)?.content || '';
    if(!original || state.streaming) return toast('Original prompt request unavailable');
    chooseWorkflowMode('analyse');
    await sendMessage({overrideMessage:`Complete the exact prompt-generation request below NOW using our existing conversation analysis. Output ONE full, independently executable prompt (or the requested number of independent prompts) with objective, workspace context, scope, constraints, implementation steps, testing, acceptance criteria and expected artifacts. Do not output a preamble, an explanation of what you will do, snippets or an outline. Do not execute it. Original request: ${original}`});
    return;
  }
  const finishPrompt=event.target.closest('[data-prompt-complete]');
  if(finishPrompt){
    const i=Number(finishPrompt.dataset.promptComplete),n=Number(finishPrompt.dataset.promptNumber);
    const source=state.messages[i];
    const sections=window.EliyaResponseArtifacts.promptSections(previousUserMessage(i)?.content || '',stripProjectMarkers(source?.content||''));
    const scope=sections[n];
    if(!scope || state.streaming) return toast('Prompt draft unavailable');
    chooseWorkflowMode('analyse');
    await sendMessage({overrideMessage:`Finish the incomplete implementation prompt below as ONE complete, self-contained, directly executable prompt. Preserve the exact selected scope and all relevant findings from conversation message #${Number(source.id)||0}; do not execute anything. Include objective, workspace, required changes, constraints, steps, tests and acceptance criteria. Do not return an introduction or outline.\n\nSELECTED DRAFT:\n${scope.content}`});
    return;
  }
  const completeVerification=event.target.closest('[data-complete-verification]');
  if(completeVerification){
    const i=Number(completeVerification.dataset.completeVerification);
    const question=previousUserMessage(i)?.content || '';
    if(!question || state.streaming) return toast('The verification request is not available');
    chooseWorkflowMode('analyse');
    await sendMessage({overrideMessage:window.EliyaResponseExperience.verificationFollowup(question)});
    return;
  }
  const generatePrompt=event.target.closest('[data-generate-implementation-prompt]');
  if(generatePrompt){
    const i=Number(generatePrompt.dataset.generateImplementationPrompt);
    const analysis=state.messages[i];
    if(!analysis || state.streaming || !window.EliyaWorkflowHandoff.canHandoff(analysis))
      return toast('A completed saved analysis is required to generate a prompt');
    const sourceText=stripProjectMarkers(analysis.content||'').trim();
    if(sourceText.length>28000) return toast('Analysis exceeds the safe prompt-generation handoff size. Split it into a focused scope first.',6500);
    chooseWorkflowMode('analyse');
    await sendMessage({overrideMessage:window.EliyaResponseExperience.promptFollowup(previousUserMessage(i)?.content || 'the previous investigation') +
      `\nAUTHORITATIVE SOURCE: saved Analyse message #${Number(analysis.id)}. The complete selected findings follow. Do not include unrelated conversation topics. Treat unverified findings as checks, not claims.\n--- BEGIN SOURCE FINDINGS ---\n${sourceText}\n--- END SOURCE FINDINGS ---`});
    return;
  }
  const regeneratePromptSet=event.target.closest('[data-prompt-regenerate-set]');
  if (regeneratePromptSet) {
    const i=Number(regeneratePromptSet.dataset.promptRegenerateSet);
    const prior=previousUserMessage(i)?.content || '';
    const expected=window.EliyaResponseArtifacts.expectedPromptCount(prior);
    if(!prior || state.streaming) return toast('Original prompt request is unavailable');
    chooseWorkflowMode('analyse');
    await sendMessage({overrideMessage:`REGENERATE PROMPTS ONLY — DO NOT EXECUTE OR IMPLEMENT.\n\nOriginal user request:\n${prior}\n\n`+
      `Return exactly ${expected||'the requested number of'} DISTINCT complete prompts with top-level headings "## Prompt 1", "## Prompt 2", etc. `+
      'Each prompt must have its own implementation scope, source/target workspace roles, constraints and independent verification criteria. '+
      'DO NOT wrap all prompts in one Markdown code fence. DO NOT repeat all prompts in each prompt. '+
      'No generic "generate implementation prompt" or "implement with agent" steps inside the prompts. '+
      'Output ONLY the separate prompts. Do not execute anything.'});
    return;
  }
  const scopedImplement=event.target.closest('[data-prompt-implement]');
  if (scopedImplement) {prepareScopedPromptHandoff(scopedImplement.dataset.promptImplement,scopedImplement.dataset.promptNumber);return;}
  const liveSource=event.target.closest('[data-live-source-full],[data-live-source-copy],[data-live-source-download]');
  if(liveSource){
    const i=Number(liveSource.dataset.liveSourceFull ?? liveSource.dataset.liveSourceCopy ?? liveSource.dataset.liveSourceDownload);
    const msg=state.messages[i];
    const source=window.EliyaResponseArtifacts.sourceView(previousUserMessage(i)?.content || '',stripProjectMarkers(msg?.content || ''),true);
    if(!msg || !source?.content)return toast('No source text generated yet');
    const name=source.kind==='html'?'generated-page.html':'generated-prompt.md';
    if(liveSource.hasAttribute('data-live-source-download')){
      downloadText(window.EliyaResponseArtifacts.draftFilename(name),source.content,source.kind==='html'?'text/html;charset=utf-8':'text/markdown;charset=utf-8');return;
    }
    if(liveSource.hasAttribute('data-live-source-copy')){
      try{await copyText(source.content);toast('Current source copied');}catch(e){toast('Copy failed: '+e.message,5000);}return;
    }
    currentRunMarkdown={name,relativePath:name,content:source.content,bytes:new TextEncoder().encode(source.content).length,source:'chat_prompt'};
    markdownRawMode=true;$('runMarkdownTitle').textContent='Source generated so far';
    $('runMarkdownPath').textContent='Draft snapshot · generation may still be running';
    $('runMarkdownBackdrop').classList.remove('hidden');showRunMarkdown();return;
  }
  const partialHtml=event.target.closest('[data-file-download-partial]');
  if(partialHtml){
    const i=Number(partialHtml.dataset.fileDownloadPartial);
    const source=window.EliyaResponseArtifacts.sourceView(previousUserMessage(i)?.content || '',stripProjectMarkers(state.messages[i]?.content || ''));
    if(!source?.content)return toast('No HTML text to save');
    downloadText(window.EliyaResponseArtifacts.draftFilename(source.filename || 'generated-page.html'),source.content,'text/html;charset=utf-8');return;
  }
  const promptFull=event.target.closest('[data-prompt-full]');
  if (promptFull) {
    const i=Number(promptFull.dataset.promptFull),msg=state.messages[i];
    const scope=window.EliyaResponseArtifacts.promptSections(previousUserMessage(i)?.content || '',stripProjectMarkers(msg?.content || ''))[Number(promptFull.dataset.promptNumber)];
    if (!scope) return toast('Prompt unavailable');
    currentRunMarkdown={name:window.EliyaResponseArtifacts.promptFileName(scope,Number(promptFull.dataset.promptNumber)),
      relativePath:scope.title,content:scope.content,bytes:new TextEncoder().encode(scope.content).length,source:'chat_prompt'};
    markdownRawMode=true;
    $('runMarkdownTitle').textContent=scope.title;
    $('runMarkdownPath').textContent='Complete selected prompt · ready to copy or download';
    $('runMarkdownBackdrop').classList.remove('hidden');showRunMarkdown();return;
  }
  const promptCopy=event.target.closest('[data-prompt-copy]');
  if (promptCopy) {
    const i=Number(promptCopy.dataset.promptCopy), msg=state.messages[i];
    const scope=window.EliyaResponseArtifacts.promptSections(previousUserMessage(i)?.content || '',stripProjectMarkers(msg?.content || ''))[Number(promptCopy.dataset.promptNumber)];
    if (!scope) return toast('Prompt unavailable');
    try {await copyText(scope.content);toast('Selected prompt copied');}catch(e){toast('Copy failed: '+e.message,5000);}return;
  }
  const promptDownload=event.target.closest('[data-prompt-download]');
  if (promptDownload) {
    const i=Number(promptDownload.dataset.promptDownload), msg=state.messages[i];
    const scope=window.EliyaResponseArtifacts.promptSections(previousUserMessage(i)?.content || '',stripProjectMarkers(msg?.content || ''))[Number(promptDownload.dataset.promptNumber)];
    if (!scope) return toast('Prompt unavailable');
    if (!window.EliyaResponseArtifacts.promptSourceDownloadable(scope)) return toast('No prompt text to save.',6000);
    const filename=window.EliyaResponseArtifacts.promptFileName(scope,Number(promptDownload.dataset.promptNumber));
    downloadText(scope.ready?filename:window.EliyaResponseArtifacts.draftFilename(filename),scope.content,'text/markdown;charset=utf-8');return;
  }
  const sourceFull=event.target.closest('[data-source-full]');
  if(sourceFull){
    const i=Number(sourceFull.dataset.sourceFull);
    const source=window.EliyaResponseArtifacts.sourceView(previousUserMessage(i)?.content || '',stripProjectMarkers(state.messages[i]?.content || ''));
    if(!source.content)return toast('HTML source unavailable');
    currentRunMarkdown={name:source.filename||'generated-page.html',relativePath:source.filename||'generated-page.html',
      content:source.content,bytes:new TextEncoder().encode(source.content).length,source:'chat_artifact'};
    markdownRawMode=true;
    $('runMarkdownTitle').textContent=currentRunMarkdown.name;
    $('runMarkdownPath').textContent='Full HTML source, no hidden lines';
    $('runMarkdownBackdrop').classList.remove('hidden');showRunMarkdown();return;
  }
  const fileCopy=event.target.closest('[data-file-copy]');
  if(fileCopy){
    const i=Number(fileCopy.dataset.fileCopy);
    const source=window.EliyaResponseArtifacts.sourceView(previousUserMessage(i)?.content || '',stripProjectMarkers(state.messages[i]?.content || ''));
    if(!source.content)return toast('HTML source unavailable');
    try{await copyText(source.content);toast('Full HTML source copied');}catch(e){toast('Copy failed: '+e.message,5000);}return;
  }
  const fileButton=event.target.closest('[data-file-preview],[data-file-download],[data-file-complete]');
  if (fileButton) {
    const key=fileButton.hasAttribute('data-file-preview')?'filePreview':fileButton.hasAttribute('data-file-download')?'fileDownload':'fileComplete';
    const i=Number(fileButton.dataset[key]);
    const file=window.EliyaResponseArtifacts.detect(previousUserMessage(i)?.content || '',stripProjectMarkers(state.messages[i]?.content || ''));
    if (key==='fileComplete') {
      chooseWorkflowMode('analyse');
      const filename=file.requested==='html'?'HTML':file.requested==='yaml'?'YAML':file.requested.toUpperCase();
      await sendMessage({overrideMessage:`Regenerate your immediately preceding ${filename} output as ONE complete, standalone ${filename} file. Output ONE fenced ${file.requested} block containing the ENTIRE file from start to finish. No placeholders, ellipses, missing closing tags or disconnected snippets. Keep all originally requested features, with no omitted parts. I need a directly downloadable file.`});
      return;
    }
    if (!file.ready) return toast(file.reason,6000);
    if (key==='fileDownload') {downloadText(file.filename,file.content,artifactMime(file.extension));return;}
    currentRunMarkdown={name:file.filename,relativePath:file.filename,content:file.content,
      bytes:new TextEncoder().encode(file.content).length,source:'chat_artifact'};
    // The inline viewer and Open full source stay dark; this separate button
    // intentionally previews rendered HTML in the existing isolated iframe.
    markdownRawMode=false;
    $('runMarkdownTitle').textContent=file.filename;
    $('runMarkdownPath').textContent='Complete '+file.extension.toUpperCase()+' output from selected response';
    $('runMarkdownBackdrop').classList.remove('hidden');showRunMarkdown();return;
  }
  const handoffButton=event.target.closest('[data-handoff-msg]');
  if (handoffButton) { prepareAnalysisHandoff(handoffButton.dataset.handoffMsg); return; }
  const archivedButton = event.target.closest('[data-saved-artifacts]');
  if (archivedButton) {
    const message = state.messages[Number(archivedButton.dataset.savedArtifacts)];
    if (!message?.id || !state.conversationId) return toast('Saved message not available');
    try {
      message.archivedFiles = await api(`/api/artifacts/saved?conversationId=${encodeURIComponent(state.conversationId)}&messageId=${encodeURIComponent(message.id)}`);
      renderMessages();
      toast(message.archivedFiles.length ? `Found ${message.archivedFiles.length} saved artifact(s)` : 'No structured file proposals archived for this message');
    } catch (error) { toast(`Cannot retrieve saved files: ${error.message}`, 5000); }
    return;
  }
  const approvePlan = event.target.closest('[data-approve-conversation-plan]');
  if (approvePlan) {
    const index = Number(approvePlan.dataset.approveConversationPlan);
    const previous = state.messages[index];
    if (state.streaming || index !== state.messages.length - 1 || previous?.mode !== 'agent' ||
        !/^## Proposed execution plan\b/m.test(String(previous.content || '')) ||
        !/Awaiting explicit approval\./.test(String(previous.content || ''))) return;
    chooseWorkflowMode('execute');
    await sendMessage({overrideMessage:'OK'});
    return;
  }
  const continueSuggested = event.target.closest('[data-agent-next]');
  if (continueSuggested) {
    const index = Number(continueSuggested.dataset.agentNext);
    const previous = state.messages[index];
    if (state.streaming || index !== state.messages.length - 1 || previous?.mode !== 'agent' ||
        !/\*\*Suggested next step:\*\*/.test(String(previous.content || ''))) return;
    // This button represents the user's explicit 'yes' to the last grounded Agent
    // suggestion. The server resolves it from saved conversation history, with no
    // implicit permission for an unrelated plan or a stale workspace.
    chooseWorkflowMode('execute');
    await sendMessage({overrideMessage:'yes'});
    return;
  }
  const promptToggle = event.target.closest('[data-prompt-format]');
  if (promptToggle) {const index=Number(promptToggle.dataset.promptFormat);
    if(formattedPromptOverrides.has(index)) formattedPromptOverrides.delete(index);
    else formattedPromptOverrides.add(index);
    renderMessages();return;}
  const fullView = event.target.closest('[data-full-preview]');
  if(fullView){previewChatResponse(Number(fullView.dataset.fullPreview));return;}
  const htmlView = event.target.closest('[data-html-chat-preview]');
  if(htmlView){previewChatResponse(Number(htmlView.dataset.htmlChatPreview),true);return;}
  const verifySaved=event.target.closest('[data-saved-verify]');
  if(verifySaved){
    const message=state.messages[Number(verifySaved.dataset.savedVerify)];
    if(!message?.id||!state.conversationId)return toast('Saved message is unavailable');
    verifySaved.disabled=true;
    try{
      const checks=await api(`/api/artifacts/saved/verify/${encodeURIComponent(state.conversationId)}/${encodeURIComponent(message.id)}`);
      message.archivedIntegrity=Array.isArray(checks)?checks:[];
      const issues=message.archivedIntegrity.filter(x=>x.status!=='verified');
      toast(issues.length?`${issues.length} artifact(s) require review. Legacy items cannot be checksum-verified.`:
        `All ${message.archivedIntegrity.length} archived artifact(s) passed SHA-256 verification.`,6000);
      renderMessages();
    }catch(error){toast(`Integrity check unavailable: ${error?.message||error}`,6500);verifySaved.disabled=false;}
    return;
  }
  const savedDownload=event.target.closest('[data-saved-download]');
  if (savedDownload) {
    const message=state.messages[Number(savedDownload.dataset.savedDownload)];
    const artifact=message?.archivedFiles?.find(file=>file.id===savedDownload.dataset.savedId);
    if (!message?.id || !artifact || !state.conversationId) return toast('Saved artifact unavailable');
    try {
      const url=`/api/artifacts/saved/${encodeURIComponent(state.conversationId)}/${encodeURIComponent(message.id)}/${encodeURIComponent(artifact.id)}`;
      const response=await fetch(url);
      if (!response.ok) throw new Error(`Artifact retrieval failed (${response.status})`);
      const blob=await response.blob();
      const link=document.createElement('a'),href=URL.createObjectURL(blob);
      link.href=href;link.download=String(artifact.path||'download.txt').split(/[\\/]/).pop()||'download.txt';
      document.body.appendChild(link);link.click();link.remove();
      setTimeout(()=>URL.revokeObjectURL(href),1800);
    } catch(error) {toast('Download failed: '+error.message,6000);}return;
  }
  const savedPreview = event.target.closest('[data-saved-preview]');
  if (savedPreview) {
    const message = state.messages[Number(savedPreview.dataset.savedPreview)];
    const artifact = message?.archivedFiles?.find(file => file.id === savedPreview.dataset.savedId);
    if (!message?.id || !artifact || !state.conversationId) return toast('Archived artifact is unavailable');
    try {
      const url = `/api/artifacts/saved/${encodeURIComponent(state.conversationId)}/${encodeURIComponent(message.id)}/${encodeURIComponent(artifact.id)}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Artifact retrieval failed (${response.status})`);
      const content = await response.text();
      markdownRawMode = false;
      markdownPreviewRequest++;
      currentRunMarkdown = {name:artifact.path.split('/').pop(), relativePath:artifact.path, content,
        bytes:artifact.bytes, source:'chat_proposal'};
      $('runMarkdownTitle').textContent = currentRunMarkdown.name;
      $('runMarkdownPath').textContent = currentRunMarkdown.relativePath;
      $('runMarkdownBackdrop').classList.remove('hidden');
      showRunMarkdown();
    } catch (error) { toast(`Cannot preview archived file: ${error.message}`, 5000); }
    return;
  }
  const proposedButton = event.target.closest('[data-preview-proposed-md]');
  if (proposedButton) {
    openProposedMarkdown(Number(proposedButton.dataset.previewProposedMd), Number(proposedButton.dataset.previewProposedIndex));
    return;
  }
  const proposedDownload = event.target.closest('[data-download-proposed]');
  if (proposedDownload) {
    const files = extractProjectFileChanges(state.messages[Number(proposedDownload.dataset.downloadProposed)]?.content || '');
    const file = files[Number(proposedDownload.dataset.downloadProposedIndex)];
    if (file && file.operation !== 'delete') downloadText(file.path.split('/').pop(), file.content || '');
    return;
  }
  const markdownButton = event.target.closest('[data-preview-agent-md]');
  if (markdownButton) {
    await openRunMarkdown(markdownButton.dataset.previewAgentMd, Number(markdownButton.dataset.previewAgentMdIndex));
    return;
  }

  const stopStalled = event.target.closest('[data-stop-stalled-opencode]');
  if (stopStalled) {
    const runId = stopStalled.dataset.stopStalledOpencode;
    stopStalled.disabled = true;
    try {
      const snapshot = await api(`/api/terminal/sessions/${encodeURIComponent(runId)}/cancel`, {method:'POST'});
      const message = state.messages.find(item => item.agentRunId === runId);
      if (message) {
        message.agentBackendStatus = snapshot.status || 'cancelled';
        message.agentProgress = agentProgressFromSnapshot({status: snapshot.status || 'cancelled'}, message.agentProgress);
        message.agentCompletionReport = null;
      }
      renderMessages();
      toast(snapshot.status==='cancelled' ? 'OpenCode stop confirmed; inspect files before retrying.'
        : snapshot.error || 'OpenCode stop is not confirmed. The workspace may still be in use.', 6500);
    } catch (error) {
      stopStalled.disabled = false;
      toast('Could not stop OpenCode: ' + error.message, 6500);
    }
    return;
  }
  const loadReport = event.target.closest('[data-load-agent-report]');
  if (loadReport) {
    const message = state.messages.find(item => item.agentRunId === loadReport.dataset.loadAgentReport);
    if (message) await fetchAgentCompletionReport(message, false);
    return;
  }
  const copyFile = event.target.closest('[data-copy-file-path]');
  if (copyFile) { try { await copyText(copyFile.dataset.copyFilePath || ''); toast('Full file path copied'); } catch (error) { toast('Copy failed: '+error.message,5000); } return; }
  const copyReport = event.target.closest('[data-copy-agent-report]');
  if (copyReport) {
    const report = state.messages.find(item => item.agentRunId === copyReport.dataset.copyAgentReport)?.agentCompletionReport;
    if (report) { try { await copyText(completionReportMarkdown(report)); toast('Task report copied'); } catch (error) { toast('Copy failed: '+error.message,5000); } }
    return;
  }
  const downloadReport = event.target.closest('[data-download-agent-report]');
  if (downloadReport) {
    const report = state.messages.find(item => item.agentRunId === downloadReport.dataset.downloadAgentReport)?.agentCompletionReport;
    if (report) downloadText(`eliya-task-${String(report.runId || '').slice(0, 8)}.md`, completionReportMarkdown(report), 'text/markdown;charset=utf-8');
    return;
  }

  let button = event.target.closest('[data-plan-add]');
  if (button) {
    const editor = button.closest('[data-plan-editor]');
    const list = editor?.querySelector('[data-plan-list]');
    if (!list) return;
    const row = document.createElement('div');
    row.className = 'plan-edit-row'; row.dataset.planRow = '';
    row.innerHTML = `<label class="plan-select" title="Include this step"><input type="checkbox" data-plan-enabled checked /></label><span class="plan-edit-index"></span><textarea class="plan-edit-text" rows="2" data-plan-text aria-label="New plan step" placeholder="Describe the next executable outcome and its validation"></textarea><div class="plan-row-actions"><button type="button" class="plan-icon-btn" data-plan-move="up" title="Move up">↑</button><button type="button" class="plan-icon-btn" data-plan-move="down" title="Move down">↓</button><button type="button" class="plan-icon-btn danger" data-plan-remove title="Remove step">×</button></div>`;
    list.appendChild(row); renumberPlanEditor(editor); row.querySelector('textarea')?.focus();
    return;
  }

  button = event.target.closest('[data-plan-remove]');
  if (button) { const editor = button.closest('[data-plan-editor]'); button.closest('[data-plan-row]')?.remove(); renumberPlanEditor(editor); return; }

  button = event.target.closest('[data-plan-move]');
  if (button) {
    const row = button.closest('[data-plan-row]'); const list = row?.parentElement; const editor = button.closest('[data-plan-editor]');
    if (!row || !list) return;
    if (button.dataset.planMove === 'up' && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
    if (button.dataset.planMove === 'down' && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
    renumberPlanEditor(editor); return;
  }

  button = event.target.closest('[data-plan-save]');
  if (button) {
    try { button.disabled = true; await savePlanEditor(button.closest('[data-plan-editor]')); renderMessages(); }
    catch (error) { toast(`Plan save failed: ${error.message}`, 4500); }
    finally { button.disabled = false; }
    return;
  }

  button = event.target.closest('[data-agent-to-terminal]');
  if (button) {
    const runId = String(button.dataset.sourceRun || '');
    const approvalId = String(button.dataset.agentToTerminal || '');
    const card = button.closest('.agent-run-card');
    const controls = card?.querySelectorAll('.plan-approval-actions button') || [];
    controls.forEach(el => el.disabled = true);
    try {
      if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) throw new Error('Configure an Agent model first');
      const editor = card?.querySelector('[data-plan-editor]');
      if (editor) await savePlanEditor(editor, true);
      const source = await api(`/api/agent/runs/${encodeURIComponent(runId)}`);
      if (source.planLocked || source.finishedAt || Number(source.mutationRevision) !== 0) throw new Error('The original Agent has already started execution');
      // This is an atomic server-side transfer. The original Agent receives TRANSFER, never approval.
      const request = terminalPayload(String(source.objective || '').trim());
      request.projectId = source.projectId || null;
      request.referenceProjectIds = state.referenceProjects.map(ref => ref.id);
      request.referenceProjectNames = Object.fromEntries(state.referenceProjects.map(ref => [ref.id,ref.name]));
      request.referenceProjectWriteAccess = referenceWriteAccess();
      const created = await api('/api/terminal/transfer', {
        method:'POST', headers:{'Content-Type':'application/json', Authorization:`Bearer ${state.config.apiKey}`},
        body:JSON.stringify({runId,approvalId,request})
      });
      terminalUi.selected = created.id;
      terminalUi.draft = null;
      $('terminalConfigPanel').open = false;
      openTerminalDock();
      await pollTerminalSessions();
      toast('Exact Agent plan transferred into Terminal; the original Agent will not execute it.');
    } catch (error) { toast(`Terminal handoff failed: ${error.message}`, 6500); }
    finally { controls.forEach(el => el.disabled = false); }
    return;
  }

  button = event.target.closest('[data-agent-approval]');
  if (button) {
    const approvalId = String(button.dataset.agentApproval || '').trim();
    const action = String(button.dataset.approvalAction || 'deny').toLowerCase();
    const runCard = button.closest('.agent-run-card');
    const planEditor = runCard?.querySelector('[data-plan-editor]');
    const approvalButtons = button.closest('.agent-approval-actions')?.querySelectorAll('button') || [];
    approvalButtons.forEach(b => b.disabled = true);
    try {
      if (!approvalId || approvalId === 'undefined' || approvalId === 'null') {
        throw new Error('Approval request is missing. Execution has not started.');
      }
      // Approval must commit the current editor contents first; the user should not have to click Save separately.
      if (action !== 'deny' && planEditor) await savePlanEditor(planEditor, true);
      const approvalResult = await api(`/api/agent/approvals/${encodeURIComponent(approvalId)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action })
      });
      if (!approvalResult?.resolved) {
        throw new Error('Approval request is no longer active. Execution was not started.');
      }
      for (const message of state.messages) {
        for (const step of (message.agentSteps || [])) {
          if (step.approvalId === approvalId && step.status === 'approval') {
            step.status = action === 'deny' ? 'error' : 'running';
            step.detail = action === 'run' ? 'Allowed for this run — executing tool' : action === 'once' ? 'Approved once — executing tool' : 'Denied';
          }
        }
      }
      renderMessages();
    } catch (error) {
      approvalButtons.forEach(b => b.disabled = false);
      toast(`Approval failed: ${error.message}`, 4500);
    }
    return;
  }

  button = event.target.closest('[data-code-action]');
  if (button) {
    const block = button.closest('.code-block');
    const code = block?.querySelector('code')?.textContent || '';
    const action = button.dataset.codeAction;
    if (action === 'expand') { openCodeInspector(block, button); return; }
    if (action === 'copy') {
      try { await copyText(code); } catch (error) { toast('Copy failed: '+error.message,5000); return; }
      const label = button.querySelector('span');
      const old = label?.textContent;
      if (label) label.textContent = 'Copied';
      setTimeout(() => { if (label) label.textContent = old || 'Copy'; }, 1200);
      return;
    }
    if (action === 'download') {
      const ext = block?.dataset.ext || 'txt';
      const fileName = ext === 'Dockerfile' ? 'Dockerfile' : `code.${ext}`;
      downloadText(fileName, code);
      return;
    }
    if (action === 'wrap') {
      block?.classList.toggle('wrap-code');
      return;
    }
  }

  button = event.target.closest('[data-copy-msg]');
  if (button) {
    const original = state.messages[Number(button.dataset.copyMsg)]?.content || '';
    try { await copyText(stripProjectMarkers(original) || original); toast('Copied'); }
    catch (error) { toast('Copy failed: '+error.message,5000); }
    return;
  }

  button = event.target.closest('[data-confluence-msg]');
  if (button) { window.EliyaConfluence?.open(stripProjectMarkers(state.messages[Number(button.dataset.confluenceMsg)]?.content || '')); return; }

  button = event.target.closest('[data-download-msg]');
  if (button) {
    const index = Number(button.dataset.downloadMsg);
    const original = state.messages[index]?.content || '';
    downloadText(`assistant-${index + 1}.md`, stripProjectMarkers(original) || original, 'text/markdown;charset=utf-8');
    return;
  }

  button = event.target.closest('[data-pdf-msg]');
  if (button) {
    try { await downloadAssistantPdf(Number(button.dataset.pdfMsg)); }
    catch (error) { toast(`PDF export failed: ${error.message}`, 5000); }
    return;
  }

  button = event.target.closest('[data-excel-msg]');
  if (button) {
    await downloadAssistantExcel(Number(button.dataset.excelMsg));
    return;
  }

  button = event.target.closest('[data-project-changes]');
  if (button) {
    openProjectChanges(Number(button.dataset.projectChanges));
    return;
  }

  button = event.target.closest('[data-execute-terminal]');
  if (button) {
    const msg = state.messages[Number(button.dataset.executeTerminal)];
    const fullText = String(msg?.content || '').trim();
    const prompt = stripProjectMarkers(fullText) || fullText;
    terminalUi.selected=null;terminalUi.detail=null;
    terminalUi.draft={projectId:state.project?.id || null,
      referenceProjectIds:state.referenceProjects.map(ref=>ref.id),
      referenceProjectNames:Object.fromEntries(state.referenceProjects.map(ref=>[ref.id,ref.name])),referenceProjectWriteAccess:referenceWriteAccess(),model:state.config.model};
    openTerminalDock(prompt);
    if(terminalUi.draft.projectId) void launchTerminalPrompt(prompt);
    else { $('terminalConfigPanel').open=true;toast('Choose a local workspace to execute this Chat response'); }
    return;
  }

  button = event.target.closest('[data-regenerate]');
  if (button) {
    if (state.messages[state.messages.length - 1]?.role === 'assistant') state.messages.pop();
    await sendMessage({ regenerate: true });
    return;
  }

  button = event.target.closest('[data-edit-msg]');
  if (button) {
    beginEditMessage(Number(button.dataset.editMsg));
    return;
  }

  button = event.target.closest('[data-edit-cancel]');
  if (button) {
    if (state.editingIndex != null && state.messages[state.editingIndex])
      delete state.messages[state.editingIndex].__eliyaEditing;
    state.editingIndex = null;
    renderMessages();
    return;
  }

  button = event.target.closest('[data-edit-save]');
  if (button) {
    await saveEditedMessage(Number(button.dataset.editSave));
  }
});

$('chatView').addEventListener('scroll', () => {
  state.userScrolledUp = !nearBottom();
  updateScrollButton();
});

document.addEventListener('click', event => {
  const starter = event.target.closest('[data-starter-prompt]');
  if (starter) {
    const mode = starter.dataset.starterMode || 'chat';
    chooseWorkflowMode(mode === 'agent' ? 'execute' : 'analyse');
    $('messageInput').value = starter.dataset.starterPrompt || '';
    autoGrow();
    $('messageInput').focus();
    return;
  }
  if (!event.target.closest('#historyMenu') && !event.target.closest('[data-menu]')) closeHistoryMenu();
  if (!event.target.closest('#exportMenu') && !event.target.closest('#exportBtn')) $('exportMenu').classList.add('hidden');
});

document.addEventListener('keydown', event => {
  if (event.defaultPrevented) return; // Avoid duplicate sends from textarea Enter.
  if (event.key === 'Tab' && !$('runMarkdownBackdrop').classList.contains('hidden')) {
    const buttons=[...$('runMarkdownBackdrop').querySelectorAll('button:not(:disabled):not(.hidden), textarea:not(:disabled)')]
      .filter(el => el.getClientRects().length>0);
    const first=buttons[0],last=buttons[buttons.length-1];
    if(first && last) {
      if(event.shiftKey && document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first.focus();}
    }
    return;
  }
  if (event.key === 'Tab' && !$('codeInspectorBackdrop').classList.contains('hidden')) {
    const buttons = [...$('codeInspectorBackdrop').querySelectorAll('button:not(:disabled)')];
    const first = buttons[0], last = buttons[buttons.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    return;
  }
  const modifier = event.ctrlKey || event.metaKey;
  if (event.altKey && !modifier && event.key.toLowerCase() === 'p' && !$('promptLibraryBackdrop').classList.contains('hidden')) return;
  if (event.altKey && !modifier && event.key.toLowerCase() === 'p') { event.preventDefault(); openPromptLibrary(); return; }
  if (modifier && event.key === 'Enter' && document.activeElement === $('messageInput')) { event.preventDefault(); sendMessage(); return; }
  if (modifier && event.key === '/' && !event.repeat) { event.preventDefault(); $('messageInput').focus(); return; }
  if (modifier && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    $('historySearch').focus();
  }
  if (modifier && event.shiftKey && event.key.toLowerCase() === 'o') {
    event.preventDefault();
    newChat();
  }
  if (event.key === 'Escape') {
    if (!$('codeInspectorBackdrop').classList.contains('hidden')) { closeCodeInspector(); return; }
    if (composerPreviewOpen) toggleComposerPreview(false);
    closeMenus();
    if (!$('modalBackdrop').classList.contains('hidden')) closeSettings();
    if (!$('promptLibraryBackdrop').classList.contains('hidden')) closePromptLibrary();
    if (!$('folderPathBackdrop').classList.contains('hidden')) closeFolderDialog();
    if (!$('renameBackdrop').classList.contains('hidden')) closeRename();
    if (!$('projectChangesBackdrop').classList.contains('hidden')) closeProjectChanges();
    if (!$('runMarkdownBackdrop').classList.contains('hidden')) closeRunMarkdown();
  }
});

let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragleave', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('dragover', event => {
  if (event.dataTransfer?.types?.includes('Files')) event.preventDefault();
});
document.addEventListener('drop', event => {
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  if (event.target.closest?.('#terminalDock') && terminalUi.visible)
    uploadTerminalFiles(event.dataTransfer.files).catch(error => toast(error.message, 4000));
  else uploadFiles(event.dataTransfer.files).catch(error => toast(error.message, 4000));
});

// Reserve the exact footprint of the bottom controls inside the scrollable chat.
// The previous fixed 220px padding could leave the last lines behind the composer
// after reference folders, model pickers or attachments expanded.
function installComposerClearance() {
  const zone = document.querySelector('.composer-zone');
  const messages = document.getElementById('messages');
  if (!zone || !messages) return;
  const update = () => {
    const height = Math.ceil(zone.getBoundingClientRect().height);
    messages.style.paddingBottom = `${Math.max(220, height + 20)}px`;
  };
  update();
  if (typeof ResizeObserver !== 'undefined') {
    const observer = new ResizeObserver(update);
    observer.observe(zone);
  }
  window.addEventListener('resize', update, {passive: true});
}

// Eliya 52 Terminal sessions run in an independent backend flow, not state.streaming.
const terminalUi = { selected: null, sessions: [], detail: null, visible: false, polling: false, workflowMode:'analyse',
  draft: null, lastNotices: new Set(), lastStatuses: new Map(), monitorPolling: false, pendingProjectId: null, editingQueue: null,
  closedTabs: new Set(JSON.parse(storageGet('local','llm.terminalClosedTabs') || '[]')),
  actionHistory: new Map(), renderSignature: null, streamController: null,
  streamSessionId: null, streamUnsupported: false, streamBufferSequence: 0,
  streamPendingTokens: [], refreshHandle: null, decisionSignature: null, forceRender: false,
  attachments: [], attachmentConversationId: null, attachmentsUploading: 0, attachmentOwnerTab: null,
  lastVisibleAnswers: new Map() };
let terminalEngineInfo = {engine:'legacy',connected:false};
function terminalExecutionChoice() {
  // Native execution is mandatory while OpenCode integration is paused.
  return 'legacy';
}
if ($('terminalExecutionEngine')) {
  const stored = storageGet('local','llm.terminalExecutionEngine93') || 'auto';
  $('terminalExecutionEngine').value = ['auto','opencode','legacy'].includes(stored) ? stored : 'auto';
  $('terminalExecutionEngine').addEventListener('change', () => {
    storageSet('local','llm.terminalExecutionEngine93',terminalExecutionChoice());
    toast(terminalExecutionChoice() === 'auto' ? 'Auto starts with a verified engine; Eliya is the fallback.'
      : 'Terminal execution engine: ' + (terminalExecutionChoice()==='legacy'?'Eliya':'OpenCode'));
  });
}
// ELIYA119: Keep no-op hooks so existing configuration events remain harmless.
async function prewarmOpenCode() {
  // OpenCode is paused: never send credentials to an auxiliary runtime.
}
async function refreshTerminalExecutionEngine() {
  // Native Eliya executes every request. No remote OpenCode readiness polling.
  terminalEngineInfo={engine:'legacy',connected:false,autoEligible:false,status:'disabled'};
  const indicator=$('terminalEngineIndicator');
  if (indicator) {
    indicator.textContent='● ELIYA execution';
    indicator.classList.remove('connected');
    indicator.title='Native Eliya agent loop';
  }
}
function terminalSelectWorkflow(mode) {
  if (!['analyse','execute'].includes(mode)) return;
  terminalUi.workflowMode=mode;
  for (const btn of document.querySelectorAll('[data-terminal-workflow]')) {
    const active=btn.dataset.terminalWorkflow===mode;
    btn.classList.toggle('active',active);
    btn.setAttribute('aria-pressed',String(active));
  }
  const hint=$('terminalModeHint');
  if (hint) hint.textContent=mode==='analyse' ? 'Indexed analysis · read-only' : 'Agent execution · changes and tests enabled';
  if ($('terminalTask')) $('terminalTask').placeholder=mode==='analyse'
    ? 'Ask about files, architecture, Jira MCP or an existing result…'
    : 'Describe an implementation, ask a question or continue earlier work…';
}
document.querySelectorAll('[data-terminal-workflow]').forEach(btn=>btn.addEventListener('click',()=>terminalSelectWorkflow(btn.dataset.terminalWorkflow)));
function terminalAttachmentTabId() { return terminalUi.selected || 'new'; }
function clearTerminalAttachments() {
  terminalUi.attachments=[];terminalUi.attachmentOwnerTab=terminalAttachmentTabId();
  renderTerminalAttachments();
}
function renderTerminalAttachments() {
  const tray=$('terminalAttachmentTray');
  if (!tray) return;
  tray.innerHTML=terminalUi.attachments.map(file=>`<span class="terminal-attachment-chip">
    <span>📎 ${esc(file.name)}</span>
    <button type="button" data-terminal-remove-attachment="${esc(file.id)}" ${file.uploading?'disabled':''} aria-label="Remove ${esc(file.name)}">×</button>
  </span>`).join('');
  const busy=terminalUi.attachmentsUploading>0;
  $('terminalSendBtn').disabled=busy;
  if (busy) $('terminalInputHint').textContent='Uploading attachment…';
}
async function uploadTerminalFiles(list) {
  const files=Array.from(list||[]).filter(Boolean);
  if (!files.length) return;
  if(terminalUi.attachmentOwnerTab !== terminalAttachmentTabId()) clearTerminalAttachments();
  if (!terminalUi.attachmentConversationId) {
    const conversation=await api('/api/conversations',{method:'POST'});
    if(!conversation?.id) throw new Error('Cannot create a Terminal attachment conversation');
    terminalUi.attachmentConversationId=conversation.id;
  }
  for(const file of files) {
    if (String(file.type||'').startsWith('audio/') || String(file.type||'').startsWith('video/')) {
      toast(`Unsupported Terminal attachment: ${file.name}`,5000);continue;
    }
    if (String(file.type||'').startsWith('image/') && !state.config.visionModel) {
      toast('Configure Agent Vision model to interpret Terminal image attachments.',6000);continue;
    }
    const pendingId=`pending-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    terminalUi.attachments.push({id:pendingId,name:file.name,uploading:true});
    terminalUi.attachmentsUploading++;renderTerminalAttachments();
    const form=new FormData();
    form.append('conversationId',terminalUi.attachmentConversationId);form.append('file',file);
    try {
      const uploaded=await api('/api/files',{method:'POST',body:form});
      if(!String(uploaded.mimeType||'').startsWith('image/') &&
          (Number(uploaded.extractedCharacters||0)===0 || String(uploaded.extractionStatus||'')!=='ready'))
        throw new Error(`${file.name}: ${uploaded.extractionMessage||'Document extraction unavailable'}`);
      const index=terminalUi.attachments.findIndex(item=>item.id===pendingId);
      if(index>=0) terminalUi.attachments[index]=uploaded;
    } catch(error) {
      terminalUi.attachments=terminalUi.attachments.filter(item=>item.id!==pendingId);
      toast(`Terminal attachment failed: ${error.message}`,6500);
    } finally {terminalUi.attachmentsUploading--;renderTerminalAttachments();}
  }
}
$('terminalAttachBtn').addEventListener('click',()=>$('terminalFileInput').click());
$('terminalFileInput').addEventListener('change',event=>{
  void uploadTerminalFiles(event.target.files).catch(error=>toast(error.message,6000));
  event.target.value='';
});
$('terminalAttachmentTray').addEventListener('click',event=>{
  const remove=event.target.closest('[data-terminal-remove-attachment]');
  if(remove){terminalUi.attachments=terminalUi.attachments.filter(file=>file.id!==remove.dataset.terminalRemoveAttachment);renderTerminalAttachments();}
});
$('terminalTask').addEventListener('paste',event=>{
  const pasted=event.clipboardData?.files;
  if(pasted?.length){event.preventDefault();void uploadTerminalFiles(pasted).catch(error=>toast(error.message,6000));}
});

function terminalCurrentAnchor() {
  const found = terminalUi.sessions.find(s => s.id === terminalUi.selected);
  return terminalUi.detail?.id === terminalUi.selected ? terminalUi.detail : found;
}
function terminalIsBusy(status) { return ['running','queued','waiting_workspace','cancelling','needs_input'].includes(status); }
async function mapTerminalWorkspace(raw) {
  const path = String(raw || '').trim().replace(/^["']|["']$/g, '');
  if (!path) throw new Error('Enter a full local directory path');
  if (!/^(?:[a-zA-Z]:[\\/]|\\\\|\/)/.test(path)) throw new Error('Use an absolute Windows or macOS/Linux directory path');
  // Terminal can be opened before Chat creates any conversation. Registration still
  // needs an owning conversation, but must not silently change the selected Chat tab.
  if (!state.conversationId && !terminalUi.mappingConversationId) {
    const created = await api('/api/conversations',{method:'POST'});
    if (!created?.id) throw new Error('Unable to create a workspace registration context');
    terminalUi.mappingConversationId = created.id;
  }
  const registrationId = state.conversationId || terminalUi.mappingConversationId;
  const project = await api('/api/projects/local', {method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({conversationId:registrationId,path,name:path.split(/[\\/]/).filter(Boolean).pop() || 'Workspace'})});
  terminalUi.pendingProjectId = project.id;
  terminalUi.draft = {...(terminalUi.draft || {}),projectId:project.id,
    referenceProjectIds:terminalUi.draft?.referenceProjectIds || [],referenceProjectNames:terminalUi.draft?.referenceProjectNames || {},
    model:terminalUi.draft?.model || state.config.model};
  await loadTerminalWorkspaces();
  $('terminalWorkspaceSelect').value = project.id;
  terminalUi.draft = terminalDraftFromInputs();
  $('terminalWorkspacePath').value = project.localPath || path;
  $('terminalConfigPanel').open = false;
  toast(`Terminal workspace: ${project.name}. Existing tasks are unchanged.`);
  return project;
}
function terminalPathInstruction(prompt) {
  const command = prompt.match(/^\s*(?:\/workspace\s+|cd\s+|switch\s+(?:workspace\s+)?to\s+)(.+)\s*$/i);
  return command ? command[1].trim() : null;
}
function terminalOpenState() {
  $('terminalDock').classList.remove('minimized');
  $('terminalRestore').classList.add('hidden');
  terminalUi.minimized = false;
}
function openTerminalDock(prompt = '') {
  terminalUi.visible = true;
  document.querySelector('main.main')?.classList.add('eliya-agent-active');
  $('terminalDock').classList.remove('hidden');
  renderUnifiedTabs();
  terminalOpenState();
  if (prompt) $('terminalTask').value = prompt;
  const anchor = terminalCurrentAnchor();
  const workspace = anchor?.projectId ? 'Terminal workspace ready' : (state.project?.localPath || state.project?.name || 'No mapped workspace selected');
  $('terminalWorkspace').textContent = workspace;
  if (!terminalUi.draft && !terminalUi.selected) {
    terminalUi.draft = { projectId: terminalUi.pendingProjectId || state.project?.id || null,
      referenceProjectIds: state.referenceProjects.map(ref => ref.id),
      referenceProjectNames: Object.fromEntries(state.referenceProjects.map(ref => [ref.id,ref.name])),
      referenceProjectWriteAccess:referenceWriteAccess() };
  }
  $('terminalConfigPanel').open = Boolean(terminalUi.draft && !terminalUi.selected && !terminalUi.draft.projectId);
  void loadTerminalWorkspaces();
  void refreshTerminalExecutionEngine();
  pollTerminalSessions();
  $('terminalTask').focus();
}
async function loadTerminalWorkspaces() {
  const requested = terminalUi.workspaceRequest = (terminalUi.workspaceRequest || 0) + 1;
  const select = $('terminalWorkspaceSelect');
  const refs = $('terminalReferences');
  const models = $('terminalModelSelect');
  const chosenModel = (document.activeElement === models ? models.value : (terminalUi.draft?.model || models.value || state.config.model));
  if (document.activeElement !== models) models.value = chosenModel || '';
  const selected = terminalUi.draft?.projectId ?? terminalUi.pendingProjectId ?? terminalCurrentAnchor()?.projectId ?? state.project?.id ?? '';
  const chosenRefs = terminalUi.draft?.referenceProjectIds || terminalCurrentAnchor()?.referenceProjectIds || state.referenceProjects.map(ref => ref.id);
  try {
    const workspaces = await api('/api/terminal/workspaces');
    if (requested !== terminalUi.workspaceRequest) return;
    terminalUi.workspaces = workspaces;
    select.replaceChildren(new Option('External analysis (no local workspace)', ''));
    refs.replaceChildren();
    for (const workspace of workspaces) {
      if (!workspace?.id) continue;
      const label = `${workspace.name || 'Workspace'} — ${workspace.localPath || ''}`;
      select.add(new Option(label, workspace.id));
      refs.add(new Option(label, workspace.id));
    }
    if (selected && [...select.options].some(option => option.value === selected)) select.value = selected;
    $('terminalWorkspacePath').value = workspaces.find(project => project.id === select.value)?.localPath || '';
    for (const option of refs.options) option.selected = chosenRefs.includes(option.value);
    renderTerminalReferences();
    await refreshTerminalWorkspaceView();
  } catch (error) { if(requested === terminalUi.workspaceRequest) $('terminalWorkspace').textContent = `Workspace discovery unavailable: ${error.message}`; }
}
function terminalDraftFromInputs() {
  const projectId = $('terminalWorkspaceSelect').value || null;
  const names = {};
  const ids = [...$('terminalReferences').selectedOptions].map(option => {
    const known = state.referenceProjects.find(ref=>ref.id===option.value);
    names[option.value] = known?.name || option.textContent.split(' — ')[0]; return option.value;
  }).filter(id => id !== projectId).slice(0, 5);
  return { projectId, referenceProjectIds: ids, referenceProjectNames: names,
    referenceProjectWriteAccess: Object.fromEntries(ids.filter(id => state.referenceProjects.some(ref => ref.id === id && ref.writable)).map(id => [id, true])),model:$('terminalModelSelect').value || state.config.model };
}
async function refreshTerminalWorkspaceView() {
  const selected = $('terminalWorkspaceSelect').value;
  const count = [...$('terminalReferences').selectedOptions].length;
  const active = terminalCurrentAnchor();
  const suffix = active?.projectId && active.projectId !== selected ? ' · next instruction switches workspace' : '';
  $('terminalWorkspace').textContent = `${$('terminalWorkspaceSelect').selectedOptions[0]?.textContent || 'No local workspace'} · ${count} reference(s)${suffix}`;

}

$('terminalWorkspaceSelect').addEventListener('change',()=>{ terminalUi.pendingProjectId = null; terminalUi.draft = terminalDraftFromInputs();
  const selectedOption = $('terminalWorkspaceSelect').selectedOptions[0];
  const found = terminalUi.workspaces?.find(project=>project.id===selectedOption?.value);
  $('terminalWorkspacePath').value = found?.localPath || ''; void refreshTerminalWorkspaceView(); });
$('terminalMapWorkspace').addEventListener('click', async () => {const button=$('terminalMapWorkspace');button.disabled=true;
  try {await mapTerminalWorkspace($('terminalWorkspacePath').value);} catch(error) {toast(`Workspace: ${error.message}`,6500);} finally {button.disabled=false;}});
$('terminalWorkspacePath').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();$('terminalMapWorkspace').click();}});
function renderTerminalReferences() {
  const refs=$('terminalReferences');
  const list=$('terminalReferenceChips');
  const checked=new Set([...refs.selectedOptions].map(option=>option.value));
  list.innerHTML = state.referenceProjects.length
    ? state.referenceProjects.map(ref=>{
      const available=[...refs.options].some(o=>o.value===ref.id);
      return `<div class="terminal-reference-entry"><label class="terminal-ref-select"><input type="checkbox" data-terminal-ref="${esc(ref.id)}" ${checked.has(ref.id)?'checked':''} ${!available?'disabled':''}><span><strong>${esc(ref.name)}</strong><small>${esc(ref.path)} · ${ref.writable?'read/write':'read-only'}${!available?' · remap path':''}</small></span></label><button type="button" class="terminal-ref-write" data-terminal-toggle-write="${esc(ref.id)}" title="${ref.writable?'Disable reference writes':'Enable reference writes for migration'}" aria-label="${ref.writable?'Make read-only':'Allow writing to'} ${esc(ref.name)}">${ref.writable?'🔓':'🔒'}</button></div>`;
    }).join('') : '<small>No references yet · add a path and alias below</small>';
}
$('terminalReferenceChips').addEventListener('click', event => {
  const button = event.target.closest('[data-terminal-toggle-write]');
  if (!button) return;
  const ref = state.referenceProjects.find(item => item.id === button.dataset.terminalToggleWrite);
  if (!ref) return;
  if (state.streaming) return toast('Finish the current response before changing reference permissions');
  if (!ref.writable && !confirm(`Allow migration writes into reference "${ref.name}"?\n\nOpenCode and Eliya agents may create or edit files under:\n${ref.path}\n\nExisting running jobs keep their previously granted permissions.`)) return;
  ref.writable = !ref.writable;
  saveReferenceFolders();
  terminalUi.draft = terminalDraftFromInputs();
  renderTerminalReferences();
  toast(`Reference "${ref.name}" is ${ref.writable?'writable':'read-only'} for new execution sessions`, 4500);
});
$('terminalReferenceChips').addEventListener('change',event=>{
  const checkbox=event.target.closest('[data-terminal-ref]');
  if(!checkbox)return;
  const option=[...$('terminalReferences').options].find(o=>o.value===checkbox.dataset.terminalRef);
  if(option) option.selected=checkbox.checked;
  if([...$('terminalReferences').selectedOptions].length>5){option.selected=false;checkbox.checked=false;return toast('Maximum five references');}
  terminalUi.draft=terminalDraftFromInputs();void refreshTerminalWorkspaceView();
});
$('terminalAddReference').addEventListener('click',()=>{
  // Same path+alias dialog and read-only registration as Home.
  openFolderDialog(true);
});
$('terminalReferences').addEventListener('change',()=>{ terminalUi.draft = terminalDraftFromInputs();renderTerminalReferences(); });
$('terminalModelSelect').addEventListener('change',()=>{ terminalUi.draft = terminalDraftFromInputs(); });
function closeTerminalDock() {
  terminalStopStream();
  terminalUi.visible = false;
  terminalUi.minimized = false;
  document.querySelector('main.main')?.classList.remove('eliya-agent-active');
  $('terminalDock').classList.add('hidden');
  renderUnifiedTabs();
  $('terminalRestore').classList.add('hidden');
}
$('terminalMinimize').addEventListener('click',()=>{
  terminalStopStream();
  terminalUi.minimized = true; terminalUi.visible = false;
  $('terminalDock').classList.add('minimized');
  $('terminalRestore').classList.remove('hidden');
});
$('terminalRestore').addEventListener('click',()=>{terminalUi.visible=true;terminalOpenState();void pollTerminalSessions();});
$('terminalMaximize').addEventListener('click',()=>{
  const dock=$('terminalDock');dock.classList.toggle('maximized');
  $('terminalMaximize').textContent=dock.classList.contains('maximized')?'❐':'□';
  $('terminalMaximize').setAttribute('aria-label',dock.classList.contains('maximized')?'Restore window':'Maximize Terminal');
});
// Persist the visible trace on tab switches and merge in each new poll by stable server sequence.
const TERMINAL_ACTION_TYPES = new Set(['agent_step','agent_changes','error','stopped','attachment_transfer','turn_start']);
function terminalActionState(sessionId) {
  if (!terminalUi.actionHistory.has(sessionId)) terminalUi.actionHistory.set(sessionId, {
    events: new Map(), hasMore: false, loaded: false, loading: false, truncated: false, journalError: false
  });
  return terminalUi.actionHistory.get(sessionId);
}
function terminalVisibleActions(detail) {
  const state = terminalActionState(detail.id);
  for (const event of detail.events || []) {
    if (TERMINAL_ACTION_TYPES.has(event.type) && Number.isFinite(Number(event.seq)))
      state.events.set(Number(event.seq), event);
  }
  // OpenCode supplies lifecycle updates with the same tool actionId. Preserve
  // the first arrival position, but replace its row with the latest status,
  // command, output and error. Unrelated actions retain chronological order.
  const ordered = [...state.events.values()].sort((a,b)=>Number(a.seq)-Number(b.seq));
  const byTool = new Map();
  const rows = [];
  for (const event of ordered) {
    const actionId=String(event.data?.actionId||'');
    if (event.type==='agent_step' && actionId) {
      if (byTool.has(actionId)) {
        const index=byTool.get(actionId);
        rows[index]={...event,seq:rows[index].seq,
          data:{...rows[index].data,...event.data}};
        continue;
      }
      byTool.set(actionId,rows.length);
    }
    rows.push(event);
  }
  return rows;
}
function terminalToolCategory(tool, status) {
  if (status === 'error' || status === 'failed') return 'error';
  if (status === 'approval') return 'approval';
  if (/^(?:bash|resource_bash|process_|http_request|mcp_)/.test(tool)) return 'command';
  if (/^(?:write|edit|delete|move|copy|apply_patch|resource_(?:write|edit|delete|move|copy))$/.test(tool)) return 'write';
  if (/^(?:read|glob|grep|file_|resource_(?:read|glob|grep|chunk|info|index))/.test(tool)) return 'read';
  return 'phase';
}
function terminalActionHtml(event) {
  const data = event.data || {};
  const status = String(data.status || (event.type === 'error' ? 'error' : 'info')).toLowerCase();
  const tool = String(data.tool || event.type || 'activity');
  const category = terminalToolCategory(tool,status);
  const icon = category === 'command' ? '›_' : category === 'write' ? '✎' : category === 'read' ? '⌕' : category === 'error' ? '!' : category === 'approval' ? '?' : '◆';
  const message = String(data.detail || data.message || data.prompt || (event.type === 'turn_start' ? 'Instruction started' : ''));
  const output = data.output == null ? '' : typeof data.output === 'string' ? data.output : JSON.stringify(data.output,null,2);
  const args = data.args == null ? '' : typeof data.args === 'string' ? data.args : JSON.stringify(data.args,null,2);
  const hasDetails = Boolean(args || output || data.approvalId);
  return `<div class="terminal-action-row terminal-action-${category}" data-action-seq="${Number(event.seq)||0}">
    <div class="terminal-action-gutter"><span class="terminal-action-icon">${icon}</span></div>
    <div class="terminal-action-content">
      <div class="terminal-action-title"><strong>${esc(tool.replaceAll('_',' '))}</strong><span class="terminal-action-status status-${esc(status)}">${esc(status)}</span><small>${Number(data.step)>0 ? `Step ${Number(data.step)} · ` : ''}#${Number(event.seq)||0}</small></div>
      ${message ? `<div class="terminal-action-description">${esc(message)}</div>` : ''}
      ${hasDetails ? `<details class="terminal-action-detail" data-action-detail="${Number(event.seq)||0}"><summary>View ${args?'input':''}${args&&output?' / ':''}${output?'output':''}${!args&&!output?'approval':''}</summary>
        ${args ? `<div class="terminal-action-code-label">Tool input</div><pre>${esc(args)}</pre>` : ''}
        ${output ? `<div class="terminal-action-code-label">Tool output</div><pre>${esc(output)}</pre>` : ''}
        ${data.approvalId ? `<div class="terminal-action-code-label">Approval requested · ${esc(String(data.approvalId))}</div>` : ''}
      </details>` : ''}
    </div>
  </div>`;
}
async function terminalLoadActions(sessionId, older=false) {
  const history = terminalActionState(sessionId);
  if (history.loading) return;
  history.loading = true;
  try {
    const earliest = history.events.size ? Math.min(...history.events.keys()) : null;
    const before = older && earliest !== null ? `&before=${earliest}` : '';
    const result = await api(`/api/terminal/sessions/${encodeURIComponent(sessionId)}/activity?limit=150${before}`);
    for (const event of result.events || []) {
      if (TERMINAL_ACTION_TYPES.has(event.type)) history.events.set(Number(event.seq),event);
    }
    history.loaded = true;
    history.hasMore = Boolean(result.hasMore);
    history.truncated = Boolean(result.truncated);
    history.journalError = Boolean(result.journalError);
  } catch (error) {
    // A legacy server may not yet expose the activity API; its current event window still renders.
    history.loaded = true;
    history.hasMore = false;
  } finally {
    history.loading = false;
    if (terminalUi.selected === sessionId && terminalUi.detail?.id === sessionId) {
      terminalUi.forceRender=true;renderTerminalUi();
    }
  }
}
// The question lives outside the scrolling activity log. Rebuilding the log must never
// destroy a partially typed clarification. These controls are shared by all Terminal states.
function renderTerminalDecision(detail) {
  const dock = $('terminalDecisionDock');
  const question = detail?.question || {};
  const status = String(detail?.status || '');
  const key = status === 'needs_input' ? JSON.stringify([detail.id, question]) : '';
  if (terminalUi.decisionSignature === key) return;
  terminalUi.decisionSignature = key;
  if (!key) { dock.textContent='';dock.classList.add('hidden');return; }
  const reason = String(question.reason || question.question || question.proposal || 'What should I do next?');
  const fromOpenCode = detail.engine==='opencode';
  const permission = fromOpenCode && question.source==='permission';
  dock.innerHTML = `<div class="terminal-question" role="status"><strong>${fromOpenCode?'OpenCode':'Eliya'} asks:</strong> ${esc(reason)}
    ${permission ? `<div class="terminal-question-actions"><button type="button" data-terminal-answer="${esc(detail.id)}" data-question-id="${esc(question.id)}" data-answer-choice="once">Approve once</button><button type="button" data-terminal-answer="${esc(detail.id)}" data-question-id="${esc(question.id)}" data-answer-choice="reject">Deny</button></div>` : ''}
    <small>${permission?'Approve or deny the action above.':'Type your answer in the Terminal message box below and press Enter.'}</small></div>`;
  dock.classList.remove('hidden');
}
function terminalFastPatch(detail) {
  const output=$('terminalOutput');
  const nearBottom=output.scrollHeight-output.scrollTop-output.clientHeight<90;
  const raw=output.querySelector('.terminal-stream-raw');
  uiRememberTerminalStream(detail);
  if (raw) {
    const next=String(detail.answer || '');
    if (raw.textContent !== next) raw.textContent=next;
  } else if (detail.answer && terminalIsBusy(detail.status)) {
    const conversation=output.querySelector('.terminal-conversation');
    if (conversation) {
      const section=document.createElement('section');section.className='terminal-message terminal-agent terminal-streaming';
      const label=document.createElement('div');label.className='terminal-message-label';label.textContent='Eliya · streaming';
      const pre=document.createElement('pre');pre.className='terminal-stream-raw';pre.textContent=String(detail.answer);
      section.append(label,pre);conversation.append(section);
    }
  }
  const feed=output.querySelector('.terminal-action-feed');
  if (feed) {
    const activities=terminalVisibleActions(detail);
    const list=feed.querySelector('.terminal-action-list');
    if(list) {
      const nextMarkup=activities.length ? activities.map(terminalActionHtml).join('')
        : `<p class="terminal-muted">${terminalIsBusy(detail.status) ? 'Waiting for the first real tool action…' : 'No agent tool actions recorded for this conversation.'}</p>`;
      // Do not rewrite the entire conversation or expand/collapse open tool
      // outputs on each SSE event; only the action feed changes.
      if (list.dataset.signature!==String(activities.map(item=>JSON.stringify(item)).join('|'))) {
        const open=[...list.querySelectorAll('.terminal-action-detail[open]')].map(node=>node.dataset.actionDetail);
        list.innerHTML=nextMarkup;
        list.dataset.signature=String(activities.map(item=>JSON.stringify(item)).join('|'));
        for(const key of open) {
          const node=[...list.querySelectorAll('.terminal-action-detail')].find(x=>x.dataset.actionDetail===key);
          if(node) node.open=true;
        }
      }
    }
    const count=feed.querySelector('.terminal-action-header small');
    if (count) count.textContent=`${activities.length} shown · ${Number(detail.sequence||0)} session events`;
  }
  const progress=detail.progress || {};
  const progressNode=output.querySelector('.terminal-live-panel');
  if(progressNode) {
    const percent=Math.max(0,Math.min(100,Number(progress.progressPercent||0)));
    const phase=progressNode.querySelector('.terminal-live-title strong');
    const progressPercent=progressNode.querySelector('.terminal-live-title span:last-child');
    const description=progressNode.querySelector('p');
    const bar=progressNode.querySelector('.terminal-progress-track > div');
    if(phase) phase.textContent=progress.progressPhase || progress.status || detail.status;
    if(progressPercent) progressPercent.textContent=progress.indeterminate ? 'Working · % unavailable'
      : percent+'%'+(progress.estimated?' est.':'');
    if(description) description.textContent=(progress.progressDetail || 'Agent is working…')
      +(Number(progress.observedActions)? ` · ${Number(progress.observedActions)} observed actions` : '');
    if(bar) bar.style.width=(progress.indeterminate ? 15 : percent)+'%';
  }
  const usageNode=output.querySelector('.execution-token-strip');
  if (usageNode) {
    const rawUsage=detail.engine==='opencode' ? detail.usage : detail.progress?.tokenUsage;
    const template=document.createElement('div');
    template.innerHTML=executionTokenStripHtml(rawUsage,!terminalIsBusy(detail.status));
    usageNode.replaceWith(template.firstElementChild);
  }
  if(nearBottom) output.scrollTop=output.scrollHeight;
}
function terminalRenderKey(detail) {
  const turns=Array.isArray(detail.turns) ? detail.turns : [];
  const last=turns[turns.length-1] || {};
  return JSON.stringify([detail.id,detail.status,detail.runId,turns.length,
    String(last.content||'').length,String(last.content||'').slice(-80),
    detail.events?.[detail.events.length-1]?.seq || 0,
    detail.queue || [],detail.queuePaused,detail.question || {},detail.error || '',
    detail.changeReport?.files?.length ?? -1, detail.changeReport?.filesVerified ?? false,
    detail.usage?.providerTotalTokens ?? 0, detail.usage?.usageStatus ?? '',
    detail.usage?.modelCalls ?? 0,
    terminalUi.editingQueue?.id || '',terminalUi.forceRender]);
}
const eliyaTerminalReports = new Map();
const eliyaTerminalReportsPending = new Set();
async function getTerminalChangeReport(runId) {
  if (!runId || eliyaTerminalReports.has(runId) || eliyaTerminalReportsPending.has(runId)) return;
  eliyaTerminalReportsPending.add(runId);
  try {
    const report = await api(`/api/agent/runs/${encodeURIComponent(runId)}/completion-report`);
    eliyaTerminalReports.set(runId, report);
    if (terminalUi.visible && terminalUi.detail?.runId===runId) renderTerminalUi();
  } catch(error) {eliyaTerminalReports.set(runId,{status:'unavailable',fileReportWarning:error.message,files:[]});}
  finally {eliyaTerminalReportsPending.delete(runId);}
}
function eliyaWhyChangedHtml(report) {
  if (!report) return '';
  const files=Array.isArray(report.files)?report.files:[];
  const objective=String(report.objective||'');
  const verified=Boolean(report.filesVerified);
  return `<section class="eliya-final-change-summary" aria-label="Execution change summary">
    <h3>Execution summary · What changed and why</h3>
    <p><strong>Task:</strong> ${esc(objective||'No objective recorded')}</p>
    <p><strong>Result:</strong> ${esc(report.status||'unknown')} · <strong>Verification:</strong> ${esc(report.verification||'Not recorded')}</p>
    <p><strong>Files:</strong> ${verified ? `${Number(report.created||0)} added · ${Number(report.modified||0)} modified · ${Number(report.deleted||0)} removed` : 'OpenCode could not provide an authoritative file diff for this run'}</p>
    ${files.length ? `<div class="eliya-change-file-list">${files.map(file=>`<div><strong>${esc(file.action||'changed')}</strong> <code>${esc(file.relativePath||file.name||'')}</code><p><b>What:</b> ${esc(file.detail||'Tracked file change')}</p><p><b>Why:</b> ${esc(file.reason|| (objective ? 'Associated with the requested task: '+objective : 'Per-file rationale not recorded'))}</p>${file.excerpt?`<details><summary>View actual diff</summary><pre>${esc(file.excerpt)}</pre></details>`:''}</div>`).join('')}</div>` : '<p>No individual file changes were recorded.</p>'}
    ${report.fileReportWarning?`<p class="agent-report-warning">${esc(report.fileReportWarning)}</p>`:''}
  </section>`;
}
function renderTerminalUi() {
  const output = $('terminalOutput');
  // Polling must preserve the user's scroll position, selections, and half-written answers.
  const scrollTop = output.scrollTop;
  const nearBottom = output.scrollHeight - output.scrollTop - output.clientHeight < 90;
  const recoveryEditor = $('terminalRecoveryText');
  const recoveryDraft = recoveryEditor?.value || '';
  const recoveryFocused = document.activeElement === recoveryEditor;
  const recoveryCursor = recoveryFocused ? recoveryEditor.selectionStart : 0;
  const questionEditor = $('terminalClarificationText');
  const questionDraft = questionEditor?.value || '';
  const questionFocused = document.activeElement === questionEditor;
  const questionCursor = questionFocused ? questionEditor.selectionStart : 0;
  const queueEditor = output.querySelector('[data-terminal-queue-editor]');
  const queueEditorFocused = queueEditor && document.activeElement === queueEditor;
  const queueEditorCursor = queueEditorFocused ? queueEditor.selectionStart : 0;
  if (queueEditor && terminalUi.editingQueue?.id === queueEditor.dataset.terminalQueueEditor)
    terminalUi.editingQueue.draft = queueEditor.value;
  const visibleSessions = terminalUi.sessions.filter(session=>!terminalUi.closedTabs.has(session.id));
  $('terminalTabs').innerHTML = visibleSessions.map((session,i) =>
    `<div class="terminal-tab ${terminalUi.selected === session.id ? 'active' : ''}"><button class="terminal-tab-select" type="button" role="tab" aria-selected="${terminalUi.selected === session.id}" data-terminal-tab="${esc(session.id)}" title="${esc(session.prompt)}"><span class="terminal-status-dot ${esc(session.status)}"></span>${i+1}. ${esc(String(session.prompt || 'Agent task').slice(0,25))}${Number(session.queueCount) ? ` <span class="terminal-tab-queue">+${session.queueCount}</span>` : ''}${Number(session.progress?.observedActions)>0 ? ` <span class="terminal-tab-queue" title="Observed agent actions">⚡${Number(session.progress.observedActions)}</span>` : ''}</button><button type="button" class="terminal-tab-close" data-terminal-tab-close="${esc(session.id)}" title="Close this tab (task continues safely)" aria-label="Close terminal tab ${i+1}">×</button></div>`
  ).join('') + (terminalUi.draft && !terminalUi.selected ? '<button class="terminal-tab active" role="tab" aria-selected="true" data-terminal-draft>＋ New conversation</button>' : '');
  $('terminalReopenTabs').classList.toggle('hidden',terminalUi.closedTabs.size===0);
  const detail = terminalUi.detail;
  renderTerminalDecision(detail);
  if (terminalUi.draft && !terminalUi.selected) {
    output.innerHTML = '<div class="terminal-welcome"><span>✦</span><h3>New Eliya conversation</h3><p>Ask for a fast indexed architecture analysis, or switch to Execute for code changes and tests. Each Terminal tab keeps its own workspace and conversation.</p></div>';
    $('terminalInputHint').textContent='New session · your other Terminal conversations continue independently';
    $('terminalSendBtn').textContent='➤ Send';
    return;
  }
  if (!detail) { output.innerHTML = '<div class="terminal-welcome"><h3>Welcome to Eliya Terminal</h3><p>Open a tab to start a conversation or select an existing session.</p></div>'; $('terminalSendBtn').textContent='➤ Send'; return; }
  uiRememberTerminalStream(detail);
  const signature=terminalRenderKey(detail);
  if(!terminalUi.forceRender && terminalUi.renderSignature===signature && output.querySelector('.terminal-conversation')) {
    terminalFastPatch(detail);return;
  }
  terminalUi.renderSignature=signature; terminalUi.forceRender=false;
  const status = String(detail.status || 'unknown');
  const busy = terminalIsBusy(status);
  const progress = detail.progress || {};
  const durationLabel = eliRunTimeLabel(detail, {startedAt:detail.startedAt || detail.createdAt, finishedAt:detail.finishedAt,
    elapsedMs:detail.elapsedMs});
  const percent = Math.max(0,Math.min(100,Number(progress.progressPercent || 0)));
  const runPlan = Array.isArray(progress.plan) ? progress.plan : [];
  const transcripts = Array.isArray(detail.turns) ? detail.turns : [];
  const lastTurn = transcripts[transcripts.length - 1];
  const finalTurn = !busy && lastTurn?.role === 'assistant' && String(lastTurn?.content || '').trim() ? lastTurn : null;
  // Successful completion belongs at the bottom, after technical telemetry.
  // Previous discussion stays intact and the actual response is never duplicated.
  const visibleTurns = finalTurn ? transcripts.slice(0, -1) : transcripts;
  const renderTurn = (turn, i) => `<div class="terminal-message ${turn.role === 'user' ? 'terminal-user' : 'terminal-agent'}"><div class="terminal-message-label">${turn.role === 'user' ? 'You' : 'Eliya'} <small>#${i+1}</small></div><div class="terminal-message-text">${turn.role === 'user' ? `<pre>${esc(turn.content)}</pre>` : MarkdownRenderer.render(turn.content || '')}</div></div>`;
  const transcriptHtml = visibleTurns.map(renderTurn).join('');
  // Always-visible OpenCode-style action timeline. Expanding an individual tool shows
  // arguments and actual output; neither the timeline nor tool status is behind <details>.
  const activity = terminalVisibleActions(detail);
  const actionHistory = terminalActionState(detail.id);
  const savedDisclosures = uiDisclosureSnapshot(output.querySelector('.terminal-conversation'));
  const expanded = new Set([...output.querySelectorAll('.terminal-action-detail[open]')]
    .map(node => node.dataset.actionDetail));
  const activityHtml = activity.map(terminalActionHtml).join('');
  const activityPane = `<section class="terminal-action-feed" aria-label="Agent execution actions">
    <div class="terminal-action-header"><strong>⚡ Agent actions</strong><small>${activity.length} shown · ${Number(detail.sequence||0)} session events</small><span class="terminal-action-live">${busy ? '● Live' : '● History'}</span></div>
    ${actionHistory.hasMore ? `<button type="button" class="terminal-load-actions" data-terminal-more-actions="${esc(detail.id)}" ${actionHistory.loading?'disabled':''}>↑ ${actionHistory.loading?'Loading…':'Load earlier actions'}</button>` : ''}
    ${detail.activityTruncated || actionHistory.truncated ? '<p class="terminal-action-warning">Action journal size limit reached. The oldest recorded actions remain available, but later actions may be missing from the archive.</p>' : ''}
    ${detail.activityJournalError || actionHistory.journalError ? '<p class="terminal-action-warning">Some actions could not be saved to disk. Check file permissions.</p>' : ''}
    <div class="terminal-action-list">${activityHtml || `<p class="terminal-muted">${busy ? 'Waiting for the first tool or planning event…' : 'No agent tool actions recorded for this conversation.'}</p>`}</div>
  </section>`;
  const progressView = Object.keys(progress).length && busy
    ? `<section class="terminal-live-panel"><div class="terminal-live-title"><span class="terminal-status-dot ${esc(status)}"></span><strong>${esc(progress.progressPhase || progress.status || status)}</strong><span>${progress.indeterminate ? 'Working · % unavailable' : percent+'%'+(progress.estimated?' est.':'')}</span></div><p>${esc(progress.progressDetail || 'Agent is working…')}${Number(progress.observedActions) ? ` · ${Number(progress.observedActions)} observed actions` : ''}</p><div class="terminal-progress-track"><div style="width:${progress.indeterminate ? 15 : percent}%"></div></div>${runPlan.length ? `<details class="terminal-run-plan"><summary>Execution plan · ${runPlan.length} steps</summary>${runPlan.map(p=>`<div>${esc(p.status || 'pending')} · ${esc(p.text || '')}</div>`).join('')}</details>` : ''}</section>` : '';
  const question = detail.question || {};
  // Any follow-up question appears only in the bottom decision dock above the composer.
  const queued = status === 'waiting_workspace'
    ? `<div class="terminal-queue-reason">${esc(detail.queueReason || 'This task is queued until another Terminal finishes using the same workspace. Your workspace was not lost.')}</div>`
    : '';
  const queue = Array.isArray(detail.queue) ? detail.queue : [];
  const pendingQueue = queue.length ? `<section class="terminal-pending-queue" aria-label="Pending agent instructions">
    <div class="terminal-queue-heading"><strong>Pending instructions (${queue.length})</strong><small>${detail.queuePaused ? 'Paused · resume manually' : 'Will run sequentially after success'}</small></div>
    ${queue.map((item,i) => {
      const editing = terminalUi.editingQueue?.id === item.id;
      const workspace = terminalUi.workspaces?.find(w => w.id === item.projectId);
      return `<div class="terminal-queue-item" data-terminal-queue-item="${esc(item.id)}">
        <div class="terminal-queue-item-top"><span>#${i+1}</span><strong>${esc(workspace?.name || item.projectId || 'Workspace')}</strong><small>${esc(item.model || '')}</small></div>
        ${editing ? `<textarea data-terminal-queue-editor="${esc(item.id)}" rows="4" maxlength="100000" aria-label="Edit queued instruction">${esc(terminalUi.editingQueue.draft)}</textarea>
          <div class="terminal-queue-actions"><button type="button" data-terminal-queue-save="${esc(item.id)}">Save</button><button type="button" data-terminal-queue-dismiss="${esc(item.id)}">Discard edit</button></div>`
          : `<pre>${esc(item.prompt)}</pre><div class="terminal-queue-actions">
              <button type="button" data-terminal-queue-move="${esc(item.id)}" data-direction="up" ${i===0?'disabled':''} aria-label="Move instruction up">↑</button>
              <button type="button" data-terminal-queue-move="${esc(item.id)}" data-direction="down" ${i===queue.length-1?'disabled':''} aria-label="Move instruction down">↓</button>
              <button type="button" data-terminal-queue-edit="${esc(item.id)}">Edit</button>
              <button type="button" data-terminal-queue-remove="${esc(item.id)}">Remove</button></div>`}
      </div>`;
    }).join('')}
    ${detail.queuePaused && !['running','queued','waiting_workspace','cancelling'].includes(status) ? '<button type="button" class="terminal-queue-resume" data-terminal-queue-resume>▶ Resume pending instructions</button>' : ''}
  </section>` : '';
  const awaiting = ['queued','running','waiting_workspace','cancelling'].includes(status);
  // Completed responses live in turns; never print the same final answer twice.
  const liveAnswer = awaiting && detail.answer ? `<section class="terminal-message terminal-agent terminal-streaming"><div class="terminal-message-label">Eliya · streaming</div><div class="terminal-message-text"><pre class="terminal-stream-raw">${esc(String(detail.answer))}</pre></div></section>` : '';
  const lastAnswer = String(detail.answer || terminalUi.lastVisibleAnswers.get(uiTerminalAnswerKey(detail)) || '');
  const hasFinalAnswer = Boolean(finalTurn);
  const previousAnswer = String(lastTurn?.role === 'assistant' ? lastTurn.content || '' : '');
  const fallbackAnswer = !busy && !hasFinalAnswer && lastAnswer.trim() && !previousAnswer.trim()
    ? `<section class="terminal-message terminal-agent terminal-final-answer" role="status"><div class="terminal-message-label">Eliya · latest response <small>Session copy</small></div><div class="terminal-message-text">${MarkdownRenderer.render(lastAnswer)}</div></section>` : '';
  const finalAnswer = finalTurn ? `<section class="terminal-final-answer" aria-label="Latest Eliya answer">${renderTurn(finalTurn, transcripts.length - 1)}</section>` : fallbackAnswer;
  const lastUserTurn = [...transcripts].reverse().find(t=>t.role==='user');
  const suggestedNext = !busy && status==='completed' ? window.EliyaConversationIntelligence?.suggest?.({
    prompt:lastUserTurn?.content || '',answer:finalTurn?.content || lastAnswer,
    mode:detail.mode==='chat'?'analyse':'execute',success:true}) || '' : '';
  const nextStep = suggestedNext ? `<div class="terminal-next-question"><small>NEXT STEP</small><p>${esc(suggestedNext)}</p><span>Reply in the message box and press Enter.</span></div>` : '';
  const header = `<div class="terminal-session-header"><span class="terminal-status-dot ${esc(status)}"></span><strong>${esc(status.replaceAll('_',' '))}</strong><small>Session ${esc(detail.id.slice(0,8))}</small><small class="terminal-duration" data-terminal-elapsed>${esc(durationLabel)}</small><button type="button" data-terminal-copy="answer">Copy last answer</button>${detail.runId ? `<button type="button" data-terminal-report="${esc(detail.runId)}">Run report</button>` : ''}${detail.engine==='opencode' && ['completed','failed'].includes(status) ? `<button type="button" data-terminal-rollback="${esc(detail.id)}">Undo changes</button>` : ''}${busy || (detail.engine==='opencode' && status==='stalled') ? `<button type="button" data-terminal-stop="${esc(detail.id)}">Stop task</button>${queue.length && !['cancelling','waiting_workspace'].includes(status) ? `<button type="button" data-terminal-interrupt="${esc(detail.id)}" title="Cancel current task, then safely run the next queued instruction">Interrupt → next</button>` : ''}` : ''}</div>`;
  const terminalUsage = detail.engine==='opencode' ? detail.usage : progress.tokenUsage;
  const tokenReport = tokenActivityReportHtml(terminalUsage, !busy);
  const tokenStrip = executionTokenStripHtml(terminalUsage, !busy);
  // Verification/provider failures are actionable run outcomes, NOT missing user guidance.
  // Keep the report accessible without a retry/close-task popup or false "completed" badge.
  const failedOutcome = ['failed','blocked'].includes(status)
    ? `<section class="terminal-run-outcome" role="status"><strong>Task ended without confirmed completion</strong><p>The Agent stopped or could not independently verify every requested outcome. Any workspace changes are preserved. Review the run report for the exact cause; you can send a NEW instruction when needed.</p></section>`
    : '';
  const diagnostics = `<details class="terminal-execution-history"><summary>Token accounting details</summary><section class="terminal-diagnostics" aria-label="Technical execution details">${tokenReport}</section></details>`;
  const liveActions = `<section class="terminal-open-actions" role="log" aria-label="Visible execution actions">${activityPane}</section>`;
  // Keep historical Terminal messages mounted through status / activity refreshes.
  // This avoids losing selection or large Markdown/diagram DOMs whenever a tool runs.
  const previousTurns = [...output.querySelectorAll('.terminal-message')];
  output.innerHTML = header + `<div class="terminal-conversation">${transcriptHtml}${queued}${progressView}${tokenStrip}${pendingQueue}${liveActions}${diagnostics}${liveAnswer}${failedOutcome}${detail.error ? `<div class="terminal-error">${esc(detail.error)}</div>` : ''}${awaiting && !activity.length && !detail.answer ? '<p class="terminal-muted">Preparing tools…</p>' : ''}${finalAnswer}${!busy ? eliyaWhyChangedHtml(detail.changeReport?.status ? detail.changeReport : (detail.runId ? eliyaTerminalReports.get(detail.runId) : null)) : ''}${nextStep}</div>`;
  output.querySelectorAll('.terminal-message').forEach((fresh, index) => {
    const old = previousTurns[index];
    if (old && old.outerHTML === fresh.outerHTML) fresh.replaceWith(old);
  });
  uiRestoreDisclosures(output.querySelector('.terminal-conversation'), savedDisclosures);
  for (const node of output.querySelectorAll('.terminal-action-detail')) {
    if (expanded.has(node.dataset.actionDetail)) node.open = true;
  }
  const restoredRecovery = $('terminalRecoveryText');
  if(restoredRecovery){ restoredRecovery.value=recoveryDraft; if(recoveryFocused){restoredRecovery.focus();restoredRecovery.setSelectionRange(recoveryCursor,recoveryCursor);} }
  const restoredEditor=$('terminalClarificationText');
  if(restoredEditor){restoredEditor.value=questionDraft;if(questionFocused){restoredEditor.focus();restoredEditor.setSelectionRange(questionCursor,questionCursor);}}
  const restoredQueueEditor=output.querySelector('[data-terminal-queue-editor]');
  if (restoredQueueEditor && queueEditorFocused) {
    restoredQueueEditor.focus();
    restoredQueueEditor.setSelectionRange(queueEditorCursor,queueEditorCursor);
  }
  $('terminalInputHint').textContent = busy
    ? status === 'needs_input' ? 'Answer Eliya in the Terminal message box and press Enter'
      : `Agent working · Send adds to this tab’s queue (${queue.length} pending)`
    : detail.queuePaused ? `${queue.length} instructions paused · Resume or edit the queue`
      : 'Continue this conversation · instructions run sequentially with workspace locks';
  $('terminalSendBtn').textContent = status==='needs_input' && detail.question?.kind==='clarification' ? '➤ Reply'
    : status==='needs_input' && detail.question?.kind==='plan_correction' ? '↻ Continue'
    : busy ? '＋ Queue' : (queue.length ? '＋ Queue' : '➤ Send');
  if (nearBottom) output.scrollTop = output.scrollHeight;
  else output.scrollTop = Math.min(scrollTop, output.scrollHeight);
}
// A single authenticated SSE subscription follows the selected tab. Token fragments are
// applied directly to a text node, without Markdown reparsing or rebuilding previous messages.
// Unexpected disconnects reconcile with a full snapshot and fall back to slow polling.
function terminalStopStream() {
  if (terminalUi.streamController) terminalUi.streamController.abort();
  terminalUi.streamController=null; terminalUi.streamSessionId=null;
  terminalUi.streamPendingTokens=[];
  if(terminalUi.refreshHandle){clearTimeout(terminalUi.refreshHandle);terminalUi.refreshHandle=null;}
}
function terminalScheduleSnapshot(delay=160) {
  if(terminalUi.refreshHandle) return;
  terminalUi.refreshHandle=setTimeout(()=>{
    terminalUi.refreshHandle=null;
    if(terminalUi.visible) void terminalRefreshActive();
  },delay);
}
async function terminalRefreshActive() {
  const id=terminalUi.selected;
  if (!id || !terminalUi.visible) return;
  try {
    const result=await api(`/api/terminal/sessions/${encodeURIComponent(id)}`);
    if(id!==terminalUi.selected || !terminalUi.visible) return;
    // Tokens can arrive while the HTTP snapshot is in flight. Reapply only deltas newer
    // than its sequence and never show a shorter answer due to a stale response.
    const fetchedSeq=Number(result.sequence||0);
    const pending=terminalUi.streamPendingTokens.filter(item=>item.seq>fetchedSeq);
    if(pending.length) {
      result.answer=String(result.answer||'')+pending.map(item=>item.text).join('');
      result.sequence=Math.max(fetchedSeq,pending[pending.length-1].seq);
    }
    terminalUi.streamPendingTokens=terminalUi.streamPendingTokens.filter(item=>item.seq>fetchedSeq);
    terminalUi.streamBufferSequence=Math.max(terminalUi.streamBufferSequence,fetchedSeq);
    terminalUi.detail=result;
    // Only refresh the badge from the session when a different tab was opened.
    if (terminalUi.modeSessionId!==id) {terminalUi.modeSessionId=id;terminalSelectWorkflow(result.mode==='chat'?'analyse':'execute');}
    const summary=terminalUi.sessions.find(s=>s.id===id);
    if(summary) Object.assign(summary,{status:result.status,queueCount:result.queue?.length||0});
    renderTerminalUi();
  } catch (error) { console.warn('Terminal snapshot reconciliation failed:',error.message); }
}
// O(delta) text append for hot streaming path. Completed Markdown is rendered once.
function terminalAppendLiveText(detail,chunk) {
  const output=$('terminalOutput');
  const nearBottom=output.scrollHeight-output.scrollTop-output.clientHeight<90;
  let raw=output.querySelector('.terminal-stream-raw');
  if (!raw) {terminalFastPatch(detail);return;}
  if(raw) {
    if(raw.textContent.length+chunk.length <= 600000 && raw.firstChild?.nodeType===Node.TEXT_NODE)
      raw.firstChild.appendData(chunk);
    else raw.textContent=String(detail.answer||'');
  }
  if(nearBottom) output.scrollTop=output.scrollHeight;
}
function terminalApplyStreamDelta(id, item) {
  if(!terminalUi.visible || terminalUi.selected!==id || !terminalUi.detail || terminalUi.detail.id!==id) return;
  if(item.type==='resync') {terminalScheduleSnapshot(0);return;}
  const seq=Number(item.seq);
  if(!Number.isSafeInteger(seq) || seq<=terminalUi.streamBufferSequence) return;
  // Never append an out-of-order token: a single authoritative snapshot restores it.
  if (seq>terminalUi.streamBufferSequence+1 && terminalUi.streamBufferSequence>0) terminalScheduleSnapshot();
  terminalUi.streamBufferSequence=seq;
  const detail=terminalUi.detail;
  if(item.type==='token') {
    detail.answer=String(detail.answer||'')+String(item.text||'');
    terminalUi.streamPendingTokens.push({seq,text:String(item.text||'')});
    if(terminalUi.streamPendingTokens.length>1024) {
      terminalUi.streamPendingTokens.shift();terminalScheduleSnapshot(0);
    }
    if(detail.answer.length>600000) detail.answer=detail.answer.slice(-600000);
    detail.sequence=seq;
    terminalAppendLiveText(detail,String(item.text||''));
    return;
  }
  if(TERMINAL_ACTION_TYPES.has(item.type)) {
    const history=terminalActionState(id);
    history.events.set(seq,{type:item.type,seq,data:item.data||{}});
    terminalFastPatch(detail);
  }
  // Completion, questions and changed progress are fetched once, not once per character.
  terminalScheduleSnapshot(['question','question_answered'].includes(item.type) ? 40
    : ['done','error','stopped','meta','agent_step'].includes(item.type) ? 120 : 350);
}
async function terminalConsumeStream(id,controller) {
  try {
    const response=await fetch(`/api/terminal/sessions/${encodeURIComponent(id)}/events`,{
      headers:{Accept:'text/event-stream',...(state.config.apiKey?{Authorization:`Bearer ${state.config.apiKey}`}:{})},
      signal:controller.signal,cache:'no-store'
    });
    const streamType=String(response.headers?.get('content-type')||'');
    if(!response.ok || !streamType.includes('text/event-stream') || !response.body || !response.body.getReader) {
      if(response.status===404 || response.status===501 || (response.ok && !streamType.includes('text/event-stream'))) terminalUi.streamUnsupported=true;
      throw new Error('Terminal event stream unavailable');
    }
    const reader=response.body.getReader();
    const decoder=new TextDecoder();
    let buffer='';
    while(!controller.signal.aborted) {
      const {done,value}=await reader.read();
      if(done) break;
      buffer += decoder.decode(value,{stream:true});
      if(buffer.length>2000000) throw new Error('Oversized Terminal event');
      // Normalize CRLF and parse complete SSE frames; JSON strings can contain escaped newlines.
      buffer=buffer.replace(/\r\n/g,'\n');
      let boundary;
      while((boundary=buffer.indexOf('\n\n'))!==-1) {
        const frame=buffer.slice(0,boundary);buffer=buffer.slice(boundary+2);
        const data=frame.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trimStart()).join('\n');
        if(!data) continue;
        try { terminalApplyStreamDelta(id,JSON.parse(data)); }
        catch(error) {console.warn('Skipping invalid Terminal event',error.message);terminalScheduleSnapshot();}
      }
    }
  } catch(error) {
    if(!controller.signal.aborted && !terminalUi.streamUnsupported) console.warn('Terminal stream disconnected; using snapshot fallback',error.message);
  } finally {
    if(terminalUi.streamController===controller) {
      terminalUi.streamController=null;terminalUi.streamSessionId=null;
      if(!controller.signal.aborted && terminalUi.visible && terminalUi.selected===id && !terminalUi.streamUnsupported)
        setTimeout(()=>{if(terminalUi.visible && terminalUi.selected===id) terminalEnsureStream();},1200);
    }
  }
}
function terminalEnsureStream() {
  const id=terminalUi.selected;
  if(!terminalUi.visible || !id || terminalUi.streamUnsupported) return;
  if(terminalUi.streamController && terminalUi.streamSessionId===id) return;
  terminalStopStream();
  terminalUi.streamSessionId=id;
  terminalUi.streamBufferSequence=Number(terminalUi.detail?.sequence||0);
  terminalUi.streamPendingTokens=[];
  const controller=new AbortController();terminalUi.streamController=controller;
  void terminalConsumeStream(id,controller);
}
async function pollTerminalSessions() {
  if (!terminalUi.visible || terminalUi.polling) return;
  terminalUi.polling = true;
  try {
    const list = await api('/api/terminal/sessions');
    terminalUi.sessions = Array.isArray(list) ? list : [];
    if (terminalUi.selected && terminalUi.closedTabs.has(terminalUi.selected)) terminalUi.selected=null;
    if (!terminalUi.selected && !terminalUi.draft && terminalUi.sessions.length) terminalUi.selected = terminalUi.sessions.find(s=>!terminalUi.closedTabs.has(s.id))?.id || null;
    const requestedId = terminalUi.selected;
    if (requestedId) {
      const fetched = await api(`/api/terminal/sessions/${encodeURIComponent(requestedId)}`);
      if (terminalUi.selected !== requestedId) return;
      if(terminalUi.streamSessionId===requestedId) {
        const recent=terminalUi.streamPendingTokens.filter(t=>t.seq>Number(fetched.sequence||0));
        if(recent.length) {
          fetched.answer=String(fetched.answer||'')+recent.map(t=>t.text).join('');
          fetched.sequence=recent[recent.length-1].seq;
        }
        terminalUi.streamPendingTokens=recent;
      }
      terminalUi.detail = fetched;
      if (!['queued','running','waiting_workspace','cancelling'].includes(String(fetched.status||'')) && fetched.runId) void getTerminalChangeReport(fetched.runId);
      if(terminalUi.streamSessionId!==requestedId) terminalUi.streamBufferSequence=Number(fetched.sequence||0);
      const history = terminalActionState(requestedId);
      if (!history.loaded && !history.loading) void terminalLoadActions(requestedId);
    } else terminalUi.detail = null;
    renderTerminalUi();
    renderUnifiedTabs();
    terminalEnsureStream();
  } catch (error) { $('terminalOutput').textContent = 'Unable to load terminals: ' + error.message; }
  finally { terminalUi.polling = false; }
}
function terminalPayload(instruction, anchor = null) {
  return {
    conversationId: (terminalUi.attachments || []).length ? terminalUi.attachmentConversationId : state.conversationId,
    message: instruction,
    attachmentIds: (terminalUi.attachments || []).map(file=>file.id),
    projectId: anchor ? anchor.projectId : (terminalUi.pendingProjectId || terminalUi.draft?.projectId || $('terminalWorkspaceSelect').value || state.project?.id || null),
    referenceProjectIds: anchor ? anchor.referenceProjectIds : (terminalUi.draft?.referenceProjectIds || terminalCurrentAnchor()?.referenceProjectIds || state.referenceProjects.map(ref => ref.id)),
    referenceProjectNames: anchor ? anchor.referenceProjectNames : (terminalUi.draft?.referenceProjectNames || terminalCurrentAnchor()?.referenceProjectNames || Object.fromEntries(state.referenceProjects.map(ref => [ref.id, ref.name]))),
    referenceProjectWriteAccess: anchor ? (anchor.referenceProjectWriteAccess || {}) : (terminalUi.draft?.referenceProjectWriteAccess || referenceWriteAccess()),
    mode: terminalUi.workflowMode === 'execute' ? 'agent' : 'chat', regenerate: false,
    settings: {
      baseUrl:state.config.baseUrl,model:terminalUi.draft?.model || $('terminalModelSelect').value || state.config.model,chatModel:state.config.chatModel || state.config.model,
      visionModel:state.config.visionModel || '',visionBaseUrl:state.config.visionBaseUrl || '',visionApiKey:state.config.visionApiKey || '',
      temperature:state.config.temperature,maxTokens:state.config.maxTokens,contextWindowTokens:state.config.contextWindowTokens,
      modelContextWindows:modelContextWindowsSetting(),modelTypes:modelTypesSetting(),embeddingModel:state.config.embeddingModel || '',
      semanticRetrieval:Boolean(state.config.semanticRetrieval),systemPrompt:state.config.systemPrompt,useFileContext:state.config.useFileContext,
      agentAllowCommands:state.config.agentAllowCommands,agentEditPermission:state.config.agentEditPermission,
      agentShellPermission:state.config.agentShellPermission,agentReviewPermission:state.config.agentReviewPermission,
      agentMcpPermission:state.config.agentMcpPermission,agentTaskPermission:state.config.agentTaskPermission,
      agentLspPermission:state.config.agentLspPermission,agentParallelReadTools:state.config.agentParallelReadTools,
      agentAutoApprove:state.config.agentAutoApprove,agentConfirmFileDeletion:state.config.agentConfirmFileDeletion,
      agentPlanApproval:false,agentFallbackModels:state.config.agentFallbackEnabled ? currentFallbackModels().join('\n') : '',
      agentRecoveryAttempts:3
    }
  };
}
$('launchTerminalBtn').addEventListener('click', () => openTerminalDock());
$('terminalClose').addEventListener('click', closeTerminalDock);
async function launchTerminalPrompt(prompt, existing = null) {
  if (terminalUi.attachmentOwnerTab && terminalUi.attachmentOwnerTab !== terminalAttachmentTabId()) clearTerminalAttachments();
  if (!prompt && !terminalUi.attachments.length) return toast('Enter an instruction or attach a document');
  if(terminalUi.attachmentsUploading) return toast('Wait until Terminal file uploads finish');
  if (!prompt) prompt='Please analyze the attached documents.';
  if (ELIYA_ROLLBACK_INTENT.test(prompt) && terminalUi.detail?.engine==='opencode') {
    $('terminalTask').value=''; await performEliyaRollback(terminalUi.detail.id); return;
  }
  const pending=terminalUi.detail;
  if(pending?.status==='needs_input' && pending.question?.kind==='clarification' && pending.question?.id) {
    try {
      await terminalSubmitClarification(pending.id,pending.question.id,'Custom',prompt);
      $('terminalTask').value='';
    } catch(error) { toast(`Clarification failed: ${error.message}`,6000); }
    return;
  }
  // A tab keeps one conversation across Analyse and Execute, without an Agent plan
  // for read-only questions. An explicit action verb authorises switching to Execute.
  const previousTerminalAnswer = String(terminalUi.detail?.turns?.filter(t=>t.role==='assistant').slice(-1)[0]?.content || '');
  const previousTerminalUser = String(terminalUi.detail?.turns?.filter(t=>t.role==='user').slice(-1)[0]?.content || '');
  const suggested = window.EliyaConversationIntelligence?.suggest?.({prompt:previousTerminalUser,answer:previousTerminalAnswer,
    mode:terminalUi.detail?.mode==='agent'?'execute':'analyse',success:terminalUi.detail?.status==='completed'}) || '';
  const resolved = window.EliyaConversationIntelligence?.resolve?.(prompt,suggested) || {text:prompt,action:'original'};
  const contextual = window.EliyaConversationIntelligence?.contextualize?.(resolved.text || prompt,{
    lastUser:previousTerminalUser,lastAssistant:previousTerminalAnswer,
    workspaceMapped:Boolean(terminalUi.detail?.projectId || terminalUi.draft?.projectId || state.project?.localWorkspace)
  });
  const intentPrompt = contextual?.text || resolved.text || prompt;
  if (terminalUi.intentRoutingPending) return;
  terminalUi.intentRoutingPending = true;
  let targetEngine;
  try { targetEngine = await window.EliyaUnifiedRouting?.decideWithModel?.({text:intentPrompt,selectedMode:'auto',
    previousAssistantText:previousTerminalAnswer+(suggested?'\n'+suggested:''),previousAssistantMode:terminalUi.detail?.mode||'',
    attachments:terminalUi.attachments}, eliyaModelIntent) || 'chat';
  } finally { terminalUi.intentRoutingPending = false; }
  // The instruction, not the previous UI mode, selects the engine.
  terminalSelectWorkflow(targetEngine === 'agent' ? 'execute' : 'analyse');
  // No corrective-plan retry. A user reply is a normal conversational instruction.
  // The model receives the prior turn context, not a duplicated long prompt.
  const requestedPath = terminalPathInstruction(prompt);
  if (requestedPath) {try {await mapTerminalWorkspace(requestedPath);$('terminalTask').value='';}
    catch(error){toast(`Cannot switch workspace: ${error.message}`,6500);}return;}
  const active = terminalUi.detail;
  const isContinuation = Boolean(active?.id && terminalUi.selected === active.id && (!existing || existing.id === active.id));
  if (!isContinuation && !existing && !terminalUi.draft && !state.project?.id && !$('terminalWorkspaceSelect').value)
    return toast('Select or paste a local workspace path before launching a task.');
  const choice = terminalExecutionChoice();
  const usesOpenCode = targetEngine==='agent' && terminalEngineInfo.engine==='opencode'
    && (choice==='opencode' || (choice==='auto' && terminalEngineInfo.autoEligible))
    && !terminalUi.attachments.length && !/\bmcp\b/i.test(intentPrompt);
  if (!usesOpenCode && (!state.config.apiKey || !state.config.baseUrl || !state.config.model))
    return toast('Configure Agent model, base URL and API key first');
  if (usesOpenCode && !terminalEngineInfo.connected)
    return toast('OpenCode 2.2+ is not ready or unsupported. Choose Auto to use Eliya, or select Eliya directly.',6500);
  const submit = $('terminalForm').querySelector('[type=submit]');
  submit.disabled = true;
  try {
    const body=terminalPayload(intentPrompt, existing);
    body.mode=targetEngine;
    // Selected tab continues its own conversation; a New tab starts an independent conversation.
    if (isContinuation) {
      // Continuation belongs to the Terminal's persistent conversation, not
      // whichever independent Chat conversation happens to be selected.
      body.conversationId = body.attachmentIds.length ? terminalUi.attachmentConversationId : active.conversationId;
      body.projectId = $('terminalWorkspaceSelect').value || terminalUi.draft?.projectId || active.projectId;
      body.referenceProjectIds = terminalUi.draft?.referenceProjectIds || active.referenceProjectIds || [];
      body.referenceProjectNames = terminalUi.draft?.referenceProjectNames || active.referenceProjectNames || {};
    }
    if (!body.projectId) throw new Error('Choose a mapped workspace or paste an absolute path first');
    const endpoint = isContinuation ? `/api/terminal/sessions/${encodeURIComponent(active.id)}/message` : '/api/terminal/sessions';
    const result = await api(endpoint, {method:'POST',headers:{'Content-Type':'application/json', 'Authorization':`Bearer ${state.config.apiKey}`,
      'X-ELIYA-Execution-Engine':choice},body:JSON.stringify(body)});
    terminalUi.selected = result.id;
    terminalUi.closedTabs.delete(result.id);
    storageSet('local','llm.terminalClosedTabs',JSON.stringify([...terminalUi.closedTabs]));
    $('terminalConfigPanel').open = false;
    terminalUi.draft = null;
    terminalUi.pendingProjectId = null; terminalUi.pendingWorktreeName = null;
    $('terminalTask').value = '';
    clearTerminalAttachments();
    await pollTerminalSessions();
    toast(isContinuation ? (result.queueCount ? `Instruction queued · ${result.queueCount} pending` : 'Instruction started in this Terminal conversation') : 'Terminal agent launched');
  } catch (error) { toast(`Terminal launch failed: ${error.message}`, 6500); }
  finally { submit.disabled = false; }
}
async function terminalSubmitClarification(sessionId,questionId,choice,detail) {
  if (!sessionId || !questionId) throw new Error('No active clarification');
  await api(`/api/terminal/sessions/${encodeURIComponent(sessionId)}/answer`,{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({questionId,choice,detail})
  });
  terminalUi.decisionSignature=null;
  await pollTerminalSessions();
}
$('terminalForm').addEventListener('submit', event => {
  event.preventDefault();
  void launchTerminalPrompt($('terminalTask').value.trim());
});
$('terminalTask').addEventListener('keydown',event=>{
  if(event.key==='Enter' && !event.shiftKey && !event.isComposing){event.preventDefault();$('terminalForm').requestSubmit();}
});
$('terminalReopenTabs').addEventListener('click',()=>{
  terminalUi.closedTabs.clear();storageSet('local','llm.terminalClosedTabs','[]');
  void pollTerminalSessions();toast('Closed tabs restored');
});
$('terminalNewTab').addEventListener('click',()=>{
  terminalUi.pendingProjectId = null;
  terminalUi.draft = {projectId:state.project?.id || null,
    referenceProjectIds:state.referenceProjects.map(ref=>ref.id),
    referenceProjectNames:Object.fromEntries(state.referenceProjects.map(ref=>[ref.id,ref.name])),referenceProjectWriteAccess:referenceWriteAccess(),model:state.config.model};
  terminalUi.selected = null; terminalUi.detail = null; terminalUi.modeSessionId = null;
  terminalSelectWorkflow('analyse'); $('terminalTask').value = '';
  renderUnifiedTabs();
  clearTerminalAttachments();
  $('terminalConfigPanel').open = true;
  void loadTerminalWorkspaces(); renderTerminalUi();
});
$('terminalTabs').addEventListener('click', event => {
  const close=event.target.closest('[data-terminal-tab-close]');
  if(close){
    const id=close.dataset.terminalTabClose;
    terminalUi.closedTabs.add(id);
    storageSet('local','llm.terminalClosedTabs',JSON.stringify([...terminalUi.closedTabs]));
    if(terminalUi.selected===id){terminalUi.selected=null;terminalUi.detail=null;terminalUi.draft=null;clearTerminalAttachments();}
    void pollTerminalSessions();renderTerminalUi();
    toast('Tab closed · an executing task continues and remains in Execution Monitor');
    return;
  }
  const tab = event.target.closest('[data-terminal-tab]');
  if (tab) { terminalUi.selected = tab.dataset.terminalTab; terminalUi.draft = null; terminalUi.detail = null;
    clearTerminalAttachments(); $('terminalTask').value='';void pollTerminalSessions().then(()=>void loadTerminalWorkspaces()); }
  if (event.target.closest('[data-terminal-draft]')) { terminalUi.selected = null; terminalUi.detail = null; terminalUi.modeSessionId=null; terminalSelectWorkflow('analyse');clearTerminalAttachments(); renderTerminalUi(); }
});
async function handleTerminalActionClick(event) {
  const undo = event.target.closest('[data-terminal-rollback]');
  if (undo) {await performEliyaRollback(undo.dataset.terminalRollback);return;}
  const moreActions = event.target.closest('[data-terminal-more-actions]');
  if (moreActions) { await terminalLoadActions(moreActions.dataset.terminalMoreActions, true); return; }
  const answerBtn = event.target.closest('[data-terminal-answer],[data-terminal-custom-answer]');
  if (answerBtn) {
    const custom=answerBtn.hasAttribute('data-terminal-custom-answer');
    const detail = $('terminalClarificationText')?.value || '';
    if(custom && !detail.trim()) { toast('Type your answer before sending.',4000);return; }
    try {
      await terminalSubmitClarification(answerBtn.dataset.terminalAnswer || answerBtn.dataset.terminalCustomAnswer,
        answerBtn.dataset.questionId,custom ? 'Custom' : answerBtn.dataset.answerChoice,detail);
    } catch (error) { toast(`Clarification failed: ${error.message}`, 6000); }
    return;
  }

  const queueEdit = event.target.closest('[data-terminal-queue-edit]');
  if (queueEdit) {
    const item = (terminalUi.detail?.queue || []).find(q=>q.id===queueEdit.dataset.terminalQueueEdit);
    if (item) {terminalUi.editingQueue={id:item.id,draft:item.prompt};renderTerminalUi();}
    return;
  }
  const queueDismiss=event.target.closest('[data-terminal-queue-dismiss]');
  if (queueDismiss) {terminalUi.editingQueue=null;renderTerminalUi();return;}
  const queueAction=event.target.closest('[data-terminal-queue-save],[data-terminal-queue-move],[data-terminal-queue-remove],[data-terminal-queue-resume],[data-terminal-interrupt]');
  if (queueAction && terminalUi.detail?.id) {
    const id = encodeURIComponent(terminalUi.detail.id);
    const itemId = encodeURIComponent(queueAction.dataset.terminalQueueSave || queueAction.dataset.terminalQueueMove || queueAction.dataset.terminalQueueRemove || '');
    queueAction.disabled=true;
    try {
      let endpoint,method='POST',body;
      if(queueAction.hasAttribute('data-terminal-queue-save')) {
        method='PATCH';endpoint=`/api/terminal/sessions/${id}/queue/${itemId}`;
        body={prompt:$('terminalOutput').querySelector('[data-terminal-queue-editor]')?.value ?? terminalUi.editingQueue?.draft ?? ''};
      } else if(queueAction.hasAttribute('data-terminal-queue-move')) {
        endpoint=`/api/terminal/sessions/${id}/queue/${itemId}/move`;
        body={direction:queueAction.dataset.direction};
      } else if(queueAction.hasAttribute('data-terminal-queue-remove')) {
        method='DELETE';endpoint=`/api/terminal/sessions/${id}/queue/${itemId}`;
      } else if(queueAction.hasAttribute('data-terminal-queue-resume')) {
        endpoint=`/api/terminal/sessions/${id}/queue/resume`;
        body=terminalPayload('Resume pending instructions',terminalUi.detail);
      } else endpoint=`/api/terminal/sessions/${id}/interrupt-next`;
      await api(endpoint,{method,headers:{'Content-Type':'application/json',
        ...(queueAction.hasAttribute('data-terminal-queue-resume') ? {'Authorization':`Bearer ${state.config.apiKey}`} : {})},
        ...(body ? {body:JSON.stringify(body)} : {})});
      if(queueAction.hasAttribute('data-terminal-queue-save')) terminalUi.editingQueue=null;
      await pollTerminalSessions();
    } catch(error) {toast(`Queue update failed: ${error.message}`,6500);queueAction.disabled=false;}
    return;
  }
  const correction = event.target.closest('[data-terminal-continue],[data-terminal-edit]');
  if (correction && terminalUi.detail?.question?.kind === 'plan_correction') {
    const old = terminalUi.detail;
    const proposal = old.question.proposal || '';
    const revised = `${old.fullPrompt}\n\n[USER-AUTHORIZED PLAN CORRECTION]\n${proposal}`;
    $('terminalTask').value = revised;
    if (correction.hasAttribute('data-terminal-continue')) void launchTerminalPrompt(revised, old);
    else $('terminalTask').focus();
    return;
  }
  const stop = event.target.closest('[data-terminal-stop]');
  if (stop) {
    const result=await api(`/api/terminal/sessions/${encodeURIComponent(stop.dataset.terminalStop)}/cancel`,{method:'POST'});
    await pollTerminalSessions();
    if(result.status==='cancelled') toast('OpenCode task stopped; managed process released when safe');
    else toast(result.error || 'Stop is not yet confirmed. The OpenCode process may still be running.',8000);
    return;
  }
  const copy = event.target.closest('[data-terminal-copy]');
  if (copy) { try { await copyText(terminalUi.detail?.answer || ''); toast('Terminal result copied'); } catch (error) { toast('Copy failed: '+error.message,5000); } return; }
  const report = event.target.closest('[data-terminal-report]');
  if (report && report.dataset.terminalReport) {
    try { const response = await api(`/api/agent/runs/${encodeURIComponent(report.dataset.terminalReport)}/completion-report`);
      downloadText(`eliya-terminal-report-${report.dataset.terminalReport.slice(0,8)}.json`, JSON.stringify(response,null,2),'application/json');
    } catch(error) { toast(error.message, 5000); }
  }
 }
$('terminalOutput').addEventListener('click',handleTerminalActionClick);
$('terminalDecisionDock').addEventListener('click',handleTerminalActionClick);
$('terminalDecisionDock').addEventListener('keydown',event=>{
  if(event.key==='Enter' && !event.shiftKey && !event.isComposing && event.target.matches('textarea')) {
    event.preventDefault();
    const id=terminalUi.detail?.id;
    const question=terminalUi.detail?.question;
    if(question?.kind==='clarification' && id) {
      void terminalSubmitClarification(id,question.id,'Custom',event.target.value).catch(e=>toast(e.message,5000));
    }
  }
});
/** Select explicit completed runs; never quietly compare different prompts or incompatible model windows. */
function renderExecutionComparisonOptions(sessions) {
  const dropdown=(id,engine)=>{
    const el=$(id);
    if (!el) return;
    const previous=el.value;
    const eligible=sessions.filter(s=>(engine==='legacy' ? !s.engine || s.engine==='legacy' : s.engine==='opencode') && ['completed','failed','blocked','stalled','interrupted'].includes(s.status));
    el.innerHTML='<option value="">Select '+esc(engine==='opencode'?'OpenCode':'Eliya')+' run…</option>'
      +eligible.map(s=>`<option value="${esc(s.id)}">${esc(String(s.prompt||'Task').slice(0,65))} · ${esc(s.status)}</option>`).join('');
    if(eligible.some(s=>s.id===previous)) el.value=previous;
  };
  dropdown('usageCompareLegacy','legacy');dropdown('usageCompareOpenCode','opencode');
}
function executionComparisonHtml(a,b) {
  const left=executionUsageNumbers(a.usage),right=executionUsageNumbers(b.usage);
  const number=value=>Number(value||0).toLocaleString('en-US');
  const sameTask=String(a.prompt||'').trim()===String(b.prompt||'').trim();
  const sameModel=String(a.model||'').trim()===String(b.model||'').trim();
  const duration=s=>Number(s.elapsedMs||0) || Math.max(0,new Date(s.finishedAt||0)-new Date(s.startedAt||s.createdAt||0));
  const row=(label,prop)=>`<tr><th>${esc(label)}</th><td>${esc(left.reported?number(left[prop]):'Not reported')}</td><td>${esc(right.reported?number(right[prop]):'Not reported')}</td></tr>`;
  const timeRow=`<tr><th>Duration</th><td>${esc(number(Math.round(duration(a)/1000)))}s</td><td>${esc(number(Math.round(duration(b)/1000)))}s</td></tr>`;
  const reason=left.reported && right.reported && !left.missing && !right.missing;
  const comparable=reason && sameTask && sameModel;
  const diff=comparable && left.total ? ((right.total-left.total)/left.total*100).toFixed(1) : null;
  return `<div class="execution-comparison-result"><strong>Eliya vs OpenCode</strong>
    <p>${!sameTask?'<strong>Different instructions:</strong> results are not an apples-to-apples benchmark. ':''}
       ${!sameModel?'<strong>Different models:</strong> provider/model differences affect tokens and latency. ':''}
       ${reason?'Both runs supplied model usage.':'Token totals cannot be compared reliably while usage is missing or partial.'}</p>
    <table><thead><tr><th>Metric</th><th>Eliya</th><th>OpenCode</th></tr></thead><tbody>
      ${row('Reported tokens','total')}${row('Input tokens','input')}${row('Output tokens','output')}${row('Cache read','read')}${row('Cache write','write')}
      <tr><th>Model calls</th><td>${esc(number(left.calls))}</td><td>${esc(number(right.calls))}</td></tr>${timeRow}
      <tr><th>Usage status</th><td>${esc(left.status)}</td><td>${esc(right.status)}</td></tr>
    </tbody></table>${diff==null?'<p>Comparative token percentage withheld: use the exact same task, model, and complete provider usage for both runs.</p>':`<p>OpenCode reported <strong>${esc(diff)}%</strong> token difference relative to Eliya on this matched instruction/model. Compare verified outcomes before concluding which engine is more efficient.</p>`}
    <p><small>Methodology: Eliya input normally includes cached tokens; OpenCode input excludes its separate cache read/write. Totals use each engine's provider counters. Reasoning is not added twice. No tokens are estimated.</small></p>
  </div>`;
}
// The global monitor polls independently of the dock, so hiding Terminal never hides task status.
async function pollExecutionMonitor() {
  if (terminalUi.monitorPolling) return;
  terminalUi.monitorPolling = true;
  try {
    const sessions = await api('/api/terminal/sessions').catch(()=>[]);
    const comparisonOpen=!$('executionMonitorPanel').classList.contains('hidden');
    // Browser Agent runs are independent of Terminal sessions: always poll both.
    const [liveAgentRuns, agentRuns] = await Promise.all([
      api('/api/agent/runs/active').catch(()=>[]),
      comparisonOpen ? api('/api/agent/runs/recent').catch(()=>[]) : Promise.resolve([])
    ]);
    if (Array.isArray(sessions)) {
      terminalUi.sessions = sessions;
      terminalUi.comparisonRuns=[...sessions,...(Array.isArray(agentRuns)?agentRuns:[])];
      if (!$('executionMonitorPanel').classList.contains('hidden')) renderExecutionComparisonOptions(terminalUi.comparisonRuns);
      const terminalActive = sessions.filter(s => ['queued','waiting_workspace','running','cancelling'].includes(s.status));
      // Terminal Eliya sessions share run IDs with their Agent execution; count once.
      const terminalRunIds = new Set(terminalActive.map(s=>String(s.runId||'')).filter(Boolean));
      const active = [...terminalActive,
        ...(Array.isArray(liveAgentRuns) ? liveAgentRuns.filter(run=>!terminalRunIds.has(String(run.id))) : [])];
      const input = sessions.filter(s => s.status === 'needs_input');
      const queuedInstructions = sessions.reduce((sum,s)=>sum+Number(s.queueCount||0),0);
      const indicators={};
      for(const job of active) {
        if(!job.conversationId) continue;
        const key=String(job.conversationId);
        const info=indicators[key] || {running:0,actions:0};
        info.running++;
        info.actions+=Number(job.observedActions||job.progress?.observedActions||0);
        indicators[key]=info;
      }
      const changed=JSON.stringify(eliyaTabState.executionIndicators||{})!==JSON.stringify(indicators);
      eliyaTabState.executionIndicators=indicators;
      if(changed) renderUnifiedTabs();
      $('executionMonitorCount').textContent = `${active.length} running${queuedInstructions ? ` · ${queuedInstructions} queued` : ''}${input.length ? ` · ${input.length} needs input` : ''}`;
      const monitor = $('executionMonitorItems');
      const monitorSessions = [...active, ...sessions.filter(s => !active.some(a => a.id === s.id))];
      monitor.innerHTML = monitorSessions.length ? monitorSessions.slice(0,30).map(session=> {
        const raw = Number(session.progressPercent);
        const showProgress = Number.isFinite(raw) && session.progressPercent != null;
        const percent = Math.max(0, Math.min(100, raw));
        const progress = showProgress ? `<div class="execution-monitor-progress"><div style="width:${percent}%"></div></div>` : '';
        const stepLabel = session.engine==='opencode'
          ? `${Number(session.progress?.observedActions||0)} real actions · ${session.lastRemoteStatus||session.status}`
          : session.engine==='agent'
            ? `${Number(session.observedActions||0)} real actions · ${session.progressPhase||session.status}`
          : Number(session.stepCount) > 0
            ? `${session.completedSteps || 0}/${session.stepCount} verified steps` : (session.progressPhase || session.status);
        const duration = eliRunTimeLabel(session, {startedAt:session.startedAt || session.createdAt,
          finishedAt:session.finishedAt, elapsedMs:session.elapsedMs});
        return `<button type="button" class="execution-monitor-item" ${session.engine==='agent' ? `data-monitor-agent="${esc(session.conversationId||'')}"` : `data-monitor-session="${esc(session.id)}"`}><span>${esc(String(session.prompt||'Terminal').slice(0,75))}</span><small>${esc(session.status)} · ${esc(stepLabel)} · ${esc(duration)}${Number(session.queueCount) ? ` · +${session.queueCount} queued${session.queuePaused?' (paused)':''}` : ''}${showProgress ? ` · ${Math.round(percent)}%${session.progressEstimated ? ' est.' : ''}` : ''}</small>${progress}</button>`;
      }).join('') : '<p>No Terminal executions yet</p>';
      // Alert only on a state transition, and never notify repeatedly on polling.
      for (const s of input) if (!terminalUi.lastNotices.has(s.id)) { terminalUi.lastNotices.add(s.id); toast(`Terminal needs input: ${String(s.prompt||'').slice(0,50)}`,5000); }
      for (const s of sessions) {
        const previous = terminalUi.lastStatuses.get(s.id);
        if (previous && ['running','queued','waiting_workspace','cancelling'].includes(previous)
            && ['completed','failed','blocked','cancelled','interrupted','stalled'].includes(s.status))
          toast(`Terminal ${s.status}: ${String(s.prompt||'').slice(0,45)}`,5000);
        terminalUi.lastStatuses.set(s.id,s.status);
        if (s.status !== 'needs_input') terminalUi.lastNotices.delete(s.id);
      }
      if (terminalUi.visible) void pollTerminalSessions();
    }
  } catch (_) { $('executionMonitorCount').textContent = 'Offline'; }
  finally { terminalUi.monitorPolling = false; }
}
$('executionMonitorBtn').addEventListener('click',()=>{
  $('executionMonitorPanel').classList.toggle('hidden');
  if(!$('executionMonitorPanel').classList.contains('hidden')) {
    renderExecutionComparisonOptions(terminalUi.comparisonRuns||terminalUi.sessions||[]);
    void pollExecutionMonitor();
  }
});
$('usageCompareRun').addEventListener('click',async()=>{
  const legacyId=$('usageCompareLegacy').value, openId=$('usageCompareOpenCode').value;
  const target=$('usageCompareResult');
  if(!legacyId || !openId) {target.textContent='Select one completed run from each engine.';return;}
  target.textContent='Reading recorded usage…';
  try {
    const index=(terminalUi.comparisonRuns||[]).find(s=>s.id===legacyId);
    const legacyUrl=index?.runId || !index?.engine || index?.id?.startsWith('oc-')
      ? '/api/terminal/sessions/'+encodeURIComponent(legacyId)
      : '/api/agent/runs/'+encodeURIComponent(legacyId);
    const [legacy,open]=await Promise.all([api(legacyUrl),
      api('/api/terminal/sessions/'+encodeURIComponent(openId))]);
    const current=(value)=>value?.engine==='opencode' ? value.usage :
      value?.progress?.tokenUsage || value?.tokenUsage;
    const first={...legacy,usage:current(legacy),prompt:legacy.fullPrompt||legacy.prompt||legacy.objective,
      model:legacy.model||legacy.activeModel,elapsedMs:legacy.elapsedMs},
      second={...open,usage:current(open),prompt:open.fullPrompt||open.prompt};
    target.innerHTML=executionComparisonHtml(first,second);
  } catch(error){target.textContent='Comparison unavailable: '+String(error.message||error);}
});
$('executionMonitorClose').addEventListener('click',()=>$('executionMonitorPanel').classList.add('hidden'));
$('executionMonitorItems').addEventListener('click',async event=>{
  const activeAgent = event.target.closest('[data-monitor-agent]');
  if (activeAgent) {
    $('executionMonitorPanel').classList.add('hidden');
    if (activeAgent.dataset.monitorAgent) await openEliyaChatTab(activeAgent.dataset.monitorAgent);
    return;
  }
  const selected = event.target.closest('[data-monitor-session]');
  if (!selected) return;
  const session=terminalUi.sessions.find(s=>s.id===selected.dataset.monitorSession);
  $('executionMonitorPanel').classList.add('hidden');
  if(session?.engine==='opencode' && session.conversationId) {
    // The old Terminal dock is intentionally hidden by unified-screen CSS.
    // Reopen the conversation that owns this OpenCode run instead.
    try { await openEliyaChatTab(String(session.conversationId)); }
    catch(error) { toast('Unable to reopen OpenCode conversation: '+error.message,6500); }
    return;
  }
  terminalUi.selected = selected.dataset.monitorSession;terminalUi.draft = null;terminalUi.detail = null;
  clearTerminalAttachments();openTerminalDock();
});
setInterval(() => {
  for (const node of document.querySelectorAll('[data-agent-elapsed]')) {
    const article = node.closest('[data-message-index]');
    const index = Number(article?.dataset.messageIndex);
    const message = Number.isInteger(index) ? state.messages[index] : null;
    if (message) node.textContent = eliRunTimeLabel(message);
  }
  if (terminalUi.visible && terminalUi.detail) {
    const node = document.querySelector('[data-terminal-elapsed]');
    if (node) node.textContent = eliRunTimeLabel(terminalUi.detail, {startedAt:terminalUi.detail.startedAt || terminalUi.detail.createdAt,
      finishedAt:terminalUi.detail.finishedAt, elapsedMs:terminalUi.detail.elapsedMs});
  }
},1000);
setInterval(()=>void pollExecutionMonitor(), 2500);
setInterval(() => { if (terminalUi.visible) void pollTerminalSessions(); }, 8000);
setInterval(() => void refreshTerminalExecutionEngine(), 3000);
void pollExecutionMonitor();

// CLI bridge: any `eliya` command from Command Prompt, PowerShell, VS Code or IntelliJ
// changes the active workspace in this already-open browser without losing chat history.
let cliWorkspacePollBusy = false;
async function pollCliWorkspaceSelection() {
  if (cliWorkspacePollBusy || state.streaming) return;
  cliWorkspacePollBusy = true;
  try {
    const selection = await api('/api/cli/selection');
    if (!selection?.version || !selection?.project?.localWorkspace) return;
    const applied = storageGet('session', 'eliya.cli.appliedVersion');
    if (selection.version === applied) return;
    // When an entirely new browser tab opens after a manual UI workspace change,
    // honor the user's latest persisted choice. Existing tabs still observe every
    // new terminal revision independently through their own session marker.
    const alreadySeenByBrowser = storageGet('local', 'eliya.cli.lastSeenVersion');
    if (!applied && alreadySeenByBrowser === selection.version && state.project?.localWorkspace &&
        state.project.id !== selection.project.id) {
      storageSet('session', 'eliya.cli.appliedVersion', selection.version);
      return;
    }
    const project = selection.project;
    if (state.project?.id !== project.id) {
      state.project = project;
      state.projectRootHandle = null;
      state.projectFallbackFiles = null;
      state.pendingProjectChanges = null;
      state.referenceProjects = state.referenceProjects.filter(ref => ref.id !== project.id);
      saveReferenceFolders();
      rememberActiveLocalWorkspace(project);
      renderProjectBar();
      sharedFolderStatus(`Terminal workspace selected: ${project.localPath} · indexing in the background`);
      void watchFolderIndex(project, false);
      toast(`Eliya workspace: ${project.name}`, 3500);
    }
    // The terminal owns a workspace-scoped conversation; show exactly that history
    // in the browser without merging unrelated workspace discussions.
    if (selection.conversationId) {
      if (state.conversationId !== selection.conversationId) {
        await loadConversations();
        await openConversation(selection.conversationId);
      } else if (state.conversationId && selection.mode && !state.streaming) {
        // This refresh also brings in completed CLI analysis/agent results.
        await openConversation(selection.conversationId);
      }
    }
    state.workflowMode = selection.mode === 'agent' ? 'execute' : 'analyse';
    state.mode = state.workflowMode === 'execute' ? 'agent' : 'chat';
    if (state.conversationId) { workflowByTab[state.conversationId] = state.workflowMode; saveWorkflowChoice(); }
    updateModeUi();
    // A successfully applied revision is session-scoped: refreshing the page won't
    // override a later manual UI selection until another terminal command arrives.
    storageSet('session', 'eliya.cli.appliedVersion', selection.version);
    storageSet('local', 'eliya.cli.lastSeenVersion', selection.version);
  } catch (_) { /* A transient backend error must not interrupt Chat or Agent. */ }
  finally { cliWorkspacePollBusy = false; }
}
if (typeof window !== 'undefined' && typeof window.setInterval === 'function') {
  window.setInterval(() => { void pollCliWorkspaceSelection(); }, 3500);
}

(function init() {
  document.querySelector('main.main')?.appendChild($('terminalDock'));
  const storedTheme = storageGet('local', 'theme');
  if (storedTheme === 'dark' || storedTheme === 'light') {
    document.documentElement.dataset.theme = storedTheme;
  } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
    document.documentElement.dataset.theme = 'dark';
  } else {
    document.documentElement.dataset.theme = 'light';
  }

  // JAR startup installs the OS-specific CLI. Surface corporate-policy failures
  // without blocking the browser UI or asking the user to bypass execution policy.
  void api('/api/cli/setup-state').then(status => {
    if (!status || status.readyInNewTerminals || /not running an executable JAR|disabled by user/.test(status.message || '')) return;
    // Registry registration does not guarantee an already-running IDE or Explorer
    // parent process adopted the new PATH. Show the limitation instead of claiming
    // that typing `eliya` in an arbitrary terminal is already operational.
    toast('Eliya terminal setup: ' + String(status.message || 'CLI registration unavailable'), 9500);
  }).catch(() => {});
  syncSettingsUi();
  ensureConfiguredModelsInCatalog();
  void syncTerminalSettings();
  updateModelBadge();
  updateModeUi();
  updateWelcomeMode();
  renderMessages();
  renderAttachmentTray();
  renderProjectBar();
  installComposerClearance();
  restoreChatDraft(null); // Restore unsent draft after reload, never overwrite it on startup.
  renderReferenceFolders();
  restoreActiveLocalWorkspace().catch(() => {}).finally(() => { void pollCliWorkspaceSelection(); });
  // The index is in-memory; after an application restart rebuild persisted references
  // in the background instead of letting the first Chat question trigger a disk scan.
  for (const ref of state.referenceProjects) {
    void api(`/api/projects/${encodeURIComponent(ref.id)}`)
      .then(project => watchFolderIndex(project, true))
      .catch(() => { /* an offline reference must not block app startup */ });
  }
  loadConversations().then(async () => {
    const last=storageGet('session','llm.lastSelectedChat144') || storageGet('local','llm.lastSelectedChat145');
    if(last && state.conversations.some(c=>String(c.id)===last) && state.conversationId==null)
      await openConversation(last);
  }).catch(error => toast(error.message, 4000));
  void prewarmOpenCode();
  void refreshTerminalExecutionEngine();
})();

// Questions are answered only in the ordinary Agent composer and the Terminal composer.
// No separate clarification buttons, textarea, or second chat interface is created.

// Keep the execution selector synchronized when a chat is opened from history.
