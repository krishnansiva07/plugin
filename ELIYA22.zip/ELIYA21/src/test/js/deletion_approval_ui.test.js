'use strict';
// Tests the actual popup implementation in isolation without starting the Spring app.
// Run: node src/test/js/deletion_approval_ui.test.js
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const code = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const start = code.indexOf('// File-deletion confirmations are conspicuous');
const end = code.indexOf('async function rescanProject()', start);
assert.ok(start > 0 && end > start, 'Deletion popup functions not present');
const block = code.slice(start, end);
class Classes {
  constructor() { this.hidden = true; }
  add(value) { if (value === 'hidden') this.hidden = true; }
  remove(value) { if (value === 'hidden') this.hidden = false; }
  contains(value) { return value === 'hidden' ? this.hidden : false; }
}
const nodes = Object.fromEntries(['deletionApprovalBackdrop', 'deletionApprovalTargets',
  'deletionApproveBtn', 'deletionRejectBtn', 'deletionApprovalCountdown'].map(x => [x, {
  dataset: {}, classList: new Classes(), textContent: '', disabled: false
}]));
const approvalId = 'approval-one';
const deletion = {step:3, status:'approval', approvalId, approvalType:'file_deletion', tool:'delete',
  output:'DELETE: src/file.java', approvalExpiresAt:new Date(Date.now() + 60000).toISOString()};
let renderCount = 0; const calls = [];
const state = {activeAgentRunId:'run1', messages:[{role:'assistant', streaming:true,
  agentRunId:'run1', agentBackendStatus:'running', agentSteps:[deletion]}]};
const env = {state, Date, Math, String, Number, Array, console,
  $:id => nodes[id], window:{setInterval:() => 0},
  api:async (url, opts) => {calls.push([url, JSON.parse(opts.body)]);return {resolved:true};},
  renderMessages:() => {renderCount++;}, toast:() => {}};
vm.createContext(env);
vm.runInContext(block, env);
assert.equal(vm.runInContext('pendingDeletionApproval()?.approvalId', env), approvalId);
vm.runInContext('refreshDeletionApprovalModal()', env);
assert.equal(nodes.deletionApprovalBackdrop.classList.contains('hidden'), false);
assert.match(nodes.deletionApprovalTargets.textContent, /src\/file\.java/);
assert.ok(Number.parseInt(nodes.deletionApprovalCountdown.textContent) > 0);
vm.runInContext('respondToDeletionApproval("once")', env).then(() => {
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0], ['/api/agent/approvals/approval-one', {action:'once'}]);
  assert.equal(nodes.deletionApprovalBackdrop.classList.contains('hidden'), true);
  assert.ok(renderCount >= 1);
  deletion.status = 'approval'; deletion.approvalExpiresAt = new Date(Date.now() - 1000).toISOString();
  vm.runInContext('refreshDeletionApprovalModal()', env);
  assert.equal(nodes.deletionApproveBtn.disabled, true);
  console.log('PASS: deletion approval popup, single approval, expiry controls');
}).catch(err => { console.error(err); process.exitCode = 1; });
