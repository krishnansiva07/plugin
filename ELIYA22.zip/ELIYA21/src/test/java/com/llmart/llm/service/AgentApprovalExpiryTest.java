package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.time.Duration;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentApprovalExpiryTest {
    @Test void expiredDeletionApprovalCannotBeAcceptedOrReused() throws Exception {
        AgentApprovalService service = new AgentApprovalService();
        var approval = service.create("test-run", "delete", "DELETE: keep.txt", false, Duration.ofMillis(30));
        Thread.sleep(70);
        assertFalse(service.resolve(approval.id(), AgentApprovalService.Decision.ONCE));
        assertThrows(IllegalStateException.class, () -> service.await(approval.id(), Duration.ofMillis(100), mock(AgentRunService.AgentRun.class)));
    }

    @Test void fileDeletionRejectsAllowForRunButAllowsSingleClick() {
        AgentApprovalService service = new AgentApprovalService();
        var approval = service.create("test-run", "delete", "DELETE: old.java", false, Duration.ofSeconds(60));
        assertFalse(service.resolve(approval.id(), AgentApprovalService.Decision.RUN));
        assertTrue(service.resolve(approval.id(), AgentApprovalService.Decision.ONCE));
    }

    @Test void unansweredDeletionTimesOutAndRequiresRollback() {
        AgentApprovalService service = new AgentApprovalService();
        var approval = service.create("test-run", "delete", "DELETE: old.java", false, Duration.ofMillis(60));
        var run = mock(AgentRunService.AgentRun.class);
        assertThrows(AgentApprovalTimeoutException.class,
                () -> service.await(approval.id(), Duration.ofMillis(60), run));
        assertFalse(service.resolve(approval.id(), AgentApprovalService.Decision.ONCE));
    }
}
