package com.llmart.llm.service;

import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Regression coverage for mixed visual/text workspaces and source-located visual evidence. */
class WorkspaceDocumentScannerTest {
    @TempDir Path tmp;
    private final WorkspaceDocumentScanner scanner = new WorkspaceDocumentScanner();

    @Test void docxWithPicturePreservesVisualAndNearbyText() throws Exception {
        BufferedImage sample = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
        ByteArrayOutputStream png = new ByteArrayOutputStream();
        ImageIO.write(sample, "png", png);
        Path source = tmp.resolve("Requirements.docx");
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText("Section 3: deep search should return successful results");
            var p = doc.createParagraph();
            p.createRun().setText("Screenshot of search button and results panel");
            p.createRun().addPicture(new ByteArrayInputStream(png.toByteArray()), Document.PICTURE_TYPE_PNG,
                    "requirements-screenshot.png", 16 * 9525, 16 * 9525);
            try (var out = Files.newOutputStream(source)) { doc.write(out); }
        }
        var scan = scanner.scan(source);
        assertTrue(scan.text().contains("deep search"));
        assertEquals(1, scan.detectedVisuals());
        assertEquals(1, scan.visuals().size());
        assertTrue(scan.visuals().get(0).context().contains("Screenshot of search button"));
    }

    @Test void textOnlyPdfDoesNotWasteVisionRequests() throws Exception {
        Path pdfPath = tmp.resolve("business-rules.pdf");
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(); doc.addPage(page);
            try (PDPageContentStream stream = new PDPageContentStream(doc, page)) {
                stream.beginText(); stream.setFont(PDType1Font.HELVETICA, 12);
                stream.newLineAtOffset(60, 680); stream.showText("Business rule: transfer limit"); stream.endText();
            }
            doc.save(pdfPath.toFile());
        }
        var scan = scanner.scan(pdfPath);
        assertTrue(scan.text().contains("transfer limit"));
        assertEquals(0, scan.detectedVisuals());
    }

    @Test void vectorFlowPdfRequiresVisionWithoutEmbeddedRasterImages() throws Exception {
        Path pdfPath = tmp.resolve("process.pdf");
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(); doc.addPage(page);
            try (PDPageContentStream stream = new PDPageContentStream(doc, page)) {
                stream.beginText(); stream.setFont(PDType1Font.HELVETICA, 12);
                stream.newLineAtOffset(60, 680); stream.showText("Approval workflow"); stream.endText();
                for (int i = 0; i < 4; i++) { stream.addRect(60 + i * 50, 440, 40, 25); stream.stroke(); }
            }
            doc.save(pdfPath.toFile());
        }
        var scan = scanner.scan(pdfPath);
        assertEquals(1, scan.detectedVisuals());
        assertEquals(1, scan.visuals().size());
        assertEquals("page-1", scan.visuals().get(0).locator());
    }

    @Test void mixedFolderScanIsContentDrivenRatherThanExtensionGuessing() throws Exception {
        Path text = tmp.resolve("rules.txt"); Files.writeString(text, "No screenshots in this document");
        Path image = tmp.resolve("visual.png");
        BufferedImage sample = new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB);
        ImageIO.write(sample, "png", image.toFile());
        assertEquals(0, scanner.scan(text).detectedVisuals());
        assertEquals(1, scanner.scan(image).detectedVisuals());
    }
}
