package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatMcpServiceTest {
    @Test
    void detectsExternalMcpRequestsWithoutHijackingOrdinaryChat() {
        ChatMcpService service = new ChatMcpService(null, null, null);
        assertTrue(service.shouldHandle("Read Jira PAY-123 and explain the acceptance criteria"));
        assertTrue(service.shouldHandle("What is the status of ABC-42?"));
        assertTrue(service.shouldHandle("Search Confluence for the SEPA architecture"));
        assertTrue(service.shouldHandle("Check the SonarQube quality gate"));
        assertTrue(service.shouldHandle("What is the recent tickets in BMSA"));
        assertTrue(service.shouldHandle("List the latest issues in BMSA"));
        assertTrue(service.shouldHandle("Show open bugs in Jira"));
        assertTrue(service.shouldHandle("How many unresolved stories are in the backlog?"));
        assertFalse(service.shouldHandle("How are Jira tickets handled in our source code?"));
        assertFalse(service.shouldHandle("Explain Java inheritance with an example"));
    }
}
