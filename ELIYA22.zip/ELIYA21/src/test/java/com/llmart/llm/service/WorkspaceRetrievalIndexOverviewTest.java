package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class WorkspaceRetrievalIndexOverviewTest {
    @TempDir Path workspace;

    @Test
    void overviewQuestionGetsRealFileTreeAndReadmeWithoutKeywordMatch() throws Exception {
        Files.writeString(workspace.resolve("README.md"), "This app uses a controller to receive orders and a service to process them.");
        Path src = Files.createDirectories(workspace.resolve("src/main/java"));
        Files.writeString(src.resolve("OrdersController.java"), "public class OrdersController {}\n");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        var stats = index.warmRoot("project-one", workspace);
        assertEquals(2, stats.indexedFiles());
        assertTrue(stats.indexedCharacters() > 0);
        String result = index.retrieveCachedRoot("project-one", workspace,
                "Can you check how the attached project works?", 12, 18_000);
        assertTrue(result.contains("README.md"));
        assertTrue(result.contains("src/main/java/OrdersController.java"));
        assertTrue(result.contains("This app uses a controller"));
        assertTrue(result.contains("ACTIVE LOCAL PROJECT"));
    }

    @Test
    void specificQuestionStillUsesMatchingCodeSnippets() throws Exception {
        Files.writeString(workspace.resolve("AuthService.java"),
                "public class AuthService { void validateJwtToken() {} }");
        Files.writeString(workspace.resolve("Readme.md"), "How to run the application.");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        index.warmRoot("project-two", workspace);
        String result = index.retrieveCachedRoot("project-two", workspace,
                "Where is validateJwtToken implemented?", 12, 18_000);
        assertTrue(result.contains("AuthService.java"));
        assertTrue(result.contains("validateJwtToken"));
    }

    @Test
    void unmatchedQuestionShowsActualManifestRatherThanPretendingThereIsNoProject() throws Exception {
        Files.writeString(workspace.resolve("pom.xml"), "<project><artifactId>demo</artifactId></project>");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        index.warmRoot("project-three", workspace);
        String result = index.retrieveCachedRoot("project-three", workspace,
                "Can you inspect the unrelated widget?", 12, 18_000);
        assertTrue(result.contains("pom.xml"));
        assertTrue(result.contains("demo"));
    }
}
