package com.llmart.llm.config;

import com.zaxxer.hikari.HikariDataSource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

import javax.sql.DataSource;
import java.nio.file.Path;
import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;

class PortableDatabaseConfigurationTest {

    @TempDir Path temp;

    @Test
    void unrelatedHostOracleSettingsCannotOverrideEliyaH2() {
        Path db = temp.resolve("db folder").resolve("chatdb");
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(DataSourceAutoConfiguration.class))
                .withUserConfiguration(PortableDatabaseConfiguration.class)
                .withPropertyValues(
                        "app.database.path=" + db,
                        "spring.datasource.url=jdbc:oracle:thin:@example:1521/ORCL",
                        "spring.datasource.driver-class-name=oracle.jdbc.OracleDriver",
                        "spring.datasource.username=some-other-user",
                        "spring.jpa.database-platform=org.hibernate.dialect.OracleDialect")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    assertThat(context).hasSingleBean(DataSource.class);
                    HikariDataSource source = (HikariDataSource) context.getBean(DataSource.class);
                    assertThat(source.getJdbcUrl()).startsWith("jdbc:h2:file:");
                    try (var connection = source.getConnection()) {
                        assertThat(connection.getMetaData().getDatabaseProductName()).isEqualTo("H2");
                    }
                    var properties = new HashMap<String, Object>();
                    context.getBean(org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer.class)
                            .customize(properties);
                    assertThat(properties).containsEntry("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
                });
        assertThat(db.resolveSibling("chatdb.mv.db")).exists();
    }
}
