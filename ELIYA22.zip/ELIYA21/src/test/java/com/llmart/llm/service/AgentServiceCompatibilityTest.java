package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class AgentServiceCompatibilityTest {
    private final ObjectMapper mapper = new ObjectMapper();
    private final AgentToolRegistry registry = new AgentToolRegistry();
    private final AgentService service = new AgentService(
            mock(OpenAiCompatibleClient.class),
            mock(AgentWorkspaceService.class),
            mock(AgentApprovalService.class),
            mock(AgentRunService.class),
            registry,
            mock(FileService.class),
            mock(McpManager.class),
            mock(WorkspaceProfileService.class),
            mock(WorkspaceRetrievalIndexService.class),
            mock(WorkspaceKnowledgeService.class),
            mock(VisionDocumentService.class),
            mock(DocumentationIntelligenceService.class),
            mock(ProtectedRunSnapshotService.class),
            mock(AgentProfileService.class),
            mock(LspManager.class),
            mock(ContextWindowManager.class),
            mapper);

    @AfterEach
    void close() { service.shutdownExecutors(); }

    @Test
    void genericSearchQueryIsRepairedToGrepPattern() {
        ObjectNode raw = mapper.createObjectNode();
        raw.put("query", "OctaneIntegration");
        raw.put("maxMatches", 20);

        var normalized = service.normalizeLegacyArgs("search", registry.canonical("search"), raw);

        assertEquals("OctaneIntegration", normalized.path("pattern").asText());
        assertEquals(20, normalized.path("maxMatches").asInt());
    }

    @Test
    void noisyReadToolStillUsesCanonicalReadName() {
        assertEquals("read", registry.canonical("read/<channel>commentary"));
        assertEquals("read", registry.canonical("functions.read/<channel>commentary"));
    }

    @Test
    void patchInputCompatibilityIsRepaired() {
        ObjectNode raw = mapper.createObjectNode();
        raw.put("input", "*** Begin Patch\n*** Add File: a.txt\n+hello\n*** End Patch");

        var normalized = service.normalizeLegacyArgs("apply_patch", "apply_patch", raw);

        assertTrue(normalized.path("patch").asText().contains("*** Begin Patch"));
    }

    @Test
    void legacyPlanUpdateMapsToNativeTodoUpdate() {
        assertEquals("todo_update", registry.canonical("update_plan"));
    }
    @Test
    void detectsRepositoryDocumentationCreationWithoutMisclassifyingDocumentAnalysis() throws Exception {
        var method = AgentService.class.getDeclaredMethod("isDocumentationTask", String.class);
        method.setAccessible(true);
        assertTrue((Boolean) method.invoke(service, "Create complete functional and technical docs for this big codebase"));
        assertTrue((Boolean) method.invoke(service, "Document this repository architecture and APIs"));
        assertFalse((Boolean) method.invoke(service, "Analyse the functional document in the project workspace and summarize section 3"));
    }

}
