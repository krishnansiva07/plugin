package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

@Service
public class AgentApprovalService {
    private final Map<String, PendingApproval> pending = new ConcurrentHashMap<>();

    public Approval create(String runId, String tool, String detail) {
        return create(runId, tool, detail, true);
    }

    /** File-destructive approvals cannot be granted for the entire run, including via the REST endpoint. */
    public Approval create(String runId, String tool, String detail, boolean allowRunGrant) {
        return create(runId, tool, detail, allowRunGrant, null);
    }

    /** TTL is enforced by backend resolve AND await; browser timers are informational only. */
    public Approval create(String runId, String tool, String detail, boolean allowRunGrant, Duration ttl) {
        String id = UUID.randomUUID().toString();
        Instant expiry = ttl == null || ttl.isZero() || ttl.isNegative() ? null : Instant.now().plus(ttl);
        PendingApproval item = new PendingApproval(new CompletableFuture<>(), Instant.now(), runId, tool, detail, allowRunGrant, expiry);
        pending.put(id, item);
        return new Approval(id, runId, tool, detail, allowRunGrant, expiry);
    }

    public Decision await(String id, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        PendingApproval item = pending.get(id);
        if (item == null) throw new IllegalStateException("Approval request no longer exists");
        long requestedNanos = timeout == null || timeout.isNegative() || timeout.isZero() ? Long.MAX_VALUE : timeout.toNanos();
        long localDeadline = requestedNanos == Long.MAX_VALUE ? Long.MAX_VALUE : System.nanoTime() + requestedNanos;
        try {
            while (true) {
                run.checkCancelled();
                if (System.nanoTime() >= localDeadline || expired(item))
                    throw new AgentApprovalTimeoutException("Approval timed out; execution must stop");
                try {
                    Decision decision = item.future().get(250, TimeUnit.MILLISECONDS);
                    // A decision delivered after deadline is never accepted, even if resolve raced with await.
                    if (System.nanoTime() >= localDeadline || expired(item))
                        throw new AgentApprovalTimeoutException("Approval timed out; execution must stop");
                    return decision;
                } catch (TimeoutException ignored) { }
            }
        } finally {
            pending.remove(id);
        }
    }

    public Decision await(String id, Duration timeout) throws Exception {
        PendingApproval item = pending.get(id);
        if (item == null) throw new IllegalStateException("Approval request no longer exists");
        try {
            Decision decision = item.future().get(timeout.toMillis(), TimeUnit.MILLISECONDS);
            if (expired(item)) throw new AgentApprovalTimeoutException("Approval timed out");
            return decision;
        } catch (TimeoutException e) {
            throw new IllegalStateException("Approval timed out");
        } finally {
            pending.remove(id);
        }
    }

    public boolean resolve(String id, Decision decision) {
        PendingApproval item = pending.get(id);
        if (item == null) return false;
        if (expired(item)) {
            item.future().complete(Decision.DENY);
            pending.remove(id, item);
            return false;
        }
        if (decision == Decision.RUN && !item.allowRunGrant()) return false;
        return item.future().complete(decision == null ? Decision.DENY : decision);
    }

    /** Backward-compatible endpoint/service helper for older clients. */
    public boolean resolve(String id, boolean approved) {
        return resolve(id, approved ? Decision.ONCE : Decision.DENY);
    }

    public int cancelRun(String runId) {
        if (runId == null || runId.isBlank()) return 0;
        int count = 0;
        for (Map.Entry<String, PendingApproval> entry : pending.entrySet()) {
            PendingApproval item = entry.getValue();
            if (!runId.equals(item.runId())) continue;
            if (item.future().complete(Decision.DENY)) count++;
        }
        return count;
    }

    private boolean expired(PendingApproval item) {
        return item.expiresAt() != null && !Instant.now().isBefore(item.expiresAt());
    }
    public enum Decision { ONCE, RUN, DENY }
    public record Approval(String id, String runId, String tool, String detail, boolean allowRunGrant, Instant expiresAt) {}
    private record PendingApproval(CompletableFuture<Decision> future, Instant createdAt, String runId, String tool,
                                   String detail, boolean allowRunGrant, Instant expiresAt) {}
}
