package com.llmart.llm.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * The application owns its embedded database. Never use SPRING_DATASOURCE_* from a
 * developer's machine: those settings often belong to another Spring application.
 *
 * All supported operating systems use the same H2 database and the existing
 * per-user app.database.path, preserving history when a JAR is replaced/moved.
 */
@Configuration(proxyBeanMethods = false)
public class PortableDatabaseConfiguration {

    @Bean
    @Primary
    public DataSource dataSource(@Value("${app.database.path}") String configuredPath) {
        if (configuredPath == null || configuredPath.isBlank()) {
            throw new IllegalStateException("ELIYA database path is empty. Configure app.database.path.");
        }

        final Path databasePath;
        try {
            databasePath = Path.of(configuredPath).toAbsolutePath().normalize();
            Path parent = databasePath.getParent();
            if (parent != null) Files.createDirectories(parent);
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException(
                    "ELIYA cannot prepare its database directory. Check app.database.path and filesystem permissions.", e);
        }

        HikariConfig config = new HikariConfig();
        config.setPoolName("ELIYA-H2");
        config.setDriverClassName("org.h2.Driver");
        // Preserve ELIYA's established on-disk H2 database and AUTO_SERVER behavior.
        // Forward slashes work with H2 on Windows, macOS, and Linux.
        config.setJdbcUrl("jdbc:h2:file:" + databasePath.toString().replace('\\', '/') + ";AUTO_SERVER=TRUE");
        config.setUsername("sa");
        config.setPassword("");
        return new HikariDataSource(config);
    }

    @Bean
    public HibernatePropertiesCustomizer eliyaH2Dialect() {
        // Prevent a machine-wide Spring/JPA Oracle dialect from leaking into ELIYA.
        return properties -> properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
    }
}
