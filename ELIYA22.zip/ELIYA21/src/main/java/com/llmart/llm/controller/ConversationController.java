package com.llmart.llm.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.service.ConversationService;
import com.llmart.llm.service.ProjectService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/api/conversations")
public class ConversationController {
    private final ConversationService service;
    private final ObjectMapper objectMapper;
    private final ProjectService projects;
    private final com.llmart.llm.service.PdfExportService pdf;
    private final com.llmart.llm.service.AgentRunService agentRuns;

    public ConversationController(ConversationService service, ObjectMapper objectMapper, ProjectService projects,
                                  com.llmart.llm.service.PdfExportService pdf,
                                  com.llmart.llm.service.AgentRunService agentRuns) {
        this.service = service;
        this.objectMapper = objectMapper;
        this.projects = projects;
        this.pdf = pdf;
        this.agentRuns = agentRuns;
    }

    @GetMapping
    public List<ConversationDto> list() { return service.list(); }

    @PostMapping
    public ConversationDto create() {
        ConversationEntity c = service.create();
        return new ConversationDto(c.getId(), c.getTitle(), c.getCreatedAt(), c.getUpdatedAt());
    }

    @GetMapping("/{id}/messages")
    public List<MessageDto> messages(@PathVariable String id) { return service.listMessages(id); }

    @PatchMapping("/{id}")
    public ConversationDto rename(@PathVariable String id, @RequestBody Map<String, String> body) {
        return service.rename(id, body.get("title"));
    }

    @PostMapping("/{id}/rewind/{messageId}")
    public void rewind(@PathVariable String id, @PathVariable Long messageId) { service.rewindFrom(id, messageId); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        projects.deleteForConversation(id);
        agentRuns.deleteForConversation(id);
        service.delete(id);
    }

    @DeleteMapping
    public Map<String, Object> clearHistory() {
        List<ConversationDto> existing = service.list();
        // Cancel/tombstone runs first so a detached worker cannot recreate history while conversations are removed.
        int runCount = agentRuns.clearHistory();
        for (ConversationDto conversation : existing) {
            String id = conversation.id();
            projects.deleteForConversation(id);
            service.delete(id);
        }
        return Map.of("clearedConversations", existing.size(), "clearedAgentRuns", runCount);
    }

    @GetMapping("/{id}/export")
    public ResponseEntity<byte[]> export(@PathVariable String id,
                                         @RequestParam(defaultValue = "md") String format) throws Exception {
        ConversationEntity c = service.require(id);
        List<MessageDto> messages = service.listMessages(id);
        String fileName;
        byte[] bytes;
        MediaType type;

        if ("json".equalsIgnoreCase(format)) {
            String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(messages);
            bytes = json.getBytes(StandardCharsets.UTF_8);
            type = MediaType.APPLICATION_JSON;
            fileName = safe(c.getTitle()) + ".json";
        } else if ("pdf".equalsIgnoreCase(format)) {
            bytes = pdf.conversation(c.getTitle(), messages);
            type = MediaType.APPLICATION_PDF;
            fileName = safe(c.getTitle()) + ".pdf";
        } else {
            StringBuilder md = new StringBuilder("# ").append(c.getTitle()).append("\n\n");
            for (MessageDto m : messages) md.append("## ").append("user".equals(m.role()) ? "You" : "Assistant").append("\n\n").append(m.content()).append("\n\n");
            bytes = md.toString().getBytes(StandardCharsets.UTF_8);
            type = new MediaType("text", "markdown", StandardCharsets.UTF_8);
            fileName = safe(c.getTitle()) + ".md";
        }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(bytes);
    }

    private String safe(String s) { return s.replaceAll("[^a-zA-Z0-9._ -]", "_"); }
}
