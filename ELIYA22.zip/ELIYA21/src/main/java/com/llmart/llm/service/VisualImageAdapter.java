package com.llmart.llm.service;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;

/** Bound vision image dimensions and request bytes before dispatching to model gateways. */
final class VisualImageAdapter {
    static byte[] normalizedJpeg(byte[] source) throws IOException {
        BufferedImage original = ImageIO.read(new ByteArrayInputStream(source));
        if (original == null) throw new IOException("Image encoding unsupported: PNG/JPEG/GIF/BMP are supported");
        int limit = 1700;
        double scale = Math.min(1.0, (double) limit / Math.max(original.getWidth(), original.getHeight()));
        int width = Math.max(1, (int) (original.getWidth() * scale));
        int height = Math.max(1, (int) (original.getHeight() * scale));
        BufferedImage rgb = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = rgb.createGraphics();
        try {
            g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.drawImage(original, 0, 0, width, height, null);
        } finally { g.dispose(); original.flush(); }
        Iterator<javax.imageio.ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpeg");
        if (!writers.hasNext()) throw new IOException("JPEG image writer unavailable");
        javax.imageio.ImageWriter writer = writers.next();
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            try (javax.imageio.stream.ImageOutputStream io = ImageIO.createImageOutputStream(out)) {
                writer.setOutput(io);
                ImageWriteParam options = writer.getDefaultWriteParam();
                options.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                options.setCompressionQuality(0.85f);
                writer.write(null, new javax.imageio.IIOImage(rgb, null, null), options);
            }
            return out.toByteArray();
        } finally { writer.dispose(); rgb.flush(); }
    }
    private VisualImageAdapter() { }
}
