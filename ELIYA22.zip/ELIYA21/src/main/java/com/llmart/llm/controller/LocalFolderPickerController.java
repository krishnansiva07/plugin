package com.llmart.llm.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.Frame;
import java.net.InetAddress;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Chooses a folder on the computer running the ELIYA JVM, not the remote browser's computer.
 * Expected desktop failures return a structured, actionable response rather than HTTP 500.
 */
@RestController
@RequestMapping("/api/local-folders")
public class LocalFolderPickerController {
    private static final Logger LOG = Logger.getLogger(LocalFolderPickerController.class.getName());
    // A second HTTP request must not queue a second modal dialog behind the first one.
    private static final AtomicBoolean PICKER_OPEN = new AtomicBoolean(false);
    private static final WindowsPicker WINDOWS_PICKER = new WindowsPicker();
    private static volatile Path lastMacDirectory;
    private static final String UNAVAILABLE = "The folder picker could not open on this computer. "
            + "Use Enter path (or Reference path) and provide a folder on the computer running ELIYA.";

    @PostConstruct
    public void prewarmDesktopPicker() {
        // PowerShell/Windows Forms cold start can take several seconds on managed Windows PCs.
        // Prepare it in a daemon thread, never on a Spring startup or HTTP request thread.
        if (isWindows()) WINDOWS_PICKER.prepare();
    }

    @PreDestroy
    public void stopDesktopPicker() {
        WINDOWS_PICKER.close();
    }

    @PostMapping("/browse")
    public ResponseEntity<Map<String, Object>> browse(HttpServletRequest request) {
        if (!isLocalRequest(request.getRemoteAddr())) {
            return error(HttpStatus.FORBIDDEN, "LOCAL_ONLY",
                    "Browse is only available when your browser and ELIYA run on the same computer. "
                    + "Use Enter path for a folder on the ELIYA machine.");
        }
        if (!isSameOrigin(request.getHeader("Origin"), request.getHeader("Host"), request.getScheme())) {
            return error(HttpStatus.FORBIDDEN, "ORIGIN_MISMATCH",
                    "Folder selection was blocked because the browser origin differs from ELIYA's address. "
                    + "Open ELIYA using the same address as the current page and try again.");
        }
        if (!PICKER_OPEN.compareAndSet(false, true)) {
            return error(HttpStatus.CONFLICT, "PICKER_BUSY",
                    "A folder picker is already open. Close it before choosing another folder.");
        }
        try {
            Optional<Path> selection = chooseDirectory();
            if (selection.isEmpty()) return ResponseEntity.ok(Map.of("cancelled", true));
            Path folder = selection.get().toRealPath();
            if (!Files.isDirectory(folder)) {
                return error(HttpStatus.BAD_REQUEST, "INVALID_FOLDER", "Choose an existing directory.");
            }
            return ResponseEntity.ok(Map.of("path", folder.toString()));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            return error(HttpStatus.SERVICE_UNAVAILABLE, "PICKER_UNAVAILABLE", UNAVAILABLE);
        } catch (Exception exception) {
            LOG.log(Level.WARNING, "ELIYA local folder selection failed", exception);
            return error(HttpStatus.SERVICE_UNAVAILABLE, "PICKER_UNAVAILABLE", UNAVAILABLE);
        } finally {
            PICKER_OPEN.set(false);
        }
    }

    static boolean isLocalRequest(String remoteAddress) {
        if (remoteAddress == null || remoteAddress.isBlank()) return false;
        try { return InetAddress.getByName(remoteAddress).isLoopbackAddress(); }
        catch (Exception ex) { return false; }
    }

    static boolean isSameOrigin(String origin, String host, String scheme) {
        if (origin == null) return true; // non-browser/older same-origin clients need not send Origin
        if (origin.isBlank() || host == null || host.isBlank()) return false;
        try {
            URI originUri = URI.create(origin);
            URI serverUri = URI.create(scheme + "://" + host);
            return originUri.getUserInfo() == null && originUri.getRawQuery() == null
                    && originUri.getRawFragment() == null
                    && originUri.getHost() != null && serverUri.getHost() != null
                    && originUri.getHost().equalsIgnoreCase(serverUri.getHost())
                    && originUri.getScheme().equalsIgnoreCase(serverUri.getScheme())
                    && effectivePort(originUri) == effectivePort(serverUri);
        } catch (IllegalArgumentException | NullPointerException ex) {
            return false;
        }
    }

    private static int effectivePort(URI uri) {
        if (uri.getPort() >= 0) return uri.getPort();
        return "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80;
    }

    private static ResponseEntity<Map<String, Object>> error(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(Map.of("code", code, "message", message));
    }

    static Optional<Path> chooseDirectory() throws Exception {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        // No workspace traversal, indexing, MCP or model call is allowed in the Browse endpoint.
        if (os.contains("mac")) {
            // macOS AWT FileDialog is the native Cocoa chooser in the *existing* Java process.
            // Avoid launching osascript afresh, which also introduces app focus/permission delays.
            return macDirectoryDialog();
        }
        if (os.contains("win")) {
            // Keep one warmed, single-threaded Windows Forms process for repeated Browse clicks.
            // It is started asynchronously when the application starts.
            return WINDOWS_PICKER.pick();
        } else if (os.contains("linux") && (System.getenv("DISPLAY") != null || System.getenv("WAYLAND_DISPLAY") != null)) {
            boolean kdeDesktop = System.getenv().getOrDefault("XDG_CURRENT_DESKTOP", "")
                    .toLowerCase(Locale.ROOT).contains("kde");
            if (kdeDesktop) {
                Optional<Optional<Path>> kde = tryNativePicker(List.of("kdialog", "--getexistingdirectory"));
                if (kde.isPresent()) return kde.get();
            }
            Optional<Optional<Path>> linux = tryNativePicker(List.of("zenity", "--file-selection", "--directory",
                    "--title=Select ELIYA folder"));
            if (linux.isPresent()) return linux.get();
            if (!kdeDesktop) {
                Optional<Optional<Path>> kde = tryNativePicker(List.of("kdialog", "--getexistingdirectory"));
                if (kde.isPresent()) return kde.get();
            }
        }
        throw new IllegalStateException("No usable graphical folder chooser in this environment");
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private static Optional<Path> macDirectoryDialog() throws Exception {
        if (java.awt.GraphicsEnvironment.isHeadless())
            throw new IllegalStateException("No macOS graphical desktop available");
        java.util.concurrent.atomic.AtomicReference<Optional<Path>> selection =
                new java.util.concurrent.atomic.AtomicReference<>(Optional.empty());
        Runnable show = () -> {
            // The folder-only setting is macOS-specific and read when FileDialog is opened.
            String previous = System.getProperty("apple.awt.fileDialogForDirectories");
            FileDialog dialog = null;
            try {
                System.setProperty("apple.awt.fileDialogForDirectories", "true");
                dialog = new FileDialog((Frame) null, "Select ELIYA folder", FileDialog.LOAD);
                dialog.setDirectory(lastMacDirectory == null ? System.getProperty("user.home")
                        : lastMacDirectory.toString());
                dialog.setAlwaysOnTop(true);
                dialog.setVisible(true);
                if (dialog.getFile() != null) {
                    Path selected = Path.of(dialog.getDirectory(), dialog.getFile())
                            .toAbsolutePath().normalize();
                    lastMacDirectory = selected;
                    selection.set(Optional.of(selected));
                }
            } finally {
                if (dialog != null) dialog.dispose();
                if (previous == null) System.clearProperty("apple.awt.fileDialogForDirectories");
                else System.setProperty("apple.awt.fileDialogForDirectories", previous);
            }
        };
        if (EventQueue.isDispatchThread()) show.run();
        else EventQueue.invokeAndWait(show);
        return selection.get();
    }

    /**
     * A reusable Windows STA picker. No shell command is constructed from a user path. Paths
     * are passed back as base64 UTF-8 so spaces, quotes and non-English names are unambiguous.
     */
    private static final class WindowsPicker {
        private static final String SCRIPT = """
                $ErrorActionPreference = 'Stop'
                $OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
                Add-Type -AssemblyName System.Windows.Forms
                [System.Windows.Forms.Application]::EnableVisualStyles()
                $lastPath = [Environment]::GetFolderPath('UserProfile')
                [Console]::WriteLine('ELIYA_READY')
                while (($cmd = [Console]::ReadLine()) -ne $null) {
                  if ($cmd -ne 'OPEN') { continue }
                  $picker = $null
                  try {
                    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
                    $picker.Description = 'Select ELIYA folder'
                    $picker.ShowNewFolderButton = $true
                    if ($lastPath -and [System.IO.Directory]::Exists($lastPath)) {
                      $picker.SelectedPath = $lastPath
                    }
                    if ($picker.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                      $lastPath = $picker.SelectedPath
                      $encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($lastPath))
                      [Console]::WriteLine('ELIYA_SELECTED:' + $encoded)
                    } else { [Console]::WriteLine('ELIYA_CANCELLED') }
                  } catch { [Console]::WriteLine('ELIYA_ERROR') }
                  finally { if ($null -ne $picker) { $picker.Dispose() } }
                }
                """;
        private volatile CompletableFuture<Worker> warming;
        private volatile Process process;

        synchronized void prepare() {
            if (warming != null) return;
            CompletableFuture<Worker> task = new CompletableFuture<>();
            warming = task;
            Thread thread = new Thread(() -> {
                try {
                    Process created = new ProcessBuilder("powershell.exe", "-NoLogo", "-NoProfile",
                            "-NonInteractive", "-STA", "-Command", SCRIPT)
                            .redirectErrorStream(true).start();
                    synchronized (WindowsPicker.this) {
                        // Shutdown or a failed warm-up may already have invalidated this task.
                        // Do not leave a late-starting PowerShell process orphaned.
                        if (warming != task) {
                            created.destroyForcibly();
                            return;
                        }
                        process = created;
                    }
                    Worker worker = new Worker(created);
                    String line;
                    int messages = 0;
                    do {
                        line = worker.output.readLine();
                    } while (line != null && !line.equals("ELIYA_READY") && ++messages < 20);
                    if (!"ELIYA_READY".equals(line)) {
                        created.destroyForcibly();
                        throw new IllegalStateException("Windows picker could not initialize");
                    }
                    task.complete(worker);
                } catch (Exception ex) {
                    task.completeExceptionally(ex);
                }
            }, "eliya-windows-picker-warmup");
            thread.setDaemon(true);
            thread.start();
        }

        Optional<Path> pick() throws Exception {
            prepare();
            Worker worker;
            try {
                worker = warming.get(12, TimeUnit.SECONDS);
            } catch (ExecutionException | TimeoutException ex) {
                close();
                throw new IllegalStateException("Windows folder picker did not initialize", ex);
            }
            if (!worker.process.isAlive()) {
                close();
                throw new IllegalStateException("Windows folder picker exited unexpectedly");
            }
            try {
                worker.input.write("OPEN\n");
                worker.input.flush();
                FutureTask<Optional<Path>> reply = new FutureTask<>(() -> {
                    String line;
                    while ((line = worker.output.readLine()) != null) {
                        if (line.equals("ELIYA_CANCELLED")) return Optional.empty();
                        if (line.startsWith("ELIYA_SELECTED:")) {
                            byte[] bytes = Base64.getDecoder().decode(line.substring("ELIYA_SELECTED:".length()));
                            return Optional.of(Path.of(new String(bytes, StandardCharsets.UTF_8)));
                        }
                        if (line.equals("ELIYA_ERROR")) throw new IllegalStateException("Windows folder dialog failed");
                    }
                    throw new IllegalStateException("Windows folder dialog exited without a selection");
                });
                Thread reader = new Thread(reply, "eliya-windows-picker-result");
                reader.setDaemon(true);
                reader.start();
                return reply.get(90, TimeUnit.SECONDS);
            } catch (Exception ex) {
                close(); // Kill a hung/failed picker so the next click gets a fresh worker.
                throw ex;
            }
        }

        synchronized void close() {
            Process current = process;
            process = null;
            warming = null;
            if (current != null && current.isAlive()) current.destroyForcibly();
        }

        private static final class Worker {
            final Process process;
            final BufferedReader output;
            final BufferedWriter input;

            Worker(Process process) {
                this.process = process;
                this.output = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8));
                this.input = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            }
        }
    }

    /** Outer empty = tool cannot launch; inner empty = user cancelled. */
    private static Optional<Optional<Path>> tryNativePicker(List<String> command) throws InterruptedException {
        Process process;
        try { process = new ProcessBuilder(command).redirectErrorStream(true).start(); }
        catch (java.io.IOException | SecurityException ex) { return Optional.empty(); }
        try {
            if (!process.waitFor(90, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return Optional.empty();
            }
            String result = new String(process.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            if (process.exitValue() != 0) {
                if (result.toLowerCase(Locale.ROOT).contains("user canceled")
                        || result.toLowerCase(Locale.ROOT).contains("user cancelled")
                        || process.exitValue() == 1 && (command.get(0).equals("zenity") || command.get(0).equals("kdialog"))) {
                    return Optional.of(Optional.empty());
                }
                LOG.warning("Native folder picker exited with status " + process.exitValue());
                return Optional.empty();
            }
            if (result.isBlank()) return Optional.of(Optional.empty());
            return Optional.of(Optional.of(Path.of(result).toAbsolutePath().normalize()));
        } catch (java.io.IOException | IllegalArgumentException ex) {
            return Optional.empty();
        } finally {
            if (process.isAlive()) process.destroyForcibly();
        }
    }
}
