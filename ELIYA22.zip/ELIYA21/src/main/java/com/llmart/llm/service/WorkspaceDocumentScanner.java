package com.llmart.llm.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.tika.Tika;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFPicture;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import java.awt.Graphics2D;
import java.awt.Color;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Zero-LLM document inventory. Keeps text and visual evidence together with a stable source locator.
 * Native Office/PDF file uploads are not assumed to be supported by arbitrary OpenAI-compatible gateways;
 * this scanner creates a compatible representation instead. Never follows symlinks or extracts ZIP paths.
 */
@Service
public class WorkspaceDocumentScanner {
    private static final int MAX_VISUALS = 60;
    private static final long MAX_IMAGE_BYTES = 10L * 1024 * 1024;
    private static final int MAX_TEXT = 600_000;
    private final Tika tika = new Tika();

    public WorkspaceDocumentScanner() { tika.setMaxStringLength(MAX_TEXT + 1); }

    public Scan scan(Path source) throws IOException {
        if (source == null || !Files.isRegularFile(source) || Files.isSymbolicLink(source))
            throw new IOException("Document must be an existing, non-symlink file");
        String name = source.getFileName().toString().toLowerCase(Locale.ROOT);
        List<Visual> visuals = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        String text = "";
        StringBuilder textBuilder = new StringBuilder();
        int detected = 0;
        if (name.endsWith(".pdf")) {
            try (PDDocument pdf = PDDocument.load(source.toFile())) {
                if (pdf.isEncrypted()) throw new IOException("Encrypted PDF requires manual decryption");
                PDFTextStripper stripper = new PDFTextStripper();
                PDFRenderer renderer = new PDFRenderer(pdf);
                for (int page = 1; page <= pdf.getNumberOfPages(); page++) {
                    stripper.setStartPage(page);
                    stripper.setEndPage(page);
                    String pageText = stripper.getText(pdf);
                    textBuilder.append("\n[PDF PAGE ").append(page).append("]\n").append(pageText);
                    // Text-only PDFs do not require the vision model. Raster/scanned/vector pages do.
                    if (!containsVisualEvidence(pdf.getPage(page - 1), pageText)) continue;
                    detected++;
                    if (visuals.size() < MAX_VISUALS) {
                        try {
                            BufferedImage image = renderer.renderImageWithDPI(page - 1, 100);
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            ImageIO.write(image, "png", out);
                            visuals.add(new Visual("page-" + page, "image/png", out.toByteArray(),
                                    "PDF page " + page + " text: " + clip(pageText, 2600)));
                            image.flush();
                        } catch (RuntimeException | IOException e) {
                            warnings.add("PDF page " + page + " rendering failed: " + e.getClass().getSimpleName());
                        }
                    }
                }
                text = textBuilder.toString();
            }
        } else if (isOffice(name)) {
            try {
                text = tika.parseToString(source.toFile());
            } catch (Exception ex) {
                warnings.add("Office text extraction failed: " + ex.getClass().getSimpleName());
            }
            // A PowerPoint slide can contain diagrams, connectors, vectors or flowcharts WITHOUT
            // embedded image media. Render the slide as a whole to preserve its visual relationships.
            if (name.endsWith(".pptx")) {
                try (var in = Files.newInputStream(source); XMLSlideShow deck = new XMLSlideShow(in)) {
                    int page = 0;
                    java.awt.Dimension size = deck.getPageSize();
                    double scale = Math.min(1.8, 1500d / Math.max(1, Math.max(size.width, size.height)));
                    for (XSLFSlide slide : deck.getSlides()) {
                        page++; detected++;
                        if (visuals.size() >= MAX_VISUALS) continue;
                        BufferedImage rendered = new BufferedImage(Math.max(1, (int)(size.width*scale)),
                                Math.max(1, (int)(size.height*scale)), BufferedImage.TYPE_INT_RGB);
                        Graphics2D graphics = rendered.createGraphics();
                        try {
                            graphics.setColor(Color.WHITE); graphics.fillRect(0, 0, rendered.getWidth(), rendered.getHeight());
                            graphics.scale(scale, scale);
                            slide.draw(graphics);
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            ImageIO.write(rendered, "png", out);
                            visuals.add(new Visual("slide-" + page, "image/png", out.toByteArray(),
                                    "PowerPoint slide " + page + ". Correlate diagram with original extracted slide text."));
                        } catch (Exception failure) {
                            warnings.add("PowerPoint slide " + page + " rendering failed: " + failure.getMessage());
                        } finally { graphics.dispose(); rendered.flush(); }
                    }
                } catch (Exception failure) { warnings.add("Unable to render PowerPoint slides: " + failure.getMessage()); detected++; }
            } else {
            Map<String,String> docxContexts = name.endsWith(".docx") ? wordImageContexts(source) : Map.of();
            String folder = name.endsWith(".docx") ? "word/media/" : "xl/media/";
            try (ZipFile zip = new ZipFile(source.toFile())) {
                Enumeration<? extends ZipEntry> entries = zip.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry entry = entries.nextElement();
                    // Chart XML encodes shapes/graphs not present in the media directory. Do not
                    // claim complete visual coverage of a chart without a compatible renderer.
                    if (entry.getName().matches(name.endsWith(".docx") ? "word/charts/chart[^/]*\\.xml" : "xl/charts/chart[^/]*\\.xml")) {
                        detected++;
                        warnings.add("Chart XML requires separate rendering: " + entry.getName());
                        continue;
                    }
                    if (entry.isDirectory() || !entry.getName().startsWith(folder) ||
                            !isImage(entry.getName())) continue;
                    detected++;
                    if (visuals.size() >= MAX_VISUALS) continue;
                    if (entry.getSize() < 0 || entry.getSize() > MAX_IMAGE_BYTES) {
                        warnings.add("Image skipped due to unknown/excessive size: " + entry.getName());
                        continue;
                    }
                    byte[] bytes;
                    try (var in = zip.getInputStream(entry)) {
                        bytes = in.readNBytes((int) MAX_IMAGE_BYTES + 1);
                    }
                    if (bytes.length > MAX_IMAGE_BYTES) {
                        warnings.add("Image exceeds limit: " + entry.getName());
                        continue;
                    }
                    String locator = entry.getName();
                    String association = docxContexts.getOrDefault(Path.of(locator).getFileName().toString(),
                            "Location unknown; cross-reference full document text");
                    visuals.add(new Visual(locator, mime(locator), bytes,
                            "Embedded image in " + source.getFileName() + ". Nearby text: " + association));
                }
            } catch (IOException e) {
                warnings.add("Embedded image inventory failed: " + e.getMessage());
            }
            } // Word/Excel media inspection branch
        } else if (isImage(name)) {
            detected = 1;
            if (Files.size(source) <= MAX_IMAGE_BYTES) {
                visuals.add(new Visual(source.getFileName().toString(), mime(name), Files.readAllBytes(source),
                        "Image document: " + source.getFileName()));
            } else warnings.add("Image exceeds 10 MB limit");
        } else {
            try { text = tika.parseToString(source.toFile()); }
            catch (Exception e) { throw new IOException("Unable to read document " + source.getFileName(), e); }
        }
        if (text.length() > MAX_TEXT) {
            warnings.add("Text exceeds 600,000 characters; text was truncated. Analyse smaller sections for full coverage.");
            text = text.substring(0, MAX_TEXT);
        }
        if (detected > visuals.size()) warnings.add("Visual coverage incomplete: " + visuals.size() + "/" + detected +
                " prepared. Split the document or raise configured limits before claiming full coverage.");
        return new Scan(text, detected, List.copyOf(visuals), List.copyOf(warnings));
    }

    private static boolean containsVisualEvidence(PDPage page, String pageText) {
        if (pageText == null || pageText.isBlank()) return true; // scanned/outlined page
        try {
            if (page.getResources() != null) {
                for (var x : page.getResources().getXObjectNames())
                    if (page.getResources().getXObject(x) instanceof PDImageXObject) return true;
            }
            // Some diagrams are PDF vector paths, not embedded raster pictures.
            PDFStreamParser parser = new PDFStreamParser(page);
            parser.parse();
            int drawnPaths = 0;
            for (Object token : parser.getTokens()) {
                if (token instanceof Operator operator &&
                        Set.of("m", "l", "c", "re", "v", "y").contains(operator.getName()) && ++drawnPaths > 3)
                    return true;
            }
        } catch (Exception ignored) { return true; } // uncertain: safe visual path
        return false;
    }

    private static Map<String,String> wordImageContexts(Path file) {
        Map<String,String> references = new HashMap<>();
        try (var in = Files.newInputStream(file); XWPFDocument doc = new XWPFDocument(in)) {
            String previous = "";
            int paragraph = 0;
            for (XWPFParagraph p : doc.getParagraphs()) {
                paragraph++;
                String context = "paragraph " + paragraph + "; preceding: " + clip(previous, 900) +
                        "; accompanying: " + clip(p.getText(), 900);
                for (XWPFRun run : p.getRuns()) {
                    for (XWPFPicture picture : run.getEmbeddedPictures()) {
                        if (picture.getPictureData() != null)
                            references.putIfAbsent(picture.getPictureData().getFileName(), context);
                    }
                }
                if (!p.getText().isBlank()) previous = p.getText();
            }
        } catch (Exception ignored) { /* non-standard DOCX may still expose ZIP media */ }
        return references;
    }

    public static boolean isDocument(Path path) {
        if (path == null || path.getFileName() == null) return false;
        String value = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return isOffice(value) || value.endsWith(".pdf") || value.endsWith(".txt") ||
                value.endsWith(".md") || value.endsWith(".html") || value.endsWith(".htm") || isImage(value);
    }
    private static boolean isOffice(String s) {
        return s.endsWith(".docx") || s.endsWith(".xlsx") || s.endsWith(".pptx");
    }
    private static boolean isImage(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") ||
                n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp");
    }
    private static String mime(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        return "image/png";
    }
    private static String clip(String s, int length) { return s == null ? "" : s.substring(0, Math.min(length, s.length())); }
    public record Visual(String locator, String mimeType, byte[] bytes, String context) { }
    public record Scan(String text, int detectedVisuals, List<Visual> visuals, List<String> warnings) { }
}
