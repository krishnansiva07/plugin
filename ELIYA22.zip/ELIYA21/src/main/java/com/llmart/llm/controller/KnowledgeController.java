package com.llmart.llm.controller;

import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.service.WorkspaceKnowledgeService;
import jakarta.annotation.PreDestroy;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;

/** Local, workspace-scoped index inspection and explicit background indexing. No credentials are persisted. */
@RestController
@RequestMapping("/api/knowledge")
public class KnowledgeController {
    private final WorkspaceKnowledgeService knowledge;
    private final ProjectService projects;
    private final ExecutorService pool = Executors.newFixedThreadPool(2, runnable -> {
        Thread thread = new Thread(runnable, "eliya-knowledge-index"); thread.setDaemon(true); return thread;
    });
    private final Map<String, Job> jobs = new ConcurrentHashMap<>();

    public KnowledgeController(WorkspaceKnowledgeService knowledge, ProjectService projects) {
        this.knowledge = knowledge; this.projects = projects;
    }
    public record IndexRequest(String projectId, String objective, ChatSettings settings) {}
    private static final class Job {
        volatile String phase = "queued", detail = "Waiting for indexing worker";
        volatile WorkspaceKnowledgeService.Summary summary;
    }
    private Path root(String id) {
        var project = projects.require(id);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("A local workspace is required for local knowledge indexing");
        return Path.of(project.getLocalPath()).toAbsolutePath().normalize();
    }
    @PostMapping("/analyse")
    public Map<String, String> analyse(@RequestHeader(value = "Authorization", required = false) String authorization,
                                       @RequestBody IndexRequest body) {
        if (body == null || body.settings() == null) throw new IllegalArgumentException("Model settings required");
        Path root = root(body.projectId());
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : "";
        String jobId = UUID.randomUUID().toString();
        Job job = new Job();
        jobs.put(jobId, job);
        pool.execute(() -> {
            try {
                job.phase = "running";
                job.summary = knowledge.analyse(root, key, body.settings(), body.objective(), msg -> job.detail = msg);
                job.phase = job.summary.incomplete() > 0 ? "partial" : "completed";
                job.detail = "Indexed " + job.summary.indexed() + " documents, analysed " +
                        job.summary.analysedVisuals() + "/" + job.summary.detectedVisuals() + " visuals";
            } catch (Exception failure) {
                job.phase = "failed";
                job.detail = failure.getMessage() == null ? "Indexing failed" : failure.getMessage();
            }
        });
        return Map.of("jobId", jobId);
    }
    @GetMapping("/jobs/{id}")
    public Map<String,Object> status(@PathVariable String id) {
        Job job = jobs.get(id);
        if (job == null) throw new NoSuchElementException("Knowledge indexing job not found");
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("phase", job.phase);
        result.put("detail", job.detail);
        if (job.summary != null) result.put("summary", job.summary);
        return result;
    }
    @GetMapping("/documents")
    public List<Map<String,Object>> documents(@RequestParam String projectId) {
        return knowledge.documents(root(projectId)).stream().map(doc -> {
            Map<String,Object> meta = new LinkedHashMap<>();
            meta.put("source", doc.source());
            meta.put("status", doc.status());
            meta.put("detectedVisuals", doc.detectedVisuals());
            meta.put("analysedVisuals", doc.analysedVisuals());
            meta.put("indexedAt", doc.indexedAt());
            meta.put("warnings", doc.warnings());
            return meta;
        }).toList();
    }
    @GetMapping("/search")
    public Map<String,String> search(@RequestParam String projectId, @RequestParam String query) {
        return Map.of("evidence", knowledge.retrieve(root(projectId), query, 16000));
    }
    @DeleteMapping("/clear")
    public Map<String,Boolean> clear(@RequestParam String projectId) throws Exception {
        knowledge.clear(root(projectId));
        return Map.of("cleared", true);
    }
    @PreDestroy public void close() { pool.shutdownNow(); }
}
