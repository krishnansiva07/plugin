package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Lightweight MCP tool loop for Chat mode.
 *
 * Chat remains a conversational surface: ordinary prompts still use the existing streaming path.
 * When a prompt clearly asks for Jira/Confluence/GitLab/SonarQube/MCP data, this service gives the
 * selected Chat model read-only MCP tools, lets it retrieve the evidence it needs, and then returns
 * a normal assistant answer. Mutating MCP tools are deliberately not exposed from Chat; external
 * write actions stay in Agent mode where the existing MCP permission/approval flow is available.
 */
@Service
public class ChatMcpService {
    private static final Pattern ISSUE_KEY = Pattern.compile("(?i)(?:^|\\b)[A-Z][A-Z0-9]{1,15}-\\d+(?:\\b|$)");
    private static final Pattern TRACKER_NOUN = Pattern.compile(
            "(?i)\\b(?:tickets?|issues?|stories|story|bugs?|epics?|sprints?|backlogs?|boards?)\\b");
    private static final Pattern TRACKER_QUERY = Pattern.compile(
            "(?i)\\b(?:recent|latest|current|open|closed|updated|assigned|unresolved|resolved|" +
            "pending|show|list|find|fetch|retrieve|search|status|details|what|which|how many)\\b");
    private static final Set<String> MCP_HINTS = Set.of(
            "mcp", "jira", "confluence", "gitlab", "sonarqube", "atlassian",
            "jira issue", "jira story", "confluence page", "space key", "quality gate");
    private static final Pattern LOCAL_IMPLEMENTATION = Pattern.compile(
            "(?i)\\b(?:how|where|why|explain|describe|trace|show|review|find)\\b.{0,110}\\b" +
            "(?:implemented|implementation|coded|codebase|source code|class|method|function|configured|configuration|integration|works internally)\\b");
    private static final int MAX_TURNS = 7;
    private static final int MAX_TOOL_CALLS = 16;

    private final OpenAiCompatibleClient llm;
    private final McpManager mcp;
    private final ObjectMapper mapper;

    public ChatMcpService(OpenAiCompatibleClient llm, McpManager mcp, ObjectMapper mapper) {
        this.llm = llm;
        this.mcp = mcp;
        this.mapper = mapper;
    }

    /** Route on the user's ORIGINAL request; never on retrieved source, attachments or model context. */
    public boolean shouldHandle(String prompt) {
        if (prompt == null || prompt.isBlank()) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        // Asking how an integration is implemented is a local code question, not a live external lookup.
        if (LOCAL_IMPLEMENTATION.matcher(prompt).find()
                && !low.matches("(?s).*(?:compare|against|latest|live|current|fetch|retrieve|search (?:in|on|from)|from (?:jira|confluence|gitlab|sonarqube)).*")) return false;
        if (ISSUE_KEY.matcher(prompt).find()) return true;
        for (String hint : MCP_HINTS) if (containsPhrase(low, hint)) return true;
        return TRACKER_NOUN.matcher(prompt).find() && TRACKER_QUERY.matcher(prompt).find()
                || (containsPhrase(low, "merge request") || containsPhrase(low, "pull request"))
                && low.matches("(?s).*(?:fetch|retrieve|search|list|open|latest|recent|current|status|assigned|comments|details).*");
    }

    private boolean containsPhrase(String text, String phrase) {
        return Pattern.compile("(?<![a-z0-9])" + Pattern.quote(phrase) + "(?![a-z0-9])").matcher(text).find();
    }

    public Optional<String> answer(String apiKey, ChatRequest request, String originalPrompt,
                                   List<Map<String,Object>> baseContext, BooleanSupplier cancelled,
                                   Consumer<McpActivity> activity, Consumer<String> onToken) throws Exception {
        String prompt = originalPrompt == null ? "" : originalPrompt;
        if (!shouldHandle(prompt)) return Optional.empty();
        if (mcp.configuredServerNames(null).isEmpty()) {
            String message = "No MCP server is enabled for Chat. Enable and test your Jira/DevOps " +
                    "MCP connection in ELIYA Settings, then retry. No live tickets were retrieved.";
            progress(activity, "mcp", "error", message);
            if (onToken != null) onToken.accept(message);
            return Optional.of(message);
        }
        progress(activity, "mcp", "discovering", "Discovering available MCP read tools…");
        McpManager.Catalog fullCatalog = mcp.catalogCachedForChat();
        List<Map<String,Object>> tools = selectTools(fullCatalog, prompt);
        Set<String> allowed = new LinkedHashSet<>();
        for (Map<String,Object> def : tools) allowed.add(functionName(def));
        progress(activity, "mcp", "ready", "MCP discovered " + fullCatalog.definitions().size() +
                " tools; " + tools.size() + " read-only tools available for this request.");

        // A configured MCP endpoint that cannot expose any safe read tools should not silently make Chat hallucinate.
        if (tools.isEmpty()) {
            String detail = fullCatalog.diagnostics().isEmpty()
                    ? "No read-only MCP tools were discovered."
                    : String.join("; ", fullCatalog.diagnostics());
            String message = "I couldn't retrieve the requested external data in Chat mode. " + detail +
                    " Chat intentionally exposes only read/search MCP operations; use Agent mode for external write actions.";
            if (onToken != null) onToken.accept(message);
            return Optional.of(message);
        }

        List<Map<String,Object>> messages = copyMessages(baseContext);
        insertMcpInstructions(messages, fullCatalog.diagnostics());
        String model = request.settings().chatModelOrPrimary();
        Map<String,Integer> repeated = new HashMap<>();
        int forcedEvidenceTurns = 0;
        int toolCalls = 0;
        boolean retrievedEvidence = false;
        List<String> failures = new ArrayList<>();

        for (int turnNumber = 0; turnNumber < MAX_TURNS; turnNumber++) {
            if (cancelled != null && cancelled.getAsBoolean()) throw new AgentCancelledException("Chat MCP request cancelled");
            progress(activity, "mcp", "thinking", "Choosing the relevant external information…");
            OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(
                    apiKey, request.settings().baseUrl(), model, request.settings().safeMaxTokens(),
                    messages, tools, false, cancelled == null ? () -> false : cancelled);

            String raw = turn.content() == null ? "" : turn.content().trim();
            if (turn.hasToolCall()) {
                appendNativeAssistant(messages, turn.toolCalls(), raw);
                for (OpenAiCompatibleClient.AgentToolCall call : turn.toolCalls()) {
                    String name = call.name() == null ? "" : call.name().trim();
                    String result = ++toolCalls > MAX_TOOL_CALLS ? "MCP tool budget reached. Answer from existing evidence."
                            : executeReadTool(fullCatalog, allowed, name, call.arguments(), prompt, cancelled, repeated, activity);
                    if (toolCalls <= MAX_TOOL_CALLS && !isFailedRead(result)) retrievedEvidence = true;
                    else if (isFailedRead(result) && failures.size() < 3) failures.add(clip(safe(result), 450));
                    appendNativeToolResult(messages, call.id(), name, result);
                }
                if (retrievedEvidence) return Optional.of(streamFinal(apiKey, request, messages, cancelled, activity, onToken));
                continue;
            }

            JsonNode envelope = parseEnvelope(raw);
            if (envelope != null && envelope.isObject()) {
                String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                if ("tool".equals(type)) {
                    String name = envelope.path("tool").asText("").trim();
                    String result = ++toolCalls > MAX_TOOL_CALLS ? "MCP tool budget reached. Answer from existing evidence."
                            : executeReadTool(fullCatalog, allowed, name, envelope.path("args"), prompt, cancelled, repeated, activity);
                    if (toolCalls <= MAX_TOOL_CALLS && !isFailedRead(result)) retrievedEvidence = true;
                    else if (isFailedRead(result) && failures.size() < 3) failures.add(clip(safe(result), 450));
                    appendFallbackToolTranscript(messages, raw, name, result);
                    if (retrievedEvidence) return Optional.of(streamFinal(apiKey, request, messages, cancelled, activity, onToken));
                    continue;
                }
                if ("tools".equals(type) && envelope.path("calls").isArray()) {
                    List<String> results = new ArrayList<>();
                    int count = 0;
                    for (JsonNode node : envelope.path("calls")) {
                        if (++count > 8) break;
                        String name = node.path("tool").asText("").trim();
                        String result = ++toolCalls > MAX_TOOL_CALLS ? "MCP tool budget reached. Answer from existing evidence."
                                : executeReadTool(fullCatalog, allowed, name, node.path("args"), prompt, cancelled, repeated, activity);
                        if (toolCalls <= MAX_TOOL_CALLS && !isFailedRead(result)) retrievedEvidence = true;
                        else if (isFailedRead(result) && failures.size() < 3) failures.add(clip(safe(result), 450));
                        results.add("TOOL RESULT for " + name + ":\n" + clip(result, 24_000));
                    }
                    if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
                    messages.add(Map.of("role", "user", "content", String.join("\n\n", results) +
                            "\n\nContinue the user's request. Use another MCP read tool if needed, otherwise answer normally."));
                    if (retrievedEvidence) return Optional.of(streamFinal(apiKey, request, messages, cancelled, activity, onToken));
                    continue;
                }
                if ("final".equals(type)) {
                    String message = envelope.path("message").asText("").trim();
                    if (!message.isBlank() && retrievedEvidence) { if (onToken != null) onToken.accept(message); return Optional.of(message); }
                }
            }

            if (!raw.isBlank()) {
                // If the user explicitly requested live external evidence but the model answered without touching MCP,
                // give it one bounded corrective opportunity before returning prose.
                if (!retrievedEvidence && forcedEvidenceTurns < 1 && clearlyRequiresRetrievedEvidence(prompt)) {
                    forcedEvidenceTurns++;
                    messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
                    messages.add(Map.of("role", "user", "content",
                            "Use an available MCP read/search tool now to ground the answer in the requested Jira/Confluence/DevOps source. Do not answer from memory. After retrieving evidence, answer the original request."));
                    continue;
                }
                if (!retrievedEvidence && clearlyRequiresRetrievedEvidence(prompt)) {
                    String warning = "No verified Jira/DevOps data was retrieved. " +
                            (failures.isEmpty() ? "The Chat model did not use an available read tool. Check that the selected Chat model supports tool calling."
                                    : "MCP returned: " + String.join("; ", failures));
                    progress(activity, "mcp", "error", warning);
                    if (onToken != null) onToken.accept(warning);
                    return Optional.of(warning);
                }
                if (onToken != null) onToken.accept(raw);
                return Optional.of(raw);
            }

            String message = "The Chat model returned no usable response after MCP processing.";
            if (onToken != null) onToken.accept(message);
            return Optional.of(message);
        }
        String warning = "MCP could not complete the request within the safe tool limit. " +
                (failures.isEmpty() ? "Try a narrower request or check the Chat model's tool support."
                        : "Errors: " + String.join("; ", failures));
        progress(activity, "mcp", "error", warning);
        if (onToken != null) onToken.accept(warning);
        return Optional.of(warning);
    }

    private boolean isFailedRead(String result) {
        return result == null || result.startsWith("MCP TOOL ERROR") ||
                result.startsWith("MCP TOOL NOT AVAILABLE") || result.startsWith("REPEATED MCP CALL SUPPRESSED") ||
                result.startsWith("MCP PROTOCOL ERROR") || result.startsWith("MCP tool budget reached") ||
                result.contains("isError=true") || JiraJqlRecovery.isSyntaxFailure(result);
    }

    private String streamFinal(String apiKey, ChatRequest request, List<Map<String,Object>> messages,
                               BooleanSupplier cancelled, Consumer<McpActivity> activity,
                               Consumer<String> onToken) throws Exception {
        progress(activity, "mcp", "generating", "External data received. Generating the answer…");
        // A separate non-tool streaming completion avoids the unbounded non-streaming MCP final loop.
        // Keep the original question and retrieved tool evidence; do not permit writes or invented follow-up reads.
        List<Map<String,Object>> finalContext = copyMessages(messages);
        finalContext.add(Map.of("role", "user", "content",
                "Answer the original user request using the external MCP evidence already obtained. " +
                "Do not invent facts or issue additional tool calls. State clearly if more evidence is needed."));
        return llm.stream(apiKey, request.settings(), finalContext,
                onToken == null ? token -> {} : onToken, cancelled == null ? () -> false : cancelled);
    }

    private void progress(Consumer<McpActivity> activity, String name, String status, String message) {
        if (activity != null) activity.accept(new McpActivity(name, status, message));
    }

    private List<Map<String,Object>> selectTools(McpManager.Catalog catalog, String prompt) {
        String low = prompt.toLowerCase(Locale.ROOT);
        Set<String> providers = new LinkedHashSet<>();
        for (String provider : List.of("jira", "confluence", "gitlab", "sonarqube", "sonar", "atlassian"))
            if (containsPhrase(low, provider)) providers.add(provider);
        // Generic ticket requests are Jira queries even if the user does not write "Jira".
        if (TRACKER_NOUN.matcher(prompt).find() && TRACKER_QUERY.matcher(prompt).find()) providers.add("jira");
        for (String serverName : mcp.configuredServerNames(null))
            if (containsPhrase(low, serverName.toLowerCase(Locale.ROOT))) providers.add(serverName.toLowerCase(Locale.ROOT));
        List<Map<String,Object>> safe = new ArrayList<>();
        List<Map<String,Object>> matched = new ArrayList<>();
        for (Map<String,Object> def : catalog.definitions()) {
            String name = functionName(def);
            if (name.isBlank() || !mcp.isChatReadOnly(catalog, name)) continue;
            safe.add(def);
            String detail = String.valueOf(def.get("function")).toLowerCase(Locale.ROOT);
            if (providers.stream().anyMatch(provider -> detail.contains(provider))) matched.add(def);
        }
        List<Map<String,Object>> candidates = new ArrayList<>(matched.isEmpty() ? safe : matched);
        boolean collectionQuery = TRACKER_NOUN.matcher(prompt).find() && TRACKER_QUERY.matcher(prompt).find()
                && !ISSUE_KEY.matcher(prompt).find();
        // The first 24 definitions are exposed to the model. Prefer Jira search/list tools for
        // requests such as "recent tickets" rather than dropping them behind unrelated read tools.
        candidates.sort(Comparator.comparingInt(def -> toolPriority(def, collectionQuery)));
        return List.copyOf(candidates.subList(0, Math.min(candidates.size(), 24)));
    }

    private int toolPriority(Map<String,Object> definition, boolean collectionQuery) {
        String name = functionName(definition).toLowerCase(Locale.ROOT);
        String detail = String.valueOf(definition.get("function")).toLowerCase(Locale.ROOT);
        if (collectionQuery) {
            if (name.matches(".*(?:search|list|query|find).*")) return 0;
            if (detail.matches("(?s).*(?:search|list|query|find).*")) return 1;
            if (name.matches(".*(?:get|fetch|read).*")) return 2;
        }
        return 3;
    }

    private String executeReadTool(McpManager.Catalog catalog, Set<String> allowed, String name, JsonNode args,
                                   String originalPrompt, BooleanSupplier cancelled, Map<String,Integer> repeated,
                                   Consumer<McpActivity> activity) {
        if (name == null || name.isBlank() || !allowed.contains(name)) {
            return "MCP TOOL NOT AVAILABLE IN CHAT: " + (name == null ? "" : name) +
                    ". Chat exposes read/search MCP operations only. Use Agent mode for mutating external actions.";
        }
        String fingerprint = name + "|" + canonicalArgs(args);
        int count = repeated.merge(fingerprint, 1, Integer::sum);
        if (count > 3) return "REPEATED MCP CALL SUPPRESSED: choose a different query/tool or answer from the evidence already retrieved.";
        try {
            if (activity != null) activity.accept(new McpActivity(name, "running", "Reading external data with " + name + "…"));
            // Bound each Chat read independently of an MCP server's (possibly much longer) configured timeout.
            long started = System.nanoTime();
            long limitMillis = Math.max(2_000L, Math.min(120_000L,
                    Long.getLong("eliya.chat.mcp.toolTimeoutMillis", 25_000L)));
            BooleanSupplier bounded = () -> (cancelled != null && cancelled.getAsBoolean()) ||
                    System.nanoTime() - started >= java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(limitMillis);
            JsonNode normalized = repairJiraSearch(catalog, name, args, originalPrompt, true);
            if (normalized != null && !canonicalArgs(normalized).equals(canonicalArgs(args))) {
                progress(activity, name, "preparing", "Converting the Jira search request into JQL…");
                args = normalized;
            }
            String result = mcp.call(null, catalog, name, args, bounded);
            if (JiraJqlRecovery.isSyntaxFailure(result) && !bounded.getAsBoolean()) {
                JsonNode repair = repairJiraSearch(catalog, name, args, originalPrompt, false);
                if (repair != null && !canonicalArgs(repair).equals(canonicalArgs(args))) {
                    progress(activity, name, "retrying", "Jira rejected the search syntax; retrying once with simpler JQL…");
                    String repairedResult = mcp.call(null, catalog, name, repair, bounded);
                    result = isFailedRead(repairedResult)
                            ? "MCP TOOL ERROR: Jira search failed after one JQL correction. " + clip(safe(repairedResult), 1200)
                            : repairedResult;
                }
            }
            if (activity != null) activity.accept(new McpActivity(name, isFailedRead(result) ? "error" : "success", summarize(result)));
            return clip(result, 32_000);
        } catch (AgentCancelledException cancelledException) {
            if (cancelled != null && cancelled.getAsBoolean()) throw cancelledException;
            String result = "MCP TOOL ERROR: Chat read timed out; narrow the query or check the external server.";
            progress(activity, name, "error", result);
            return result;
        } catch (Exception e) {
            String result = "MCP TOOL ERROR: " + safe(e.getMessage());
            if (activity != null) activity.accept(new McpActivity(name, "error", result));
            return result;
        }
    }

    /** Only rewrite an input field explicitly declared as JQL by this Jira MCP tool's schema. */
    private JsonNode repairJiraSearch(McpManager.Catalog catalog, String toolName, JsonNode args,
                                      String originalPrompt, boolean onlyNaturalLanguage) {
        if (args == null || !args.isObject()) return null;
        for (Map<String,Object> definition : catalog.definitions()) {
            if (!toolName.equals(functionName(definition))) continue;
            Object raw = definition.get("function");
            if (!(raw instanceof Map<?,?> fn)) return null;
            // Some corporate MCP gateways use a generic server/tool name. The
            // discovered JQL input field is a safer indicator than naming alone.
            if (!(fn.get("parameters") instanceof Map<?,?> schema) ||
                    !(schema.get("properties") instanceof Map<?,?> properties)) return null;
            for (Map.Entry<?,?> entry : properties.entrySet()) {
                String field = String.valueOf(entry.getKey());
                String lower = field.toLowerCase(Locale.ROOT);
                String description = entry.getValue() instanceof Map<?,?> property
                        ? String.valueOf(property.get("description")).toLowerCase(Locale.ROOT) : "";
                boolean jqlField = lower.equals("jql") || lower.equals("jqlquery") || lower.equals("jql_query") ||
                        ((lower.equals("query") || lower.equals("searchquery") || lower.equals("search_query"))
                                && description.contains("jql"));
                if (!jqlField) continue;
                if (onlyNaturalLanguage && !JiraJqlRecovery.looksLikeNaturalLanguage(args.path(field).asText("")))
                    return null;
                ObjectNode fixed = ((ObjectNode) args).deepCopy();
                fixed.put(field, JiraJqlRecovery.simpleJql(originalPrompt));
                return fixed;
            }
            return null;
        }
        return null;
    }

    private void insertMcpInstructions(List<Map<String,Object>> messages, List<String> diagnostics) {
        String diag = diagnostics == null || diagnostics.isEmpty() ? "" : "\nMCP status: " + String.join("; ", diagnostics);
        String protocol = """
                CHAT MCP MODE
                - The user is asking for external DevOps information. Use the available MCP read/search tools whenever Jira, Confluence, GitLab, SonarQube or another configured MCP source is needed.
                - Do not invent issue/page contents, comments, statuses, acceptance criteria or search results. Retrieve them first.
                - Chat mode is read/analysis only for MCP. Mutating external actions are intentionally not available here; tell the user to use Agent mode if a write/update action is requested.
                - Retrieve only the evidence required for the question. Do not dump whole projects/spaces into context.
                - Jira search tools requiring JQL must receive valid JQL, NOT a natural-language sentence. Example for a named project: project = BMSA ORDER BY updated DESC. If no project was specified, use updated >= -30d ORDER BY updated DESC. Respect each MCP tool's discovered input schema.
                - After tool use, answer normally in concise Markdown.
                - Compatibility fallback when native tool calling is unavailable: return exactly one JSON object: {\"type\":\"tool\",\"tool\":\"exact_tool_name\",\"args\":{...}}. For multiple independent reads use {\"type\":\"tools\",\"calls\":[...]}. When done, return normal prose or {\"type\":\"final\",\"message\":\"...\"}.
                """ + diag;
        int insert = !messages.isEmpty() && "system".equals(String.valueOf(messages.get(0).get("role"))) ? 1 : 0;
        messages.add(insert, Map.of("role", "system", "content", protocol));
    }

    private List<Map<String,Object>> copyMessages(List<Map<String,Object>> source) {
        List<Map<String,Object>> out = new ArrayList<>();
        if (source != null) for (Map<String,Object> message : source) out.add(new LinkedHashMap<>(message));
        return out;
    }

    private String latestUserText(List<Map<String,Object>> messages) {
        if (messages == null) return "";
        for (int i = messages.size() - 1; i >= 0; i--) {
            Map<String,Object> message = messages.get(i);
            if (!"user".equals(String.valueOf(message.get("role")))) continue;
            Object content = message.get("content");
            if (content instanceof String text) return text;
            if (content instanceof List<?> parts) {
                StringBuilder out = new StringBuilder();
                for (Object part : parts) {
                    if (part instanceof Map<?,?> map && "text".equals(String.valueOf(map.get("type")))) {
                        Object value = map.get("text");
                        if (value != null) out.append(value).append('\n');
                    }
                }
                return out.toString();
            }
        }
        return "";
    }

    private boolean clearlyRequiresRetrievedEvidence(String prompt) {
        if (prompt == null) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        return ISSUE_KEY.matcher(prompt).find() || low.contains("jira") || low.contains("confluence") ||
                low.contains("gitlab") || low.contains("sonarqube") || low.contains("mcp") ||
                low.contains("acceptance criteria") || TRACKER_NOUN.matcher(prompt).find();
    }

    private String functionName(Map<String,Object> definition) {
        if (definition == null) return "";
        Object fn = definition.get("function");
        if (!(fn instanceof Map<?,?> map)) return "";
        Object name = map.get("name");
        return name == null ? "" : String.valueOf(name).trim();
    }

    private void appendNativeAssistant(List<Map<String,Object>> messages,
                                       List<OpenAiCompatibleClient.AgentToolCall> calls, String content) {
        List<Map<String,Object>> toolCalls = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            Map<String,Object> fn = new LinkedHashMap<>();
            fn.put("name", call.name());
            try { fn.put("arguments", mapper.writeValueAsString(call.arguments())); }
            catch (Exception ignored) { fn.put("arguments", "{}"); }
            Map<String,Object> item = new LinkedHashMap<>();
            item.put("id", call.id());
            item.put("type", "function");
            item.put("function", fn);
            toolCalls.add(item);
        }
        Map<String,Object> assistant = new LinkedHashMap<>();
        assistant.put("role", "assistant");
        if (content != null && !content.isBlank()) assistant.put("content", clip(content, 12_000));
        assistant.put("tool_calls", toolCalls);
        messages.add(assistant);
    }

    private void appendNativeToolResult(List<Map<String,Object>> messages, String id, String name, String result) {
        Map<String,Object> tool = new LinkedHashMap<>();
        tool.put("role", "tool");
        tool.put("tool_call_id", id == null ? "" : id);
        tool.put("name", name == null ? "" : name);
        tool.put("content", clip(result, 32_000));
        messages.add(tool);
    }

    private void appendFallbackToolTranscript(List<Map<String,Object>> messages, String raw, String tool, String result) {
        if (raw != null && !raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
        messages.add(Map.of("role", "user", "content", "TOOL RESULT for " + tool + ":\n" + clip(result, 32_000) +
                "\n\nContinue the original request. Use another MCP read tool if needed; otherwise answer normally."));
    }

    private JsonNode parseEnvelope(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        if (text.startsWith("```")) {
            int first = text.indexOf('\n');
            int last = text.lastIndexOf("```");
            if (first >= 0 && last > first) text = text.substring(first + 1, last).trim();
        }
        try { return mapper.readTree(text); } catch (Exception ignored) { return null; }
    }

    private String canonicalArgs(JsonNode args) {
        try { return mapper.writeValueAsString(args == null || args.isNull() ? mapper.createObjectNode() : args); }
        catch (Exception e) { return "{}"; }
    }

    private String summarize(String result) {
        if (result == null || result.isBlank()) return "MCP returned no content";
        String one = result.replaceAll("\\s+", " ").trim();
        return one.length() <= 240 ? one : one.substring(0, 240) + "…";
    }

    private String clip(String value, int max) {
        if (value == null) return "";
        if (value.length() <= max) return value;
        int head = Math.max(1, max * 2 / 3);
        int tail = Math.max(1, max - head - 40);
        return value.substring(0, head) + "\n...[MCP output clipped]...\n" + value.substring(value.length() - tail);
    }

    private String safe(String value) { return value == null || value.isBlank() ? "unknown error" : value.replaceAll("[\\r\\n]+", " ").trim(); }

    public record McpActivity(String tool, String status, String detail) {}
}
