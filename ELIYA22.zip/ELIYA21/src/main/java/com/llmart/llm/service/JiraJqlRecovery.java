package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, read-only fallback for Jira search tools that accept JQL.
 * Only used after an explicit JQL syntax failure; never retries authentication,
 * access-control, missing-project, or unrelated MCP errors.
 */
final class JiraJqlRecovery {
    private static final Pattern KEY = Pattern.compile("(?i)\\b([A-Z][A-Z0-9]{1,15}-[0-9]+)\\b");
    private static final Pattern PROJECT = Pattern.compile(
            "(?i)\\b(?:project(?:\\s+key)?\\s*(?:=|:|\\s)\\s*|(?:in|for|within)\\s+(?:project\\s+)?)([A-Z][A-Z0-9_]{1,15})\\b");
    private static final Pattern QUERY_FAILURE = Pattern.compile(
            "(?is)(?:\\bsyntax\\s+error\\b|\\bjql\\b.{0,100}\\b(?:syntax|parse|invalid|malformed)\\b|" +
            "\\b(?:syntax|parse|invalid|malformed)\\b.{0,100}\\bjql\\b|" +
            "\\b(?:search\\s+)?query\\s+(?:was\\s+)?rejected\\b|\\bexpecting\\s+(?:operator|keyword)\\b)");
    private static final Pattern AUTH_FAILURE = Pattern.compile(
            "(?is)(?:\\b(?:401|403|unauthori[sz]ed|forbidden|permission denied|access denied)\\b)");

    private JiraJqlRecovery() {}

    static boolean isSyntaxFailure(String result) {
        return result != null && !AUTH_FAILURE.matcher(result).find() && QUERY_FAILURE.matcher(result).find();
    }

    static boolean looksLikeNaturalLanguage(String candidate) {
        if (candidate == null || candidate.isBlank()) return true;
        String query = candidate.strip();
        // Preserve user/model-provided JQL filters rather than discarding them.
        if (query.matches("(?is).*(?:[=<>~!]|\\border\\s+by\\b|\\bis\\s+(?:not\\s+)?(?:empty|null)\\b).*"))
            return false;
        return query.matches("(?is)^(?:please|show|list|find|fetch|get|search|give|what|recent|latest|tickets?|issues?)\\b.*");
    }

    static String simpleJql(String prompt) {
        String text = prompt == null ? "" : prompt;
        Matcher key = KEY.matcher(text);
        if (key.find()) return "key = " + key.group(1).toUpperCase(Locale.ROOT);
        Matcher project = PROJECT.matcher(text);
        while (project.find()) {
            String value = project.group(1).toUpperCase(Locale.ROOT);
            if (!value.matches("JIRA|MCP|PROJECT|TICKET|TICKETS|ISSUE|ISSUES|THE|RECENT|LATEST|SEARCH|ALL|ME"))
                return "project = " + value + " ORDER BY updated DESC";
        }
        // Do not assume the previously discussed project when the user does not name one.
        return "updated >= -30d ORDER BY updated DESC";
    }
}
