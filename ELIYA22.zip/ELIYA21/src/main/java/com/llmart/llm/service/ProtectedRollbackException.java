package com.llmart.llm.service;

/** Fail closed when rollback is incomplete. The preserved snapshot requires explicit manual recovery. */
public class ProtectedRollbackException extends RuntimeException {
    public ProtectedRollbackException(String message, Throwable cause) { super(message, cause); }
}
