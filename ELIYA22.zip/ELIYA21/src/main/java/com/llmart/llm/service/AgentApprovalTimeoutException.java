package com.llmart.llm.service;

/** A security-significant approval timeout. Never hand it back to the executor as a recoverable tool error. */
public class AgentApprovalTimeoutException extends RuntimeException {
    public AgentApprovalTimeoutException(String message) { super(message); }
}
