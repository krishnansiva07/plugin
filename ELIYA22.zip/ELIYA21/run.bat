@echo off
setlocal
cd /d "%~dp0"
set JAR=target\eliya.jar
if not exist "%JAR%" (
  echo JAR not found. Building application...
  call mvnw.cmd clean package
  if errorlevel 1 exit /b 1
)
java -jar "%JAR%"
