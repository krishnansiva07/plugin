#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
mkdir -p "$DIR/src/com/llmart/llm/service" "$DIR/classes"
cp src/main/java/com/llmart/llm/service/JiraJqlRecovery.java "$DIR/src/com/llmart/llm/service/"
cat > "$DIR/src/com/llmart/llm/service/JiraJqlRecoverySmoke.java" <<'JAVA'
package com.llmart.llm.service;
public class JiraJqlRecoverySmoke {
 static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
 public static void main(String[] args){
  check(JiraJqlRecovery.simpleJql("List recent tickets in BMSA").equals("project = BMSA ORDER BY updated DESC"),"project scope");
  check(JiraJqlRecovery.simpleJql("List five latest Jira tickets from MCP").equals("updated >= -30d ORDER BY updated DESC"),"no invented project");
  check(JiraJqlRecovery.simpleJql("Show BMSA-104 from Jira").equals("key = BMSA-104"),"exact key");
  check(JiraJqlRecovery.simpleJql("recent tickets for project ABCD").equals("project = ABCD ORDER BY updated DESC"),"explicit project");
  check(JiraJqlRecovery.isSyntaxFailure("mcpServer=jira; isError=false\nSearch query rejected by Jira due to syntax error"),"wrapped syntax error");
  check(JiraJqlRecovery.isSyntaxFailure("JQL invalid: unexpected operator"),"JQL validation error");
  check(!JiraJqlRecovery.isSyntaxFailure("isError=true; 401 Unauthorized"),"auth error");
  check(!JiraJqlRecovery.isSyntaxFailure("isError=true; project not found"),"project unknown");
  check(!JiraJqlRecovery.isSyntaxFailure("isError=false; BMSA-104 Ready"),"successful response");
  System.out.println("PASS: JQL project/key/default construction, syntax error detection, and auth/project error exclusions");
 }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$DIR/src" -name '*.java')
java -cp "$DIR/classes" com.llmart.llm.service.JiraJqlRecoverySmoke
