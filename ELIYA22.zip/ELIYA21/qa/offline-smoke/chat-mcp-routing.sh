#!/usr/bin/env bash
# Offline compile + behavioral tests for the modified Chat MCP router and streaming service.
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
ROOT="$DIR/src"
mkdir -p "$ROOT/com/llmart/llm/service" "$ROOT/com/llmart/llm/dto" "$ROOT/com/fasterxml/jackson/databind" "$ROOT/org/springframework/stereotype" "$DIR/classes"
cp src/main/java/com/llmart/llm/service/ChatMcpService.java src/main/java/com/llmart/llm/service/JiraJqlRecovery.java "$ROOT/com/llmart/llm/service/"
mkdir -p "$ROOT/com/fasterxml/jackson/databind/node"
cat > "$ROOT/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/JsonNode.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import java.util.*;
public class JsonNode implements Iterable<JsonNode> {
 protected String value; public JsonNode(){} public JsonNode(String value){this.value=value;}
 public JsonNode path(String name){return this;} public String asText(String fallback){return value==null?fallback:value;}
 public String asText(){return asText("");} public boolean isObject(){return false;} public boolean isArray(){return false;}
 public boolean isNull(){return false;} public Iterator<JsonNode> iterator(){return Collections.emptyIterator();}
 @Override public String toString(){return value==null?"null":value;}
}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
public class ObjectMapper {
 public String writeValueAsString(Object value){return value==null?"null":value.toString();}
 public JsonNode readTree(String text){return new JsonNode();}
 public com.fasterxml.jackson.databind.node.ObjectNode createObjectNode(){return new com.fasterxml.jackson.databind.node.ObjectNode();}
}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/node/ObjectNode.java" <<'JAVA'
package com.fasterxml.jackson.databind.node;
import com.fasterxml.jackson.databind.JsonNode; import java.util.*;
public class ObjectNode extends JsonNode {
 private final Map<String,JsonNode> fields=new LinkedHashMap<>();
 public ObjectNode put(String key,String value){fields.put(key,new JsonNode(value));return this;}
 @Override public JsonNode path(String key){return fields.getOrDefault(key,new JsonNode());}
 @Override public boolean isObject(){return true;}
 public ObjectNode deepCopy(){ObjectNode copy=new ObjectNode();copy.fields.putAll(fields);return copy;}
 @Override public String toString(){return fields.toString();}
}
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatSettings {
 public String chatModelOrPrimary(){return "mock-chat";}
 public String baseUrl(){return "http://localhost";}
 public int safeMaxTokens(){return 1024;}
}
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatRequest.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatRequest { public ChatSettings settings(){return new ChatSettings();} }
JAVA
cat > "$ROOT/com/llmart/llm/service/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service;
public class AgentCancelledException extends RuntimeException {public AgentCancelledException(String s){super(s);}}
JAVA
cat > "$ROOT/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import java.util.function.*;import com.fasterxml.jackson.databind.JsonNode;
import com.llmart.llm.dto.ChatSettings;
public class OpenAiCompatibleClient {
 public record AgentToolCall(String id,String name,JsonNode arguments) {}
 public record AgentCompletion(String content,List<AgentToolCall> toolCalls,boolean hasToolCall) {}
 public Queue<AgentCompletion> turns=new ArrayDeque<>(); public int streamCalls=0; public List<Map<String,Object>> finalMessages=List.of(), lastTools=List.of();
 public AgentCompletion completeAgent(String key,String url,String model,int max,List<Map<String,Object>> context,List<Map<String,Object>> tools,boolean json,BooleanSupplier cancelled){lastTools=tools;return turns.remove();}
 public String stream(String key,ChatSettings settings,List<Map<String,Object>> messages,Consumer<String> onToken,BooleanSupplier cancelled){
   streamCalls++;finalMessages=messages;onToken.accept("Answer ");onToken.accept("streamed.");return "Answer streamed.";
 }
}
JAVA
cat > "$ROOT/com/llmart/llm/service/McpManager.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*; import java.nio.file.Path;import java.util.function.BooleanSupplier;import com.fasterxml.jackson.databind.JsonNode;
public class McpManager {
 public record Catalog(List<Map<String,Object>> definitions,Map<String,String> byFunction,List<String> diagnostics){}
 public int catalogCalls=0, readCalls=0; public boolean enabled=true; public String lastJql="";
 public Queue<String> outcomes=new ArrayDeque<>();
 private final Catalog catalog=new Catalog(List.of(
  Map.of("function",Map.of("name","jira_get_issue","description","MCP jira / get_issue")),
  Map.of("function",Map.of("name","jira_search_issues","description","MCP jira / search issues",
    "parameters",Map.of("type","object","properties",Map.of("jql",Map.of("type","string","description","JQL search"))))),
  Map.of("function",Map.of("name","confluence_search","description","MCP confluence / search")),
  Map.of("function",Map.of("name","jira_delete_issue","description","MCP jira / delete_issue"))
 ),Map.of(),List.of());
 public List<String> configuredServerNames(Path root){return enabled?List.of("jira","confluence"):List.of();}
 public Catalog catalogCachedForChat(){catalogCalls++;return catalog;}
 public boolean isChatReadOnly(Catalog cat,String name){return !name.contains("delete");}
 public String call(Path root,Catalog cat,String name,JsonNode args,BooleanSupplier cancel){
    readCalls++;lastJql=args==null?"":args.path("jql").asText("");return outcomes.isEmpty()?"Issue exists":outcomes.remove();}
}
JAVA
cat > "$ROOT/com/llmart/llm/service/ChatMcpOfflineTest.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import com.llmart.llm.dto.ChatRequest;
public class ChatMcpOfflineTest {
 static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  McpManager mcp=new McpManager();OpenAiCompatibleClient llm=new OpenAiCompatibleClient();
  ChatMcpService chat=new ChatMcpService(llm,mcp,new com.fasterxml.jackson.databind.ObjectMapper());
  String[] local={"How is Deep Search implemented?","How is Jira integration implemented?", "How is Confluence configured in source code?", "How are Jira tickets handled in our source code?", "Explain Java inheritance"};
  for(String query:local)check(!chat.shouldHandle(query),"Unexpected MCP request: "+query);
  String[] external={"Read Jira PAY-123 and explain acceptance criteria", "What is the status of ABC-42?", "Search Confluence for SEPA architecture", "Check SonarQube quality gate", "What is the recent tickets in BMSA", "List the latest issues in BMSA", "Show open bugs in Jira"};
  for(String query:external)check(chat.shouldHandle(query),"MCP routing missed "+query);
  var projectContext=List.<Map<String,Object>>of(Map.of("role","user","content","How is Deep Search implemented? Retrieved: Jira PAY-123"));
  check(chat.answer("key",new ChatRequest(),"How is Deep Search implemented?",projectContext,()->false,a->{},t->{}).isEmpty(),"Retrieved code incorrectly activated MCP");
  check(mcp.catalogCalls==0,"Local prompt attempted catalog discovery");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c1","jira_get_issue",null)),true));
  List<String> progress=new ArrayList<>(),tokens=new ArrayList<>();
  String answer=chat.answer("key",new ChatRequest(),"Read Jira PAY-123",List.of(Map.of("role","user","content","Read Jira PAY-123")),()->false,
     a->progress.add(a.status()),tokens::add).orElseThrow();
  check(mcp.catalogCalls==1 && mcp.readCalls==1,"Expected exactly one discovery and external read");
  check(llm.streamCalls==1,"MCP answer was not streamed");
  check(answer.equals("Answer streamed.") && tokens.equals(List.of("Answer ","streamed.")),"Wrong streamed output");
  check(progress.contains("discovering") && progress.contains("running") && progress.contains("generating"),"Missing loading statuses: "+progress);
  check(llm.finalMessages.stream().anyMatch(msg->"tool".equals(msg.get("role"))),"Missing MCP evidence in final response context");
  check(llm.lastTools.stream().noneMatch(t->t.toString().contains("delete_issue")),"Mutating MCP tool was exposed to Chat");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c2","jira_get_issue",null)),true));
  String recent=chat.answer("key",new ChatRequest(),"What is the recent tickets in BMSA",List.of(Map.of("role","user","content","What is the recent tickets in BMSA")),()->false,a->{},t->{}).orElseThrow();
  check(recent.equals("Answer streamed.") && mcp.readCalls==2,"Plural ticket query did not perform a live MCP read");
  // The Jira server may report errors in text even when its MCP isError flag is false.
  mcp.outcomes.add("mcpServer=jira; tool=search; isError=false\nThe search query was rejected by Jira due to syntax error");
  mcp.outcomes.add("mcpServer=jira; tool=search; isError=false\nBMSA-102 Ready");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c3","jira_search_issues",
     new com.fasterxml.jackson.databind.node.ObjectNode().put("jql","project = BMSA SORT BY updated"))),true));
  int readsBefore=mcp.readCalls;
  List<String> retryStatus=new ArrayList<>();
  String repaired=chat.answer("key",new ChatRequest(),"List recent tickets in BMSA",List.of(Map.of("role","user","content","List recent tickets in BMSA")),()->false,
     a->retryStatus.add(a.status()),t->{}).orElseThrow();
  check(repaired.equals("Answer streamed.") && mcp.readCalls==readsBefore+2,"Expected exactly one JQL repair retry");
  check(mcp.lastJql.equals("project = BMSA ORDER BY updated DESC"),"Incorrect repaired JQL: "+mcp.lastJql);
  check(retryStatus.contains("retrying"),"JQL recovery must be visible in UI activity");
  mcp.outcomes.add("mcpServer=jira; tool=search; isError=true\n403 forbidden");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c4","jira_search_issues",
     new com.fasterxml.jackson.databind.node.ObjectNode().put("jql","project = BMSA"))),true));
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Unavailable",List.of(),false));
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Unavailable",List.of(),false));
  readsBefore=mcp.readCalls;
  String denied=chat.answer("key",new ChatRequest(),"List recent tickets in BMSA",List.of(Map.of("role","user","content","List recent tickets in BMSA")),()->false,a->{},t->{}).orElseThrow();
  check(denied.contains("No verified Jira/DevOps data") && mcp.readCalls==readsBefore+1,"Permissions error must not be retried or reported as evidence");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c5","jira_search_issues",
     new com.fasterxml.jackson.databind.node.ObjectNode().put("jql","recent tickets from MCP"))),true));
  readsBefore=mcp.readCalls;
  List<String> prepared=new ArrayList<>();
  String fast=chat.answer("key",new ChatRequest(),"Show recent Jira tickets from MCP",List.of(Map.of("role","user","content","Show recent Jira tickets from MCP")),()->false,
     a->prepared.add(a.status()),t->{}).orElseThrow();
  check(fast.equals("Answer streamed.") && mcp.readCalls==readsBefore+1,"Plain-language JQL should be converted BEFORE the first tool call");
  check(mcp.lastJql.equals("updated >= -30d ORDER BY updated DESC") && prepared.contains("preparing"),"Missing proactive JQL correction");
  mcp.enabled=false;
  String disabled=chat.answer("key",new ChatRequest(),"List recent tickets in BMSA",List.of(),()->false,a->{},t->{}).orElseThrow();
  check(disabled.contains("No MCP server is enabled") && mcp.catalogCalls==5,"Disabled MCP silently fell back to an ungrounded model reply");
  System.out.println("PASS: MCP routing and streaming; proactive natural-language JQL correction; one-retry syntax repair; permission errors not retried; disabled MCP reports error");
 }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$ROOT" -name '*.java')
java -cp "$DIR/classes" com.llmart.llm.service.ChatMcpOfflineTest
