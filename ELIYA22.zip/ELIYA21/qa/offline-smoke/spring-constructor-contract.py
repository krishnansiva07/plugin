#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path('src/main/java')
problems=[]
for p in root.rglob('*.java'):
    text=p.read_text(errors='ignore')
    if not re.search(r'@(Service|Component|Repository|Controller|RestController)\b', text):
        continue
    m=re.search(r'public\s+(?:final\s+)?class\s+(\w+)', text)
    if not m:
        continue
    cls=m.group(1)
    ctors=[]
    for mm in re.finditer(r'(?m)^\s*(public|protected|private)?\s*'+re.escape(cls)+r'\s*\(([^)]*)\)', text):
        prefix=text[max(0,mm.start()-160):mm.start()]
        ctors.append({'args':mm.group(2).strip(), 'autowired':'@Autowired' in prefix})
    if len(ctors) <= 1:
        continue
    has_noarg=any(not c['args'] for c in ctors)
    has_autowired=any(c['autowired'] for c in ctors)
    if not has_noarg and not has_autowired:
        problems.append(f'{p}: multiple constructors, no no-arg constructor, and no @Autowired constructor')
if problems:
    print('\n'.join('FAIL: '+x for x in problems))
    sys.exit(1)
print('PASS: Spring bean constructor contract check')
