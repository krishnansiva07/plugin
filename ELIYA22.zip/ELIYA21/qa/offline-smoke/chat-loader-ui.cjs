// Dependency-free JS behavior check: status updates retain the loader until the first Chat token.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const start = source.indexOf('function chatLoadingHtml(message) {');
const end = source.indexOf('function updateAgentProgressUi(index) {', start);
assert(start >= 0 && end > start, 'Chat loader functions not found');
let cursor = false;
const content = {innerHTML:'', classList:{toggle(name,on){if(name==='typing-cursor')cursor=on;}}};
const state = {messages:[{mode:'chat',streaming:true,content:'',chatLoadingStatus:'Searching project…'}]};
const ctx = {
  state, esc: s => String(s).replace(/&/g, '&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'),
  $: name => name === 'messages' ? {querySelector:()=>({querySelector:()=>content})} : null,
  MarkdownRenderer: {render: text=>text}, stripProjectMarkers: text=>text,
  updateContextBadge: ()=>{}, renderMessages: ()=>{throw new Error('Unexpected full render')}
};
vm.createContext(ctx);
vm.runInContext(source.slice(start,end),ctx);
ctx.updateStreamingMessage(0);
assert.match(content.innerHTML,/chat-loading-spinner/);
assert.match(content.innerHTML,/Searching project/);
assert.equal(cursor,false);
state.messages[0].chatLoadingStatus='Reading Jira issue…';
ctx.updateStreamingMessage(0);
assert.match(content.innerHTML,/Reading Jira issue/);
state.messages[0].content='First streamed token';
ctx.updateStreamingMessage(0);
assert.equal(content.innerHTML,'First streamed token');
assert.equal(cursor,true);
assert(!content.innerHTML.includes('chat-loading-spinner'));
console.log('PASS: Chat loader visible during status updates, then removed when first token arrives');
