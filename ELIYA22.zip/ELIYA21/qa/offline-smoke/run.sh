#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
command -v javac >/dev/null || { echo 'JDK 17+ required' >&2; exit 2; }
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
PKG="$DIR/src/com/llmart/llm/service"; mkdir -p "$PKG" "$DIR/src/org/springframework/stereotype" "$DIR/classes"
cat > "$DIR/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$PKG/AgentWorkspaceService.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.Path; import java.util.Map;
class AgentWorkspaceService {record Workspace(Path root, Map<String,PromptResourceResolver.ResolvedResource> resources) {}}
JAVA
cat > "$PKG/PromptResourceResolver.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.Path;
class PromptResourceResolver {record ResolvedResource(Path root, boolean writable) {}}
JAVA
cat > "$PKG/AgentRunService.java" <<'JAVA'
package com.llmart.llm.service;
class AgentRunService {static class AgentRun {void checkCancelled() {}}}
JAVA
cat > "$PKG/OfflineSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.io.*; import java.nio.file.*; import java.time.Duration; import java.util.*;
public class OfflineSmoke {
    static void verify(boolean ok, String message) {if (!ok) throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        Path temp = Files.createTempDirectory("eliya-offline-smoke");
        try {
            Path project = temp.resolve("project"); Files.createDirectories(project.resolve("nested"));
            Path tracked = project.resolve("nested/old.txt");
            Path binary = project.resolve("nested/binary.dat");
            Files.writeString(tracked, "original"); byte[] before = {0, 1, -1, 88}; Files.write(binary, before);
            var ws = new AgentWorkspaceService.Workspace(project, Map.of());
            var snapshots = new ProtectedRunSnapshotService(temp.resolve("safe-snapshots"));
            snapshots.begin("first", ws);
            Files.writeString(tracked, "changed"); Files.delete(binary);
            Files.createDirectories(project.resolve("new")); Files.writeString(project.resolve("new/created.txt"), "new");
            String result = snapshots.rollback("first");
            verify(result.contains("restored"), "Rollback result missing");
            verify(Files.readString(tracked).equals("original"), "Text restore failed");
            verify(Arrays.equals(Files.readAllBytes(binary), before), "Binary restore failed");
            verify(!Files.exists(project.resolve("new")), "New directory not removed");
            var inside = new ProtectedRunSnapshotService(project.resolve("data/protection-snapshots"));
            try {inside.begin("unsafe", ws); throw new AssertionError("Snapshot-inside-workspace must be denied");}
            catch (IOException expected) {verify(expected.getMessage().contains("inside"), "Unexpected snapshot error");}
            verify(!Files.exists(project.resolve("data/protection-snapshots/unsafe")), "Unsafe snapshot created");
            var approvals = new AgentApprovalService();
            var forDelete = approvals.create("run", "delete", "path", false, Duration.ofMillis(40));
            verify(!approvals.resolve(forDelete.id(), AgentApprovalService.Decision.RUN), "Run-wide deletion approval bypass");
            Thread.sleep(85);
            verify(!approvals.resolve(forDelete.id(), AgentApprovalService.Decision.ONCE), "Late approval accepted");
            var wait = approvals.create("run", "delete", "path", false, Duration.ofMillis(70));
            try {approvals.await(wait.id(), Duration.ofMillis(70), new AgentRunService.AgentRun());
                throw new AssertionError("Approval timeout missing");}
            catch (AgentApprovalTimeoutException expected) {}
            var forOnce = approvals.create("run", "delete", "path", false, Duration.ofSeconds(60));
            verify(approvals.resolve(forOnce.id(), AgentApprovalService.Decision.ONCE), "Specific approval blocked");
            verify(approvals.await(forOnce.id(), Duration.ofSeconds(2), new AgentRunService.AgentRun()) == AgentApprovalService.Decision.ONCE, "Specific approval lost");
            verify(AgentDeletionCommandGuard.isPotentialDestructiveShell("rm -rf src"), "rm guard failed");
            verify(AgentDeletionCommandGuard.isPotentialDestructiveShell("powershell Remove-Item -Force foo"), "PowerShell guard failed");
            verify(!AgentDeletionCommandGuard.isPotentialDestructiveShell("cat README.md"), "False positive on read");
            System.out.println("PASS: deletion approval TTL, single-use permission, rollback, outside-root snapshot, command guard");
        } finally {
            try(var paths = Files.walk(temp)) { for (var path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path); }
        }
    }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$DIR/src" -name '*.java') \
  src/main/java/com/llmart/llm/service/AgentApprovalService.java \
  src/main/java/com/llmart/llm/service/AgentApprovalTimeoutException.java \
  src/main/java/com/llmart/llm/service/AgentDeletionCommandGuard.java \
  src/main/java/com/llmart/llm/service/ProtectedRunSnapshotService.java
java -cp "$DIR/classes" com.llmart.llm.service.OfflineSmoke
