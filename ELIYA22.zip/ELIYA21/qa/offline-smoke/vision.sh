#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
PKG="$DIR/src/com/llmart/llm/service"
mkdir -p "$PKG" "$DIR/src/com/llmart/llm/dto" "$DIR/src/org/springframework/stereotype" "$DIR/classes"
cat > "$DIR/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$DIR/src/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public record ChatSettings(String model, String url, String key) {
  public boolean hasDedicatedVisionModel() {return model != null && !model.isBlank();}
  public String visionModelOrPrimary() {return model;}
  public String visionEndpoint() {return url;}
  public String visionKey(String fallback) {return key == null ? fallback : key;}
}
JAVA
cat > "$PKG/WorkspaceDocumentScanner.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.List;
class WorkspaceDocumentScanner {
  record Visual(String locator, String mimeType, byte[] bytes, String context) {}
  record Scan(String text, int detectedVisuals, List<Visual> visuals, List<String> warnings) {}
}
JAVA
cat > "$PKG/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.List; import java.util.Map;
class OpenAiCompatibleClient {
  int calls = 0; boolean failSecond = false;
  String complete(String key, String url, String model, int tokens, List<Map<String,Object>> messages) throws Exception {
    calls++;
    if (failSecond && calls == 2) throw new java.io.IOException("Simulated endpoint failure");
    Object userContent = messages.get(1).get("content");
    if (!(userContent instanceof List<?> content) || content.size() < 2) throw new AssertionError("Missing image input");
    String prompt = String.valueOf(((Map<?,?>)content.get(0)).get("text"));
    var matcher = java.util.regex.Pattern.compile("(?m)^Image locator: (\\S+)").matcher(prompt);
    StringBuilder output = new StringBuilder();
    while(matcher.find()) output.append("[IMAGE: ").append(matcher.group(1)).append("] Visible test label\\n");
    return output.toString();
  }
}
JAVA
cat > "$PKG/VisionSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*; import java.awt.image.BufferedImage; import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream; import com.llmart.llm.dto.ChatSettings;
public class VisionSmoke {
  static void verify(boolean b, String m) {if (!b) throw new AssertionError(m);}
  public static void main(String[] args) throws Exception {
    BufferedImage picture = new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB);
    ByteArrayOutputStream encoded = new ByteArrayOutputStream(); ImageIO.write(picture,"png",encoded);
    var visuals = new ArrayList<WorkspaceDocumentScanner.Visual>();
    for (int i=0;i<4;i++) visuals.add(new WorkspaceDocumentScanner.Visual("page-"+i,"image/png",encoded.toByteArray(),"Surrounding text section "+i));
    var scan = new WorkspaceDocumentScanner.Scan("Business rule: confirm payment",4,visuals,List.of());
    var client = new OpenAiCompatibleClient(); var svc = new VisionDocumentService(client);
    var noVision = svc.analyse("agent-key",new ChatSettings("", "url",null),scan,"requirements.pdf","Extract testable flows");
    verify("vision_not_configured".equals(noVision.status()), "Unconfigured vision should not claim coverage");
    var result = svc.analyse("agent-key",new ChatSettings("custom-future-model","vision-endpoint",null),scan,"requirements.pdf","Extract testable flows");
     verify(result.analysedImages()==4 && "complete".equals(result.status()) && client.calls==2,"Batch vision processing failed");
    client.calls=0; client.failSecond=true;
    var incomplete = svc.analyse("agent-key",new ChatSettings("another-new-model","vision-endpoint",null),scan,"requirements.pdf","Extract testable flows");
    verify(incomplete.analysedImages()==3 && "partial".equals(incomplete.status()) && !incomplete.warnings().isEmpty(),"Partial vision failure was hidden");
    System.out.println("PASS: model-independent Vision adapter, image batching, missing configuration, partial-failure reporting");
  }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$DIR/src" -name '*.java') \
  src/main/java/com/llmart/llm/service/VisualImageAdapter.java \
  src/main/java/com/llmart/llm/service/VisionDocumentService.java
java -Djava.awt.headless=true -cp "$DIR/classes" com.llmart.llm.service.VisionSmoke
