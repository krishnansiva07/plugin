#!/usr/bin/env bash
# Compile the real HTTP controller against minimal Spring/Jakarta signatures, then exercise
# the Windows process protocol with a fake native picker (no Windows GUI required in CI).
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/jakarta/annotation" "$TMP/src/jakarta/servlet/http" \
 "$TMP/src/org/springframework/web/bind/annotation" "$TMP/src/org/springframework/http" \
 "$TMP/src/com/llmart/llm/controller" "$TMP/bin" "$TMP/classes" "$TMP/project with spaces"
for anno in PostConstruct PreDestroy; do
  echo "package jakarta.annotation; public @interface $anno {}" > "$TMP/src/jakarta/annotation/$anno.java"
done
cat > "$TMP/src/jakarta/servlet/http/HttpServletRequest.java" <<'JAVA'
package jakarta.servlet.http;
public interface HttpServletRequest {
  String getRemoteAddr(); String getHeader(String header); String getScheme();
}
JAVA
for anno in PostMapping RequestMapping RestController; do
  echo "package org.springframework.web.bind.annotation; public @interface $anno {String[] value() default {}; }" > "$TMP/src/org/springframework/web/bind/annotation/$anno.java"
done
cat > "$TMP/src/org/springframework/http/HttpStatus.java" <<'JAVA'
package org.springframework.http;
public enum HttpStatus {OK, FORBIDDEN, CONFLICT, BAD_REQUEST, SERVICE_UNAVAILABLE}
JAVA
cat > "$TMP/src/org/springframework/http/ResponseEntity.java" <<'JAVA'
package org.springframework.http;
public final class ResponseEntity<T> {
  private final HttpStatus status; private final T body;
  private ResponseEntity(HttpStatus status, T body) {this.status = status; this.body = body;}
  public static <T> ResponseEntity<T> ok(T body) {return new ResponseEntity<>(HttpStatus.OK, body);}
  public static BodyBuilder status(HttpStatus status) {return new BodyBuilder(status);}
  public HttpStatus getStatusCode() {return status;}
  public T getBody() {return body;}
  public static class BodyBuilder {
    private final HttpStatus status;
    private BodyBuilder(HttpStatus status) {this.status = status;}
    public <T> ResponseEntity<T> body(T body) {return new ResponseEntity<>(status, body);}
  }
}
JAVA
cat > "$TMP/bin/powershell.exe" <<'SHIM'
#!/usr/bin/env bash
set -euo pipefail
echo launch >> "$PICKER_COUNT_FILE"
sleep 0.3 # simulated expensive cold process startup
printf 'ELIYA_READY\n'
while IFS= read -r command; do
  if [[ "$command" == 'OPEN' ]]; then
    if [[ -f "$PICKER_WAIT_FILE" ]]; then sleep 0.6; fi
    if [[ -f "$PICKER_CANCEL_FILE" ]]; then
      printf 'ELIYA_CANCELLED\n'
    else
      printf 'ELIYA_SELECTED:%s\n' "$PICKER_FAKE_BASE64"
    fi
  fi
done
SHIM
chmod +x "$TMP/bin/powershell.exe"
cat > "$TMP/src/com/llmart/llm/controller/FolderPickerSmoke.java" <<'JAVA'
package com.llmart.llm.controller;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
public class FolderPickerSmoke {
  private static void check(boolean ok, String description) {
    if (!ok) throw new AssertionError(description);
  }
  private static final HttpServletRequest LOCAL = new HttpServletRequest() {
    public String getRemoteAddr() {return "127.0.0.1";}
    public String getScheme() {return "http";}
    public String getHeader(String name) {
      return name.equals("Origin") ? "http://localhost:8080" : "localhost:8080";
    }
  };
  public static void main(String[] args) throws Exception {
    System.setProperty("os.name", "Windows 11");
    var ctrl = new LocalFolderPickerController();
    ctrl.prewarmDesktopPicker();
    Thread.sleep(600); // warm-up finishes without an HTTP request
    for (int i = 0; i < 2; i++) {
      var response = ctrl.browse(LOCAL);
      check(response.getStatusCode() == HttpStatus.OK, "Expected successful Browse " + (i + 1));
      check(Path.of((String) response.getBody().get("path")).equals(Path.of(args[0]).toRealPath()),
          "Selected path was not returned intact");
    }
    check(Files.readAllLines(Path.of(args[1])).size() == 1,
        "Second Browse incorrectly launched a second PowerShell process");
    Files.createFile(Path.of(args[2]));
    var first = CompletableFuture.supplyAsync(() -> ctrl.browse(LOCAL));
    Thread.sleep(120);
    var concurrent = ctrl.browse(LOCAL);
    check(concurrent.getStatusCode() == HttpStatus.CONFLICT,
        "Concurrent Browse should return 409 instead of queueing another dialog");
    check(first.get(4, TimeUnit.SECONDS).getStatusCode() == HttpStatus.OK,
        "First concurrent picker did not complete");
    Files.delete(Path.of(args[2]));
    Files.createFile(Path.of(args[3]));
    var cancelled = ctrl.browse(LOCAL);
    check(cancelled.getStatusCode() == HttpStatus.OK && Boolean.TRUE.equals(cancelled.getBody().get("cancelled")),
        "Cancellation should not be treated as an error or trigger indexing");
    Files.delete(Path.of(args[3]));
    check(Files.readAllLines(Path.of(args[1])).size() == 1, "Picker process not reused");
    check(!LocalFolderPickerController.isSameOrigin("http://evil.test", "localhost:8080", "http"),
        "Origin check regressed");
    check(LocalFolderPickerController.isLocalRequest("::1"), "IPv6 localhost rejected");
    ctrl.stopDesktopPicker();
    System.out.println("PASS: Java 17 controller compile, picker reused, concurrent request rejected, "
        + "cancel supported, spaces in path and local origin validated");
  }
}
JAVA
PICKER_FAKE_BASE64="$(printf '%s' "$TMP/project with spaces" | base64 -w0)" \
PICKER_COUNT_FILE="$TMP/launches" \
PICKER_WAIT_FILE="$TMP/wait" PICKER_CANCEL_FILE="$TMP/cancel" \
PATH="$TMP/bin:$PATH" bash -c '
  javac --release 17 -d "$1/classes" $(find "$1/src" -name "*.java") \
    src/main/java/com/llmart/llm/controller/LocalFolderPickerController.java
  java -cp "$1/classes" com.llmart.llm.controller.FolderPickerSmoke \
    "$1/project with spaces" "$1/launches" "$1/wait" "$1/cancel"
' _ "$TMP"
