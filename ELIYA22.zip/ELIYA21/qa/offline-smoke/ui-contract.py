#!/usr/bin/env python3
"""Source-level UI/API wiring assertions; this is NOT a browser or integration test."""
from pathlib import Path

ui = Path('src/main/resources/static/index.html').read_text()
js = Path('src/main/resources/static/app.js').read_text()
agent = Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
controller = Path('src/main/java/com/llmart/llm/controller/KnowledgeController.java').read_text()
knowledge = Path('src/main/java/com/llmart/llm/service/WorkspaceKnowledgeService.java').read_text()
checks = {
    'Agentic model selector': 'id="agentModelSelect"' in ui,
    'Optional Vision selector': 'id="agentVisionSelect"' in ui,
    'Workspace knowledge controls': all(f'id="{k}"' in ui for k in ['knowledgeAnalyseBtn','knowledgeViewBtn','knowledgeStatus','knowledgePanel']),
    'Deletion popup with countdown and actions': all(f'id="{k}"' in ui for k in ['deletionApprovalBackdrop','deletionApprovalTargets','deletionApprovalCountdown','deletionApproveBtn','deletionRejectBtn']),
    'Front-end indexing endpoint': '/api/knowledge/analyse' in js,
    'Front-end approval endpoint': '/api/agent/approvals/' in js,
    'Backend index endpoint': '@PostMapping("/analyse")' in controller,
    'Backend direct source search': '@GetMapping("/search")' in controller,
    'Backend explicit 60-second TTL': 'Duration.ofSeconds(60)' in agent,
    'Backend rollback on timeout and reject': agent.count('rollbackAfterDeletionDeclined(') >= 4,
    'Knowledge file hash check': 'doc.sha256().equals(fileHash(source))' in knowledge,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {label}")
if not all(checks.values()):
    raise SystemExit(1)
print(f"UI/API source contract checks: {len(checks)} passed")
