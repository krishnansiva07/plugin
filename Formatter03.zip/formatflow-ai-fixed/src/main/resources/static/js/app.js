const state = { format:"CONFLUENCE", operation:"FORMAT", originalContent:"", finalContent:"", previewHtml:"", document:null, currentPreview:"formatted" };
const $ = id => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async()=>{ bindEvents(); updateCounts(); await checkSession(); });

function bindEvents(){
  $("toggleKey").addEventListener("click",()=>$("apiKey").type=$("apiKey").type==="password"?"text":"password");
  $("validateKeyBtn").addEventListener("click",validateKey); $("apiKey").addEventListener("keydown",e=>{if(e.key==="Enter")validateKey()});
  $("disconnectBtn").addEventListener("click",disconnect); $("changeKeyBtn").addEventListener("click",()=>{$("apiKey").value="";showAuth()});
  document.querySelectorAll(".input-tabs .tab").forEach(b=>b.addEventListener("click",()=>switchInputTab(b.dataset.tab)));
  $("contentInput").addEventListener("input",updateCounts); $("uploadBtn").addEventListener("click",uploadFile); $("urlImportBtn").addEventListener("click",importUrl);
  document.querySelectorAll(".activity-card").forEach(b=>b.addEventListener("click",()=>selectOperation(b)));
  document.querySelectorAll(".format-card").forEach(b=>b.addEventListener("click",()=>selectFormat(b)));
  document.querySelectorAll('input[name="mode"]').forEach(r=>r.addEventListener("change",updateModeCards));
  $("previewBtn").addEventListener("click",preview); $("copyBtn").addEventListener("click",copyOutput); $("downloadBtn").addEventListener("click",downloadOutput);
  document.querySelectorAll(".mini-tab").forEach(b=>b.addEventListener("click",()=>{state.currentPreview=b.dataset.preview;document.querySelectorAll(".mini-tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderPreviewMode()}));
}

async function checkSession(){ try{const r=await fetch("/api/session/status");const d=await r.json();$("authEndpoint").textContent=`Model: ${d.model||"Not configured"} • Endpoint: ${d.baseUrl||"Not configured"}`;d.connected?showApp():showAuth()}catch{showAuth();showMessage("authMessage","Unable to reach FormatFlow server.",true)} }
async function validateKey(){const apiKey=$("apiKey").value.trim();if(!apiKey){showMessage("authMessage","Enter the LLM API key.",true);return}setBusy("validateKeyBtn",true,"Validating...");try{const r=await fetch("/api/session/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apiKey})});const d=await r.json();if(!d.valid){showMessage("authMessage",d.message||"Validation failed.",true);return}$("apiKey").value="";showApp()}catch{showMessage("authMessage","Unable to validate the key.",true)}finally{setBusy("validateKeyBtn",false,"Validate & Continue")}}
async function disconnect(){try{await fetch("/api/session/disconnect",{method:"POST"})}finally{state.document=null;showAuth()}}
function showAuth(){$("authGate").classList.remove("hidden");$("appShell").classList.add("hidden")} function showApp(){$("authGate").classList.add("hidden");$("appShell").classList.remove("hidden")}
function switchInputTab(name){document.querySelectorAll(".input-tabs .tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===name));["paste","upload","url"].forEach(t=>$(t+"Tab").classList.toggle("active",t===name))}
function selectOperation(btn){state.operation=btn.dataset.operation;document.querySelectorAll(".activity-card").forEach(x=>x.classList.remove("selected"));btn.classList.add("selected");const summary=state.operation==="SUMMARIZE";$("summaryOptions").classList.toggle("hidden",!summary);$("formatModeWrap").classList.toggle("hidden",summary);$("topProtectionText").textContent=summary?"Summarization explicitly transforms source content":"Format mode preserves source wording"}
function selectFormat(card){state.format=card.dataset.format;document.querySelectorAll(".format-card").forEach(x=>x.classList.remove("selected"));card.classList.add("selected");$("emailSubjectWrap").classList.toggle("hidden",state.format!=="EMAIL");$("downloadBtn").textContent=`Download ${displayFormat(state.format)}`;$("copyBtn").textContent=state.format==="CONFLUENCE"?"Copy for Confluence":(state.format==="MARKDOWN"?"Copy Markdown":"Copy Formatted")}
function updateModeCards(){document.querySelectorAll(".mode-card").forEach(c=>c.classList.toggle("selected",c.querySelector("input").checked));$("topProtectionText").textContent=selectedMode()==="PRESERVE"?"LLM formats metadata only; wording stays intact":"Enhancement enabled; all changes are measured"}
function selectedMode(){return document.querySelector('input[name="mode"]:checked').value}
function updateCounts(){const t=$("contentInput").value;$("wordCount").textContent=`${wordCount(t)} words`;$("charCount").textContent=`${t.length} characters`}

async function uploadFile(){const file=$("fileInput").files[0];if(!file){showMessage("importMessage","Choose a file first.",true);return}const fd=new FormData();fd.append("file",file);showMessage("importMessage","Importing...");try{const d=await jsonOrError(await fetch("/api/import/file",{method:"POST",body:fd}));$("contentInput").value=d.content;updateCounts();switchInputTab("paste");showMessage("importMessage",`Imported ${d.words} words from ${d.source}.`,false)}catch(e){handleApiError(e,"importMessage")}}
async function importUrl(){const url=$("urlInput").value.trim();if(!url){showMessage("importMessage","Enter a URL.",true);return}setBusy("urlImportBtn",true,"Importing...");try{const d=await jsonOrError(await fetch("/api/import/url",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url})}));$("contentInput").value=d.content;updateCounts();switchInputTab("paste");showMessage("importMessage",`Imported ${d.words} words from ${d.source}.`,false)}catch(e){handleApiError(e,"importMessage")}finally{setBusy("urlImportBtn",false,"Import Content")}}

async function preview(){const content=$("contentInput").value;if(!content.trim()){toast("Add source content first.",true);return}const request={content,audience:$("audience").value,purpose:$("purpose").value,format:state.format,operation:state.operation,mode:state.operation==="SUMMARIZE"?"PRESERVE":selectedMode(),summaryLength:$("summaryLength").value,visualStyle:$("visualStyle").value,iconLevel:$("iconLevel").value,emailSubject:$("emailSubject").value,generateEmailSubject:$("generateSubject").checked,smartLayout:$("smartLayout").checked};
  setBusy("previewBtn",true,state.operation==="SUMMARIZE"?"Summarizing in LLM chunks...":"Applying LLM formatting...");$("processingInfo").classList.remove("hidden");$("processingInfo").textContent="Processing with the configured LLM. Large content is chunked automatically.";
  try{const d=await jsonOrError(await fetch("/api/format/preview",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(request)}));state.originalContent=content;state.finalContent=d.finalContent;state.previewHtml=d.previewHtml;state.copyHtml=d.copyHtml||"";state.copyText=d.copyText||d.finalContent||"";state.document=d.document;renderPreviewMode();updateStats(d.stats);$("copyBtn").disabled=false;$("downloadBtn").disabled=false;$("downloadBtn").textContent=`Download ${displayFormat(state.format)}`;const layouts=(d.processing.detectedLayouts||[]).join(", ");$("processingInfo").textContent=`${d.processing.activity} • ${d.processing.llmCalls} LLM call(s) • ${d.processing.semanticSections||0} semantic section(s)${layouts?` • Detected: ${layouts}`:""}${d.processing.chunked?" • Large content chunking used":""}${d.processing.semanticFallback?" • Safe text fallback used for unsupported/invalid sections":""}`;toast("Preview ready.",false)}catch(e){if(e.status===401)showAuth();else{toast(e.message||"Processing failed.",true);$("processingInfo").textContent="Processing failed. See the error message."}}finally{setBusy("previewBtn",false,"✦ Process with LLM & Preview")}}

function renderPreviewMode(){if(!state.document)return;if(state.currentPreview==="formatted"){$("previewArea").innerHTML=state.previewHtml}else if(state.currentPreview==="original"){$("previewArea").innerHTML=`<div class="side-box"><h4>Original Content</h4><pre>${escapeHtml(state.originalContent)}</pre></div>`}else{$("previewArea").innerHTML=`<div class="side-by-side"><div class="side-box"><h4>Original</h4><pre>${escapeHtml(state.originalContent)}</pre></div><div class="side-box"><h4>Output Content</h4><pre>${escapeHtml(state.finalContent)}</pre></div></div>`}}
function updateStats(s){$("statOriginal").textContent=s.originalWords;$("statFormatted").textContent=s.formattedWords;$("statAdded").textContent=s.addedWords;$("statRemoved").textContent=s.removedWords;$("statStatus").textContent=s.exactContentPreserved?"100% Preserved":(state.operation==="SUMMARIZE"?"Summarized":"Changed");$("statStatus").style.color=s.exactContentPreserved?"var(--green)":"#996300"}

async function copyOutput(){
  if(!state.document)return;
  try{
    // Markdown is a text format. Copy the exact generated Markdown, not preview HTML.
    if(state.format==="MARKDOWN" || !state.copyHtml){
      await navigator.clipboard.writeText(state.copyText||state.finalContent);
      toast(state.format==="MARKDOWN"?"Markdown copied.":"Content copied.",false);
      return;
    }

    if(navigator.clipboard && window.ClipboardItem){
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/html":new Blob([state.copyHtml],{type:"text/html"}),
          "text/plain":new Blob([state.copyText||state.finalContent],{type:"text/plain"})
        })
      ]);
      toast(state.format==="CONFLUENCE"?"Confluence-compatible content copied. Paste into the Confluence editor.":"Formatted content copied.",false);
    }else{
      await navigator.clipboard.writeText(state.copyText||state.finalContent);
      toast("Plain-text fallback copied.",false);
    }
  }catch(e){
    await navigator.clipboard.writeText(state.copyText||state.finalContent);
    toast("Clipboard rich HTML was unavailable; plain-text fallback copied.",true);
  }
}
async function downloadOutput(){if(!state.document)return;setBusy("downloadBtn",true,"Preparing...");try{const r=await fetch("/api/export",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({document:state.document,format:state.format,filename:"formatflow-output"})});if(!r.ok){const e=await r.json().catch(()=>({error:"Export failed."}));throw new Error(e.error||"Export failed.")}const blob=await r.blob();const disp=r.headers.get("Content-Disposition")||"";const star=disp.match(/filename\*=UTF-8''([^;]+)/i);const simple=disp.match(/filename="?([^";]+)"?/i);const filename=star?decodeURIComponent(star[1]):(simple?simple[1]:`formatflow-output.${extensionFor(state.format)}`);const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast(`${displayFormat(state.format)} downloaded.`,false)}catch(e){toast(e.message||"Export failed.",true)}finally{setBusy("downloadBtn",false,`Download ${displayFormat(state.format)}`)}}

async function jsonOrError(r){const d=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(d.error||`Request failed (${r.status}).`);e.status=r.status;throw e}return d} function handleApiError(e,id){if(e.status===401){showAuth();return}showMessage(id,e.message||"Request failed.",true)}
function showMessage(id,text,error=false){const n=$(id);n.textContent=text||"";n.classList.toggle("error",!!text&&error);n.classList.toggle("success",!!text&&!error)} function setBusy(id,busy,label){const b=$(id);b.disabled=busy;b.textContent=label}
function toast(text,error=false){const t=$("toast");t.textContent=text;t.classList.toggle("error",error);t.classList.remove("hidden");clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>t.classList.add("hidden"),4500)}
function wordCount(t){const s=(t||"").trim();return s?s.split(/\s+/).length:0} function escapeHtml(v){return(v||"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}
function displayFormat(f){return({CONFLUENCE:"Confluence",WORD:"Word",POWERPOINT:"PowerPoint",PDF:"PDF",EMAIL:"Email",MARKDOWN:"Markdown",HTML:"HTML"})[f]||f} function extensionFor(f){return({CONFLUENCE:"html",WORD:"docx",POWERPOINT:"pptx",PDF:"pdf",EMAIL:"html",MARKDOWN:"md",HTML:"html"})[f]||"txt"}
