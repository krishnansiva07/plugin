package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.ScenarioResult;
import com.itps.vibium.model.StepResult;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ReportService {
    private final ObjectMapper mapper = new ObjectMapper();

    public void writeReports(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("report.json").toFile(), status);
        writeHtml(status, runDir.resolve("report.html"));
        writeExcel(status, runDir.resolve("report.xlsx"));
        zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip"));
    }


    public void writeFallbackHtml(RunStatus status, Path runDir, Exception error) throws Exception {
        Files.createDirectories(runDir);
        String html = "<!doctype html><html><head><meta charset='utf-8'><title>ITPS VIBIUM Report Failure</title>" +
                "<style>body{font-family:Segoe UI,Arial;margin:32px;background:#f4f8f6;color:#10231e}.card{background:white;border:1px solid #dce8e2;border-radius:16px;padding:20px;max-width:1000px}pre{white-space:pre-wrap;color:#b42318}</style></head><body>" +
                "<div class='card'><h1>ITPS VIBIUM Report</h1><p>The normal report writer failed, so this fallback report was generated.</p>" +
                "<p><b>Run:</b> " + esc(status == null ? "" : status.getRunId()) + "</p>" +
                "<p><b>Status:</b> " + esc(status == null ? "" : status.getStatus()) + "</p>" +
                "<pre>" + esc(error == null ? "Unknown report error" : error.getMessage()) + "</pre></div></body></html>";
        Files.writeString(runDir.resolve("report.html"), html, StandardCharsets.UTF_8);
    }

    private void writeHtml(RunStatus status, Path file) throws Exception {
        String html = """
                <!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
                <title>ITPS VIBIUM MCP Report</title>
                <style>
                :root{--green:#007A53;--green2:#004B35;--ink:#10231e;--muted:#66756f;--line:#dce8e2;--bg:#f4f8f6;--card:#fff;--red:#b42318;--ok:#027a48;--amber:#b54708;--blue:#175cd3}
                *{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Segoe UI,Arial,sans-serif;color:var(--ink)}
                .top{background:linear-gradient(135deg,var(--green2),var(--green));color:#fff;padding:26px 34px;border-bottom:4px solid #b7e4d2}.brand{letter-spacing:.18em;text-transform:uppercase;font-size:12px;opacity:.9}.title{font-size:32px;font-weight:850;margin-top:6px}.sub{opacity:.92;margin-top:6px}.wrap{padding:24px 34px}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.kpi{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(0,75,53,.06)}.kpi .label{font-size:12px;color:var(--muted);font-weight:750;text-transform:uppercase}.kpi .value{font-size:29px;font-weight:850;margin-top:8px}.note{margin-top:16px;background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px 16px;color:#42534e}
                .panel{background:var(--card);border:1px solid var(--line);border-radius:18px;margin-top:20px;box-shadow:0 8px 24px rgba(0,75,53,.06);overflow:hidden}.scenario-head{display:flex;justify-content:space-between;gap:12px;padding:17px 18px;border-bottom:1px solid var(--line)}.scenario-title{font-size:18px;font-weight:850}.url,.small{font-size:12px;color:var(--muted);margin-top:4px}.pill{display:inline-block;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:850}.pass{background:#e7f8ef;color:var(--ok)}.fail{background:#fee4e2;color:var(--red)}.run{background:#fff4e5;color:var(--amber)}
                table{width:100%;border-collapse:collapse}th,td{text-align:left;border-bottom:1px solid var(--line);padding:11px;vertical-align:top;font-size:13px}th{font-size:11px;text-transform:uppercase;color:#53645f;letter-spacing:.05em;background:#fbfdfc}.code{font-family:Consolas,monospace;font-size:11px;white-space:pre-wrap;word-break:break-word;max-width:360px}.err{color:var(--red);font-weight:650}.shot{color:var(--blue);font-weight:800;text-decoration:none}.evidence{color:#31564b}.footer{margin:26px 0 8px;color:var(--muted);font-size:12px}
                </style></head><body>
                """ +
                "<div class='top'><div class='brand'>ITPS VIBIUM Framework</div><div class='title'>MCP Execution Report</div><div class='sub'>Run " + esc(status.getRunId()) + " · " + esc(status.getStatus()) + " · V4 closed-loop agent mode</div><div class='sub'>Started: " + fmt(status.getStartedAt()) + " · Finished: " + fmt(status.getFinishedAt()) + "</div></div>" +
                "<main class='wrap'>" + kpis(status) + diagnosticsLinks() + scenarios(status) + "<div class='footer'>Generated by ITPS VIBIUM Framework · Vibium MCP execution · No Selenium fallback</div></main></body></html>";
        Files.writeString(file, html, StandardCharsets.UTF_8);
    }


    private String diagnosticsLinks() {
        return "<div class='note'><b>Diagnostics:</b> <a href='mcp-tools.json'>MCP tools</a> · <a href='mcp-transcript.json'>MCP transcript</a> · <a href='mcp-process.log'>MCP process log</a></div>";
    }

    private String kpis(RunStatus s) {
        return "<section class='grid'>" +
                kpi("Total", String.valueOf(s.getTotal())) + kpi("Passed", String.valueOf(s.getPassed())) +
                kpi("Failed", String.valueOf(s.getFailed())) + kpi("Status", s.getStatus()) + "</section>" +
                (s.getMessage() == null ? "" : "<div class='note'>" + esc(s.getMessage()) + "</div>");
    }

    private String kpi(String label, String value) { return "<div class='kpi'><div class='label'>" + esc(label) + "</div><div class='value'>" + esc(value) + "</div></div>"; }

    private String scenarios(RunStatus status) {
        StringBuilder sb = new StringBuilder();
        for (ScenarioResult s : status.getScenarios()) {
            boolean pass = "PASSED".equalsIgnoreCase(s.getStatus());
            sb.append("<section class='panel'><div class='scenario-head'><div><div class='scenario-title'>")
                    .append(esc(s.getId())).append(" - ").append(esc(s.getName())).append("</div><div class='url'>")
                    .append(esc(s.getUrl())).append("</div><div class='small'>Duration: ").append(s.getDurationMs()).append(" ms</div></div>")
                    .append("<span class='pill ").append(pass ? "pass" : "fail").append("'>").append(esc(s.getStatus())).append("</span></div>");
            sb.append("<table><thead><tr><th>#</th><th>Instruction</th><th>Plan</th><th>MCP Tool</th><th>Arguments</th><th>Evidence</th><th>Status</th><th>ms</th><th>Screenshot</th><th>Error</th></tr></thead><tbody>");
            for (StepResult st : s.getSteps()) {
                boolean stepPass = "PASSED".equalsIgnoreCase(st.getStatus());
                sb.append("<tr><td>").append(st.getStepNo()).append("</td><td>").append(esc(st.getInstruction())).append("</td>")
                        .append("<td><b>").append(esc(st.getPlanSource())).append("</b><div class='code'>").append(esc(st.getActionJson())).append("</div></td>")
                        .append("<td><b>").append(esc(st.getToolName())).append("</b></td>")
                        .append("<td><div class='code'>").append(esc(st.getToolArguments())).append("</div></td>")
                        .append("<td class='evidence'>").append(esc(st.getEvidence())).append("</td>")
                        .append("<td><span class='pill ").append(stepPass ? "pass" : "fail").append("'>").append(esc(st.getStatus())).append("</span></td>")
                        .append("<td>").append(st.getDurationMs()).append("</td>")
                        .append("<td>").append(screenshotLink(st)).append("</td>")
                        .append("<td class='err'>").append(esc(st.getErrorMessage())).append("</td></tr>");
            }
            sb.append("</tbody></table></section>");
        }
        return sb.toString();
    }

    private String screenshotLink(StepResult step) {
        if (step.getScreenshot() == null || step.getScreenshot().isBlank()) return "";
        return "<a class='shot' href='screenshots/" + esc(step.getScreenshot()) + "' target='_blank'>view</a>";
    }

    private void writeExcel(RunStatus status, Path path) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet sheet = wb.createSheet("Execution Results");
            String[] headers = {"Scenario ID", "Scenario Name", "Step", "Instruction", "Plan Source", "MCP Tool", "Status", "Duration ms", "Evidence", "Screenshot", "Error"};
            Row header = sheet.createRow(0);
            CellStyle headerStyle = wb.createCellStyle();
            Font hf = wb.createFont(); hf.setBold(true); hf.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(hf); headerStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex()); headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            for (int i = 0; i < headers.length; i++) { Cell c = header.createCell(i); c.setCellValue(headers[i]); c.setCellStyle(headerStyle); }
            int r = 1;
            for (ScenarioResult s : status.getScenarios()) {
                for (StepResult st : s.getSteps()) {
                    Row row = sheet.createRow(r++);
                    row.createCell(0).setCellValue(s.getId());
                    row.createCell(1).setCellValue(s.getName());
                    row.createCell(2).setCellValue(st.getStepNo());
                    row.createCell(3).setCellValue(st.getInstruction());
                    row.createCell(4).setCellValue(st.getPlanSource());
                    row.createCell(5).setCellValue(st.getToolName());
                    row.createCell(6).setCellValue(st.getStatus());
                    row.createCell(7).setCellValue(st.getDurationMs());
                    row.createCell(8).setCellValue(st.getEvidence());
                    row.createCell(9).setCellValue(st.getScreenshot());
                    row.createCell(10).setCellValue(st.getErrorMessage());
                }
            }
            for (int i = 0; i < headers.length; i++) sheet.autoSizeColumn(i);
            try (FileOutputStream out = new FileOutputStream(path.toFile())) { wb.write(out); }
        }
    }

    private void zipScreenshots(Path screenshotDir, Path zipPath) throws Exception {
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zipPath))) {
            if (!Files.exists(screenshotDir)) return;
            try (var stream = Files.list(screenshotDir)) {
                for (Path p : stream.filter(Files::isRegularFile).toList()) {
                    zos.putNextEntry(new ZipEntry(p.getFileName().toString()));
                    Files.copy(p, zos);
                    zos.closeEntry();
                }
            }
        }
    }

    private String fmt(java.time.Instant i) { return i == null ? "" : DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault()).format(i); }
    private String esc(Object v) { return v == null ? "" : String.valueOf(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;"); }
}
