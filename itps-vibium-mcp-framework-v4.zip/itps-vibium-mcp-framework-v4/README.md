# ITPS VIBIUM Framework - MCP Edition V4

Java Spring Boot based test execution UI that drives the browser through **Vibium MCP**. No Selenium dependency and no Selenium fallback.

## Why V4

V3 could mark a step passed when the MCP call returned success even if the page did not really change. V4 removes that fake-pass risk by using a closed-loop execution model:

1. Observe page with Vibium MCP `browser_map`.
2. Probe DOM using Vibium MCP `browser_evaluate` when available.
3. Send instruction + map + DOM evidence to LLM.
4. Execute only Vibium MCP tools.
5. Verify DOM/text/URL/screenshot evidence after action.
6. Capture screenshots and produce a professional HTML report.

## Machine prerequisite

Your machine already confirmed this command works:

```powershell
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd mcp
```

`application.properties` is configured for that default path:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
itps.vibium.skip-browser-download=true
```

Do not manually keep `vibium.cmd mcp` running while the app runs. The Java app starts MCP itself.

## Run locally

```cmd
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Recommended UI settings for debugging

- Use LLM agent planning: ON
- Headless execution: OFF
- Continue on failure: ON
- Strict evidence validation: ON
- Screenshot mode: All steps
- Retry count: 1 or 2

## Sample data

Use:

```text
samples/itps-vibium-mcp-scenarios-v4.xlsx
```

The sample uses better step wording and test data placeholders:

```text
Click the search icon | Enter {{searchText}} in the search field | Click {{searchText}} from the search results | Click {{alertTab}} tab | Click {{flowTab}} tab | Click {{camTab}} tab
```

with:

```text
data.searchText = NEW-IP
data.alertTab = Alert
data.flowTab = Flow
data.camTab = CAM
```

## Reports generated

After execution:

```text
target/itps-vibium-runs/<run-id>/
  report.html
  report.json
  report.xlsx
  screenshots.zip
  screenshots/
  mcp-tools.json
  mcp-transcript.json
  mcp-process.log
```

If normal report generation fails, V4 writes a fallback `report.html` instead of returning a blank/missing report.

## Troubleshooting

### App launches but actions do not happen

Open the generated `mcp-transcript.json` and check the exact MCP tool arguments. V4 also fails the step if a click/fill/select returns success but no DOM/text/URL/screenshot evidence changes.

### Screenshots are missing

V4 starts MCP with `--screenshot-dir target/itps-vibium-runs/<run-id>/screenshots` and also tries to decode inline image content returned by the MCP screenshot tool.

### LLM chooses poor selector

Use clearer step wording and test data placeholders. Prefer:

```text
Click the search icon
Enter NEW-IP in the search field
Click NEW-IP from the search results
```

instead of:

```text
click NEW-IP capsule
```

