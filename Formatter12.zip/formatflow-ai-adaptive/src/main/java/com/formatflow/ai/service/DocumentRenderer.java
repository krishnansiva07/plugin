package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Safelist;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DocumentRenderer {

    private final IconCatalog iconCatalog;

    public DocumentRenderer(IconCatalog iconCatalog) {
        this.iconCatalog = iconCatalog;
    }

    public FormattedDocument compose(List<SourceBlock> blocks,
                                     List<PlanItem> plan,
                                     List<SemanticSection> semanticSections,
                                     String plainContent,
                                     String audience,
                                     String purpose,
                                     String outputFormat,
                                     String operation,
                                     boolean enhanced,
                                     String emailSubject) {
        Map<String, PlanItem> byId = plan.stream().collect(Collectors.toMap(PlanItem::id, Function.identity()));
        List<DocumentBlock> output = new ArrayList<>();
        String title = "";

        for (SourceBlock source : blocks) {
            if (source.blank()) {
                output.add(new DocumentBlock(source.id(), "", BlockType.SPACER, "NONE", "", "NONE", "NONE"));
                continue;
            }

            PlanItem p = byId.get(source.id());
            if (p == null) throw new IllegalStateException("Missing formatting metadata for " + source.id());

            BlockType type = safeType(p.type());
            if (source.codeLike()) type = BlockType.CODE;
            if (source.bulletLike() && type == BlockType.PARAGRAPH) type = BlockType.BULLET;

            String iconKey = iconCatalog.normalize(p.iconKey());
            String icon = iconCatalog.symbol(iconKey);
            String bullet = type == BlockType.BULLET && "NONE".equalsIgnoreCase(p.bulletStyle()) ? "CHECK" : p.bulletStyle();

            DocumentBlock block = new DocumentBlock(
                    source.id(), source.text(), type, iconKey, icon,
                    p.emphasis() == null ? "NONE" : p.emphasis(),
                    bullet == null ? "NONE" : bullet
            );
            output.add(block);
            if (title.isBlank() && type == BlockType.TITLE) title = source.text();
        }

        if (title.isBlank()) {
            title = output.stream()
                    .filter(b -> b.type() == BlockType.HEADING)
                    .map(DocumentBlock::text)
                    .findFirst()
                    .orElse("");
        }

        return new FormattedDocument(
                title,
                output,
                semanticSections == null ? List.of() : semanticSections,
                plainContent,
                audience,
                purpose,
                outputFormat,
                operation,
                enhanced,
                emailSubject
        );
    }

    public String previewHtml(FormattedDocument document) {
        String format = safeUpper(document.outputFormat());

        // The preview must reflect the selected destination. In particular,
        // Confluence preview uses the same portable structures that Copy uses,
        // and Markdown preview shows the exact Markdown text that will be copied.
        if ("CONFLUENCE".equals(format)) {
            return """
                    <section class="document-preview target-preview">
                      <div class="preview-meta"><span>CONFLUENCE</span><span>Copy-safe native layout</span></div>
                      <div class="confluence-preview">%s</div>
                    </section>
                    """.formatted(confluencePortableHtml(document));
        }

        if ("MARKDOWN".equals(format)) {
            return """
                    <section class="document-preview target-preview">
                      <div class="preview-meta"><span>MARKDOWN</span><span>Raw output</span></div>
                      <pre class="raw-markdown">%s</pre>
                    </section>
                    """.formatted(esc(markdown(document)));
        }

        String meta = """
                <div class="preview-meta">
                  <span>%s</span><span>%s</span><span>%s</span><span>%s</span>
                </div>
                """.formatted(
                esc(document.outputFormat()), esc(document.audience()), esc(document.purpose()), esc(document.operation())
        );

        String body = bodyFragment(document);
        if ("EMAIL".equals(format)) {
            String subject = document.emailSubject() == null || document.emailSubject().isBlank()
                    ? "<span class=\"subject-placeholder\">Subject not added</span>"
                    : esc(document.emailSubject());
            return """
                    <section class="email-preview">%s
                      <div class="email-header"><strong>Subject:</strong> %s</div>
                      <div class="email-body">%s</div>
                    </section>
                    """.formatted(meta, subject, body);
        }
        return "<section class=\"document-preview\">" + meta + body + "</section>";
    }

    /**
     * HTML written to the clipboard. This is intentionally target-specific and
     * is NOT the styled preview fragment.
     */
    public String copyHtml(FormattedDocument document) {
        return switch (safeUpper(document.outputFormat())) {
            case "CONFLUENCE" -> confluencePortableHtml(document);
            case "MARKDOWN" -> "";
            case "EMAIL" -> emailPortableHtml(document);
            case "HTML" -> bodyFragment(document);
            default -> portableRichHtml(document);
        };
    }

    /**
     * Plain-text clipboard fallback. Markdown gets actual Markdown, not the
     * original source string.
     */
    public String copyText(FormattedDocument document) {
        return switch (safeUpper(document.outputFormat())) {
            case "MARKDOWN" -> markdown(document);
            case "HTML" -> standaloneHtml(document, false);
            default -> document.plainContent() == null ? "" : document.plainContent();
        };
    }

    public String standaloneHtml(FormattedDocument document, boolean email) {
        String body = bodyFragment(document);
        String title = document.title() == null || document.title().isBlank() ? "FormatFlow AI" : document.title();
        String subject = document.emailSubject() == null ? "" : document.emailSubject();
        String emailHeader = email
                ? "<div class=\"email-export-head\"><strong>Subject:</strong> " + esc(subject) + "</div>"
                : "";

        return """
                <!doctype html>
                <html lang="en">
                <head>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <title>%s</title>
                  <style>
                    :root{--g:#008542;--gd:#006b36;--soft:#eef8f2;--soft2:#f7fbf8;--border:#cfe4d7;--text:#1f2d25;--muted:#687a70}
                    *{box-sizing:border-box}body{margin:0;background:#f5f8f6;color:var(--text);font-family:Arial,Helvetica,sans-serif;line-height:1.55}
                    .page{max-width:1080px;margin:28px auto;background:#fff;border:1px solid #dde8e1;border-radius:14px;overflow:hidden;box-shadow:0 8px 30px rgba(0,80,40,.08)}
                    .top-accent{height:8px;background:var(--g)}.content{padding:34px 42px}.ff-title,.ff-heading,.semantic-title{color:var(--gd);font-weight:750}.ff-title{font-size:28px;margin:4px 0 22px}.ff-heading{font-size:18px;margin:22px 0 9px}
                    .ff-paragraph{margin:7px 0}.ff-bullet{display:flex;gap:9px;margin:7px 0;padding-left:5px}.ff-bullet .bullet{color:var(--g);font-weight:800;min-width:18px}
                    .ff-code{font-family:Consolas,monospace;background:#f3f6f4;border-left:4px solid var(--g);padding:8px 11px;white-space:pre-wrap;overflow-wrap:anywhere;margin:4px 0}
                    .ff-callout{background:var(--soft);border:1px solid var(--border);border-left:4px solid var(--g);padding:11px 13px;border-radius:7px;margin:10px 0}.ff-quote{border-left:3px solid #8ebaa1;margin:10px 0;padding:8px 12px;color:#50675a;font-style:italic}
                    .icon{display:inline-block;min-width:28px;margin-right:5px}.ff-spacer{height:10px}.strong{font-weight:700}.muted{color:var(--muted)}.highlight{background:#f3fbf6;border-radius:4px;padding:1px 3px}
                    .email-export-head{background:var(--soft);border-bottom:1px solid var(--border);padding:16px 42px;color:var(--gd)}
                    .semantic-section{margin:20px 0 26px}.semantic-title{font-size:18px;margin:0 0 12px;display:flex;align-items:center;gap:7px}.layout-badge{font-size:9px;color:var(--gd);background:var(--soft);border:1px solid var(--border);padding:3px 6px;border-radius:999px;margin-left:auto;text-transform:uppercase;letter-spacing:.04em}
                    .semantic-table{width:100%%;border-collapse:collapse;margin:8px 0}.semantic-table th{background:var(--gd);color:#fff;text-align:left;padding:9px 11px;font-size:12px}.semantic-table td{border:1px solid #dce8e1;padding:9px 11px;vertical-align:top;font-size:12px}.semantic-table tr:nth-child(even) td{background:#fbfdfc}
                    .flow{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 0}.flow-node{min-width:120px;max-width:210px;padding:12px 14px;background:#fff;border:1.5px solid var(--g);border-radius:10px;text-align:center;font-weight:700;color:var(--gd);box-shadow:0 3px 10px rgba(0,100,50,.06)}.flow-arrow{display:flex;flex-direction:column;align-items:center;color:var(--g);font-weight:800}.flow-label{font-size:9px;color:var(--muted);font-weight:500;max-width:120px;text-align:center}.flow-arrow-symbol{font-size:22px}
                    .timeline{border-left:3px solid var(--g);padding-left:17px;margin-left:8px}.timeline-item{position:relative;padding:2px 0 16px}.timeline-item:before{content:'';position:absolute;left:-24px;top:7px;width:11px;height:11px;border-radius:50%%;background:var(--g);border:2px solid #fff;box-shadow:0 0 0 1px var(--g)}
                    .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.semantic-card{border:1px solid var(--border);border-radius:10px;padding:13px;background:var(--soft2)}.semantic-card .label{font-weight:750;color:var(--gd)}.semantic-card .value{margin-top:5px}.semantic-card .status{display:inline-block;margin-top:7px;background:#fff;border:1px solid var(--border);border-radius:999px;padding:3px 7px;font-size:10px;color:var(--gd)}
                    .checklist{display:grid;gap:7px}.check-item{display:flex;gap:9px;align-items:flex-start}.check{color:var(--g);font-weight:900;font-size:16px}.callout-grid{display:grid;gap:8px}.semantic-callout{background:var(--soft);border:1px solid var(--border);border-left:4px solid var(--g);padding:11px 13px;border-radius:8px}
                    @media(max-width:700px){.page{margin:0;border:0;border-radius:0}.content{padding:22px}.ff-title{font-size:23px}.flow{align-items:stretch}.flow-arrow{width:100%%}.flow-arrow-symbol{transform:rotate(90deg)}.semantic-table{font-size:11px}}
                  </style>
                </head>
                <body><main class="page"><div class="top-accent"></div>%s<div class="content">%s</div></main></body>
                </html>
                """.formatted(esc(title), emailHeader, body);
    }

    public String confluenceHtml(FormattedDocument document) {
        return confluencePortableHtml(document);
    }

    /**
     * Confluence Cloud copy/paste target. Confluence does not understand our
     * application CSS classes. Use only editor-friendly HTML elements whose
     * structure can survive clipboard sanitization: headings, paragraphs,
     * lists, tables, pre/code and blockquotes.
     */
    public String confluencePortableHtml(FormattedDocument document) {
        String html = hasSemantic(document)
                ? semanticPortableFragment(document, true)
                : portableBlocks(document.blocks());

        Safelist safe = Safelist.relaxed()
                .addTags("h1", "h2", "h3", "h4", "pre", "code", "blockquote",
                        "table", "thead", "tbody", "tr", "th", "td", "ul", "ol", "li",
                        "p", "strong", "em", "br")
                .preserveRelativeLinks(true);
        return Jsoup.clean(html, safe);
    }

    private String portableRichHtml(FormattedDocument document) {
        String html = hasSemantic(document)
                ? semanticPortableFragment(document, false)
                : portableBlocks(document.blocks());
        return Jsoup.clean(html, Safelist.relaxed()
                .addTags("h1", "h2", "h3", "h4", "pre", "code", "blockquote",
                        "table", "thead", "tbody", "tr", "th", "td", "ul", "ol", "li",
                        "p", "strong", "em", "br")
                .preserveRelativeLinks(true));
    }

    private String emailPortableHtml(FormattedDocument document) {
        String subject = document.emailSubject() == null ? "" : document.emailSubject();
        return "<p><strong>Subject:</strong> " + esc(subject) + "</p>"
                + portableRichHtml(document);
    }

    private String semanticPortableFragment(FormattedDocument document, boolean confluence) {
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder html = new StringBuilder();

        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType type = layout(section);
            String title = (type == SemanticLayoutType.TEXT || type == SemanticLayoutType.CODE_GROUP)
                    ? "" : semanticTitle(section);

            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                html.append("<h2>")
                        .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                        .append(esc(title))
                        .append("</h2>");
            }

            switch (type) {
                case TABLE, COMPARISON, STATUS, KPI -> html.append(portableTable(section));
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> html.append(portableFlow(section));
                case TIMELINE -> html.append(portableTimeline(section));
                case CHECKLIST -> html.append(portableChecklist(section));
                case CALLOUT -> html.append(portableCallout(section));
                case TEXT, CODE_GROUP -> html.append(portableBlocks(referencedBlocks(section, blocks)));
            }
        }
        return html.toString();
    }

    private String portableTable(SemanticSection section) {
        if (safe(section.rows()).isEmpty() && !safe(section.items()).isEmpty()) {
            // defensive representation if a STATUS/KPI section reaches this renderer
            StringBuilder table = new StringBuilder("<table><thead><tr><th>Item</th><th>Details</th></tr></thead><tbody>");
            for (SemanticItem item : safe(section.items())) {
                String first = nonblank(item.label(), item.value(), item.status());
                String rest = remainingItem(item, first);
                table.append("<tr><td>").append(esc(first)).append("</td><td>").append(esc(rest)).append("</td></tr>");
            }
            return table.append("</tbody></table>").toString();
        }

        StringBuilder html = new StringBuilder("<table><thead><tr>");
        int maxCells = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < maxCells) columns.add(columns.isEmpty() ? "Item" : "Details");
        for (int i = 0; i < maxCells; i++) html.append("<th>").append(esc(columns.get(i))).append("</th>");
        html.append("</tr></thead><tbody>");
        for (SemanticRow row : safe(section.rows())) {
            html.append("<tr>");
            List<SemanticValue> cells = safe(row.cells());
            for (int i = 0; i < maxCells; i++) {
                html.append("<td>").append(i < cells.size() ? esc(cells.get(i).text()) : "").append("</td>");
            }
            html.append("</tr>");
        }
        return html.append("</tbody></table>").toString();
    }

    private String portableFlow(SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        if (nodes.isEmpty()) return "";
        StringBuilder html = new StringBuilder("<ol>");
        for (SemanticNode node : nodes) {
            String symbol = iconCatalog.symbol(node.iconKey());
            html.append("<li>")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(node.text()))
                    .append("</li>");
        }
        return html.append("</ol>").toString();
    }

    private String portableTimeline(SemanticSection section) {
        StringBuilder html = new StringBuilder("<ol>");
        for (SemanticItem item : safe(section.items())) {
            html.append("<li>").append(esc(joinItem(item))).append("</li>");
        }
        return html.append("</ol>").toString();
    }

    private String portableChecklist(SemanticSection section) {
        StringBuilder html = new StringBuilder("<ul>");
        for (SemanticItem item : safe(section.items())) {
            html.append("<li>✓ ").append(esc(joinItem(item))).append("</li>");
        }
        return html.append("</ul>").toString();
    }

    private String portableCallout(SemanticSection section) {
        StringBuilder html = new StringBuilder();
        for (SemanticItem item : safe(section.items())) {
            html.append("<blockquote>⚠ ").append(esc(joinItem(item))).append("</blockquote>");
        }
        return html.toString();
    }

    private String portableBlocks(List<DocumentBlock> blocks) {
        StringBuilder html = new StringBuilder();
        boolean listOpen = false;

        for (DocumentBlock block : blocks) {
            if (block.type() != BlockType.BULLET && listOpen) {
                html.append("</ul>");
                listOpen = false;
            }

            String icon = block.iconSymbol().isBlank() ? "" : esc(block.iconSymbol()) + " ";
            switch (block.type()) {
                case TITLE -> html.append("<h1>").append(icon).append(esc(block.text())).append("</h1>");
                case HEADING -> html.append("<h2>").append(icon).append(esc(block.text())).append("</h2>");
                case BULLET -> {
                    if (!listOpen) {
                        html.append("<ul>");
                        listOpen = true;
                    }
                    html.append("<li>✓ ").append(esc(stripBullet(block.text()))).append("</li>");
                }
                case CODE -> html.append("<pre><code>").append(esc(block.text())).append("</code></pre>");
                case CALLOUT, QUOTE -> html.append("<blockquote>").append(icon).append(esc(block.text())).append("</blockquote>");
                case SPACER -> html.append("<br>");
                default -> html.append("<p>").append(esc(block.text())).append("</p>");
            }
        }

        if (listOpen) html.append("</ul>");
        return html.toString();
    }

    public String markdown(FormattedDocument document) {
        if (!hasSemantic(document)) return markdownBlocks(document.blocks());
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder out = new StringBuilder();
        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType sectionLayout = layout(section);
            String title = (sectionLayout == SemanticLayoutType.TEXT || sectionLayout == SemanticLayoutType.CODE_GROUP) ? "" : semanticTitle(section);
            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                out.append("## ").append(symbol.isBlank() ? "" : symbol + " ").append(title).append("\n\n");
            }
            switch (sectionLayout) {
                case TABLE, COMPARISON -> appendMarkdownTable(out, section);
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> appendMarkdownFlow(out, section);
                case TIMELINE -> {
                    for (SemanticItem item : safe(section.items())) out.append("- ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                case STATUS, KPI -> {
                    for (SemanticItem item : safe(section.items())) out.append("- **").append(nonblank(item.label(), item.value(), item.status())).append("**")
                            .append(restItem(item)).append("\n");
                    out.append("\n");
                }
                case CHECKLIST -> {
                    for (SemanticItem item : safe(section.items())) out.append("- [x] ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                case CALLOUT -> {
                    for (SemanticItem item : safe(section.items())) out.append("> ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                default -> appendMarkdownReferencedBlocks(out, section, blocks);
            }
        }
        return out.toString().stripTrailing() + "\n";
    }

    private String bodyFragment(FormattedDocument document) {
        return hasSemantic(document) ? semanticFragment(document, false) : blockFragment(document.blocks());
    }

    private boolean hasSemantic(FormattedDocument document) {
        return document.semanticSections() != null && !document.semanticSections().isEmpty();
    }

    private String semanticFragment(FormattedDocument document, boolean confluence) {
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder html = new StringBuilder();
        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType layout = layout(section);
            html.append("<section class=\"semantic-section\" data-layout=\"").append(layout.name()).append("\">");
            String title = (layout == SemanticLayoutType.TEXT || layout == SemanticLayoutType.CODE_GROUP) ? "" : semanticTitle(section);
            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                html.append("<div class=\"semantic-title\">")
                        .append(symbol.isBlank() ? "" : "<span>" + esc(symbol) + "</span>")
                        .append("<span>").append(esc(title)).append("</span>");
                if (!confluence) html.append("<span class=\"layout-badge\">").append(layout.name()).append("</span>");
                html.append("</div>");
            }

            switch (layout) {
                case TABLE, COMPARISON -> html.append(tableHtml(section));
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> html.append(flowHtml(section));
                case TIMELINE -> html.append(timelineHtml(section));
                case STATUS, KPI -> html.append(cardsHtml(section));
                case CHECKLIST -> html.append(checklistHtml(section));
                case CALLOUT -> html.append(calloutHtml(section));
                case TEXT, CODE_GROUP -> html.append(blockFragment(referencedBlocks(section, blocks)));
            }
            html.append("</section>");
        }
        return html.toString();
    }

    private String tableHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<table class=\"semantic-table\"><thead><tr>");
        int maxCells = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < maxCells) columns.add(columns.size() == 0 ? "Item" : "Details");
        for (int i = 0; i < maxCells; i++) html.append("<th>").append(esc(columns.get(i))).append("</th>");
        html.append("</tr></thead><tbody>");
        for (SemanticRow row : safe(section.rows())) {
            html.append("<tr>");
            List<SemanticValue> cells = safe(row.cells());
            for (int i = 0; i < maxCells; i++) {
                String text = i < cells.size() ? cells.get(i).text() : "";
                html.append("<td>").append(esc(text)).append("</td>");
            }
            html.append("</tr>");
        }
        return html.append("</tbody></table>").toString();
    }

    private String flowHtml(SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeFrom = new LinkedHashMap<>();
        for (SemanticEdge edge : safe(section.edges())) edgeFrom.putIfAbsent(edge.from(), edge);
        StringBuilder html = new StringBuilder("<div class=\"flow\">");
        for (int i = 0; i < nodes.size(); i++) {
            SemanticNode node = nodes.get(i);
            String symbol = iconCatalog.symbol(node.iconKey());
            html.append("<div class=\"flow-node\">")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(node.text())).append("</div>");
            if (i < nodes.size() - 1) {
                SemanticEdge edge = edgeFrom.get(node.id());
                String label = edge == null ? "" : edge.label();
                html.append("<div class=\"flow-arrow\">")
                        .append(label == null || label.isBlank() ? "" : "<span class=\"flow-label\">" + esc(label) + "</span>")
                        .append("<span class=\"flow-arrow-symbol\">→</span></div>");
            }
        }
        return html.append("</div>").toString();
    }

    private String timelineHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"timeline\">");
        for (SemanticItem item : safe(section.items())) {
            html.append("<div class=\"timeline-item\"><strong>").append(esc(nonblank(item.value(), item.status(), item.label())))
                    .append("</strong>");
            String rest = remainingItem(item, nonblank(item.value(), item.status(), item.label()));
            if (!rest.isBlank()) html.append("<div>").append(esc(rest)).append("</div>");
            html.append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String cardsHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"cards\">");
        for (SemanticItem item : safe(section.items())) {
            String symbol = iconCatalog.symbol(item.iconKey());
            html.append("<div class=\"semantic-card\">");
            String label = nonblank(item.label(), item.value(), item.status());
            html.append("<div class=\"label\">").append(symbol.isBlank() ? "" : esc(symbol) + " ").append(esc(label)).append("</div>");
            if (!item.value().isBlank() && !item.value().equals(label)) html.append("<div class=\"value\">").append(esc(item.value())).append("</div>");
            if (!item.status().isBlank() && !item.status().equals(label)) html.append("<div class=\"status\">").append(esc(item.status())).append("</div>");
            html.append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String checklistHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"checklist\">");
        for (SemanticItem item : safe(section.items())) {
            html.append("<div class=\"check-item\"><span class=\"check\">✓</span><span>")
                    .append(esc(joinItem(item))).append("</span></div>");
        }
        return html.append("</div>").toString();
    }

    private String calloutHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"callout-grid\">");
        for (SemanticItem item : safe(section.items())) {
            String symbol = iconCatalog.symbol(item.iconKey());
            html.append("<div class=\"semantic-callout\">")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(joinItem(item))).append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String blockFragment(List<DocumentBlock> blocks) {
        StringBuilder html = new StringBuilder();
        for (DocumentBlock block : blocks) {
            String emphasis = switch (safeUpper(block.emphasis())) {
                case "STRONG" -> " strong";
                case "MUTED" -> " muted";
                case "HIGHLIGHT" -> " highlight";
                default -> "";
            };
            String icon = block.iconSymbol().isBlank() ? "" : "<span class=\"icon\">" + esc(block.iconSymbol()) + "</span>";
            switch (block.type()) {
                case TITLE -> html.append("<div class=\"ff-title").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case HEADING -> html.append("<div class=\"ff-heading").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case BULLET -> html.append("<div class=\"ff-bullet").append(emphasis).append("\"><span class=\"bullet\">")
                        .append(bulletSymbol(block.bulletStyle())).append("</span><span>").append(esc(stripBullet(block.text()))).append("</span></div>");
                case CODE -> html.append("<div class=\"ff-code").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
                case CALLOUT -> html.append("<div class=\"ff-callout").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case QUOTE -> html.append("<div class=\"ff-quote").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
                case SPACER -> html.append("<div class=\"ff-spacer\"></div>");
                default -> html.append("<div class=\"ff-paragraph").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
            }
        }
        return html.toString();
    }

    private String markdownBlocks(List<DocumentBlock> blocks) {
        StringBuilder out = new StringBuilder();
        for (DocumentBlock block : blocks) {
            String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + " ";
            switch (block.type()) {
                case TITLE -> out.append("# ").append(icon).append(block.text()).append("\n\n");
                case HEADING -> out.append("## ").append(icon).append(block.text()).append("\n\n");
                case BULLET -> out.append("- ✓ ").append(stripBullet(block.text())).append("\n");
                case CODE -> out.append("```\n").append(block.text()).append("\n```\n\n");
                case CALLOUT, QUOTE -> out.append("> ").append(block.text()).append("\n\n");
                case SPACER -> out.append("\n");
                default -> out.append(block.text()).append("\n\n");
            }
        }
        return out.toString().stripTrailing() + "\n";
    }

    private void appendMarkdownReferencedBlocks(StringBuilder out, SemanticSection section, Map<String, DocumentBlock> blocks) {
        out.append(markdownBlocks(referencedBlocks(section, blocks))).append("\n");
    }

    private void appendMarkdownTable(StringBuilder out, SemanticSection section) {
        int count = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < count) columns.add(columns.isEmpty() ? "Item" : "Details");
        out.append("| ").append(String.join(" | ", columns.subList(0, count))).append(" |\n");
        out.append("|").append(" --- |".repeat(count)).append("\n");
        for (SemanticRow row : safe(section.rows())) {
            List<String> cells = safe(row.cells()).stream().map(c -> c.text().replace("|", "\\|")).toList();
            List<String> padded = new ArrayList<>(cells);
            while (padded.size() < count) padded.add("");
            out.append("| ").append(String.join(" | ", padded.subList(0, count))).append(" |\n");
        }
        out.append("\n");
    }

    private void appendMarkdownFlow(StringBuilder out, SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        for (int i = 0; i < nodes.size(); i++) {
            if (i > 0) out.append(" → ");
            out.append(nodes.get(i).text());
        }
        out.append("\n\n");
    }


    /**
     * Sanitizes the free-form model output into a portable semantic HTML fragment.
     * The model has editorial freedom, but executable/unsafe markup never reaches
     * the preview or clipboard.
     */
    public String sanitizeFreeformHtml(String rawHtml) {
        String candidate = normalizeFreeformResponse(rawHtml);
        Safelist safelist = Safelist.none()
                .addTags("h1", "h2", "h3", "h4", "p", "ul", "ol", "li",
                        "table", "thead", "tbody", "tr", "th", "td",
                        "blockquote", "pre", "code", "strong", "em", "br", "hr", "a")
                .addAttributes("a", "href", "title")
                .addProtocols("a", "href", "http", "https", "mailto")
                .preserveRelativeLinks(true);
        String cleaned = Jsoup.clean(candidate, "", safelist, new Document.OutputSettings().prettyPrint(false));
        return cleaned.isBlank() ? "<p>" + esc(rawHtml == null ? "" : rawHtml) + "</p>" : cleaned;
    }

    /**
     * Produces the canonical destination fragment used by BOTH preview and copy.
     * Confluence used to render an unstyled preview but a separately-decorated
     * clipboard tree, which made the two paths drift.  The Confluence branch now
     * normalizes structure once and reuses that exact fragment everywhere.
     */
    public String prepareDestinationHtml(String sanitizedHtml, String outputFormat) {
        String format = safeUpper(outputFormat);
        if ("CONFLUENCE".equals(format)) return canonicalConfluenceHtml(sanitizedHtml);
        return sanitizedHtml == null ? "" : sanitizedHtml;
    }

    public String freeformPreviewHtml(String preparedHtml, String outputFormat, String emailSubject) {
        String format = safeUpper(outputFormat);
        if ("EMAIL".equals(format)) {
            String subject = emailSubject == null || emailSubject.isBlank()
                    ? "<span class=\"subject-placeholder\">No subject provided</span>"
                    : esc(emailSubject);
            return "<div class=\"email-freeform-preview\"><div class=\"email-header\"><strong>Subject:</strong> "
                    + subject + "</div><div class=\"email-body\">" + preparedHtml + "</div></div>";
        }
        if ("CONFLUENCE".equals(format)) {
            String canonical = isPreparedConfluenceHtml(preparedHtml)
                    ? preparedHtml : canonicalConfluenceHtml(preparedHtml);
            return "<div class=\"confluence-preview\">" + canonical + "</div>";
        }
        return "<div class=\"html-freeform-preview\">" + preparedHtml + "</div>";
    }

    public String freeformCopyHtml(String preparedHtml, String outputFormat) {
        String format = safeUpper(outputFormat);
        if ("CONFLUENCE".equals(format)) {
            return isPreparedConfluenceHtml(preparedHtml)
                    ? preparedHtml : canonicalConfluenceHtml(preparedHtml);
        }
        if ("EMAIL".equals(format)) return decorateEmailHtml(preparedHtml);
        if ("HTML".equals(format)) return decoratePortableHtml(preparedHtml);
        if ("POWERPOINT".equals(format)) return preparedHtml;
        return preparedHtml;
    }

    public String freeformCopyText(String sanitizedHtml) {
        Document doc = Jsoup.parseBodyFragment(sanitizedHtml == null ? "" : sanitizedHtml);
        StringBuilder out = new StringBuilder();
        for (Element child : doc.body().children()) appendPlainText(child, out, 0);
        return out.toString().replaceAll("[ \t]+\n", "\n")
                .replaceAll("\n{3,}", "\n\n").trim();
    }

    private String normalizeFreeformResponse(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.startsWith("```")) {
            value = value.replaceFirst("^```(?:html|xml)?\\s*", "")
                    .replaceFirst("\\s*```$", "").trim();
        }
        // If the model returned a full document, retain only the body fragment.
        if (value.matches("(?is).*<(?:html|body)(?:\\s|>).*")) {
            return Jsoup.parse(value).body().html();
        }
        // Defensive fallback if a model ignores the HTML-only instruction.
        if (!value.matches("(?is).*<\\s*(?:h[1-4]|p|ul|ol|li|table|blockquote|pre|strong|em|a|hr|br)\\b.*")) {
            return plainOrMarkdownToHtml(value);
        }
        return value;
    }

    private String plainOrMarkdownToHtml(String value) {
        String[] lines = (value == null ? "" : value).split("\\R", -1);
        StringBuilder html = new StringBuilder();
        boolean ul = false;
        boolean ol = false;
        boolean code = false;
        StringBuilder codeText = new StringBuilder();

        for (int i = 0; i < lines.length; i++) {
            String rawLine = lines[i];
            String line = rawLine.trim();

            if (line.startsWith("```")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                if (!code) {
                    code = true;
                    codeText.setLength(0);
                } else {
                    html.append("<pre><code>").append(esc(codeText.toString().stripTrailing())).append("</code></pre>");
                    code = false;
                }
                continue;
            }
            if (code) {
                if (!codeText.isEmpty()) codeText.append('\n');
                codeText.append(rawLine);
                continue;
            }

            // Markdown table recovery.  This matters when a model ignores the
            // HTML-only instruction: table rows remain real Confluence tables
            // instead of becoming pipe-delimited paragraphs.
            if (looksLikeMarkdownTableHeader(lines, i)) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                List<String> headers = splitMarkdownTableRow(lines[i]);
                html.append("<table><thead><tr>");
                for (String header : headers) html.append("<th>").append(markdownInline(header)).append("</th>");
                html.append("</tr></thead><tbody>");
                i += 2; // consume header + separator, then data rows below
                while (i < lines.length && looksLikeMarkdownTableRow(lines[i])) {
                    List<String> cells = splitMarkdownTableRow(lines[i]);
                    html.append("<tr>");
                    int width = Math.max(headers.size(), cells.size());
                    for (int c = 0; c < width; c++) {
                        html.append("<td>").append(c < cells.size() ? markdownInline(cells.get(c)) : "").append("</td>");
                    }
                    html.append("</tr>");
                    i++;
                }
                html.append("</tbody></table>");
                i--; // let the for-loop process the first non-table line
                continue;
            }

            if (line.isBlank()) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                continue;
            }
            if (line.startsWith("### ")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<h3>").append(markdownInline(line.substring(4))).append("</h3>");
            } else if (line.startsWith("## ")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<h2>").append(markdownInline(line.substring(3))).append("</h2>");
            } else if (line.startsWith("# ")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<h1>").append(markdownInline(line.substring(2))).append("</h1>");
            } else if (line.matches("^[-*•]\\s+.+")) {
                if (ol) { html.append("</ol>"); ol = false; }
                if (!ul) { html.append("<ul>"); ul = true; }
                html.append("<li>").append(markdownInline(line.replaceFirst("^[-*•]\\s+", ""))).append("</li>");
            } else if (line.matches("^\\d+[.)]\\s+.+")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (!ol) { html.append("<ol>"); ol = true; }
                html.append("<li>").append(markdownInline(line.replaceFirst("^\\d+[.)]\\s+", ""))).append("</li>");
            } else if (line.startsWith("> ")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<blockquote>").append(markdownInline(line.substring(2))).append("</blockquote>");
            } else if (line.matches("^([-*_])(?:\\s*\\1){2,}$")) {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<hr>");
            } else {
                if (ul) { html.append("</ul>"); ul = false; }
                if (ol) { html.append("</ol>"); ol = false; }
                html.append("<p>").append(markdownInline(line)).append("</p>");
            }
        }
        if (code) html.append("<pre><code>").append(esc(codeText.toString().stripTrailing())).append("</code></pre>");
        if (ul) html.append("</ul>");
        if (ol) html.append("</ol>");
        return html.toString();
    }

    private boolean looksLikeMarkdownTableHeader(String[] lines, int index) {
        if (index + 1 >= lines.length) return false;
        return looksLikeMarkdownTableRow(lines[index])
                && lines[index + 1].trim().matches("^\\|?\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?$");
    }

    private boolean looksLikeMarkdownTableRow(String line) {
        if (line == null) return false;
        String value = line.trim();
        return value.contains("|") && !value.matches("^\\|?\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?$");
    }

    private List<String> splitMarkdownTableRow(String line) {
        String value = line == null ? "" : line.trim();
        if (value.startsWith("|")) value = value.substring(1);
        if (value.endsWith("|")) value = value.substring(0, value.length() - 1);
        return Arrays.stream(value.split("\\|", -1)).map(String::trim).toList();
    }

    private String markdownInline(String value) {
        String result = esc(value == null ? "" : value);
        result = result.replaceAll("\\*\\*([^*]+)\\*\\*", "<strong>$1</strong>");
        result = result.replaceAll("`([^`]+)`", "<code>$1</code>");
        return result;
    }

    /**
     * Builds one canonical Confluence fragment.  No rows, bullets or code lines
     * are truncated here.  The method only normalizes editor-safe structure:
     * one page title, sane heading progression, merged adjacent lists and proper
     * table sections.  The decorated result is then reused by preview and copy.
     */
    public String canonicalConfluenceHtml(String sanitizedHtml) {
        if (isPreparedConfluenceHtml(sanitizedHtml)) return sanitizedHtml;
        Document doc = Jsoup.parseBodyFragment(sanitizedHtml == null ? "" : sanitizedHtml);
        normalizeConfluenceHeadings(doc);
        mergeAdjacentLists(doc);
        normalizeConfluenceTables(doc);
        normalizeConfluenceCallouts(doc);
        return decorateConfluenceClipboardHtml(doc.body().html());
    }

    private boolean isPreparedConfluenceHtml(String html) {
        if (html == null || html.isBlank()) return false;
        Document doc = Jsoup.parseBodyFragment(html);
        return doc.body().selectFirst("div[data-formatflow-confluence=1]") != null;
    }

    private void normalizeConfluenceHeadings(Document doc) {
        String firstTitle = null;
        int previousLevel = 0;
        for (Element heading : new ArrayList<>(doc.select("h1,h2,h3,h4"))) {
            String text = heading.text().replaceAll("\\s+", " ").trim();
            if ("h1".equals(heading.tagName())) {
                if (firstTitle == null) {
                    firstTitle = text.toLowerCase(Locale.ROOT);
                } else if (firstTitle.equals(text.toLowerCase(Locale.ROOT))) {
                    // Repeated chunk titles are generation artefacts, not content.
                    heading.remove();
                    continue;
                } else {
                    heading.tagName("h2");
                }
            }
            int level = Integer.parseInt(heading.tagName().substring(1));
            if (previousLevel > 0 && level > previousLevel + 1) {
                level = previousLevel + 1;
                heading.tagName("h" + level);
            }
            if (previousLevel == 0 && level > 2) {
                level = 2;
                heading.tagName("h2");
            }
            previousLevel = level;
        }
    }

    private void mergeAdjacentLists(Document doc) {
        for (Element list : new ArrayList<>(doc.select("ul,ol"))) {
            if (list.parent() == null) continue;
            Element next = list.nextElementSibling();
            while (next != null && next.tagName().equals(list.tagName())) {
                Element following = next.nextElementSibling();
                for (Element child : new ArrayList<>(next.children())) { child.remove(); list.appendChild(child); }
                next.remove();
                next = following;
            }
        }
    }

    private void normalizeConfluenceTables(Document doc) {
        for (Element table : doc.select("table")) {
            // Preserve every row, but normalize direct rows into thead/tbody so
            // browser clipboard implementations and Confluence see a real table.
            List<Element> directRows = new ArrayList<>();
            for (Element child : new ArrayList<>(table.children())) {
                if ("tr".equals(child.tagName())) directRows.add(child);
            }
            if (!directRows.isEmpty()) {
                Element thead = table.selectFirst(":scope > thead");
                Element tbody = table.selectFirst(":scope > tbody");
                if (thead == null) thead = table.prependElement("thead");
                if (tbody == null) tbody = table.appendElement("tbody");
                for (int i = 0; i < directRows.size(); i++) {
                    Element row = directRows.get(i);
                    boolean header = i == 0 && !row.select(":scope > th").isEmpty();
                    row.remove();
                    (header ? thead : tbody).appendChild(row);
                }
                if (thead.children().isEmpty()) thead.remove();
            }
        }
    }

    private void normalizeConfluenceCallouts(Document doc) {
        for (Element blockquote : doc.select("blockquote")) {
            String text = blockquote.text().trim();
            String lower = text.toLowerCase(Locale.ROOT);
            for (String prefix : List.of("note:", "important:", "warning:", "tip:")) {
                if (lower.startsWith(prefix) && blockquote.selectFirst("strong") == null) {
                    String label = text.substring(0, prefix.length() - 1);
                    String rest = text.substring(prefix.length()).trim();
                    blockquote.html("<strong>" + esc(label) + ":</strong> " + esc(rest));
                    break;
                }
            }
        }
    }

    /**
     * Rich clipboard HTML tuned for pasting into the Confluence editor.
     *
     * The model deliberately returns semantic HTML without CSS.  The preview can
     * style that HTML with application CSS, but clipboard targets do not receive
     * those styles.  We therefore add deterministic inline presentation here,
     * after sanitization, so font colours, table borders/header colours and
     * callout styling have a chance to survive a browser -> Confluence paste.
     * Legacy table attributes are included as an additional compatibility hint
     * because some clipboard/editor sanitizers discard part of the CSS style.
     */
    private String decorateConfluenceClipboardHtml(String sanitizedHtml) {
        Document doc = Jsoup.parseBodyFragment(sanitizedHtml == null ? "" : sanitizedHtml);
        for (Element e : doc.body().getAllElements()) {
            String tag = e.tagName();
            switch (tag) {
                case "h1" -> {
                    e.attr("style", "margin:0 0 18px;font-family:Arial,Segoe UI,sans-serif;font-size:26px;line-height:1.25;color:#006b36;font-weight:700;");
                    wrapWithColorSpan(e, "#006b36", true);
                }
                case "h2" -> {
                    e.attr("style", "margin:22px 0 10px;padding-bottom:5px;border-bottom:2px solid #b9dfca;font-family:Arial,Segoe UI,sans-serif;font-size:20px;line-height:1.3;color:#006b36;font-weight:700;");
                    wrapWithColorSpan(e, "#006b36", true);
                }
                case "h3", "h4" -> {
                    e.attr("style", "margin:16px 0 8px;font-family:Arial,Segoe UI,sans-serif;font-size:16px;line-height:1.35;color:#008542;font-weight:700;");
                    wrapWithColorSpan(e, "#008542", true);
                }
                case "p" -> e.attr("style", "margin:0 0 10px;font-family:Arial,Segoe UI,sans-serif;font-size:14px;line-height:1.55;color:#1f2d25;");
                case "ul", "ol" -> e.attr("style", "margin:7px 0 13px;padding-left:25px;font-family:Arial,Segoe UI,sans-serif;font-size:14px;line-height:1.55;color:#1f2d25;");
                case "li" -> e.attr("style", "margin:0 0 5px;color:#1f2d25;");
                case "table" -> {
                    e.attr("border", "1");
                    e.attr("cellpadding", "0");
                    e.attr("cellspacing", "0");
                    e.attr("style", "width:100%;border-collapse:collapse;border:1px solid #9fcdb2;margin:12px 0 18px;font-family:Arial,Segoe UI,sans-serif;font-size:13px;");
                }
                case "th" -> {
                    e.attr("bgcolor", "#006b36");
                    e.attr("style", "border:1px solid #8bbca0;background-color:#006b36;color:#ffffff;text-align:left;padding:8px 9px;font-weight:700;");
                    wrapWithColorSpan(e, "#ffffff", true);
                }
                case "td" -> e.attr("style", "border:1px solid #b9d7c5;padding:8px 9px;vertical-align:top;color:#1f2d25;background-color:#ffffff;");
                case "blockquote" -> e.attr("style", "margin:11px 0 14px;padding:10px 12px;border:1px solid #b9dfca;border-left:4px solid #008542;background-color:#eef8f2;color:#1f2d25;font-family:Arial,Segoe UI,sans-serif;font-size:14px;line-height:1.5;");
                case "pre" -> e.attr("style", "margin:12px 0 16px;padding:11px;border:1px solid #cfded5;border-left:4px solid #008542;background-color:#f4f7f5;font-family:Consolas,monospace;font-size:12px;line-height:1.5;white-space:pre-wrap;");
                case "strong" -> e.attr("style", "font-weight:700;");
                case "a" -> e.attr("style", "color:#006b36;text-decoration:underline;");
                case "hr" -> e.attr("style", "border:0;border-top:1px solid #b9d7c5;margin:20px 0;");
                default -> { }
            }
        }
        return "<div data-formatflow-confluence=\"1\" style=\"font-family:Arial,Segoe UI,sans-serif;color:#1f2d25;background-color:#ffffff;\">"
                + doc.body().html() + "</div>";
    }

    private void wrapWithColorSpan(Element element, String color, boolean bold) {
        if (element.childrenSize() == 1 && "span".equals(element.child(0).tagName())
                && element.child(0).hasAttr("data-formatflow-colour")) {
            return;
        }
        String inner = element.html();
        element.html("<span data-formatflow-colour=\"1\" style=\"color:" + color
                + ";" + (bold ? "font-weight:700;" : "") + "\">" + inner + "</span>");
    }

    private String decorateEmailHtml(String sanitizedHtml) {
        Document doc = Jsoup.parseBodyFragment(sanitizedHtml);
        for (Element e : doc.body().getAllElements()) {
            String tag = e.tagName();
            switch (tag) {
                case "p" -> e.attr("style", "margin:0 0 10px;font-family:Arial,sans-serif;font-size:14px;line-height:1.5;color:#1f2d25;");
                case "h1" -> e.attr("style", "margin:0 0 14px;font-family:Arial,sans-serif;font-size:22px;line-height:1.25;color:#006b36;");
                case "h2" -> e.attr("style", "margin:18px 0 8px;font-family:Arial,sans-serif;font-size:18px;line-height:1.3;color:#006b36;");
                case "h3", "h4" -> e.attr("style", "margin:14px 0 7px;font-family:Arial,sans-serif;font-size:15px;line-height:1.3;color:#006b36;");
                case "ul", "ol" -> e.attr("style", "margin:6px 0 12px;padding-left:24px;font-family:Arial,sans-serif;font-size:14px;line-height:1.5;color:#1f2d25;");
                case "li" -> e.attr("style", "margin:0 0 5px;");
                case "table" -> e.attr("style", "width:100%;border-collapse:collapse;margin:10px 0 14px;font-family:Arial,sans-serif;font-size:13px;");
                case "th" -> e.attr("style", "border:1px solid #b9dfca;background:#006b36;color:#ffffff;text-align:left;padding:7px 8px;");
                case "td" -> e.attr("style", "border:1px solid #dce5df;padding:7px 8px;vertical-align:top;color:#1f2d25;");
                case "blockquote" -> e.attr("style", "margin:10px 0;padding:9px 12px;border-left:4px solid #008542;background:#eef8f2;color:#1f2d25;font-family:Arial,sans-serif;font-size:14px;");
                case "pre" -> e.attr("style", "margin:10px 0;padding:10px;border-left:4px solid #008542;background:#f3f5f4;font-family:Consolas,monospace;font-size:12px;white-space:pre-wrap;");
                case "a" -> e.attr("style", "color:#006b36;text-decoration:underline;");
                default -> { }
            }
        }
        return doc.body().html();
    }

    private String decoratePortableHtml(String sanitizedHtml) {
        Document doc = Jsoup.parseBodyFragment(sanitizedHtml);
        for (Element e : doc.body().getAllElements()) {
            String tag = e.tagName();
            switch (tag) {
                case "p" -> e.attr("style", "margin:0 0 12px;font-family:Segoe UI,Arial,sans-serif;font-size:15px;line-height:1.65;color:#1f2d25;");
                case "h1" -> e.attr("style", "margin:0 0 20px;font-family:Segoe UI,Arial,sans-serif;font-size:30px;line-height:1.2;color:#005b31;");
                case "h2" -> e.attr("style", "margin:26px 0 12px;padding-bottom:7px;border-bottom:2px solid #d9eee3;font-family:Segoe UI,Arial,sans-serif;font-size:21px;line-height:1.3;color:#006b36;");
                case "h3", "h4" -> e.attr("style", "margin:20px 0 9px;font-family:Segoe UI,Arial,sans-serif;font-size:16px;line-height:1.35;color:#006b36;");
                case "ul", "ol" -> e.attr("style", "margin:8px 0 16px;padding-left:26px;font-family:Segoe UI,Arial,sans-serif;font-size:15px;line-height:1.6;color:#1f2d25;");
                case "li" -> e.attr("style", "margin:0 0 7px;");
                case "table" -> e.attr("style", "width:100%;border-collapse:collapse;margin:14px 0 22px;font-family:Segoe UI,Arial,sans-serif;font-size:14px;");
                case "th" -> e.attr("style", "border:1px solid #b9dfca;background:#006b36;color:#ffffff;text-align:left;padding:9px 10px;");
                case "td" -> e.attr("style", "border:1px solid #dce5df;padding:9px 10px;vertical-align:top;color:#1f2d25;");
                case "blockquote" -> e.attr("style", "margin:14px 0 18px;padding:11px 14px;border-left:4px solid #008542;background:#eef8f2;color:#1f2d25;font-family:Segoe UI,Arial,sans-serif;font-size:14px;line-height:1.55;");
                case "pre" -> e.attr("style", "margin:14px 0 20px;padding:13px;border:1px solid #d8e2dc;border-left:4px solid #008542;background:#f3f5f4;font-family:Consolas,monospace;font-size:13px;line-height:1.5;white-space:pre-wrap;");
                case "a" -> e.attr("style", "color:#006b36;text-decoration:underline;");
                case "hr" -> e.attr("style", "border:0;border-top:1px solid #dce5df;margin:24px 0;");
                default -> { }
            }
        }
        return "<div style=\"font-family:Segoe UI,Arial,sans-serif;max-width:980px;margin:0 auto;padding:28px 32px;background:#ffffff;color:#1f2d25;\">"
                + doc.body().html() + "</div>";
    }

    private void appendPlainText(Element element, StringBuilder out, int depth) {
        String tag = element.tagName();
        if ("table".equals(tag)) {
            for (Element row : element.select("tr")) {
                List<String> cells = row.select("th,td").eachText();
                out.append(String.join(" | ", cells)).append('\n');
            }
            out.append('\n');
            return;
        }
        if ("ul".equals(tag) || "ol".equals(tag)) {
            boolean numbered = "ol".equals(tag);
            int i = 1;
            for (Element li : element.children()) {
                if (!"li".equals(li.tagName())) continue;
                out.append(numbered ? (i++) + ". " : "• ").append(li.text()).append('\n');
            }
            out.append('\n');
            return;
        }
        if (Set.of("h1", "h2", "h3", "h4", "p", "blockquote", "pre").contains(tag)) {
            out.append(element.wholeText().trim()).append("\n\n");
            return;
        }
        if ("hr".equals(tag)) {
            out.append("--------------------\n\n");
            return;
        }
        for (Element child : element.children()) appendPlainText(child, out, depth + 1);
        if (element.children().isEmpty() && !element.ownText().isBlank()) out.append(element.ownText()).append('\n');
    }

    private Map<String, DocumentBlock> blockMap(FormattedDocument document) {
        return document.blocks().stream().collect(Collectors.toMap(DocumentBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    private List<DocumentBlock> referencedBlocks(SemanticSection section, Map<String, DocumentBlock> blocks) {
        List<DocumentBlock> result = new ArrayList<>();
        for (String id : safe(section.sourceIds())) {
            DocumentBlock block = blocks.get(id);
            if (block != null) result.add(block);
        }
        return result;
    }

    private String semanticTitle(SemanticSection section) {
        return section.title() == null ? "" : section.title();
    }

    private SemanticLayoutType layout(SemanticSection section) {
        try { return SemanticLayoutType.valueOf(safeUpper(section.layoutType())); }
        catch (Exception ex) { return SemanticLayoutType.TEXT; }
    }

    private String joinItem(SemanticItem item) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank()) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank()) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank()) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private String restItem(SemanticItem item) {
        String first = nonblank(item.label(), item.value(), item.status());
        return remainingItem(item, first);
    }

    private String remainingItem(SemanticItem item, String first) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank() && !item.label().equals(first)) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank() && !item.value().equals(first)) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank() && !item.status().equals(first)) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private String nonblank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value;
        return "";
    }

    private String bulletSymbol(String style) {
        return switch (safeUpper(style)) {
            case "ARROW" -> "→";
            case "DOT" -> "•";
            default -> "✓";
        };
    }

    private String stripBullet(String text) {
        if (text == null) return "";
        return text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "");
    }

    private BlockType safeType(String value) {
        try { return BlockType.valueOf(safeUpper(value)); }
        catch (Exception ex) { return BlockType.PARAGRAPH; }
    }

    private String safeUpper(String value) {
        return value == null ? "NONE" : value.trim().toUpperCase(Locale.ROOT);
    }

    private <T> List<T> safe(List<T> values) {
        return values == null ? List.of() : values;
    }

    private String esc(String value) {
        return HtmlUtils.htmlEscape(value == null ? "" : value);
    }
}
