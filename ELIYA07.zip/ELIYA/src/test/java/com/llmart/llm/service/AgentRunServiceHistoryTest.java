package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunServiceHistoryTest {
    @TempDir Path temp;

    @Test
    void deleteForConversationRemovesOnlyTargetDurableRunHistory() {
        Path store = temp.resolve("runs");
        AgentRunService service = new AgentRunService(store);
        AgentRunService.AgentRun first = service.start("conversation-a", "project-a");
        AgentRunService.AgentRun second = service.start("conversation-b", "project-b");
        assertTrue(Files.exists(store.resolve(first.id() + ".properties")));
        assertTrue(Files.exists(store.resolve(second.id() + ".properties")));
        assertEquals(1, service.deleteForConversation("conversation-a"));
        assertTrue(service.forConversation("conversation-a").isEmpty());
        assertEquals(1, service.forConversation("conversation-b").size());
        assertFalse(Files.exists(store.resolve(first.id() + ".properties")));
        assertTrue(Files.exists(store.resolve(second.id() + ".properties")));
    }

    @Test
    void clearHistoryRemovesAllLoadedAndOrphanedRunFiles() throws Exception {
        Path store = temp.resolve("runs-all");
        AgentRunService service = new AgentRunService(store);
        AgentRunService.AgentRun first = service.start("conversation-a", "project-a");
        AgentRunService.AgentRun second = service.start("conversation-b", "project-b");
        Files.writeString(store.resolve("orphan-run.properties"), "orphan=true");
        Files.writeString(store.resolve("orphan-run.events"), "event");

        assertEquals(3, service.clearHistory());
        assertTrue(service.forConversation("conversation-a").isEmpty());
        assertTrue(service.forConversation("conversation-b").isEmpty());
        assertFalse(Files.exists(store.resolve(first.id() + ".properties")));
        assertFalse(Files.exists(store.resolve(second.id() + ".properties")));
        assertFalse(Files.exists(store.resolve("orphan-run.properties")));
        assertFalse(Files.exists(store.resolve("orphan-run.events")));
    }
}
