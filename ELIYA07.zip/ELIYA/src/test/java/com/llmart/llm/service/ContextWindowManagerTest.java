package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class ContextWindowManagerTest {

    private final ContextWindowManager manager = new ContextWindowManager(new ObjectMapper());

    @Test
    void proactivelyCompactsLargeHistoryAndKeepsRecentTail() {
        ChatSettings settings = settings(32_000, true, 4_000, 8_000, 1_000);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "system instructions"));
        messages.add(message("user", "Implement token management without stopping useful work"));
        for (int i = 0; i < 30; i++) {
            messages.add(message("assistant", "analysis-" + i + " " + "a".repeat(1200)));
            Map<String,Object> tool = message("tool", "exitCode=1; " + "E".repeat(3000));
            tool.put("name", "test");
            tool.put("tool_call_id", "call-" + i);
            messages.add(tool);
        }
        String newest = String.valueOf(messages.get(messages.size() - 1).get("content"));

        ContextWindowManager.ContextEstimate before = manager.estimate(messages, List.of(), settings);
        assertTrue(before.estimatedInputTokens() > before.inputLimitTokens());

        ContextWindowManager.CompactionResult result = manager.compact(messages, List.of(), settings, null, false);

        assertTrue(result.compacted());
        assertTrue(result.estimatedTokensSaved() > 10_000);
        assertTrue(result.after().estimatedInputTokens() < before.estimatedInputTokens());
        assertEquals("system", messages.get(0).get("role"));
        assertTrue(String.valueOf(messages.get(1).get("content")).startsWith("HISTORICAL SESSION CHECKPOINT"));
        assertTrue(messages.stream().anyMatch(m -> newest.equals(m.get("content"))), "newest tool result must remain in recent tail");
        assertTrue(String.valueOf(messages.get(1).get("content")).contains("Implement token management"), "checkpoint must retain original objective");
    }

    @Test
    void prunesOnlyOlderToolOutputsAndLeavesRecentResultsIntact() {
        ChatSettings settings = settings(128_000, true, 15_000, 20_000, 800);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        for (int i = 0; i < 10; i++) {
            Map<String,Object> tool = message("tool", "result-" + i + " " + "x".repeat(4000));
            tool.put("name", "read");
            tool.put("tool_call_id", "c" + i);
            messages.add(tool);
        }

        int changed = manager.pruneOldToolOutputs(messages, settings);

        assertEquals(8, changed, "two newest tool messages are intentionally preserved in bounded full form");
        assertTrue(String.valueOf(messages.get(1).get("content")).contains("Older tool output pruned"));
        assertFalse(String.valueOf(messages.get(messages.size() - 1).get("content")).contains("Older tool output pruned"));
    }

    @Test
    void removesSupersededRuntimeSteeringWithoutTouchingUserAuthoredMessages() {
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        messages.add(message("user", "RECOVERY is a word in my real requirement; keep this user-authored sentence"));
        messages.add(message("user", "[RUNTIME_STEERING:recovery]\nRECOVERY 1/10. old generated steering"));
        messages.add(message("user", "[RUNTIME_STEERING:recovery]\nRECOVERY 2/10. newest generated steering"));
        messages.add(message("system", "[RUNTIME_STEERING:focused-recovery]\nRECOVERY CYCLE 1 old focused recovery"));
        messages.add(message("system", "[RUNTIME_STEERING:focused-recovery]\nRECOVERY CYCLE 2 newest focused recovery"));
        messages.add(message("system", "[RUNTIME_STEERING:model-failover]\nMODEL FAILOVER CONTINUATION. old"));
        messages.add(message("system", "[RUNTIME_STEERING:model-failover]\nMODEL FAILOVER CONTINUATION. newest"));

        int removed = manager.pruneSupersededRuntimeSteering(messages);

        assertEquals(3, removed);
        assertTrue(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("real requirement")));
        assertTrue(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("RECOVERY 2/10")));
        assertFalse(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("RECOVERY 1/10")));
        assertTrue(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("RECOVERY CYCLE 2 newest")));
        assertFalse(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("RECOVERY CYCLE 1 old")));
    }

    @Test
    void estimatesToolSchemasAsPartOfContextBudget() {
        ChatSettings settings = settings(32_000, true, 4_000, 8_000, 1_000);
        List<Map<String,Object>> messages = List.of(message("system", "sys"), message("user", "task"));
        List<Map<String,Object>> smallTools = List.of(Map.of("type", "function", "function", Map.of("name", "read")));
        List<Map<String,Object>> largeTools = List.of(Map.of("type", "function", "function", Map.of("name", "read", "description", "d".repeat(20_000))));

        var small = manager.estimate(messages, smallTools, settings);
        var large = manager.estimate(messages, largeTools, settings);

        assertTrue(large.toolSchemaTokens() > small.toolSchemaTokens());
        assertTrue(large.estimatedInputTokens() > small.estimatedInputTokens());
    }


    @Test
    void adaptiveThresholdUsesReservedInputLimitAndDynamicHeadroom() {
        ChatSettings settings128 = settings(128_000, true, 8_000, 20_000, 1_200);
        var estimate128 = manager.estimate(List.of(message("user", "task")), List.of(), settings128);
        assertEquals(108_000, estimate128.inputLimitTokens());
        assertEquals(95_200, manager.adaptiveCompactionThreshold(estimate128, settings128));

        ChatSettings settings200 = settings(200_000, true, 8_000, 20_000, 1_200);
        var estimate200 = manager.estimate(List.of(message("user", "task")), List.of(), settings200);
        assertEquals(180_000, estimate200.inputLimitTokens());
        assertEquals(160_000, manager.adaptiveCompactionThreshold(estimate200, settings200));
    }

    @Test
    void durableStateAndRetrievalHintsAreSingleChangingSuffixes() {
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "stable prefix"));
        messages.add(message("user", "real task"));
        messages.add(message("system", "[RUNTIME_STATE:durable]\nold one"));
        messages.add(message("system", "[RUNTIME_STATE:durable]\nold two"));
        messages.add(message("system", "[RUNTIME_RETRIEVAL:index]\nold hints"));

        assertEquals(2, manager.upsertDurableRuntimeState(messages, "new state"));
        assertEquals(1, manager.upsertRetrievalHints(messages, "new hints"));
        assertEquals("stable prefix", messages.get(0).get("content"));
        assertTrue(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("new state")));
        assertTrue(messages.stream().anyMatch(m -> String.valueOf(m.get("content")).contains("new hints")));
        assertEquals(1, messages.stream().filter(m -> String.valueOf(m.get("content")).startsWith("[RUNTIME_STATE:durable]")).count());
        assertEquals(1, messages.stream().filter(m -> String.valueOf(m.get("content")).startsWith("[RUNTIME_RETRIEVAL:index]")).count());
    }

    @Test
    void aggressivePruningBoundsRecentAndOldToolOutputsWithoutTouchingUserTask() {
        ChatSettings settings = settings(128_000, true, 8_000, 20_000, 1_200);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("user", "keep my real requirement exactly"));
        for (int i = 0; i < 8; i++) {
            Map<String,Object> tool = message("tool", "result-" + i + " " + "x".repeat(10_000));
            tool.put("name", "test");
            messages.add(tool);
        }

        int changed = manager.pruneOldToolOutputs(messages, settings, true);

        assertEquals(8, changed);
        assertEquals("keep my real requirement exactly", messages.get(0).get("content"));
        assertTrue(String.valueOf(messages.get(messages.size() - 1).get("content")).length() < 6_000);
        assertTrue(String.valueOf(messages.get(1).get("content")).contains("Older tool output pruned"));
    }

    @Test
    void defaultGptOssContextIsProactivelyBounded() {
        ChatSettings settings = settings(0, true, 8_000, 20_000, 2_000);
        assertEquals(131_072, settings.safeContextWindowTokens());
        assertEquals(8_000, settings.safeCompactionKeepTokens());
        assertEquals(20_000, settings.safeCompactionBufferTokens());
        assertTrue(settings.autoCompactEnabled());
    }

    @Test
    void autoCompactionCanBeDisabledWithoutRemovingOverflowRecoveryCapability() {
        ChatSettings settings = settings(32_000, false, 4_000, 8_000, 1_000);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        messages.add(message("user", "original task"));
        messages.add(message("assistant", "a".repeat(45_000)));
        messages.add(message("user", "continue " + "u".repeat(55_000)));
        assertFalse(manager.shouldCompact(messages, List.of(), settings));
        assertTrue(manager.compact(messages, List.of(), settings, null, true).compacted(),
                "forced provider-overflow recovery must still work when proactive compaction is disabled");
    }


    @Test
    void boundsOneHugeFreshToolResultBeforeItCanConsumeTheWindow() {
        ChatSettings settings = settings(128_000, true, 8_000, 20_000, 2_000);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        Map<String,Object> tool = message("tool", "x".repeat(250_000));
        tool.put("name", "read");
        tool.put("tool_call_id", "latest");
        messages.add(tool);

        int changed = manager.pruneOldToolOutputs(messages, settings);

        assertEquals(1, changed);
        String bounded = String.valueOf(messages.get(1).get("content"));
        assertTrue(bounded.length() < 55_000);
        assertTrue(bounded.contains("Oversized recent tool output bounded"));
    }

    @Test
    void prunesJsonCompatibilityToolResultsAsObservations() {
        ChatSettings settings = settings(128_000, true, 8_000, 20_000, 900);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        for (int i = 0; i < 9; i++) {
            messages.add(message("user", "TOOL RESULT for read:\n" + i + " " + "z".repeat(4_000)));
        }

        int changed = manager.pruneOldToolOutputs(messages, settings);

        assertEquals(7, changed);
        assertTrue(String.valueOf(messages.get(1).get("content")).contains("Older tool output pruned"));
        assertFalse(String.valueOf(messages.get(messages.size() - 1).get("content")).contains("Older tool output pruned"));
    }

    @Test
    void semanticCheckpointIsPreferredButDeterministicFallbackAlwaysWorks() {
        ChatSettings settings = settings(32_000, true, 3_000, 8_000, 1_000);
        List<Map<String,Object>> original = new ArrayList<>();
        original.add(message("system", "sys"));
        original.add(message("user", "Preserve this exact objective"));
        for (int i = 0; i < 24; i++) {
            original.add(message("assistant", "work-" + i + " " + "a".repeat(1400)));
            Map<String,Object> tool = message("tool", "exitCode=0; " + "o".repeat(1800));
            tool.put("name", "test");
            tool.put("tool_call_id", "c" + i);
            original.add(tool);
        }

        List<Map<String,Object>> semanticMessages = deepCopy(original);
        var semantic = manager.compact(semanticMessages, List.of(), settings, null, false,
                (prompt, maxTokens) -> "## Objective\nPreserve this exact objective\n## Work State\n### Completed\nTests inspected");
        assertTrue(semantic.compacted());
        assertTrue(semantic.reason().contains("semantic summary"));
        assertTrue(String.valueOf(semanticMessages.get(1).get("content")).contains("Tests inspected"));

        List<Map<String,Object>> fallbackMessages = deepCopy(original);
        var fallback = manager.compact(fallbackMessages, List.of(), settings, null, false,
                (prompt, maxTokens) -> { throw new IllegalStateException("summary provider unavailable"); });
        assertTrue(fallback.compacted());
        assertTrue(fallback.reason().contains("deterministic fallback"));
        assertTrue(String.valueOf(fallbackMessages.get(1).get("content")).contains("Preserve this exact objective"));
    }

    @Test
    void compactionAccountsForToolSchemasWhenChoosingRecentTail() {
        ChatSettings settings = settings(32_000, true, 8_000, 8_000, 1_000);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "system instructions"));
        messages.add(message("user", "task"));
        for (int i = 0; i < 30; i++) {
            messages.add(message("assistant", "reason-" + i + " " + "r".repeat(1200)));
            Map<String,Object> tool = message("tool", "exitCode=0; " + "t".repeat(1400));
            tool.put("name", "test");
            tool.put("tool_call_id", "c" + i);
            messages.add(tool);
        }
        List<Map<String,Object>> tools = List.of(Map.of("type", "function", "function",
                Map.of("name", "large_tool", "description", "schema".repeat(2_000))));

        var result = manager.compact(messages, tools, settings, null, false);

        assertTrue(result.compacted());
        assertTrue(result.after().estimatedInputTokens() <= result.after().inputLimitTokens(),
                "recent tail should be reduced to leave room for tool schemas and checkpoint");
    }


    @Test
    void deterministicCheckpointPreservesWindowsAbsolutePaths() {
        ChatSettings settings = settings(16_000, true, 2_000, 4_000, 800);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        messages.add(message("user", "Fix project C:\\Users\\me\\repo\\pom.xml"));
        for (int i = 0; i < 30; i++) {
            messages.add(message("assistant", "a".repeat(800)));
            Map<String,Object> tool = message("tool", "t".repeat(800));
            tool.put("name", "read");
            messages.add(tool);
        }

        var result = manager.compact(messages, List.of(), settings, null, false);

        assertTrue(result.compacted());
        assertTrue(String.valueOf(messages.get(1).get("content")).contains("C:\\Users\\me\\repo\\pom.xml"));
    }

    @Test
    void deterministicCheckpointPreservesOldUserConstraints() {
        ChatSettings settings = settings(16_000, true, 2_000, 4_000, 800);
        List<Map<String,Object>> messages = new ArrayList<>();
        messages.add(message("system", "sys"));
        messages.add(message("user", "Keep only Chat and Agent. Do not show release identifiers. Never modify the reference project."));
        for (int i = 0; i < 28; i++) {
            messages.add(message("assistant", "work " + i + " " + "a".repeat(900)));
            Map<String,Object> tool = message("tool", "ok " + "t".repeat(900));
            tool.put("name", "read");
            messages.add(tool);
        }

        var result = manager.compact(messages, List.of(), settings, null, false);

        assertTrue(result.compacted());
        String checkpoint = String.valueOf(messages.get(1).get("content"));
        assertTrue(checkpoint.contains("Keep only Chat and Agent"));
        assertTrue(checkpoint.contains("Do not show release identifiers"));
        assertTrue(checkpoint.contains("Never modify the reference project"));
    }

    private static Map<String,Object> message(String role, String content) {
        return new LinkedHashMap<>(Map.of("role", role, "content", content));
    }


    private static List<Map<String,Object>> deepCopy(List<Map<String,Object>> source) {
        List<Map<String,Object>> result = new ArrayList<>();
        for (Map<String,Object> item : source) result.add(new LinkedHashMap<>(item));
        return result;
    }

    private static ChatSettings settings(int contextWindow, boolean autoCompact, int keep, int buffer, int oldToolChars) {
        return new ChatSettings(
                "http://localhost/v1", "gpt-oss-120b", null, null, null, null, null, null, null, true, true, 0.1, 0, 0,
                contextWindow, null, null, autoCompact, keep, buffer, oldToolChars,
                null, true, 0, true,
                "allow", "allow", "allow", true, "",
                "allow", "allow", "allow", true, true, null, 10
        );
    }
}
