package com.llmart.llm.service;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.repository.FileRepository;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class FileServiceDocumentExtractionTest {

    @TempDir
    Path tempDir;

    @Mock
    FileRepository repository;

    @Mock
    ConversationService conversations;

    private AutoCloseable mocks;
    private FileService service;
    private final AtomicReference<FileEntity> saved = new AtomicReference<>();

    @BeforeEach
    void setUp() {
        mocks = MockitoAnnotations.openMocks(this);
        when(conversations.require(anyString())).thenReturn(new ConversationEntity("c1", "test"));
        when(repository.save(any(FileEntity.class))).thenAnswer(invocation -> {
            FileEntity entity = invocation.getArgument(0);
            saved.set(entity);
            return entity;
        });
        service = new FileService(repository, conversations, tempDir.toString());
    }

    @AfterEach
    void tearDown() throws Exception {
        mocks.close();
    }

    @Test
    void extractsDocxTextAtUploadTime() throws Exception {
        byte[] bytes;
        try (XWPFDocument document = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            document.createParagraph().createRun().setText("Teamspark document summary content");
            document.createTable(1, 2).getRow(0).getCell(0).setText("Owner");
            document.getTables().get(0).getRow(0).getCell(1).setText("Siva");
            document.write(out);
            bytes = out.toByteArray();
        }

        MockMultipartFile upload = new MockMultipartFile(
                "file",
                "teamspark.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                bytes);

        FileDto dto = service.save("c1", upload);

        assertEquals("ready", dto.extractionStatus());
        assertTrue(dto.extractedCharacters() > 0);
        assertNotNull(saved.get());
        assertTrue(saved.get().getExtractedText().contains("Teamspark document summary content"));
        assertTrue(saved.get().getExtractedText().contains("Owner"));
    }
    @Test
    void extractsXlsxTextAtUploadTimeWithoutTreatingOpenXmlMimeAsPlainText() throws Exception {
        byte[] bytes;
        try (XSSFWorkbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var sheet = workbook.createSheet("Summary");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("Project");
            row.createCell(1).setCellValue("TeamSpark");
            workbook.write(out);
            bytes = out.toByteArray();
        }

        MockMultipartFile upload = new MockMultipartFile(
                "file",
                "teamspark.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                bytes);

        FileDto dto = service.save("c1", upload);

        assertEquals("ready", dto.extractionStatus());
        assertTrue(saved.get().getExtractedText().contains("TeamSpark"));
    }

    @Test
    void extractsPptxTextAtUploadTimeWithoutTreatingOpenXmlMimeAsPlainText() throws Exception {
        byte[] bytes;
        try (XMLSlideShow show = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            var slide = show.createSlide();
            var box = slide.createTextBox();
            box.setText("TeamSpark presentation summary");
            show.write(out);
            bytes = out.toByteArray();
        }

        MockMultipartFile upload = new MockMultipartFile(
                "file",
                "teamspark.pptx",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                bytes);

        FileDto dto = service.save("c1", upload);

        assertEquals("ready", dto.extractionStatus());
        assertTrue(saved.get().getExtractedText().contains("TeamSpark presentation summary"));
    }


    @Test
    void parsesHtmlAsDocumentContentInsteadOfRawMarkup() throws Exception {
        String html = """
                <!doctype html><html><head><title>Migration Report</title>
                <style>.hidden{display:none}</style><script>window.secret='do-not-send';</script></head>
                <body><h1>Migration Summary</h1><p>25 tests migrated successfully.</p>
                <table><tr><th>Status</th><th>Count</th></tr><tr><td>Passed</td><td>25</td></tr></table></body></html>
                """;
        MockMultipartFile upload = new MockMultipartFile(
                "file", "migration-report.html", "text/html", html.getBytes(java.nio.charset.StandardCharsets.UTF_8));

        FileDto dto = service.save("c1", upload);

        assertEquals("ready", dto.extractionStatus());
        String extracted = saved.get().getExtractedText();
        assertTrue(extracted.contains("Migration Summary"));
        assertTrue(extracted.contains("25 tests migrated successfully"));
        assertFalse(extracted.contains("<h1>"));
        assertFalse(extracted.contains("window.secret"));
    }

}
