package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentWorkspaceServiceCommandExecutionTest {

    @TempDir
    Path temp;

    @Test
    void foregroundCommandCapturesMergedOutputThroughPipe() throws Exception {
        Path workspace = temp.resolve("workspace");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("README.md"), "test\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p1")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p1");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-1")).start("c1", "p1");

        AgentWorkspaceService.CommandResult result = service.runCommand(
                ws,
                isWindows() ? "echo hello-from-agent" : "printf 'hello-from-agent'; printf ' stderr-ok' >&2",
                "",
                true,
                Set.of(),
                10,
                run);

        assertEquals(0, result.exitCode());
        assertTrue(result.output().contains("hello-from-agent"));
        if (!isWindows()) assertTrue(result.output().contains("stderr-ok"));
    }

    @Test
    void failedCommandIsReturnedAsResultInsteadOfThrowingTempFileCleanupError() throws Exception {
        Path workspace = temp.resolve("workspace-fail");
        Files.createDirectories(workspace);

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p2")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p2");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-2")).start("c2", "p2");

        AgentWorkspaceService.CommandResult result = service.runCommand(
                ws,
                "definitely-not-a-real-command-advanced-ai",
                "",
                true,
                Set.of(),
                10,
                run);

        assertNotEquals(0, result.exitCode());
        assertFalse(result.output().isBlank());
    }


    @Test
    void identicalDirectWriteIsReportedAsNoChange() throws Exception {
        Path workspace = temp.resolve("workspace-noop");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "same-content");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p3")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p3");

        String result = service.writeFile(ws, "sample.txt", "same-content");

        assertTrue(result.startsWith("workspaceChanged=false;"));
        assertTrue(service.changes(ws).isEmpty(), "a no-op write must not create a synthetic workspace revision");
    }

    @Test
    void shellMutationIsDetectedWithoutWholeWorkspaceHashing() throws Exception {
        Path workspace = temp.resolve("workspace-watch");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "before");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p4")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p4");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-4")).start("c4", "p4");

        String command = isWindows()
                ? "echo after>sample.txt"
                : "printf 'after' > sample.txt";
        AgentWorkspaceService.CommandResult result = service.runCommand(ws, command, "", true, Set.of(), 10, run);

        assertEquals(0, result.exitCode());
        assertTrue(result.output().contains("workspaceChanged=true"), result.output());
        assertTrue(service.changes(ws).stream().anyMatch(c -> c.contains("sample.txt")));
    }

    @Test
    void normalGitInspectionCommandIsAllowed() throws Exception {
        if (!isGitAvailable()) return;
        Path workspace = temp.resolve("workspace-git");
        Files.createDirectories(workspace);

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p5")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p5");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-5")).start("c5", "p5");

        AgentWorkspaceService.CommandResult init = service.runCommand(ws, "git init", "", true, Set.of(), 10, run);
        assertEquals(0, init.exitCode(), init.output());
        AgentWorkspaceService.CommandResult status = service.runCommand(ws, "git status --porcelain", "", true, Set.of(), 10, run);
        assertEquals(0, status.exitCode(), status.output());
    }

    @Test
    void openAiStylePatchTextIsAcceptedAndApplied() throws Exception {
        Path workspace = temp.resolve("workspace-patch-text");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "alpha\nbeta\ngamma\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p6")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p6");
        String patch = """
                *** Begin Patch
                *** Update File: sample.txt
                @@
                 alpha
                -beta
                +beta-updated
                 gamma
                *** Add File: added.txt
                +new-file
                *** End Patch
                """;

        String result = service.applyPatch(ws, null, patch);

        assertTrue(result.startsWith("workspaceChanged=true;"));
        assertEquals("alpha\nbeta-updated\ngamma\n", Files.readString(workspace.resolve("sample.txt")));
        assertEquals("new-file", Files.readString(workspace.resolve("added.txt")));
    }

    @Test
    void editAcceptsEquivalentCrLfAndLfText() throws Exception {
        Path workspace = temp.resolve("workspace-line-endings");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "one\r\ntwo\r\nthree\r\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p7")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p7");
        String result = service.editFile(ws, "sample.txt", "one\ntwo\n", "one\ntwo-updated\n", false);

        assertTrue(result.startsWith("workspaceChanged=true;"));
        assertEquals("one\r\ntwo-updated\r\nthree\r\n", Files.readString(workspace.resolve("sample.txt")));
    }


    @Test
    void gitCleanupWithNonUtf8FilesDoesNotBreakFinalWorkspaceReporting() throws Exception {
        if (!isGitAvailable() || isWindows()) return;
        Path workspace = temp.resolve("workspace-git-clean-binary");
        Files.createDirectories(workspace);
        runShell(workspace, "git init");
        runShell(workspace, "git config user.email test@example.com");
        runShell(workspace, "git config user.name Test");
        Files.writeString(workspace.resolve("tracked.txt"), "committed\n");
        Files.write(workspace.resolve("binary.dat"), new byte[]{0, 1, 2, (byte) 0xFF, 3});
        runShell(workspace, "git add . && git commit -m baseline");
        Files.writeString(workspace.resolve("tracked.txt"), "local-change\n");
        Files.write(workspace.resolve("binary.dat"), new byte[]{0, 9, (byte) 0xFE, 8});
        Files.writeString(workspace.resolve("untracked.tmp"), "remove-me");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p8")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p8");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-8")).start("c8", "p8");
        AgentWorkspaceService.CommandResult cleanup = service.runCommand(
                ws, "git reset HEAD && git restore . && git clean -fd", "", true, Set.of(), 20, run);

        assertEquals(0, cleanup.exitCode(), cleanup.output());
        assertEquals("", runShell(workspace, "git status --porcelain").strip());
        assertDoesNotThrow(() -> service.changes(ws));
        assertTrue(service.changeCount(ws) >= 3);
        assertTrue(service.omittedTextChangeCount(ws) >= 1);
        assertTrue(service.workspaceDiff(ws, null).contains("binary/non-UTF-8"));
    }

    @Test
    void touchedFileRestoredToRunStartBytesIsNotReportedAsFinalChange() throws Exception {
        if (isWindows()) return;
        Path workspace = temp.resolve("workspace-restored-noop");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "original");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p9")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p9");
        AgentRunService.AgentRun run = new AgentRunService(temp.resolve("runs-9")).start("c9", "p9");
        AgentWorkspaceService.CommandResult result = service.runCommand(
                ws, "printf 'changed' > sample.txt; printf 'original' > sample.txt", "", true, Set.of(), 10, run);

        assertEquals(0, result.exitCode(), result.output());
        assertEquals("original", Files.readString(workspace.resolve("sample.txt")));
        assertTrue(service.changes(ws).isEmpty());
        assertEquals(0, service.changeCount(ws));
    }

    private static String runShell(Path cwd, String command) throws Exception {
        Process process = new ProcessBuilder("/bin/sh", "-lc", command)
                .directory(cwd.toFile()).redirectErrorStream(true).start();
        String output = new String(process.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        int exit = process.waitFor();
        if (exit != 0) throw new AssertionError("Command failed (" + exit + "): " + command + "\n" + output);
        return output;
    }

    private static boolean isGitAvailable() {
        try {
            Process p = new ProcessBuilder("git", "--version").redirectErrorStream(true).start();
            return p.waitFor() == 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
