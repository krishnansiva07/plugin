package com.llmart.llm.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.service.*;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class ConversationControllerHistoryTest {
    @Test
    void clearHistoryDeletesConversationDataAndRunHistory() {
        ConversationService conversations = mock(ConversationService.class);
        ProjectService projects = mock(ProjectService.class);
        AgentRunService runs = mock(AgentRunService.class);
        PdfExportService pdf = mock(PdfExportService.class);
        Instant now = Instant.now();
        when(conversations.list()).thenReturn(List.of(
                new ConversationDto("c1", "one", now, now),
                new ConversationDto("c2", "two", now, now)));
        when(runs.clearHistory()).thenReturn(3);

        ConversationController controller = new ConversationController(conversations, new ObjectMapper(), projects, pdf, runs);
        Map<String,Object> result = controller.clearHistory();

        assertEquals(2, result.get("clearedConversations"));
        assertEquals(3, result.get("clearedAgentRuns"));
        verify(runs).clearHistory();
        verify(projects).deleteForConversation("c1");
        verify(projects).deleteForConversation("c2");
        verify(conversations).delete("c1");
        verify(conversations).delete("c2");
    }
}
