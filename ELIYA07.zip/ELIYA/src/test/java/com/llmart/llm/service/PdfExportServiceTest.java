package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class PdfExportServiceTest {
    @Test
    void createsValidLookingPdfWithMarkdownAndTableBreaks() {
        PdfExportService service = new PdfExportService();
        byte[] bytes = service.fromMarkdown("ELIYA Export", "# Summary\n\n| Case | Steps |\n|---|---|\n| Login | User<br>Password |\n");
        assertTrue(bytes.length > 500);
        String ascii = new String(bytes, StandardCharsets.ISO_8859_1);
        assertTrue(ascii.startsWith("%PDF-1.4"));
        assertTrue(ascii.contains("xref"));
        assertTrue(ascii.contains("ELIYA Export"));
    }
}
