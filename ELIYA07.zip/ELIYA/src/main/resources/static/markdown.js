(function (global) {
  'use strict';

  const LANGUAGE_NAMES = {
    js: 'JavaScript', javascript: 'JavaScript', ts: 'TypeScript', typescript: 'TypeScript',
    java: 'Java', py: 'Python', python: 'Python', json: 'JSON', xml: 'XML', html: 'HTML',
    css: 'CSS', sql: 'SQL', sh: 'Shell', bash: 'Bash', shell: 'Shell', yml: 'YAML', yaml: 'YAML',
    md: 'Markdown', markdown: 'Markdown', c: 'C', cpp: 'C++', csharp: 'C#', cs: 'C#',
    go: 'Go', rust: 'Rust', kotlin: 'Kotlin', groovy: 'Groovy', powershell: 'PowerShell',
    ps1: 'PowerShell', dockerfile: 'Dockerfile', text: 'Text', txt: 'Text'
  };

  const KEYWORDS = {
    java: /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|native|new|package|private|protected|public|record|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|var|void|volatile|while|true|false|null)\b/g,
    javascript: /\b(?:async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|false|finally|for|from|function|get|if|import|in|instanceof|let|new|null|of|return|set|static|super|switch|this|throw|true|try|typeof|undefined|var|void|while|with|yield)\b/g,
    typescript: /\b(?:abstract|any|as|asserts|async|await|boolean|break|case|catch|class|const|continue|declare|default|delete|do|else|enum|export|extends|false|finally|for|from|function|get|if|implements|import|in|infer|instanceof|interface|keyof|let|namespace|never|new|null|number|object|of|private|protected|public|readonly|return|set|static|string|super|switch|symbol|this|throw|true|try|type|typeof|undefined|unknown|var|void|while|yield)\b/g,
    python: /\b(?:and|as|assert|async|await|break|class|continue|def|del|elif|else|except|False|finally|for|from|global|if|import|in|is|lambda|None|nonlocal|not|or|pass|raise|return|True|try|while|with|yield)\b/g,
    sql: /\b(?:SELECT|FROM|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|FULL|ON|GROUP|BY|ORDER|HAVING|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|ALTER|DROP|TABLE|VIEW|INDEX|AS|AND|OR|NOT|NULL|IS|IN|EXISTS|CASE|WHEN|THEN|ELSE|END|DISTINCT|UNION|ALL|LIMIT|OFFSET|WITH|OVER|PARTITION|DESC|ASC)\b/gi,
    bash: /\b(?:if|then|else|elif|fi|for|while|in|do|done|case|esac|function|select|until|time|coproc|echo|printf|export|local|readonly|return|exit|source)\b/g,
    kotlin: /\b(?:as|break|class|continue|do|else|false|for|fun|if|in|interface|is|null|object|package|return|super|this|throw|true|try|typealias|val|var|when|while|by|catch|constructor|delegate|dynamic|field|file|finally|get|import|init|param|property|receiver|set|setparam|where|actual|abstract|annotation|companion|const|crossinline|data|enum|expect|external|final|infix|inline|inner|internal|lateinit|noinline|open|operator|out|override|private|protected|public|reified|sealed|suspend|tailrec|vararg)\b/g
  };

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
  }

  function safeUrl(url) {
    const value = String(url || '').trim();
    if (/^(https?:|mailto:)/i.test(value)) return value;
    return '#';
  }

  function renderInline(raw) {
    let text = String(raw == null ? '' : raw);
    const tokens = [];
    const protect = html => {
      const id = tokens.length;
      tokens.push(html);
      return `\u0000TOKEN${id}\u0000`;
    };

    // Inline code first so markdown markers inside code stay literal.
    text = text.replace(/`([^`\n]+)`/g, (_, code) => protect(`<code class="inline-code">${escapeHtml(code)}</code>`));

    // The assistant is explicitly allowed to use <br> inside Markdown table cells. Preserve only this
    // harmless tag before the general HTML escaping below; all other raw HTML remains escaped.
    text = text.replace(/<br\s*\/?\s*>/gi, () => protect('<br>'));

    // Markdown links.
    text = text.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (_, label, url, title) => {
      const href = safeUrl(url);
      const titleAttr = title ? ` title="${escapeHtml(title)}"` : '';
      return protect(`<a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer"${titleAttr}>${escapeHtml(label)}</a>`);
    });

    // Bare links are useful in technical answers and should not look like plain text.
    text = text.replace(/(^|[\s(])((?:https?:\/\/)[^\s<)]+)(?=$|[\s).,!?:;])/g, (_, prefix, url) => {
      const href = safeUrl(url);
      return `${prefix}${protect(`<a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(url)}</a>`)}`;
    });

    text = escapeHtml(text);
    text = text
      .replace(/\*\*([^*\n][\s\S]*?)\*\*/g, '<strong>$1</strong>')
      .replace(/__([^_\n][\s\S]*?)__/g, '<strong>$1</strong>')
      .replace(/~~([^~\n][\s\S]*?)~~/g, '<del>$1</del>')
      .replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>')
      .replace(/(^|[^_])_([^_\n]+)_(?!_)/g, '$1<em>$2</em>');

    return text.replace(/\u0000TOKEN(\d+)\u0000/g, (_, id) => tokens[Number(id)] || '');
  }

  function detectLanguage(code) {
    const t = String(code || '').trim();
    if (!t) return 'text';
    if (/^\s*[{[]/.test(t)) {
      try { JSON.parse(t); return 'json'; } catch (_) { /* ignore */ }
    }
    if (/\bpackage\s+[\w.]+\s*;|\bpublic\s+(?:class|interface|record|enum)\b|\bimport\s+java\./.test(t)) return 'java';
    if (/\b(?:const|let|var)\s+\w+\s*=|=>|\bfunction\s+\w+\s*\(/.test(t)) return 'javascript';
    if (/\binterface\s+\w+\s*\{|:\s*(?:string|number|boolean)\b/.test(t)) return 'typescript';
    if (/^\s*(?:def|class)\s+\w+.*:\s*$/m.test(t) || /\bimport\s+(?:os|sys|pandas|numpy)\b/.test(t)) return 'python';
    if (/\bSELECT\b[\s\S]*\bFROM\b|\bINSERT\s+INTO\b|\bUPDATE\s+\w+\s+SET\b/i.test(t)) return 'sql';
    if (/^\s*<\?xml\b|^\s*<\w+[\s>]/.test(t)) return /<html\b|<!doctype\s+html/i.test(t) ? 'html' : 'xml';
    if (/^\s*(?:#!\/bin\/(?:ba)?sh|(?:sudo\s+)?(?:cd|ls|grep|awk|sed|curl|chmod|mkdir)\b)/m.test(t)) return 'bash';
    if (/^\s*[.#]?[\w-]+\s*\{[\s\S]*:[^;]+;/.test(t)) return 'css';
    return 'text';
  }

  function normalizeLanguage(lang) {
    const key = String(lang || '').toLowerCase();
    if (key === 'js') return 'javascript';
    if (key === 'ts') return 'typescript';
    if (key === 'py') return 'python';
    if (key === 'sh' || key === 'shell') return 'bash';
    if (key === 'cs') return 'csharp';
    return key || 'text';
  }

  function codeExtension(lang) {
    const key = String(lang || '').toLowerCase();
    return ({
      java: 'java', javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py',
      json: 'json', xml: 'xml', html: 'html', css: 'css', sql: 'sql', bash: 'sh', sh: 'sh', shell: 'sh',
      yaml: 'yml', yml: 'yml', markdown: 'md', md: 'md', c: 'c', cpp: 'cpp', csharp: 'cs', cs: 'cs',
      go: 'go', rust: 'rs', kotlin: 'kt', groovy: 'groovy', powershell: 'ps1', ps1: 'ps1', dockerfile: 'Dockerfile'
    })[key] || 'txt';
  }

  function languageLabel(lang) {
    const key = String(lang || '').toLowerCase();
    return LANGUAGE_NAMES[key] || (lang ? String(lang) : 'Code');
  }

  function icon(name) {
    const icons = {
      copy: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="10" height="10" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>',
      download: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12"></path><path d="m7 10 5 5 5-5"></path><path d="M5 21h14"></path></svg>',
      wrap: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7h13a4 4 0 1 1 0 8H9"></path><path d="m12 12-3 3 3 3"></path><path d="M3 17h3"></path></svg>'
    };
    return icons[name] || '';
  }

  function highlightSegment(value, lang) {
    const normalized = normalizeLanguage(lang);
    let html = escapeHtml(value);
    const keywordRegex = KEYWORDS[normalized];
    if (keywordRegex) html = html.replace(keywordRegex, '<span class="tok-keyword">$&</span>');
    html = html.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="tok-number">$1</span>');
    return html;
  }

  // Small dependency-free highlighter. Strings/comments are isolated before keyword highlighting,
  // so formatting never changes the code text that Copy/Download uses.
  function highlightCode(code, lang) {
    const normalized = normalizeLanguage(lang);
    if (normalized === 'text' || normalized === 'markdown') return escapeHtml(code);

    if (normalized === 'json') {
      return escapeHtml(code)
        .replace(/(&quot;(?:\\.|[^&])*?&quot;)(\s*:)?/g, (_, str, colon) => colon ? `<span class="tok-property">${str}</span>${colon}` : `<span class="tok-string">${str}</span>`)
        .replace(/\b(true|false|null)\b/g, '<span class="tok-keyword">$1</span>')
        .replace(/\b(-?\d+(?:\.\d+)?)\b/g, '<span class="tok-number">$1</span>');
    }

    if (normalized === 'html' || normalized === 'xml') {
      return escapeHtml(code)
        .replace(/(&lt;\/?)([\w:-]+)/g, '$1<span class="tok-tag">$2</span>')
        .replace(/([\w:-]+)(=)(&quot;.*?&quot;)/g, '<span class="tok-property">$1</span>$2<span class="tok-string">$3</span>')
        .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="tok-comment">$1</span>');
    }

    const stringCommentRegex = normalized === 'python'
      ? /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|#[^\n]*)/g
      : normalized === 'sql'
        ? /('(?:''|[^'])*'|--[^\n]*|\/\*[\s\S]*?\*\/)/g
        : /("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\/\/[^\n]*|\/\*[\s\S]*?\*\/)/g;

    let out = '';
    let last = 0;
    String(code).replace(stringCommentRegex, (match, _g, offset) => {
      out += highlightSegment(String(code).slice(last, offset), normalized);
      const isComment = /^(?:#|\/\/|\/\*|--)/.test(match);
      out += `<span class="${isComment ? 'tok-comment' : 'tok-string'}">${escapeHtml(match)}</span>`;
      last = offset + match.length;
      return match;
    });
    out += highlightSegment(String(code).slice(last), normalized);
    return out;
  }

  function renderCode(code, requestedLang, openFence) {
    const detected = requestedLang && requestedLang.toLowerCase() !== 'code' ? requestedLang.toLowerCase() : detectLanguage(code);
    const lang = normalizeLanguage(detected);
    const label = languageLabel(detected);
    const lines = String(code).split('\n');
    const lineNumbers = lines.map((_, index) => `<span>${index + 1}</span>`).join('');
    const highlighted = highlightCode(code, lang);

    return `<section class="code-block${openFence ? ' code-streaming' : ''}" data-lang="${escapeHtml(lang)}" data-ext="${escapeHtml(codeExtension(lang))}">
      <div class="code-head">
        <span class="code-language"><span class="language-dot"></span>${escapeHtml(label)}${openFence ? '<span class="stream-badge">streaming</span>' : ''}</span>
        <div class="code-actions">
          <button class="code-btn" type="button" data-code-action="wrap" title="Toggle line wrap" aria-label="Toggle line wrap">${icon('wrap')}<span>Wrap</span></button>
          <button class="code-btn" type="button" data-code-action="copy" title="Copy code" aria-label="Copy code">${icon('copy')}<span>Copy</span></button>
          <button class="code-btn" type="button" data-code-action="download" title="Download code" aria-label="Download code">${icon('download')}<span>Download</span></button>
        </div>
      </div>
      <div class="code-body"><div class="line-numbers" aria-hidden="true">${lineNumbers}</div><pre><code>${highlighted}</code></pre></div>
    </section>`;
  }

  function isTableDivider(line) {
    const stripped = String(line || '').trim().replace(/^\|/, '').replace(/\|$/, '');
    const cells = stripped.split('|').map(v => v.trim());
    return cells.length > 0 && cells.every(cell => /^:?-{3,}:?$/.test(cell));
  }

  function splitTableCells(line) {
    let s = String(line || '').trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|')) s = s.slice(0, -1);
    const cells = [];
    let current = '';
    let escaped = false;
    for (const ch of s) {
      if (escaped) { current += ch; escaped = false; continue; }
      if (ch === '\\') { escaped = true; current += ch; continue; }
      if (ch === '|') { cells.push(current.trim()); current = ''; continue; }
      current += ch;
    }
    cells.push(current.trim());
    return cells;
  }

  function isBlockStart(lines, i) {
    const line = lines[i] || '';
    const next = lines[i + 1] || '';
    if (!line.trim()) return true;
    if (/^\s{0,3}#{1,6}\s+/.test(line)) return true;
    if (/^\s{0,3}(?:---+|___+|\*\*\*+)\s*$/.test(line)) return true;
    if (/^\s{0,3}>\s?/.test(line)) return true;
    if (/^\s*(?:[-+*]|\d+[.)])\s+/.test(line)) return true;
    if (line.includes('|') && isTableDivider(next)) return true;
    return false;
  }

  function renderTable(lines, start) {
    const header = splitTableCells(lines[start]);
    const align = splitTableCells(lines[start + 1]).map(cell => {
      const left = cell.startsWith(':');
      const right = cell.endsWith(':');
      return left && right ? 'center' : right ? 'right' : left ? 'left' : '';
    });
    const rows = [];
    let i = start + 2;
    while (i < lines.length && lines[i].trim() && lines[i].includes('|')) {
      if (/^\s*(```|~~~)/.test(lines[i])) break;
      rows.push(splitTableCells(lines[i]));
      i++;
    }
    let html = '<div class="md-table-wrap"><table class="md-table"><thead><tr>';
    header.forEach((cell, idx) => html += `<th${align[idx] ? ` style="text-align:${align[idx]}"` : ''}>${renderInline(cell)}</th>`);
    html += '</tr></thead><tbody>';
    rows.forEach(row => {
      html += '<tr>';
      header.forEach((_, idx) => html += `<td${align[idx] ? ` style="text-align:${align[idx]}"` : ''}>${renderInline(row[idx] || '')}</td>`);
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    return { html, next: i };
  }

  function listInfo(line) {
    const m = String(line || '').match(/^(\s*)([-+*]|\d+[.)])\s+(.+)$/);
    if (!m) return null;
    return { indent: m[1].replace(/\t/g, '    ').length, marker: m[2], ordered: /^\d/.test(m[2]), text: m[3] };
  }

  function renderList(lines, start) {
    const first = listInfo(lines[start]);
    if (!first) return { html: '', next: start + 1 };
    const tag = first.ordered ? 'ol' : 'ul';
    const baseIndent = first.indent;
    let html = `<${tag} class="md-list">`;
    let i = start;

    while (i < lines.length) {
      const info = listInfo(lines[i]);
      if (!info || info.indent < baseIndent || info.ordered !== first.ordered) break;
      if (info.indent > baseIndent) {
        // Nested block belongs to previous item.
        const nested = renderList(lines, i);
        html = html.replace(/<\/li>\s*$/, `${nested.html}</li>`);
        i = nested.next;
        continue;
      }

      let item = info.text;
      const task = item.match(/^\[([ xX])\]\s+(.+)$/);
      if (task) {
        const checked = task[1].toLowerCase() === 'x';
        item = `<span class="task-item"><input type="checkbox" disabled ${checked ? 'checked' : ''}><span>${renderInline(task[2])}</span></span>`;
      } else {
        item = renderInline(item);
      }
      html += `<li>${item}</li>`;
      i++;

      // Continuation text indented under this list item.
      while (i < lines.length && lines[i].trim() && !listInfo(lines[i]) && /^\s{2,}/.test(lines[i])) {
        html = html.replace(/<\/li>\s*$/, `<div class="list-continuation">${renderInline(lines[i].trim())}</div></li>`);
        i++;
      }
    }
    html += `</${tag}>`;
    return { html, next: i };
  }

  function renderBlockQuote(lines, start) {
    const content = [];
    let i = start;
    while (i < lines.length) {
      const match = lines[i].match(/^\s{0,3}>\s?(.*)$/);
      if (!match) break;
      content.push(match[1]);
      i++;
    }

    const first = (content[0] || '').trim();
    const callout = first.match(/^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*(.*)$/i);
    if (callout) {
      const type = callout[1].toLowerCase();
      content[0] = callout[2] || '';
      const title = type.charAt(0).toUpperCase() + type.slice(1);
      return {
        html: `<aside class="md-callout ${type}"><div class="callout-title">${escapeHtml(title)}</div><div class="callout-body">${renderTextBlocks(content.join('\n'))}</div></aside>`,
        next: i
      };
    }

    return { html: `<blockquote class="md-quote">${renderTextBlocks(content.join('\n'))}</blockquote>`, next: i };
  }

  function renderParagraph(lines) {
    let out = '';
    lines.forEach((line, index) => {
      const hardBreak = /\s{2}$/.test(line);
      const clean = line.replace(/\s{2}$/, '');
      if (index > 0) out += hardBreak ? '<br>' : ' ';
      out += renderInline(clean.trim());
    });
    return out;
  }

  function renderTextBlocks(raw) {
    const lines = String(raw || '').replace(/\r\n?/g, '\n').split('\n');
    let html = '';
    let i = 0;

    while (i < lines.length) {
      const line = lines[i];
      if (!line.trim()) { i++; continue; }

      let match = line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
      if (match) {
        const level = match[1].length;
        html += `<h${level} class="md-h md-h${level}">${renderInline(match[2])}</h${level}>`;
        i++;
        continue;
      }

      if (/^\s{0,3}(?:---+|___+|\*\*\*+)\s*$/.test(line)) {
        html += '<hr class="md-hr">';
        i++;
        continue;
      }

      if (/^\s{0,3}>\s?/.test(line)) {
        const quote = renderBlockQuote(lines, i);
        html += quote.html;
        i = quote.next;
        continue;
      }

      if (line.includes('|') && i + 1 < lines.length && isTableDivider(lines[i + 1])) {
        const table = renderTable(lines, i);
        html += table.html;
        i = table.next;
        continue;
      }

      if (listInfo(line)) {
        const list = renderList(lines, i);
        html += list.html;
        i = list.next;
        continue;
      }

      const paragraph = [line];
      i++;
      while (i < lines.length && lines[i].trim() && !isBlockStart(lines, i)) {
        paragraph.push(lines[i]);
        i++;
      }
      html += `<p class="md-p">${renderParagraph(paragraph)}</p>`;
    }
    return html;
  }

  function splitFencedBlocks(raw) {
    const lines = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').split('\n');
    const segments = [];
    let text = [];
    let code = [];
    let inCode = false;
    let fence = '```';
    let lang = '';

    const flushText = () => {
      if (text.length) {
        segments.push({ type: 'text', text: text.join('\n') });
        text = [];
      }
    };

    const flushCode = open => {
      segments.push({ type: 'code', code: code.join('\n'), lang, open });
      code = [];
      lang = '';
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!inCode) {
        const open = line.match(/^\s*(```|~~~)\s*([^\s`]*)?.*$/);
        if (open) {
          flushText();
          inCode = true;
          fence = open[1];
          lang = (open[2] || '').trim();
        } else {
          text.push(line);
        }
      } else {
        const closeRegex = fence === '```' ? /^\s*```\s*$/ : /^\s*~~~\s*$/;
        if (closeRegex.test(line)) {
          flushCode(false);
          inCode = false;
        } else {
          code.push(line);
        }
      }
    }

    if (inCode) flushCode(true);
    flushText();
    return segments;
  }

  function looksLikeStandaloneCode(text) {
    const t = String(text || '').trim();
    if (!t || t.includes('\n\n')) return false;
    const lines = t.split('\n');
    if (lines.length < 3) return false;
    const codeish = lines.filter(line => /[{};]|^\s*(?:import|package|public|private|class|def|function|const|let|var|SELECT|INSERT|UPDATE|<\w|#include)\b/i.test(line)).length;
    return codeish / lines.length >= 0.55;
  }

  function render(raw, options) {
    const text = String(raw == null ? '' : raw);
    const opts = options || {};
    const segments = splitFencedBlocks(text);

    if (segments.length === 1 && segments[0].type === 'text' && looksLikeStandaloneCode(text)) {
      return renderCode(text, detectLanguage(text), !!opts.streaming);
    }

    return segments.map(segment => {
      if (segment.type === 'code') return renderCode(segment.code, segment.lang, segment.open && !!opts.streaming);
      return renderTextBlocks(segment.text);
    }).join('');
  }

  global.MarkdownRenderer = {
    render,
    renderInline,
    escapeHtml,
    detectLanguage,
    codeExtension
  };
})(window);
