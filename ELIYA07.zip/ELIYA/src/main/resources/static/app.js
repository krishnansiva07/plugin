'use strict';

const MAX_AGENT_EVENTS_RETAINED = 5000;
const AGENT_RENDER_THROTTLE_MS = 120;

// Browser storage can be disabled by enterprise/privacy policies. A storage exception used to
// abort app.js during startup, which left model controls empty and every button unwired. Keep a
// small in-memory fallback so the UI remains fully usable even when persistence is unavailable.
const volatileStorage = new Map();
function storageKey(scope, key) { return `${scope}:${key}`; }
function storageGet(scope, key) {
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    const value = store.getItem(key);
    if (value !== null) return value;
  } catch (_) { /* enterprise/private browser may block storage */ }
  return volatileStorage.has(storageKey(scope, key)) ? volatileStorage.get(storageKey(scope, key)) : null;
}
function storageSet(scope, key, value) {
  volatileStorage.set(storageKey(scope, key), String(value));
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    store.setItem(key, String(value));
  } catch (_) { /* memory fallback already holds the value */ }
}
function storageRemove(scope, key) {
  volatileStorage.delete(storageKey(scope, key));
  try {
    const store = scope === 'session' ? window.sessionStorage : window.localStorage;
    store.removeItem(key);
  } catch (_) { /* ignore */ }
}

const DEFAULT_MODEL_CATALOG = [
  { id:'qwen3.8-27b', type:'chat', context:262144 },
  { id:'gpt-oss-120b-ITG', type:'chat', context:131072 },
  { id:'mistral-small-4-ITG', type:'chat', context:262144 },
  { id:'qwen3.6-27b', type:'chat', context:262144 },
  { id:'qwen3.6-35b-a3b', type:'chat', context:262144 },
  { id:'qwen-latest', type:'chat', context:262144 },
  { id:'mistral-medium-2508-ITG', type:'chat', context:128000 },
  { id:'mistral-small-2506-ITG', type:'chat', context:128000 },
  { id:'gemma-4-31b-ITG', type:'chat', context:262144 },
  { id:'mistral-ocr-2512-ITG', type:'ocr', context:128000 },
  { id:'mistral-ocr-4-ITG', type:'ocr', context:128000 },
  { id:'qwen3-embedding-8b', type:'embedding', context:32768 },
  { id:'bge-m3-ITG', type:'embedding', context:8192 },
  { id:'bge-large-en-v1.5-ITG', type:'embedding', context:512 },
  { id:'multilingual-e5-large-ITG', type:'embedding', context:512 }
];

function loadModelCatalog() {
  try {
    const saved = JSON.parse(storageGet('local', 'llm.modelCatalog') || 'null');
    if (Array.isArray(saved) && saved.length) return saved.filter(item => item && String(item.id || '').trim()).map(item => ({
      id:String(item.id).trim(), type:['chat','embedding','vision','ocr'].includes(item.type) ? item.type : 'chat',
      context:Math.max(0, Number(item.context || 0))
    }));
  } catch (_) { /* reset to defaults */ }
  return DEFAULT_MODEL_CATALOG.map(item => ({...item}));
}

function saveModelCatalog() {
  storageSet('local', 'llm.modelCatalog', JSON.stringify(state.modelCatalog));
}

function modelContextWindowsSetting() {
  return state.modelCatalog.filter(item => Number(item.context) > 0).map(item => `${item.id}=${Math.round(Number(item.context))}`).join('\n');
}

function modelTypesSetting() {
  return state.modelCatalog.filter(item => item && item.id).map(item => `${item.id}=${item.type || 'chat'}`).join('\n');
}

function storedSetting(key, defaultValue = '') {
  const value = storageGet('local', key);
  return value === null ? defaultValue : value;
}

const DEFAULT_FALLBACK_MODELS = ''; // optional fallbacks are disabled by default

const PROMPT_LIBRARY = [
  {
    title: 'Write JUnit 5 Tests for Existing Code',
    category: 'Java / JUnit',
    prompt: `Project path: <path>
Target class/package: <class, package or file>

Read the project instructions, pom.xml/build.gradle, target implementation and nearby tests first. Follow the existing JUnit version, mocking library, naming, fixtures and assertion style. Create meaningful JUnit tests for normal paths, boundaries, null/invalid input and important failure paths without changing production behavior just to make tests pass.

Finish all required test-code changes first. Then run one final targeted compile/test command for the affected module or test class, fix any failures caused by the change, rerun, and review the final diff.`
  },
  {
    title: 'Generate JUnit Tests from Requirement',
    category: 'Java / JUnit',
    prompt: `Project path: <path>
Requirement / acceptance criteria: <paste requirement>

Trace the production code that implements this requirement and inspect the repository's existing JUnit conventions. Build a compact coverage map from acceptance criteria to test cases, then add only the required JUnit tests and reusable test data/helpers.

Do not compile after every edit. Complete the coherent test changes first, then run the smallest final compile/test scope that proves the new tests work. Fix failures and rerun until verified or a genuine environment blocker is proven.`
  },
  {
    title: 'Fix an Issue from Error or Stack Trace',
    category: 'Debugging',
    prompt: `Project path: <path>
Error / stack trace / reproduction: <paste here>
Expected behavior: <expected result>

Read project instructions and inspect the exact failing path before editing. Use the error, logs and current code as evidence; identify the first real root cause instead of patching symptoms. Make the smallest maintainable fix and add/update a regression test when practical.

Complete all related edits first. Then run the final targeted compile/test/execution that best reproduces the user's failure, fix any remaining issue, rerun, and review the final diff.`
  },
  {
    title: 'Fix Using a Reference Project',
    category: 'Reference project',
    prompt: `Target project: <target path>
Reference project: <reference path>
Issue / behavior to match: <describe>

Treat the reference project as read-only unless I explicitly say otherwise. Compare the relevant architecture, configuration, implementation and tests. Identify the smallest transferable pattern that fixes the target while respecting the target project's own conventions; do not blindly copy unrelated files or dependencies.

Apply all coherent target-project changes first, then compile/test/execute the target once at final verification based on the requested behavior. Fix failures and rerun as needed.`
  },
  {
    title: 'Migrate Feature from Reference Project',
    category: 'Migration',
    prompt: `Target project: <target path>
Reference/source project: <reference path>
Feature/module to migrate: <feature>

Read instructions and build files in both projects. Treat the source as reference/read-only. Map behavior, public interfaces, dependencies, configuration, tests and data from source to target, then implement the feature using the target project's architecture rather than performing a line-by-line copy.

Complete the migration changes as a coherent set. After all changes are in place, run the target project's final compile/test/execution required by the user, fix failures, rerun, and report any deliberate differences from the source.`
  },
  {
    title: 'Implement or Modify a Feature',
    category: 'Development',
    prompt: `Project path: <path>
Requirement: <paste requirement>

Read project instructions, build configuration, relevant implementation and existing tests. Trace the current design, make the smallest coherent implementation that follows repository conventions, and update focused tests/documentation only where needed.

Batch the implementation edits before verification. Do not compile after each plan step. When all requested changes are complete, run the final compile/test/execution appropriate to the user's request and project type, fix failures, rerun, then review the final diff.`
  },
  {
    title: 'Refactor Without Changing Behavior',
    category: 'Refactoring',
    prompt: `Project path: <path>
Refactor goal/scope: <describe>

Inspect the current design, callers and tests. Preserve observable behavior and public contracts unless I explicitly request an API change. Remove duplication or improve structure only inside the requested scope; avoid speculative cleanup.

Make the full coherent refactor first. Then run the final targeted compile/tests for the affected module, fix regressions, rerun and summarize the structural changes and behavior-preservation evidence.`
  },
  {
    title: 'Summarise a Project or Module',
    category: 'Analysis',
    prompt: `Project path: <path>
Scope: <whole project, module, package or feature>

Read the relevant instructions, build files, entry points, main packages, configuration and representative tests. Produce a concise developer summary covering purpose, architecture, request/data flow, important classes/modules, dependencies, build/run/test commands, extension points, risks and any obvious technical debt. Distinguish confirmed facts from assumptions. Do not modify files unless I explicitly ask.`
  },
  {
    title: 'Review Code and Find Improvement Gaps',
    category: 'Code review',
    prompt: `Project path: <path>
Review scope: <module/files/whole project>

Inspect the current code and tests as a senior developer. Prioritize correctness, reliability, maintainability, security, performance, testability and unnecessary complexity. Give evidence-backed findings with file/class references and severity. If I ask you to implement the improvements, make the coherent changes first and perform one final compile/test verification after the edits are complete.`
  },
  {
    title: 'Playwright MCP + Java Selenium/TestNG/Cucumber',
    category: 'Browser diagnosis',
    prompt: `Project path: C:\\work\\selenium-framework

Keep Java + Selenium + TestNG + Cucumber as the test runner. Read AGENTS.md, relevant .agents/skills/*/SKILL.md, pom.xml, runner, hooks, page objects and .agents/mcp.json first. Determine the active Cucumber tag expression from the framework instead of asking me to repeat it.

Run the smallest affected scope. If browser evidence is required, use Playwright MCP only to inspect the live DOM/accessibility tree, frames, overlays, redirects, visibility and stable locator state. Do not add Playwright to pom.xml just for MCP.

Apply the smallest maintainable Selenium/framework fix, rerun and verify the current revision. If this reveals a reusable convention, update AGENTS.md or a focused .agents/skills/playwright-mcp-testing/SKILL.md without storing secrets or temporary incident details.`
  },
  {
    title: 'Playwright Framework Improvement',
    category: 'Testing',
    prompt: `Project path: C:\\work\\playwright-framework

Read AGENTS.md, relevant skills, package.json, playwright.config.*, fixtures, page/component objects, reporters and CI configuration. Improve this framework for: <goal>.

Prefer Playwright-native auto-waiting, role/test-id locators, fixtures, isolated state and useful failure artifacts. Remove redundant sleeps/retries instead of adding more. Run lint/typecheck if configured plus targeted tests, fix real failures and review the final diff.

Persist only reusable conventions in AGENTS.md or a focused .agents/skills/<name>/SKILL.md.`
  },
  {
    title: 'Migrate Java Selenium to Playwright TypeScript',
    category: 'Migration',
    prompt: `Target project: C:\\work\\playwright-framework
Source reference: C:\\work\\selenium-framework

Treat the Selenium source as read-only. Read AGENTS.md and skills in both projects. Map runner/tags, scenarios, page objects, waits, data, auth/session handling, assertions, reports and CI to the target architecture.

Migrate: <feature/module/tag>. Preserve business behavior but do not translate Selenium APIs line by line. Use Playwright-native fixtures, auto-waiting, resilient locators and parallel-safe data. Migrate the requested coherent scope, keep an explicit source-to-target coverage mapping, and defer compile/test execution until the requested migration edits are complete unless an intermediate command is required to resolve a concrete blocker.

Create/update reusable migration guidance in AGENTS.md and .agents/skills/selenium-to-playwright/SKILL.md when useful.`
  },
  {
    title: 'Add Tests to Existing Java Automation Framework',
    category: 'Testing',
    prompt: `Project path: C:\\work\\selenium-framework
Requirement: <paste requirement>

Read AGENTS.md and relevant skills. Inspect the existing Cucumber/TestNG runner, hooks, page objects, step definitions, test-data pattern and reporting. Reuse the framework instead of creating a parallel design.

Add focused business-readable scenarios and only the required implementation. Prefer stable locators and existing abstractions. Run the smallest relevant tag/scope, fix compile/runtime/test failures, then review the final diff. Save reusable testing conventions to AGENTS.md or a focused skill only when they will help future tasks.`
  },
  {
    title: 'Implement a Feature',
    category: 'Development',
    prompt: `Project path: <path>
Feature: <requirement>

Read AGENTS.md, relevant skills, project structure, build configuration and nearest implementation/tests. Trace the current architecture first, reuse established patterns and preserve public behavior outside the requested scope.

Implement the smallest coherent change and add/update focused tests. After all requested edits are complete, run the smallest high-signal final build/test/check, fix failures caused by the change and review the final diff. Do not claim completion without real verification. Record only stable reusable conventions in AGENTS.md or a focused skill.`
  },
  {
    title: 'Diagnose and Fix a Bug',
    category: 'Development',
    prompt: `Project path: <path>
Failure/error: <paste failure or reproduction>

Read AGENTS.md and relevant skills. Reproduce or trace the failure with the smallest relevant command/test and identify the first evidence-backed root cause. Do not patch symptoms blindly.

Implement the smallest correct fix, add a regression test when practical, rerun the failing scope and review the final diff. Continue until verified or a genuine external blocker is proven. Capture a reusable diagnostic convention in AGENTS.md/skills only if it will prevent repeated future work.`
  },
  {
    title: 'Stabilize a Flaky Regression Suite',
    category: 'Testing',
    prompt: `Project path: <path>
Scope/tag: <scope>

Read AGENTS.md, skills, runner, waits, locators, fixtures/hooks, test data, retries, parallel settings and failure artifacts. Run the smallest representative failing scope and classify failures from evidence: product defect, locator, synchronization, shared state/data, environment or framework.

Fix root causes; do not hide failures with arbitrary sleeps, global retries or weaker assertions. Rerun enough to verify the current revision and document only stable anti-flakiness conventions in AGENTS.md or a focused testing skill.`
  },
  {
    title: 'Create AGENTS.md and Reusable Skills',
    category: 'Agent guidance',
    prompt: `Project path: <path>

Analyze the repository deeply. Read existing AGENTS.md, CLAUDE.md, .agents/skills, build/test configuration, architecture docs and representative implementation/tests.

Identify stable architecture boundaries, validated commands, coding/testing conventions, safety constraints and recurring workflows future agents must know. Create or improve a concise root AGENTS.md and only the focused .agents/skills/<name>/SKILL.md files that materially improve future work. Keep them evidence-based, non-duplicative and free of secrets or temporary incident details. Validate the guidance against the repository before finishing.`
  }
];

const state = {
  conversationId: null,
  conversations: [],
  messages: [],
  attachments: [],
  filesById: new Map(),
  uploadingCount: 0,
  project: null,
  projectRootHandle: null,
  projectFallbackFiles: null,
  pendingProjectChanges: null,
  mode: ['chat','agent'].includes(storageGet('local', 'llm.mode')) ? storageGet('local', 'llm.mode') : 'chat',
  streaming: false,
  abortController: null,
  activeAgentRunId: null,
  agentWatchTimer: null,
  agentWatchdogCompleted: false,
  agentRenderTimer: null,
  renderTimer: null,
  editingIndex: null,
  historyMenuId: null,
  renameId: null,
  userScrolledUp: false,
  historyLoadSeq: 0,
  modelCatalog: loadModelCatalog(),
  config: {
    apiKey: storageGet('session', 'llm.apiKey') || storageGet('local', 'llm.apiKey') || '',
    baseUrl: storageGet('local', 'llm.baseUrl') || '',
    model: storageGet('local', 'llm.model') || '',
    chatModel: storedSetting('llm.chatModel', storageGet('local', 'llm.model') || 'mistral-small-4-ITG'),
    chatModels: storedSetting('llm.chatModels', storedSetting('llm.chatModel', storageGet('local', 'llm.model') || 'mistral-small-4-ITG')),
    visionModel: '',
    analysisModel: '',
    plannerModel: '',
    planValidatorModel: '',
    criticModel: '',
    embeddingModel: '',
    smartModelRouting: false,
    semanticRetrieval: false,
    temperature: Number(storageGet('local', 'llm.temperature') || 0.7),
    maxTokens: Number(storageGet('local', 'llm.maxTokens') || 0),
    contextChars: 0,
    contextWindowTokens: Number(storageGet('local', 'llm.contextWindowTokens') || (Number(storageGet('local', 'llm.contextChars') || 0) > 0 ? Math.floor(Number(storageGet('local', 'llm.contextChars')) / 4) : 0)),
    autoCompact: storageGet('local', 'llm.autoCompact') !== 'false',
    compactionKeepTokens: Number(storageGet('local', 'llm.compactionKeepTokens') || 8000),
    compactionBufferTokens: Number(storageGet('local', 'llm.compactionBufferTokens') || 20000),
    oldToolOutputChars: Number(storageGet('local', 'llm.oldToolOutputChars') || 1200),
    systemPrompt: storageGet('local', 'llm.systemPrompt') || '',
    useFileContext: storageGet('local', 'llm.useFileContext') !== 'false',
    agentAllowCommands: storageGet('local', 'llm.agentAllowCommands') !== 'false',
    agentEditPermission: storageGet('local', 'llm.agentEditPermission') || 'allow',
    agentShellPermission: storageGet('local', 'llm.agentShellPermission') || 'allow',
    agentReviewPermission: storageGet('local', 'llm.agentReviewPermission') || storageGet('local', 'llm.agentGitPermission') || 'allow',
    agentMcpPermission: storageGet('local', 'llm.agentMcpPermission') || 'allow',
    agentTaskPermission: storageGet('local', 'llm.agentTaskPermission') || 'allow',
    agentLspPermission: storageGet('local', 'llm.agentLspPermission') || 'allow',
    agentParallelReadTools: storageGet('local', 'llm.agentParallelReadTools') !== 'false',
    agentAutoApprove: storageGet('local', 'llm.agentAutoApprove') === 'true',
    agentPlanApproval: storageGet('local', 'llm.agentPlanApproval') !== 'false',
    agentFallbackModels: storedSetting('llm.agentFallbackModels', ''),
    agentFallbackEnabled: storageGet('local', 'llm.agentFallbackEnabled') === 'true',
    agentRecoveryAttempts: Math.max(1, Math.min(50, Number(storageGet('local', 'llm.agentRecoveryAttempts') || 3))),
    agentExtraCommands: storageGet('local', 'llm.agentExtraCommands') || '',
    rememberKey: Boolean(storageGet('local', 'llm.apiKey'))
  }
};

const $ = id => document.getElementById(id);
const esc = value => MarkdownRenderer.escapeHtml(value);

function activeModelForMode() {
  return state.mode === 'chat' ? (state.config.chatModel || state.config.model) : state.config.model;
}

function isConfigured() {
  return Boolean(state.config.apiKey && state.config.baseUrl && activeModelForMode());
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const body = await response.json();
        message = body.message || body.error || message;
      } else {
        const body = await response.text();
        if (body.trim()) message = body.trim().slice(0, 1200);
      }
    } catch (_) { /* ignore parse failure */ }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function toast(text, duration = 2300) {
  const node = $('toast');
  node.textContent = text;
  node.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add('hidden'), duration);
}

function saveConfig() {
  storageSet('local', 'llm.baseUrl', state.config.baseUrl);
  storageSet('local', 'llm.model', state.config.model);
  storageSet('local', 'llm.chatModel', state.config.chatModel || state.config.model || '');
  storageSet('local', 'llm.chatModels', configuredChatModels().join(', '));
  storageRemove('local', 'llm.visionModel');
  // Agent uses one primary model for the whole workflow. Clear legacy per-role routing.
  storageRemove('local', 'llm.analysisModel');
  storageRemove('local', 'llm.plannerModel');
  storageRemove('local', 'llm.planValidatorModel');
  storageRemove('local', 'llm.criticModel');
  storageRemove('local', 'llm.embeddingModel');
  storageSet('local', 'llm.smartModelRouting', 'false');
  storageSet('local', 'llm.semanticRetrieval', 'false');
  storageSet('local', 'llm.temperature', String(state.config.temperature));
  storageSet('local', 'llm.maxTokens', String(state.config.maxTokens));
  storageRemove('local', 'llm.contextChars');
  storageSet('local', 'llm.contextWindowTokens', String(state.config.contextWindowTokens));
  storageSet('local', 'llm.autoCompact', String(state.config.autoCompact));
  storageSet('local', 'llm.compactionKeepTokens', String(state.config.compactionKeepTokens));
  storageSet('local', 'llm.compactionBufferTokens', String(state.config.compactionBufferTokens));
  storageSet('local', 'llm.oldToolOutputChars', String(state.config.oldToolOutputChars));
  storageSet('local', 'llm.systemPrompt', state.config.systemPrompt);
  storageSet('local', 'llm.useFileContext', String(state.config.useFileContext));
  storageSet('local', 'llm.agentAllowCommands', String(state.config.agentAllowCommands));
  storageSet('local', 'llm.agentEditPermission', state.config.agentEditPermission);
  storageSet('local', 'llm.agentShellPermission', state.config.agentShellPermission);
  storageSet('local', 'llm.agentReviewPermission', state.config.agentReviewPermission);
  storageSet('local', 'llm.agentMcpPermission', state.config.agentMcpPermission);
  storageSet('local', 'llm.agentTaskPermission', state.config.agentTaskPermission);
  storageSet('local', 'llm.agentLspPermission', state.config.agentLspPermission);
  storageSet('local', 'llm.agentParallelReadTools', String(state.config.agentParallelReadTools));
  storageSet('local', 'llm.agentAutoApprove', String(state.config.agentAutoApprove));
  storageSet('local', 'llm.agentPlanApproval', String(state.config.agentPlanApproval));
  storageSet('local', 'llm.agentFallbackModels', state.config.agentFallbackModels || '');
  storageSet('local', 'llm.agentFallbackEnabled', String(Boolean(state.config.agentFallbackEnabled && state.config.agentFallbackModels)));
  storageSet('local', 'llm.agentRecoveryAttempts', String(state.config.agentRecoveryAttempts || 3));
  storageSet('local', 'llm.agentExtraCommands', state.config.agentExtraCommands || '');
  storageSet('local', 'llm.mode', state.mode);
  saveModelCatalog();

  if (state.config.rememberKey) {
    storageSet('local', 'llm.apiKey', state.config.apiKey);
    storageRemove('session', 'llm.apiKey');
  } else {
    storageRemove('local', 'llm.apiKey');
    if (state.config.apiKey) storageSet('session', 'llm.apiKey', state.config.apiKey);
    else storageRemove('session', 'llm.apiKey');
  }

  updateModelBadge();
  updateWelcomeMode();
  if (document.getElementById('attachmentTray')) renderAttachmentTray();
  refreshAgentModelStrip();
  refreshChatModelPicker();
}

function syncSettingsUi() {
  $('apiKey').value = state.config.apiKey;
  $('baseUrl').value = state.config.baseUrl;
  $('modelName').value = state.config.model || '';
  if ($('chatModel')) $('chatModel').value = configuredChatModels().join(', ');
  $('analysisModel').value = state.config.model || '';
  $('plannerModel').value = state.config.model || '';
  $('planValidatorModel').value = state.config.model || '';
  $('criticModel').value = state.config.model || '';
  $('embeddingModel').value = '';
  $('smartModelRouting').checked = false;
  $('semanticRetrieval').checked = false;
  $('temperature').value = state.config.temperature;
  $('maxTokens').value = state.config.maxTokens;
  $('contextWindowTokens').value = state.config.contextWindowTokens;
  $('autoCompact').checked = state.config.autoCompact;
  $('compactionKeepTokens').value = state.config.compactionKeepTokens;
  $('compactionBufferTokens').value = state.config.compactionBufferTokens;
  $('oldToolOutputChars').value = state.config.oldToolOutputChars;
  $('systemPrompt').value = state.config.systemPrompt;
  $('useFileContext').checked = state.config.useFileContext;
  $('agentAllowCommands').checked = state.config.agentAllowCommands;
  $('agentEditPermission').value = state.config.agentEditPermission;
  $('agentShellPermission').value = state.config.agentShellPermission;
  $('agentReviewPermission').value = state.config.agentReviewPermission;
  $('agentMcpPermission').value = state.config.agentMcpPermission;
  $('agentTaskPermission').value = state.config.agentTaskPermission;
  $('agentLspPermission').value = state.config.agentLspPermission;
  $('agentParallelReadTools').checked = state.config.agentParallelReadTools;
  $('agentAutoApprove').checked = state.config.agentAutoApprove;
  $('agentPlanApproval').checked = state.config.agentPlanApproval;
  $('agentFallbackModels').value = state.config.agentFallbackModels || '';
  if ($('agentFallbackEnabled')) $('agentFallbackEnabled').checked = Boolean(state.config.agentFallbackEnabled);
  renderFallbackModels();
  $('agentRecoveryAttempts').value = 3;
  $('agentExtraCommands').value = state.config.agentExtraCommands || '';
  $('rememberKey').checked = state.config.rememberKey;

  $('homeApiKey').value = state.config.apiKey;
  $('homeBaseUrl').value = state.config.baseUrl;
  $('homeModel').value = state.config.model || '';
  if ($('homeChatModel')) $('homeChatModel').value = configuredChatModels().join(', ');
  $('homeRemember').checked = state.config.rememberKey;
  renderModelCatalog();
}


function parseModelList(value) {
  return String(value || '').split(/[,\n]/).map(item => item.trim()).filter(Boolean);
}

function uniqueModelList(value) {
  const seen = new Set();
  return parseModelList(value).filter(model => {
    const key = model.toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function configuredChatModels() {
  const values = uniqueModelList(state.config.chatModels || state.config.chatModel || '');
  if (!values.length && state.config.chatModel) values.push(state.config.chatModel);
  return values;
}

function configuredAgentModels() {
  return state.config.model ? [state.config.model] : [];
}

function ensureModelsInCatalog(models, type = 'chat') {
  for (const raw of models || []) {
    const id = String(raw || '').trim();
    if (!id) continue;
    const existing = state.modelCatalog.find(item => item.id.toLowerCase() === id.toLowerCase());
    if (!existing) state.modelCatalog.push({id, type, context:0});
  }
}

function applyChatModelsText(value) {
  const models = uniqueModelList(value);
  state.config.chatModels = models.join(', ');
  state.config.chatModel = models[0] || '';
  ensureModelsInCatalog(models, 'chat');
  return models;
}

function applyAgentModelsText(value) {
  const model = String(value || '').trim();
  state.config.model = model;
  ensureModelsInCatalog(model ? [model] : [], 'chat');
  return model ? [model] : [];
}

function fallbackPrimaryModel() {
  const settingsOpen = !$('modalBackdrop')?.classList.contains('hidden');
  return String(settingsOpen ? ($('modelName')?.value || state.config.model || '') : (state.config.model || '')).trim();
}

function currentFallbackModels() {
  const raw = $('agentFallbackModels') ? $('agentFallbackModels').value : state.config.agentFallbackModels;
  const primary = fallbackPrimaryModel().toLowerCase();
  const seen = new Set();
  return parseModelList(raw).filter(model => {
    const key = model.toLowerCase();
    if (!key || key === primary || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 2);
}

function fallbackModelsEnabled() {
  const checkbox = $('agentFallbackEnabled');
  return checkbox ? checkbox.checked : Boolean(state.config.agentFallbackEnabled);
}

function writeFallbackModels(models) {
  const primary = fallbackPrimaryModel().toLowerCase();
  const values = [];
  const seen = new Set();
  for (const raw of models || []) {
    const model = String(raw || '').trim();
    const key = model.toLowerCase();
    if (!model || key === primary || seen.has(key)) continue;
    seen.add(key); values.push(model);
    if (values.length >= 2) break;
  }
  if ($('agentFallbackModels')) $('agentFallbackModels').value = values.join('\n');
  renderFallbackModels();
}

function renderFallbackModels() {
  const list = $('fallbackModelList');
  const select = $('fallbackModelSelect');
  const manager = $('fallbackManager');
  if (!list && !select && !manager) return;
  const enabled = fallbackModelsEnabled();
  if (manager) {
    manager.classList.toggle('hidden', !enabled);
    manager.setAttribute('aria-hidden', enabled ? 'false' : 'true');
  }
  const values = currentFallbackModels();
  if (list) {
    list.innerHTML = values.length ? values.map((model, index) => `<div class="fallback-model-row" data-fallback-index="${index}"><span class="fallback-order">${index + 1}</span><strong>${esc(model)}</strong><div class="fallback-row-actions"><button type="button" class="plan-icon-btn" data-fallback-action="up" title="Move up" aria-label="Move ${esc(model)} up">↑</button><button type="button" class="plan-icon-btn" data-fallback-action="down" title="Move down" aria-label="Move ${esc(model)} down">↓</button><button type="button" class="plan-icon-btn danger" data-fallback-action="remove" title="Remove fallback" aria-label="Remove ${esc(model)} fallback">×</button></div></div>`).join('')
      : '<div class="fallback-model-empty">Fallbacks are optional. Add up to two models.</div>';
  }
  if (select) {
    const used = new Set(values.map(v => v.toLowerCase()));
    const primary = fallbackPrimaryModel().toLowerCase();
    const available = state.modelCatalog.filter(item => item.type === 'chat' && item.id.toLowerCase() !== primary && !used.has(item.id.toLowerCase()));
    const atLimit = values.length >= 2;
    select.innerHTML = !atLimit && available.length
      ? '<option value="">Choose model…</option>' + available.map(item => `<option value="${esc(item.id)}">${esc(item.id)}</option>`).join('')
      : `<option value="">${atLimit ? 'Maximum 2 fallbacks selected' : 'No additional models'}</option>`;
    select.disabled = !enabled || atLimit || !available.length;
    if ($('addFallbackModelBtn')) $('addFallbackModelBtn').disabled = !enabled || atLimit || !available.length;
  }
}

function updateFallbackAt(index, action) {
  const values = currentFallbackModels();
  if (index < 0 || index >= values.length) return;
  if (action === 'remove') values.splice(index, 1);
  else if (action === 'up' && index > 0) [values[index - 1], values[index]] = [values[index], values[index - 1]];
  else if (action === 'down' && index + 1 < values.length) [values[index + 1], values[index]] = [values[index], values[index + 1]];
  writeFallbackModels(values);
}

function configuredModelPool() {
  return configuredAgentModels();
}

function refreshAgentModelStrip() {
  const input = $('agentModelSelect');
  if (!input) return;
  if (document.activeElement !== input) input.value = state.config.model || '';
  input.disabled = state.streaming;
}

function autoRoleModel(role, pool) {
  const values = pool || configuredModelPool();
  if (role === 'critic' || role === 'validator' || role === 'analysis') return values.find(m => /gpt-oss/i.test(m)) || values.find(m => /qwen3\.8|mistral-small-4/i.test(m)) || '';
  if (role === 'planner') return values.find(m => /gpt-oss|qwen3\.8|mistral-small-4/i.test(m)) || '';
  return '';
}

function shortModel(model) {
  const value = String(model || 'primary');
  return value.length > 24 ? value.slice(0, 22) + '…' : value;
}

function chooseAgentPrimaryModel(selected) {
  const next = String(selected || '').trim();
  if (!next) return;
  state.config.model = next;
  ensureModelsInCatalog([next], 'chat');
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  saveConfig();
  syncSettingsUi();
  refreshAgentModelStrip();
  toast(`Agent model: ${next}`);
}

function chooseChatModel(selected) {
  const next = String(selected || '').trim();
  if (!next) return;
  const pool = uniqueModelList([next, ...configuredChatModels()].join(','));
  state.config.chatModel = next;
  state.config.chatModels = pool.join(', ');
  ensureModelsInCatalog([next], isVisionCapableModel(next) ? 'vision' : 'chat');
  saveConfig();
  refreshChatModelPicker();
  updateContextBadge();
  renderAttachmentTray();
  toast(`Chat model: ${next}`);
}

function updateModelBadge() {
  const pool = configuredModelPool();
  const active = activeModelForMode();
  if (state.mode === 'chat') $('modelBadge').textContent = active ? `Chat · ${active}` : 'Chat model not configured';
  else $('modelBadge').textContent = active ? `Agent · ${active}${pool.length > 1 ? ` +${pool.length - 1}` : ''}` : 'Agent model not configured';
}

function chatCapableModels() {
  return state.modelCatalog.filter(item => ['chat','vision'].includes(item.type));
}

function agentCapableModels() {
  return state.modelCatalog.filter(item => item.type === 'chat');
}

function fillModelSelect(control, models, selected, emptyLabel) {
  if (!control) return;
  const wanted = String(selected || '').trim();
  if (control.tagName !== 'SELECT') {
    if (document.activeElement !== control) control.value = wanted;
    control.placeholder = control.placeholder || emptyLabel || 'Enter model';
    return;
  }
  const values = [...models];
  if (wanted && !values.some(item => item.id.toLowerCase() === wanted.toLowerCase())) {
    values.unshift({id:wanted, type:'chat', context:0});
  }
  control.innerHTML = values.length
    ? values.map(item => `<option value="${esc(item.id)}"${item.id === wanted ? ' selected' : ''}>${esc(item.id)}${isVisionCapableModel(item.id) ? ' · image' : ''}</option>`).join('')
    : `<option value="">${esc(emptyLabel || 'No model configured')}</option>`;
  if (wanted) control.value = wanted;
}

function refreshConfigurationModelSelectors() {
  const chatText = configuredChatModels().join(', ');
  const agentText = state.config.model || '';
  for (const id of ['chatModel','homeChatModel']) {
    const input = $(id);
    if (input && document.activeElement !== input) input.value = chatText;
  }
  for (const id of ['modelName','homeModel']) {
    const input = $(id);
    if (input && document.activeElement !== input) input.value = agentText;
  }
}

function isVisionCapableModel(model) {
  const id = String(model || '').trim().toLowerCase();
  const item = state.modelCatalog.find(entry => String(entry.id).toLowerCase() === id);
  if (item?.type === 'vision') return true;
  return /mistral-small-4|gemma-4|vision|vl|multimodal/i.test(id);
}

function refreshChatModelPicker() {
  const input = $('chatModelSelect');
  if (!input) return;
  if (document.activeElement !== input) input.value = state.config.chatModel || state.config.model || '';
  input.disabled = state.streaming;
}


function setMode(mode, persist = true) {
  const next = ['chat', 'agent'].includes(String(mode)) ? String(mode) : 'chat';
  if (state.streaming) return toast('Stop the current response before changing mode');
  if (next === 'agent' && state.attachments.some(file => String(file.mimeType || '').startsWith('image/'))) return toast('Images are handled in Chat mode. Remove the image or analyse it in Chat before switching to Agent.', 6000);
  state.mode = next;
  if (persist) storageSet('local', 'llm.mode', next);
  updateModeUi();
}

function updateModeUi() {
  document.querySelectorAll('[data-mode]').forEach(button => {
    const active = button.dataset.mode === state.mode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  const hints = {
    chat: 'Conversation, documents and images. Choose the Chat model for this input; Chat does not execute workspace tools.',
    agent: state.project
      ? 'Autonomous workspace work: analyse → plan → validate → inspect/edit → run/verify → finish.'
      : 'Agent mode can use the active workspace or automatically resolve an existing project/file path written in your prompt.'
  };
  if ($('modeHint')) $('modeHint').textContent = hints[state.mode] || hints.chat;
  if ($('messageInput')) {
    const placeholders = {
      chat: 'Message ELIYA',
      agent: 'Give the agent a task and include the project/file path(s) it should work with…'
    };
    $('messageInput').placeholder = placeholders[state.mode] || placeholders.chat;
  }
  document.body.dataset.chatMode = state.mode;
  if ($('agentModelPicker')) $('agentModelPicker').classList.toggle('hidden', state.mode !== 'agent');
  if ($('chatModelPicker')) $('chatModelPicker').classList.toggle('hidden', state.mode !== 'chat');
  refreshAgentModelStrip();
  refreshChatModelPicker();
  updateModelBadge();
}

function updateWelcomeMode() {
  const setup = document.querySelector('.setup-card');
  const configured = isConfigured();
  setup.classList.toggle('hidden', configured);
  const modeLabel = state.mode === 'agent' ? 'Agent' : 'Chat';
  const active = activeModelForMode();
  $('welcomeText').textContent = configured
    ? `Connected to ${active} · ${modeLabel} mode.`
    : 'Connect your endpoint and choose a Chat model or Agent execution model.';
}

function updateContextBadge() {
  const chars = state.messages.reduce((sum, item) => sum + String(item.content || '').length, 0);
  const estimatedTokens = Math.ceil(chars / 3);
  const configured = state.config.contextWindowTokens || 0;
  const limit = configured || detectedContextWindow(activeModelForMode());
  $('contextBadge').textContent = limit > 0
    ? `~${formatCompact(estimatedTokens)} / ${formatCompact(limit)} tokens${configured ? '' : ' · auto'}`
    : `~${formatCompact(estimatedTokens)} tokens`;
}

function detectedContextWindow(model) {
  const exact = state.modelCatalog.find(item => String(item.id).toLowerCase() === String(model || '').toLowerCase());
  if (exact && Number(exact.context) > 0) return Number(exact.context);
  const m = String(model || '').toLowerCase();
  if (/mistral-small-4|qwen3\.8|qwen3\.6|qwen-latest|gemma-4-31b/.test(m)) return 262144;
  if (m.includes('gpt-oss')) return 131072;
  if (m.includes('claude')) return 200000;
  if (m.includes('mistral-small-2506') || m.includes('mistral-medium-2508')) return 128000;
  return 128000;
}


function ensureRecommendedModels() {
  const known = new Set(state.modelCatalog.map(item => String(item.id).toLowerCase()));
  for (const item of DEFAULT_MODEL_CATALOG) {
    if (!known.has(item.id.toLowerCase())) state.modelCatalog.push({...item});
  }
  saveModelCatalog();
  renderModelCatalog();
}

function renderModelCatalog() {
  const list = $('modelCatalogList');
  const options = $('modelCatalogOptions');
  const sorted = [...state.modelCatalog].sort((a,b) => a.type.localeCompare(b.type) || a.id.localeCompare(b.id));
  if (options) options.innerHTML = sorted.map(item => `<option value="${esc(item.id)}"></option>`).join('');
  refreshConfigurationModelSelectors();
  refreshChatModelPicker();
  if (!list) return;
  if (!sorted.length) {
    list.innerHTML = '<div class="model-catalog-empty">No models in the library. Add a model below.</div>';
    renderFallbackModels();
    return;
  }
  list.innerHTML = sorted.map(item => `<div class="model-catalog-row" data-model-id="${esc(item.id)}">
      <div class="model-catalog-name"><input data-model-name value="${esc(item.id)}" aria-label="Model ID" title="Edit model ID" /><span>${esc(item.type)}</span></div>
      <select data-model-type aria-label="Type for ${esc(item.id)}">
        ${['chat','vision','embedding','ocr'].map(type => `<option value="${type}"${item.type === type ? ' selected' : ''}>${type === 'chat' ? 'Chat / Agent' : type === 'vision' ? 'Vision (Chat image)' : type[0].toUpperCase()+type.slice(1)}</option>`).join('')}
      </select>
      <input data-model-context type="number" min="0" value="${esc(String(item.context || 0))}" title="Context window tokens; 0 = auto" aria-label="Context window for ${esc(item.id)}" />
      <button type="button" class="secondary-btn compact-btn model-test-btn" data-test-model="${esc(item.id)}" title="Run a lightweight connection probe">Test</button>
      <button type="button" class="plan-icon-btn danger" data-remove-model="${esc(item.id)}" title="Remove model" aria-label="Remove ${esc(item.id)}">×</button>
    </div>`).join('');
  renderFallbackModels();
}

function addModelFromUi() {
  const id = String($('newModelId')?.value || '').trim();
  if (!id) return toast('Enter a model ID');
  if (state.modelCatalog.some(item => item.id.toLowerCase() === id.toLowerCase())) return toast('That model is already in the library');
  const type = String($('newModelType')?.value || 'chat');
  const context = Math.max(0, Number($('newModelContext')?.value || 0));
  state.modelCatalog.push({id, type, context});
  saveModelCatalog(); renderModelCatalog();
  $('newModelId').value = ''; $('newModelContext').value = '';
  toast(`Added ${id}`);
}

async function testModelFromLibrary(id, button) {
  const item = state.modelCatalog.find(entry => entry.id === id);
  if (!item) return;
  const apiKey = String($('apiKey')?.value || state.config.apiKey || '').trim();
  const baseUrl = String($('baseUrl')?.value || state.config.baseUrl || '').trim();
  if (!apiKey || !baseUrl) return toast('Enter API key and Base URL before testing a model.', 4500);
  const original = button?.textContent || 'Test';
  if (button) { button.disabled = true; button.textContent = 'Testing…'; }
  try {
    const response = await fetch('/api/chat/model-probe', {
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`},
      body:JSON.stringify({baseUrl, model:item.id, type:item.type || 'chat'})
    });
    if (!response.ok) throw new Error(await readHttpError(response));
    const result = await response.json();
    toast(`${item.id} ready · ${result.capability || 'connection'} · ${result.elapsedMs || '?'} ms`, 5000);
  } catch (error) {
    toast(`${item.id} test failed: ${error.message}`, 6000);
  } finally {
    if (button) { button.disabled = false; button.textContent = original; }
  }
}

function removeModelFromLibrary(id) {
  const model = String(id || '').trim();
  if (!model) return;
  const executionValues = uniqueModelList($('modelName')?.value || configuredAgentModels().join(','));
  const executionValue = executionValues[0] || state.config.model || '';
  if (executionValue.toLowerCase() === model.toLowerCase()) {
    return toast('Choose another execution model before removing this model.');
  }
  const roleFields = ['chatModel'];
  const assignedRoles = roleFields.filter(field => uniqueModelList($(field)?.value || configuredChatModels().join(',')).some(value => value.toLowerCase() === model.toLowerCase()));
  const fallbackValues = parseModelList($('agentFallbackModels')?.value || state.config.agentFallbackModels || '');
  const inFallback = fallbackValues.some(value => value.toLowerCase() === model.toLowerCase());
  const assignmentText = [...assignedRoles.map(field => field.replace(/Model$/, '')), ...(inFallback ? ['fallback'] : [])];
  if (assignmentText.length && !confirm(`${model} is assigned to ${assignmentText.join(', ')}. Remove it and clear those assignments?`)) return;

  for (const field of assignedRoles) if ($(field)) $(field).value = '';
  const nextFallbacks = fallbackValues.filter(value => value.toLowerCase() !== model.toLowerCase());
  if ($('agentFallbackModels')) $('agentFallbackModels').value = nextFallbacks.join('\n');
  state.modelCatalog = state.modelCatalog.filter(item => item.id.toLowerCase() !== model.toLowerCase());
  saveModelCatalog(); renderModelCatalog();
  toast(`Removed ${model}. Save settings to apply routing changes.`);
}

function updateModelLibraryEntry(id, patch) {
  const item = state.modelCatalog.find(entry => entry.id === id);
  if (!item) return;
  Object.assign(item, patch);
  saveModelCatalog(); renderModelCatalog();
}

function renameModelInLibrary(id, nextId) {
  const oldId = String(id || '').trim();
  const renamed = String(nextId || '').trim();
  if (!oldId || !renamed) { renderModelCatalog(); return toast('Model ID cannot be empty'); }
  if (oldId === renamed) return;
  if (state.modelCatalog.some(item => item.id.toLowerCase() === renamed.toLowerCase() && item.id !== oldId)) {
    renderModelCatalog();
    return toast('That model ID already exists');
  }
  const item = state.modelCatalog.find(entry => entry.id === oldId);
  if (!item) return;
  item.id = renamed;

  const fields = ['chatModel','modelName','homeChatModel','homeModel'];
  for (const field of fields) {
    const input = $(field);
    if (!input) continue;
    const values = uniqueModelList(input.value).map(value => value.toLowerCase() === oldId.toLowerCase() ? renamed : value);
    if (values.length) input.value = values.join(', ');
  }
  const fallbacks = parseModelList($('agentFallbackModels')?.value || state.config.agentFallbackModels || '')
    .map(value => value.toLowerCase() === oldId.toLowerCase() ? renamed : value);
  if ($('agentFallbackModels')) $('agentFallbackModels').value = [...new Set(fallbacks)].join('\n');
  saveModelCatalog(); renderModelCatalog();
  toast(`Renamed ${oldId} to ${renamed}. Save settings to apply routing changes.`);
}

function ensureConfiguredModelsInCatalog() {
  const candidates = [
    ...configuredChatModels().map(id => [id, isVisionCapableModel(id) ? 'vision' : 'chat']),
    ...configuredAgentModels().map(id => [id, 'chat'])
  ];
  let changed = false;
  for (const [rawId, type] of candidates) {
    const id = String(rawId || '').trim();
    if (!id || state.modelCatalog.some(item => item.id.toLowerCase() === id.toLowerCase())) continue;
    state.modelCatalog.push({id, type, context:0});
    changed = true;
  }
  if (changed) { saveModelCatalog(); renderModelCatalog(); }
}


function formatCompact(n) {
  const value = Number(n || 0);
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}m`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1)}k`;
  return String(value);
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}

async function loadConversations() {
  state.conversations = await api('/api/conversations');
  renderHistory($('historySearch').value || '');
}

function renderHistory(filter = '') {
  const q = filter.trim().toLowerCase();
  const list = state.conversations.filter(c => !q || String(c.title || '').toLowerCase().includes(q));
  if (!list.length) {
    $('historyList').innerHTML = `<div class="history-empty">${q ? 'No matching chats' : 'Your chats will appear here'}</div>`;
    return;
  }
  $('historyList').innerHTML = list.map(c => `
    <div class="history-item ${c.id === state.conversationId ? 'active' : ''}" data-id="${esc(c.id)}" title="${esc(c.title)}">
      <span class="history-title">${esc(c.title || 'New chat')}</span>
      <button class="history-menu" type="button" data-menu="${esc(c.id)}" aria-label="Chat options">⋯</button>
    </div>`).join('');
}

function newChat() {
  const persistentLocalWorkspace = state.project?.localWorkspace ? state.project : null;
  if (state.streaming) {
    const runId = state.activeAgentRunId;
    if (runId) fetch(`/api/agent/runs/${encodeURIComponent(runId)}/cancel`, { method: 'POST' }).catch(() => {});
    else if (state.conversationId) fetch(`/api/chat/cancel?conversationId=${encodeURIComponent(state.conversationId)}`, { method: 'POST' }).catch(() => {});
    state.abortController?.abort();
  }
  state.activeAgentRunId = null;
  state.conversationId = null;
  state.messages = [];
  state.attachments = [];
  state.filesById = new Map();
  state.project = persistentLocalWorkspace;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  state.pendingProjectChanges = null;
  state.editingIndex = null;
  state.userScrolledUp = false;
  $('conversationTitle').textContent = 'New chat';
  $('historySearch').value = '';
  closeHistoryMenu();
  renderHistory();
  renderAttachmentTray();
  renderProjectBar();
  renderMessages();
  updateModeUi();
  updateWelcomeMode();
  $('messageInput').value = '';
  autoGrow();
  $('messageInput').focus();
}

async function ensureConversation() {
  if (state.conversationId) return state.conversationId;
  const created = await api('/api/conversations', { method: 'POST' });
  state.conversationId = created.id;
  $('conversationTitle').textContent = created.title || 'New chat';
  await loadConversations();
  return created.id;
}

async function openConversation(id) {
  if (state.streaming) return toast('Stop the current response before switching chats');
  const loadSeq = ++state.historyLoadSeq;
  const previousConversationId = state.conversationId;
  const previousTitle = $('conversationTitle').textContent;
  closeHistoryMenu();
  state.conversationId = id;
  state.editingIndex = null;
  $('conversationTitle').textContent = 'Loading chat…';
  $('messages').innerHTML = '<div class="history-loading"><span class="history-loading-dot"></span>Loading conversation…</div>';

  // Messages are authoritative. Optional attachments/projects/run history must never prevent an old chat from opening.
  let messages = [];
  try { messages = await api(`/api/conversations/${encodeURIComponent(id)}/messages`); }
  catch (error) {
    if (loadSeq === state.historyLoadSeq) {
      state.conversationId = previousConversationId;
      $('conversationTitle').textContent = previousTitle || 'Chat';
      renderMessages();
      renderHistory($('historySearch').value || '');
    }
    throw error;
  }
  const [filesResult, projectsResult, runsResult] = await Promise.allSettled([
    api(`/api/files?conversationId=${encodeURIComponent(id)}`),
    api(`/api/projects?conversationId=${encodeURIComponent(id)}`),
    api(`/api/agent/conversations/${encodeURIComponent(id)}/runs`)
  ]);
  if (loadSeq !== state.historyLoadSeq) return;
  const files = filesResult.status === 'fulfilled' ? filesResult.value : [];
  const projects = projectsResult.status === 'fulfilled' ? projectsResult.value : [];
  const conversationRuns = runsResult.status === 'fulfilled' ? runsResult.value : [];

  state.messages = Array.isArray(messages) ? messages : [];
  const usedAssistantIds = new Set();
  const assistantKey = message => message?.id != null ? `id:${message.id}` : `idx:${state.messages.indexOf(message)}`;
  const snapshots = Array.isArray(conversationRuns) ? conversationRuns : [];
  for (const runSnapshot of snapshots) {
    if (!runSnapshot?.id) continue;
    let assistant = null;
    if (runSnapshot.assistantMessageId) {
      assistant = state.messages.find(message => String(message.id) === String(runSnapshot.assistantMessageId) && message.role === 'assistant');
    }
    // Backward-compatible recovery for older durable runs written before assistantMessageId was persisted.
    if (!assistant) {
      const created = Date.parse(runSnapshot.createdAt || '');
      assistant = state.messages.find(message => {
        if (message.role !== 'assistant' || usedAssistantIds.has(assistantKey(message))) return false;
        const messageAt = Date.parse(message.createdAt || '');
        return Number.isFinite(created) && Number.isFinite(messageAt) && messageAt >= created;
      });
      // Very old conversations may not have message timestamps. Preserve order rather than dropping run history.
      if (!assistant) assistant = state.messages.find(message => message.role === 'assistant' && !usedAssistantIds.has(assistantKey(message)));
    }
    if (!assistant) {
      const status = String(runSnapshot.status || 'interrupted');
      const syntheticContent = String(runSnapshot.finalAnswer || '').trim()
        || (status === 'failed'
          ? 'Agent run failed before a final response was saved. The persisted execution history is shown below.'
          : status === 'cancelled'
            ? 'Agent run was cancelled before a final response was saved. The persisted execution history is shown below.'
            : 'Agent run ended before a final response was saved. The persisted execution history is shown below.');
      assistant = {
        id: `agent-run-${runSnapshot.id}`,
        role: 'assistant',
        content: syntheticContent,
        createdAt: runSnapshot.createdAt || runSnapshot.finishedAt || new Date().toISOString(),
        attachmentIds: [],
        syntheticAgentRun: true,
        mode: 'agent'
      };
      const created = Date.parse(assistant.createdAt || '');
      let insertAt = state.messages.length;
      if (Number.isFinite(created)) {
        const later = state.messages.findIndex(message => {
          const at = Date.parse(message?.createdAt || '');
          return Number.isFinite(at) && at > created;
        });
        if (later >= 0) insertAt = later;
      }
      state.messages.splice(insertAt, 0, assistant);
    }
    usedAssistantIds.add(assistantKey(assistant));
    assistant.agentRunId = runSnapshot.id;
    assistant.agentProgress = agentProgressFromSnapshot(runSnapshot, assistant.agentProgress);
    assistant.agentBackendStatus = runSnapshot.status || assistant.agentProgress.status || 'unknown';
    assistant.agentBackendReachable = true;
    assistant.agentBackendPolledAt = new Date().toISOString();
    assistant.agentConnectionStatus = runSnapshot.finishedAt ? 'closed' : 'recovering';
    assistant.agentSteps = Array.isArray(runSnapshot.activityEvents) ? runSnapshot.activityEvents.map(event => ({...event})) : (assistant.agentSteps || []);
    assistant.agentEventTotal = assistant.agentSteps.length;
    assistant.mode = 'agent';
  }
  state.filesById = new Map((Array.isArray(files) ? files : []).map(file => [file.id, file]));
  state.attachments = [];
  const conversationProject = Array.isArray(projects) && projects.length ? projects[0] : null;
  // The explicitly selected local workspace is application-level state. Opening an older chat must not
  // silently replace it with that conversation's historical workspace. Only an explicit project path in a
  // new Agent prompt changes the active workspace.
  if (!state.project?.localWorkspace) {
    const rememberedWorkspacePath = storageGet('local', 'llm.activeLocalWorkspacePath');
    await restoreActiveLocalWorkspace();
    if (loadSeq !== state.historyLoadSeq) return;
    // If a persistent path is remembered but its backend record is temporarily unavailable, keep that
    // path authoritative and remap it on the next Agent send instead of adopting an old chat's workspace.
    if (!state.project?.localWorkspace && !rememberedWorkspacePath && conversationProject) {
      state.project = conversationProject;
      if (conversationProject.localWorkspace) rememberActiveLocalWorkspace(conversationProject);
    }
  }
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  const conversation = state.conversations.find(c => String(c.id) === String(id));
  $('conversationTitle').textContent = conversation?.title || 'Chat';
  renderMessages();
  renderAttachmentTray();
  renderProjectBar();
  updateModeUi();
  renderHistory($('historySearch').value || '');
  $('sidebar').classList.remove('open');
  state.userScrolledUp = false;
  scrollBottom(true);
  if (filesResult.status === 'rejected' || projectsResult.status === 'rejected' || runsResult.status === 'rejected') {
    toast('Chat loaded. Some older workspace/run metadata could not be restored.', 4500);
  }
}

function attachmentHtml(ids) {
  if (!Array.isArray(ids) || !ids.length) return '';
  const cards = ids.map(id => {
    const file = state.filesById.get(id);
    if (!file) return `<span class="message-file"><span class="file-icon">📎</span><span class="file-text"><span class="file-name">Attachment</span></span></span>`;
    const image = String(file.mimeType || '').toLowerCase().startsWith('image/');
    const visual = image
      ? `<img class="attachment-thumb" src="/api/files/${encodeURIComponent(id)}/view" alt="${esc(file.name)}" />`
      : `<span class="file-icon">${fileIcon(file.mimeType, file.name)}</span>`;
    return `<a class="message-file" href="/api/files/${encodeURIComponent(id)}/download" title="Download ${esc(file.name)}">
      ${visual}
      <span class="file-text"><span class="file-name">${esc(file.name)}</span><span class="file-meta">${esc(formatBytes(file.size))}${Number(file.extractedCharacters || 0) > 0 ? ` · ${esc(formatCompact(file.extractedCharacters))} text chars` : ''}</span></span>
    </a>`;
  }).join('');
  return `<div class="attachment-list">${cards}</div>`;
}

function fileIcon(mime, name) {
  const m = String(mime || '').toLowerCase();
  const n = String(name || '').toLowerCase();
  if (m.startsWith('image/')) return '🖼';
  if (m.includes('pdf') || n.endsWith('.pdf')) return 'PDF';
  if (m.includes('spreadsheet') || m.includes('excel') || /\.(xlsx?|csv)$/.test(n)) return 'XLS';
  if (m.includes('word') || /\.docx?$/.test(n)) return 'DOC';
  if (m.includes('presentation') || /\.pptx?$/.test(n)) return 'PPT';
  if (/\.(java|js|ts|py|json|xml|html|css|sql|yml|yaml|sh)$/.test(n)) return '&lt;/&gt;';
  return '📎';
}

function parsePlanTextForUi(text) {
  const lines = String(text || '').split(/\r?\n/);
  const items = [];
  let current = null;
  for (const raw of lines) {
    const line = String(raw || '').trim();
    if (!line) continue;
    const numbered = line.match(/^(\d+)[.)]\s*(?:\[[^\]]+\]\s*)?(.*)$/);
    if (numbered) {
      if (current?.text) items.push(current);
      current = { index: Number(numbered[1]) || items.length + 1, text: numbered[2].replace(/\s+—\s+.*$/, '').trim(), status: 'pending', note: '' };
      continue;
    }
    // Structured planner fields belong to the previous numbered plan step; do not render them as separate steps.
    if (current && /^(Objective|Files|Validate|Depends on|Risk):\s*/i.test(line)) {
      current.text += `\n${line}`;
      continue;
    }
    // Backward-compatible unnumbered plan text: each meaningful line is a step.
    if (current?.text) { items.push(current); current = null; }
    const cleaned = line.replace(/^\[[^\]]+\]\s*/, '').replace(/\s+—\s+.*$/, '').trim();
    if (cleaned) items.push({ index: items.length + 1, text: cleaned, status: 'pending', note: '' });
  }
  if (current?.text) items.push(current);
  return items.map((item, index) => ({...item, index: index + 1}));
}

function structuredPlanStepHtml(text) {
  const lines = String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  if (!lines.length) return '';
  const title = lines[0];
  const fields = [];
  let objective = '';
  for (const line of lines.slice(1)) {
    const match = line.match(/^(Objective|Files|Validate|Depends on|Risk):\s*(.*)$/i);
    if (!match) { fields.push(['Detail', line]); continue; }
    const label = match[1].toLowerCase();
    const value = match[2];
    if (label === 'objective') objective = value;
    else fields.push([match[1], value]);
  }
  return `<div class="plan-step-structure"><strong class="plan-step-title">${esc(title)}</strong>${objective ? `<span class="plan-step-objective">${esc(objective)}</span>` : ''}${fields.length ? `<div class="plan-step-fields">${fields.map(([label,value]) => `<span class="plan-step-field"><b>${esc(label)}</b><em>${esc(value)}</em></span>`).join('')}</div>` : ''}</div>`;
}

function planEditorHtml(runId, planItems, validationStatus = 'not_run', validationSummary = '') {
  if (!runId || !Array.isArray(planItems) || !planItems.length) return '';
  const rows = planItems.map((item, idx) => {
    const rowCount = Math.max(2, Math.min(7, String(item.text || '').split(/\r?\n/).length));
    return `<div class="plan-edit-row" data-plan-row>
      <label class="plan-select" title="Include this step"><input type="checkbox" data-plan-enabled checked /></label>
      <span class="plan-edit-index">${idx + 1}</span>
      <textarea class="plan-edit-text" rows="${rowCount}" data-plan-text aria-label="Plan step ${idx + 1}">${esc(item.text || '')}</textarea>
      <div class="plan-row-actions"><button type="button" class="plan-icon-btn" data-plan-move="up" title="Move up">↑</button><button type="button" class="plan-icon-btn" data-plan-move="down" title="Move down">↓</button><button type="button" class="plan-icon-btn danger" data-plan-remove title="Remove step">×</button></div>
    </div>`;
  }).join('');
  const approved = String(validationStatus) === 'approved';
  const badge = approved ? 'VALIDATED' : String(validationStatus) === 'needs_review' ? 'REVIEW' : 'DRAFT';
  const validatorNote = validationSummary ? `<div class="plan-quality-inline ${approved ? 'approved' : 'review'}"><span>${approved ? '✓' : '!'}</span><span>${esc(validationSummary)}</span></div>` : '';
  return `<div class="agent-plan-editor" data-plan-editor data-run-id="${esc(runId)}">
      <div class="plan-editor-head"><div><strong>Review execution plan</strong><span>${approved ? 'Independently validated. You can still edit, reorder, add or remove steps.' : 'Edit, reorder, add, remove, or unselect steps before approval.'}</span></div><span class="plan-draft-badge ${approved ? 'validated' : ''}">${badge}</span></div>${validatorNote}
      <div class="plan-edit-list" data-plan-list>${rows}</div>
      <div class="plan-editor-actions"><button type="button" class="secondary-btn" data-plan-add>＋ Add step</button><button type="button" class="secondary-btn" data-plan-save>Save plan</button></div>
    </div>`;
}


function agentStageHtml(progress, waiting) {
  const phase = String(progress?.phase || 'starting').toLowerCase();
  const status = String(progress?.status || 'running').toLowerCase();
  const stages = [
    ['index','Index'], ['analyse','Analyse'], ['plan','Plan'], ['validate','Validate'],
    ['review','Review'], ['execute','Execute'], ['verify','Verify'], ['complete','Complete']
  ];
  let active = 0;
  if (phase.includes('index')) active = 0;
  else if (phase.includes('analys')) active = 1;
  else if (phase.includes('plan_validation')) active = 3;
  else if (phase.includes('plan_review') || waiting) active = 4;
  else if (phase.includes('plan')) active = 2;
  else if (phase.includes('verify')) active = 6;
  else if (phase.includes('final') || phase.includes('tasks_complete')) active = 7;
  else if (phase.includes('execut') || phase.includes('working') || phase.includes('recover')) active = 5;
  if (['completed','blocked','failed','cancelled','interrupted'].includes(status)) active = 7;
  return `<div class="agent-stage-strip">${stages.map((stage, index) => {
    const cls = index < active ? 'done' : index === active ? 'active' : 'pending';
    return `<span class="agent-stage ${cls}"><i>${index < active ? '✓' : index + 1}</i><b>${stage[1]}</b></span>`;
  }).join('')}</div>`;
}

function activityAgeText(iso, running) {
  if (!iso) return running ? 'Live' : '';
  const seconds = Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 1000));
  if (!Number.isFinite(seconds)) return running ? 'Live' : '';
  if (running && seconds < 3) return 'Live now';
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  return minutes < 60 ? `${minutes}m ago` : `${Math.floor(minutes / 60)}h ago`;
}

function durableAgentArgsText(step) {
  if (!step || step.args == null || step.args === '') return '';
  if (typeof step.args !== 'string') {
    try { return JSON.stringify(step.args, null, 2); } catch (_) { return String(step.args); }
  }
  try { return JSON.stringify(JSON.parse(step.args), null, 2); }
  catch (_) { return step.args; }
}

function agentActivityRowHtml(step) {
  const status = ['success', 'error', 'running', 'approval', 'done', 'blocked'].includes(step.status) ? step.status : 'running';
  const icon = status === 'success' || status === 'done' ? '✓' : status === 'error' || status === 'blocked' ? '!' : status === 'approval' ? '?' : '↻';
  const args = durableAgentArgsText(step);
  const details = (args || step.output) ? `<details class="agent-step-details"><summary>Details</summary>${args ? `<div class="agent-detail-label">Input</div><pre>${esc(args)}</pre>` : ''}${step.output ? `<div class="agent-detail-label">Output</div><pre>${esc(step.output)}</pre>` : ''}</details>` : '';
  const approval = status === 'approval' && step.approvalId
    ? `<div class="agent-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="deny">Deny</button><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="once">Approve once</button><button type="button" class="primary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="run">Allow this run</button></div>` : '';
  const at = step.at ? `<span class="agent-step-time">${esc(new Date(step.at).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'}))}</span>` : '';
  return `<div class="agent-step ${status}"><div class="agent-step-line"><span class="agent-step-icon">${icon}</span><span class="agent-step-tool">${esc(step.tool || 'agent')}</span><span class="agent-step-detail">${esc(step.detail || '')}</span>${at}</div>${approval}${details}</div>`;
}

function agentRuntimeStatusHtml(message, progress, runId, detail, runningNow) {
  const backendRaw = String(message.agentBackendStatus || progress?.status || (runningNow ? 'running' : 'unknown')).trim().toLowerCase();
  const backendStatus = backendRaw || 'unknown';
  const backendReachable = message.agentBackendReachable;
  const streamState = String(message.agentConnectionStatus || (runningNow ? 'connecting' : 'closed')).trim().toLowerCase();
  const lastActivity = activityAgeText(progress?.lastActivityAt, runningNow) || 'Unknown';
  const runText = runId ? String(runId) : 'Pending';
  const shortRun = runText.length > 18 ? `${runText.slice(0, 8)}…${runText.slice(-6)}` : runText;
  const backendLabel = backendStatus.replaceAll('_', ' ');
  let connectionLabel;
  if (streamState === 'connected') connectionLabel = backendReachable === false ? 'Stream connected · backend status unavailable' : 'Stream connected · backend reachable';
  else if (streamState === 'disconnected') connectionLabel = backendReachable === false ? 'Stream disconnected · retrying backend status' : 'Stream disconnected · polling backend';
  else if (streamState === 'recovering') connectionLabel = backendReachable === false ? 'Recovering · backend unreachable' : 'Recovering · backend reachable';
  else if (streamState === 'connecting') connectionLabel = backendReachable === false ? 'Connecting · backend status unavailable' : 'Connecting';
  else connectionLabel = backendReachable === false ? 'Closed · backend status unavailable' : 'Closed';
  const reachabilityClass = backendReachable === false ? 'unreachable' : backendReachable === true ? 'reachable' : 'checking';
  const transportNote = message.agentTransportError && streamState === 'disconnected'
    ? `<div class="agent-runtime-warning">Frontend stream interrupted: ${esc(message.agentTransportError)}. Backend polling remains active.</div>`
    : '';
  return `<div class="agent-runtime-status ${esc(reachabilityClass)}" data-agent-runtime-status>
    <div class="agent-runtime-status-item"><span>Backend</span><strong data-agent-backend-status>${esc(backendLabel.toUpperCase())}</strong></div>
    <div class="agent-runtime-status-item wide"><span>Connection</span><strong data-agent-connection-status>${esc(connectionLabel)}</strong></div>
    <div class="agent-runtime-status-item wide"><span>Current step</span><strong data-agent-current-step title="${esc(detail || '')}">${esc(detail || 'Preparing agent run')}</strong></div>
    <div class="agent-runtime-status-item"><span>Last backend activity</span><strong data-agent-last-activity>${esc(lastActivity)}</strong></div>
    <div class="agent-runtime-status-item"><span>Run ID</span><strong data-agent-run-id title="${esc(runText)}">${esc(shortRun)}</strong></div>
  </div>${transportNote}`;
}

function agentStepsHtml(message) {
  const steps = Array.isArray(message.agentSteps) ? message.agentSteps : [];
  const progress = message.agentProgress || null;
  if (!steps.length && !progress) return '';

  const progressPlan = Array.isArray(progress?.plan) ? progress.plan : [];
  const latestPlanApproval = [...steps].reverse().find(step => step.tool === 'plan_approval');
  const planApprovalStep = latestPlanApproval?.status === 'approval' ? latestPlanApproval : null;
  const draftPlan = progressPlan.length ? progressPlan : parsePlanTextForUi(planApprovalStep?.output || '');
  const runId = message.agentRunId || planApprovalStep?.runId || '';

  // Keep the recent activity visible, but preserve the full durable history behind an expandable section.
  const activity = steps.filter(step => step.tool !== 'plan' && step.tool !== 'plan_approval');
  const maxVisibleEvents = 55;
  const hiddenEventCount = Math.max(0, activity.length - maxVisibleEvents);
  const olderSteps = hiddenEventCount ? activity.slice(0, -maxVisibleEvents) : [];
  const visibleSteps = hiddenEventCount ? activity.slice(-maxVisibleEvents) : activity;
  const olderActivityRows = hiddenEventCount
    ? `<details class="agent-event-history"><summary>Show ${esc(String(hiddenEventCount))} earlier activity events</summary><div class="agent-event-history-body">${olderSteps.map(agentActivityRowHtml).join('')}</div></details>`
    : '';
  const activityRows = `${olderActivityRows}${visibleSteps.map(agentActivityRowHtml).join('')}`;

  const planApprovalHtml = planApprovalStep ? `${planEditorHtml(runId, draftPlan, progress?.planValidationStatus, progress?.planValidationSummary)}<div class="agent-approval-actions plan-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(planApprovalStep.approvalId)}" data-approval-action="deny">Cancel</button><button type="button" class="primary-btn" data-agent-approval="${esc(planApprovalStep.approvalId)}" data-approval-action="once" data-plan-approve>Approve plan & run step 1</button></div>` : '';
  const waitingGenericApproval = visibleSteps.some((step, index) => step.status === 'approval' && !visibleSteps.slice(index + 1).some(next => next.tool === step.tool && next.step === step.step && next.status !== 'approval'));
  const waiting = Boolean(planApprovalStep) || waitingGenericApproval;
  const changed = Number(message.agentDirectChangeCount || 0);
  const completedPlans = progressPlan.filter(item => item.status === 'completed').length;
  const totalPlans = progressPlan.length;
  const eventTotal = Number(message.agentEventTotal || steps.length);
  const workSummary = progress?.workItemSummary || {};
  const workTotal = Number(workSummary.total || 0);
  const workCompleted = Number(workSummary.completed || 0);
  const workFailed = Number(workSummary.failed || 0);
  const summary = workTotal
    ? `${workCompleted}/${workTotal} work items completed${workFailed ? ` · ${workFailed} failed` : ''}`
    : (totalPlans ? `${completedPlans}/${totalPlans} planned steps completed` : (changed > 0 ? `${changed} file${changed === 1 ? '' : 's'} changed directly` : `${eventTotal} activity event${eventTotal === 1 ? '' : 's'}`));
  const pct = Math.max(0, Math.min(100, Number(progress?.percent ?? (message.streaming ? 2 : 100))));
  const phase = progress?.phase || (message.streaming ? 'starting' : 'completed');
  const detail = progress?.detail || (message.streaming ? 'Preparing agent run' : 'Task completed');
  const usage = progress?.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const compactionsNow = Number(usage.compactions || 0);
  const prunedNow = Number(usage.prunedObservations || 0);
  const savedNow = Number(usage.estimatedTokensSavedByPruning || 0) + Number(usage.estimatedTokensSavedByCompaction || 0);
  const cacheHitNow = Number(usage.cacheHitPercent || 0);
  const tokenLine = (providerTotal || contextNow || compactionsNow || prunedNow)
    ? `<div class="agent-token-line">${contextNow ? `Context ~${esc(formatCompact(contextNow))}${contextWindow ? ` / ${esc(formatCompact(contextWindow))}` : ''}` : ''}${providerTotal ? `${contextNow ? ' · ' : ''}Run tokens ${esc(formatCompact(providerTotal))}` : ''}${compactionsNow ? ` · ${esc(String(compactionsNow))} compaction${compactionsNow === 1 ? '' : 's'}` : ''}${prunedNow ? ` · ${esc(String(prunedNow))} pruned` : ''}${savedNow ? ` · ~${esc(formatCompact(savedNow))} active tokens saved` : ''}${cacheHitNow > 0 ? ` · cache ${esc(cacheHitNow.toFixed(0))}%` : ''}</div>`
    : '';

  const activeModel = progress?.activeModel || '';
  const modelPool = Array.isArray(progress?.modelPool) ? progress.modelPool : [];
  const failovers = Number(progress?.modelFailovers || 0);
  const recoveryReplans = Number(progress?.recoveryReplans || 0);
  const activePlanIndex = Number(progress?.activePlanIndex || 0);
  const runtimeMeta = activeModel || modelPool.length || activePlanIndex || recoveryReplans || workTotal
    ? `<div class="agent-runtime-meta">${activeModel ? `<span class="agent-runtime-pill">Model <strong>${esc(activeModel)}</strong></span>` : ''}${modelPool.length > 1 ? `<span class="agent-runtime-pill">Pool ${esc(String(modelPool.length))}</span>` : ''}${failovers ? `<span class="agent-runtime-pill">Failovers ${esc(String(failovers))}</span>` : ''}${recoveryReplans ? `<span class="agent-runtime-pill recovery">Recoveries ${esc(String(recoveryReplans))}</span>` : ''}${activePlanIndex ? `<span class="agent-runtime-pill">Active step ${esc(String(activePlanIndex))}</span>` : ''}${workTotal ? `<span class="agent-runtime-pill">Work ${esc(String(workCompleted))}/${esc(String(workTotal))}</span>` : ''}${workFailed ? `<span class="agent-runtime-pill recovery">Failed ${esc(String(workFailed))}</span>` : ''}</div>`
    : '';

  const planBoard = progressPlan.length && !planApprovalStep ? `<div class="agent-plan-board">${progressPlan.map(item => {
    const status = ['pending','in_progress','completed','blocked'].includes(item.status) ? item.status : 'pending';
    const evidence = Array.isArray(item.evidence) ? item.evidence.filter(Boolean) : [];
    const evidenceHtml = evidence.length ? `<details class="agent-plan-evidence" ${status === 'in_progress' ? 'open' : ''}><summary>${status === 'completed' ? 'Completed details' : 'Live step details'} · ${evidence.length}</summary><ul>${evidence.map(line => `<li>${esc(line)}</li>`).join('')}</ul></details>` : '';
    return `<div class="agent-plan-item ${esc(status)}"><span class="agent-plan-index">${esc(String(item.index || ''))}</span><span class="agent-plan-text">${structuredPlanStepHtml(item.text || '')}${item.note ? `<small class="agent-plan-note">${esc(item.note)}</small>` : ''}${evidenceHtml}</span><span class="agent-plan-state">${esc(status.replaceAll('_',' '))}</span></div>`;
  }).join('')}</div>` : '';

  const activeProgress = message.streaming && pct < 100 ? ' active' : '';
  const runningNow = Boolean(message.streaming || String(progress?.status || '') === 'running');
  const liveAge = activityAgeText(progress?.lastActivityAt, runningNow);
  const liveStatus = `<div class="agent-live-status ${runningNow ? 'running' : 'finished'}"><span class="agent-live-dot"></span><strong>${runningNow ? 'Live status' : 'Last status'}</strong><span class="agent-live-age">${esc(liveAge)}</span><span class="agent-live-detail">${esc(detail)}</span></div>`;
  const runtimeStatus = agentRuntimeStatusHtml(message, progress, runId, detail, runningNow);
  const validationStatus = String(progress?.planValidationStatus || 'not_run');
  const validationSummary = String(progress?.planValidationSummary || '');
  const planQuality = validationStatus !== 'not_run' ? `<div class="agent-plan-quality ${validationStatus === 'approved' ? 'approved' : 'review'}"><span>${validationStatus === 'approved' ? '✓' : '!'}</span><div><strong>${validationStatus === 'approved' ? 'Plan validated' : 'Plan needs review'}</strong>${validationSummary ? `<small>${esc(validationSummary)}</small>` : ''}</div></div>` : '';
  const progressHtml = `<div class="agent-progress">${agentStageHtml(progress, waiting)}<div class="agent-progress-top"><strong>${esc(String(phase).replaceAll('_',' '))}</strong><span class="agent-progress-percent">${esc(String(Math.round(pct)))}%</span></div><div class="agent-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${esc(String(Math.round(pct)))}"><div class="agent-progress-fill${activeProgress}" style="width:${esc(String(pct))}%"></div></div>${liveStatus}${runtimeStatus}${planQuality}${tokenLine}${runtimeMeta}${planBoard}${planApprovalHtml}</div>`;
  const activityPanel = activityRows ? `<details class="agent-activity-panel" ${message.streaming ? 'open' : ''}><summary><span>Live activity</span><span>${eventTotal} events</span></summary><div class="agent-activity-list">${activityRows}</div></details>` : '';
  return `<div class="agent-run-card ${waiting ? 'waiting-approval' : ''}"><div class="agent-run-head"><span>Agent run</span><span>${summary}</span></div>${progressHtml}${activityPanel}</div>`;
}

function messageHtml(message, index) {
  const assistant = message.role === 'assistant';
  const isLastAssistant = assistant && index === state.messages.length - 1;

  if (!assistant && state.editingIndex === index) {
    return `<article class="message user" data-message-index="${index}">
      <div class="avatar">You</div>
      <div class="message-body">
        ${attachmentHtml(message.attachmentIds)}
        <div class="edit-panel">
          <textarea id="editMessageInput" class="edit-textarea" rows="4">${esc(message.content || '')}</textarea>
          <div class="edit-actions"><button class="secondary-btn" type="button" data-edit-cancel="${index}">Cancel</button><button class="primary-btn" type="button" data-edit-save="${index}">Save & submit</button></div>
        </div>
      </div>
    </article>`;
  }

  const displayContent = assistant ? stripProjectMarkers(message.content || '') : (message.content || '');
  const rendered = MarkdownRenderer.render(displayContent, { streaming: Boolean(message.streaming) });
  const contentClass = assistant && message.streaming ? 'message-content typing-cursor' : 'message-content';
  const excelAction = assistant && !message.streaming && (hasMarkdownTable(message.content || '') || isExcelRequestedForAssistant(index))
    ? `<button class="mini-btn artifact-btn" type="button" data-excel-msg="${index}">▦ Excel</button>` : '';
  const projectChanges = assistant && !message.streaming ? extractProjectFileChanges(message.content || '') : [];
  const projectAction = projectChanges.length
    ? `<button class="mini-btn artifact-btn" type="button" data-project-changes="${index}">⌘ Review ${projectChanges.length} file${projectChanges.length === 1 ? '' : 's'}</button>` : '';
  const actions = assistant
    ? `<button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button><button class="mini-btn" type="button" data-download-msg="${index}">Markdown</button><button class="mini-btn" type="button" data-pdf-msg="${index}">PDF</button>${excelAction}${projectAction}${isLastAssistant && !message.streaming ? `<button class="mini-btn" type="button" data-regenerate="${index}">Regenerate</button>` : ''}`
    : `<button class="mini-btn" type="button" data-edit-msg="${index}">Edit</button><button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button>`;

  return `<article class="message ${assistant ? 'assistant' : 'user'}" data-message-index="${index}">
    <div class="avatar">${assistant ? 'AI' : 'You'}</div>
    <div class="message-body">
      ${attachmentHtml(message.attachmentIds)}
      ${assistant ? agentStepsHtml(message) : ''}
      <div class="${contentClass}">${rendered}</div>
      <div class="message-actions">${actions}</div>
    </div>
  </article>`;
}

function renderMessages() {
  $('messages').innerHTML = state.messages.map(messageHtml).join('');
  $('welcome').classList.toggle('hidden', state.messages.length > 0);
  updateContextBadge();
  if (state.editingIndex != null) {
    requestAnimationFrame(() => {
      const input = $('editMessageInput');
      if (input) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
    });
  }
}


function refreshAgentCard(index) {
  const article = $('messages')?.querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const html = agentStepsHtml(message);
  const existing = article.querySelector('.agent-run-card');
  if (!html) { existing?.remove(); return; }
  const holder = document.createElement('div');
  holder.innerHTML = html;
  const next = holder.firstElementChild;
  if (!next) return;
  if (existing) existing.replaceWith(next);
  else article.querySelector('.message-body')?.insertBefore(next, article.querySelector('.message-content'));
}

function scheduleAgentRender(index) {
  if (state.agentRenderTimer) return;
  state.agentRenderTimer = setTimeout(() => {
    state.agentRenderTimer = null;
    refreshAgentCard(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, AGENT_RENDER_THROTTLE_MS);
}

function agentProgressFromSnapshot(snapshot, existing = {}) {
  return {
    ...(existing || {}),
    percent: Number(snapshot?.progressPercent ?? existing?.percent ?? 0),
    phase: snapshot?.progressPhase || snapshot?.status || existing?.phase || 'working',
    detail: snapshot?.progressDetail || existing?.detail || '',
    status: snapshot?.status || existing?.status || 'running',
    responsePersisted: Boolean(snapshot?.responsePersisted),
    tokenUsage: snapshot?.tokenUsage || existing?.tokenUsage || {},
    activeModel: snapshot?.activeModel || existing?.activeModel || '',
    modelPool: Array.isArray(snapshot?.modelPool) ? snapshot.modelPool : (existing?.modelPool || []),
    modelFailovers: Number(snapshot?.modelFailovers || 0),
    recoveryReplans: Number(snapshot?.recoveryReplans || 0),
    lastRecoveryAnalysis: snapshot?.lastRecoveryAnalysis || existing?.lastRecoveryAnalysis || '',
    activePlanIndex: Number(snapshot?.activePlanIndex || 0),
    planLocked: Boolean(snapshot?.planLocked),
    plan: Array.isArray(snapshot?.plan) ? snapshot.plan : (existing?.plan || []),
    lastActivityAt: snapshot?.lastActivityAt || existing?.lastActivityAt || '',
    totalToolActions: Number(snapshot?.totalToolActions || existing?.totalToolActions || 0),
    planValidationStatus: snapshot?.planValidationStatus || existing?.planValidationStatus || 'not_run',
    planValidationSummary: snapshot?.planValidationSummary || existing?.planValidationSummary || '',
    largeTaskMode: Boolean(snapshot?.largeTaskMode ?? existing?.largeTaskMode),
    workItemSummary: snapshot?.workItemSummary || existing?.workItemSummary || {},
    workItems: Array.isArray(snapshot?.workItems) ? snapshot.workItems : (existing?.workItems || []),
    verificationFailures: Array.isArray(snapshot?.verificationFailures) ? snapshot.verificationFailures : (existing?.verificationFailures || [])
  };
}

function updateStreamingMessage(index) {
  const article = $('messages').querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const content = article.querySelector('.message-content');
  if (!content) return;
  content.innerHTML = MarkdownRenderer.render(stripProjectMarkers(message.content || ''), { streaming: true });
  content.classList.add('typing-cursor');
  updateContextBadge();
}


function updateAgentProgressUi(index) {
  const article = $('messages')?.querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return;
  const card = article.querySelector('.agent-run-card');
  if (!card) { renderMessages(); return; }
  const progress = message.agentProgress || {};
  const pct = Math.max(0, Math.min(100, Number(progress.percent ?? (message.streaming ? 2 : 100))));
  const phase = String(progress.phase || (message.streaming ? 'working' : 'completed')).replaceAll('_', ' ');
  const detail = progress.detail || (message.streaming ? 'Agent is working' : 'Task completed');
  const phaseEl = card.querySelector('.agent-progress-top strong');
  const pctEl = card.querySelector('.agent-progress-percent');
  const fillEl = card.querySelector('.agent-progress-fill');
  const detailEl = card.querySelector('.agent-progress-detail');
  const liveDetailEl = card.querySelector('.agent-live-detail');
  const liveAgeEl = card.querySelector('.agent-live-age');
  if (phaseEl) phaseEl.textContent = phase;
  if (pctEl) pctEl.textContent = `${Math.round(pct)}%`;
  if (fillEl) {
    fillEl.style.width = `${pct}%`;
    fillEl.classList.toggle('active', Boolean(message.streaming && pct < 100));
  }
  if (detailEl) detailEl.textContent = detail;
  if (liveDetailEl) liveDetailEl.textContent = detail;
  if (liveAgeEl) liveAgeEl.textContent = activityAgeText(progress.lastActivityAt, Boolean(message.streaming || progress.status === 'running'));
  const backendStatusEl = card.querySelector('[data-agent-backend-status]');
  const connectionStatusEl = card.querySelector('[data-agent-connection-status]');
  const currentStepEl = card.querySelector('[data-agent-current-step]');
  const lastBackendActivityEl = card.querySelector('[data-agent-last-activity]');
  const runtimeStatusEl = card.querySelector('[data-agent-runtime-status]');
  const backendRaw = String(message.agentBackendStatus || progress.status || (message.streaming ? 'running' : 'unknown')).trim().toLowerCase();
  const streamState = String(message.agentConnectionStatus || (message.streaming ? 'connecting' : 'closed')).trim().toLowerCase();
  const backendReachable = message.agentBackendReachable;
  let connectionLabel;
  if (streamState === 'connected') connectionLabel = backendReachable === false ? 'Stream connected · backend status unavailable' : 'Stream connected · backend reachable';
  else if (streamState === 'disconnected') connectionLabel = backendReachable === false ? 'Stream disconnected · retrying backend status' : 'Stream disconnected · polling backend';
  else if (streamState === 'recovering') connectionLabel = backendReachable === false ? 'Recovering · backend unreachable' : 'Recovering · backend reachable';
  else if (streamState === 'connecting') connectionLabel = backendReachable === false ? 'Connecting · backend status unavailable' : 'Connecting';
  else connectionLabel = backendReachable === false ? 'Closed · backend status unavailable' : 'Closed';
  if (backendStatusEl) backendStatusEl.textContent = (backendRaw || 'unknown').replaceAll('_', ' ').toUpperCase();
  if (connectionStatusEl) connectionStatusEl.textContent = connectionLabel;
  if (currentStepEl) { currentStepEl.textContent = detail || 'Preparing agent run'; currentStepEl.title = detail || ''; }
  if (lastBackendActivityEl) lastBackendActivityEl.textContent = activityAgeText(progress.lastActivityAt, Boolean(message.streaming || progress.status === 'running')) || 'Unknown';
  if (runtimeStatusEl) {
    runtimeStatusEl.classList.toggle('reachable', backendReachable === true);
    runtimeStatusEl.classList.toggle('unreachable', backendReachable === false);
    runtimeStatusEl.classList.toggle('checking', backendReachable == null);
  }
  const track = card.querySelector('.agent-progress-track');
  if (track) track.setAttribute('aria-valuenow', String(Math.round(pct)));
  const usage = progress.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const compactions = Number(usage.compactions || 0);
  const pruned = Number(usage.prunedObservations || 0);
  const saved = Number(usage.estimatedTokensSavedByPruning || 0) + Number(usage.estimatedTokensSavedByCompaction || 0);
  const cacheHit = Number(usage.cacheHitPercent || 0);
  let tokenText = '';
  if (contextNow) tokenText += `Context ~${formatCompact(contextNow)}${contextWindow ? ` / ${formatCompact(contextWindow)}` : ''}`;
  if (providerTotal) tokenText += `${tokenText ? ' · ' : ''}Run tokens ${formatCompact(providerTotal)}`;
  if (compactions) tokenText += `${tokenText ? ' · ' : ''}${compactions} compaction${compactions === 1 ? '' : 's'}`;
  if (pruned) tokenText += `${tokenText ? ' · ' : ''}${pruned} pruned`;
  if (saved) tokenText += `${tokenText ? ' · ' : ''}~${formatCompact(saved)} active tokens saved`;
  if (cacheHit > 0) tokenText += `${tokenText ? ' · ' : ''}cache ${cacheHit.toFixed(0)}%`;
  let tokenEl = card.querySelector('.agent-token-line');
  if (tokenText && !tokenEl) {
    tokenEl = document.createElement('div');
    tokenEl.className = 'agent-token-line';
    card.querySelector('.agent-progress')?.appendChild(tokenEl);
  }
  if (tokenEl) { tokenEl.textContent = tokenText; tokenEl.classList.toggle('hidden', !tokenText); }
}

function scheduleStreamingRender(index) {
  if (state.renderTimer) return;
  state.renderTimer = setTimeout(() => {
    state.renderTimer = null;
    updateStreamingMessage(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, 45);
}

function nearBottom() {
  const view = $('chatView');
  return view.scrollHeight - view.scrollTop - view.clientHeight < 180;
}

function scrollBottom(force = false) {
  if (!force && state.userScrolledUp) return;
  const view = $('chatView');
  requestAnimationFrame(() => {
    view.scrollTop = view.scrollHeight;
    if (force) state.userScrolledUp = false;
    updateScrollButton();
  });
}

function updateScrollButton() {
  $('scrollBottomBtn').classList.toggle('hidden', nearBottom());
}

function setStreaming(value) {
  state.streaming = value;
  $('sendBtn').classList.toggle('hidden', value);
  $('stopBtn').classList.toggle('hidden', !value);
  $('attachBtn').disabled = value;
  refreshAgentModelStrip();
  refreshChatModelPicker();
}

async function stopCurrentRun() {
  const runId = state.activeAgentRunId;
  if (runId) {
    try { await api(`/api/agent/runs/${encodeURIComponent(runId)}/cancel`, { method: 'POST' }); }
    catch (_) { /* the HTTP stream may already be closing */ }
  } else if (state.conversationId) {
    try { await api(`/api/chat/cancel?conversationId=${encodeURIComponent(state.conversationId)}`, { method: 'POST' }); }
    catch (_) { /* best-effort explicit chat cancellation */ }
  }
  state.abortController?.abort();
}

function stopAgentWatch() {
  if (state.agentWatchTimer) clearInterval(state.agentWatchTimer);
  state.agentWatchTimer = null;
}

function mergeDurableAgentActivity(existingSteps, durableSteps) {
  const existing = Array.isArray(existingSteps) ? existingSteps : [];
  const durable = Array.isArray(durableSteps) ? durableSteps : [];
  if (!durable.length) return existing;

  // Durable run state is authoritative for history, but live SSE can briefly be ahead of polling.
  // Preserve richer live metadata (especially approvalId) when the same event is present in both streams.
  const keyOf = step => [
    Number(step?.step || 0),
    String(step?.tool || ''),
    String(step?.status || ''),
    String(step?.detail || ''),
    String(step?.output || '')
  ].join('\u001f');
  const liveByKey = new Map();
  for (const step of existing) {
    const key = keyOf(step);
    const bucket = liveByKey.get(key) || [];
    bucket.push(step);
    liveByKey.set(key, bucket);
  }
  const merged = durable.map(step => {
    const bucket = liveByKey.get(keyOf(step));
    const live = bucket?.shift();
    if (!live) return {...step};
    return {
      ...live,
      ...step,
      approvalId: step.approvalId || live.approvalId || undefined,
      args: step.args ?? live.args,
      output: step.output ?? live.output
    };
  });

  // If SSE delivered a newer event while this polling request was in flight, do not erase it.
  const durableCounts = new Map();
  for (const step of durable) {
    const key = keyOf(step);
    durableCounts.set(key, (durableCounts.get(key) || 0) + 1);
  }
  const seen = new Map();
  for (const step of existing) {
    const key = keyOf(step);
    const index = (seen.get(key) || 0) + 1;
    seen.set(key, index);
    if (index > (durableCounts.get(key) || 0)) merged.push({...step});
  }
  return merged;
}

function startAgentWatch(runId, assistant, assistantIndex) {
  stopAgentWatch();
  state.agentWatchdogCompleted = false;
  let polling = false;
  const tick = async () => {
    if (polling || !runId) return;
    polling = true;
    try {
      const snapshot = await api(`/api/agent/runs/${encodeURIComponent(runId)}`);
      assistant.agentBackendReachable = true;
      assistant.agentBackendStatus = snapshot.status || assistant.agentBackendStatus || 'running';
      assistant.agentBackendPolledAt = new Date().toISOString();
      assistant.agentProgress = agentProgressFromSnapshot(snapshot, assistant.agentProgress);
      if (Array.isArray(snapshot.activityEvents)) {
        assistant.agentSteps = mergeDurableAgentActivity(assistant.agentSteps, snapshot.activityEvents);
        assistant.agentEventTotal = assistant.agentSteps.length;
      }
      const orchestrationFingerprint = JSON.stringify([assistant.agentProgress.phase, assistant.agentProgress.planValidationStatus, assistant.agentProgress.activeModel, assistant.agentProgress.modelFailovers, assistant.agentProgress.recoveryReplans, assistant.agentProgress.activePlanIndex, assistant.agentProgress.workItemSummary, assistant.agentProgress.verificationFailures, assistant.agentProgress.plan.map(item => [item.index, item.status, item.note, item.evidence]), assistant.agentEventTotal, assistant.agentConnectionStatus, assistant.agentBackendReachable, assistant.agentBackendStatus]);
      if (assistant.agentOrchestrationFingerprint !== orchestrationFingerprint) {
        assistant.agentOrchestrationFingerprint = orchestrationFingerprint;
        renderMessages();
      } else {
        updateAgentProgressUi(assistantIndex);
      }

      if (snapshot.finishedAt) {
        if (typeof snapshot.finalAnswer === 'string' && snapshot.finalAnswer.trim()) assistant.content = snapshot.finalAnswer;
        else if (!snapshot.responsePersisted && !assistant.content.trim()) {
          assistant.content = `Agent run ended with backend status **${String(snapshot.status || 'finished').replaceAll('_', ' ')}** before a final response was persisted. The durable run status and activity are preserved above.`;
        }
        assistant.streaming = false;
        state.agentWatchdogCompleted = true;
        renderMessages();
        stopAgentWatch();
        if (assistant.agentConnectionStatus === 'disconnected' || assistant.agentConnectionStatus === 'recovering') {
          setStreaming(false);
          if (state.activeAgentRunId === runId) state.activeAgentRunId = null;
          state.abortController = null;
          toast(`Backend run ${String(snapshot.status || 'completed').replaceAll('_', ' ')} after stream interruption`, 5000);
        } else {
          // The durable run state is authoritative. If the HTTP/SSE stream fails to close after the terminal
          // response was persisted, end only the stale transport; do not ask the user to press Stop.
          setTimeout(() => {
            if (state.streaming && !assistant.serverDone && state.activeAgentRunId === runId) state.abortController?.abort();
          }, 900);
        }
      }
    } catch (_) {
      assistant.agentBackendReachable = false;
      assistant.agentBackendPolledAt = new Date().toISOString();
      updateAgentProgressUi(assistantIndex);
    }
    finally { polling = false; }
  };
  tick();
  state.agentWatchTimer = setInterval(tick, 850);
}

async function sendMessage({ regenerate = false, overrideMessage = null } = {}) {
  if (state.streaming) return;
  if (state.uploadingCount > 0) return toast('Wait for the file upload to finish');
  if (!isConfigured()) {
    openSettings();
    return toast('Configure API key, base URL and model first');
  }
  await ensureConversation();
  if (state.mode === 'agent' && !state.project?.localWorkspace) await ensurePersistentActiveWorkspace();
  let pendingAttachments = regenerate ? [] : [...state.attachments];
  const unsupportedMedia = pendingAttachments.find(file => {
    const mime = String(file.mimeType || '').toLowerCase();
    return mime.startsWith('audio/') || mime.startsWith('video/');
  });
  if (!regenerate && unsupportedMedia) {
    return toast(`Audio/video attachment reading is not enabled yet: ${unsupportedMedia.name}`, 6500);
  }
  if (!regenerate && pendingAttachments.length) {
    try { pendingAttachments = await ensureDocumentAttachmentsReady(pendingAttachments); }
    catch (error) { return toast(error.message, 8000); }
  }
  const hasImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
  if (!regenerate && hasImage && state.mode === 'agent') {
    return toast('Images are handled in Chat mode. Analyse the image in Chat, then give Agent the textual findings or task.', 6500);
  }
  if (!regenerate && hasImage && state.mode === 'chat' && !isVisionCapableModel(state.config.chatModel || state.config.model)) {
    refreshChatModelPicker();
    $('chatModelSelect')?.focus();
    return toast('Select a vision-capable Chat model before sending an image.', 6500);
  }
  let text = overrideMessage != null ? String(overrideMessage).trim() : $('messageInput').value.trim();
  if (!regenerate && !text && pendingAttachments.length) text = 'Please analyze the attached file(s).';
  if (!regenerate && !text) return;

  if (!regenerate) {
    state.messages.push({
      role: 'user',
      content: text,
      attachmentIds: pendingAttachments.map(file => file.id),
      createdAt: new Date().toISOString()
    });
    $('messageInput').value = '';
    state.attachments = [];
    autoGrow();
    renderAttachmentTray();
  }

  const assistantIndex = state.messages.length;
  const assistant = {
    role: 'assistant',
    content: '',
    streaming: true,
    attachmentIds: [],
    mode: state.mode,
    agentSteps: state.mode === 'agent' ? [] : undefined,
    agentConnectionStatus: state.mode === 'agent' ? 'connecting' : undefined,
    agentBackendReachable: state.mode === 'agent' ? null : undefined,
    agentBackendStatus: state.mode === 'agent' ? 'starting' : undefined,
    agentBackendPolledAt: state.mode === 'agent' ? '' : undefined,
    agentTransportError: ''
  };
  state.messages.push(assistant);
  state.editingIndex = null;
  state.userScrolledUp = false;
  renderMessages();
  scrollBottom(true);
  setStreaming(true);
  state.agentWatchdogCompleted = false;

  const payload = {
    conversationId: state.conversationId,
    message: regenerate ? null : text,
    attachmentIds: pendingAttachments.map(file => file.id),
    projectId: state.project?.id || null,
    mode: state.mode,
    regenerate,
    settings: {
      baseUrl: state.config.baseUrl,
      model: state.config.model,
      chatModel: state.config.chatModel || state.config.model,
      temperature: state.config.temperature,
      maxTokens: state.config.maxTokens,
      contextWindowTokens: state.config.contextWindowTokens,
      modelContextWindows: modelContextWindowsSetting(),
      modelTypes: modelTypesSetting(),
      systemPrompt: state.config.systemPrompt,
      useFileContext: state.config.useFileContext,
      agentAllowCommands: state.config.agentAllowCommands,
      agentEditPermission: state.config.agentEditPermission,
      agentShellPermission: state.config.agentShellPermission,
      agentReviewPermission: state.config.agentReviewPermission,
      agentMcpPermission: state.config.agentMcpPermission,
      agentTaskPermission: state.config.agentTaskPermission,
      agentLspPermission: state.config.agentLspPermission,
      agentParallelReadTools: state.config.agentParallelReadTools,
      agentAutoApprove: state.config.agentAutoApprove,
      agentPlanApproval: state.config.agentPlanApproval,
      agentFallbackModels: state.config.agentFallbackEnabled ? currentFallbackModels().join('\n') : '',
      agentRecoveryAttempts: 3
    }
  };

  state.abortController = new AbortController();
  state.activeAgentRunId = null;
  let keepAgentWatchAfterTransportFailure = false;
  try {
    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      signal: state.abortController.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.config.apiKey}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error(await readHttpError(response));

    await consumeSse(response, (event, rawData) => {
      if (event === 'meta') {
        try {
          const meta = JSON.parse(rawData);
          state.conversationId = meta.conversationId || state.conversationId;
          if (meta.agentRunId) {
            state.activeAgentRunId = meta.agentRunId;
            assistant.agentRunId = meta.agentRunId;
            assistant.agentConnectionStatus = 'connected';
            assistant.agentBackendStatus = 'running';
            assistant.agentBackendReachable = null;
            assistant.agentProgress = { percent: 2, phase: 'starting', detail: 'Preparing agent run', status: 'running', tokenUsage: {} };
            startAgentWatch(meta.agentRunId, assistant, assistantIndex);
            renderMessages();
          }
          if (meta.projectId && (!state.project || state.project.id !== meta.projectId)) {
            api(`/api/projects/${encodeURIComponent(meta.projectId)}`).then(project => {
              state.project = project;
              state.projectRootHandle = null;
              state.projectFallbackFiles = null;
              if (project?.localWorkspace) rememberActiveLocalWorkspace(project);
              renderProjectBar();
              updateModeUi();
              if (meta.autoResolvedWorkspace) toast(`Workspace resolved from prompt: ${project.localPath || project.name}`, 4500);
            }).catch(() => {});
          }
          for (let i = state.messages.length - 1; i >= 0; i--) {
            if (state.messages[i].role === 'user' && !state.messages[i].id) {
              state.messages[i].id = meta.userMessageId;
              break;
            }
          }
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'agent_step') {
        try {
          const step = JSON.parse(rawData);
          if (step.runId) { state.activeAgentRunId = step.runId; assistant.agentRunId = step.runId; }
          if (!Array.isArray(assistant.agentSteps)) assistant.agentSteps = [];
          assistant.agentEventTotal = Number(assistant.agentEventTotal || assistant.agentSteps.length) + 1;
          const previous = assistant.agentSteps[assistant.agentSteps.length - 1];
          if (previous && previous.step === step.step && previous.tool === step.tool && previous.status === 'running') {
            assistant.agentSteps[assistant.agentSteps.length - 1] = step;
          } else {
            assistant.agentSteps.push(step);
          }
          if (assistant.agentSteps.length > MAX_AGENT_EVENTS_RETAINED) {
            assistant.agentSteps.splice(0, assistant.agentSteps.length - MAX_AGENT_EVENTS_RETAINED);
          }
          // Approval controls must appear immediately. High-volume tool activity is throttled and refreshes only
          // the Agent card instead of rebuilding the entire conversation DOM on every event.
          if (step.status === 'approval' || step.tool === 'plan_approval') renderMessages();
          else scheduleAgentRender(assistantIndex);
        } catch (_) { /* ignore malformed agent progress */ }
        return;
      }

      if (event === 'agent_changes' || event === 'agent_patch') {
        try {
          const patch = JSON.parse(rawData);
          assistant.agentDirectChangeCount = Number(patch.count || 0);
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'token') {
        let token = rawData;
        try {
          const parsed = JSON.parse(rawData);
          if (parsed && typeof parsed.text === 'string') token = parsed.text;
        } catch (_) { /* backward compatibility with raw token SSE */ }
        assistant.content += token;
        scheduleStreamingRender(assistantIndex);
        return;
      }

      if (event === 'done') {
        assistant.serverDone = true;
        assistant.agentConnectionStatus = assistant.mode === 'agent' ? 'closed' : assistant.agentConnectionStatus;
        if (assistant.mode === 'agent' && (!assistant.agentBackendStatus || ['starting','running'].includes(String(assistant.agentBackendStatus)))) assistant.agentBackendStatus = 'completed';
        stopAgentWatch();
        try {
          const saved = JSON.parse(rawData);
          const steps = assistant.agentSteps;
          const directChangeCount = assistant.agentDirectChangeCount;
          Object.assign(assistant, saved, { streaming: false, agentSteps: steps, agentDirectChangeCount: directChangeCount, mode: assistant.mode });
        } catch (_) {
          assistant.streaming = false;
        }
        return;
      }

      if (event === 'error') {
        let message = rawData;
        try { message = JSON.parse(rawData).message || message; } catch (_) { /* ignore */ }
        const serverError = new Error(message);
        serverError.isServerEvent = true;
        throw serverError;
      }
    });

    assistant.streaming = false;
    renderMessages();
    await loadConversations();
    const conversation = state.conversations.find(c => c.id === state.conversationId);
    if (conversation) $('conversationTitle').textContent = conversation.title;
    if (!regenerate && wantsExcel(text) && assistant.content && !assistant.content.includes('**Error:**')) {
      try { await downloadAssistantExcel(assistantIndex, true); }
      catch (artifactError) { toast(`Excel export failed: ${artifactError.message}`, 5000); }
    }
    const sentImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
    if (!regenerate && sentImage && /(?:not (?:seeing|see)|no (?:image|file).{0,30}(?:attached|provided)|cannot (?:see|view))/i.test(assistant.content || '')) {
      toast('The configured model did not process the image. Use a vision-capable model if image analysis is required.', 6500);
    }
  } catch (error) {
    assistant.streaming = false;
    if (error.name === 'AbortError') {
      if (state.agentWatchdogCompleted) {
        try { await loadConversations(); } catch (_) { /* durable answer is already shown */ }
      } else {
        if (!assistant.content.trim()) assistant.content = 'Generation stopped.';
        else assistant.content += '\n\n*Generation stopped.*';
      }
    } else {
      const agentRunId = assistant.agentRunId || state.activeAgentRunId;
      const isAgentTransportFailure = assistant.mode === 'agent' && !assistant.serverDone && Boolean(agentRunId) && !error.isServerEvent;
      const isChatTransportFailure = assistant.mode === 'chat' && !assistant.serverDone;
      if (isAgentTransportFailure) {
        keepAgentWatchAfterTransportFailure = true;
        assistant.streaming = true;
        assistant.agentConnectionStatus = 'disconnected';
        assistant.agentTransportError = error.message || 'Network connection interrupted';
        if (!assistant.agentBackendStatus || assistant.agentBackendStatus === 'starting') assistant.agentBackendStatus = 'running';
        renderMessages();
        toast('Agent stream disconnected. Backend status polling is still active.', 6000);
      } else if (isChatTransportFailure) {
        const userMessage = [...state.messages.slice(0, assistantIndex)].reverse().find(m => m.role === 'user' && m.id);
        assistant.content += `${assistant.content ? '\n\n' : ''}*Connection interrupted. Recovering the server-side response…*`;
        renderMessages();
        const recovered = await recoverChatAfterStreamFailure(assistantIndex, userMessage?.id);
        if (!recovered) {
          assistant.content = assistant.content.replace(/\n?\n?\*Connection interrupted\. Recovering the server-side response…\*$/, '');
          assistant.content += `${assistant.content ? '\n\n' : ''}**Connection interrupted:** ${error.message}\n\nThe server may still finish and save this response. Reopen this conversation to recover it.`;
        }
      } else {
        assistant.content += `${assistant.content ? '\n\n' : ''}**Error:** ${error.message}`;
      }
    }
    renderMessages();
  } finally {
    if (!keepAgentWatchAfterTransportFailure) {
      stopAgentWatch();
      setStreaming(false);
      state.activeAgentRunId = null;
    }
    state.abortController = null;
    if (state.renderTimer) { clearTimeout(state.renderTimer); state.renderTimer = null; }
    if (state.agentRenderTimer) { clearTimeout(state.agentRenderTimer); state.agentRenderTimer = null; }
    scrollBottom(true);
  }
}


async function recoverChatAfterStreamFailure(assistantIndex, userMessageId) {
  if (!state.conversationId) return false;
  for (let attempt = 0; attempt < 12; attempt++) {
    await new Promise(resolve => setTimeout(resolve, attempt < 4 ? 750 : 1500));
    try {
      const serverMessages = await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/messages`);
      const userIndex = serverMessages.findIndex(m => Number(m.id) === Number(userMessageId));
      if (userIndex < 0) continue;
      const recovered = serverMessages.slice(userIndex + 1).find(m => m.role === 'assistant');
      if (!recovered) continue;
      state.messages[assistantIndex] = { ...recovered, streaming: false, mode: 'chat' };
      renderMessages();
      toast('Chat response recovered after connection interruption', 4500);
      return true;
    } catch (_) { /* network may still be recovering */ }
  }
  return false;
}

async function readHttpError(response) {
  let message = `HTTP ${response.status}`;
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const body = await response.json();
      return body.message || body.error || message;
    }
    const text = await response.text();
    if (text.trim()) return text.trim().slice(0, 1200);
  } catch (_) { /* ignore */ }
  return message;
}

async function consumeSse(response, onEvent) {
  if (!response.body) throw new Error('Streaming response body is unavailable');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventName = 'message';
  let dataLines = [];

  const dispatch = () => {
    if (!dataLines.length) {
      eventName = 'message';
      return;
    }
    const data = dataLines.join('\n');
    dataLines = [];
    const currentEvent = eventName;
    eventName = 'message';
    onEvent(currentEvent, data);
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newline;
    while ((newline = buffer.indexOf('\n')) >= 0) {
      let line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);

      if (line === '') {
        dispatch();
        continue;
      }
      if (line.startsWith(':')) continue;
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
        continue;
      }
      if (line.startsWith('data:')) {
        let valuePart = line.slice(5);
        // SSE allows one optional transport separator space. Remove only that one space,
        // never trimStart(), because model tokens may intentionally start with whitespace.
        if (valuePart.startsWith(' ')) valuePart = valuePart.slice(1);
        dataLines.push(valuePart);
      }
    }
  }

  buffer += decoder.decode();
  if (buffer) {
    let line = buffer.endsWith('\r') ? buffer.slice(0, -1) : buffer;
    if (line.startsWith('data:')) {
      line = line.slice(5);
      if (line.startsWith(' ')) line = line.slice(1);
      dataLines.push(line);
    }
  }
  dispatch();
}

function isDocumentAttachment(file) {
  const mime = String(file?.mimeType || file?.type || '').toLowerCase();
  return !mime.startsWith('image/') && !mime.startsWith('audio/') && !mime.startsWith('video/');
}

async function ensureDocumentAttachmentsReady(files) {
  const refreshed = [];
  for (const file of files || []) {
    if (!isDocumentAttachment(file) || file.uploading) {
      refreshed.push(file);
      continue;
    }
    let current = file;
    const chars = Number(current.extractedCharacters || 0);
    const status = String(current.extractionStatus || '').toLowerCase();
    if (chars <= 0 || status !== 'ready') {
      current = await api(`/api/files/${encodeURIComponent(current.id)}/reextract?conversationId=${encodeURIComponent(state.conversationId)}`, { method: 'POST' });
      const existing = state.attachments.find(item => item.id === file.id);
      current = { ...current, previewUrl: existing?.previewUrl || file.previewUrl || null };
      state.filesById.set(current.id, current);
      const index = state.attachments.findIndex(item => item.id === file.id);
      if (index >= 0) state.attachments[index] = current;
    }
    if (Number(current.extractedCharacters || 0) <= 0 || String(current.extractionStatus || '').toLowerCase() !== 'ready') {
      const detail = current.extractionMessage || 'No readable text could be extracted';
      throw new Error(`Cannot read ${current.name}: ${detail}`);
    }
    refreshed.push(current);
  }
  renderAttachmentTray();
  return refreshed;
}

async function uploadFiles(fileList) {
  let files = Array.from(fileList || []).filter(Boolean);
  if (!files.length) return;
  const images = files.filter(file => String(file.type || '').startsWith('image/'));
  if (state.mode === 'agent' && images.length) {
    files = files.filter(file => !String(file.type || '').startsWith('image/'));
    toast('Images are supported in Chat mode only. Switch to Chat and choose a vision-capable Chat model.', 6500);
    if (!files.length) return;
  }
  await ensureConversation();

  for (const file of files) {
    const tempId = `upload-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    const previewUrl = String(file.type || '').startsWith('image/') ? URL.createObjectURL(file) : null;
    state.attachments.push({ id: tempId, name: file.name, size: file.size, mimeType: file.type, uploading: true, previewUrl });
    state.uploadingCount++;
    renderAttachmentTray();

    const form = new FormData();
    form.append('conversationId', state.conversationId);
    form.append('file', file);

    try {
      const uploaded = await api('/api/files', { method: 'POST', body: form });
      const index = state.attachments.findIndex(item => item.id === tempId);
      if (index >= 0) state.attachments[index] = { ...uploaded, previewUrl };
      state.filesById.set(uploaded.id, uploaded);
      if (String(uploaded.mimeType || '').startsWith('image/')) {
        const selectedChatModel = state.config.chatModel || state.config.model || '';
        if (isVisionCapableModel(selectedChatModel)) {
          toast(`Image ready · Chat will use ${selectedChatModel}`, 4500);
        } else {
          refreshChatModelPicker();
          $('chatModelSelect')?.focus();
          toast('Image ready. Select an image-capable Chat model from the Chat model picker before sending.', 6500);
        }
      } else {
        const chars = Number(uploaded.extractedCharacters || 0);
        const status = String(uploaded.extractionStatus || 'unknown');
        const extractionMessage = String(uploaded.extractionMessage || 'No readable text was extracted');
        if (chars > 0) toast(`${uploaded.name} ready · ${formatCompact(chars)} text chars extracted`, 4200);
        else toast(`${uploaded.name} uploaded, but document reading is ${status}: ${extractionMessage}`, 8000);
      }
      renderAttachmentTray();
    } catch (error) {
      state.attachments = state.attachments.filter(item => item.id !== tempId);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      renderAttachmentTray();
      toast(`Upload failed: ${error.message}`, 4000);
    } finally {
      state.uploadingCount = Math.max(0, state.uploadingCount - 1);
    }
  }
}

function renderAttachmentTray() {
  const hasImage = state.attachments.some(file => String(file.mimeType || '').startsWith('image/'));
  const chips = state.attachments.map(file => {
    const image = String(file.mimeType || '').startsWith('image/');
    const preview = image ? (file.previewUrl || (!file.uploading ? `/api/files/${encodeURIComponent(file.id)}/view` : '')) : '';
    const visual = preview ? `<img class="attachment-thumb" src="${preview}" alt="${esc(file.name)}" />` : `<span>${fileIcon(file.mimeType, file.name)}</span>`;
    const extractionStatus = String(file.extractionStatus || '').toLowerCase();
    const extractionChars = Number(file.extractedCharacters || 0);
    const documentStatus = !image && !file.uploading
      ? (extractionStatus === 'ready' && extractionChars > 0
          ? `<span class="chip-status chip-ready">Ready · ${formatCompact(extractionChars)} chars</span>`
          : `<span class="chip-status chip-warning" title="${esc(file.extractionMessage || 'Document text is not ready')}">${esc(extractionStatus || 'checking')}</span>`)
      : '';
    return `<div class="attachment-chip ${image ? 'image-chip' : ''}" title="${esc(file.name)}">
      ${visual}
      <span class="chip-name">${esc(file.name)}</span>
      ${file.uploading ? '<span class="chip-status">Uploading…</span>' : documentStatus}
      <button class="chip-remove" type="button" data-remove-file="${esc(file.id)}" ${file.uploading ? 'disabled' : ''} aria-label="Remove attachment">×</button>
    </div>`;
  }).join('');
  const note = hasImage
    ? `<div class="image-capability-note">Images use the selected <strong>Chat model</strong>: ${esc(state.config.chatModel || state.config.model || 'not selected')}. ${isVisionCapableModel(state.config.chatModel || state.config.model) ? 'Image input is enabled.' : 'Choose a vision-capable Chat model before sending.'}</div>`
    : '';
  $('attachmentTray').innerHTML = chips + note;
}

function openSettings() {
  syncSettingsUi();
  $('modalBackdrop').classList.remove('hidden');
  setTimeout(() => $('apiKey').focus(), 0);
}

function closeSettings() { $('modalBackdrop').classList.add('hidden'); }

function togglePassword(inputId, buttonId) {
  const input = $(inputId);
  const button = $(buttonId);
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  button.textContent = show ? 'Hide' : 'Show';
}

function autoGrow() {
  const input = $('messageInput');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
  } catch (_) {
    const area = document.createElement('textarea');
    area.value = String(text || '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
  }
}

function downloadText(name, text, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([String(text || '')], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}


function wantsExcel(text) {
  return /\b(excel|xlsx|spreadsheet)\b/i.test(String(text || ''));
}


function previousUserMessage(index) {
  for (let i = Number(index) - 1; i >= 0; i--) {
    if (state.messages[i]?.role === 'user') return state.messages[i];
  }
  return null;
}

function isExcelRequestedForAssistant(index) {
  return wantsExcel(previousUserMessage(index)?.content || '');
}

function hasMarkdownTable(text) {
  return /^\s*\|?.+\|.+\s*\n\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+/m.test(String(text || ''));
}

function filenameFromDisposition(response, fallback) {
  const value = response.headers.get('content-disposition') || '';
  const match = value.match(/filename="?([^";]+)"?/i);
  return match?.[1] || fallback;
}

async function downloadAssistantExcel(index, automatic = false) {
  const message = state.messages[Number(index)];
  if (!message?.content) return;
  const title = `${$('conversationTitle').textContent || 'assistant-export'}-export`;
  const response = await fetch('/api/artifacts/excel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, markdown: message.content })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filenameFromDisposition(response, 'assistant-export.xlsx');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
  toast(automatic ? 'Excel file downloaded' : 'Excel downloaded');
}


async function downloadAssistantPdf(index) {
  const message = state.messages[Number(index)];
  if (!message?.content) return;
  const title = `${$('conversationTitle').textContent || 'assistant-export'}-assistant-${Number(index) + 1}`;
  const response = await fetch('/api/artifacts/pdf', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, markdown: stripProjectMarkers(message.content) })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filenameFromDisposition(response, 'assistant-export.pdf');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
  toast('PDF downloaded');
}

function stripProjectMarkers(text) {
  return String(text || '')
    .replace(/<!--\s*PROJECT_FILE_START:[^>]+-->[\s\S]*?<!--\s*PROJECT_FILE_END\s*-->/gi, '')
    .trim();
}

function extractProjectFileChanges(text) {
  const source = String(text || '');
  const changes = [];
  const marker = /<!--\s*PROJECT_FILE_START:([^\n>]+?)\s*-->([\s\S]*?)<!--\s*PROJECT_FILE_END\s*-->/gi;
  let match;
  while ((match = marker.exec(source)) !== null) {
    const rawMeta = match[1].trim();
    let path = '';
    let baselineHash = '';
    let operation = 'write';

    // Newer structured start-marker format, retained for compatibility.
    if (rawMeta.startsWith('{')) {
      try {
        const meta = JSON.parse(rawMeta);
        path = String(meta.path || '').trim().replace(/\\/g, '/');
        baselineHash = String(meta.baselineHash || '');
        operation = String(meta.operation || 'write').toLowerCase() === 'delete' ? 'delete' : 'write';
      } catch (_) { /* fall back to legacy path marker */ }
    }
    if (!path) path = rawMeta.replace(/^['"]|['"]$/g, '').replace(/\\/g, '/');

    let body = match[2].trim();
    // Agent metadata is a separate hidden comment so legacy Chat-mode patches still work.
    const metaMatch = body.match(/<!--\s*PROJECT_FILE_META:([^>]+?)\s*-->/i);
    if (metaMatch) {
      for (const token of metaMatch[1].split(';')) {
        const eq = token.indexOf('=');
        if (eq < 0) continue;
        const key = token.slice(0, eq).trim();
        const value = token.slice(eq + 1).trim();
        if (key === 'baselineHash') baselineHash = value;
        if (key === 'operation') operation = value.toLowerCase() === 'delete' ? 'delete' : 'write';
      }
      body = body.replace(metaMatch[0], '').trim();
    }

    const fence = body.match(/^```[^\n]*\n([\s\S]*?)\n```\s*$/);
    const content = operation === 'delete' ? null : (fence ? fence[1] : body);
    if (path) changes.push({ path, content, baselineHash, operation });
  }
  return changes;
}

const ACTIVE_LOCAL_WORKSPACE_KEY = 'llm.activeLocalWorkspaceId';

function rememberActiveLocalWorkspace(project) {
  if (!project?.localWorkspace || !project.id) return;
  storageSet('local', ACTIVE_LOCAL_WORKSPACE_KEY, project.id);
  if (project.localPath) storageSet('local', 'llm.activeLocalWorkspacePath', project.localPath);
  if (project.name) storageSet('local', 'llm.activeLocalWorkspaceName', project.name);
}

function forgetActiveLocalWorkspace() {
  storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
  storageRemove('local', 'llm.activeLocalWorkspacePath');
  storageRemove('local', 'llm.activeLocalWorkspaceName');
}

async function restoreActiveLocalWorkspace() {
  const id = storageGet('local', ACTIVE_LOCAL_WORKSPACE_KEY);
  if (!id) return null;
  try {
    const project = await api(`/api/projects/${encodeURIComponent(id)}`);
    if (!project?.localWorkspace) {
      // Keep the remembered path so the workspace can be remapped on the next Agent turn.
      storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
      return null;
    }
    state.project = project;
    state.projectRootHandle = null;
    state.projectFallbackFiles = null;
    rememberActiveLocalWorkspace(project);
    renderProjectBar();
    return project;
  } catch (_) {
    // Do not erase the remembered path on a transient backend/startup failure. The next Agent send can
    // recreate/reuse the local workspace record from the canonical path.
    storageRemove('local', ACTIVE_LOCAL_WORKSPACE_KEY);
    return null;
  }
}

async function ensurePersistentActiveWorkspace() {
  if (state.project?.localWorkspace) return state.project;
  const restored = await restoreActiveLocalWorkspace();
  if (restored?.localWorkspace) return restored;
  const path = storageGet('local', 'llm.activeLocalWorkspacePath');
  if (!path || !state.conversationId) return null;
  try {
    const project = await api('/api/projects/local', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        conversationId: state.conversationId,
        path,
        name: storageGet('local', 'llm.activeLocalWorkspaceName') || 'Local workspace'
      })
    });
    if (!project?.localWorkspace) return null;
    state.project = project;
    state.projectRootHandle = null;
    state.projectFallbackFiles = null;
    rememberActiveLocalWorkspace(project);
    renderProjectBar();
    return project;
  } catch (_) {
    // A prompt may intentionally provide a new path. Let the server resolve that prompt instead of blocking send.
    return null;
  }
}

function renderProjectBar() {
  const bar = $('projectBar');
  if (!state.project) {
    bar.classList.add('hidden');
    updateModeUi();
    return;
  }
  bar.classList.remove('hidden');
  $('projectName').textContent = state.project.name || 'Project';
  const files = Number(state.project.fileCount || 0);
  const chars = Number(state.project.indexedCharacters || 0);
  const access = state.project.localWorkspace ? ' · local workspace · writable' : ' · indexed reference';
  $('projectStats').textContent = `${files} files · ${formatCompact(chars)} indexed chars${access}`;
  updateModeUi();
}

async function rescanProject() {
  if (!state.project?.localWorkspace) {
    return toast('Supply the workspace path in an Agent prompt to activate a live local workspace.', 4500);
  }
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}/rescan-local`, { method: 'POST' });
  renderProjectBar();
  return toast(`Workspace rescanned: ${state.project.fileCount} files`, 3500);
}

function closeProjectWorkspace() {
  if (state.project?.localWorkspace) forgetActiveLocalWorkspace();
  state.project = null;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  renderProjectBar();
  toast('Workspace disconnected. It will no longer be reused automatically.');
}

function openProjectChanges(index) {
  const message = state.messages[Number(index)];
  const changes = extractProjectFileChanges(message?.content || '');
  if (!changes.length) return toast('No structured project file changes found');
  state.pendingProjectChanges = { index: Number(index), changes };
  $('projectChangesSummary').textContent = `${changes.length} file${changes.length === 1 ? '' : 's'} proposed${state.project ? ` for ${state.project.name}` : ''}.`;
  $('projectChangesList').innerHTML = changes.map(change => `<div class="project-change-row"><span class="project-change-path">${change.operation === 'delete' ? '− ' : '+ '}${esc(change.path)}</span><span class="project-change-size">${change.operation === 'delete' ? 'delete' : `${formatCompact((change.content || '').length)} chars`}</span></div>`).join('');
  const canApply = Boolean(state.project?.localWorkspace);
  $('applyProjectChanges').disabled = !canApply;
  $('applyProjectChanges').textContent = canApply ? 'Apply to local workspace' : 'Use an Agent prompt path to activate workspace';
  $('projectChangesBackdrop').classList.remove('hidden');
}

function closeProjectChanges() {
  $('projectChangesBackdrop').classList.add('hidden');
}

async function downloadPendingProjectPatch() {
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  const response = await fetch('/api/artifacts/project-patch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project?.name || 'project', files: pending.changes })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filenameFromDisposition(response, 'project-fixes.zip');
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
}

async function applyPendingProjectChanges() {
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  if (!state.project?.localWorkspace) {
    return toast('No live local workspace is active. Supply its path in an Agent prompt or download the patch.', 5000);
  }
  const result = await api(`/api/projects/${encodeURIComponent(state.project.id)}/apply`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project.name || 'project', files: pending.changes })
  });
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}`);
  renderProjectBar(); closeProjectChanges();
  const totalApplied = Number(result.applied || 0) + Number(result.deleted || 0);
  toast(`Applied ${totalApplied} change(s); originals backed up`, 5000);
}

function beginEditMessage(index) {
  if (state.streaming) return;
  state.editingIndex = index;
  renderMessages();
}

async function saveEditedMessage(index) {
  const input = $('editMessageInput');
  const edited = String(input?.value || '').trim();
  if (!edited) return toast('Message cannot be empty');
  const original = state.messages[index];
  if (!original?.id) return toast('This message is not saved yet');

  const attachments = (original.attachmentIds || []).map(id => state.filesById.get(id)).filter(Boolean);
  await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/rewind/${original.id}`, { method: 'POST' });
  state.messages = state.messages.slice(0, index);
  state.attachments = attachments;
  state.editingIndex = null;
  await sendMessage({ overrideMessage: edited });
}

function openHistoryMenu(id, anchor) {
  state.historyMenuId = id;
  const menu = $('historyMenu');
  const rect = anchor.getBoundingClientRect();
  menu.style.left = `${Math.min(rect.left, window.innerWidth - 145)}px`;
  menu.style.top = `${Math.min(rect.bottom + 4, window.innerHeight - 100)}px`;
  menu.classList.remove('hidden');
}

function closeHistoryMenu() {
  state.historyMenuId = null;
  $('historyMenu').classList.add('hidden');
}

function openRename(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!conversation) return;
  state.renameId = id;
  $('renameInput').value = conversation.title || '';
  $('renameBackdrop').classList.remove('hidden');
  setTimeout(() => { $('renameInput').focus(); $('renameInput').select(); }, 0);
}

function closeRename() {
  state.renameId = null;
  $('renameBackdrop').classList.add('hidden');
}

async function saveRename() {
  if (!state.renameId) return;
  const title = $('renameInput').value.trim();
  if (!title) return toast('Enter a title');
  const id = state.renameId;
  await api(`/api/conversations/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  });
  closeRename();
  await loadConversations();
  if (state.conversationId === id) $('conversationTitle').textContent = title;
}

async function deleteConversation(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!confirm(`Delete “${conversation?.title || 'this chat'}”?`)) return;
  await api(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (state.conversationId === id) newChat();
  await loadConversations();
}

async function clearAllHistory() {
  if (state.streaming) return toast('Stop the current response before clearing history');
  const count = state.conversations.length;
  const scope = count
    ? `all ${count} chat${count === 1 ? '' : 's'} and saved agent-run history`
    : 'all saved chat and agent-run history';
  if (!confirm(`Clear ${scope}?\n\nModel settings, API details and the active local workspace will be kept.`)) return;
  const result = await api('/api/conversations', { method: 'DELETE' });
  state.conversations = [];
  newChat();
  renderHistory();
  toast(`History cleared (${Number(result?.clearedConversations || 0)} chats, ${Number(result?.clearedAgentRuns || 0)} agent runs)`);
}

function closeMenus() {
  closeHistoryMenu();
  $('exportMenu').classList.add('hidden');
}

function renderPromptLibrary() {
  const host = $('promptLibraryList');
  if (!host) return;
  host.innerHTML = PROMPT_LIBRARY.map((item, index) => `<article class="prompt-library-card"><div class="prompt-library-card-head"><div><span>${esc(item.category)}</span><strong>${esc(item.title)}</strong></div><button class="primary-btn" type="button" data-use-prompt="${index}">Use prompt</button></div><pre>${esc(item.prompt)}</pre></article>`).join('');
}

function openPromptLibrary() {
  renderPromptLibrary();
  $('promptLibraryBackdrop')?.classList.remove('hidden');
}

function closePromptLibrary() { $('promptLibraryBackdrop')?.classList.add('hidden'); }

// ---- Event wiring ----
$('brandBtn').onclick = newChat;
$('newChatBtn').onclick = newChat;
$('sendBtn').onclick = () => sendMessage();
$('stopBtn').onclick = () => stopCurrentRun();
$('attachBtn').onclick = () => $('fileInput').click();
document.querySelectorAll('[data-mode]').forEach(button => {
  button.addEventListener('click', () => { setMode(button.dataset.mode); updateWelcomeMode(); });
});
$('projectRefreshBtn').onclick = () => rescanProject().catch(error => toast(error.message, 5000));
$('projectCloseBtn').onclick = closeProjectWorkspace;
$('fileInput').onchange = event => { uploadFiles(event.target.files); event.target.value = ''; };
$('messageInput').addEventListener('input', autoGrow);
$('messageInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    sendMessage();
  }
});
$('messageInput').addEventListener('paste', event => {
  const files = Array.from(event.clipboardData?.files || []);
  if (files.length) uploadFiles(files);
});
$('historySearch').addEventListener('input', event => renderHistory(event.target.value));
$('promptLibraryBtn').onclick = openPromptLibrary;
$('settingsBtn').onclick = openSettings;
$('topSettingsBtn').onclick = openSettings;
$('closeSettings').onclick = closeSettings;
$('cancelSettings').onclick = closeSettings;
$('modalBackdrop').addEventListener('click', event => { if (event.target === $('modalBackdrop')) closeSettings(); });
$('closePromptLibrary').onclick = closePromptLibrary;
$('promptLibraryBackdrop').addEventListener('click', event => { if (event.target === $('promptLibraryBackdrop')) closePromptLibrary(); });
$('promptLibraryList').addEventListener('click', event => {
  const button = event.target.closest('[data-use-prompt]');
  if (!button) return;
  const item = PROMPT_LIBRARY[Number(button.dataset.usePrompt)];
  if (!item) return;
  setMode('agent');
  $('messageInput').value = item.prompt;
  autoGrow();
  closePromptLibrary();
  $('messageInput').focus();
});
$('toggleKey').onclick = () => togglePassword('apiKey', 'toggleKey');
$('homeToggleKey').onclick = () => togglePassword('homeApiKey', 'homeToggleKey');
$('openSidebar').onclick = () => $('sidebar').classList.add('open');
$('closeSidebar').onclick = () => $('sidebar').classList.remove('open');
$('scrollBottomBtn').onclick = () => scrollBottom(true);

if ($('addModelBtn')) $('addModelBtn').onclick = addModelFromUi;
if ($('newModelId')) $('newModelId').addEventListener('keydown', event => {
  if (event.key === 'Enter') { event.preventDefault(); addModelFromUi(); }
});
if ($('modelCatalogList')) {
  $('modelCatalogList').addEventListener('click', event => {
    const testButton = event.target.closest('[data-test-model]');
    if (testButton) return testModelFromLibrary(testButton.dataset.testModel, testButton);
    const button = event.target.closest('[data-remove-model]');
    if (button) removeModelFromLibrary(button.dataset.removeModel);
  });
  $('modelCatalogList').addEventListener('change', event => {
    const row = event.target.closest('[data-model-id]');
    if (!row) return;
    const id = row.dataset.modelId;
    if (event.target.matches('[data-model-name]')) return renameModelInLibrary(id, event.target.value);
    if (event.target.matches('[data-model-type]')) return updateModelLibraryEntry(id, {type:event.target.value});
    if (event.target.matches('[data-model-context]')) return updateModelLibraryEntry(id, {context:Math.max(0, Number(event.target.value || 0))});
  });
}
if ($('agentFallbackEnabled')) $('agentFallbackEnabled').addEventListener('change', renderFallbackModels);
if ($('agentFallbackModels')) $('agentFallbackModels').addEventListener('input', renderFallbackModels);
if ($('modelName')) $('modelName').addEventListener('input', renderFallbackModels);
if ($('addFallbackModelBtn')) $('addFallbackModelBtn').onclick = () => {
  const model = String($('fallbackModelSelect')?.value || '').trim();
  if (!model) return;
  writeFallbackModels([...currentFallbackModels(), model]);
};
if ($('fallbackModelList')) $('fallbackModelList').addEventListener('click', event => {
  const button = event.target.closest('[data-fallback-action]');
  const row = event.target.closest('[data-fallback-index]');
  if (!button || !row) return;
  updateFallbackAt(Number(row.dataset.fallbackIndex), button.dataset.fallbackAction);
});

$('themeBtn').onclick = () => {
  const current = document.documentElement.dataset.theme || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  storageSet('local', 'theme', next);
};

if ($('clearHistoryBtn')) $('clearHistoryBtn').onclick = () => {
  clearAllHistory().catch(error => toast(error.message, 5000));
};

$('exportBtn').onclick = event => {
  event.stopPropagation();
  if (!state.conversationId) return toast('No chat to export');
  $('exportMenu').classList.toggle('hidden');
};
$('exportMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-export-format]');
  if (!button || !state.conversationId) return;
  const format = button.dataset.exportFormat;
  $('exportMenu').classList.add('hidden');
  window.location.href = `/api/conversations/${encodeURIComponent(state.conversationId)}/export?format=${encodeURIComponent(format)}`;
});


if ($('agentModelSelect')) {
  $('agentModelSelect').addEventListener('change', event => chooseAgentPrimaryModel(event.target.value));
  $('agentModelSelect').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); chooseAgentPrimaryModel(event.target.value); event.target.blur(); } });
}
if ($('chatModelSelect')) {
  $('chatModelSelect').addEventListener('change', event => chooseChatModel(event.target.value));
  $('chatModelSelect').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); chooseChatModel(event.target.value); event.target.blur(); } });
}

if ($('applyCibProfile')) $('applyCibProfile').onclick = () => {
  ensureRecommendedModels();
  $('modelName').value = 'qwen3.8-27b';
  if ($('chatModel')) $('chatModel').value = 'mistral-small-4-ITG';
  $('contextWindowTokens').value = '0';
  writeFallbackModels(currentFallbackModels());
  toast('Recommended chat and agent models filled in. Save settings to apply.');
};

$('homeSave').onclick = () => {
  state.config.apiKey = $('homeApiKey').value.trim();
  state.config.baseUrl = $('homeBaseUrl').value.trim();
  const chatModels = applyChatModelsText($('homeChatModel')?.value || '');
  const agentModels = applyAgentModelsText($('homeModel')?.value || '');
  state.config.analysisModel = state.config.model;
  state.config.plannerModel = state.config.model;
  state.config.planValidatorModel = state.config.model;
  state.config.criticModel = state.config.model;
  state.config.embeddingModel = '';
  state.config.smartModelRouting = false;
  state.config.semanticRetrieval = false;
  state.config.rememberKey = $('homeRemember').checked;
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  if (!state.config.agentFallbackModels) state.config.agentFallbackEnabled = false;
  if (!state.config.apiKey || !state.config.baseUrl || !agentModels.length || !chatModels.length) return toast('Enter API key, base URL, one Chat model and one Agent model');
  saveModelCatalog();
  saveConfig();
  syncSettingsUi();
  $('messageInput').focus();
  toast('Model configuration saved');
};

$('saveSettings').onclick = () => {
  state.config.apiKey = $('apiKey').value.trim();
  state.config.baseUrl = $('baseUrl').value.trim();
  const chatModels = applyChatModelsText($('chatModel')?.value || '');
  const agentModels = applyAgentModelsText($('modelName')?.value || '');
  state.config.analysisModel = state.config.model;
  state.config.plannerModel = state.config.model;
  state.config.planValidatorModel = state.config.model;
  state.config.criticModel = state.config.model;
  state.config.embeddingModel = '';
  state.config.smartModelRouting = false;
  state.config.semanticRetrieval = false;
  state.config.temperature = Math.max(0, Math.min(2, Number($('temperature').value || 0.7)));
  state.config.maxTokens = Math.max(0, Number($('maxTokens').value || 0));
  state.config.contextWindowTokens = Math.max(0, Number($('contextWindowTokens').value || 0));
  state.config.autoCompact = $('autoCompact').checked;
  state.config.compactionKeepTokens = Math.max(2000, Number($('compactionKeepTokens').value || 8000));
  state.config.compactionBufferTokens = Math.max(4000, Number($('compactionBufferTokens').value || 20000));
  state.config.oldToolOutputChars = Math.max(400, Number($('oldToolOutputChars').value || 1200));
  state.config.systemPrompt = $('systemPrompt').value;
  state.config.useFileContext = $('useFileContext').checked;
  state.config.agentAllowCommands = $('agentAllowCommands').checked;
  state.config.agentEditPermission = $('agentEditPermission').value;
  state.config.agentShellPermission = $('agentShellPermission').value;
  state.config.agentReviewPermission = $('agentReviewPermission').value;
  state.config.agentMcpPermission = $('agentMcpPermission').value;
  state.config.agentTaskPermission = $('agentTaskPermission').value;
  state.config.agentLspPermission = $('agentLspPermission').value;
  state.config.agentParallelReadTools = $('agentParallelReadTools').checked;
  state.config.agentAutoApprove = $('agentAutoApprove').checked;
  state.config.agentPlanApproval = $('agentPlanApproval').checked;
  state.config.agentFallbackEnabled = Boolean($('agentFallbackEnabled')?.checked);
  state.config.agentFallbackModels = currentFallbackModels().join('\n');
  if (!state.config.agentFallbackModels) state.config.agentFallbackEnabled = false;
  state.config.agentRecoveryAttempts = 3;
  state.config.agentExtraCommands = $('agentExtraCommands').value.trim();
  state.config.rememberKey = $('rememberKey').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !agentModels.length || !chatModels.length) return toast('API key, base URL, one Chat model and one Agent model are required');
  ensureConfiguredModelsInCatalog();
  saveConfig();
  syncSettingsUi();
  closeSettings();
  updateContextBadge();
  toast('Settings saved');
};

$('clearKey').onclick = () => {
  state.config.apiKey = '';
  state.config.rememberKey = false;
  storageRemove('session', 'llm.apiKey');
  storageRemove('local', 'llm.apiKey');
  $('apiKey').value = '';
  $('homeApiKey').value = '';
  $('rememberKey').checked = false;
  $('homeRemember').checked = false;
  updateWelcomeMode();
  toast('API key cleared');
};

$('historyList').addEventListener('click', event => {
  const menuButton = event.target.closest('[data-menu]');
  if (menuButton) {
    event.stopPropagation();
    openHistoryMenu(menuButton.dataset.menu, menuButton);
    return;
  }
  const item = event.target.closest('.history-item');
  if (item) openConversation(item.dataset.id).catch(error => toast(error.message, 4000));
});

$('historyMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-history-action]');
  if (!button || !state.historyMenuId) return;
  const id = state.historyMenuId;
  const action = button.dataset.historyAction;
  closeHistoryMenu();
  if (action === 'rename') openRename(id);
  if (action === 'delete') deleteConversation(id).catch(error => toast(error.message, 4000));
});

$('closeRename').onclick = closeRename;
$('cancelRename').onclick = closeRename;
$('saveRename').onclick = () => saveRename().catch(error => toast(error.message, 4000));
$('renameBackdrop').addEventListener('click', event => { if (event.target === $('renameBackdrop')) closeRename(); });
$('renameInput').addEventListener('keydown', event => { if (event.key === 'Enter') saveRename().catch(error => toast(error.message, 4000)); });
$('closeProjectChanges').onclick = closeProjectChanges;
$('cancelProjectChanges').onclick = closeProjectChanges;
$('downloadProjectPatch').onclick = () => downloadPendingProjectPatch().catch(error => toast(error.message, 5000));
$('applyProjectChanges').onclick = () => applyPendingProjectChanges().catch(error => toast(error.message, 5000));
$('projectChangesBackdrop').addEventListener('click', event => { if (event.target === $('projectChangesBackdrop')) closeProjectChanges(); });

$('attachmentTray').addEventListener('click', event => {
  const button = event.target.closest('[data-remove-file]');
  if (!button || button.disabled) return;
  state.attachments = state.attachments.filter(file => file.id !== button.dataset.removeFile);
  renderAttachmentTray();
});

function renumberPlanEditor(editor) {
  editor?.querySelectorAll('[data-plan-row]').forEach((row, index) => {
    const badge = row.querySelector('.plan-edit-index');
    const text = row.querySelector('[data-plan-text]');
    if (badge) badge.textContent = String(index + 1);
    if (text) text.setAttribute('aria-label', `Plan step ${index + 1}`);
  });
}

function collectPlanEditorItems(editor) {
  if (!editor) return [];
  return [...editor.querySelectorAll('[data-plan-row]')]
    .filter(row => row.querySelector('[data-plan-enabled]')?.checked !== false)
    .map(row => String(row.querySelector('[data-plan-text]')?.value || '').trim())
    .filter(Boolean);
}

async function savePlanEditor(editor, quiet = false) {
  if (!editor) return null;
  const runId = editor.dataset.runId;
  const items = collectPlanEditorItems(editor);
  if (!runId) throw new Error('Agent run id is unavailable');
  if (!items.length) throw new Error('Select or add at least one plan step');
  const snapshot = await api(`/api/agent/runs/${encodeURIComponent(runId)}/plan`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ items })
  });
  for (const message of state.messages) {
    if (message.agentRunId !== runId) continue;
    message.agentProgress = agentProgressFromSnapshot(snapshot, message.agentProgress);
  }
  if (!quiet) toast('Plan saved');
  return snapshot;
}

$('messages').addEventListener('click', async event => {
  let button = event.target.closest('[data-plan-add]');
  if (button) {
    const editor = button.closest('[data-plan-editor]');
    const list = editor?.querySelector('[data-plan-list]');
    if (!list) return;
    const row = document.createElement('div');
    row.className = 'plan-edit-row'; row.dataset.planRow = '';
    row.innerHTML = `<label class="plan-select" title="Include this step"><input type="checkbox" data-plan-enabled checked /></label><span class="plan-edit-index"></span><textarea class="plan-edit-text" rows="2" data-plan-text aria-label="New plan step" placeholder="Describe the next executable outcome and its validation"></textarea><div class="plan-row-actions"><button type="button" class="plan-icon-btn" data-plan-move="up" title="Move up">↑</button><button type="button" class="plan-icon-btn" data-plan-move="down" title="Move down">↓</button><button type="button" class="plan-icon-btn danger" data-plan-remove title="Remove step">×</button></div>`;
    list.appendChild(row); renumberPlanEditor(editor); row.querySelector('textarea')?.focus();
    return;
  }

  button = event.target.closest('[data-plan-remove]');
  if (button) { const editor = button.closest('[data-plan-editor]'); button.closest('[data-plan-row]')?.remove(); renumberPlanEditor(editor); return; }

  button = event.target.closest('[data-plan-move]');
  if (button) {
    const row = button.closest('[data-plan-row]'); const list = row?.parentElement; const editor = button.closest('[data-plan-editor]');
    if (!row || !list) return;
    if (button.dataset.planMove === 'up' && row.previousElementSibling) list.insertBefore(row, row.previousElementSibling);
    if (button.dataset.planMove === 'down' && row.nextElementSibling) list.insertBefore(row.nextElementSibling, row);
    renumberPlanEditor(editor); return;
  }

  button = event.target.closest('[data-plan-save]');
  if (button) {
    try { button.disabled = true; await savePlanEditor(button.closest('[data-plan-editor]')); renderMessages(); }
    catch (error) { toast(`Plan save failed: ${error.message}`, 4500); }
    finally { button.disabled = false; }
    return;
  }

  button = event.target.closest('[data-agent-approval]');
  if (button) {
    const approvalId = String(button.dataset.agentApproval || '').trim();
    const action = String(button.dataset.approvalAction || 'deny').toLowerCase();
    const runCard = button.closest('.agent-run-card');
    const planEditor = runCard?.querySelector('[data-plan-editor]');
    const approvalButtons = button.closest('.agent-approval-actions')?.querySelectorAll('button') || [];
    approvalButtons.forEach(b => b.disabled = true);
    try {
      if (!approvalId || approvalId === 'undefined' || approvalId === 'null') {
        throw new Error('Approval request is missing. Execution has not started.');
      }
      // Approval must commit the current editor contents first; the user should not have to click Save separately.
      if (action !== 'deny' && planEditor) await savePlanEditor(planEditor, true);
      const approvalResult = await api(`/api/agent/approvals/${encodeURIComponent(approvalId)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action })
      });
      if (!approvalResult?.resolved) {
        throw new Error('Approval request is no longer active. Execution was not started.');
      }
      for (const message of state.messages) {
        for (const step of (message.agentSteps || [])) {
          if (step.approvalId === approvalId && step.status === 'approval') {
            step.status = action === 'deny' ? 'error' : 'running';
            step.detail = action === 'run' ? 'Allowed for this run — executing tool' : action === 'once' ? 'Approved once — executing tool' : 'Denied';
          }
        }
      }
      renderMessages();
    } catch (error) {
      approvalButtons.forEach(b => b.disabled = false);
      toast(`Approval failed: ${error.message}`, 4500);
    }
    return;
  }

  button = event.target.closest('[data-code-action]');
  if (button) {
    const block = button.closest('.code-block');
    const code = block?.querySelector('code')?.textContent || '';
    const action = button.dataset.codeAction;
    if (action === 'copy') {
      await copyText(code);
      const label = button.querySelector('span');
      const old = label?.textContent;
      if (label) label.textContent = 'Copied';
      setTimeout(() => { if (label) label.textContent = old || 'Copy'; }, 1200);
      return;
    }
    if (action === 'download') {
      const ext = block?.dataset.ext || 'txt';
      const fileName = ext === 'Dockerfile' ? 'Dockerfile' : `code.${ext}`;
      downloadText(fileName, code);
      return;
    }
    if (action === 'wrap') {
      block?.classList.toggle('wrap-code');
      return;
    }
  }

  button = event.target.closest('[data-copy-msg]');
  if (button) {
    await copyText(stripProjectMarkers(state.messages[Number(button.dataset.copyMsg)]?.content || ''));
    toast('Copied');
    return;
  }

  button = event.target.closest('[data-download-msg]');
  if (button) {
    const index = Number(button.dataset.downloadMsg);
    downloadText(`assistant-${index + 1}.md`, stripProjectMarkers(state.messages[index]?.content || ''), 'text/markdown;charset=utf-8');
    return;
  }

  button = event.target.closest('[data-pdf-msg]');
  if (button) {
    try { await downloadAssistantPdf(Number(button.dataset.pdfMsg)); }
    catch (error) { toast(`PDF export failed: ${error.message}`, 5000); }
    return;
  }

  button = event.target.closest('[data-excel-msg]');
  if (button) {
    await downloadAssistantExcel(Number(button.dataset.excelMsg));
    return;
  }

  button = event.target.closest('[data-project-changes]');
  if (button) {
    openProjectChanges(Number(button.dataset.projectChanges));
    return;
  }

  button = event.target.closest('[data-regenerate]');
  if (button) {
    if (state.messages[state.messages.length - 1]?.role === 'assistant') state.messages.pop();
    await sendMessage({ regenerate: true });
    return;
  }

  button = event.target.closest('[data-edit-msg]');
  if (button) {
    beginEditMessage(Number(button.dataset.editMsg));
    return;
  }

  button = event.target.closest('[data-edit-cancel]');
  if (button) {
    state.editingIndex = null;
    renderMessages();
    return;
  }

  button = event.target.closest('[data-edit-save]');
  if (button) {
    await saveEditedMessage(Number(button.dataset.editSave));
  }
});

$('chatView').addEventListener('scroll', () => {
  state.userScrolledUp = !nearBottom();
  updateScrollButton();
});

document.addEventListener('click', event => {
  const starter = event.target.closest('[data-starter-prompt]');
  if (starter) {
    const mode = starter.dataset.starterMode || 'chat';
    setMode(mode);
    $('messageInput').value = starter.dataset.starterPrompt || '';
    autoGrow();
    $('messageInput').focus();
    return;
  }
  if (!event.target.closest('#historyMenu') && !event.target.closest('[data-menu]')) closeHistoryMenu();
  if (!event.target.closest('#exportMenu') && !event.target.closest('#exportBtn')) $('exportMenu').classList.add('hidden');
});

document.addEventListener('keydown', event => {
  const modifier = event.ctrlKey || event.metaKey;
  if (modifier && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    $('historySearch').focus();
  }
  if (modifier && event.shiftKey && event.key.toLowerCase() === 'o') {
    event.preventDefault();
    newChat();
  }
  if (event.key === 'Escape') {
    closeMenus();
    if (!$('modalBackdrop').classList.contains('hidden')) closeSettings();
    if (!$('promptLibraryBackdrop').classList.contains('hidden')) closePromptLibrary();
    if (!$('renameBackdrop').classList.contains('hidden')) closeRename();
    if (!$('projectChangesBackdrop').classList.contains('hidden')) closeProjectChanges();
  }
});

let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragleave', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('dragover', event => {
  if (event.dataTransfer?.types?.includes('Files')) event.preventDefault();
});
document.addEventListener('drop', event => {
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  uploadFiles(event.dataTransfer.files).catch(error => toast(error.message, 4000));
});

(function init() {
  const storedTheme = storageGet('local', 'theme');
  if (storedTheme === 'dark' || storedTheme === 'light') {
    document.documentElement.dataset.theme = storedTheme;
  } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
    document.documentElement.dataset.theme = 'dark';
  } else {
    document.documentElement.dataset.theme = 'light';
  }

  syncSettingsUi();
  ensureConfiguredModelsInCatalog();
  updateModelBadge();
  updateModeUi();
  updateWelcomeMode();
  renderMessages();
  renderAttachmentTray();
  renderProjectBar();
  autoGrow();
  restoreActiveLocalWorkspace().catch(() => {});
  loadConversations().catch(error => toast(error.message, 4000));
})();
