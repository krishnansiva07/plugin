package com.llmart.llm.controller;

import com.llmart.llm.dto.*;
import com.llmart.llm.service.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/artifacts")
public class ArtifactController {
    private final ExcelExportService excel;
    private final PdfExportService pdf;
    private final ProjectPatchService patches;

    public ArtifactController(ExcelExportService excel, PdfExportService pdf, ProjectPatchService patches) {
        this.excel = excel;
        this.pdf = pdf;
        this.patches = patches;
    }

    @PostMapping(value = "/excel", produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    public ResponseEntity<byte[]> excel(@RequestBody ExcelExportRequest request) throws Exception {
        byte[] bytes = excel.fromMarkdown(request.title(), request.markdown());
        String fileName = safe(request.title() == null || request.title().isBlank() ? "assistant-export" : request.title()) + ".xlsx";
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(bytes);
    }

    @PostMapping(value = "/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> pdf(@RequestBody ExcelExportRequest request) {
        byte[] bytes = pdf.fromMarkdown(request.title(), request.markdown());
        String fileName = safe(request.title() == null || request.title().isBlank() ? "assistant-export" : request.title()) + ".pdf";
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(bytes);
    }

    @PostMapping(value = "/project-patch", produces = "application/zip")
    public ResponseEntity<byte[]> projectPatch(@RequestBody ProjectPatchRequest request) throws Exception {
        byte[] bytes = patches.zip(request);
        String base = request.projectName() == null || request.projectName().isBlank() ? "project-fixes" : safe(request.projectName()) + "-fixes";
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/zip"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + base + ".zip\"")
                .body(bytes);
    }

    private String safe(String s) {
        String value = s.replaceAll("[^a-zA-Z0-9._ -]", "_").trim();
        return value.isBlank() ? "artifact" : value;
    }
}
