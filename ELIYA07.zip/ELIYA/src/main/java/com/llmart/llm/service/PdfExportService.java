package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Lightweight local PDF export with no cloud service or additional binary dependency. */
@Service
public class PdfExportService {
    private static final double PAGE_W = 595.0; // A4
    private static final double PAGE_H = 842.0;
    private static final double LEFT = 48.0;
    private static final double TOP = 52.0;
    private static final double BOTTOM = 48.0;

    public byte[] fromMarkdown(String title, String markdown) {
        List<PdfLine> lines = new ArrayList<>();
        String cleanTitle = title == null || title.isBlank() ? "ELIYA Chat" : title.strip();
        lines.add(new PdfLine(cleanTitle, "F2", 17, 23));
        lines.add(new PdfLine("", "F1", 10.5, 10));
        lines.addAll(markdownLines(markdown));
        return buildPdf(paginate(lines));
    }

    public byte[] conversation(String title, List<com.llmart.llm.dto.MessageDto> messages) {
        List<PdfLine> lines = new ArrayList<>();
        String cleanTitle = title == null || title.isBlank() ? "ELIYA Chat" : title.strip();
        lines.add(new PdfLine(cleanTitle, "F2", 17, 23));
        lines.add(new PdfLine("", "F1", 10.5, 10));
        for (com.llmart.llm.dto.MessageDto message : messages == null ? List.<com.llmart.llm.dto.MessageDto>of() : messages) {
            lines.add(new PdfLine("user".equals(message.role()) ? "You" : "ELIYA", "F2", 12, 18));
            lines.addAll(markdownLines(message.content()));
            lines.add(new PdfLine("", "F1", 10.5, 12));
        }
        return buildPdf(paginate(lines));
    }

    private List<PdfLine> markdownLines(String markdown) {
        String source = String.valueOf(markdown == null ? "" : markdown)
                .replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "")
                .replaceAll("(?i)<br\\s*/?>", " / ")
                .replace("\r\n", "\n").replace('\r', '\n');
        List<PdfLine> out = new ArrayList<>();
        boolean code = false;
        for (String raw : source.split("\n", -1)) {
            String line = raw;
            if (line.stripLeading().startsWith("```" ) || line.stripLeading().startsWith("~~~")) {
                code = !code;
                continue;
            }
            if (line.isBlank()) {
                out.add(new PdfLine("", "F1", 10.5, 8));
                continue;
            }
            String font = code || line.contains("|") ? "F3" : "F1";
            double size = code || line.contains("|") ? 9.2 : 10.5;
            double leading = code || line.contains("|") ? 12 : 14.5;
            String stripped = line.strip();
            int heading = 0;
            while (heading < stripped.length() && stripped.charAt(heading) == '#') heading++;
            if (heading > 0 && heading < stripped.length() && Character.isWhitespace(stripped.charAt(heading))) {
                stripped = stripped.substring(heading).strip();
                font = "F2";
                size = heading == 1 ? 15 : heading == 2 ? 13 : 11.5;
                leading = size + 6;
            }
            stripped = markdownPlainText(stripped);
            int wrap = font.equals("F3") ? 94 : Math.max(56, (int)(88 * 10.5 / size));
            List<String> wrapped = wrap(stripped, wrap);
            for (String part : wrapped) out.add(new PdfLine(part, font, size, leading));
        }
        return out;
    }

    private String markdownPlainText(String value) {
        return value
                .replaceAll("!\\[([^]]*)]\\([^)]*\\)", "$1")
                .replaceAll("\\[([^]]+)]\\(([^)]+)\\)", "$1 ($2)")
                .replace("**", "").replace("__", "").replace("~~", "")
                .replaceAll("(?<!\\*)\\*([^*]+)\\*(?!\\*)", "$1")
                .replaceAll("(?<!_)_([^_]+)_(?!_)", "$1")
                .replace("`", "")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
                .replace("&quot;", "\"").replace("&#39;", "'");
    }

    private List<String> wrap(String text, int maxChars) {
        if (text == null || text.isEmpty()) return List.of("");
        List<String> out = new ArrayList<>();
        String remaining = text;
        while (remaining.length() > maxChars) {
            int cut = remaining.lastIndexOf(' ', maxChars);
            if (cut < Math.max(16, maxChars / 2)) cut = maxChars;
            out.add(remaining.substring(0, cut).stripTrailing());
            remaining = remaining.substring(cut).stripLeading();
        }
        out.add(remaining);
        return out;
    }

    private List<List<PdfLine>> paginate(List<PdfLine> lines) {
        List<List<PdfLine>> pages = new ArrayList<>();
        List<PdfLine> page = new ArrayList<>();
        double y = PAGE_H - TOP;
        for (PdfLine line : lines) {
            if (y - line.leading < BOTTOM && !page.isEmpty()) {
                pages.add(page);
                page = new ArrayList<>();
                y = PAGE_H - TOP;
            }
            page.add(line);
            y -= line.leading;
        }
        if (!page.isEmpty() || pages.isEmpty()) pages.add(page);
        return pages;
    }

    private byte[] buildPdf(List<List<PdfLine>> pages) {
        try {
            List<byte[]> objects = new ArrayList<>();
            objects.add(bytes("<< /Type /Catalog /Pages 2 0 R >>")); // 1
            objects.add(new byte[0]); // pages placeholder, object 2
            objects.add(bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")); // 3
            objects.add(bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")); // 4
            objects.add(bytes("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")); // 5

            List<Integer> pageObjectIds = new ArrayList<>();
            for (List<PdfLine> page : pages) {
                int pageObjId = objects.size() + 1;
                int contentObjId = pageObjId + 1;
                pageObjectIds.add(pageObjId);
                String pageObject = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + fmt(PAGE_W) + " " + fmt(PAGE_H) + "] " +
                        "/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents " + contentObjId + " 0 R >>";
                objects.add(bytes(pageObject));
                byte[] content = pageContent(page);
                ByteArrayOutputStream streamObj = new ByteArrayOutputStream();
                streamObj.write(bytes("<< /Length " + content.length + " >>\nstream\n"));
                streamObj.write(content);
                streamObj.write(bytes("\nendstream"));
                objects.add(streamObj.toByteArray());
            }

            String kids = pageObjectIds.stream().map(id -> id + " 0 R").reduce("", (a,b) -> a.isEmpty() ? b : a + " " + b);
            objects.set(1, bytes("<< /Type /Pages /Kids [" + kids + "] /Count " + pageObjectIds.size() + " >>"));

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(bytes("%PDF-1.4\n%ELIYA\n"));
            List<Integer> offsets = new ArrayList<>();
            offsets.add(0);
            for (int i = 0; i < objects.size(); i++) {
                offsets.add(out.size());
                out.write(bytes((i + 1) + " 0 obj\n"));
                out.write(objects.get(i));
                out.write(bytes("\nendobj\n"));
            }
            int xref = out.size();
            out.write(bytes("xref\n0 " + (objects.size() + 1) + "\n"));
            out.write(bytes("0000000000 65535 f \n"));
            for (int i = 1; i < offsets.size(); i++) out.write(bytes(String.format(Locale.ROOT, "%010d 00000 n \n", offsets.get(i))));
            out.write(bytes("trailer\n<< /Size " + (objects.size() + 1) + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n"));
            return out.toByteArray();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to create PDF export", e);
        }
    }

    private byte[] pageContent(List<PdfLine> lines) {
        StringBuilder out = new StringBuilder("BT\n");
        double y = PAGE_H - TOP;
        String currentFont = "";
        double currentSize = -1;
        for (PdfLine line : lines) {
            y -= line.leading;
            if (!Objects.equals(currentFont, line.font) || currentSize != line.size) {
                out.append('/').append(line.font).append(' ').append(fmt(line.size)).append(" Tf\n");
                currentFont = line.font;
                currentSize = line.size;
            }
            out.append("1 0 0 1 ").append(fmt(LEFT)).append(' ').append(fmt(y)).append(" Tm\n");
            out.append('(').append(pdfString(line.text)).append(") Tj\n");
        }
        out.append("ET");
        return bytes(out.toString());
    }

    private String pdfString(String value) {
        StringBuilder out = new StringBuilder();
        for (char ch : String.valueOf(value == null ? "" : value).toCharArray()) {
            if (ch == '\\' || ch == '(' || ch == ')') out.append('\\').append(ch);
            else if (ch >= 32 && ch <= 255) out.append(ch);
            else if (ch == '\t') out.append("    ");
            else out.append('?');
        }
        return out.toString();
    }

    private String fmt(double n) { return String.format(Locale.ROOT, "%.2f", n); }
    private byte[] bytes(String value) { return value.getBytes(StandardCharsets.ISO_8859_1); }
    private record PdfLine(String text, String font, double size, double leading) {}
}
