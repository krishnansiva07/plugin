package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.BiConsumer;

@Service
public class AgentRunService {
    private static final int MAX_RETAINED_RUNS = 1000;
    private static final int MAX_ACTIVITY_EVENTS_IN_MEMORY = 20_000;
    private static final int ACTIVITY_EVENTS_IN_SNAPSHOT = 500;
    private final Map<String, AgentRun> runs = new ConcurrentHashMap<>();
    // A deleted run may still be unwinding on a worker thread. Tombstoning its id prevents that stale worker
    // from recreating history files after the user explicitly cleared history.
    private final Set<String> suppressedRunIds = ConcurrentHashMap.newKeySet();
    private final Path storeDir;
    private final Object activityJournalLock = new Object();

    public AgentRunService() {
        this(Path.of(System.getProperty("advanced.ai.agentRunStore", "./data/agent-runs")));
    }

    AgentRunService(Path storeDir) {
        this.storeDir = storeDir.toAbsolutePath().normalize();
        try { Files.createDirectories(this.storeDir); } catch (Exception ignored) { }
        loadPersistedRuns();
    }

    public AgentRun start(String conversationId, String projectId) {
        prune();
        AgentRun prior = runs.values().stream()
                .filter(candidate -> Objects.equals(conversationId, candidate.conversationId()))
                .filter(candidate -> Objects.equals(projectId, candidate.projectId()))
                .filter(candidate -> "interrupted".equals(candidate.status))
                .max(Comparator.comparing(AgentRun::createdAt))
                .orElse(null);
        AgentRun run = new AgentRun(UUID.randomUUID().toString(), conversationId, projectId, Instant.now(),
                this::persistQuietly, this::appendActivityQuietly);
        if (prior != null) run.inheritLargeTaskStateFrom(prior);
        runs.put(run.id(), run);
        persistQuietly(run);
        return run;
    }

    public AgentRun require(String id) {
        AgentRun run = runs.get(id);
        if (run == null) throw new NoSuchElementException("Agent run not found");
        return run;
    }

    public boolean cancel(String id) {
        AgentRun run = runs.get(id);
        return run != null && run.cancel();
    }

    public Map<String, Object> status(String id) {
        return require(id).snapshot();
    }

    /** Remove durable agent-run history for a deleted conversation without touching user workspace files. */
    public int deleteForConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return 0;
        List<String> ids = runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .map(AgentRun::id)
                .toList();
        ids.forEach(this::deleteRunHistory);
        return ids.size();
    }

    /** Clear every retained Agent run, including orphaned on-disk history from previously deleted chats. */
    public int clearHistory() {
        LinkedHashSet<String> ids = new LinkedHashSet<>(runs.keySet());
        if (Files.isDirectory(storeDir)) {
            try (var stream = Files.list(storeDir)) {
                stream.map(path -> path.getFileName().toString())
                        .map(AgentRunService::historyRunId)
                        .filter(Objects::nonNull)
                        .forEach(ids::add);
            } catch (Exception ignored) { }
        }
        ids.forEach(this::deleteRunHistory);
        return ids.size();
    }

    private void deleteRunHistory(String id) {
        if (id == null || id.isBlank()) return;
        suppressedRunIds.add(id);
        AgentRun run = runs.remove(id);
        if (run != null && !run.finished()) run.cancel();
        try { Files.deleteIfExists(storeDir.resolve(id + ".properties")); } catch (Exception ignored) { }
        try { Files.deleteIfExists(storeDir.resolve(id + ".properties.tmp")); } catch (Exception ignored) { }
        try { Files.deleteIfExists(storeDir.resolve(id + ".events")); } catch (Exception ignored) { }
    }

    private static String historyRunId(String fileName) {
        if (fileName == null) return null;
        for (String suffix : List.of(".properties.tmp", ".properties", ".events")) {
            if (fileName.endsWith(suffix) && fileName.length() > suffix.length()) {
                return fileName.substring(0, fileName.length() - suffix.length());
            }
        }
        return null;
    }

    /** Latest durable agent-run snapshot for restoring plan/progress after reopening chat history. */
    public Optional<Map<String, Object>> latestForConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return Optional.empty();
        return runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .max(Comparator.comparing(AgentRun::createdAt))
                .map(AgentRun::snapshot);
    }

    /** Durable agent-run snapshots for every retained Agent response in a conversation. */
    public List<Map<String, Object>> forConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return List.of();
        return runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .map(AgentRun::snapshot)
                .toList();
    }

    private void prune() {
        if (runs.size() < MAX_RETAINED_RUNS) return;
        runs.values().stream()
                .filter(AgentRun::finished)
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .limit(Math.max(1, runs.size() - MAX_RETAINED_RUNS + 20L))
                .map(AgentRun::id)
                .toList()
                .forEach(id -> {
                    runs.remove(id);
                    try { Files.deleteIfExists(storeDir.resolve(id + ".properties")); } catch (Exception ignored) { }
                    try { Files.deleteIfExists(storeDir.resolve(id + ".events")); } catch (Exception ignored) { }
                });
    }

    private void persistQuietly(AgentRun run) {
        if (run == null || suppressedRunIds.contains(run.id())) return;
        try {
            Files.createDirectories(storeDir);
            Properties p = run.toProperties();
            Path tmp = storeDir.resolve(run.id() + ".properties.tmp");
            Path target = storeDir.resolve(run.id() + ".properties");
            try (OutputStream out = Files.newOutputStream(tmp, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                p.store(out, "ELIYA agent run");
            }
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    /**
     * Activity is append-journaled independently from the coalesced run snapshot. A JVM crash, provider failure,
     * broken SSE connection, or forced application close can therefore preserve every completed activity event.
     */
    private void appendActivityQuietly(String runId, AgentRun.ActivityEvent event) {
        if (runId == null || runId.isBlank() || event == null || suppressedRunIds.contains(runId)) return;
        try {
            Files.createDirectories(storeDir);
            Path journal = storeDir.resolve(runId + ".events");
            String encoded = AgentRun.encodeActivity(event) + System.lineSeparator();
            synchronized (activityJournalLock) {
                Files.writeString(journal, encoded, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
            }
        } catch (Exception ignored) { }
    }

    private void restoreActivityJournal(AgentRun run) {
        if (run == null) return;
        Path journal = storeDir.resolve(run.id() + ".events");
        if (!Files.isRegularFile(journal)) return;
        ArrayDeque<AgentRun.ActivityEvent> restored = new ArrayDeque<>();
        try (BufferedReader reader = Files.newBufferedReader(journal, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                AgentRun.ActivityEvent event = AgentRun.decodeActivity(line.trim());
                if (event == null) continue;
                restored.addLast(event);
                while (restored.size() > MAX_ACTIVITY_EVENTS_IN_MEMORY) restored.removeFirst();
            }
        } catch (Exception ignored) { return; }
        if (restored.isEmpty()) return;
        synchronized (run) {
            run.activityEvents.clear();
            run.activityEvents.addAll(restored);
            AgentRun.ActivityEvent last = run.activityEvents.peekLast();
            if (last != null && (run.lastActivityAt == null || last.at().isAfter(run.lastActivityAt))) {
                run.lastActivityAt = last.at();
            }
        }
    }

    private void loadPersistedRuns() {
        if (!Files.isDirectory(storeDir)) return;
        try (var stream = Files.list(storeDir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".properties")).sorted().forEach(path -> {
                try (InputStream in = Files.newInputStream(path)) {
                    Properties props = new Properties(); props.load(in);
                    AgentRun run = AgentRun.fromProperties(props, this::persistQuietly, this::appendActivityQuietly);
                    if (run != null) {
                        restoreActivityJournal(run);
                        // A JVM restart cannot safely resume an in-flight tool call. Preserve the run and mark it
                        // interrupted so the UI/user can see exactly where it stopped instead of losing the state.
                        if (!run.finished() && "running".equals(run.status)) {
                            run.markInterruptedByRestart();
                        } else if (!run.finished()) {
                            // A persisted non-running state (for example cancelled/failed) is terminal after restart.
                            run.finishedAt = Instant.now();
                            run.persist();
                        }
                        runs.put(run.id(), run);
                    }
                } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
        prune();
    }

    public static final class AgentRun {
        private final String id;
        private final String conversationId;
        private final String projectId;
        private final Instant createdAt;
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final AtomicReference<Process> activeProcess = new AtomicReference<>();
        private final AtomicLong mutationRevision = new AtomicLong(0);
        private final AtomicLong lastVerificationAttemptRevision = new AtomicLong(-1);
        private final AtomicLong verificationRequiredRevision = new AtomicLong(-1);
        private final AtomicLong lastSuccessfulVerificationRevision = new AtomicLong(-1);
        private final AtomicLong lastDiffRevision = new AtomicLong(-1);
        private final AtomicBoolean lastVerificationSuccessful = new AtomicBoolean(false);
        private final AtomicLong modelCalls = new AtomicLong(0);
        private final AtomicLong providerInputTokens = new AtomicLong(0);
        private final AtomicLong providerOutputTokens = new AtomicLong(0);
        private final AtomicLong providerTotalTokens = new AtomicLong(0);
        private final AtomicLong cachedInputTokens = new AtomicLong(0);
        private final AtomicLong cacheWriteTokens = new AtomicLong(0);
        private final AtomicLong estimatedInputTokens = new AtomicLong(0);
        private final AtomicLong currentContextTokens = new AtomicLong(0);
        private final AtomicLong contextWindowTokens = new AtomicLong(0);
        private final AtomicLong compactions = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByCompaction = new AtomicLong(0);
        private final AtomicLong prunedObservations = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByPruning = new AtomicLong(0);
        private final AtomicLong repeatedCallsPrevented = new AtomicLong(0);
        private final AtomicLong totalToolActions = new AtomicLong(0);
        private final AtomicLong lastSoftPersistNanos = new AtomicLong(0);
        private final AtomicLong progressPercent = new AtomicLong(2);
        private final AtomicBoolean responsePersisted = new AtomicBoolean(false);
        private volatile String progressPhase = "starting";
        private volatile String progressDetail = "Preparing agent run";
        private volatile String finalAnswer = "";
        private volatile String assistantMessageId = "";
        private volatile String lastCheckpointReason = "";
        private volatile String loopBlockReason = "";
        private volatile String objective = "";
        private volatile String planValidationStatus = "not_run";
        private volatile String planValidationSummary = "";
        private final ArrayDeque<ActivityEvent> activityEvents = new ArrayDeque<>();
        private final LinkedHashSet<String> touchedPaths = new LinkedHashSet<>();
        private final List<PlanItem> plan = new ArrayList<>();
        private final Map<Integer, ArrayDeque<String>> planEvidence = new LinkedHashMap<>();
        private final ArrayDeque<String> failureMemory = new ArrayDeque<>();
        private volatile boolean largeTaskMode = false;
        private volatile int workItemBatchSize = 10;
        private final LinkedHashMap<String, WorkItem> workItems = new LinkedHashMap<>();
        private final ArrayDeque<String> verificationFailureQueue = new ArrayDeque<>();
        private volatile boolean planLocked = false;
        private volatile int activePlanIndex = 0;
        private final AtomicLong planStepToolActivity = new AtomicLong(0);
        private final AtomicLong planStepStartMutationRevision = new AtomicLong(0);
        private final List<String> modelPool = new ArrayList<>();
        private volatile int activeModelIndex = 0;
        private volatile String activeModel = "";
        private final AtomicLong modelFailovers = new AtomicLong(0);
        private final AtomicLong recoveryReplans = new AtomicLong(0);
        private volatile String lastModelError = "";
        private volatile String lastRecoveryAnalysis = "";
        private final Set<String> approvedToolsForRun = ConcurrentHashMap.newKeySet();
        private volatile String status = "running";
        private volatile String lastVerification = "";
        private volatile Instant lastActivityAt;
        private volatile Instant finishedAt;
        private final Consumer<AgentRun> persistHook;
        private final BiConsumer<String, ActivityEvent> activityPersistHook;

        private AgentRun(String id, String conversationId, String projectId, Instant createdAt,
                         Consumer<AgentRun> persistHook, BiConsumer<String, ActivityEvent> activityPersistHook) {
            this.id = id;
            this.conversationId = conversationId;
            this.projectId = projectId;
            this.createdAt = createdAt;
            this.lastActivityAt = createdAt;
            this.persistHook = persistHook == null ? ignored -> { } : persistHook;
            this.activityPersistHook = activityPersistHook == null ? (ignoredId, ignoredEvent) -> { } : activityPersistHook;
        }

        private void persist() { persistHook.accept(this); }

        /** Coalesce non-critical telemetry/activity disk writes; correctness checkpoints still call persist(). */
        private void persistSoft() {
            long now = System.nanoTime();
            long previous = lastSoftPersistNanos.get();
            if (previous != 0 && now - previous < 250_000_000L) return;
            if (lastSoftPersistNanos.compareAndSet(previous, now)) persist();
        }

        public String id() { return id; }
        public String conversationId() { return conversationId; }
        public String projectId() { return projectId; }
        public Instant createdAt() { return createdAt; }
        public boolean cancelled() { return cancelled.get(); }
        public boolean finished() { return finishedAt != null; }
        public long mutationRevision() { return mutationRevision.get(); }
        public long lastVerificationAttemptRevision() { return lastVerificationAttemptRevision.get(); }
        public long verificationRequiredRevision() { return verificationRequiredRevision.get(); }
        public long lastSuccessfulVerificationRevision() { return lastSuccessfulVerificationRevision.get(); }
        public long lastDiffRevision() { return lastDiffRevision.get(); }
        public String lastVerification() { return lastVerification; }
        public boolean lastVerificationSuccessful() { return lastVerificationSuccessful.get(); }
        public long modelCalls() { return modelCalls.get(); }
        public long providerInputTokens() { return providerInputTokens.get(); }
        public long providerOutputTokens() { return providerOutputTokens.get(); }
        public long providerTotalTokens() { return providerTotalTokens.get(); }
        public long cachedInputTokens() { return cachedInputTokens.get(); }
        public long compactions() { return compactions.get(); }
        public long prunedObservations() { return prunedObservations.get(); }
        public long estimatedTokensSavedByPruning() { return estimatedTokensSavedByPruning.get(); }
        public long currentContextTokens() { return currentContextTokens.get(); }
        public long contextWindowTokens() { return contextWindowTokens.get(); }
        public long totalToolActions() { return totalToolActions.get(); }
        public Instant lastActivityAt() { return lastActivityAt == null ? createdAt : lastActivityAt; }
        public int progressPercent() { return (int) progressPercent.get(); }
        public String progressPhase() { return progressPhase == null ? "" : progressPhase; }
        public String progressDetail() { return progressDetail == null ? "" : progressDetail; }
        public boolean responsePersisted() { return responsePersisted.get(); }
        public String finalAnswer() { return finalAnswer == null ? "" : finalAnswer; }
        public String assistantMessageId() { return assistantMessageId == null ? "" : assistantMessageId; }
        public synchronized String activeModel() { return activeModel == null ? "" : activeModel; }
        public synchronized List<String> modelPool() { return List.copyOf(modelPool); }
        public long modelFailovers() { return modelFailovers.get(); }
        public long recoveryReplans() { return recoveryReplans.get(); }
        public String lastModelError() { return lastModelError == null ? "" : lastModelError; }
        public String lastRecoveryAnalysis() { return lastRecoveryAnalysis == null ? "" : lastRecoveryAnalysis; }
        public synchronized boolean hasNextModel() { return activeModelIndex + 1 < modelPool.size(); }
        public synchronized int activePlanIndex() { return activePlanIndex; }
        public synchronized boolean planLocked() { return planLocked; }
        public synchronized boolean largeTaskMode() { return largeTaskMode; }
        public synchronized int workItemBatchSize() { return workItemBatchSize; }
        public long planStepToolActivity() { return planStepToolActivity.get(); }
        public boolean loopBlocked() { return loopBlockReason != null && !loopBlockReason.isBlank(); }
        public String loopBlockReason() { return loopBlockReason == null ? "" : loopBlockReason; }
        public void markLoopBlocked(String reason) { loopBlockReason = reason == null ? "Repeated no-progress loop" : reason; persist(); }
        public boolean isToolApprovedForRun(String tool) { return tool != null && approvedToolsForRun.contains(tool); }
        public void approveToolForRun(String tool) { if (tool != null && !tool.isBlank()) { approvedToolsForRun.add(tool); persist(); } }


        private void touchActivity() { lastActivityAt = Instant.now(); }

        /** Update the visible phase/detail without moving the plan-derived percentage. */
        public void updateActivity(String phase, String detail) {
            if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
            if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            touchActivity();
            persistSoft();
        }

        public synchronized void setObjective(String value) {
            objective = value == null ? "" : value.strip();
            persist();
        }

        public synchronized String objective() { return objective == null ? "" : objective; }


        public synchronized void setPlanValidation(String status, String summary) {
            planValidationStatus = status == null || status.isBlank() ? "not_run" : status.strip().toLowerCase(Locale.ROOT);
            planValidationSummary = summary == null ? "" : summary.strip();
            persist();
        }

        public String planValidationStatus() { return planValidationStatus == null ? "not_run" : planValidationStatus; }
        public String planValidationSummary() { return planValidationSummary == null ? "" : planValidationSummary; }

        /** Persist a bounded activity timeline so reopening chat history restores the live agent story, not just final text. */
        public synchronized void recordActivityEvent(Map<String,Object> event) {
            if (event == null || event.isEmpty()) return;
            int step = 0;
            try { step = Integer.parseInt(String.valueOf(event.getOrDefault("step", "0"))); } catch (Exception ignored) { }
            String tool = String.valueOf(event.getOrDefault("tool", "agent"));
            String detail = String.valueOf(event.getOrDefault("detail", ""));
            String statusValue = String.valueOf(event.getOrDefault("status", "running"));
            String args = String.valueOf(event.getOrDefault("args", ""));
            String approvalId = String.valueOf(event.getOrDefault("approvalId", ""));
            if ("null".equalsIgnoreCase(approvalId)) approvalId = "";
            String output = String.valueOf(event.getOrDefault("output", ""));
            if (args.length() > 3000) args = args.substring(0, 3000) + " …";
            if (output.length() > 1800) output = output.substring(0, 1800) + " …";
            ActivityEvent durableEvent = new ActivityEvent(Instant.now(), step, tool, statusValue, detail, args, approvalId, output);
            activityEvents.addLast(durableEvent);
            while (activityEvents.size() > MAX_ACTIVITY_EVENTS_IN_MEMORY) activityEvents.removeFirst();
            syncActivityFromEvent(tool, detail, statusValue);
            // Journal every activity event immediately; the heavier full-state snapshot can remain coalesced.
            activityPersistHook.accept(id, durableEvent);
            persistSoft();
        }

        private void syncActivityFromEvent(String tool, String detail, String statusValue) {
            if (finished()) return;
            String t = tool == null ? "" : tool.toLowerCase(Locale.ROOT);
            String nextPhase;
            if (t.contains("workspace_index") || t.equals("indexing")) nextPhase = "indexing";
            else if (t.contains("recovery_")) nextPhase = "recovering";
            else if (t.contains("plan_validation")) nextPhase = "plan_validation";
            else if (t.contains("plan_analysis") || t.equals("analysis") || t.contains("workspace_resolution")) nextPhase = "analysing";
            else if (t.equals("plan_approval") || "approval".equalsIgnoreCase(statusValue)) nextPhase = "plan_review";
            else if ((t.equals("plan") || t.contains("model_route")) && !planLocked) nextPhase = "planning";
            else if (t.contains("verification") || t.equals("build") || t.equals("test") || t.equals("check")) nextPhase = "verifying";
            else if (t.equals("finish") || t.contains("completion_check")) nextPhase = "finalizing";
            else nextPhase = planLocked ? "executing" : progressPhase;
            if (nextPhase != null && !nextPhase.isBlank()) progressPhase = nextPhase;
            if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            touchActivity();
        }

        public synchronized List<Map<String,Object>> activitySnapshot() {
            List<Map<String,Object>> out = new ArrayList<>();
            for (ActivityEvent event : activityEvents) {
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("at", event.at().toString());
                row.put("step", event.step());
                row.put("tool", event.tool());
                row.put("status", event.status());
                row.put("detail", event.detail());
                if (!event.args().isBlank()) row.put("args", event.args());
                if (!event.approvalId().isBlank()) row.put("approvalId", event.approvalId());
                if (!event.output().isBlank()) row.put("output", event.output());
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized void recordTouchedPaths(Collection<String> paths) {
            if (paths == null) return;
            for (String raw : paths) {
                if (raw == null) continue;
                String path = raw.strip();
                if (path.isBlank()) continue;
                touchedPaths.add(path);
                while (touchedPaths.size() > 200) {
                    Iterator<String> it = touchedPaths.iterator();
                    if (it.hasNext()) { it.next(); it.remove(); } else break;
                }
            }
            persist();
        }

        public synchronized List<String> touchedPaths() { return List.copyOf(touchedPaths); }

        /** Bounded per-step memory of strategies/errors that must not be repeated across executor failovers. */
        public synchronized void recordExecutionFailure(String value) {
            if (value == null) return;
            String line = value.replaceAll("\s+", " ").strip();
            if (line.isBlank()) return;
            if (line.length() > 700) line = line.substring(0, 700) + " …";
            if (failureMemory.isEmpty() || !failureMemory.peekLast().equals(line)) failureMemory.addLast(line);
            while (failureMemory.size() > 50) failureMemory.removeFirst();
            persistSoft();
        }

        public synchronized String failureMemoryText() {
            if (failureMemory.isEmpty()) return "";
            StringBuilder out = new StringBuilder();
            int i = 1;
            for (String item : failureMemory) out.append(i++).append(". ").append(item).append('\n');
            return out.toString().stripTrailing();
        }

        private synchronized void clearFailureMemory() { failureMemory.clear(); }


        public synchronized void configureLargeTask(boolean enabled, int batchSize) {
            largeTaskMode = enabled;
            if (batchSize > 0) workItemBatchSize = Math.max(3, Math.min(50, batchSize));
            persist();
        }

        public synchronized void initializeWorkItems(List<String> items, int batchSize) {
            configureLargeTask(true, batchSize);
            workItems.clear();
            verificationFailureQueue.clear();
            addWorkItemsInternal(items);
            recalculatePlanProgress();
            progressPhase = "large_task";
            progressDetail = workItemProgressDetail();
            persist();
        }

        public synchronized void addWorkItems(List<String> items) {
            configureLargeTask(true, workItemBatchSize);
            addWorkItemsInternal(items);
            recalculatePlanProgress();
            persist();
        }

        private void addWorkItemsInternal(List<String> items) {
            for (String raw : items == null ? List.<String>of() : items) {
                if (raw == null || raw.isBlank()) continue;
                String value = raw.replaceAll("\\s+", " ").strip();
                if (value.length() > 700) value = value.substring(0, 700);
                String id = stableWorkItemId(value);
                workItems.putIfAbsent(id, new WorkItem(id, value, "pending", "", 0));
            }
        }

        private String stableWorkItemId(String value) {
            String base = value == null ? "item" : value.toLowerCase(Locale.ROOT)
                    .replaceAll("[^a-z0-9]+", "-").replaceAll("(^-+|-+$)", "");
            if (base.length() > 36) base = base.substring(0, 36);
            if (base.isBlank()) base = "item";
            String candidate = base;
            int suffix = 2;
            while (workItems.containsKey(candidate) && !Objects.equals(workItems.get(candidate).title(), value)) {
                candidate = base + "-" + suffix++;
            }
            return candidate;
        }

        public synchronized void updateWorkItems(List<String> ids, String newStatus, String note) {
            String statusValue = normalizeWorkItemStatus(newStatus);
            if (ids == null || ids.isEmpty()) throw new IllegalArgumentException("At least one work-item id is required");
            if ("in_progress".equals(statusValue)) {
                long alreadyActive = workItems.values().stream()
                        .filter(item -> "in_progress".equals(item.status()) && !ids.contains(item.id())).count();
                long requested = ids.stream().distinct().filter(workItems::containsKey).count();
                if (alreadyActive + requested > workItemBatchSize) {
                    throw new IllegalStateException("Large-task batch limit is " + workItemBatchSize +
                            " active work items. Complete/fail the current batch before starting more items.");
                }
            }
            String finalNote = note == null ? "" : note.replaceAll("\\s+", " ").strip();
            if (finalNote.length() > 500) finalNote = finalNote.substring(0, 500);
            for (String id : ids) {
                WorkItem old = workItems.get(id);
                if (old == null) throw new IllegalArgumentException("Unknown work-item id: " + id);
                int attempts = old.attempts() + (Set.of("in_progress", "failed").contains(statusValue) ? 1 : 0);
                workItems.put(id, new WorkItem(old.id(), old.title(), statusValue, finalNote, attempts));
            }
            recalculatePlanProgress();
            progressDetail = workItemProgressDetail();
            persist();
        }

        public synchronized String workItemsText(String statusFilter, int offset, int limit) {
            String filter = statusFilter == null ? "" : statusFilter.strip().toLowerCase(Locale.ROOT);
            int skip = Math.max(0, offset);
            int max = limit <= 0 ? 50 : Math.min(200, limit);
            StringBuilder out = new StringBuilder();
            int matched = 0, emitted = 0;
            for (WorkItem item : workItems.values()) {
                if (!filter.isBlank() && !filter.equals(item.status())) continue;
                if (matched++ < skip) continue;
                if (emitted++ >= max) break;
                out.append(item.id()).append(" [").append(item.status()).append("] ").append(item.title());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            if (out.isEmpty()) return "[No matching work items]";
            return workItemProgressDetail() + "\n" + out.toString().stripTrailing();
        }

        public synchronized List<Map<String,Object>> workItemsSnapshot(int maxItems) {
            int max = maxItems <= 0 ? 200 : Math.min(2000, maxItems);
            List<Map<String,Object>> out = new ArrayList<>();
            for (WorkItem item : workItems.values()) {
                if (out.size() >= max) break;
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("id", item.id()); row.put("title", item.title()); row.put("status", item.status());
                row.put("note", item.note()); row.put("attempts", item.attempts());
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized Map<String,Object> workItemSummary() {
            Map<String,Long> counts = new LinkedHashMap<>();
            for (String status : List.of("pending","in_progress","completed","failed","blocked")) counts.put(status, 0L);
            for (WorkItem item : workItems.values()) counts.compute(item.status(), (k,v) -> v == null ? 1L : v + 1L);
            Map<String,Object> summary = new LinkedHashMap<>();
            summary.put("enabled", largeTaskMode);
            summary.put("batchSize", workItemBatchSize);
            summary.put("total", workItems.size());
            summary.putAll(counts);
            summary.put("verificationFailures", verificationFailureQueue.size());
            return summary;
        }

        public synchronized boolean hasUnresolvedWorkItems() {
            return workItems.values().stream().anyMatch(i -> Set.of("pending","in_progress","failed","blocked").contains(i.status()));
        }

        public synchronized void recordVerificationFailures(String result) {
            if (result == null || result.isBlank()) return;
            for (String raw : result.split("\\R")) {
                String line = raw == null ? "" : raw.replaceAll("\\s+", " ").strip();
                String low = line.toLowerCase(Locale.ROOT);
                if (line.length() < 4) continue;
                boolean signal = low.contains("failed") || low.contains("failure") || low.contains("error") ||
                        low.startsWith("fail ") || low.startsWith("fail:") || low.contains(" fail ") ||
                        low.startsWith("✘") || low.startsWith("×") || low.startsWith("x ");
                if (!signal) continue;
                if (line.length() > 500) line = line.substring(0, 500) + " …";
                if (!verificationFailureQueue.contains(line)) verificationFailureQueue.addLast(line);
                while (verificationFailureQueue.size() > 100) verificationFailureQueue.removeFirst();
            }
            persist();
        }

        public synchronized boolean hasVerificationFailures() { return !verificationFailureQueue.isEmpty(); }

        public synchronized void clearVerificationFailures() {
            verificationFailureQueue.clear();
            persist();
        }

        public synchronized String verificationFailureText() {
            if (verificationFailureQueue.isEmpty()) return "[No unresolved verifier failures]";
            Map<String,Integer> groups = new LinkedHashMap<>();
            for (String failure : verificationFailureQueue) groups.merge(failureCategory(failure), 1, Integer::sum);
            StringBuilder out = new StringBuilder("Failure clusters: ");
            out.append(groups.entrySet().stream().map(e -> e.getKey() + "=" + e.getValue()).reduce((a,b) -> a + ", " + b).orElse("none"));
            out.append('\n');
            int i = 1;
            for (String failure : verificationFailureQueue) {
                if (i > 30) { out.append("... ").append(verificationFailureQueue.size() - 30).append(" more"); break; }
                out.append(i++).append(". [").append(failureCategory(failure)).append("] ").append(failure).append('\n');
            }
            return out.toString().stripTrailing();
        }

        private static String failureCategory(String failure) {
            String low = failure == null ? "" : failure.toLowerCase(Locale.ROOT);
            if (low.contains("locator") || low.contains("strict mode") || low.contains("element") || low.contains("selector")) return "locator";
            if (low.contains("fixture") || low.contains("module not found") || low.contains("cannot find module") || low.contains("import")) return "fixture/import";
            if (low.contains("compile") || low.contains("compilation") || low.contains("typescript") || low.contains("type error") || low.contains("cannot find symbol")) return "compile/type";
            if (low.contains("timeout") || low.contains("timed out")) return "timeout";
            if (low.contains("assert") || low.contains("expected") || low.contains("actual")) return "assertion";
            if (low.contains("data") || low.contains("excel") || low.contains("csv") || low.contains("json")) return "test-data";
            return "other";
        }

        private synchronized String workItemProgressDetail() {
            if (workItems.isEmpty()) return largeTaskMode ? "Large-task mode enabled; inventory not initialized" : "";
            long completed = workItems.values().stream().filter(i -> "completed".equals(i.status())).count();
            long failed = workItems.values().stream().filter(i -> "failed".equals(i.status())).count();
            long active = workItems.values().stream().filter(i -> "in_progress".equals(i.status())).count();
            return completed + "/" + workItems.size() + " work items completed" +
                    (active > 0 ? "; " + active + " active" : "") + (failed > 0 ? "; " + failed + " failed" : "");
        }

        private static String normalizeWorkItemStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "failed", "blocked" -> status;
                default -> throw new IllegalArgumentException("Unsupported work-item status: " + value);
            };
        }

        public void recordPruning(long observations, long estimatedTokensSaved) {
            prunedObservations.addAndGet(Math.max(0, observations));
            estimatedTokensSavedByPruning.addAndGet(Math.max(0, estimatedTokensSaved));
            persistSoft();
        }

        /** Durable state is stored outside active chat history and re-injected as a small suffix before each call. */
        public synchronized String durableContextText() {
            StringBuilder out = new StringBuilder();
            out.append("DURABLE AGENT STATE — runtime authoritative; do not infer newer state from compacted history.\n");
            if (!objective().isBlank()) out.append("objective: ").append(clipDurable(objective(), 1400)).append('\n');
            out.append("activeModel: ").append(activeModel()).append("; failovers=").append(modelFailovers())
                    .append("; recoveryReplans=").append(recoveryReplans()).append('\n');
            out.append("workspaceRevision: ").append(mutationRevision()).append("; verificationRequired=").append(verificationRequired())
                    .append("; currentRevisionVerified=").append(verifiedCurrentRevision()).append('\n');
            if (!lastVerification().isBlank()) out.append("lastVerification: ").append(clipDurable(lastVerification(), 1000)).append('\n');
            if (!touchedPaths.isEmpty()) out.append("touchedPaths: ").append(String.join(", ", touchedPaths)).append('\n');
            if (hasPlan()) {
                out.append("activePlanIndex: ").append(activePlanIndex()).append('\n');
                out.append("plan:\n").append(clipDurable(planText(), 4200)).append('\n');
            }
            if (!lastModelError().isBlank()) out.append("lastModelError: ").append(clipDurable(lastModelError(), 700)).append('\n');
            if (!lastRecoveryAnalysis().isBlank()) out.append("lastRecoveryAnalysis: ").append(clipDurable(lastRecoveryAnalysis(), 1200)).append('\n');
            if (!failureMemory.isEmpty()) out.append("avoidRepeatingFailures:\n").append(clipDurable(failureMemoryText(), 1800)).append('\n');
            if (largeTaskMode) {
                out.append("largeTask: ").append(workItemProgressDetail()).append("; batchSize=").append(workItemBatchSize).append('\n');
                if (!verificationFailureQueue.isEmpty()) out.append("verificationFailureQueue:\n").append(clipDurable(verificationFailureText(), 1800)).append('\n');
                if (!workItems.isEmpty()) out.append("activeWorkItems:\n").append(clipDurable(workItemsText("in_progress", 0, 12), 1800)).append('\n');
            }
            if (loopBlocked()) out.append("loopBlock: ").append(clipDurable(loopBlockReason(), 700)).append('\n');
            out.append("continuation: continue only the active approved step; live workspace/tool results override historical summaries.");
            return out.toString();
        }

        private static String clipDurable(String value, int max) {
            if (value == null || value.length() <= max) return value == null ? "" : value;
            return value.substring(0, Math.max(0, max - 22)) + " …[state clipped]";
        }

        public synchronized void configureModelPool(List<String> models) {
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String model : models == null ? List.<String>of() : models) {
                if (model != null && !model.isBlank()) clean.add(model.trim());
            }
            modelPool.clear();
            modelPool.addAll(clean);
            activeModelIndex = 0;
            activeModel = modelPool.isEmpty() ? "" : modelPool.get(0);
            modelFailovers.set(0);
            lastModelError = "";
            persist();
        }

        public synchronized boolean switchToNextModel(String error) {
            lastModelError = error == null ? "" : error.strip();
            if (activeModelIndex + 1 >= modelPool.size()) { persist(); return false; }
            activeModelIndex++;
            activeModel = modelPool.get(activeModelIndex);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /**
         * Provider-recovery failover is cyclic: primary -> fallback(s) -> primary. The caller owns the
         * bounded cycle budget so successful calls reset recovery immediately while long runs never enter
         * an unbounded failover loop. This method changes only the active runtime model; the saved primary
         * configuration and approved plan/workspace state are untouched.
         */
        public synchronized boolean switchToNextModelCyclic(String error) {
            lastModelError = error == null ? "" : error.strip();
            if (modelPool.size() < 2) { persist(); return false; }
            activeModelIndex = Math.floorMod(activeModelIndex + 1, modelPool.size());
            activeModel = modelPool.get(activeModelIndex);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /** Context-specific failover may choose a later, larger-context model without disturbing completed work. */
        public synchronized boolean switchToModel(String targetModel, String error) {
            if (targetModel == null || targetModel.isBlank()) return false;
            int index = -1;
            for (int i = activeModelIndex + 1; i < modelPool.size(); i++) {
                if (targetModel.equals(modelPool.get(i))) { index = i; break; }
            }
            if (index < 0) return false;
            lastModelError = error == null ? "" : error.strip();
            activeModelIndex = index;
            activeModel = modelPool.get(index);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /**
         * Start a fresh executor pass from the primary model after a recovery replan.
         * Failover telemetry is intentionally preserved so the UI/history reflects the complete run.
         */
        public synchronized boolean restartModelCycle(String reason) {
            lastModelError = reason == null ? "" : reason.strip();
            if (modelPool.isEmpty()) { activeModelIndex = 0; activeModel = ""; persist(); return false; }
            activeModelIndex = 0;
            activeModel = modelPool.get(0);
            persist();
            return true;
        }

        public synchronized void recordRecoveryReplan(String analysis) {
            recoveryReplans.incrementAndGet();
            lastRecoveryAnalysis = analysis == null ? "" : analysis.strip();
            progressPhase = "recovering";
            progressDetail = "Focused same-model recovery prepared; resuming the active step";
            touchActivity();
            persist();
        }

        private synchronized void inheritLargeTaskStateFrom(AgentRun prior) {
            if (prior == null || !prior.largeTaskMode()) return;
            largeTaskMode = true;
            workItemBatchSize = prior.workItemBatchSize();
            synchronized (prior) {
                for (WorkItem item : prior.workItems.values()) {
                    workItems.put(item.id(), new WorkItem(item.id(), item.title(), item.status(), item.note(), item.attempts()));
                }
                verificationFailureQueue.addAll(prior.verificationFailureQueue);
                touchedPaths.addAll(prior.touchedPaths);
            }
            long inheritedRevision = Math.max(0, prior.mutationRevision());
            if (inheritedRevision > 0) {
                mutationRevision.set(inheritedRevision);
                verificationRequiredRevision.set(inheritedRevision);
                lastVerificationAttemptRevision.set(-1);
                lastSuccessfulVerificationRevision.set(-1);
                lastVerificationSuccessful.set(false);
                lastVerification = "Inherited workspace changes require fresh verification after restart.";
            }
            progressPhase = "resuming";
            progressDetail = workItems.isEmpty()
                    ? "Resuming interrupted large task"
                    : "Recovered durable large-task ledger after restart: " + workItemProgressDetail();
            lastCheckpointReason = "Recovered durable work-item state from interrupted run " + prior.id();
        }

        public void checkCancelled() {
            if (cancelled()) throw new AgentCancelledException("Agent run was cancelled");
        }

        public boolean cancel() {
            if (finished()) return false;
            if (!cancelled.compareAndSet(false, true)) return false;
            status = "cancelled";
            terminate(activeProcess.get());
            persist();
            return true;
        }

        public void registerProcess(Process process) {
            checkCancelled();
            activeProcess.set(process);
            if (cancelled()) terminate(process);
        }

        public void unregisterProcess(Process process) {
            activeProcess.compareAndSet(process, null);
        }

        public long markMutation() {
            return markMutation(true);
        }

        public long markMutation(boolean verificationRequired) {
            long revision = mutationRevision.incrementAndGet();
            if (verificationRequired) verificationRequiredRevision.set(revision);
            persist();
            return revision;
        }

        public void recordContextEstimate(long currentTokens, long windowTokens) {
            currentContextTokens.set(Math.max(0, currentTokens));
            contextWindowTokens.set(Math.max(0, windowTokens));
            persistSoft();
        }

        public void recordModelUsage(OpenAiCompatibleClient.Usage usage, long estimatedInputForCall) {
            modelCalls.incrementAndGet();
            estimatedInputTokens.addAndGet(Math.max(0, estimatedInputForCall));
            if (usage == null) { persistSoft(); return; }
            providerInputTokens.addAndGet(Math.max(0, usage.inputTokens()));
            providerOutputTokens.addAndGet(Math.max(0, usage.outputTokens()));
            providerTotalTokens.addAndGet(Math.max(0, usage.totalTokens()));
            cachedInputTokens.addAndGet(Math.max(0, usage.cachedInputTokens()));
            cacheWriteTokens.addAndGet(Math.max(0, usage.cacheWriteTokens()));
            persistSoft();
        }

        public void recordCompaction(long estimatedTokensSaved, String reason) {
            compactions.incrementAndGet();
            estimatedTokensSavedByCompaction.addAndGet(Math.max(0, estimatedTokensSaved));
            lastCheckpointReason = reason == null ? "" : reason;
            persist();
        }

        public void markRepeatedCallPrevented() { repeatedCallsPrevented.incrementAndGet(); persist(); }

        /**
         * Monotonic phase progress before/after execution. While an approved plan is active, the percentage is
         * authoritative plan progress and tool/activity updates may change only the phase/detail.
         */
        public void updateProgress(int percent, String phase, String detail) {
            int bounded = Math.max(0, Math.min(99, percent));
            synchronized (this) {
                if (planLocked && hasOpenPlanItems()) {
                    if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                    if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
                    touchActivity();
                    persist();
                    return;
                }
            }
            long before = progressPercent.getAndAccumulate(bounded, Math::max);
            if (bounded >= before) {
                if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            }
            touchActivity();
            persist();
        }

        public void markFinalAnswer(String answer) {
            finalAnswer = answer == null ? "" : answer;
            updateProgress(97, "finalizing", "Preparing final response");
        }

        public void markResponsePersisted(String messageId, String answer) {
            if (answer != null && !answer.isBlank()) finalAnswer = answer;
            assistantMessageId = messageId == null ? "" : messageId;
            responsePersisted.set(true);
            if ("completed".equals(status)) {
                progressPercent.set(100);
                progressPhase = "completed";
                progressDetail = "Task completed";
            } else {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = status;
                if (progressDetail == null || progressDetail.isBlank() || "Persisting final response".equals(progressDetail)) {
                    progressDetail = "blocked".equals(status) ? "Task blocked" : "Task " + status;
                }
            }
            persist();
        }

        public void markVerificationAttempt(boolean successful, String summary) {
            long rev = mutationRevision.get();
            lastVerificationAttemptRevision.set(rev);
            if (successful) lastSuccessfulVerificationRevision.set(rev);
            lastVerificationSuccessful.set(successful);
            lastVerification = summary == null ? "" : summary;
            persist();
        }

        public boolean verifiedCurrentRevision() {
            long required = verificationRequiredRevision.get();
            if (required < 0) return true;
            if (lastVerificationAttemptRevision.get() >= required && !lastVerificationSuccessful.get()) return false;
            return lastSuccessfulVerificationRevision.get() >= required;
        }

        public boolean verificationRequired() {
            return !verifiedCurrentRevision();
        }

        public void markDiffReview() {
            lastDiffRevision.set(mutationRevision.get());
            persist();
        }

        public boolean diffReviewedCurrentRevision() {
            return lastDiffRevision.get() >= mutationRevision.get();
        }

        public synchronized void setPlan(List<String> items) {
            if (planLocked) throw new IllegalStateException("Approved execution plan is locked; use todo_update on the active step instead of replacing it");
            plan.clear();
            planEvidence.clear();
            int i = 1;
            for (String item : items == null ? List.<String>of() : items) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                plan.add(new PlanItem(i++, value, "pending", ""));
            }
            activePlanIndex = 0;
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            persist();
        }

        /** Replace the human-reviewable draft before approval. Once execution starts the plan is immutable. */
        public synchronized void replaceDraftPlan(List<String> items) {
            if (planLocked || activePlanIndex > 0) {
                throw new IllegalStateException("Execution has already started; the approved plan can no longer be edited");
            }
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String item : items == null ? List.<String>of() : items) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                clean.add(value);
                if (clean.size() >= 15) break;
            }
            if (clean.isEmpty()) throw new IllegalArgumentException("At least one plan step is required");
            plan.clear();
            planEvidence.clear();
            int index = 1;
            for (String item : clean) plan.add(new PlanItem(index++, item, "pending", ""));
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            planValidationStatus = "needs_review";
            planValidationSummary = "Plan edited by the user after model validation; user approval is authoritative for this edited draft.";
            progressPhase = "plan_review";
            progressDetail = "Plan updated; waiting for approval";
            persist();
        }

        /**
         * Replace only the unfinished portion of an already-approved plan after every executor model has
         * exhausted its recovery path. Completed steps/evidence stay immutable; the newly validated
         * remaining steps become the active sequential contract immediately.
         */
        public synchronized void reviseRemainingPlan(List<String> remainingItems, String reason) {
            if (!planLocked) throw new IllegalStateException("Recovery replanning requires an approved/locked plan");
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String item : remainingItems == null ? List.<String>of() : remainingItems) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                clean.add(value);
                if (clean.size() >= 12) break;
            }
            if (clean.isEmpty()) throw new IllegalArgumentException("Recovery replan must contain at least one remaining step");

            List<PlanItem> completed = new ArrayList<>();
            Map<Integer, ArrayDeque<String>> completedEvidence = new LinkedHashMap<>();
            for (PlanItem item : plan) {
                if (!"completed".equals(item.status())) continue;
                int nextIndex = completed.size() + 1;
                completed.add(new PlanItem(nextIndex, item.text(), "completed", item.note()));
                ArrayDeque<String> evidence = planEvidence.get(item.index());
                if (evidence != null && !evidence.isEmpty()) completedEvidence.put(nextIndex, new ArrayDeque<>(evidence));
            }

            plan.clear();
            planEvidence.clear();
            plan.addAll(completed);
            planEvidence.putAll(completedEvidence);
            int index = plan.size() + 1;
            boolean firstRecoveryStep = true;
            for (String item : clean) {
                String note = firstRecoveryStep && reason != null && !reason.isBlank()
                        ? "Recovery replan: " + clipDurable(reason.replaceAll("\\s+", " ").strip(), 280)
                        : "";
                plan.add(new PlanItem(index++, item, "pending", note));
                firstRecoveryStep = false;
            }
            activePlanIndex = completed.size() + 1;
            if (activePlanIndex <= plan.size()) {
                PlanItem first = plan.get(activePlanIndex - 1);
                plan.set(activePlanIndex - 1, new PlanItem(first.index(), first.text(), "in_progress",
                        first.note().isBlank() ? "Recovery execution started" : first.note()));
            } else {
                activePlanIndex = 0;
            }
            clearFailureMemory();
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            progressPhase = "recovering";
            progressDetail = "Recovery plan validated; resuming from step " + activePlanIndex;
            persist();
        }

        public synchronized void lockPlan() {
            planLocked = true;
            persist();
        }

        public synchronized void updatePlan(int index, String newStatus, String note) {
            if (index < 1 || index > plan.size()) throw new IllegalArgumentException("Plan index is out of range");
            String status = normalizePlanStatus(newStatus);
            PlanItem old = plan.get(index - 1);
            if (planLocked) {
                if (index != activePlanIndex) {
                    throw new IllegalStateException("Sequential plan gate: only active step " + activePlanIndex + " can be updated; step " + index + " is locked");
                }
                if ("skipped".equals(status)) {
                    throw new IllegalStateException("Approved plan contract: retained steps cannot be skipped. Complete the active step or report a genuine blocker.");
                }
                if ("completed".equals(status) && planStepToolActivity.get() <= 0) {
                    throw new IllegalStateException("Sequential plan gate: step " + index + " cannot complete without real tool activity");
                }
                // Implementation steps may complete from real workspace/tool evidence without compiling after every edit.
                // The final approved step is the verification boundary: if the workspace changed, it cannot close until
                // the latest revision has passed a real verifier. This batches build/test/check/run after coherent edits.
                if ("completed".equals(status) && index == plan.size() && verificationRequired()) {
                    throw new IllegalStateException("Final verification step cannot complete until the latest workspace revision passes a real verifier");
                }
                if ("completed".equals(status) && index == plan.size() && largeTaskMode) {
                    if (workItems.isEmpty()) {
                        throw new IllegalStateException("Large-task final step cannot complete before the durable work-item inventory is initialized");
                    }
                    if (hasUnresolvedWorkItems()) {
                        throw new IllegalStateException("Large-task final step cannot complete while pending/in-progress/failed/blocked work items remain");
                    }
                    if (hasVerificationFailures()) {
                        throw new IllegalStateException("Large-task final step cannot complete while verifier failures remain unresolved");
                    }
                }
                if ("pending".equals(status)) {
                    throw new IllegalStateException("Sequential plan gate: the active approved step cannot be moved back to pending");
                }
            }
            String finalNote = note == null ? "" : note.strip();
            if ("completed".equals(status) && finalNote.isBlank()) finalNote = completionEvidence(index);
            plan.set(index - 1, new PlanItem(old.index(), old.text(), status, finalNote));
            if (planLocked && "completed".equals(status)) {
                int next = index + 1;
                if (next <= plan.size()) {
                    PlanItem nextItem = plan.get(next - 1);
                    plan.set(next - 1, new PlanItem(nextItem.index(), nextItem.text(), "in_progress", "Unlocked after step " + index + " completed"));
                    activePlanIndex = next;
                    clearFailureMemory();
                    planStepToolActivity.set(0);
                    planStepStartMutationRevision.set(mutationRevision.get());
                } else {
                    activePlanIndex = 0;
                    clearFailureMemory();
                }
            }
            recalculatePlanProgress();
            persist();
        }

        public synchronized void recordPlanToolActivity(String tool) { recordPlanToolActivity(tool, ""); }

        public synchronized void recordPlanToolActivity(String tool, String summary) {
            if (!planLocked || activePlanIndex <= 0) return;
            String t = tool == null ? "" : tool.trim().toLowerCase(Locale.ROOT);
            if (Set.of("todowrite", "todoread", "todo_update").contains(t)) return;
            planStepToolActivity.incrementAndGet();
            totalToolActions.incrementAndGet();
            String evidence = summary == null ? "" : summary.replaceAll("\\s+", " ").strip();
            if (!evidence.isBlank()) {
                if (evidence.length() > 360) evidence = evidence.substring(0, 360) + " …";
                ArrayDeque<String> items = planEvidence.computeIfAbsent(activePlanIndex, ignored -> new ArrayDeque<>());
                String line = (t.isBlank() ? "tool" : t) + ": " + evidence;
                if (items.isEmpty() || !items.peekLast().equals(line)) items.addLast(line);
                while (items.size() > 20) items.removeFirst();
            }
            recalculatePlanProgress();
            touchActivity();
            persist();
        }

        private synchronized String completionEvidence(int index) {
            ArrayDeque<String> evidence = planEvidence.get(index);
            if (evidence == null || evidence.isEmpty()) return "Completed with recorded tool evidence.";
            String value = evidence.peekLast();
            return value == null || value.isBlank() ? "Completed with recorded tool evidence." : value;
        }

        public synchronized List<Map<String,Object>> planSnapshot() {
            List<Map<String,Object>> out = new ArrayList<>();
            for (PlanItem item : plan) {
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("index", item.index());
                row.put("text", item.text());
                row.put("status", item.status());
                row.put("note", item.note());
                ArrayDeque<String> evidence = planEvidence.get(item.index());
                row.put("evidence", evidence == null ? List.of() : List.copyOf(evidence));
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized String activePlanStepText() {
            if (activePlanIndex < 1 || activePlanIndex > plan.size()) return "";
            return plan.get(activePlanIndex - 1).text();
        }

        /** Workspace revision when the current plan step was unlocked. */
        public long planStepStartMutationRevision() { return planStepStartMutationRevision.get(); }

        /** Bounded tool evidence collected only for the current active step. */
        public synchronized String activePlanEvidenceText() {
            if (activePlanIndex < 1) return "";
            ArrayDeque<String> evidence = planEvidence.get(activePlanIndex);
            if (evidence == null || evidence.isEmpty()) return "";
            StringBuilder out = new StringBuilder();
            for (String item : evidence) out.append("- ").append(item).append('\n');
            return out.toString().stripTrailing();
        }

        public synchronized String planText() {
            if (plan.isEmpty()) return "[No plan set]";
            StringBuilder out = new StringBuilder();
            for (PlanItem item : plan) {
                out.append(item.index()).append(". [").append(item.status()).append("] ").append(item.text());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }

        public synchronized boolean hasPlan() { return !plan.isEmpty(); }
        public synchronized int planSize() { return plan.size(); }

        public synchronized boolean hasOpenPlanItems() {
            return plan.stream().anyMatch(item -> "pending".equals(item.status()) || "in_progress".equals(item.status()));
        }

        /** Compatibility helper. Locked approved plans must be progressed step-by-step, never bulk-completed. */
        public synchronized void completeOpenPlanItems(String note) {
            if (planLocked) throw new IllegalStateException("Approved plan is sequentially locked and cannot be bulk-completed");
            if (plan.isEmpty()) return;
            String n = note == null ? "" : note.strip();
            for (int i = 0; i < plan.size(); i++) {
                PlanItem old = plan.get(i);
                if ("pending".equals(old.status()) || "in_progress".equals(old.status())) {
                    plan.set(i, new PlanItem(old.index(), old.text(), "completed", n));
                }
            }
            recalculatePlanProgress();
            persist();
        }

        public synchronized void markPlanStarted() {
            if (plan.isEmpty()) return;
            planLocked = true;
            int firstOpen = -1;
            for (int i = 0; i < plan.size(); i++) {
                String status = plan.get(i).status();
                if ("pending".equals(status) || "in_progress".equals(status)) { firstOpen = i; break; }
            }
            if (firstOpen < 0) { activePlanIndex = 0; persist(); return; }
            PlanItem first = plan.get(firstOpen);
            plan.set(firstOpen, new PlanItem(first.index(), first.text(), "in_progress", first.note().isBlank() ? "Execution started" : first.note()));
            activePlanIndex = first.index();
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            persist();
        }

        public void finish(String finalStatus) {
            if (!"cancelled".equals(status)) status = finalStatus == null || finalStatus.isBlank() ? "completed" : finalStatus;
            synchronized (this) {
                if ("completed".equals(status) && planLocked && !plan.isEmpty() && plan.stream().anyMatch(item -> !"completed".equals(item.status()))) {
                    status = "blocked";
                    loopBlockReason = "Approved plan is incomplete; every retained step must complete before the run can finish successfully.";
                }
                if ("completed".equals(status) && largeTaskMode && workItems.isEmpty()) {
                    status = "blocked";
                    loopBlockReason = "Large task did not initialize its durable work-item inventory, so completion cannot be proven.";
                }
                if ("completed".equals(status) && largeTaskMode && hasUnresolvedWorkItems()) {
                    status = "blocked";
                    loopBlockReason = "Large task still has unresolved work items. Complete or explicitly block the remaining items before successful completion.";
                }
                if ("completed".equals(status) && largeTaskMode && !verificationFailureQueue.isEmpty()) {
                    status = "blocked";
                    loopBlockReason = "Large task still has unresolved verification failures. Fix and rerun the relevant verifier before successful completion.";
                }
            }
            if ("completed".equals(status)) {
                progressPercent.accumulateAndGet(98, Math::max);
                progressPhase = "finalizing";
                progressDetail = "Persisting final response";
            } else if ("blocked".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "blocked";
                progressDetail = loopBlocked() ? loopBlockReason() : "Task blocked";
            } else if ("cancelled".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "cancelled";
                progressDetail = "Task cancelled";
            } else if ("failed".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "failed";
                progressDetail = "Task failed";
            }
            finishedAt = Instant.now();
            terminate(activeProcess.getAndSet(null));
            persist();
        }

        private synchronized void recalculatePlanProgress() {
            if (plan.isEmpty()) return;
            long completed = plan.stream().filter(item -> "completed".equals(item.status())).count();
            if (!planLocked) {
                progressPercent.accumulateAndGet(12, Math::max);
                return;
            }
            if (largeTaskMode && !workItems.isEmpty()) {
                long workCompleted = workItems.values().stream().filter(item -> "completed".equals(item.status())).count();
                long workActive = workItems.values().stream().filter(item -> "in_progress".equals(item.status())).count();
                double workFraction = (workCompleted + Math.min(0.5, workActive * 0.15)) / Math.max(1.0, workItems.size());
                double planFraction = completed / Math.max(1.0, plan.size());
                double combined = Math.min(1.0, (workFraction * 0.78) + (planFraction * 0.22));
                progressPercent.set(Math.max(15, Math.min(88, (int)Math.round(15 + combined * 73))));
                progressPhase = completed == plan.size() && !hasUnresolvedWorkItems() ? "tasks_complete" : "executing";
                progressDetail = workItemProgressDetail();
                touchActivity();
                return;
            }
            double span = 73.0 / Math.max(1, plan.size());
            double base = 15.0 + completed * span;
            if (completed < plan.size() && activePlanIndex > 0) {
                double actions = Math.max(0, planStepToolActivity.get());
                // Real tool activity gives bounded within-step movement without pretending the step is complete.
                double activityFraction = Math.min(0.72, (actions / (actions + 4.0)) * 0.72);
                base += span * activityFraction;
            }
            progressPercent.set(Math.max(15, Math.min(88, (int)Math.round(base))));
            if (completed == plan.size()) progressPhase = "tasks_complete";
            else if (progressPhase == null || progressPhase.isBlank() || "working".equals(progressPhase)) progressPhase = "executing";
            if (progressDetail == null || progressDetail.isBlank() || progressDetail.matches("\\d+/\\d+ planned steps completed")) {
                progressDetail = completed + "/" + plan.size() + " planned steps completed";
            }
            touchActivity();
        }

        private void markInterruptedByRestart() {
            status = "interrupted";
            progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
            progressPhase = "interrupted";
            progressDetail = "Agent run was interrupted by application restart";
            if (finalAnswer == null || finalAnswer.isBlank()) finalAnswer = "Agent run was interrupted by application restart before completion.";
            finishedAt = Instant.now();
            recordActivityEvent(Map.of(
                    "step", activePlanIndex,
                    "tool", "run_interrupted",
                    "status", "error",
                    "detail", "Application restarted while this run was active; persisted history and task state were recovered"));
            persist();
        }

        private Properties toProperties() {
            Properties p = new Properties();
            p.setProperty("id", id);
            p.setProperty("conversationId", conversationId == null ? "" : conversationId);
            p.setProperty("projectId", projectId == null ? "" : projectId);
            p.setProperty("createdAt", createdAt.toString());
            p.setProperty("status", status == null ? "running" : status);
            p.setProperty("cancelled", Boolean.toString(cancelled()));
            p.setProperty("mutationRevision", Long.toString(mutationRevision()));
            p.setProperty("verificationRequiredRevision", Long.toString(verificationRequiredRevision()));
            p.setProperty("lastVerificationAttemptRevision", Long.toString(lastVerificationAttemptRevision()));
            p.setProperty("lastSuccessfulVerificationRevision", Long.toString(lastSuccessfulVerificationRevision()));
            p.setProperty("lastDiffRevision", Long.toString(lastDiffRevision()));
            p.setProperty("lastVerificationSuccessful", Boolean.toString(lastVerificationSuccessful()));
            p.setProperty("lastVerification", lastVerification == null ? "" : lastVerification);
            p.setProperty("progressPercent", Integer.toString(progressPercent()));
            p.setProperty("progressPhase", progressPhase());
            p.setProperty("progressDetail", progressDetail());
            p.setProperty("responsePersisted", Boolean.toString(responsePersisted()));
            p.setProperty("finalAnswer", finalAnswer());
            p.setProperty("assistantMessageId", assistantMessageId());
            p.setProperty("planValidationStatus", planValidationStatus());
            p.setProperty("planValidationSummary", planValidationSummary());
            synchronized (this) {
                int skip = Math.max(0, activityEvents.size() - ACTIVITY_EVENTS_IN_SNAPSHOT);
                List<ActivityEvent> recentActivity = activityEvents.stream().skip(skip).toList();
                p.setProperty("activity.count", Integer.toString(recentActivity.size()));
                int ai = 0;
                for (ActivityEvent event : recentActivity) p.setProperty("activity." + (ai++), encodeActivity(event));
            }
            p.setProperty("modelCalls", Long.toString(modelCalls.get()));
            p.setProperty("providerInputTokens", Long.toString(providerInputTokens.get()));
            p.setProperty("providerOutputTokens", Long.toString(providerOutputTokens.get()));
            p.setProperty("providerTotalTokens", Long.toString(providerTotalTokens.get()));
            p.setProperty("cachedInputTokens", Long.toString(cachedInputTokens.get()));
            p.setProperty("cacheWriteTokens", Long.toString(cacheWriteTokens.get()));
            p.setProperty("estimatedInputTokens", Long.toString(estimatedInputTokens.get()));
            p.setProperty("currentContextTokens", Long.toString(currentContextTokens.get()));
            p.setProperty("contextWindowTokens", Long.toString(contextWindowTokens.get()));
            p.setProperty("compactions", Long.toString(compactions.get()));
            p.setProperty("estimatedTokensSavedByCompaction", Long.toString(estimatedTokensSavedByCompaction.get()));
            p.setProperty("prunedObservations", Long.toString(prunedObservations.get()));
            p.setProperty("estimatedTokensSavedByPruning", Long.toString(estimatedTokensSavedByPruning.get()));
            p.setProperty("repeatedCallsPrevented", Long.toString(repeatedCallsPrevented.get()));
            p.setProperty("totalToolActions", Long.toString(totalToolActions.get()));
            p.setProperty("lastActivityAt", lastActivityAt().toString());
            p.setProperty("lastCheckpointReason", lastCheckpointReason == null ? "" : lastCheckpointReason);
            p.setProperty("loopBlockReason", loopBlockReason == null ? "" : loopBlockReason);
            p.setProperty("objective", objective == null ? "" : objective);
            p.setProperty("planLocked", Boolean.toString(planLocked));
            p.setProperty("largeTaskMode", Boolean.toString(largeTaskMode));
            p.setProperty("workItemBatchSize", Integer.toString(workItemBatchSize));
            p.setProperty("activePlanIndex", Integer.toString(activePlanIndex));
            p.setProperty("planStepToolActivity", Long.toString(planStepToolActivity.get()));
            p.setProperty("planStepStartMutationRevision", Long.toString(planStepStartMutationRevision.get()));
            p.setProperty("activeModelIndex", Integer.toString(activeModelIndex));
            p.setProperty("activeModel", activeModel == null ? "" : activeModel);
            p.setProperty("modelFailovers", Long.toString(modelFailovers.get()));
            p.setProperty("recoveryReplans", Long.toString(recoveryReplans.get()));
            p.setProperty("lastModelError", lastModelError == null ? "" : lastModelError);
            p.setProperty("lastRecoveryAnalysis", lastRecoveryAnalysis == null ? "" : lastRecoveryAnalysis);
            synchronized (this) {
                p.setProperty("modelPool.count", Integer.toString(modelPool.size()));
                for (int i = 0; i < modelPool.size(); i++) p.setProperty("modelPool." + i, modelPool.get(i));
                p.setProperty("failureMemory.count", Integer.toString(failureMemory.size()));
                int failureIndex = 0;
                for (String failure : failureMemory) p.setProperty("failureMemory." + failureIndex++, failure);
                p.setProperty("touchedPaths.count", Integer.toString(touchedPaths.size()));
                int touchedIndex = 0;
                for (String path : touchedPaths) p.setProperty("touchedPaths." + touchedIndex++, path);
                p.setProperty("workItems.count", Integer.toString(workItems.size()));
                int workItemIndex = 0;
                for (WorkItem item : workItems.values()) {
                    String wp = "workItems." + workItemIndex++ + ".";
                    p.setProperty(wp + "id", item.id());
                    p.setProperty(wp + "title", item.title());
                    p.setProperty(wp + "status", item.status());
                    p.setProperty(wp + "note", item.note());
                    p.setProperty(wp + "attempts", Integer.toString(item.attempts()));
                }
                p.setProperty("verificationFailures.count", Integer.toString(verificationFailureQueue.size()));
                int vfIndex = 0;
                for (String failure : verificationFailureQueue) p.setProperty("verificationFailures." + vfIndex++, failure);
                p.setProperty("plan.count", Integer.toString(plan.size()));
                for (int i = 0; i < plan.size(); i++) {
                    PlanItem item = plan.get(i);
                    String prefix = "plan." + i + ".";
                    p.setProperty(prefix + "text", item.text());
                    p.setProperty(prefix + "status", item.status());
                    p.setProperty(prefix + "note", item.note());
                    ArrayDeque<String> evidence = planEvidence.get(item.index());
                    int evidenceCount = evidence == null ? 0 : evidence.size();
                    p.setProperty(prefix + "evidence.count", Integer.toString(evidenceCount));
                    if (evidence != null) {
                        int evidenceIndex = 0;
                        for (String value : evidence) p.setProperty(prefix + "evidence." + evidenceIndex++, value);
                    }
                }
            }
            if (finishedAt != null) p.setProperty("finishedAt", finishedAt.toString());
            return p;
        }

        private static AgentRun fromProperties(Properties p, Consumer<AgentRun> persistHook,
                                               BiConsumer<String, ActivityEvent> activityPersistHook) {
            String id = p.getProperty("id", "").trim();
            if (id.isBlank()) return null;
            Instant created; try { created = Instant.parse(p.getProperty("createdAt")); } catch (Exception e) { created = Instant.now(); }
            AgentRun run = new AgentRun(id, emptyToNull(p.getProperty("conversationId")),
                    emptyToNull(p.getProperty("projectId")), created, persistHook, activityPersistHook);
            run.status = p.getProperty("status", "running");
            run.cancelled.set(Boolean.parseBoolean(p.getProperty("cancelled", "false")));
            setLong(run.mutationRevision, p, "mutationRevision", 0);
            setLong(run.verificationRequiredRevision, p, "verificationRequiredRevision", -1);
            setLong(run.lastVerificationAttemptRevision, p, "lastVerificationAttemptRevision", -1);
            setLong(run.lastSuccessfulVerificationRevision, p, "lastSuccessfulVerificationRevision", -1);
            setLong(run.lastDiffRevision, p, "lastDiffRevision", -1);
            run.lastVerificationSuccessful.set(Boolean.parseBoolean(p.getProperty("lastVerificationSuccessful", "false")));
            run.lastVerification = p.getProperty("lastVerification", "");
            setLong(run.progressPercent, p, "progressPercent", 2);
            run.progressPhase = p.getProperty("progressPhase", "starting");
            run.progressDetail = p.getProperty("progressDetail", "Preparing agent run");
            run.responsePersisted.set(Boolean.parseBoolean(p.getProperty("responsePersisted", "false")));
            run.finalAnswer = p.getProperty("finalAnswer", "");
            run.assistantMessageId = p.getProperty("assistantMessageId", "");
            run.planValidationStatus = p.getProperty("planValidationStatus", "not_run");
            run.planValidationSummary = p.getProperty("planValidationSummary", "");
            int activityCount = 0;
            try { activityCount = Integer.parseInt(p.getProperty("activity.count", "0")); } catch (Exception ignored) { }
            for (int i = 0; i < Math.max(0, activityCount); i++) {
                ActivityEvent event = decodeActivity(p.getProperty("activity." + i, ""));
                if (event != null) run.activityEvents.addLast(event);
            }
            setLong(run.modelCalls, p, "modelCalls", 0); setLong(run.providerInputTokens, p, "providerInputTokens", 0);
            setLong(run.providerOutputTokens, p, "providerOutputTokens", 0); setLong(run.providerTotalTokens, p, "providerTotalTokens", 0);
            setLong(run.cachedInputTokens, p, "cachedInputTokens", 0); setLong(run.cacheWriteTokens, p, "cacheWriteTokens", 0);
            setLong(run.estimatedInputTokens, p, "estimatedInputTokens", 0); setLong(run.currentContextTokens, p, "currentContextTokens", 0);
            setLong(run.contextWindowTokens, p, "contextWindowTokens", 0); setLong(run.compactions, p, "compactions", 0);
            setLong(run.estimatedTokensSavedByCompaction, p, "estimatedTokensSavedByCompaction", 0);
            setLong(run.prunedObservations, p, "prunedObservations", 0);
            setLong(run.estimatedTokensSavedByPruning, p, "estimatedTokensSavedByPruning", 0);
            setLong(run.repeatedCallsPrevented, p, "repeatedCallsPrevented", 0);
            setLong(run.totalToolActions, p, "totalToolActions", 0);
            try { run.lastActivityAt = Instant.parse(p.getProperty("lastActivityAt", created.toString())); } catch (Exception ignored) { run.lastActivityAt = created; }
            run.lastCheckpointReason = p.getProperty("lastCheckpointReason", "");
            run.loopBlockReason = p.getProperty("loopBlockReason", "");
            run.objective = p.getProperty("objective", "");
            run.planLocked = Boolean.parseBoolean(p.getProperty("planLocked", "false"));
            run.largeTaskMode = Boolean.parseBoolean(p.getProperty("largeTaskMode", "false"));
            try { run.workItemBatchSize = Math.max(3, Math.min(50, Integer.parseInt(p.getProperty("workItemBatchSize", "10")))); }
            catch (Exception ignored) { run.workItemBatchSize = 10; }
            try { run.activePlanIndex = Integer.parseInt(p.getProperty("activePlanIndex", "0")); } catch (Exception ignored) { run.activePlanIndex = 0; }
            setLong(run.planStepToolActivity, p, "planStepToolActivity", 0);
            setLong(run.planStepStartMutationRevision, p, "planStepStartMutationRevision", run.mutationRevision());
            try { run.activeModelIndex = Integer.parseInt(p.getProperty("activeModelIndex", "0")); } catch (Exception ignored) { run.activeModelIndex = 0; }
            run.activeModel = p.getProperty("activeModel", "");
            setLong(run.modelFailovers, p, "modelFailovers", 0);
            setLong(run.recoveryReplans, p, "recoveryReplans", 0);
            run.lastModelError = p.getProperty("lastModelError", "");
            run.lastRecoveryAnalysis = p.getProperty("lastRecoveryAnalysis", "");
            int modelCount; try { modelCount = Integer.parseInt(p.getProperty("modelPool.count", "0")); } catch (Exception ignored) { modelCount = 0; }
            for (int i = 0; i < Math.max(0, modelCount); i++) {
                String model = p.getProperty("modelPool." + i, "").strip();
                if (!model.isBlank()) run.modelPool.add(model);
            }
            if (run.activeModel.isBlank() && !run.modelPool.isEmpty()) {
                run.activeModelIndex = Math.max(0, Math.min(run.activeModelIndex, run.modelPool.size() - 1));
                run.activeModel = run.modelPool.get(run.activeModelIndex);
            }
            int failureCount;
            try { failureCount = Integer.parseInt(p.getProperty("failureMemory.count", "0")); } catch (Exception e) { failureCount = 0; }
            for (int i = 0; i < Math.min(8, Math.max(0, failureCount)); i++) {
                String value = p.getProperty("failureMemory." + i, "").strip();
                if (!value.isBlank()) run.failureMemory.addLast(value);
            }
            int touchedCount;
            try { touchedCount = Integer.parseInt(p.getProperty("touchedPaths.count", "0")); } catch (Exception e) { touchedCount = 0; }
            for (int i = 0; i < Math.max(0, touchedCount); i++) {
                String path = p.getProperty("touchedPaths." + i, "").strip();
                if (!path.isBlank()) run.touchedPaths.add(path);
            }
            int workItemCount;
            try { workItemCount = Integer.parseInt(p.getProperty("workItems.count", "0")); } catch (Exception e) { workItemCount = 0; }
            for (int i = 0; i < Math.max(0, workItemCount); i++) {
                String wp = "workItems." + i + ".";
                String idValue = p.getProperty(wp + "id", "").strip();
                String title = p.getProperty(wp + "title", "").strip();
                if (idValue.isBlank() || title.isBlank()) continue;
                String statusValue;
                try { statusValue = normalizeWorkItemStatus(p.getProperty(wp + "status", "pending")); } catch (Exception ignored) { statusValue = "pending"; }
                int attempts = 0; try { attempts = Integer.parseInt(p.getProperty(wp + "attempts", "0")); } catch (Exception ignored) { }
                run.workItems.put(idValue, new WorkItem(idValue, title, statusValue, p.getProperty(wp + "note", ""), Math.max(0, attempts)));
            }
            int vfCount;
            try { vfCount = Integer.parseInt(p.getProperty("verificationFailures.count", "0")); } catch (Exception e) { vfCount = 0; }
            for (int i = 0; i < Math.min(100, Math.max(0, vfCount)); i++) {
                String value = p.getProperty("verificationFailures." + i, "").strip();
                if (!value.isBlank()) run.verificationFailureQueue.addLast(value);
            }
            int planCount;
            try { planCount = Integer.parseInt(p.getProperty("plan.count", "0")); } catch (Exception e) { planCount = 0; }
            for (int i = 0; i < Math.max(0, planCount); i++) {
                String prefix = "plan." + i + ".";
                String text = p.getProperty(prefix + "text", "").strip();
                if (text.isBlank()) continue;
                String planStatus;
                try { planStatus = normalizePlanStatus(p.getProperty(prefix + "status", "pending")); } catch (Exception ignored) { planStatus = "pending"; }
                int restoredIndex = run.plan.size() + 1;
                run.plan.add(new PlanItem(restoredIndex, text, planStatus, p.getProperty(prefix + "note", "")));
                int evidenceCount;
                try { evidenceCount = Integer.parseInt(p.getProperty(prefix + "evidence.count", "0")); } catch (Exception ignored) { evidenceCount = 0; }
                if (evidenceCount > 0) {
                    ArrayDeque<String> evidence = new ArrayDeque<>();
                    for (int e = 0; e < Math.min(6, evidenceCount); e++) {
                        String value = p.getProperty(prefix + "evidence." + e, "").strip();
                        if (!value.isBlank()) evidence.addLast(value);
                    }
                    if (!evidence.isEmpty()) run.planEvidence.put(restoredIndex, evidence);
                }
            }
            String finished = p.getProperty("finishedAt", "");
            if (!finished.isBlank()) try { run.finishedAt = Instant.parse(finished); } catch (Exception ignored) { }
            return run;
        }

        private static void setLong(AtomicLong target, Properties p, String key, long fallback) {
            try { target.set(Long.parseLong(p.getProperty(key, Long.toString(fallback)))); } catch (Exception e) { target.set(fallback); }
        }
        private static String emptyToNull(String value) { return value == null || value.isBlank() ? null : value; }

        public Map<String, Object> snapshot() {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", id);
            map.put("conversationId", conversationId == null ? "" : conversationId);
            map.put("projectId", projectId == null ? "" : projectId);
            map.put("status", status);
            map.put("cancelled", cancelled());
            map.put("createdAt", createdAt.toString());
            if (finishedAt != null) map.put("finishedAt", finishedAt.toString());
            map.put("mutationRevision", mutationRevision());
            map.put("lastVerificationAttemptRevision", lastVerificationAttemptRevision());
            map.put("verificationRequiredRevision", verificationRequiredRevision());
            map.put("lastSuccessfulVerificationRevision", lastSuccessfulVerificationRevision());
            map.put("lastDiffRevision", lastDiffRevision());
            map.put("lastVerification", lastVerification);
            map.put("lastVerificationSuccessful", lastVerificationSuccessful());
            map.put("activeModel", activeModel());
            map.put("modelPool", modelPool());
            map.put("modelFailovers", modelFailovers());
            map.put("recoveryReplans", recoveryReplans());
            map.put("lastModelError", lastModelError());
            map.put("lastRecoveryAnalysis", lastRecoveryAnalysis());
            map.put("objective", objective());
            map.put("planValidationStatus", planValidationStatus());
            map.put("planValidationSummary", planValidationSummary());
            map.put("largeTaskMode", largeTaskMode());
            map.put("workItemBatchSize", workItemBatchSize());
            map.put("workItemSummary", workItemSummary());
            map.put("workItems", workItemsSnapshot(200));
            map.put("verificationFailures", List.copyOf(verificationFailureQueue));
            map.put("activityEvents", activitySnapshot());
            map.put("touchedPaths", touchedPaths());
            map.put("activePlanIndex", activePlanIndex());
            map.put("planLocked", planLocked());
            map.put("planStepToolActivity", planStepToolActivity());
            map.put("progressPercent", progressPercent());
            map.put("progressPhase", progressPhase());
            map.put("progressDetail", progressDetail());
            map.put("lastActivityAt", lastActivityAt().toString());
            map.put("totalToolActions", totalToolActions());
            map.put("responsePersisted", responsePersisted());
            if (finished() && !finalAnswer().isBlank()) map.put("finalAnswer", finalAnswer());
            if (!assistantMessageId().isBlank()) map.put("assistantMessageId", assistantMessageId());
            Map<String,Object> usage = new LinkedHashMap<>();
            usage.put("modelCalls", modelCalls.get());
            usage.put("providerInputTokens", providerInputTokens.get());
            usage.put("providerOutputTokens", providerOutputTokens.get());
            usage.put("providerTotalTokens", providerTotalTokens.get());
            usage.put("cachedInputTokens", cachedInputTokens.get());
            usage.put("cacheWriteTokens", cacheWriteTokens.get());
            usage.put("estimatedInputTokens", estimatedInputTokens.get());
            usage.put("currentContextTokens", currentContextTokens.get());
            usage.put("contextWindowTokens", contextWindowTokens.get());
            usage.put("compactions", compactions.get());
            usage.put("estimatedTokensSavedByCompaction", estimatedTokensSavedByCompaction.get());
            usage.put("prunedObservations", prunedObservations.get());
            usage.put("estimatedTokensSavedByPruning", estimatedTokensSavedByPruning.get());
            long providerInput = providerInputTokens.get();
            usage.put("cacheHitPercent", providerInput <= 0 ? 0.0 : Math.min(100.0, (cachedInputTokens.get() * 100.0) / providerInput));
            usage.put("repeatedCallsPrevented", repeatedCallsPrevented.get());
            usage.put("toolActions", totalToolActions.get());
            usage.put("lastCheckpointReason", lastCheckpointReason);
            usage.put("loopBlockReason", loopBlockReason);
            map.put("tokenUsage", usage);
            map.put("approvedToolsForRun", List.copyOf(approvedToolsForRun));
            synchronized (this) {
                map.put("plan", planSnapshot());
            }
            return map;
        }

        private static String normalizePlanText(String raw) {
            if (raw == null) return "";
            String value = raw.strip();
            if (value.isBlank()) return "";
            value = value.replaceFirst("^\\d{1,2}[.)]\\s*", "");
            value = value.replaceFirst("^\\[[ xX✓✔]\\]\\s*", "");
            value = value.replaceFirst("^[\\-*•‣▪▫◦]+\\s*", "");
            value = value.replaceFirst("^(?:✅|☑️?|✔️?|✓|🔲|⬜|🟩|🟢|🔹|🔸|➡️?|→|➜|➤|▶️?|⏳|🛠️?|⚙️?)\\s*", "").strip();
            if (!value.matches("(?s).*[\\p{L}\\p{N}].*") || value.replaceAll("[^\\p{L}\\p{N}]", "").length() < 3) return "";
            return value.length() <= 1_400 ? value : value.substring(0, 1_400);
        }

        private static String normalizePlanStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "blocked", "skipped" -> status;
                default -> throw new IllegalArgumentException("Unsupported plan status: " + value);
            };
        }

        private static String encodeActivity(ActivityEvent event) {
            String raw = String.join("\u001f", event.at().toString(), Integer.toString(event.step()), safeActivity(event.tool()),
                    safeActivity(event.status()), safeActivity(event.detail()), safeActivity(event.args()),
                    safeActivity(event.approvalId()), safeActivity(event.output()));
            return Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        }

        private static ActivityEvent decodeActivity(String encoded) {
            if (encoded == null || encoded.isBlank()) return null;
            try {
                String raw = new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);
                String[] parts = raw.split("\u001f", -1);
                if (parts.length < 6) return null;
                // Backward compatible with the original 6-field encoding and the first durable-history 7-field encoding.
                if (parts.length == 6) {
                    return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                            parts[2], parts[3], parts[4], "", "", parts[5]);
                }
                if (parts.length == 7) {
                    return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                            parts[2], parts[3], parts[4], parts[5], "", parts[6]);
                }
                return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                        parts[2], parts[3], parts[4], parts[5], parts[6], parts[7]);
            } catch (Exception ignored) { return null; }
        }

        private static String safeActivity(String value) { return value == null ? "" : value.replace("\u001f", " "); }

        private record ActivityEvent(Instant at, int step, String tool, String status, String detail, String args, String approvalId, String output) { }

        private static void terminate(Process process) {
            if (process == null || !process.isAlive()) return;
            try {
                process.descendants().forEach(handle -> {
                    try { handle.destroy(); } catch (Exception ignored) { }
                });
                process.destroy();
                if (process.isAlive()) {
                    process.descendants().forEach(handle -> {
                        try { handle.destroyForcibly(); } catch (Exception ignored) { }
                    });
                    process.destroyForcibly();
                }
            } catch (Exception ignored) { }
        }
    }

    public record PlanItem(int index, String text, String status, String note) {}
    public record WorkItem(String id, String title, String status, String note, int attempts) {}
}
