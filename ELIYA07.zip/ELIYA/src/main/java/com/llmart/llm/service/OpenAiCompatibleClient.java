package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class OpenAiCompatibleClient {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final Set<String> nativeToolsUnsupported = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<String> jsonFormatUnsupported = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public OpenAiCompatibleClient(HttpClient httpClient, ObjectMapper objectMapper) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
    }

    public String stream(String apiKey, ChatSettings settings, List<Map<String, Object>> messages,
                         Consumer<String> onToken) throws Exception {
        return stream(apiKey, settings, messages, onToken, () -> false);
    }

    /**
     * Streams an OpenAI-compatible chat completion while tolerating the common SSE variations used by gateways:
     * event/id/comment lines, multi-line data payloads, keep-alives and plain JSON lines. Cancellation is explicit
     * (for the Chat Stop button) and is intentionally independent from the browser/SSE transport connection.
     */
    public String stream(String apiKey, ChatSettings settings, List<Map<String, Object>> messages,
                         Consumer<String> onToken, BooleanSupplier cancelled) throws Exception {
        validate(settings);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", settings.chatModelOrPrimary());
        body.put("messages", messages);
        body.put("temperature", settings.safeTemperature());
        if (settings.safeMaxTokens() > 0) body.put("max_tokens", settings.safeMaxTokens());
        body.put("stream", true);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(chatCompletionsUrl(settings.baseUrl())))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "text/event-stream, application/json")
                .timeout(Duration.ofMinutes(4))
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        HttpResponse<Stream<String>> response = httpClient.send(request, HttpResponse.BodyHandlers.ofLines());
        StringBuilder complete = new StringBuilder();
        List<String> errorLines = new ArrayList<>();

        try (Stream<String> lines = response.body()) {
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                lines.limit(30).forEach(errorLines::add);
                throw new IllegalStateException("LLM HTTP " + response.statusCode() + ": " + String.join(" ", errorLines));
            }

            Iterator<String> iterator = lines.iterator();
            List<String> dataLines = new ArrayList<>();
            String eventName = "message";
            while (iterator.hasNext()) {
                if (cancelled != null && cancelled.getAsBoolean()) {
                    throw new AgentCancelledException("Chat generation was stopped by the user");
                }
                String line = iterator.next();
                if (line == null) continue;

                // Blank line dispatches one SSE event. Gateways sometimes split a JSON payload across data: lines.
                if (line.isBlank()) {
                    if (dispatchStreamEvent(eventName, dataLines, complete, onToken)) break;
                    dataLines.clear();
                    eventName = "message";
                    continue;
                }
                if (line.startsWith(":")) continue; // keep-alive/comment
                if (line.startsWith("event:")) {
                    eventName = line.substring(6).trim();
                    continue;
                }
                if (line.startsWith("id:") || line.startsWith("retry:")) continue;
                if (line.startsWith("data:")) {
                    String value = line.substring(5);
                    if (value.startsWith(" ")) value = value.substring(1); // exactly one SSE separator space
                    dataLines.add(value);
                    continue;
                }

                // Some compatible gateways send newline-delimited JSON even when stream=true. Treat each raw
                // JSON line as its own event instead of waiting for an SSE blank-line delimiter.
                if (dataLines.isEmpty()) {
                    dataLines.add(line.trim());
                    if (dispatchStreamEvent(eventName, dataLines, complete, onToken)) break;
                    dataLines.clear();
                    eventName = "message";
                }
            }
            if (!dataLines.isEmpty()) dispatchStreamEvent(eventName, dataLines, complete, onToken);
        }
        return complete.toString();
    }

    private boolean dispatchStreamEvent(String eventName, List<String> dataLines, StringBuilder complete,
                                        Consumer<String> onToken) throws Exception {
        if (dataLines == null || dataLines.isEmpty()) return false;
        String data = String.join("\n", dataLines).trim();
        if (data.isEmpty()) return false;
        if ("[DONE]".equals(data)) return true;

        JsonNode json;
        try { json = objectMapper.readTree(data); }
        catch (Exception ignored) { return false; }

        JsonNode error = json.path("error");
        if ("error".equalsIgnoreCase(eventName) || (error.isObject() && !error.isEmpty())) {
            String message = error.path("message").asText("");
            if (message.isBlank()) message = json.path("message").asText(data);
            throw new IllegalStateException("LLM stream error: " + clipError(message));
        }

        JsonNode choices = json.path("choices");
        if (!choices.isArray() || choices.isEmpty()) return false;
        JsonNode choice = choices.get(0);
        JsonNode content = choice.path("delta").path("content");
        if (content.isMissingNode() || content.isNull()) content = choice.path("message").path("content");

        if (content.isTextual()) append(content.asText(), complete, onToken);
        else if (content.isArray()) {
            for (JsonNode item : content) {
                String token = item.path("text").asText("");
                if (!token.isEmpty()) append(token, complete, onToken);
            }
        }
        return false;
    }


    /** OpenAI-compatible embeddings request used by hybrid workspace retrieval. */
    public List<double[]> embed(String apiKey, String baseUrl, String model, List<String> inputs,
                                BooleanSupplier cancelled) throws Exception {
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Embedding model is required");
        if (inputs == null || inputs.isEmpty()) return List.of();

        Map<String,Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("input", inputs);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(embeddingsUrl(baseUrl)))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .timeout(Duration.ofMinutes(4))
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        HttpResponse<String> response = awaitResponse(
                httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString()), cancelled);
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("Embedding HTTP " + response.statusCode() + ": " + clipError(response.body()));
        }
        JsonNode data = objectMapper.readTree(response.body()).path("data");
        if (!data.isArray() || data.isEmpty()) throw new IllegalStateException("Embedding provider returned no vectors");
        List<Map.Entry<Integer,double[]>> indexed = new ArrayList<>();
        int fallbackIndex = 0;
        for (JsonNode item : data) {
            JsonNode vector = item.path("embedding");
            if (!vector.isArray() || vector.isEmpty()) continue;
            double[] values = new double[vector.size()];
            for (int i = 0; i < vector.size(); i++) values[i] = vector.get(i).asDouble(0.0);
            indexed.add(Map.entry(item.path("index").asInt(fallbackIndex++), values));
        }
        indexed.sort(Map.Entry.comparingByKey());
        if (indexed.isEmpty()) throw new IllegalStateException("Embedding provider returned no usable vectors");
        return indexed.stream().map(Map.Entry::getValue).toList();
    }

    public String complete(String apiKey, String baseUrl, String model, int maxTokens,
                           List<Map<String, Object>> messages) throws Exception {
        return complete(apiKey, baseUrl, model, maxTokens, messages, () -> false);
    }

    public String complete(String apiKey, String baseUrl, String model, int maxTokens,
                           List<Map<String, Object>> messages, BooleanSupplier cancelled) throws Exception {
        CompletionResponse response = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                null, false, false, cancelled);
        return response.content();
    }

    /** Plain non-streaming completion that also exposes provider usage. Used by context compaction so the
     * summarization call is visible in the run token telemetry instead of becoming hidden spend. */
    public AgentCompletion completeTextWithUsage(String apiKey, String baseUrl, String model, int maxTokens,
                                                 List<Map<String, Object>> messages,
                                                 BooleanSupplier cancelled) throws Exception {
        CompletionResponse response = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                null, false, false, cancelled);
        return new AgentCompletion(response.content(), List.of(), false, false, response.finishReason(), response.usage());
    }

    /**
     * Agent completion with automatic compatibility fallback:
     * 1) OpenAI-compatible native function/tool calling.
     * 2) JSON response_format when the provider/model rejects native tools.
     * 3) Plain completion when response_format is also unsupported.
     */
    public AgentCompletion completeAgent(String apiKey, String baseUrl, String model, int maxTokens,
                                         List<Map<String, Object>> messages,
                                         List<Map<String, Object>> tools,
                                         BooleanSupplier cancelled) throws Exception {
        return completeAgent(apiKey, baseUrl, model, maxTokens, messages, tools, false, cancelled);
    }

    /**
     * Agent completion. When requireTool is true, OpenAI-compatible providers receive tool_choice=required.
     * This is used only as a one-turn recovery when a capable model answers with prose before doing any
     * workspace work; normal turns always use tool_choice=auto so the model can naturally finish.
     */
    public AgentCompletion completeAgent(String apiKey, String baseUrl, String model, int maxTokens,
                                         List<Map<String, Object>> messages,
                                         List<Map<String, Object>> tools,
                                         boolean requireTool,
                                         BooleanSupplier cancelled) throws Exception {
        String capabilityKey = capabilityKey(baseUrl, model);
        if (!nativeToolsUnsupported.contains(capabilityKey)) {
            try {
                CompletionResponse nativeResponse = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                        tools, false, requireTool, cancelled);
                return new AgentCompletion(nativeResponse.content(), nativeResponse.toolCalls(), true, false,
                        nativeResponse.finishReason(), nativeResponse.usage());
            } catch (NativeToolsUnsupportedException unsupported) {
                nativeToolsUnsupported.add(capabilityKey);
            }
        }

        if (!jsonFormatUnsupported.contains(capabilityKey)) {
            try {
                CompletionResponse jsonResponse = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                        null, true, false, cancelled);
                return new AgentCompletion(jsonResponse.content(), List.of(), false, true,
                        jsonResponse.finishReason(), jsonResponse.usage());
            } catch (JsonResponseFormatUnsupportedException jsonUnsupported) {
                jsonFormatUnsupported.add(capabilityKey);
            }
        }

        CompletionResponse plain = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                null, false, false, cancelled);
        return new AgentCompletion(plain.content(), List.of(), false, false, plain.finishReason(), plain.usage());
    }

    public AgentCompletion repairAgentEnvelope(String apiKey, String baseUrl, String model, int maxTokens,
                                                List<Map<String, Object>> messages,
                                                BooleanSupplier cancelled) throws Exception {
        try {
            CompletionResponse response = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                    null, true, false, cancelled);
            return new AgentCompletion(response.content(), List.of(), false, true, response.finishReason(), response.usage());
        } catch (JsonResponseFormatUnsupportedException unsupported) {
            CompletionResponse plain = requestCompletion(apiKey, baseUrl, model, maxTokens, messages,
                    null, false, false, cancelled);
            return new AgentCompletion(plain.content(), List.of(), false, false, plain.finishReason(), plain.usage());
        }
    }

    private CompletionResponse requestCompletion(String apiKey, String baseUrl, String model, int maxTokens,
                                                 List<Map<String, Object>> messages,
                                                 List<Map<String, Object>> tools,
                                                 boolean jsonResponse,
                                                 boolean requireTool,
                                                 BooleanSupplier cancelled) throws Exception {
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Model name is required");

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("messages", messages);
        // Agent/role calls intentionally use the provider/model default sampling policy.
        // Forcing one temperature across reasoning/coding models can degrade quality or be rejected by some OpenAI-compatible endpoints.
        if (maxTokens > 0) body.put("max_tokens", maxTokens);
        body.put("stream", false);
        if (tools != null && !tools.isEmpty()) {
            body.put("tools", tools);
            body.put("tool_choice", requireTool ? "required" : "auto");
        }
        if (jsonResponse) body.put("response_format", Map.of("type", "json_object"));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(chatCompletionsUrl(baseUrl)))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .timeout(Duration.ofMinutes(4))
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        CompletableFuture<HttpResponse<String>> future = httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());
        HttpResponse<String> response = awaitResponse(future, cancelled);

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            String error = response.body() == null ? "" : response.body();
            int status = response.statusCode();
            // Context overflows are commonly returned as HTTP 400/422. Detect them before the generic
            // tool-schema compatibility fallback; otherwise one oversized request could incorrectly cache the model
            // as "native tools unsupported" and trigger two additional doomed compatibility requests.
            if (looksLikeContextLimitError(error)) {
                throw new IllegalStateException("LLM HTTP " + status + ": " + clipError(error));
            }
            if (tools != null && !tools.isEmpty() && indicatesUnsupportedNativeTools(status, error)) {
                // Cache a capability downgrade only when the provider explicitly says tools/function calling are unsupported.
                // Generic 400/404/422 validation errors must surface normally; otherwise one malformed request could
                // silently downgrade every later turn for this model until the JVM restarts.
                throw new NativeToolsUnsupportedException("Native tool capability is unsupported: " + clipError(error));
            }
            if (jsonResponse && indicatesUnsupportedJsonFormat(status, error)) {
                throw new JsonResponseFormatUnsupportedException("JSON response_format capability is unsupported: " + clipError(error));
            }
            throw new IllegalStateException("LLM HTTP " + status + ": " + clipError(error));
        }

        JsonNode json = objectMapper.readTree(response.body());
        JsonNode choices = json.path("choices");
        if (!choices.isArray() || choices.isEmpty()) throw new IllegalStateException("LLM returned no choices");
        JsonNode choice = choices.get(0);
        JsonNode message = choice.path("message");
        String content = extractText(message.path("content"));
        String finishReason = choice.path("finish_reason").asText("");
        List<AgentToolCall> toolCalls = parseToolCalls(message.path("tool_calls"));
        // Some OpenAI-compatible/local providers still emit the pre-tools `function_call` shape.
        // Accept it as a single native action instead of incorrectly treating the response as prose.
        if (toolCalls.isEmpty()) {
            AgentToolCall legacy = parseLegacyFunctionCall(message.path("function_call"));
            if (legacy != null) toolCalls = List.of(legacy);
        }
        Usage usage = parseUsage(json.path("usage"));
        return new CompletionResponse(content, toolCalls, finishReason, usage);
    }

    private HttpResponse<String> awaitResponse(CompletableFuture<HttpResponse<String>> future,
                                               BooleanSupplier cancelled) throws Exception {
        while (true) {
            if (cancelled != null && cancelled.getAsBoolean()) {
                future.cancel(true);
                throw new AgentCancelledException("Agent run was cancelled during the model request");
            }
            try {
                return future.get(250, TimeUnit.MILLISECONDS);
            } catch (TimeoutException ignored) {
                // Poll cancellation while the provider request is in flight.
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof Exception exception) throw exception;
                throw e;
            }
        }
    }

    private AgentToolCall parseLegacyFunctionCall(JsonNode function) {
        if (function == null || !function.isObject()) return null;
        String name = function.path("name").asText("").trim();
        if (name.isBlank()) return null;
        JsonNode argsNode = function.path("arguments");
        JsonNode args;
        if (argsNode.isObject()) args = argsNode;
        else {
            String raw = argsNode.asText("").trim();
            try { args = raw.isBlank() ? objectMapper.createObjectNode() : objectMapper.readTree(raw); }
            catch (Exception ignored) { args = objectMapper.createObjectNode(); }
        }
        if (!args.isObject()) args = objectMapper.createObjectNode();
        return new AgentToolCall("call_" + UUID.randomUUID(), name, args);
    }

    private List<AgentToolCall> parseToolCalls(JsonNode node) {
        if (!node.isArray() || node.isEmpty()) return List.of();
        List<AgentToolCall> result = new ArrayList<>();
        for (JsonNode call : node) {
            JsonNode function = call.path("function");
            String name = function.path("name").asText("").trim();
            if (name.isBlank()) continue;
            String id = call.path("id").asText("").trim();
            if (id.isBlank()) id = "call_" + UUID.randomUUID();
            JsonNode argsNode = function.path("arguments");
            JsonNode args;
            if (argsNode.isObject()) args = argsNode;
            else {
                String raw = argsNode.asText("").trim();
                try { args = raw.isBlank() ? objectMapper.createObjectNode() : objectMapper.readTree(raw); }
                catch (Exception ignored) { args = objectMapper.createObjectNode(); }
            }
            if (!args.isObject()) args = objectMapper.createObjectNode();
            result.add(new AgentToolCall(id, name, args));
        }
        return List.copyOf(result);
    }

    private String extractText(JsonNode content) {
        if (content == null || content.isMissingNode() || content.isNull()) return "";
        if (content.isTextual()) return content.asText();
        if (content.isArray()) {
            StringBuilder out = new StringBuilder();
            for (JsonNode item : content) {
                String text = item.path("text").asText("");
                if (!text.isBlank()) {
                    if (!out.isEmpty()) out.append('\n');
                    out.append(text);
                }
            }
            return out.toString();
        }
        return content.asText("");
    }


    private Usage parseUsage(JsonNode usage) {
        if (usage == null || !usage.isObject()) return Usage.ZERO;
        long input = firstLong(usage, "prompt_tokens", "input_tokens");
        long output = firstLong(usage, "completion_tokens", "output_tokens");
        long total = firstLong(usage, "total_tokens");
        if (total <= 0 && (input > 0 || output > 0)) total = input + output;
        long cached = firstLong(usage, "cache_read_input_tokens", "cached_input_tokens");
        JsonNode promptDetails = usage.path("prompt_tokens_details");
        if (promptDetails.isObject()) cached = Math.max(cached, firstLong(promptDetails, "cached_tokens"));
        JsonNode inputDetails = usage.path("input_tokens_details");
        if (inputDetails.isObject()) cached = Math.max(cached, firstLong(inputDetails, "cached_tokens", "cache_read_tokens"));
        long cacheWrite = firstLong(usage, "cache_creation_input_tokens", "cache_write_input_tokens");
        return new Usage(Math.max(0, input), Math.max(0, output), Math.max(0, total), Math.max(0, cached),
                Math.max(0, cacheWrite), true);
    }

    private long firstLong(JsonNode node, String... fields) {
        if (node == null) return 0;
        for (String field : fields) {
            JsonNode value = node.path(field);
            if (value.isNumber()) return value.asLong(0);
            if (value.isTextual()) {
                try { return Long.parseLong(value.asText().trim()); } catch (Exception ignored) { }
            }
        }
        return 0;
    }


    static boolean indicatesUnsupportedNativeTools(int status, String error) {
        if (status != 400 && status != 404 && status != 422) return false;
        String text = error == null ? "" : error.toLowerCase(Locale.ROOT);
        boolean toolTerm = text.contains("tool") || text.contains("function call") || text.contains("function_call") || text.contains("functions");
        boolean unsupported = text.contains("not support") || text.contains("unsupported") || text.contains("unknown field") ||
                text.contains("unknown parameter") || text.contains("unrecognized") || text.contains("not allowed") ||
                text.contains("not available") || text.contains("does not implement");
        return toolTerm && unsupported;
    }

    static boolean indicatesUnsupportedJsonFormat(int status, String error) {
        if (status != 400 && status != 404 && status != 422) return false;
        String text = error == null ? "" : error.toLowerCase(Locale.ROOT);
        boolean formatTerm = text.contains("response_format") || text.contains("json_object") || text.contains("json mode");
        boolean unsupported = text.contains("not support") || text.contains("unsupported") || text.contains("unknown field") ||
                text.contains("unknown parameter") || text.contains("unrecognized") || text.contains("not available");
        return formatTerm && unsupported;
    }

    private boolean looksLikeContextLimitError(String error) {
        String text = error == null ? "" : error.toLowerCase(Locale.ROOT);
        return text.contains("context length") || text.contains("context window") || text.contains("maximum context") ||
                text.contains("too many tokens") || text.contains("token limit") || text.contains("prompt is too long") ||
                text.contains("input too long") || text.contains("maximum number of tokens") ||
                text.contains("context_length_exceeded");
    }

    private String capabilityKey(String baseUrl, String model) {
        return (baseUrl == null ? "" : baseUrl.trim().replaceAll("/+$", "")) + "|" + (model == null ? "" : model.trim());
    }

    private String clipError(String error) {
        if (error == null) return "";
        return error.length() > 1800 ? error.substring(0, 1800) : error;
    }

    private void append(String token, StringBuilder complete, Consumer<String> onToken) {
        complete.append(token);
        onToken.accept(token);
    }

    private void validate(ChatSettings s) {
        if (s.baseUrl() == null || s.baseUrl().isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (s.chatModelOrPrimary().isBlank()) throw new IllegalArgumentException("Chat model name is required");
    }

    private String chatCompletionsUrl(String baseUrl) {
        String base = baseUrl.trim().replaceAll("/+$", "");
        if (base.endsWith("/chat/completions")) return base;
        return base + "/chat/completions";
    }

    private String embeddingsUrl(String baseUrl) {
        String base = baseUrl.trim().replaceAll("/+$", "");
        if (base.endsWith("/chat/completions")) base = base.substring(0, base.length() - "/chat/completions".length());
        if (base.endsWith("/embeddings")) return base;
        return base + "/embeddings";
    }

    public record AgentToolCall(String id, String name, JsonNode arguments) {}
    public record AgentCompletion(String content, List<AgentToolCall> toolCalls, boolean nativeToolsUsed,
                                  boolean jsonModeUsed, String finishReason, Usage usage) {
        public AgentCompletion {
            content = content == null ? "" : content;
            toolCalls = toolCalls == null ? List.of() : List.copyOf(toolCalls);
            finishReason = finishReason == null ? "" : finishReason;
            usage = usage == null ? Usage.ZERO : usage;
        }
        public boolean hasToolCall() { return !toolCalls.isEmpty(); }
    }

    public record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens,
                        long cacheWriteTokens, boolean providerReported) {
        public static final Usage ZERO = new Usage(0, 0, 0, 0, 0, false);
    }

    private record CompletionResponse(String content, List<AgentToolCall> toolCalls, String finishReason, Usage usage) {}

    public static class NativeToolsUnsupportedException extends Exception {
        public NativeToolsUnsupportedException(String message) { super(message); }
    }

    public static class JsonResponseFormatUnsupportedException extends Exception {
        public JsonResponseFormatUnsupportedException(String message) { super(message); }
    }
}
