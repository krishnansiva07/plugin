# ELIYA32 Chat MCP routing validation

## Implemented
- Chat normalizes common MCP tool aliases such as `mcp|server|tool` back to the exact advertised `mcp__server__tool` function.
- Alias resolution is case-insensitive and can resolve a unique native MCP tool name, but refuses ambiguous native names shared by multiple servers.
- Chat still exposes only a compact ranked MCP tool list initially. If the model requests a valid safe tool from the full discovered catalog, ELIYA adds only that resolved tool on demand instead of failing the request.
- Jira, Confluence, GitLab and SonarQube receive source-specific ranking boosts so their relevant tools are more likely to be in the initial compact set.
- Compact gateway tools such as `discover` and `executeRead` are treated as read capabilities; `executeWrite` and other mutating operations remain action-gated.
- Confluence search results are not treated as full page evidence when the request asks for details/content; Chat must continue to the content/read capability.
- MCP master switch behavior is unchanged: MCP disabled means no MCP discovery or calls.

## Offline validation completed
- Parsed all 121 Java main/test source files with the JDK compiler parser: 0 syntax errors.
- Focused MCP alias/safety Java harness: 10 assertions passed.
- Front-end JavaScript test suite: 18 passed, 0 failed.
- `node --check` passed for app.js, markdown.js, confluence-composer.js and prompt-catalog.js.

## Maven limitation in this environment
The build runtime does not have Maven installed and outbound Maven Central access is unavailable, so a full dependency-resolved Maven compile/test could not be executed here. The added JUnit regression test is included at:
`src/test/java/com/llmart/llm/service/McpToolAliasResolutionTest.java`.

Run on the target machine:
`./mvnw -Pfull-tests clean test`
then
`./mvnw -DskipTests package`

## Manual regression tests
1. Chat + MCP ON: `can you get maternity leave details from confluence`
   - Expect Confluence search followed by content/read retrieval and a grounded answer.
   - Must not show `MCP TOOL NOT AVAILABLE` for `mcp|...|searchconfluencepages` / `getconfluencecontent` aliases.
2. Agent + MCP ON: run the same query and compare the retrieved answer/source coverage.
3. Jira: ask for a known issue/status/details and verify retrieval occurs without tool-name errors.
4. GitLab: ask for a known project/MR/file read and verify the appropriate read tool is selected.
5. SonarQube: ask for a known project's quality gate/issues and verify retrieval.
6. MCP OFF: repeat any external query. ELIYA must report MCP disabled and must not discover or invoke MCP tools.
