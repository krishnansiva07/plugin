# Agentic Actions

The framework now uses LangGraph4j for bounded agentic orchestration of normal planned browser actions.

## Runtime graph

```text
START
  |
  v
PLAN
  |
  v
EXECUTE + EXISTING VALIDATION
  | success                      | failure
  v                              v
SUCCESS                         HEAL / RE-PLAN
  |                              |
  v                              +----> EXECUTE + VALIDATION
 END                                      |
                                          +-- success --> SUCCESS
                                          +-- exhausted -> FAILURE -> END
```

## What LangGraph owns

- State transitions between planning, execution, validation outcome, healing and termination.
- Bounded retry/turn decisions.
- A per-step graph history written into the existing healing history/report data.

## What stays in the existing framework

- `LlmClient` and the existing OpenAI-compatible `/chat/completions` configuration.
- Vibium MCP transport and tool execution.
- Browser/session lifecycle, shared-browser mode and separate-browser parallel mode.
- Cookie replacement/addition.
- DOM/page observation and candidate ranking.
- Strict evidence validation and fake-pass prevention.
- Deterministic XPath, CSS, visible-text, focused-input and enterprise-dropdown paths.
- Screenshots and report generation.

## Required dependency

Maven resolves only the LangGraph4j core dependency added in `pom.xml`:

```xml
<dependency>
    <groupId>org.bsc.langgraph4j</groupId>
    <artifactId>langgraph4j-core</artifactId>
    <version>1.8.24</version>
</dependency>
```

No Python LangGraph service, LangChain4j, Spring AI, vector database, Redis/Postgres checkpoint saver, LangGraph Studio, or separate agent server is required.

## Run controls

- `enableAgenticActions=true` — enables the LangGraph path.
- `enableSelfHealing=true` — allows the HEAL node to call the existing LLM healing logic.
- `retryCount` — maximum LLM healing attempts, additionally capped by `maxAgentTurns - 1`.
- `maxAgentTurns=3` — hard ceiling for bounded plan/recovery cycles.
- `healingConfidenceThreshold=0.75` — unchanged confidence gate for accepting an LLM healing plan.

The web UI exposes **Agentic actions (LangGraph)** and keeps the safety defaults enabled.


## Runtime state-serialization rule

LangGraph state contains only simple serializable coordination values (booleans, counters, error text and history).
The browser `Plan`/Jackson `JsonNode` payload is intentionally kept outside graph state in a per-run `AtomicReference`.
This prevents graph-state cloning/serialization failures and also avoids copying large DOM observations between graph nodes.
The holder is local to each `run(...)` invocation, so parallel scenarios do not share plan state.
