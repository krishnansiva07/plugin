package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.itps.vibium.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ReportService {
    private final ObjectMapper mapper;

    public ReportService() {
        mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    public void writeReports(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        List<String> failures = new ArrayList<>();

        attempt("consolidated HTML", failures, () -> writeSummaryHtml(status, runDir.resolve("report.html")));
        attempt("technical logs HTML", failures, () -> writeLogsHtml(status, runDir.resolve("logs.html")));
        attempt("Excel report", failures, () -> writeExcel(status, runDir.resolve("report.xlsx")));
        attempt("screenshots ZIP", failures, () -> zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip")));
        attempt("JSON report", failures, () -> mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("report.json").toFile(), status));

        if (!failures.isEmpty()) {
            Files.writeString(runDir.resolve("report-generation.log"), String.join(System.lineSeparator(), failures), StandardCharsets.UTF_8);
        }
        if (!Files.exists(runDir.resolve("report.html"))) {
            throw new IllegalStateException("Consolidated report could not be generated: " + String.join(" | ", failures));
        }
    }

    public void writeFallbackHtml(RunStatus status, Path runDir, Exception error) throws Exception {
        Files.createDirectories(runDir);
        String body = "<header><div class='brand'>ITPS VIBIUM Framework</div><h1>Execution report</h1></header>" +
                "<section class='panel message'><h2>Report generation problem</h2><p>Run: " + esc(status == null ? "" : status.getRunId()) + "</p><pre>" + esc(error == null ? "Unknown error" : error.toString()) + "</pre></section>";
        if (!Files.exists(runDir.resolve("report.html"))) {
            Files.writeString(runDir.resolve("report.html"), shell("Execution Report", body), StandardCharsets.UTF_8);
        }
        if (!Files.exists(runDir.resolve("logs.html"))) {
            Files.writeString(runDir.resolve("logs.html"), shell("Technical Logs", body), StandardCharsets.UTF_8);
        }
    }

    private void writeSummaryHtml(RunStatus s, Path file) throws Exception {
        StringBuilder rows = new StringBuilder();
        for (ScenarioResult r : s.getScenarios()) {
            String status = normalizedStatus(r.getStatus());
            rows.append("<tr data-status='").append(esc(status)).append("'><td>").append(esc(fmt(s.getStartedAt()))).append("</td><td>").append(esc(r.getId())).append("</td><td>")
                    .append(esc(r.getName())).append("</td><td><span class='pill ").append(status.startsWith("PASSED") ? "pass" : "fail")
                    .append("'>").append(status).append("</span></td><td>").append(formatDuration(r.getDurationMs())).append("</td><td><div class='summary-error' title='")
                    .append(escAttr(r.getErrorMessage())).append("'>").append(esc(shortText(r.getErrorMessage(), 220))).append("</div></td></tr>");
        }
        String body = header(s, "Execution report") +
                "<section class='filters'><input id='q' placeholder='Search results'><select id='statusFilter'><option value=''>All statuses</option><option>PASSED</option><option>PASSED_HEALED</option><option>FAILED</option></select><a class='btn' href='logs.html'>Technical logs</a></section>" +
                "<section class='panel'><table id='summary'><thead><tr><th>Execution date</th><th>Test ID</th><th>Test name</th><th>Status</th><th>Duration</th><th>Error</th></tr></thead><tbody>" + rows + "</tbody></table></section>" +
                "<section class='links'><a href='report.xlsx' download>Excel</a><a href='report.json' download>JSON</a><a href='screenshots.zip' download>Screenshots</a></section>" + filterScript("summary");
        Files.writeString(file, shell("ITPS VIBIUM Execution Report", body), StandardCharsets.UTF_8);
    }

    private void writeLogsHtml(RunStatus s, Path file) throws Exception {
        StringBuilder rows = new StringBuilder();
        for (ScenarioResult r : s.getScenarios()) {
            for (StepResult st : r.getSteps()) {
                String status = normalizedStatus(st.getStatus());
                rows.append("<tr data-status='").append(esc(status)).append("'><td>").append(esc(fmt(s.getStartedAt()))).append("</td><td>").append(esc(r.getId())).append("</td><td>").append(esc(r.getName())).append("</td><td>")
                        .append(st.getStepNo()).append("</td><td>").append(esc(st.getInstruction())).append("</td><td>").append(esc(st.getPlanSource())).append("</td><td>")
                        .append(esc(st.getToolName())).append("</td><td><pre>").append(esc(st.getToolArguments())).append("</pre></td><td><pre class='inventory'>")
                        .append(esc(st.getPageInventory())).append("</pre></td><td>").append(esc(st.getEvidence())).append("</td><td><pre>").append(esc(st.getHealingHistory())).append("</pre></td><td><span class='pill ")
                        .append(status.startsWith("PASSED") ? "pass" : "fail").append("'>").append(status).append("</span></td><td>")
                        .append(formatDuration(st.getDurationMs())).append("</td><td>").append(shot(st)).append("</td><td>").append(esc(st.getErrorMessage())).append("</td></tr>");
            }
        }
        String body = header(s, "Technical logs") +
                "<section class='filters'><input id='q' placeholder='Search logs'><select id='statusFilter'><option value=''>All statuses</option><option>PASSED</option><option>PASSED_HEALED</option><option>FAILED</option></select><a class='btn' href='report.html'>Execution report</a></section>" +
                "<section class='panel wide'><table id='logs'><thead><tr><th>Execution date</th><th>Test ID</th><th>Test name</th><th>#</th><th>Instruction</th><th>Plan</th><th>MCP tool</th><th>Arguments</th><th>Page inventory</th><th>Evidence</th><th>Healing</th><th>Status</th><th>Duration</th><th>Screenshot</th><th>Error</th></tr></thead><tbody>" + rows + "</tbody></table></section>" + filterScript("logs");
        Files.writeString(file, shell("ITPS VIBIUM Technical Logs", body), StandardCharsets.UTF_8);
    }

    private String header(RunStatus s, String title) {
        String status = shortRunStatus(s);
        return "<header><div class='brand'>ITPS VIBIUM Framework</div><h1>" + esc(title) + "</h1><p>" + esc(s.getRunId()) + " · " + status + " · " + fmt(s.getStartedAt()) + "</p></header>" +
                "<section class='kpis'><div><span>Total</span><b>" + s.getTotal() + "</b></div><div><span>Passed</span><b>" + s.getPassed() + "</b></div><div><span>Failed</span><b>" + s.getFailed() + "</b></div><div><span>Status</span><b>" + status + "</b></div></section>";
    }

    private String shell(String title, String body) {
        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>" + esc(title) + "</title><style>" + css() + "</style></head><body><main>" + body + "</main></body></html>";
    }

    private String css() {
        return ":root{--g:#007a53;--d:#004a34;--bg:#f4f7f5;--line:#dce7e2;--red:#b42318;--ok:#027a48}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Segoe UI,Arial;color:#14251f}main{padding:24px;max-width:1600px;margin:auto}header{background:linear-gradient(135deg,var(--d),var(--g));color:white;padding:22px 25px;border-radius:16px}.brand{font-size:11px;letter-spacing:.15em;text-transform:uppercase}h1{margin:6px 0 2px;font-size:25px}header p{margin:0;opacity:.86}.kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:11px;margin:16px 0}.kpis div,.panel,.filters,.links{background:white;border:1px solid var(--line);border-radius:13px;padding:13px}.kpis span{display:block;color:#65746f;font-size:11px;text-transform:uppercase}.kpis b{display:block;font-size:22px;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.filters{display:flex;gap:9px;align-items:center;margin-bottom:13px}.filters input{flex:1;padding:10px;border:1px solid var(--line);border-radius:8px}.filters select,.btn{padding:9px;border:1px solid var(--line);border-radius:8px;background:white}.btn,a{color:var(--g);font-weight:700;text-decoration:none}.panel{overflow:auto;padding:0}.wide{max-height:76vh}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{padding:9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:12px;overflow-wrap:anywhere}th{position:sticky;top:0;background:#f8fbfa;z-index:1;font-size:10px;text-transform:uppercase}#summary th:nth-child(1){width:14%}#summary th:nth-child(2){width:10%}#summary th:nth-child(3){width:23%}#summary th:nth-child(4){width:10%}#summary th:nth-child(5){width:10%}#summary th:nth-child(6){width:33%}.pill{display:inline-block;padding:4px 8px;border-radius:999px;font-size:10px;font-weight:800}.pass{background:#e7f8ef;color:var(--ok)}.fail{background:#fee4e2;color:var(--red)}.summary-error{color:var(--red);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}pre{white-space:pre-wrap;word-break:break-word;max-width:390px;max-height:170px;overflow:auto;margin:0;font:10px Consolas}.inventory{max-width:500px}.links{display:flex;gap:15px;margin-top:13px}.message{padding:20px}@media(max-width:800px){main{padding:12px}.kpis{grid-template-columns:1fr 1fr}.filters{flex-direction:column;align-items:stretch}table{min-width:900px}}";
    }

    private String filterScript(String tableId) {
        return "<script>const q=document.getElementById('q'),sf=document.getElementById('statusFilter');function f(){const x=q.value.toLowerCase(),s=sf.value;document.querySelectorAll('#" + tableId + " tbody tr').forEach(r=>{r.style.display=(!x||r.innerText.toLowerCase().includes(x))&&(!s||r.dataset.status===s)?'':'none'})}q.addEventListener('input',f);sf.addEventListener('change',f)</script>";
    }

    private String shot(StepResult st) {
        return st.getScreenshot() == null || st.getScreenshot().isBlank() ? "" : "<a href='screenshots/" + esc(st.getScreenshot()) + "' target='_blank'>View</a>";
    }

    private void writeExcel(RunStatus status, Path path) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet summary = wb.createSheet("Results");
            String[] headers = {"Execution Date", "Test ID", "Test Name", "Status", "Duration", "Error"};
            Row header = summary.createRow(0);
            for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);
            int rowNo = 1;
            for (ScenarioResult result : status.getScenarios()) {
                Row row = summary.createRow(rowNo++);
                row.createCell(0).setCellValue(fmt(status.getStartedAt()));
                row.createCell(1).setCellValue(result.getId());
                row.createCell(2).setCellValue(result.getName());
                row.createCell(3).setCellValue(normalizedStatus(result.getStatus()));
                row.createCell(4).setCellValue(formatDuration(result.getDurationMs()));
                row.createCell(5).setCellValue(nullSafe(result.getErrorMessage()));
            }

            Sheet logs = wb.createSheet("Technical Logs");
            String[] logHeaders = {"Execution Date", "Test ID", "Test Name", "Step", "Instruction", "Plan", "MCP Tool", "Arguments", "Page Inventory", "Evidence", "Healing", "Status", "Duration", "Screenshot", "Error"};
            Row logHeader = logs.createRow(0);
            for (int i = 0; i < logHeaders.length; i++) logHeader.createCell(i).setCellValue(logHeaders[i]);
            rowNo = 1;
            for (ScenarioResult result : status.getScenarios()) {
                for (StepResult step : result.getSteps()) {
                    Row row = logs.createRow(rowNo++);
                    row.createCell(0).setCellValue(fmt(status.getStartedAt()));
                    row.createCell(1).setCellValue(result.getId());
                    row.createCell(2).setCellValue(result.getName());
                    row.createCell(3).setCellValue(step.getStepNo());
                    row.createCell(4).setCellValue(nullSafe(step.getInstruction()));
                    row.createCell(5).setCellValue(nullSafe(step.getPlanSource()));
                    row.createCell(6).setCellValue(nullSafe(step.getToolName()));
                    row.createCell(7).setCellValue(excelSafe(step.getToolArguments()));
                    row.createCell(8).setCellValue(excelSafe(step.getPageInventory()));
                    row.createCell(9).setCellValue(excelSafe(step.getEvidence()));
                    row.createCell(10).setCellValue(excelSafe(step.getHealingHistory()));
                    row.createCell(11).setCellValue(normalizedStatus(step.getStatus()));
                    row.createCell(12).setCellValue(formatDuration(step.getDurationMs()));
                    row.createCell(13).setCellValue(nullSafe(step.getScreenshot()));
                    row.createCell(14).setCellValue(excelSafe(step.getErrorMessage()));
                }
            }
            for (int i = 0; i < 6; i++) summary.setColumnWidth(i, i == 2 || i == 5 ? 12000 : (i == 0 ? 6500 : 5000));
            for (int i = 0; i < 15; i++) logs.setColumnWidth(i, i == 8 ? 16000 : (i == 0 ? 6500 : 7000));
            try (OutputStream output = Files.newOutputStream(path)) { wb.write(output); }
        }
    }

    private void zipScreenshots(Path dir, Path zip) throws Exception {
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(zip))) {
            if (!Files.isDirectory(dir)) return;
            try (var paths = Files.walk(dir)) {
                for (Path path : paths.filter(Files::isRegularFile).toList()) {
                    output.putNextEntry(new ZipEntry(dir.relativize(path).toString().replace('\\', '/')));
                    Files.copy(path, output);
                    output.closeEntry();
                }
            }
        }
    }

    private void attempt(String name, List<String> failures, CheckedRunnable action) {
        try { action.run(); }
        catch (Exception e) { failures.add(name + ": " + e); }
    }

    private String shortRunStatus(RunStatus status) {
        if (status == null) return "UNKNOWN";
        if ("FAILED".equalsIgnoreCase(status.getStatus())
                || "COMPLETED_WITH_FAILURES".equalsIgnoreCase(status.getStatus())) return "FAILED";
        if (status.getFailed() > 0) return "FAILED";
        if (status.getTotal() > 0 && status.getPassed() == status.getTotal()) return "PASSED";
        return "COMPLETED";
    }

    private String normalizedStatus(String status) { if (status == null) return "FAILED"; if ("PASSED_HEALED".equalsIgnoreCase(status)) return "PASSED_HEALED"; return status.toUpperCase().startsWith("PASSED") ? "PASSED" : "FAILED"; }
    private String formatDuration(long millis) { return millis < 1000 ? millis + " ms" : String.format("%.1f s", millis / 1000.0); }
    private String shortText(String value, int limit) { String v = nullSafe(value).replaceAll("\\s+", " ").trim(); return v.length() <= limit ? v : v.substring(0, limit - 3) + "..."; }
    private String excelSafe(String value) { String v = nullSafe(value); return v.length() > 32000 ? v.substring(0, 32000) : v; }
    private String fmt(Instant instant) { return instant == null ? "" : DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss").withZone(ZoneId.systemDefault()).format(instant); }
    private String nullSafe(String value) { return value == null ? "" : value; }
    private String esc(String value) { return nullSafe(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;"); }
    private String escAttr(String value) { return esc(value).replace("`", "&#96;"); }

    @FunctionalInterface
    private interface CheckedRunnable { void run() throws Exception; }
}
