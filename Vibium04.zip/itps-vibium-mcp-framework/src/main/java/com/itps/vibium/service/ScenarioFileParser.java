package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.TestScenario;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

@Service
public class ScenarioFileParser {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<TestScenario> parse(MultipartFile file) throws Exception { return parse(file, List.of()); }

    public List<TestScenario> parse(MultipartFile file, String sheetName) throws Exception {
        return parse(file, blank(sheetName) ? List.of() : List.of(sheetName));
    }

    public List<TestScenario> parse(MultipartFile file, List<String> sheetNames) throws Exception {
        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("scenario.json").toLowerCase(Locale.ROOT);
        if (filename.endsWith(".xlsx") || filename.endsWith(".xls")) return parseExcel(file.getInputStream(), sheetNames);
        return parseJson(file.getBytes());
    }

    public List<String> sheetNames(MultipartFile file) throws Exception {
        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (!(filename.endsWith(".xlsx") || filename.endsWith(".xls"))) return List.of();
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            List<String> names = new ArrayList<>();
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) names.add(workbook.getSheetName(i));
            return names;
        }
    }

    private List<TestScenario> parseJson(byte[] bytes) throws Exception {
        JsonNode root = objectMapper.readTree(bytes);
        JsonNode arrayNode = root.isArray() ? root : root.path("scenarios");
        if (!arrayNode.isArray()) throw new IllegalArgumentException("JSON must be an array or an object with scenarios array");
        List<TestScenario> scenarios = objectMapper.convertValue(arrayNode, new TypeReference<List<TestScenario>>() {});
        normalize(scenarios);
        return scenarios;
    }

    private List<TestScenario> parseExcel(InputStream inputStream, List<String> requestedSheetNames) throws Exception {
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            List<String> selected = requestedSheetNames == null ? new ArrayList<>() : requestedSheetNames.stream()
                    .filter(name -> !blank(name)).map(String::trim).distinct().toList();
            if (selected.isEmpty()) selected = List.of(workbook.getSheetName(0));

            List<TestScenario> combined = new ArrayList<>();
            Set<String> usedIds = new LinkedHashSet<>();
            for (String sheetName : selected) {
                Sheet sheet = workbook.getSheet(sheetName);
                if (sheet == null) throw new IllegalArgumentException("Excel sheet not found: " + sheetName);
                List<TestScenario> sheetScenarios = parseSheet(sheet, sheetName);
                for (TestScenario scenario : sheetScenarios) {
                    String originalId = scenario.getId();
                    String uniqueId = originalId;
                    if (!usedIds.add(uniqueId)) {
                        uniqueId = sanitizeId(sheetName) + "-" + originalId;
                        int suffix = 2;
                        while (!usedIds.add(uniqueId)) uniqueId = sanitizeId(sheetName) + "-" + originalId + "-" + suffix++;
                        scenario.setId(uniqueId);
                    }
                    scenario.getData().put("sourceSheet", sheetName);
                    combined.add(scenario);
                }
            }
            normalize(combined);
            return combined;
        }
    }

    private List<TestScenario> parseSheet(Sheet sheet, String sheetName) throws Exception {
        Row headerRow = sheet.getRow(0);
        if (headerRow == null) throw new IllegalArgumentException("Excel first row must contain headers in sheet: " + sheetName);
        Map<String, Integer> headers = new LinkedHashMap<>();
        for (Cell cell : headerRow) {
            String header = cellToString(cell).trim();
            if (!header.isBlank()) headers.put(header.toLowerCase(Locale.ROOT), cell.getColumnIndex());
        }
        List<TestScenario> scenarios = new ArrayList<>();
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;
            String id = cell(row, headers, "id");
            String name = cell(row, headers, "name");
            String stepsRaw = cell(row, headers, "steps");
            String runValue = cell(row, headers, "run");
            if (headers.containsKey("run") && !isRunEnabled(runValue)) continue;
            if (blank(id) && blank(name) && blank(stepsRaw)) continue;
            TestScenario scenario = new TestScenario();
            scenario.setId(blank(id) ? "TC" + String.format("%03d", i) : id.trim());
            scenario.setName(blank(name) ? scenario.getId() : name.trim());
            scenario.setUrl(cell(row, headers, "url"));
            scenario.setExpected(cell(row, headers, "expected"));
            scenario.setSteps(splitSteps(stepsRaw));

            Map<String, Object> data = new LinkedHashMap<>();
            for (Map.Entry<String, Integer> h : headers.entrySet()) {
                String key = h.getKey();
                if (key.startsWith("data.")) data.put(key.substring("data.".length()), cellToString(row.getCell(h.getValue())));
            }
            String dataJson = firstNonBlank(cell(row, headers, "testdatajson"), cell(row, headers, "testdata"), cell(row, headers, "data"));
            if (!blank(dataJson)) {
                try { data.putAll(objectMapper.readValue(dataJson, new TypeReference<Map<String, Object>>() {})); }
                catch (Exception e) { data.put("raw", dataJson); }
            }
            scenario.setData(data);
            scenarios.add(scenario);
        }
        normalize(scenarios);
        return scenarios;
    }

    private String sanitizeId(String value) {
        String sanitized = value == null ? "SHEET" : value.trim().replaceAll("[^A-Za-z0-9_-]+", "-");
        return sanitized.isBlank() ? "SHEET" : sanitized;
    }

    private void normalize(List<TestScenario> scenarios) {
        int i = 1;
        for (TestScenario scenario : scenarios) {
            if (blank(scenario.getId())) scenario.setId("TC" + String.format("%03d", i));
            if (blank(scenario.getName())) scenario.setName(scenario.getId());
            if (scenario.getSteps() == null) scenario.setSteps(new ArrayList<>());
            if (scenario.getData() == null) scenario.setData(new LinkedHashMap<>());
            scenario.setSteps(scenario.getSteps().stream().map(this::replaceWindowsLineNoise).filter(s -> !blank(s)).toList());
            i++;
        }
    }

    private String replaceWindowsLineNoise(String s) { return s == null ? "" : s.trim(); }

    private List<String> splitSteps(String stepsRaw) {
        if (blank(stepsRaw)) return new ArrayList<>();
        return Arrays.stream(stepsRaw.split("\\r?\\n|\\|"))
                .map(String::trim).filter(s -> !s.isBlank()).toList();
    }

    private String cell(Row row, Map<String, Integer> headers, String header) {
        Integer index = headers.get(header.toLowerCase(Locale.ROOT));
        return index == null ? "" : cellToString(row.getCell(index));
    }

    private String cellToString(Cell cell) {
        if (cell == null) return "";
        return new DataFormatter().formatCellValue(cell);
    }

    private boolean isRunEnabled(String value) {
        if (blank(value)) return false;
        String v = value.trim().toLowerCase(Locale.ROOT);
        return Set.of("true","yes","y","1","run","execute","enabled").contains(v);
    }

    private boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private String firstNonBlank(String... values) {
        for (String v : values) if (!blank(v)) return v;
        return "";
    }
}
