# Run tests after generating the JAR

Follow these steps after `target/itps-vibium-mcp-framework-1.0.0.jar` has been generated.

## 1. Check prerequisites

Open a terminal in the project root and verify:

```bash
java -version
node --version
```

Java must be 17 or later. Node.js is used to install Vibium and by the localhost bridge. Maven is not required just to run an already-built JAR.

## 2. Provide Vibium

The configured portable location is `tools/vibium-portable`.

From the project root:

```bash
cd tools
mkdir vibium-portable
cd vibium-portable
npm init -y
npm install vibium@latest
cd ../..
```

Confirm the executable exists:

Windows:

```bat
dir tools\vibium-portable\node_modules\.bin\vibium.cmd
```

macOS/Linux:

```bash
ls -l tools/vibium-portable/node_modules/.bin/vibium
chmod +x tools/vibium-portable/node_modules/.bin/vibium
```

If Vibium is already installed globally, ensure `vibium` is on `PATH` or set `VIBIUM_MCP_COMMAND` before starting the framework. For shared-browser or recorder use, also edit `tools/local-mcp-bridge/local-mcp-config.json` if the bridge cannot resolve the command.

Confirm Vibium itself starts before continuing:

Windows:

```bat
tools\vibium-portable\node_modules\.bin\vibium.cmd --help
```

macOS/Linux:

```bash
tools/vibium-portable/node_modules/.bin/vibium --help
```

## 3. Start the local MCP bridge only when needed

The bridge is required for the default **one browser for all tests** mode and for the UI recorder. It is not used by **Separate browser for each test** or **Parallel execution**; those modes launch independent Vibium stdio processes directly.

For shared-browser mode or the recorder, keep this first terminal open for the entire run.

Windows:

```bat
start-local-mcp-windows.cmd
```

Optional readiness check in another Windows terminal:

```bat
tools\local-mcp-bridge\check-local-mcp-windows.cmd
```

macOS/Linux:

```bash
chmod +x start-local-mcp-mac.sh tools/local-mcp-bridge/start-local-mcp-mac.sh
./start-local-mcp-mac.sh
```

Expected output includes:

```text
Listening : 127.0.0.1:8765
Version   : vibium v...
Isolation : unique VIBIUM_SESSION per browser; 250 ms startup spacing
Status    : READY
Max users : 4 simultaneous browser sessions
```

The bridge serves the single shared Java MCP connection. Its `maxClients` setting does not control separate-browser or parallel execution.

For separate-browser or parallel mode, skip this step. Even if an older bridge is already listening on port 8765, the direct-process mode does not connect to it.

## 4. Start the framework JAR

Open a terminal in the project root. If the bridge is running, use a second terminal.

Windows:

```bat
start-framework-jar-windows.cmd
```

macOS/Linux:

```bash
chmod +x start-framework-jar-mac.sh
./start-framework-jar-mac.sh
```

Equivalent direct command:

```bash
java -jar target/itps-vibium-mcp-framework-1.0.0.jar --spring.config.additional-location=optional:file:./config/application-local.properties
```

Wait until Spring reports that the application started, then open:

```text
http://localhost:8090
```

## 5. Prepare the scenario file

Upload `.xlsx`, `.xls`, or `.json`.

For Excel:

1. Put headers in row 1.
2. Use `Id`, `Name`, `Url`, `Steps`, and optionally `Expected`, `Run`, `TestDataJson`, or `data.*` columns.
3. Put each step on its own line or separate steps with `|`.
4. If a `Run` column exists, mark rows with `true`, `yes`, `y`, `1`, `run`, `execute`, or `enabled`.
5. Select the worksheets to execute after upload.

For JSON, upload an array of scenario objects or an object with a `scenarios` array.

## 6. Choose the browser-session mode

### One browser for all tests — default

Leave **Separate browser for each test** and **Parallel execution** unchecked.

- Tests run sequentially.
- One browser remains open for the complete run.
- Login and cookie/session state continue into later tests.
- Optional cookie replacement runs once after the first successful scenario URL navigation.
- This mode connects to the localhost bridge on port 8765, so start the bridge first.

This is the correct choice when the session cookie has an extension or later tests depend on the same authenticated session.

### A fresh browser for every test

Check **Separate browser for each test**.

- Each scenario receives a clean MCP client and browser.
- Each scenario launches its own direct `vibium mcp` process; port 8765 and the bridge are not used.
- With **Parallel execution** unchecked, isolated browsers run one at a time.
- Optional cookie replacement and additional-cookie setup run separately in each test browser.

### Parallel tests

Check **Parallel execution**. The UI automatically enables **Separate browser for each test**.

Select two, three, or four parallel browsers. Each concurrently executing scenario is isolated; shared-browser parallel execution is intentionally rejected because it would race browser state and cookies.

For three selected tests with three parallel browsers, the expected behavior is three independent Vibium processes and three browser instances. The framework assigns each process a unique session/runtime directory and spaces launches by 300 ms. No worker competes for the bridge's single MCP client slot.

Start with two browsers and increase only if the machine has enough CPU and memory.

## 7. Configure the optional cookie replacement

Leave **Replace one session cookie after the home page opens** unchecked when no cookie change is required.

When it is required:

1. Check the option.
2. Enter the exact name of a cookie that exists after the scenario home URL loads.
3. Enter the new cookie value.
4. Do not add the cookie to the scenario steps; the framework performs the transaction automatically.

The runtime then performs this exact transaction:

1. Reads all existing cookies before removing anything, using `browser_storage_state` first and `browser_get_cookies` as a fallback.
2. Finds the existing cookie whose name exactly matches the UI name and selects the best domain/path match when duplicates exist.
3. Copies every existing attribute accepted by the active set-cookie schema.
4. Removes every cookie with one clear-all operation.
5. Restores only the matched cookie name with the value entered in the UI.
6. Refreshes the current page.
7. Reads cookies again and verifies the exact name/value pair.

Vibium 26.5.31 exposes name, value, domain, and path on `browser_set_cookie`, so those existing fields are injected. If a future or alternate MCP schema exposes expiry, `HttpOnly`, `Secure`, `SameSite`, or partition fields, the framework injects those too.

The value field is optional only in the sense that the entire cookie feature is optional. When the checkbox is enabled, both cookie name and replacement value are mandatory.

If the named cookie is not present at the home page, the cookie step fails before any cookie is removed. If the installed Vibium MCP build does not expose native cookie tools, disable this option or upgrade Vibium.

### Add one or more new cookies

Click **+ Add cookie** for each new cookie needed before the scenario steps continue. Enter both the name and value; empty rows must be removed. This feature is optional and can be used with or without replacement.

For additional cookies, the framework reads the existing cookies first, derives the current domain/path scope, adds the new name/value pairs without clearing existing cookies, refreshes once, and verifies every pair. A requested name that already exists is rejected before any cookie is added. Up to ten rows are supported, values are redacted from reports, and the replacement-cookie name cannot also be used as an additional-cookie name.

When both features are enabled, the replacement transaction runs first. The additional cookies are then added to the resulting cookie set.

## 8. Configure remaining execution options

- **Headless**: run without visible browser windows.
- **Allow self-signed/internal HTTPS certificates**: use only for authorized internal test systems.
- **Continue on failure**: keep evaluating independent scenarios and permitted later work.
- **Validate actions**: require observable evidence instead of trusting only a successful MCP response.
- **LLM self-healing**: retry eligible failed steps with a materially different plan.
- **Screenshot**: all passed steps, failures only, or none.
- **Timeout**: per-step action/verification allowance.
- **Failure healing attempts**: bounded retry count.

Natural-language steps that cannot be handled deterministically require the configured LLM endpoint and a valid token. Explicit XPath, CSS, and JSON MCP steps can use deterministic paths where supported.

## 9. Run and monitor

Click **Run tests**.

The UI polls the run status and shows total, passed, failed, duration, and error details. In isolated parallel mode, a browser startup failure is attached only to its scenario; other tests continue.

Keep the framework terminal open until the run finishes. In shared-browser mode, keep the bridge terminal open too.

## 10. Download results

Use the result buttons for:

- Execution report (`report.html`)
- Technical logs (`logs.html`)
- Excel results (`report.xlsx`)
- JSON results (`report.json`)
- Screenshots (`screenshots.zip`)

Select failed tests and click **Rerun selected** to reuse the same execution configuration while the framework process is still running.

Artifacts are also stored under:

```text
target/itps-vibium-runs/<RUN-ID>/
```

## Troubleshooting

### The page opens but tests do not start

- In shared-browser mode, confirm the bridge terminal still says it is ready and port `8765` matches both configuration files.
- In separate/parallel mode, confirm the portable Vibium executable exists; the bridge is not involved.
- Check the run's `mcp-process.log` and `mcp-transcript.json`.

### `ITPS_BRIDGE_BUSY`

- This message is relevant only to shared-browser mode or the recorder.
- Separate/parallel mode must not show this message because it does not connect to the bridge. If it appears there, an older JAR or cached UI is still running.
- Stop the old Java process, replace the previously extracted source folder, run `mvn clean package`, start the newly generated JAR, and force-refresh the browser with `Ctrl+F5`.
- For an actual shared-mode conflict, stop the previous bridge client/framework run and restart the bridge.

### Parallel browser initialization fails

- Install or update the portable runtime with `npm install vibium@latest`.
- Run the portable executable's `--help` command from the project root.
- Confirm **Separate browser for each test** is checked; the UI does this automatically when parallel is enabled.
- Rebuild with `mvn clean package` and make sure only the newly generated JAR is running.
- Read `target/itps-vibium-runs/<RUN-ID>/mcp-sessions/<TEST>/mcp-process.log` and `mcp-transcript.json`. Every test has its own direct-process diagnostics.
- Reduce the count if all processes initialize but the workstation cannot sustain the selected number of browser instances.

### Vibium command not found

- Recheck the executable path under `tools/vibium-portable/node_modules/.bin`.
- Run the executable's `--help` command directly.
- Set `VIBIUM_MCP_COMMAND` before starting the framework or put `vibium` on `PATH` for separate/parallel mode.
- Correct `windowsCommand` or `macCommand` in the bridge config for shared-browser/recorder mode.

### Cookie setup fails

- Verify the cookie exists immediately after the configured URL loads.
- Match the name exactly, including case.
- Inspect `mcp-tools.json` for `browser_storage_state` (or `browser_get_cookies`), `browser_set_cookie`, `browser_delete_cookies` (or `browser_clear_cookies`), and `browser_reload`.
- Upgrade Vibium if native cookie tools are absent.
- Disable cookie replacement to confirm the rest of the test flow independently.
- For a **+ Add cookie** row, use a new name that is not already present; existing names are intentionally rejected before changes are made.

### Selected installed browser is rejected

The current Vibium `browser_start` schema may not accept a browser channel or executable path. Select **Vibium Managed Chrome for Testing**.

### Internal HTTPS page remains blocked

- Enable the internal-certificate option only for an approved environment.
- Confirm the browser displays a standard Chrome privacy interstitial.
- Do not use this option to bypass trust checks on systems you do not own or administer.

### Port 8090 is already in use

Change `server.port` in `config/application-local.properties`, restart the JAR, and open the new port.
