package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.itps.vibium.model.RecordedAction;
import com.itps.vibium.model.RecorderSessionStatus;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class RecorderExportServiceTest {

    @Test
    void createsDirectlyExecutableScenarioAndDetailedActionSheet() throws Exception {
        ObjectMapper mapper = JsonMapper.builder().addModule(new JavaTimeModule()).build();
        RecorderExportService service = new RecorderExportService(mapper);
        RecorderSessionStatus status = new RecorderSessionStatus();
        status.setSessionId("20260722-test");
        status.setApplicationUrl("https://example.test/search");

        RecordedAction click = new RecordedAction();
        click.setSequence(1);
        click.setAction("CLICK");
        click.setElementName("Entity Code");
        click.setLocatorType("CSS");
        click.setLocator("#entityCode");
        click.setCssSelector("#entityCode");
        click.setRecordedAt(Instant.parse("2026-07-22T08:00:00Z"));
        click.setPrompt(RecorderPromptFormatter.format(click));

        RecordedAction type = new RecordedAction();
        type.setSequence(2);
        type.setAction("TYPE");
        type.setElementName("Entity Code");
        type.setValue("BCEF");
        type.setLocatorType("CSS");
        type.setLocator("#entityCode input");
        type.setCssSelector("#entityCode input");
        type.setRecordedAt(Instant.parse("2026-07-22T08:00:01Z"));
        type.setPrompt(RecorderPromptFormatter.format(type));
        status.setActions(List.of(click, type));

        byte[] bytes = service.excel(status);
        try (XSSFWorkbook workbook = new XSSFWorkbook(new ByteArrayInputStream(bytes))) {
            assertThat(workbook.getSheet("RecordedScenario")).isNotNull();
            assertThat(workbook.getSheet("RecordedActions")).isNotNull();
            assertThat(workbook.getSheet("RecordedScenario").getRow(1).getCell(0).getStringCellValue()).isEqualTo("true");
            assertThat(workbook.getSheet("RecordedScenario").getRow(1).getCell(3).getStringCellValue())
                    .isEqualTo("https://example.test/search");
            assertThat(workbook.getSheet("RecordedScenario").getRow(1).getCell(4).getStringCellValue())
                    .contains("Click \"Entity Code\" using css=\"#entityCode\"")
                    .contains("Type \"BCEF\" in \"Entity Code\" using css=\"#entityCode input\"");
            assertThat(workbook.getSheet("RecordedActions").getLastRowNum()).isEqualTo(2);
        }
    }
}
