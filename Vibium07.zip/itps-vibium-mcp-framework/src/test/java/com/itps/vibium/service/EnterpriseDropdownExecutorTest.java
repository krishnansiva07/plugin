package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnterpriseDropdownExecutorTest {
    private final EnterpriseDropdownExecutor executor = new EnterpriseDropdownExecutor(new ObjectMapper());

    @Test
    void parsesSemanticAngularDropdownInstruction() {
        EnterpriseDropdownExecutor.Request request = executor.parse("Select BCEF from MF dropdown");
        assertEquals("BCEF", request.value());
        assertEquals("MF", request.field());
        assertTrue(executor.supports("Select BCEF from MF dropdown"));
    }

    @Test
    void parsesSetFieldToValueInstruction() {
        EnterpriseDropdownExecutor.Request request = executor.parse("Set MF to BCEF");
        assertEquals("BCEF", request.value());
        assertEquals("MF", request.field());
        assertTrue(executor.supports("Set MF to BCEF"));
    }

    @Test
    void treatsOptionXpathAsOptionRatherThanTrigger() {
        String step = "Select BCEF from MF dropdown using xpath=//div[@role='option' and normalize-space(.)='BCEF']";
        EnterpriseDropdownExecutor.Request request = executor.parse(step);
        assertEquals("", request.genericXPath());
        assertTrue(request.optionXPath().contains("@role='option'"));
        assertEquals("BCEF", request.value());
    }

    @Test
    void supportsSeparateTriggerOptionAndVerificationXpaths() {
        String step = "Select 'BCEF' from 'MF' dropdown " +
                "triggerXPath=//*[@id='mf-trigger'] " +
                "optionXPath=//*[@role='option' and normalize-space(.)='BCEF'] " +
                "verifyXPath=//*[@id='mf-selected-value']";
        EnterpriseDropdownExecutor.Request request = executor.parse(step);
        assertEquals("BCEF", request.value());
        assertEquals("MF", request.field());
        assertEquals("//*[@id='mf-trigger']", request.triggerXPath());
        assertTrue(request.optionXPath().contains("@role='option'"));
        assertEquals("//*[@id='mf-selected-value']", request.verifyXPath());
    }

    @Test
    void doesNotHijackOrdinaryButtonClick() {
        assertFalse(executor.supports("Click Save button using xpath=//*[@id='save']"));
    }

    @Test
    void normalizesSmartQuotesFromExcelOrTeams() {
        String step = "Select BCEF from MF dropdown using xpath=“//*[text()=‘BCEF’]”";
        EnterpriseDropdownExecutor.Request request = executor.parse(step);
        assertEquals("//*[text()='BCEF']", request.genericXPath());
        assertEquals("BCEF", request.value());
        assertEquals("MF", request.field());
    }

    @Test
    void ordinaryExplicitXpathClickIsReservedForLiveXpathPriorityExecutor() {
        String step = "Click the element using following Xpath “//*[text()=‘BCEF’]”";
        assertFalse(executor.supports(step));
        assertEquals("Click the element using following Xpath \"//*[text()='BCEF']\"",
                LiveXPathActionExecutor.normalizeSmartQuotes(step));
    }
}
