package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.AdditionalCookie;
import com.itps.vibium.model.McpTool;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CookieSessionManagerTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void preservesAttributesClearsAllRestoresRefreshesAndVerifies() throws Exception {
        FakeMcpClient mcp = new FakeMcpClient(mapper, List.of(
                cookie("other", "old", ".example.test", "/", false, false, "Lax"),
                cookie("SESSION", "original", ".example.test", "/app", true, true, "Strict")));
        CookieSessionManager manager = new CookieSessionManager(mapper);

        CookieSessionManager.Result result = manager.replaceCookie(mcp, catalog(), "SESSION", "replacement-secret");

        assertThat(mcp.calls).extracting(Call::name).containsSubsequence(
                "browser_get_url", "browser_get_cookies", "browser_clear_cookies",
                "context_add_cookies", "browser_navigate", "browser_wait_for_load", "browser_get_cookies");
        @SuppressWarnings("unchecked")
        Map<String, Object> restored = (Map<String, Object>) ((List<?>) mcp.calls.stream()
                .filter(call -> call.name.equals("context_add_cookies"))
                .findFirst().orElseThrow().arguments.get("cookies")).get(0);
        assertThat(restored).containsEntry("name", "SESSION")
                .containsEntry("value", "replacement-secret")
                .containsEntry("domain", ".example.test")
                .containsEntry("path", "/app")
                .containsEntry("httpOnly", true)
                .containsEntry("secure", true)
                .containsEntry("sameSite", "Strict");
        assertThat(result.redactedAudit().toString()).contains("[REDACTED]").doesNotContain("replacement-secret");
        assertThat(mcp.cookies).hasSize(1);
    }

    @Test
    void missingSelectedCookieDoesNotClearAnything() {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("OTHER", "value", "example.test", "/", false, false, "Lax")));

        assertThrows(IllegalStateException.class,
                () -> new CookieSessionManager(mapper).replaceCookie(mcp, catalog(), "SESSION", "replacement"));

        assertThat(mcp.calls).extracting(Call::name).doesNotContain("browser_clear_cookies", "context_add_cookies");
        assertThat(mcp.cookies).hasSize(1);
    }

    @Test
    void supportsVibiumStorageStateSetCookieClearCookiesAndReloadTools() throws Exception {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("SESSION", "original", "app.example.test", "/", true, true, "Lax")));
        McpToolCatalog vibiumCatalog = new McpToolCatalog(List.of(
                tool("browser_get_url"),
                tool("browser_storage_state"),
                tool("browser_clear_cookies"),
                flatCookieTool("browser_set_cookie"),
                tool("browser_reload")));

        CookieSessionManager.Result result = new CookieSessionManager(mapper)
                .replaceCookie(mcp, vibiumCatalog, "SESSION", "new-value");

        assertThat(mcp.calls).extracting(Call::name).containsSubsequence(
                "browser_storage_state", "browser_clear_cookies", "browser_set_cookie",
                "browser_reload", "browser_storage_state");
        assertThat(result.redactedAudit().path("verified").asBoolean()).isTrue();
        assertThat(mcp.cookies).singleElement().satisfies(cookie ->
                assertThat(cookie).containsEntry("value", "new-value").containsEntry("httpOnly", true));
    }

    @Test
    void followsCurrentVibiumSchemaReadAllClearAllSetAndVerify() throws Exception {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("SESSION", "original", ".example.test", "/app", true, true, "Strict")), true);
        McpToolCatalog currentVibium = new McpToolCatalog(List.of(
                tool("browser_get_url"),
                tool("browser_get_cookies"),
                tool("browser_storage_state"),
                toolWithProperty("browser_delete_cookies", "name"),
                currentVibiumSetCookieTool(),
                tool("browser_reload")));

        CookieSessionManager.Result result = new CookieSessionManager(mapper)
                .replaceCookie(mcp, currentVibium, "SESSION", "replacement-secret");

        assertThat(mcp.calls).extracting(Call::name).containsExactly(
                "browser_get_url", "browser_storage_state", "browser_delete_cookies",
                "browser_set_cookie", "browser_reload", "browser_storage_state");
        Call clear = mcp.calls.stream().filter(call -> call.name.equals("browser_delete_cookies"))
                .findFirst().orElseThrow();
        assertThat(clear.arguments).isEmpty();
        Call set = mcp.calls.stream().filter(call -> call.name.equals("browser_set_cookie"))
                .findFirst().orElseThrow();
        assertThat(set.arguments).containsExactlyInAnyOrderEntriesOf(Map.of(
                "name", "SESSION",
                "value", "replacement-secret",
                "domain", ".example.test",
                "path", "/app"));
        assertThat(result.redactedAudit().path("existingAttributesReadBeforeRemoval").path("httpOnly").asBoolean()).isTrue();
        assertThat(result.redactedAudit().path("injectedAttributes").has("httpOnly")).isFalse();
        assertThat(result.redactedAudit().toString()).doesNotContain("replacement-secret");
        assertThat(mcp.cookies).singleElement().satisfies(cookie -> assertThat(cookie)
                .containsEntry("name", "SESSION")
                .containsEntry("value", "replacement-secret")
                .containsEntry("domain", ".example.test")
                .containsEntry("path", "/app"));
    }

    @Test
    void parsesVibiumHumanReadableGetCookiesAsCompatibilityFallback() throws Exception {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("SESSION", "original=value", "app.example.test", "/", false, true, "Lax")), true);
        McpToolCatalog textOnlyVibium = new McpToolCatalog(List.of(
                tool("browser_get_url"),
                tool("browser_get_cookies"),
                toolWithProperty("browser_delete_cookies", "name"),
                currentVibiumSetCookieTool(),
                tool("browser_reload")));

        new CookieSessionManager(mapper).replaceCookie(mcp, textOnlyVibium, "SESSION", "new=value");

        assertThat(mcp.calls).extracting(Call::name).containsExactly(
                "browser_get_url", "browser_get_cookies", "browser_delete_cookies",
                "browser_set_cookie", "browser_reload", "browser_get_cookies");
        assertThat(mcp.cookies).singleElement().satisfies(cookie -> assertThat(cookie)
                .containsEntry("name", "SESSION")
                .containsEntry("value", "new=value")
                .containsEntry("domain", "app.example.test")
                .containsEntry("path", "/"));
    }

    @Test
    void addsUserCookieWithExistingPageScopeWithoutClearingWorkingCookies() throws Exception {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("SESSION", "working", ".example.test", "/app", true, true, "Lax")));
        McpToolCatalog currentVibium = new McpToolCatalog(List.of(
                tool("browser_get_url"),
                tool("browser_storage_state"),
                toolWithProperty("browser_delete_cookies", "name"),
                currentVibiumSetCookieTool(),
                tool("browser_reload")));

        CookieSessionManager.Result result = new CookieSessionManager(mapper).addCookies(
                mcp, currentVibium, List.of(new AdditionalCookie("FEATURE_FLAG", "enabled")));

        assertThat(mcp.calls).extracting(Call::name).containsExactly(
                "browser_get_url", "browser_storage_state", "browser_set_cookie",
                "browser_reload", "browser_storage_state");
        assertThat(mcp.calls).extracting(Call::name).doesNotContain("browser_delete_cookies");
        assertThat(mcp.cookies).hasSize(2);
        assertThat(mcp.cookies).anySatisfy(cookie -> assertThat(cookie)
                .containsEntry("name", "FEATURE_FLAG")
                .containsEntry("value", "enabled")
                .containsEntry("domain", ".example.test")
                .containsEntry("path", "/app"));
        assertThat(result.redactedAudit().toString()).doesNotContain("enabled");
        assertThat(result.redactedAudit().path("verified").asBoolean()).isTrue();
    }

    @Test
    void refusesToOverwriteAnExistingCookieWhenAddingAUserCookie() {
        FakeMcpClient mcp = new FakeMcpClient(mapper,
                List.of(cookie("FEATURE_FLAG", "existing", "app.example.test", "/", false, true, "Lax")));
        McpToolCatalog currentVibium = new McpToolCatalog(List.of(
                tool("browser_get_url"), tool("browser_storage_state"),
                currentVibiumSetCookieTool(), tool("browser_reload")));

        IllegalStateException error = assertThrows(IllegalStateException.class,
                () -> new CookieSessionManager(mapper).addCookies(
                        mcp, currentVibium, List.of(new AdditionalCookie("FEATURE_FLAG", "new"))));
        assertThat(error).hasMessageContaining("already exists")
                .hasMessageContaining("No additional cookies were changed");
        assertThat(mcp.calls).extracting(Call::name).doesNotContain("browser_set_cookie", "browser_reload");
        assertThat(mcp.cookies).singleElement().satisfies(cookie -> assertThat(cookie)
                .containsEntry("value", "existing"));
    }

    private McpToolCatalog catalog() {
        return new McpToolCatalog(List.of(
                tool("browser_get_url"),
                tool("browser_get_cookies"),
                tool("browser_clear_cookies"),
                addCookiesTool(),
                toolWithProperty("browser_navigate", "url"),
                tool("browser_wait_for_load")));
    }

    private McpTool addCookiesTool() {
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode item = schema.putObject("properties").putObject("cookies").putObject("items");
        ObjectNode properties = item.putObject("properties");
        for (String name : List.of("name", "value", "domain", "path", "httpOnly", "secure", "sameSite", "expires")) {
            properties.putObject(name);
        }
        return new McpTool("context_add_cookies", "add cookies", schema);
    }

    private McpTool flatCookieTool(String name) {
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = schema.putObject("properties");
        for (String property : List.of("name", "value", "domain", "path", "httpOnly", "secure", "sameSite", "expires")) {
            properties.putObject(property);
        }
        return new McpTool(name, name, schema);
    }

    private McpTool currentVibiumSetCookieTool() {
        ObjectNode schema = mapper.createObjectNode();
        ObjectNode properties = schema.putObject("properties");
        for (String property : List.of("name", "value", "domain", "path")) properties.putObject(property);
        return new McpTool("browser_set_cookie", "Set a cookie", schema);
    }

    private McpTool tool(String name) {
        ObjectNode schema = mapper.createObjectNode();
        schema.putObject("properties");
        return new McpTool(name, name, schema);
    }

    private McpTool toolWithProperty(String name, String property) {
        ObjectNode schema = mapper.createObjectNode();
        schema.putObject("properties").putObject(property);
        return new McpTool(name, name, schema);
    }

    private Map<String, Object> cookie(String name, String value, String domain, String path,
                                       boolean httpOnly, boolean secure, String sameSite) {
        Map<String, Object> cookie = new LinkedHashMap<>();
        cookie.put("name", name);
        cookie.put("value", value);
        cookie.put("domain", domain);
        cookie.put("path", path);
        cookie.put("httpOnly", httpOnly);
        cookie.put("secure", secure);
        cookie.put("sameSite", sameSite);
        cookie.put("size", 99);
        return cookie;
    }

    private static final class FakeMcpClient extends McpClient {
        private final ObjectMapper mapper;
        private final List<Call> calls = new ArrayList<>();
        private final List<Map<String, Object>> cookies = new ArrayList<>();
        private final boolean vibiumWireFormat;

        FakeMcpClient(ObjectMapper mapper, List<Map<String, Object>> initial) {
            this(mapper, initial, false);
        }

        FakeMcpClient(ObjectMapper mapper, List<Map<String, Object>> initial, boolean vibiumWireFormat) {
            super("unused", List.of(), Duration.ofSeconds(1), true);
            this.mapper = mapper;
            this.vibiumWireFormat = vibiumWireFormat;
            initial.forEach(cookie -> cookies.add(new LinkedHashMap<>(cookie)));
        }

        @Override
        public JsonNode callTool(String name, Map<String, Object> arguments) throws Exception {
            calls.add(new Call(name, new LinkedHashMap<>(arguments == null ? Map.of() : arguments)));
            if ("browser_get_url".equals(name)) return text("https://app.example.test/app/home");
            if ("browser_get_cookies".equals(name) && vibiumWireFormat) {
                String lines = cookies.stream().map(cookie -> cookie.get("name") + "=" + cookie.get("value")
                                + " (domain=" + cookie.getOrDefault("domain", "")
                                + ", path=" + cookie.getOrDefault("path", "/") + ")")
                        .reduce((left, right) -> left + "\n" + right).orElse("No cookies");
                return text(lines);
            }
            if ("browser_get_cookies".equals(name) || "browser_storage_state".equals(name)) {
                return text(mapper.writeValueAsString(Map.of("cookies", cookies)));
            }
            if ("browser_clear_cookies".equals(name) || "browser_delete_cookies".equals(name)) cookies.clear();
            if ("context_add_cookies".equals(name)) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> additions = (List<Map<String, Object>>) arguments.get("cookies");
                additions.forEach(cookie -> cookies.add(new LinkedHashMap<>(cookie)));
            }
            if ("browser_set_cookie".equals(name)) cookies.add(new LinkedHashMap<>(arguments));
            return text("OK");
        }

        private JsonNode text(String value) {
            ObjectNode result = mapper.createObjectNode();
            result.put("isError", false);
            result.putArray("content").addObject().put("type", "text").put("text", value);
            return result;
        }
    }

    private record Call(String name, Map<String, Object> arguments) { }
}
