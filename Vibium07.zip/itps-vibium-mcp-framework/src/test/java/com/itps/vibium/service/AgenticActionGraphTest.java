package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class AgenticActionGraphTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void healsAndReexecutesThroughLangGraph() throws Exception {
        AgenticActionGraph graph = new AgenticActionGraph();
        AtomicInteger executions = new AtomicInteger();

        AgenticActionGraph.Result result = graph.run(new AgenticActionGraph.Actions() {
            @Override
            public AgenticActionGraph.Plan plan() {
                return new AgenticActionGraph.Plan("INITIAL", mapper.createObjectNode().put("selector", "#old"), null);
            }

            @Override
            public void execute(AgenticActionGraph.Plan plan) {
                if (executions.incrementAndGet() == 1) {
                    throw new IllegalStateException("old selector failed validation");
                }
                assertEquals("HEALED_1", plan.source());
            }

            @Override
            public AgenticActionGraph.Plan heal(String failure, AgenticActionGraph.Plan previousPlan, int attempt) {
                assertTrue(failure.contains("old selector"));
                assertEquals(1, attempt);
                return new AgenticActionGraph.Plan("HEALED_1", mapper.createObjectNode().put("selector", "#new"), null);
            }
        }, 2);

        assertTrue(result.success());
        assertTrue(result.healed());
        assertEquals(1, result.healingAttempts());
        assertEquals(2, executions.get());
        assertEquals("HEALED_1", result.finalPlan().source());
        assertTrue(result.history().stream().anyMatch(line -> line.startsWith("VALIDATE_FAILED")));
        assertTrue(result.history().stream().anyMatch(line -> line.startsWith("HEAL_PLAN_OK_1")));
    }

    @Test
    void stopsWhenHealingBudgetIsExhausted() throws Exception {
        AgenticActionGraph graph = new AgenticActionGraph();

        AgenticActionGraph.Result result = graph.run(new AgenticActionGraph.Actions() {
            @Override
            public AgenticActionGraph.Plan plan() {
                return new AgenticActionGraph.Plan("INITIAL", mapper.createObjectNode(), null);
            }

            @Override
            public void execute(AgenticActionGraph.Plan plan) {
                throw new IllegalStateException("no observable change");
            }

            @Override
            public AgenticActionGraph.Plan heal(String failure, AgenticActionGraph.Plan previousPlan, int attempt) {
                throw new IllegalStateException("confidence too low");
            }
        }, 1);

        assertFalse(result.success());
        assertEquals(1, result.healingAttempts());
        assertTrue(result.error().contains("confidence too low"));
    }
}
