package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FocusedInputExecutorTest {
    private final FocusedInputExecutor executor = new FocusedInputExecutor(new ObjectMapper());

    @Test
    void supportsStandaloneTypeAfterAFieldWasClicked() {
        assertTrue(executor.supports("Type \"BCEF\""));
        assertTrue(executor.supports("Enter ‘BCEF’"));
    }

    @Test
    void leavesExplicitXpathTypingToXpathPriorityExecutor() {
        assertFalse(executor.supports("Type \"BCEF\" using xpath=\"//*[@id='entityCode']//input\""));
    }

    @Test
    void doesNotHijackFieldNamedTypingThatNeedsSemanticPlanning() {
        assertFalse(executor.supports("Type \"BCEF\" in the Entity Code field"));
    }
}
