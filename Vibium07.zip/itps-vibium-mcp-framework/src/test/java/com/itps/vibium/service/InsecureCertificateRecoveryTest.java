package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class InsecureCertificateRecoveryTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void onlyAttemptsEnabledHttpsUrls() {
        assertTrue(InsecureCertificateRecovery.canAttempt("https://10.229.107.207/app", true));
        assertFalse(InsecureCertificateRecovery.canAttempt("http://10.229.107.207/app", true));
        assertFalse(InsecureCertificateRecovery.canAttempt("https://10.229.107.207/app", false));
        assertFalse(InsecureCertificateRecovery.canAttempt("not-a-url", true));
    }

    @Test
    void detectsPrivacyPageAndToolFailure() throws Exception {
        assertTrue(InsecureCertificateRecovery.containsPrivacyMarker("Your connection is not private"));
        assertTrue(InsecureCertificateRecovery.containsPrivacyMarker("NET::ERR_CERT_AUTHORITY_INVALID"));
        assertFalse(InsecureCertificateRecovery.containsPrivacyMarker("Application login"));

        JsonNode failed = mapper.readTree("{\"isError\":true,\"content\":[{\"type\":\"text\",\"text\":\"Failed to navigate: BiDi error\"}]}");
        JsonNode passed = mapper.readTree("{\"isError\":false,\"content\":[{\"type\":\"text\",\"text\":\"Navigated\"}]}");
        assertTrue(InsecureCertificateRecovery.isToolFailure(failed));
        assertFalse(InsecureCertificateRecovery.isToolFailure(passed));
    }

    @Test
    void clicksChromeInterstitialAndRetriesNavigation() {
        FakeMcpClient mcp = new FakeMcpClient(mapper);
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                tool("browser_navigate", "url"),
                tool("browser_click", "selector", "timeout"),
                tool("browser_get_url"),
                tool("browser_get_title"),
                tool("browser_get_text"),
                tool("browser_wait_for_load")
        ));

        InsecureCertificateRecovery.Outcome outcome = InsecureCertificateRecovery.recover(
                mcp, catalog, "https://10.229.107.207/aura", mapper);

        assertTrue(outcome.recovered(), outcome.evidence());
        assertFalse(InsecureCertificateRecovery.isToolFailure(outcome.navigationResult()));
        assertTrue(mcp.calls.stream().anyMatch(call -> call.name.equals("browser_click")
                && "#details-button".equals(call.arguments.get("selector"))));
        assertTrue(mcp.calls.stream().anyMatch(call -> call.name.equals("browser_click")
                && "#proceed-link".equals(call.arguments.get("selector"))));
        assertTrue(mcp.calls.stream().anyMatch(call -> call.name.equals("browser_navigate")));
    }

    private McpTool tool(String name, String... properties) {
        ObjectNode schema = mapper.createObjectNode();
        schema.put("type", "object");
        ObjectNode props = schema.putObject("properties");
        for (String property : properties) props.putObject(property).put("type", "string");
        return new McpTool(name, name, schema);
    }

    private static final class FakeMcpClient extends McpClient {
        private final ObjectMapper mapper;
        private final List<Call> calls = new ArrayList<>();
        private boolean proceeded;

        FakeMcpClient(ObjectMapper mapper) {
            super("unused", List.of(), Duration.ofSeconds(1), true);
            this.mapper = mapper;
        }

        @Override
        public JsonNode callTool(String name, Map<String, Object> arguments) {
            calls.add(new Call(name, new LinkedHashMap<>(arguments == null ? Map.of() : arguments)));
            if ("browser_get_url".equals(name)) {
                return text(proceeded ? "https://10.229.107.207/aura" : "chrome-error://chromewebdata/");
            }
            if ("browser_get_title".equals(name)) {
                return text(proceeded ? "Application" : "Privacy error");
            }
            if ("browser_get_text".equals(name)) {
                return text(proceeded ? "Login" : "Your connection is not private NET::ERR_CERT_AUTHORITY_INVALID");
            }
            if ("browser_click".equals(name)) {
                if ("#proceed-link".equals(arguments.get("selector"))) proceeded = true;
                return text("Clicked " + arguments.get("selector"));
            }
            if ("browser_navigate".equals(name)) {
                return proceeded ? text("Navigated") : error("Failed to navigate: BiDi error");
            }
            return text("OK");
        }

        private JsonNode text(String value) {
            ObjectNode out = mapper.createObjectNode();
            out.put("isError", false);
            out.putArray("content").addObject().put("type", "text").put("text", value);
            return out;
        }

        private JsonNode error(String value) {
            ObjectNode out = mapper.createObjectNode();
            out.put("isError", true);
            out.putArray("content").addObject().put("type", "text").put("text", value);
            return out;
        }
    }

    private record Call(String name, Map<String, Object> arguments) { }
}
