package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LiveXPathActionExecutorTest {
    private final LiveXPathActionExecutor executor = new LiveXPathActionExecutor(new ObjectMapper());

    @Test
    void convertsCurlyQuotesToXpathSafeQuotes() {
        assertEquals("Click using xpath=\"//*[text()='BCEF']\"",
                LiveXPathActionExecutor.normalizeSmartQuotes(
                        "Click using xpath=“//*[text()=‘BCEF’]”"));
    }

    @Test
    void recognizesUsingVisibleTextAsDeterministicAction() {
        assertTrue(executor.supportsVisibleText("Click \"BCEF\" using visible text"));
        assertTrue(executor.supportsVisibleText("Click ‘BCEF’ by exact text"));
    }

    @Test
    void doesNotHijackAnOrdinarySemanticClick() {
        assertFalse(executor.supportsVisibleText("Click BCEF"));
    }
}
