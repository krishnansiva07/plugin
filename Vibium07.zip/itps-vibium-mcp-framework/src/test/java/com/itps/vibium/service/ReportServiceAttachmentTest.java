package com.itps.vibium.service;

import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.ScenarioAttemptResult;
import com.itps.vibium.model.ScenarioResult;
import com.itps.vibium.model.StepResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Base64;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ReportServiceAttachmentTest {
    @TempDir
    Path output;

    @Test
    void detailedReportHasNoOutlookOrScreenshotLinksAndScreenshotReportIsStandalone() throws Exception {
        Path screenshots = Files.createDirectories(output.resolve("screenshots"));
        String fileName = "TC001_step_1_attempt_1.png";
        Files.write(screenshots.resolve(fileName), Base64.getDecoder().decode(
                "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nYQAAAAASUVORK5CYII="));

        StepResult step = new StepResult();
        step.setStepNo(1);
        step.setInstruction("Click Payments");
        step.setStatus("PASSED");
        step.setScreenshot(fileName);
        step.setEvidence("Payments page displayed");

        ScenarioAttemptResult attempt = new ScenarioAttemptResult();
        attempt.setAttemptNo(1);
        attempt.setStatus("PASSED");
        attempt.setSteps(List.of(step));

        ScenarioResult scenario = new ScenarioResult();
        scenario.setId("TC001");
        scenario.setName("Payment navigation");
        scenario.setStatus("PASSED");
        scenario.setAttemptCount(1);
        scenario.setMaxAttempts(1);
        scenario.setSteps(List.of(step));
        scenario.setAttempts(List.of(attempt));

        RunStatus status = new RunStatus();
        status.setRunId("RUN-REPORT-TEST");
        status.setStatus("PASSED");
        status.setStartedAt(Instant.now());
        status.setTotal(1);
        status.setExecuted(1);
        status.setPassed(1);
        status.setPassPercentage(100.0);
        status.setScenarios(List.of(scenario));

        new ReportService().writeReports(status, output);

        String detailed = Files.readString(output.resolve("report.html"));
        assertThat(detailed).doesNotContain("outlook-report.html");
        assertThat(detailed).doesNotContain("screenshots/");
        assertThat(detailed).doesNotContain("<th>Screenshot</th>");

        String screenshotReport = Files.readString(output.resolve("screenshots-report.html"));
        assertThat(screenshotReport).contains("data:image/png;base64,");
        assertThat(screenshotReport).contains("Payment navigation");
        assertThat(screenshotReport).doesNotContain("src='screenshots/");
    }
}
