package com.itps.vibium.service;

import com.itps.vibium.model.RecordedAction;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class RecorderPromptFormatterTest {

    @Test
    void formatsCssTypeStepForExistingExcelSyntax() {
        RecordedAction action = action("TYPE", "Entity Code", "BCEF", "CSS", "#entityCode input");
        assertThat(RecorderPromptFormatter.format(action))
                .isEqualTo("Type \"BCEF\" in \"Entity Code\" using css=\"#entityCode input\"");
    }

    @Test
    void formatsXpathOptionClickWithoutChangingLocator() {
        RecordedAction action = action("CLICK", "BCEF", "", "XPATH",
                "//*[@role='option' and normalize-space()='BCEF']");
        assertThat(RecorderPromptFormatter.format(action))
                .isEqualTo("Click \"BCEF\" using xpath=\"//*[@role='option' and normalize-space()='BCEF']\"");
    }

    @Test
    void formatsMaskedSensitiveValue() {
        RecordedAction action = action("TYPE", "Password", "${PASSWORD}", "CSS", "input[name='password']");
        action.setSensitive(true);
        assertThat(RecorderPromptFormatter.format(action))
                .isEqualTo("Type \"${PASSWORD}\" in \"Password\" using css=\"input[name='password']\"");
    }


    @Test
    void escapesQuotesAndBackslashesInRecordedValues() {
        RecordedAction action = action("TYPE", "Comment", "C:\\temp \"BCEF\"", "CSS", "textarea[name='comment']");
        assertThat(RecorderPromptFormatter.format(action))
                .isEqualTo("Type \"C:\\\\temp \\\"BCEF\\\"\" in \"Comment\" using css=\"textarea[name='comment']\"");
    }

    private RecordedAction action(String type, String name, String value, String locatorType, String locator) {
        RecordedAction action = new RecordedAction();
        action.setAction(type);
        action.setElementName(name);
        action.setValue(value);
        action.setLocatorType(locatorType);
        action.setLocator(locator);
        return action;
    }
}
