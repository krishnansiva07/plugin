package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.ScenarioResult;
import com.itps.vibium.model.TestScenario;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class ItpsMcpRunnerParallelTest {
    @TempDir
    Path output;

    @Test
    void parallelModeUsesFixedConcurrentBrowserPoolAndKeepsResultOrder() throws Exception {
        try (StubMcpServer server = new StubMcpServer()) {
            RunConfig config = config(server.port());
            RunStatus status = new RunStatus();
            status.setRunId(config.getRunId());
            List<TestScenario> scenarios = List.of(
                    scenario("ONE", "https://example.test/one"),
                    scenario("TWO", "https://example.test/two"),
                    scenario("THREE", "https://example.test/three"));

            ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                    output.toString(), 5, true);
            runner.execute(scenarios, config, status);

            assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
            assertThat(status.getPassed()).isEqualTo(3);
            assertThat(status.getScenarios()).extracting(result -> result.getId())
                    .containsExactly("ONE", "TWO", "THREE");
            assertThat(server.acceptedSessions()).isEqualTo(3);
            assertThat(server.maxConcurrentSessions()).isGreaterThanOrEqualTo(2);
            assertThat(output.resolve(config.getRunId()).resolve("mcp-sessions")).isDirectory();
            assertThat(output.resolve(config.getRunId()).resolve("mcp-transcript.json")).isRegularFile();
        }
    }

    @Test
    void defaultModeRunsEveryScenarioThroughOneSharedBrowserSession() throws Exception {
        try (StubMcpServer server = new StubMcpServer()) {
            RunConfig config = config(server.port());
            config.setRunId("RUN-SHARED-TEST");
            config.setSeparateBrowserPerTest(false);
            config.setParallelExecution(false);
            RunStatus status = new RunStatus();
            status.setRunId(config.getRunId());

            ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                    output.toString(), 5, true);
            runner.execute(List.of(
                    scenario("ONE", "https://example.test/one"),
                    scenario("TWO", "https://example.test/two"),
                    scenario("THREE", "https://example.test/three")), config, status);

            assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
            assertThat(status.getPassed()).isEqualTo(3);
            assertThat(server.acceptedSessions()).isEqualTo(1);
            assertThat(server.maxConcurrentSessions()).isEqualTo(1);
        }
    }

    @Test
    void parallelModeLaunchesOnlyConfiguredStdioBrowserWorkers() throws Exception {
        Path markers = Files.createDirectories(output.resolve("process-markers"));
        RunConfig config = config(1);
        config.setRunId("RUN-PROCESS-PARALLEL-TEST");
        config.setMcpMode("process-stdio");
        config.setMcpCommand(Path.of(System.getProperty("java.home"), "bin",
                System.getProperty("os.name", "").toLowerCase().contains("win") ? "java.exe" : "java").toString());
        config.setMcpArgs("-cp \"" + childProcessClasspath() + "\" \""
                + FakeMcpProcess.class.getName() + "\" \"" + markers + "\"");
        RunStatus status = new RunStatus();
        status.setRunId(config.getRunId());

        ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                output.toString(), 8, true);
        runner.execute(List.of(
                scenario("ONE", "https://example.test/one"),
                scenario("TWO", "https://example.test/two"),
                scenario("THREE", "https://example.test/three")), config, status);

        assertThat(status.getStatus()).as(status.getMessage() + " | " + status.getScenarios().stream()
                .map(result -> result.getId() + ": " + result.getErrorMessage()).toList()).isEqualTo("PASSED");
        assertThat(status.getPassed()).isEqualTo(3);
        try (var files = Files.list(markers)) {
            assertThat(files.filter(Files::isRegularFile).count()).isEqualTo(3);
        }
        Path sessions = output.resolve(config.getRunId()).resolve("mcp-sessions");
        try (var directories = Files.list(sessions)) {
            assertThat(directories.filter(Files::isDirectory).count()).isEqualTo(3);
        }
    }

    @Test
    void twoBrowserPoolReusesOnlyTwoProcessesForSixScenarios() throws Exception {
        Path markers = Files.createDirectories(output.resolve("two-worker-markers"));
        RunConfig config = config(1);
        config.setRunId("RUN-TWO-WORKER-POOL");
        config.setParallelThreads(2);
        config.setMcpMode("process-stdio");
        config.setMcpCommand(Path.of(System.getProperty("java.home"), "bin",
                System.getProperty("os.name", "").toLowerCase().contains("win") ? "java.exe" : "java").toString());
        config.setMcpArgs("-cp \"" + childProcessClasspath() + "\" \""
                + FakeMcpProcess.class.getName() + "\" \"" + markers + "\"");
        RunStatus status = new RunStatus();
        status.setRunId(config.getRunId());

        ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                output.toString(), 8, true);
        runner.execute(List.of(
                scenario("ONE", "https://example.test/one"),
                scenario("TWO", "https://example.test/two"),
                scenario("THREE", "https://example.test/three"),
                scenario("FOUR", "https://example.test/four"),
                scenario("FIVE", "https://example.test/five"),
                scenario("SIX", "https://example.test/six")), config, status);

        assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
        assertThat(status.getPassed()).isEqualTo(6);
        try (var files = Files.list(markers)) {
            assertThat(files.filter(Files::isRegularFile).count()).isEqualTo(2);
        }
        Path sessions = output.resolve(config.getRunId()).resolve("mcp-sessions");
        try (var directories = Files.list(sessions)) {
            assertThat(directories.filter(Files::isDirectory).count()).isEqualTo(2);
        }
    }

    @Test
    void immediateFailedScenarioRerunStaysOnSameBrowserPoolWorker() throws Exception {
        Path markers = Files.createDirectories(output.resolve("rerun-worker-markers"));
        RunConfig config = config(1);
        config.setRunId("RUN-RERUN-SAME-WORKER");
        config.setParallelThreads(2);
        config.setFailedScenarioRerunCount(1);
        config.setRetryCount(0);
        config.setMcpMode("process-stdio");
        config.setMcpCommand(Path.of(System.getProperty("java.home"), "bin",
                System.getProperty("os.name", "").toLowerCase().contains("win") ? "java.exe" : "java").toString());
        config.setMcpArgs("-cp \"" + childProcessClasspath() + "\" \""
                + FakeMcpProcess.class.getName() + "\" \"" + markers + "\"");
        RunStatus status = new RunStatus();
        status.setRunId(config.getRunId());

        ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                output.toString(), 8, true);
        runner.execute(List.of(
                scenario("ONE", "https://example.test/one"),
                scenario("RERUN", "https://example.test/force-rerun"),
                scenario("THREE", "https://example.test/three"),
                scenario("FOUR", "https://example.test/four")), config, status);

        assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
        ScenarioResult rerun = status.getScenarios().stream()
                .filter(result -> "RERUN".equals(result.getId())).findFirst().orElseThrow();
        assertThat(rerun.getStatus()).isEqualTo("PASSED_AFTER_RERUN");
        assertThat(rerun.getAttemptCount()).isEqualTo(2);
        try (var files = Files.list(markers)) {
            assertThat(files.filter(Files::isRegularFile).count()).isEqualTo(2);
        }
    }

    private RunConfig config(int port) {
        RunConfig config = new RunConfig();
        config.setRunId("RUN-PARALLEL-TEST");
        config.setMcpMode("external-tcp");
        config.setMcpHost("127.0.0.1");
        config.setMcpPort(port);
        config.setMcpConnectTimeoutSeconds(2);
        config.setBrowserId("vibium-managed-chrome");
        config.setSeparateBrowserPerTest(false);
        config.setParallelExecution(true);
        config.setParallelThreads(3);
        config.setScreenshotMode("NONE");
        // These tests exercise deterministic Navigate actions through the Agentic-Step graph.
        // No external LLM call is required for those actions.
        config.setUseLlm(false);
        config.setEnableSelfHealing(false);
        config.setRetryDelayMs(100);
        config.setAllowInsecureCertificates(false);
        return config;
    }

    private TestScenario scenario(String id, String url) {
        TestScenario scenario = new TestScenario();
        scenario.setId(id);
        scenario.setName(id);
        scenario.setUrl(url);
        return scenario;
    }

    private String childProcessClasspath() throws Exception {
        Set<String> entries = new LinkedHashSet<>();
        for (Class<?> type : List.of(
                FakeMcpProcess.class,
                ObjectMapper.class,
                com.fasterxml.jackson.core.JsonFactory.class,
                com.fasterxml.jackson.annotation.JsonIgnore.class)) {
            entries.add(Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI()).toString());
        }
        return String.join(File.pathSeparator, entries);
    }

    private static final class StubMcpServer implements AutoCloseable {
        private final ObjectMapper mapper = new ObjectMapper();
        private final ServerSocket server;
        private final ExecutorService clients = Executors.newCachedThreadPool();
        private final Thread acceptThread;
        private final AtomicBoolean closed = new AtomicBoolean();
        private final AtomicInteger active = new AtomicInteger();
        private final AtomicInteger maximum = new AtomicInteger();
        private final AtomicInteger accepted = new AtomicInteger();
        private final List<Socket> sockets = new CopyOnWriteArrayList<>();

        StubMcpServer() throws IOException {
            server = new ServerSocket(0);
            acceptThread = new Thread(this::acceptLoop, "stub-mcp-accept");
            acceptThread.setDaemon(true);
            acceptThread.start();
        }

        int port() { return server.getLocalPort(); }
        int acceptedSessions() { return accepted.get(); }
        int maxConcurrentSessions() { return maximum.get(); }

        private void acceptLoop() {
            while (!closed.get()) {
                try {
                    Socket socket = server.accept();
                    sockets.add(socket);
                    accepted.incrementAndGet();
                    clients.submit(() -> handle(socket));
                } catch (IOException error) {
                    if (!closed.get()) throw new UncheckedIOException(error);
                }
            }
        }

        private void handle(Socket socket) {
            int now = active.incrementAndGet();
            maximum.accumulateAndGet(now, Math::max);
            String currentUrl = "about:blank";
            try (socket;
                 BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    JsonNode request = mapper.readTree(line);
                    if (!request.has("id")) continue;
                    String method = request.path("method").asText();
                    ObjectNode result = mapper.createObjectNode();
                    if ("tools/list".equals(method)) {
                        addTool(result, "browser_navigate", "url");
                        addTool(result, "browser_get_url");
                    } else if ("tools/call".equals(method)) {
                        String tool = request.path("params").path("name").asText();
                        if ("browser_navigate".equals(tool)) {
                            currentUrl = request.path("params").path("arguments").path("url").asText();
                            Thread.sleep(250);
                            result = toolResult("Navigated to " + currentUrl);
                        } else if ("browser_get_url".equals(tool)) {
                            result = toolResult(currentUrl);
                        } else {
                            result = toolResult("OK");
                        }
                    }
                    ObjectNode response = mapper.createObjectNode();
                    response.put("jsonrpc", "2.0");
                    response.set("id", request.get("id"));
                    response.set("result", result);
                    writer.write(mapper.writeValueAsString(response));
                    writer.newLine();
                    writer.flush();
                }
            } catch (Exception ignored) {
            } finally {
                active.decrementAndGet();
                sockets.remove(socket);
            }
        }

        private void addTool(ObjectNode result, String name, String... properties) {
            ObjectNode tool = result.withArray("tools").addObject();
            tool.put("name", name);
            tool.put("description", name);
            ObjectNode schema = tool.putObject("inputSchema");
            schema.put("type", "object");
            ObjectNode fields = schema.putObject("properties");
            for (String property : properties) fields.putObject(property).put("type", "string");
        }

        private ObjectNode toolResult(String text) {
            ObjectNode result = mapper.createObjectNode();
            result.put("isError", false);
            result.putArray("content").addObject().put("type", "text").put("text", text);
            return result;
        }

        @Override
        public void close() throws Exception {
            if (!closed.compareAndSet(false, true)) return;
            server.close();
            for (Socket socket : new ArrayList<>(sockets)) {
                try { socket.close(); } catch (Exception ignored) { }
            }
            clients.shutdownNow();
            acceptThread.join(1_000);
        }
    }

    public static final class FakeMcpProcess {
        private FakeMcpProcess() { }

        public static void main(String[] args) throws Exception {
            Path markerDirectory = Path.of(args[0]);
            Files.createDirectories(markerDirectory);
            Files.writeString(markerDirectory.resolve("mcp-" + UUID.randomUUID() + ".started"),
                    String.valueOf(ProcessHandle.current().pid()), StandardCharsets.UTF_8);
            ObjectMapper mapper = new ObjectMapper();
            String currentUrl = "about:blank";
            boolean forcedRerunFailureInjected = false;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    JsonNode request = mapper.readTree(line);
                    if (!request.has("id")) continue;
                    String method = request.path("method").asText();
                    ObjectNode result = mapper.createObjectNode();
                    if ("initialize".equals(method)) {
                        result.put("protocolVersion", "2024-11-05");
                        result.putObject("capabilities").putObject("tools");
                        result.putObject("serverInfo").put("name", "fake-vibium-process").put("version", "test");
                    } else if ("tools/list".equals(method)) {
                        addFakeTool(result, "browser_navigate", "url");
                        addFakeTool(result, "browser_get_url");
                    } else if ("tools/call".equals(method)) {
                        String tool = request.path("params").path("name").asText();
                        if ("browser_navigate".equals(tool)) {
                            String targetUrl = request.path("params").path("arguments").path("url").asText();
                            Thread.sleep(350);
                            if (targetUrl.contains("force-rerun") && !forcedRerunFailureInjected) {
                                forcedRerunFailureInjected = true;
                                result = fakeToolError(mapper, "forced first-attempt failure");
                            } else {
                                currentUrl = targetUrl;
                                result = fakeToolResult(mapper, "Navigated to " + currentUrl);
                            }
                        } else if ("browser_get_url".equals(tool)) {
                            result = fakeToolResult(mapper, currentUrl);
                        } else {
                            result = fakeToolResult(mapper, "OK");
                        }
                    }
                    ObjectNode response = mapper.createObjectNode();
                    response.put("jsonrpc", "2.0");
                    response.set("id", request.get("id"));
                    response.set("result", result);
                    writer.write(mapper.writeValueAsString(response));
                    writer.newLine();
                    writer.flush();
                }
            }
        }

        private static void addFakeTool(ObjectNode result, String name, String... properties) {
            ObjectNode tool = result.withArray("tools").addObject();
            tool.put("name", name);
            tool.put("description", name);
            ObjectNode fields = tool.putObject("inputSchema").putObject("properties");
            for (String property : properties) fields.putObject(property).put("type", "string");
        }

        private static ObjectNode fakeToolResult(ObjectMapper mapper, String text) {
            ObjectNode result = mapper.createObjectNode();
            result.put("isError", false);
            result.putArray("content").addObject().put("type", "text").put("text", text);
            return result;
        }

        private static ObjectNode fakeToolError(ObjectMapper mapper, String text) {
            ObjectNode result = mapper.createObjectNode();
            result.put("isError", true);
            result.putArray("content").addObject().put("type", "text").put("text", text);
            return result;
        }
    }
}
