package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RecordedAction;
import com.itps.vibium.model.RecorderSessionStatus;
import com.itps.vibium.model.RecorderStartRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class UiRecorderService {
    private final ObjectMapper mapper;
    private final RecorderExportService exportService;
    private final String mcpCommand;
    private final String mcpArgs;
    private final String mcpMode;
    private final String mcpHost;
    private final int mcpPort;
    private final int mcpConnectTimeoutSeconds;
    private final boolean skipBrowserDownload;
    private final int requestTimeoutSeconds;
    private final Path outputRoot;
    private final String recorderScript;
    private final Map<String, RecorderSession> sessions = new ConcurrentHashMap<>();
    private final ExecutorService launcher = Executors.newCachedThreadPool(namedDaemon("ui-recorder-launch"));
    private final ScheduledExecutorService poller = Executors.newScheduledThreadPool(2, namedDaemon("ui-recorder-poll"));

    public UiRecorderService(ObjectMapper mapper,
                             RecorderExportService exportService,
                             @Value("${itps.vibium.mcp.command:vibium}") String mcpCommand,
                             @Value("${itps.vibium.mcp.args:mcp}") String mcpArgs,
                             @Value("${itps.vibium.mcp.mode:external-tcp}") String mcpMode,
                             @Value("${itps.vibium.mcp.host:127.0.0.1}") String mcpHost,
                             @Value("${itps.vibium.mcp.port:8765}") int mcpPort,
                             @Value("${itps.vibium.mcp.connect-timeout-seconds:10}") int mcpConnectTimeoutSeconds,
                             @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload,
                             @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                             @Value("${recorder.output-dir:target/itps-vibium-recordings}") String outputDir) throws Exception {
        this.mapper = mapper;
        this.exportService = exportService;
        this.mcpCommand = mcpCommand;
        this.mcpArgs = mcpArgs;
        this.mcpMode = mcpMode;
        this.mcpHost = mcpHost;
        this.mcpPort = mcpPort;
        this.mcpConnectTimeoutSeconds = Math.max(1, mcpConnectTimeoutSeconds);
        this.skipBrowserDownload = skipBrowserDownload;
        this.requestTimeoutSeconds = Math.max(15, requestTimeoutSeconds);
        this.outputRoot = Path.of(outputDir);
        try (var in = new ClassPathResource("recorder-inject.js").getInputStream()) {
            this.recorderScript = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    public RecorderSessionStatus start(RecorderStartRequest request) {
        validateRequest(request);
        boolean active = sessions.values().stream().anyMatch(s -> Set.of("STARTING", "RECORDING", "STOPPING").contains(s.status.getState()));
        if (active) throw new IllegalStateException("Another UI recording is already active. Stop it before starting a new recording.");

        String sessionId = Instant.now().toString().replaceAll("[-:.TZ]", "").substring(0, 14)
                + "-" + UUID.randomUUID().toString().substring(0, 6);
        RecorderSessionStatus status = new RecorderSessionStatus();
        status.setSessionId(sessionId);
        status.setState("STARTING");
        status.setApplicationUrl(request.getApplicationUrl().trim());
        status.setBrowserName(blank(request.getBrowserName()) ? defaultText(request.getBrowserId(), "Vibium managed Chrome") : request.getBrowserName());
        status.setStartedAt(Instant.now());
        status.setMessage("Launching a headed browser and opening the application URL...");

        RecorderSession session = new RecorderSession(status, request);
        sessions.put(sessionId, session);
        launcher.submit(() -> initialize(session));
        return snapshot(session);
    }

    public RecorderSessionStatus get(String sessionId) {
        return snapshot(requireSession(sessionId));
    }

    public RecorderSessionStatus stop(String sessionId) {
        RecorderSession session = requireSession(sessionId);
        synchronized (session.lock) {
            if (Set.of("STOPPED", "FAILED").contains(session.status.getState())) return snapshot(session);
            session.stopRequested = true;
            session.status.setState("STOPPING");
            session.status.setMessage("Stopping recording and generating Excel-compatible steps...");
            if (session.pollFuture != null) session.pollFuture.cancel(false);
        }

        // A final drain flushes any debounced typing that has not yet reached the server.
        for (int i = 0; i < 2; i++) {
            try { drain(session); } catch (Exception ignored) { }
            try { Thread.sleep(150); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }

        closeBrowserAndMcp(session);
        synchronized (session.lock) {
            session.status.setStoppedAt(Instant.now());
            if (!"FAILED".equals(session.status.getState())) {
                session.status.setState("STOPPED");
                session.status.setMessage(session.status.getActions().isEmpty()
                        ? "Recording stopped. No supported UI actions were captured."
                        : "Recording stopped. " + session.status.getActions().size() + " Excel-compatible step(s) generated.");
            }
            try {
                exportService.writeFiles(snapshot(session), outputRoot.resolve(session.status.getSessionId()));
            } catch (Exception e) {
                session.status.setMessage(session.status.getMessage() + " Export warning: " + e.getMessage());
            }
            return snapshot(session);
        }
    }

    public RecorderSessionStatus deleteAction(String sessionId, int sequence) {
        RecorderSession session = requireSession(sessionId);
        synchronized (session.lock) {
            session.status.getActions().removeIf(a -> a.getSequence() == sequence);
            renumber(session.status.getActions());
            return snapshot(session);
        }
    }

    public byte[] excel(String sessionId) throws Exception { return exportService.excel(get(sessionId)); }
    public byte[] json(String sessionId) throws Exception { return exportService.json(get(sessionId)); }

    private void initialize(RecorderSession session) {
        try {
            McpClient mcp = createMcpClient();
            session.mcp = mcp;
            mcp.start();
            cancelIfRequested(session);
            List<McpTool> tools = mcp.initializeAndListTools();
            session.catalog = new McpToolCatalog(tools);
            cancelIfRequested(session);
            if (session.catalog.evaluateTool().isEmpty()) {
                throw new IllegalStateException("This Vibium MCP build does not expose browser_evaluate, which is required by the UI action recorder.");
            }
            startBrowser(session);
            cancelIfRequested(session);
            navigate(session, session.status.getApplicationUrl());
            cancelIfRequested(session);
            waitForLoadQuietly(session);
            synchronized (session.lock) {
                session.status.setState("RECORDING");
                session.status.setMessage("Recording is active. Perform the required UI actions in the launched browser, then click Stop Recording.");
            }
            drain(session);
            session.pollFuture = poller.scheduleWithFixedDelay(() -> {
                try { drain(session); }
                catch (Exception e) {
                    synchronized (session.lock) {
                        session.pollFailures++;
                        session.status.setMessage("Recording is active; waiting for the current page to become scriptable after navigation. " + compact(e.getMessage(), 220));
                    }
                }
            }, 450, 700, TimeUnit.MILLISECONDS);
        } catch (CancellationException cancelled) {
            synchronized (session.lock) {
                session.status.setState("STOPPED");
                session.status.setStoppedAt(Instant.now());
                session.status.setMessage("Recording was stopped before browser initialization completed.");
            }
            closeBrowserAndMcp(session);
        } catch (Exception e) {
            synchronized (session.lock) {
                session.status.setState("FAILED");
                session.status.setStoppedAt(Instant.now());
                session.status.setMessage("Unable to start UI recorder: " + compact(e.getMessage(), 900));
            }
            closeBrowserAndMcp(session);
        }
    }

    private McpClient createMcpClient() {
        if ("external-tcp".equalsIgnoreCase(mcpMode)) {
            return McpClient.externalTcp(
                    mcpHost,
                    mcpPort,
                    Duration.ofSeconds(mcpConnectTimeoutSeconds),
                    Duration.ofSeconds(requestTimeoutSeconds));
        }
        return new McpClient(mcpCommand, splitArgs(mcpArgs), Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload);
    }

    private void cancelIfRequested(RecorderSession session) {
        if (session.stopRequested) throw new CancellationException("Recorder stop requested");
    }

    private void startBrowser(RecorderSession session) throws Exception {
        Optional<McpTool> start = session.catalog.startTool();
        if (start.isEmpty()) return;
        McpTool tool = start.get();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "headless")) args.put("headless", false);
        RecorderStartRequest request = session.request;
        if (!blank(request.getBrowserId()) && !"vibium-managed-chrome".equalsIgnoreCase(request.getBrowserId())) {
            boolean applied = false;
            if (!blank(request.getBrowserExecutable())) {
                for (String key : List.of("executablePath", "browserExecutable", "browserPath", "binary", "executable")) {
                    if (schemaContains(tool, key)) { args.put(key, request.getBrowserExecutable()); applied = true; break; }
                }
            }
            if (!applied) {
                for (String key : List.of("browser", "channel", "browserName")) {
                    if (schemaContains(tool, key)) { args.put(key, request.getBrowserId()); applied = true; break; }
                }
            }
            if (!applied) throw new IllegalStateException("The selected installed browser cannot be passed to this Vibium MCP version. Select Vibium Managed Chrome or upgrade Vibium.");
        }
        JsonNode result = session.mcp.callTool(tool.getName(), args);
        assertToolSuccess(tool.getName(), result);
    }

    private void navigate(RecorderSession session, String url) throws Exception {
        McpTool tool = session.catalog.navigateTool().orElseThrow(() -> new IllegalStateException("Vibium MCP does not expose a navigate tool."));
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "url")) args.put("url", url);
        else if (schemaContains(tool, "uri")) args.put("uri", url);
        else args.put("target", url);
        try {
            JsonNode result = session.mcp.callTool(tool.getName(), args);
            assertToolSuccess(tool.getName(), result);
        } catch (Exception navigationFailure) {
            if (InsecureCertificateRecovery.canAttempt(url, session.request.isAllowInsecureCertificates())) {
                InsecureCertificateRecovery.Outcome recovery = InsecureCertificateRecovery.recover(
                        session.mcp, session.catalog, url, mapper);
                if (recovery.recovered()) {
                    synchronized (session.lock) {
                        session.status.setMessage("Internal HTTPS certificate warning handled automatically. Starting UI recording...");
                    }
                    return;
                }
                throw new IllegalStateException(
                        "Navigation failed and automatic internal-certificate recovery was unsuccessful. Original error: "
                                + compact(navigationFailure.getMessage(), 500) + ". Recovery evidence: "
                                + compact(recovery.evidence(), 700), navigationFailure);
            }
            throw navigationFailure;
        }
    }

    private void waitForLoadQuietly(RecorderSession session) {
        try {
            Optional<McpTool> wait = session.catalog.waitTool();
            if (wait.isPresent()) session.mcp.callTool(wait.get().getName(), Map.of());
        } catch (Exception ignored) { }
    }

    private void drain(RecorderSession session) throws Exception {
        if (session.mcp == null || session.catalog == null) return;
        if (!Set.of("RECORDING", "STOPPING").contains(session.status.getState())) return;
        McpTool evaluate = session.catalog.evaluateTool().orElseThrow();
        JsonNode raw;
        synchronized (session.ioLock) {
            if (session.mcp == null) return;
            raw = session.mcp.callTool(evaluate.getName(), evaluateArgs(evaluate, recorderScript));
        }
        assertToolSuccess(evaluate.getName(), raw);
        JsonNode payload = unwrapJson(raw);
        if (!payload.isObject()) throw new IllegalStateException("Recorder evaluation returned no JSON payload.");

        synchronized (session.lock) {
            session.pollFailures = 0;
            session.status.setCurrentPageUrl(payload.path("url").asText(session.status.getCurrentPageUrl()));
            session.status.setCurrentPageTitle(payload.path("title").asText(session.status.getCurrentPageTitle()));
            JsonNode events = payload.path("events");
            if (events.isArray()) {
                for (JsonNode event : events) appendEvent(session, event);
            }
            if ("RECORDING".equals(session.status.getState())) {
                int count = session.status.getActions().size();
                session.status.setMessage("Recording is active. " + count + " action" + (count == 1 ? "" : "s") + " captured.");
            }
        }
    }

    private void appendEvent(RecorderSession session, JsonNode event) {
        String eventId = event.path("eventId").asText("");
        if (!eventId.isBlank() && !session.eventIds.add(eventId)) return;
        RecordedAction action = mapper.convertValue(event, RecordedAction.class);
        if (action.getRecordedAt() == null) action.setRecordedAt(Instant.now());
        List<RecordedAction> actions = session.status.getActions();
        Integer replacementSequence = null;
        if (!actions.isEmpty() && "DOUBLE_CLICK".equalsIgnoreCase(action.getAction())) {
            RecordedAction last = actions.get(actions.size() - 1);
            if ("CLICK".equalsIgnoreCase(last.getAction()) && Objects.equals(last.getLocator(), action.getLocator())
                    && last.getRecordedAt() != null && action.getRecordedAt() != null
                    && Duration.between(last.getRecordedAt(), action.getRecordedAt()).abs().toMillis() <= 1_500) {
                replacementSequence = last.getSequence();
                actions.remove(actions.size() - 1);
            }
        }
        action.setSequence(replacementSequence == null ? session.sequence.incrementAndGet() : replacementSequence);
        action.setPrompt(RecorderPromptFormatter.format(action));
        if (action.getPrompt().isBlank() || blank(action.getLocator())) return;

        if (!actions.isEmpty() && "TYPE".equalsIgnoreCase(action.getAction())) {
            RecordedAction last = actions.get(actions.size() - 1);
            if ("TYPE".equalsIgnoreCase(last.getAction()) && Objects.equals(last.getLocator(), action.getLocator())
                    && last.getRecordedAt() != null && action.getRecordedAt() != null
                    && Duration.between(last.getRecordedAt(), action.getRecordedAt()).abs().toSeconds() <= 3) {
                action.setSequence(last.getSequence());
                actions.set(actions.size() - 1, action);
                return;
            }
        }
        actions.add(action);
    }

    private void closeBrowserAndMcp(RecorderSession session) {
        synchronized (session.ioLock) {
            McpClient mcp = session.mcp;
            if (mcp == null) return;
            try {
                if (session.catalog != null && session.catalog.stopTool().isPresent()) {
                    McpTool stop = session.catalog.stopTool().get();
                    try { mcp.callTool(stop.getName(), Map.of()); } catch (Exception ignored) { }
                }
                mcp.writeDiagnostics(outputRoot.resolve(session.status.getSessionId()));
            } finally {
                try { mcp.close(); } catch (Exception ignored) { }
                session.mcp = null;
            }
        }
    }

    private Map<String, Object> evaluateArgs(McpTool tool, String script) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "expression")) args.put("expression", script);
        else if (schemaContains(tool, "script")) args.put("script", script);
        else if (schemaContains(tool, "code")) args.put("code", script);
        else args.put("expression", script);
        return args;
    }

    private JsonNode unwrapJson(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode();
        List<String> texts = new ArrayList<>();
        collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String candidate = text == null ? "" : text.trim();
            if (!(candidate.startsWith("{") || candidate.startsWith("["))) continue;
            try { return mapper.readTree(candidate); } catch (Exception ignored) { }
        }
        return raw;
    }

    private void collectText(JsonNode node, List<String> output) {
        if (node == null) return;
        if (node.isTextual()) output.add(node.asText());
        else if (node.isArray()) node.forEach(child -> collectText(child, output));
        else if (node.isObject()) node.fields().forEachRemaining(entry -> collectText(entry.getValue(), output));
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException(tool + " returned isError=true: " + compact(result.toString(), 1000));
        String text = flatten(result).toLowerCase(Locale.ROOT);
        for (String fatal : List.of("invalid selector", "browser has not been started", "no active page", "exception")) {
            if (text.contains(fatal)) throw new IllegalStateException(tool + " failed: " + compact(text, 1000));
        }
    }

    private String flatten(JsonNode node) {
        if (node == null) return "";
        if (node.isValueNode()) return node.asText("");
        StringBuilder out = new StringBuilder();
        if (node.isArray()) node.forEach(child -> out.append(' ').append(flatten(child)));
        else node.fields().forEachRemaining(entry -> out.append(' ').append(flatten(entry.getValue())));
        return out.toString();
    }

    private RecorderSession requireSession(String sessionId) {
        RecorderSession session = sessions.get(sessionId);
        if (session == null) throw new NoSuchElementException("Recorder session not found: " + sessionId);
        return session;
    }

    private RecorderSessionStatus snapshot(RecorderSession session) {
        synchronized (session.lock) {
            RecorderSessionStatus copy = new RecorderSessionStatus();
            copy.setSessionId(session.status.getSessionId());
            copy.setState(session.status.getState());
            copy.setApplicationUrl(session.status.getApplicationUrl());
            copy.setBrowserName(session.status.getBrowserName());
            copy.setStartedAt(session.status.getStartedAt());
            copy.setStoppedAt(session.status.getStoppedAt());
            copy.setMessage(session.status.getMessage());
            copy.setCurrentPageUrl(session.status.getCurrentPageUrl());
            copy.setCurrentPageTitle(session.status.getCurrentPageTitle());
            copy.setActions(new ArrayList<>(session.status.getActions()));
            return copy;
        }
    }

    private void renumber(List<RecordedAction> actions) {
        for (int i = 0; i < actions.size(); i++) {
            actions.get(i).setSequence(i + 1);
            actions.get(i).setPrompt(RecorderPromptFormatter.format(actions.get(i)));
        }
    }

    private void validateRequest(RecorderStartRequest request) {
        if (request == null || blank(request.getApplicationUrl())) throw new IllegalArgumentException("Application URL is mandatory to record UI actions.");
        try {
            URI uri = URI.create(request.getApplicationUrl().trim());
            if (!Set.of("http", "https").contains(String.valueOf(uri.getScheme()).toLowerCase(Locale.ROOT)) || blank(uri.getHost())) {
                throw new IllegalArgumentException("Application URL must be a complete http:// or https:// URL.");
            }
        } catch (RuntimeException e) {
            if (e instanceof IllegalArgumentException && e.getMessage() != null && e.getMessage().startsWith("Application URL")) throw e;
            throw new IllegalArgumentException("Application URL is invalid: " + request.getApplicationUrl());
        }
    }

    private boolean schemaContains(McpTool tool, String value) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(value.toLowerCase(Locale.ROOT));
    }

    private List<String> splitArgs(String raw) {
        if (blank(raw)) return new ArrayList<>();
        List<String> out = new ArrayList<>();
        var matcher = java.util.regex.Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s]+)").matcher(raw);
        while (matcher.find()) out.add(matcher.group(1) != null ? matcher.group(1) : matcher.group(2) != null ? matcher.group(2) : matcher.group(3));
        return out;
    }

    private String compact(String value, int max) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        return text.length() <= max ? text : text.substring(0, max) + "...";
    }
    private boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private String defaultText(String value, String fallback) { return blank(value) ? fallback : value.trim(); }

    private static ThreadFactory namedDaemon(String prefix) {
        AtomicInteger counter = new AtomicInteger();
        return runnable -> {
            Thread thread = new Thread(runnable, prefix + "-" + counter.incrementAndGet());
            thread.setDaemon(true);
            return thread;
        };
    }

    @PreDestroy
    public void shutdown() {
        sessions.values().forEach(this::closeBrowserAndMcp);
        launcher.shutdownNow();
        poller.shutdownNow();
    }

    private static final class RecorderSession {
        final Object lock = new Object();
        final Object ioLock = new Object();
        final RecorderSessionStatus status;
        final RecorderStartRequest request;
        final Set<String> eventIds = ConcurrentHashMap.newKeySet();
        final AtomicInteger sequence = new AtomicInteger();
        volatile McpClient mcp;
        volatile McpToolCatalog catalog;
        volatile ScheduledFuture<?> pollFuture;
        volatile int pollFailures;
        volatile boolean stopRequested;

        RecorderSession(RecorderSessionStatus status, RecorderStartRequest request) {
            this.status = status;
            this.request = request;
        }
    }
}
