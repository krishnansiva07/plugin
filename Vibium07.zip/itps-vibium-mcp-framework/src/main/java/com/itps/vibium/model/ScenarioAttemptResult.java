package com.itps.vibium.model;

import java.util.ArrayList;
import java.util.List;

/**
 * One complete execution attempt of a scenario. Attempt 1 is the original run;
 * later attempts are immediate full-scenario reruns requested from the UI.
 */
public class ScenarioAttemptResult {
    private int attemptNo;
    private String status;
    private long durationMs;
    private String errorMessage;
    private List<StepResult> steps = new ArrayList<>();

    public int getAttemptNo() { return attemptNo; }
    public void setAttemptNo(int attemptNo) { this.attemptNo = attemptNo; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public List<StepResult> getSteps() { return steps; }
    public void setSteps(List<StepResult> steps) { this.steps = steps == null ? new ArrayList<>() : steps; }
}
