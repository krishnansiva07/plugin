package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.state.AgentState;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

/**
 * Small LangGraph4j orchestration layer for one browser action.
 *
 * The graph deliberately does not own the LLM or MCP implementation. Those remain in the
 * existing Vibium framework and are supplied through {@link Actions}. This keeps agentic
 * orchestration isolated from browser/session/parallel-execution concerns.
 *
 * Flow:
 * START -> PLAN -> EXECUTE -> SUCCESS -> END
 *                    | failure
 *                    v
 *                  HEAL ------> EXECUTE
 *                    | exhausted
 *                    v
 *                  FAILURE -> END
 */
public final class AgenticActionGraph {

    public record Plan(String source, JsonNode payload, JsonNode observation) { }

    public record Result(boolean success,
                         boolean healed,
                         int healingAttempts,
                         Plan finalPlan,
                         String error,
                         List<String> history) { }

    public interface Actions {
        Plan plan() throws Exception;
        void execute(Plan plan) throws Exception;
        Plan heal(String failure, Plan previousPlan, int attempt) throws Exception;
    }

    static final class ActionState extends AgentState {
        ActionState(Map<String, Object> initData) {
            super(initData);
        }

        boolean success() { return this.<Boolean>value("success").orElse(false); }
        boolean planReady() { return this.<Boolean>value("planReady").orElse(false); }
        boolean healed() { return this.<Boolean>value("healed").orElse(false); }
        int attempt() { return this.<Integer>value("attempt").orElse(0); }
        String error() { return this.<String>value("error").orElse(""); }
        List<String> history() { return this.<List<String>>value("history").orElse(List.of()); }
    }

    public Result run(Actions actions, int maxHealingAttempts) throws Exception {
        int boundedHealing = Math.max(0, maxHealingAttempts);

        // Keep the rich browser plan OUTSIDE LangGraph state. LangGraph4j clones/serializes
        // state between node executions; Plan contains Jackson JsonNode objects and should not
        // be part of that serialized graph state. This holder is local to one run, so it is
        // isolated even when scenarios execute in parallel.
        AtomicReference<Plan> currentPlan = new AtomicReference<>();

        var workflow = new StateGraph<>(ActionState::new)
                .addNode("plan", node_async(state -> {
                    List<String> history = append(state.history(), "PLAN: selecting deterministic or LLM-backed action plan");
                    try {
                        Plan plan = actions.plan();
                        currentPlan.set(plan);
                        history = append(history, "PLAN_OK: " + safeSource(plan));
                        return updates(
                                "planReady", true,
                                "success", false,
                                "error", "",
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "PLAN_FAILED: " + compact(error));
                        return updates(
                                "planReady", false,
                                "success", false,
                                "error", message(error),
                                "history", history);
                    }
                }))
                .addNode("execute", node_async(state -> {
                    List<String> history = state.history();
                    Plan plan = currentPlan.get();
                    if (plan == null || !state.planReady()) {
                        history = append(history, "EXECUTE_SKIPPED: no executable plan");
                        return updates("success", false, "error", "No executable agent plan", "history", history);
                    }
                    try {
                        history = append(history, "EXECUTE: " + safeSource(plan));
                        actions.execute(plan);
                        history = append(history, "VALIDATE_OK: action produced acceptable evidence");
                        return updates(
                                "success", true,
                                "planReady", true,
                                "error", "",
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "VALIDATE_FAILED: " + compact(error));
                        return updates(
                                "success", false,
                                "planReady", true,
                                "error", message(error),
                                "history", history);
                    }
                }))
                .addNode("heal", node_async(state -> {
                    int attempt = state.attempt() + 1;
                    List<String> history = append(state.history(), "HEAL_" + attempt + ": observe failure and request a materially different plan");
                    try {
                        Plan healedPlan = actions.heal(state.error(), currentPlan.get(), attempt);
                        currentPlan.set(healedPlan);
                        history = append(history, "HEAL_PLAN_OK_" + attempt + ": " + safeSource(healedPlan));
                        return updates(
                                "attempt", attempt,
                                "healed", true,
                                "planReady", true,
                                "success", false,
                                "error", "",
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "HEAL_FAILED_" + attempt + ": " + compact(error));
                        return updates(
                                "attempt", attempt,
                                "planReady", false,
                                "success", false,
                                "error", message(error),
                                "history", history);
                    }
                }))
                .addNode("success", node_async(state ->
                        updates("history", append(state.history(), "END: action completed"))))
                .addNode("failure", node_async(state ->
                        updates("history", append(state.history(), "END_FAILED: agentic action exhausted available recovery turns"))))
                .addEdge(START, "plan")
                .addConditionalEdges("plan",
                        edge_async(state -> {
                            if (state.planReady()) return "execute";
                            if (boundedHealing > 0) return "heal";
                            return "failure";
                        }),
                        Map.of("execute", "execute", "heal", "heal", "failure", "failure"))
                .addConditionalEdges("execute",
                        edge_async(state -> {
                            if (state.success()) return "success";
                            if (state.attempt() < boundedHealing) return "heal";
                            return "failure";
                        }),
                        Map.of("success", "success", "heal", "heal", "failure", "failure"))
                .addConditionalEdges("heal",
                        edge_async(state -> {
                            if (state.planReady()) return "execute";
                            if (state.attempt() < boundedHealing) return "heal";
                            return "failure";
                        }),
                        Map.of("execute", "execute", "heal", "heal", "failure", "failure"))
                .addEdge("success", END)
                .addEdge("failure", END)
                .compile();

        Map<String, Object> input = updates(
                "success", false,
                "planReady", false,
                "healed", false,
                "attempt", 0,
                "error", "",
                "history", new ArrayList<String>());

        ActionState state = workflow.invoke(input)
                .orElseThrow(() -> new IllegalStateException("LangGraph4j returned no terminal action state"));
        return new Result(
                state.success(),
                state.healed(),
                state.attempt(),
                currentPlan.get(),
                state.error(),
                List.copyOf(state.history()));
    }

    private static String safeSource(Plan plan) {
        return plan == null || plan.source() == null || plan.source().isBlank() ? "UNKNOWN" : plan.source();
    }

    private static List<String> append(List<String> existing, String value) {
        List<String> out = new ArrayList<>(existing == null ? List.of() : existing);
        out.add(value);
        return out;
    }

    private static String message(Exception error) {
        if (error == null) return "Unknown agentic action failure";
        return error.getMessage() == null || error.getMessage().isBlank()
                ? error.getClass().getSimpleName()
                : error.getMessage();
    }

    private static String compact(Exception error) {
        String value = message(error).replaceAll("\\s+", " ").trim();
        return value.length() <= 500 ? value : value.substring(0, 500) + "...";
    }

    private static Map<String, Object> updates(Object... pairs) {
        Map<String, Object> values = new LinkedHashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            values.put(String.valueOf(pairs[i]), pairs[i + 1]);
        }
        return values;
    }
}
