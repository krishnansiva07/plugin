package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.RecordedAction;
import com.itps.vibium.model.RecorderSessionStatus;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class RecorderExportService {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneId.systemDefault());
    private final ObjectMapper mapper;

    public RecorderExportService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public byte[] excel(RecorderSessionStatus status) throws Exception {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);

            CellStyle wrapStyle = workbook.createCellStyle();
            wrapStyle.setWrapText(true);
            wrapStyle.setVerticalAlignment(VerticalAlignment.TOP);

            Sheet scenario = workbook.createSheet("RecordedScenario");
            String[] scenarioHeaders = {"Run", "Id", "Name", "Url", "Steps", "Expected"};
            Row scenarioHeader = scenario.createRow(0);
            for (int i = 0; i < scenarioHeaders.length; i++) {
                Cell cell = scenarioHeader.createCell(i);
                cell.setCellValue(scenarioHeaders[i]);
                cell.setCellStyle(headerStyle);
            }
            Row scenarioRow = scenario.createRow(1);
            scenarioRow.createCell(0).setCellValue("true");
            scenarioRow.createCell(1).setCellValue("REC_" + status.getSessionId());
            scenarioRow.createCell(2).setCellValue("Recorded UI flow");
            scenarioRow.createCell(3).setCellValue(nullSafe(status.getApplicationUrl()));
            Cell stepsCell = scenarioRow.createCell(4);
            stepsCell.setCellValue(status.getActions().stream().map(RecordedAction::getPrompt)
                    .filter(v -> v != null && !v.isBlank()).reduce((a, b) -> a + "\n" + b).orElse(""));
            stepsCell.setCellStyle(wrapStyle);
            scenarioRow.createCell(5).setCellValue("");
            scenario.setColumnWidth(0, 10 * 256);
            scenario.setColumnWidth(1, 24 * 256);
            scenario.setColumnWidth(2, 30 * 256);
            scenario.setColumnWidth(3, 52 * 256);
            scenario.setColumnWidth(4, 120 * 256);
            scenario.setColumnWidth(5, 45 * 256);
            scenario.createFreezePane(0, 1);

            Sheet actions = workbook.createSheet("RecordedActions");
            String[] actionHeaders = {"Step", "Action", "Element", "Value", "Prompt", "Locator Type", "Primary Locator",
                    "CSS Selector", "XPath", "Fallback Locator", "Frame", "Shadow DOM", "Sensitive", "Page URL", "Page Title", "Recorded At"};
            Row actionHeader = actions.createRow(0);
            for (int i = 0; i < actionHeaders.length; i++) {
                Cell cell = actionHeader.createCell(i);
                cell.setCellValue(actionHeaders[i]);
                cell.setCellStyle(headerStyle);
            }
            List<RecordedAction> recorded = status.getActions();
            for (int i = 0; i < recorded.size(); i++) {
                RecordedAction a = recorded.get(i);
                Row row = actions.createRow(i + 1);
                row.createCell(0).setCellValue(a.getSequence());
                row.createCell(1).setCellValue(nullSafe(a.getAction()));
                row.createCell(2).setCellValue(nullSafe(a.getElementName()));
                row.createCell(3).setCellValue(nullSafe(a.getValue()));
                row.createCell(4).setCellValue(nullSafe(a.getPrompt()));
                row.createCell(5).setCellValue(nullSafe(a.getLocatorType()));
                row.createCell(6).setCellValue(nullSafe(a.getLocator()));
                row.createCell(7).setCellValue(nullSafe(a.getCssSelector()));
                row.createCell(8).setCellValue(nullSafe(a.getXpath()));
                row.createCell(9).setCellValue(nullSafe(a.getFallbackLocator()));
                row.createCell(10).setCellValue(nullSafe(a.getFramePath()));
                row.createCell(11).setCellValue(a.isShadowDom());
                row.createCell(12).setCellValue(a.isSensitive());
                row.createCell(13).setCellValue(nullSafe(a.getPageUrl()));
                row.createCell(14).setCellValue(nullSafe(a.getPageTitle()));
                row.createCell(15).setCellValue(a.getRecordedAt() == null ? "" : TIME.format(a.getRecordedAt()));
                for (Cell cell : row) cell.setCellStyle(wrapStyle);
            }
            actions.createFreezePane(0, 1);
            int[] widths = {9, 16, 28, 25, 90, 15, 75, 65, 80, 65, 35, 14, 12, 55, 35, 22};
            for (int i = 0; i < widths.length; i++) actions.setColumnWidth(i, widths[i] * 256);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    public byte[] json(RecorderSessionStatus status) throws Exception {
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(status);
    }

    public void writeFiles(RecorderSessionStatus status, Path directory) throws Exception {
        Files.createDirectories(directory);
        Files.write(directory.resolve("recorded-steps.xlsx"), excel(status));
        Files.write(directory.resolve("recorded-actions.json"), json(status));
        Files.writeString(directory.resolve("recorded-steps.txt"), status.getActions().stream()
                .map(RecordedAction::getPrompt).filter(v -> v != null && !v.isBlank())
                .reduce((a, b) -> a + System.lineSeparator() + b).orElse(""));
    }

    private String nullSafe(String value) { return value == null ? "" : value; }
}
