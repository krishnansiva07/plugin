package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.AdditionalCookie;
import com.itps.vibium.model.McpTool;

import java.net.URI;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Performs the optional preserve-one-cookie transaction using native MCP cookie tools. */
final class CookieSessionManager {
    private static final Set<String> READ_ONLY_COOKIE_FIELDS = Set.of(
            "size", "session", "hostOnly", "storeId", "id");
    private static final Pattern VIBIUM_COOKIE_LINE = Pattern.compile(
            "^\\s*([^=\\s]+)=(.*?)\\s+\\(domain=([^,]*),\\s*path=(.*?)\\)\\s*$");
    private final ObjectMapper mapper;

    CookieSessionManager(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    Result replaceCookie(McpClient mcp, McpToolCatalog catalog, String cookieName,
                         String replacementValue) throws Exception {
        if (cookieName == null || cookieName.isBlank()) throw new IllegalArgumentException("Cookie name is required.");
        if (replacementValue == null || replacementValue.isBlank()) throw new IllegalArgumentException("Cookie replacement value is required.");

        if (catalog.cookieReadTools().isEmpty()) throw new IllegalStateException(
                "Vibium MCP does not expose a supported cookie inspection tool (browser_get_cookies/browser_storage_state). " +
                        "Cookie replacement cannot safely preserve HttpOnly, domain, path and SameSite attributes.");
        McpTool setCookie = catalog.setCookieTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP does not expose a supported cookie set tool (browser_set_cookie/browser_add_cookie)."));
        if (catalog.clearCookiesTool().isEmpty() && catalog.deleteCookieTool().isEmpty()) {
            throw new IllegalStateException("Vibium MCP does not expose a supported clear-all or delete-cookie tool.");
        }

        List<String> toolsUsed = new ArrayList<>();
        String currentUrl = readCurrentUrl(mcp, catalog, toolsUsed);
        CookieSnapshot before = readCookies(mcp, catalog, currentUrl, toolsUsed, null);
        List<Map<String, Object>> cookies = before.cookies();
        List<Map<String, Object>> matches = cookies.stream()
                .filter(cookie -> cookieName.equals(cookieField(cookie, "name")))
                .toList();
        if (matches.isEmpty()) {
            throw new IllegalStateException("Cookie '" + cookieName + "' was not present after the home page loaded. No cookies were changed.");
        }

        Map<String, Object> selected = selectCookie(matches, currentUrl);
        Map<String, Object> replacement = writableCookie(selected, setCookie, currentUrl);
        replacement.put("name", cookieName);
        replacement.put("value", replacementValue);

        Optional<McpTool> clear = catalog.clearCookiesTool();
        if (clear.isPresent()) {
            Map<String, Object> clearArguments = hasTopProperty(clear.get(), "action")
                    ? Map.of("action", "clear") : Map.of();
            JsonNode cleared = mcp.callTool(clear.get().getName(), clearArguments);
            toolsUsed.add(clear.get().getName());
            assertSuccess(clear.get().getName(), cleared);
        } else {
            McpTool delete = catalog.deleteCookieTool().orElseThrow();
            for (Map<String, Object> cookie : cookies) {
                JsonNode deleted = mcp.callTool(delete.getName(), deleteArguments(delete, cookie, currentUrl));
                toolsUsed.add(delete.getName());
                assertSuccess(delete.getName(), deleted);
            }
        }

        Map<String, Object> setArguments = setArguments(setCookie, replacement);
        try {
            JsonNode setResult = mcp.callTool(setCookie.getName(), setArguments);
            toolsUsed.add(setCookie.getName());
            assertSuccess(setCookie.getName(), setResult);
        } catch (Exception setError) {
            Map<String, Object> rollback = new LinkedHashMap<>(replacement);
            rollback.put("value", cookieField(selected, "value"));
            try {
                mcp.callTool(setCookie.getName(), setArguments(setCookie, rollback));
                toolsUsed.add(setCookie.getName());
            } catch (Exception ignored) { }
            throw new IllegalStateException("Cookie '" + cookieName
                    + "' could not be restored with the replacement value; an original-value rollback was attempted.", setError);
        }

        refresh(mcp, catalog, currentUrl, toolsUsed);

        CookieSnapshot afterSnapshot = readCookies(mcp, catalog, currentUrl, toolsUsed, before.tool());
        List<Map<String, Object>> after = afterSnapshot.cookies();
        boolean verified = after.stream().anyMatch(cookie -> cookieName.equals(cookieField(cookie, "name"))
                && replacementValue.equals(cookieField(cookie, "value")));
        if (!verified) {
            throw new IllegalStateException("Cookie '" + cookieName + "' was restored but its replacement value could not be verified after refresh.");
        }

        ObjectNode audit = mapper.createObjectNode();
        audit.put("transaction", "PRESERVE_ONE_REMOVE_ALL_RESTORE_REFRESH");
        audit.put("cookieName", cookieName);
        audit.put("replacementValue", "[REDACTED]");
        audit.put("cookiesFoundBefore", cookies.size());
        audit.put("cookiesRemainingAfter", after.size());
        audit.put("refreshUrl", currentUrl);
        audit.put("cookieReadTool", before.tool().getName());
        audit.put("cookieSetTool", setCookie.getName());
        audit.put("verified", true);
        ObjectNode discoveredAttributes = audit.putObject("existingAttributesReadBeforeRemoval");
        selected.forEach((key, value) -> {
            if (!"name".equalsIgnoreCase(key) && !"value".equalsIgnoreCase(key)) {
                discoveredAttributes.set(key, mapper.valueToTree(value));
            }
        });
        ObjectNode injectedAttributes = audit.putObject("injectedAttributes");
        replacement.forEach((key, value) -> {
            if (!"name".equalsIgnoreCase(key) && !"value".equalsIgnoreCase(key)) {
                injectedAttributes.set(key, mapper.valueToTree(value));
            }
        });
        return new Result(List.copyOf(toolsUsed), audit,
                "Removed all " + cookies.size() + " existing cookie(s), restored '" + cookieName
                        + "' with every existing attribute accepted by " + setCookie.getName()
                        + ", refreshed the page, and verified the replacement value.");
    }

    Result addCookies(McpClient mcp, McpToolCatalog catalog,
                      List<AdditionalCookie> requestedCookies) throws Exception {
        List<AdditionalCookie> additions = requestedCookies == null ? List.of() : requestedCookies.stream()
                .filter(Objects::nonNull)
                .toList();
        if (additions.isEmpty()) throw new IllegalArgumentException("At least one additional cookie is required.");
        if (catalog.cookieReadTools().isEmpty()) throw new IllegalStateException(
                "Vibium MCP does not expose browser_storage_state or browser_get_cookies for additional-cookie verification.");
        McpTool setCookie = catalog.setCookieTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP does not expose browser_set_cookie/browser_add_cookie for additional cookies."));

        Set<String> requestedNames = new LinkedHashSet<>();
        for (AdditionalCookie addition : additions) {
            if (addition.getName() == null || addition.getName().isBlank()
                    || addition.getValue() == null || addition.getValue().isBlank()) {
                throw new IllegalArgumentException("Every additional cookie requires both a name and value.");
            }
            if (!requestedNames.add(addition.getName())) {
                throw new IllegalArgumentException("Additional cookie names must be unique: " + addition.getName());
            }
        }

        List<String> toolsUsed = new ArrayList<>();
        String currentUrl = readCurrentUrl(mcp, catalog, toolsUsed);
        CookieSnapshot before = readCookies(mcp, catalog, currentUrl, toolsUsed, null);
        Set<String> existingNames = before.cookies().stream()
                .map(cookie -> cookieField(cookie, "name"))
                .collect(java.util.stream.Collectors.toSet());
        for (String requestedName : requestedNames) {
            if (existingNames.contains(requestedName)) {
                throw new IllegalStateException("Cookie '" + requestedName
                        + "' already exists after the home page loaded. No additional cookies were changed.");
            }
        }

        Map<String, Object> scopeTemplate = before.cookies().isEmpty()
                ? new LinkedHashMap<>()
                : selectCookie(before.cookies(), currentUrl);
        List<Map<String, Object>> cookiesToAdd = additions.stream()
                .map(addition -> additionalCookie(addition, scopeTemplate, setCookie, currentUrl))
                .toList();
        List<Map<String, Object>> applied = new ArrayList<>();
        CookieSnapshot afterSnapshot;
        try {
            for (Map<String, Object> cookie : cookiesToAdd) {
                JsonNode setResult = mcp.callTool(setCookie.getName(), setArguments(setCookie, cookie));
                toolsUsed.add(setCookie.getName());
                assertSuccess(setCookie.getName(), setResult);
                applied.add(cookie);
            }
            refresh(mcp, catalog, currentUrl, toolsUsed);
            afterSnapshot = readCookies(mcp, catalog, currentUrl, toolsUsed, before.tool());
            for (AdditionalCookie addition : additions) {
                boolean verified = afterSnapshot.cookies().stream().anyMatch(cookie ->
                        addition.getName().equals(cookieField(cookie, "name"))
                                && addition.getValue().equals(cookieField(cookie, "value")));
                if (!verified) throw new IllegalStateException(
                        "Additional cookie '" + addition.getName() + "' could not be verified after refresh.");
            }
        } catch (Exception error) {
            rollbackAdditionalCookies(mcp, catalog, applied, currentUrl, toolsUsed);
            throw new IllegalStateException("Additional cookie setup failed; already-added cookies were rolled back where supported.", error);
        }

        ObjectNode audit = mapper.createObjectNode();
        audit.put("transaction", "ADD_COOKIES_REFRESH_VERIFY");
        audit.put("cookiesFoundBefore", before.cookies().size());
        audit.put("cookiesAdded", additions.size());
        audit.put("refreshUrl", currentUrl);
        audit.put("cookieReadTool", before.tool().getName());
        audit.put("cookieSetTool", setCookie.getName());
        audit.put("verified", true);
        var added = audit.putArray("addedCookies");
        for (Map<String, Object> cookie : cookiesToAdd) {
            ObjectNode item = added.addObject();
            item.put("name", cookieField(cookie, "name"));
            item.put("value", "[REDACTED]");
            ObjectNode scope = item.putObject("injectedAttributes");
            cookie.forEach((key, value) -> {
                if (!"name".equalsIgnoreCase(key) && !"value".equalsIgnoreCase(key)) {
                    scope.set(key, mapper.valueToTree(value));
                }
            });
        }
        return new Result(List.copyOf(toolsUsed), audit,
                "Added " + additions.size() + " user-supplied cookie(s), refreshed the page, and verified every name/value pair.");
    }

    private Map<String, Object> additionalCookie(AdditionalCookie addition,
                                                  Map<String, Object> template,
                                                  McpTool setTool,
                                                  String currentUrl) {
        Map<String, Object> cookie = writableCookie(template, setTool, currentUrl);
        cookie.keySet().removeIf(key -> Set.of("name", "value", "expires", "expiry").contains(key));
        Set<String> supported = nestedCookieProperties(setTool);
        if (!cookie.containsKey("domain") && acceptsCookieField(supported, "domain")) {
            try {
                String host = URI.create(currentUrl).getHost();
                if (host != null && !host.isBlank()) {
                    cookie.put("domain", host);
                    // Cookie APIs accept either URL scope or domain/path scope, not both.
                    cookie.remove("url");
                }
            } catch (Exception ignored) { }
        }
        if (!cookie.containsKey("path") && acceptsCookieField(supported, "path")) cookie.put("path", "/");
        if (!cookie.containsKey("domain") && acceptsCookieField(supported, "url")) cookie.put("url", currentUrl);
        cookie.put("name", addition.getName());
        cookie.put("value", addition.getValue());
        return cookie;
    }

    private boolean acceptsCookieField(Set<String> supported, String field) {
        return supported.isEmpty() || supported.contains(field);
    }

    private void rollbackAdditionalCookies(McpClient mcp, McpToolCatalog catalog,
                                           List<Map<String, Object>> applied, String currentUrl,
                                           List<String> toolsUsed) {
        Optional<McpTool> delete = catalog.deleteCookieTool();
        if (delete.isEmpty()) return;
        for (Map<String, Object> cookie : applied) {
            try {
                mcp.callTool(delete.get().getName(), deleteArguments(delete.get(), cookie, currentUrl));
                toolsUsed.add(delete.get().getName());
            } catch (Exception ignored) { }
        }
    }

    private String readCurrentUrl(McpClient mcp, McpToolCatalog catalog, List<String> toolsUsed) throws Exception {
        McpTool urlTool = catalog.urlTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP must expose browser_get_url so the page can be refreshed after cookie replacement."));
        JsonNode raw = mcp.callTool(urlTool.getName(), Map.of());
        toolsUsed.add(urlTool.getName());
        assertSuccess(urlTool.getName(), raw);
        for (String text : textValues(raw)) {
            String value = text.trim();
            if (value.startsWith("http://") || value.startsWith("https://")) return value;
            int start = Math.max(value.indexOf("https://"), value.indexOf("http://"));
            if (start >= 0) {
                int end = value.indexOf(' ', start);
                return end < 0 ? value.substring(start) : value.substring(start, end);
            }
        }
        throw new IllegalStateException("Vibium MCP did not return the current page URL before cookie replacement.");
    }

    private CookieSnapshot readCookies(McpClient mcp, McpToolCatalog catalog, String currentUrl,
                                       List<String> toolsUsed, McpTool preferred) throws Exception {
        List<McpTool> ordered = new ArrayList<>();
        if (preferred != null) ordered.add(preferred);
        for (McpTool tool : catalog.cookieReadTools()) {
            if (ordered.stream().noneMatch(existing -> existing.getName().equalsIgnoreCase(tool.getName()))) {
                ordered.add(tool);
            }
        }

        CookieSnapshot recognizedEmpty = null;
        List<String> failures = new ArrayList<>();
        for (McpTool tool : ordered) {
            try {
                toolsUsed.add(tool.getName());
                JsonNode raw = mcp.callTool(tool.getName(), getArguments(tool, currentUrl));
                assertSuccess(tool.getName(), raw);
                CookieExtraction extraction = extractCookies(raw);
                if (!extraction.cookies().isEmpty()) return new CookieSnapshot(tool, extraction.cookies());
                if (extraction.recognized() && recognizedEmpty == null) {
                    recognizedEmpty = new CookieSnapshot(tool, List.of());
                } else if (!extraction.recognized()) {
                    failures.add(tool.getName() + " returned an unrecognized cookie payload");
                }
            } catch (Exception error) {
                failures.add(tool.getName() + ": " + Optional.ofNullable(error.getMessage()).orElse(error.getClass().getSimpleName()));
            }
        }
        if (recognizedEmpty != null) return recognizedEmpty;
        throw new IllegalStateException("Existing cookies could not be read before removal. " + String.join(" | ", failures));
    }

    private void refresh(McpClient mcp, McpToolCatalog catalog, String currentUrl,
                         List<String> toolsUsed) throws Exception {
        Optional<McpTool> reload = catalog.reloadTool();
        if (reload.isPresent()) {
            JsonNode result = mcp.callTool(reload.get().getName(), Map.of());
            toolsUsed.add(reload.get().getName());
            assertSuccess(reload.get().getName(), result);
        } else {
            McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalStateException(
                    "Vibium MCP does not expose browser_reload or browser_navigate for the required refresh."));
            Map<String, Object> arguments = new LinkedHashMap<>();
            String key = hasTopProperty(navigate, "url") ? "url" : "target";
            arguments.put(key, currentUrl);
            JsonNode result = mcp.callTool(navigate.getName(), arguments);
            toolsUsed.add(navigate.getName());
            assertSuccess(navigate.getName(), result);
        }
        if (catalog.findByName("browser_wait_for_load").isPresent()) {
            McpTool wait = catalog.findByName("browser_wait_for_load").get();
            JsonNode waited = mcp.callTool(wait.getName(), Map.of());
            toolsUsed.add(wait.getName());
            assertSuccess(wait.getName(), waited);
        }
    }

    private Map<String, Object> writableCookie(Map<String, Object> source, McpTool setTool,
                                                String currentUrl) {
        Map<String, Object> cookie = new LinkedHashMap<>();
        Set<String> supported = nestedCookieProperties(setTool);
        for (Map.Entry<String, Object> entry : source.entrySet()) {
            if (READ_ONLY_COOKIE_FIELDS.contains(entry.getKey())) continue;
            if (!supported.isEmpty() && !supported.contains(entry.getKey())) continue;
            cookie.put(entry.getKey(), entry.getValue());
        }
        if (!cookie.containsKey("domain") && !cookie.containsKey("url") && currentUrl != null && !currentUrl.isBlank()) {
            cookie.put("url", currentUrl);
        }
        return cookie;
    }

    private Set<String> nestedCookieProperties(McpTool tool) {
        JsonNode properties = schemaProperties(tool);
        JsonNode cookieSchema = properties.path("cookie");
        if (cookieSchema.isMissingNode()) cookieSchema = properties.path("cookies").path("items");
        JsonNode nested = cookieSchema.path("properties");
        if (!nested.isObject() && (properties.has("name") || properties.has("value"))) nested = properties;
        if (!nested.isObject()) return Set.of();
        Set<String> names = new LinkedHashSet<>();
        nested.fieldNames().forEachRemaining(names::add);
        names.remove("action");
        return names;
    }

    private Map<String, Object> setArguments(McpTool tool, Map<String, Object> cookie) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> result;
        if (properties.has("cookies")) result = new LinkedHashMap<>(Map.of("cookies", List.of(cookie)));
        else if (properties.has("cookie")) result = new LinkedHashMap<>(Map.of("cookie", cookie));
        else if (properties.has("name") || properties.has("value")) {
            Map<String, Object> flat = new LinkedHashMap<>();
            cookie.forEach((key, value) -> {
                if (properties.has(key)) flat.put(key, value);
            });
            result = flat.isEmpty() ? new LinkedHashMap<>(cookie) : flat;
        } else {
            result = new LinkedHashMap<>(cookie);
        }
        if (properties.has("action")) result.put("action", "set");
        return result;
    }

    private Map<String, Object> getArguments(McpTool tool, String currentUrl) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> arguments = new LinkedHashMap<>();
        if (properties.has("action")) arguments.put("action", "get");
        if (properties.has("urls") && currentUrl != null && !currentUrl.isBlank()) {
            arguments.put("urls", List.of(currentUrl));
        }
        return arguments;
    }

    private Map<String, Object> deleteArguments(McpTool tool, Map<String, Object> cookie,
                                                 String currentUrl) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> identity = new LinkedHashMap<>();
        for (String key : List.of("name", "domain", "path", "url")) {
            if (cookie.containsKey(key)) identity.put(key, cookie.get(key));
        }
        if (!identity.containsKey("url") && currentUrl != null && !currentUrl.isBlank()) identity.put("url", currentUrl);
        if (properties.has("cookies")) return Map.of("cookies", List.of(identity));
        if (properties.has("cookie")) return Map.of("cookie", identity);
        if (properties.isObject() && properties.size() > 0) {
            identity.entrySet().removeIf(entry -> !properties.has(entry.getKey()));
        }
        return identity;
    }

    private Map<String, Object> selectCookie(List<Map<String, Object>> matches, String currentUrl) {
        if (matches.size() == 1) return matches.get(0);
        String host = "";
        String path = "/";
        try {
            URI uri = URI.create(currentUrl);
            host = Optional.ofNullable(uri.getHost()).orElse("");
            path = Optional.ofNullable(uri.getPath()).filter(value -> !value.isBlank()).orElse("/");
        } catch (Exception ignored) { }
        String finalHost = host;
        String finalPath = path;
        return matches.stream().max(Comparator.comparingInt(cookie -> cookieScore(cookie, finalHost, finalPath)))
                .orElse(matches.get(0));
    }

    private int cookieScore(Map<String, Object> cookie, String host, String currentPath) {
        String domain = String.valueOf(cookie.getOrDefault("domain", "")).replaceFirst("^\\.", "");
        String path = String.valueOf(cookie.getOrDefault("path", "/"));
        int score = host.equalsIgnoreCase(domain) ? 10_000 : (host.endsWith("." + domain) ? 5_000 : 0);
        if (currentPath.startsWith(path)) score += Math.min(path.length(), 1_000);
        return score;
    }

    private CookieExtraction extractCookies(JsonNode raw) {
        List<JsonNode> roots = new ArrayList<>();
        roots.add(raw);
        boolean recognized = false;
        for (String text : textValues(raw)) {
            String value = text.trim();
            JsonNode parsed = parseEmbeddedJson(value);
            if (parsed != null) {
                roots.add(parsed);
                recognized = true;
            }
        }
        List<Map<String, Object>> cookies = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        boolean[] structuredRecognition = {recognized};
        for (JsonNode root : roots) collectCookies(root, cookies, seen, structuredRecognition);
        for (String text : textValues(raw)) {
            for (String line : text.split("\\R")) {
                Matcher matcher = VIBIUM_COOKIE_LINE.matcher(line);
                if (!matcher.matches()) {
                    if (line.trim().equalsIgnoreCase("No cookies")) structuredRecognition[0] = true;
                    continue;
                }
                structuredRecognition[0] = true;
                Map<String, Object> cookie = new LinkedHashMap<>();
                cookie.put("name", matcher.group(1));
                cookie.put("value", matcher.group(2));
                cookie.put("domain", matcher.group(3));
                cookie.put("path", matcher.group(4));
                addCookie(cookie, cookies, seen);
            }
        }
        return new CookieExtraction(List.copyOf(cookies), structuredRecognition[0]);
    }

    private JsonNode parseEmbeddedJson(String value) {
        if (value == null || value.isBlank()) return null;
        String candidate = value.trim();
        if (candidate.startsWith("```")) {
            int newline = candidate.indexOf('\n');
            int closing = candidate.lastIndexOf("```");
            if (newline >= 0 && closing > newline) candidate = candidate.substring(newline + 1, closing).trim();
        }
        int objectStart = candidate.indexOf('{');
        int arrayStart = candidate.indexOf('[');
        int start;
        char closing;
        if (objectStart < 0) {
            start = arrayStart;
            closing = ']';
        } else if (arrayStart < 0 || objectStart < arrayStart) {
            start = objectStart;
            closing = '}';
        } else {
            start = arrayStart;
            closing = ']';
        }
        if (start < 0) return null;
        int end = candidate.lastIndexOf(closing);
        if (end < start) return null;
        try {
            return mapper.readTree(candidate.substring(start, end + 1));
        } catch (Exception ignored) {
            return null;
        }
    }

    private void collectCookies(JsonNode node, List<Map<String, Object>> out, Set<String> seen,
                                boolean[] recognized) {
        if (node == null || node.isNull() || node.isMissingNode()) return;
        if (node.isObject()) {
            JsonNode cookieArray = findFieldIgnoreCase(node, "cookies");
            if (cookieArray != null && cookieArray.isArray()) {
                recognized[0] = true;
                for (JsonNode child : cookieArray) collectCookies(child, out, seen, recognized);
                return;
            }
            JsonNode name = findFieldIgnoreCase(node, "name");
            JsonNode value = findFieldIgnoreCase(node, "value");
            if (name != null && value != null && (name.isTextual() || name.isObject())) {
                @SuppressWarnings("unchecked")
                Map<String, Object> rawCookie = mapper.convertValue(node, LinkedHashMap.class);
                addCookie(normalizeCookie(rawCookie), out, seen);
                recognized[0] = true;
                return;
            }
            node.fields().forEachRemaining(entry -> {
                String key = entry.getKey().toLowerCase(Locale.ROOT);
                if (!Set.of("storage", "origins", "localstorage", "sessionstorage").contains(key)) {
                    collectCookies(entry.getValue(), out, seen, recognized);
                }
            });
        } else if (node.isArray()) {
            for (JsonNode child : node) collectCookies(child, out, seen, recognized);
        }
    }

    private JsonNode findFieldIgnoreCase(JsonNode object, String name) {
        if (object == null || !object.isObject()) return null;
        Iterator<Map.Entry<String, JsonNode>> fields = object.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            if (field.getKey().equalsIgnoreCase(name)) return field.getValue();
        }
        return null;
    }

    private Map<String, Object> normalizeCookie(Map<String, Object> source) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        source.forEach((key, value) -> {
            String canonical = switch (key.toLowerCase(Locale.ROOT).replace("_", "")) {
                case "name" -> "name";
                case "value" -> "value";
                case "domain" -> "domain";
                case "path" -> "path";
                case "httponly" -> "httpOnly";
                case "secure" -> "secure";
                case "samesite" -> "sameSite";
                case "expiry", "expires" -> key.equalsIgnoreCase("expires") ? "expires" : "expiry";
                case "size" -> "size";
                case "partitionkey" -> "partitionKey";
                default -> key;
            };
            if ((canonical.equals("name") || canonical.equals("value")) && value instanceof Map<?, ?> map
                    && map.containsKey("value")) {
                value = map.get("value");
            }
            normalized.put(canonical, value);
        });
        return normalized;
    }

    private void addCookie(Map<String, Object> cookie, List<Map<String, Object>> out, Set<String> seen) {
        String name = cookieField(cookie, "name");
        if (name.isBlank() || !cookie.containsKey("value")) return;
        String identity = name + "|" + cookie.get("domain") + "|" + cookie.get("path") + "|" + cookieField(cookie, "value");
        if (seen.add(identity)) out.add(cookie);
    }

    private List<String> textValues(JsonNode node) {
        List<String> values = new ArrayList<>();
        collectText(node, values);
        values.sort(Comparator.comparingInt(String::length).reversed());
        return values;
    }

    private void collectText(JsonNode node, List<String> values) {
        if (node == null) return;
        if (node.isTextual()) values.add(node.asText());
        else if (node.isArray()) for (JsonNode child : node) collectText(child, values);
        else if (node.isObject()) node.fields().forEachRemaining(entry -> collectText(entry.getValue(), values));
    }

    private JsonNode schemaProperties(McpTool tool) {
        if (tool == null || tool.getInputSchema() == null) return mapper.createObjectNode();
        JsonNode properties = tool.getInputSchema().path("properties");
        return properties.isObject() ? properties : mapper.createObjectNode();
    }

    private boolean hasTopProperty(McpTool tool, String name) {
        return schemaProperties(tool).has(name);
    }

    private String cookieField(Map<String, Object> cookie, String name) {
        Object raw = cookie.get(name);
        if (raw instanceof Map<?, ?> map && map.containsKey("value")) raw = map.get("value");
        return raw == null ? "" : String.valueOf(raw);
    }

    private void assertSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false) || result.path("success").isBoolean() && !result.path("success").asBoolean()) {
            throw new IllegalStateException("MCP cookie operation failed in " + toolName + ".");
        }
        if (result.has("error") && !result.path("error").isNull() && !result.path("error").asText("").isBlank()) {
            throw new IllegalStateException("MCP cookie operation failed in " + toolName + ".");
        }
    }

    private record CookieExtraction(List<Map<String, Object>> cookies, boolean recognized) { }
    private record CookieSnapshot(McpTool tool, List<Map<String, Object>> cookies) { }
    record Result(List<String> toolsUsed, ObjectNode redactedAudit, String evidence) { }
}
