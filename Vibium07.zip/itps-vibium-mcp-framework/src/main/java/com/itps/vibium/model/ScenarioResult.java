package com.itps.vibium.model;

import java.util.ArrayList;
import java.util.List;

public class ScenarioResult {
    private String id;
    private String name;
    private String url;
    private String status;
    private long durationMs;
    private String errorMessage;
    private int attemptCount;
    private int maxAttempts = 1;
    private List<StepResult> steps = new ArrayList<>();
    private List<ScenarioAttemptResult> attempts = new ArrayList<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public int getAttemptCount() { return attemptCount; }
    public void setAttemptCount(int attemptCount) { this.attemptCount = attemptCount; }
    public int getMaxAttempts() { return maxAttempts; }
    public void setMaxAttempts(int maxAttempts) { this.maxAttempts = maxAttempts; }
    public List<StepResult> getSteps() { return steps; }
    public void setSteps(List<StepResult> steps) { this.steps = steps == null ? new ArrayList<>() : steps; }
    public List<ScenarioAttemptResult> getAttempts() { return attempts; }
    public void setAttempts(List<ScenarioAttemptResult> attempts) { this.attempts = attempts == null ? new ArrayList<>() : attempts; }
}
