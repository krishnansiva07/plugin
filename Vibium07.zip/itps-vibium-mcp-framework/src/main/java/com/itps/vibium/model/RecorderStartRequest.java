package com.itps.vibium.model;

public class RecorderStartRequest {
    private String applicationUrl;
    private String browserId;
    private String browserName;
    private String browserExecutable;
    private boolean allowInsecureCertificates = true;

    public String getApplicationUrl() { return applicationUrl; }
    public void setApplicationUrl(String applicationUrl) { this.applicationUrl = applicationUrl; }
    public String getBrowserId() { return browserId; }
    public void setBrowserId(String browserId) { this.browserId = browserId; }
    public String getBrowserName() { return browserName; }
    public void setBrowserName(String browserName) { this.browserName = browserName; }
    public String getBrowserExecutable() { return browserExecutable; }
    public void setBrowserExecutable(String browserExecutable) { this.browserExecutable = browserExecutable; }
    public boolean isAllowInsecureCertificates() { return allowInsecureCertificates; }
    public void setAllowInsecureCertificates(boolean allowInsecureCertificates) { this.allowInsecureCertificates = allowInsecureCertificates; }
}
