package com.itps.vibium.controller;

import com.itps.vibium.model.RecorderStartRequest;
import com.itps.vibium.service.UiRecorderService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/recorder")
public class RecorderController {
    private final UiRecorderService recorderService;

    public RecorderController(UiRecorderService recorderService) {
        this.recorderService = recorderService;
    }

    @PostMapping("/start")
    public ResponseEntity<?> start(@RequestBody RecorderStartRequest request) {
        try { return ResponseEntity.ok(recorderService.start(request)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", message(e))); }
    }

    @GetMapping("/{sessionId}")
    public ResponseEntity<?> status(@PathVariable String sessionId) {
        try { return ResponseEntity.ok(recorderService.get(sessionId)); }
        catch (NoSuchElementException e) { return ResponseEntity.status(404).body(Map.of("error", message(e))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", message(e))); }
    }

    @PostMapping("/{sessionId}/stop")
    public ResponseEntity<?> stop(@PathVariable String sessionId) {
        try { return ResponseEntity.ok(recorderService.stop(sessionId)); }
        catch (NoSuchElementException e) { return ResponseEntity.status(404).body(Map.of("error", message(e))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", message(e))); }
    }

    @DeleteMapping("/{sessionId}/actions/{sequence}")
    public ResponseEntity<?> deleteAction(@PathVariable String sessionId, @PathVariable int sequence) {
        try { return ResponseEntity.ok(recorderService.deleteAction(sessionId, sequence)); }
        catch (NoSuchElementException e) { return ResponseEntity.status(404).body(Map.of("error", message(e))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", message(e))); }
    }

    @GetMapping("/{sessionId}/recorded-steps.xlsx")
    public ResponseEntity<?> excel(@PathVariable String sessionId) {
        try {
            byte[] bytes = recorderService.excel(sessionId);
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .contentLength(bytes.length)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=recorded-steps-" + sessionId + ".xlsx")
                    .body(bytes);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(404).body(Map.of("error", message(e)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", message(e)));
        }
    }

    @GetMapping("/{sessionId}/recorded-actions.json")
    public ResponseEntity<?> json(@PathVariable String sessionId) {
        try {
            byte[] bytes = recorderService.json(sessionId);
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_JSON)
                    .contentLength(bytes.length)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=recorded-actions-" + sessionId + ".json")
                    .body(bytes);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(404).body(Map.of("error", message(e)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", message(e)));
        }
    }

    private String message(Exception e) {
        return e.getMessage() == null || e.getMessage().isBlank() ? e.getClass().getSimpleName() : e.getMessage();
    }
}
