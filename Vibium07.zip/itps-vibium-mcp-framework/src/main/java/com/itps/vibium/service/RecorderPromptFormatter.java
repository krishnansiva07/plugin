package com.itps.vibium.service;

import com.itps.vibium.model.RecordedAction;

import java.util.Locale;

/** Converts structured recorder events into the framework's existing Excel step syntax. */
public final class RecorderPromptFormatter {
    private RecorderPromptFormatter() { }

    public static String format(RecordedAction action) {
        if (action == null) return "";
        String kind = text(action.getAction()).toUpperCase(Locale.ROOT);
        String name = defaultText(action.getElementName(), "element");
        String value = text(action.getValue());
        String locatorType = "XPATH".equalsIgnoreCase(action.getLocatorType()) ? "xpath" : "css";
        String locator = text(action.getLocator());
        String locatorClause = locator.isBlank() ? "" : " using " + locatorType + "=\"" + escapeLocator(locator) + "\"";

        return switch (kind) {
            case "TYPE", "FILL", "INPUT" -> "Type \"" + escapeLiteral(value) + "\" in \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "SELECT" -> "Select \"" + escapeLiteral(value) + "\" from \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "CHECK" -> "Check \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "UNCHECK" -> "Uncheck \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "DOUBLE_CLICK" -> "Double-click \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "PRESS" -> "Press \"" + escapeLiteral(value) + "\" on \"" + escapeLiteral(name) + "\"" + locatorClause;
            case "UPLOAD" -> "Upload \"" + escapeLiteral(value) + "\" in \"" + escapeLiteral(name) + "\"" + locatorClause;
            default -> "Click \"" + escapeLiteral(name) + "\"" + locatorClause;
        };
    }

    private static String defaultText(String value, String fallback) {
        String normalized = text(value);
        return normalized.isBlank() ? fallback : normalized;
    }

    private static String text(String value) {
        return value == null ? "" : value.replaceAll("\\s+", " ").trim();
    }

    private static String escapeLiteral(String value) {
        return text(value).replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String escapeLocator(String value) {
        return text(value).replace("\"", "\\\"");
    }
}
