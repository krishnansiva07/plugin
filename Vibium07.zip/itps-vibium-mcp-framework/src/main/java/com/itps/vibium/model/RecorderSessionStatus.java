package com.itps.vibium.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class RecorderSessionStatus {
    private String sessionId;
    private String state;
    private String applicationUrl;
    private String browserName;
    private Instant startedAt;
    private Instant stoppedAt;
    private String message;
    private String currentPageUrl;
    private String currentPageTitle;
    private List<RecordedAction> actions = new ArrayList<>();

    public String getSessionId() { return sessionId; }
    public void setSessionId(String sessionId) { this.sessionId = sessionId; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getApplicationUrl() { return applicationUrl; }
    public void setApplicationUrl(String applicationUrl) { this.applicationUrl = applicationUrl; }
    public String getBrowserName() { return browserName; }
    public void setBrowserName(String browserName) { this.browserName = browserName; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getStoppedAt() { return stoppedAt; }
    public void setStoppedAt(Instant stoppedAt) { this.stoppedAt = stoppedAt; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getCurrentPageUrl() { return currentPageUrl; }
    public void setCurrentPageUrl(String currentPageUrl) { this.currentPageUrl = currentPageUrl; }
    public String getCurrentPageTitle() { return currentPageTitle; }
    public void setCurrentPageTitle(String currentPageTitle) { this.currentPageTitle = currentPageTitle; }
    public List<RecordedAction> getActions() { return actions; }
    public void setActions(List<RecordedAction> actions) { this.actions = actions == null ? new ArrayList<>() : actions; }
}
