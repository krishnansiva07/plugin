package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Recovers from Chrome's certificate interstitial for approved internal test environments.
 *
 * <p>Current Vibium MCP versions expose only {@code headless} on {@code browser_start}; they do
 * not expose WebDriver's {@code acceptInsecureCerts} capability. When an internal HTTPS site uses
 * a private/self-signed certificate, {@code browser_navigate} can therefore return a generic BiDi
 * navigation error while Chrome displays "Your connection is not private". This helper detects
 * that interstitial, opens Advanced, selects Proceed, and retries the original navigation.</p>
 */
public final class InsecureCertificateRecovery {
    private static final List<String> PRIVACY_MARKERS = List.of(
            "your connection is not private",
            "privacy error",
            "net::err_cert",
            "err_cert_",
            "attackers might be trying",
            "certificate is not trusted",
            "certificate authority is invalid"
    );

    private InsecureCertificateRecovery() { }

    public record Outcome(boolean recovered, JsonNode navigationResult, String evidence) { }

    public static boolean canAttempt(String url, boolean enabled) {
        if (!enabled || url == null || url.isBlank()) return false;
        try {
            return "https".equalsIgnoreCase(URI.create(url.trim()).getScheme());
        } catch (Exception ignored) {
            return false;
        }
    }

    public static Outcome recover(McpClient mcp,
                                  McpToolCatalog catalog,
                                  String url,
                                  ObjectMapper mapper) {
        List<String> evidence = new ArrayList<>();
        if (!canAttempt(url, true)) {
            return new Outcome(false, null, "Certificate recovery was not attempted because the URL is not HTTPS.");
        }

        try {
            String initialState = readPageState(mcp, catalog);
            boolean privacyPageDetected = containsPrivacyMarker(initialState);
            evidence.add("privacyPageDetected=" + privacyPageDetected);

            boolean advancedClicked = clickQuietly(mcp, catalog, "#details-button", 3_000, evidence);
            if (!advancedClicked) {
                advancedClicked = clickQuietly(mcp, catalog,
                        "button[id*='details'],button[class*='advanced'],#advancedButton", 3_000, evidence);
            }
            if (advancedClicked) sleep(250);

            boolean proceedClicked = clickQuietly(mcp, catalog, "#proceed-link", 5_000, evidence);
            if (!proceedClicked) {
                proceedClicked = clickQuietly(mcp, catalog,
                        "a[id*='proceed'],button[id*='proceed'],a[href*='proceed']", 5_000, evidence);
            }

            if (!proceedClicked) {
                proceedClicked = evaluateInterstitialQuietly(mcp, catalog, evidence);
            }

            // Chrome also supports a well-known interstitial bypass phrase. It is used only as a
            // final fallback and only after an HTTPS navigation failure with the UI option enabled.
            if (!proceedClicked) {
                proceedClicked = typeBypassPhraseQuietly(mcp, catalog, evidence);
            }

            if (proceedClicked) {
                sleep(700);
                callWaitQuietly(mcp, catalog, evidence);
            }

            JsonNode retryResult = retryNavigation(mcp, catalog, url, evidence);
            if (!isToolFailure(retryResult)) {
                evidence.add("navigationRetry=success");
                return new Outcome(true, retryResult, String.join("; ", evidence));
            }

            // In some Chrome versions clicking Proceed completes the navigation, while a second
            // navigate command still reports the original BiDi error. Verify the live page before
            // declaring recovery unsuccessful.
            String finalState = readPageState(mcp, catalog);
            if (matchesTargetUrl(finalState, url) && !containsPrivacyMarker(finalState)) {
                evidence.add("targetPageVerifiedAfterProceed=true");
                return new Outcome(true, syntheticSuccess(mapper, url, evidence), String.join("; ", evidence));
            }

            evidence.add("navigationRetry=failure");
            evidence.add("finalState=" + compact(finalState, 500));
            return new Outcome(false, retryResult, String.join("; ", evidence));
        } catch (Exception e) {
            evidence.add("recoveryException=" + compact(e.getMessage(), 500));
            return new Outcome(false, null, String.join("; ", evidence));
        }
    }

    private static JsonNode retryNavigation(McpClient mcp,
                                            McpToolCatalog catalog,
                                            String url,
                                            List<String> evidence) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(
                () -> new IllegalStateException("Vibium MCP does not expose browser_navigate."));
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(navigate, "url")) args.put("url", url);
        else if (schemaContains(navigate, "uri")) args.put("uri", url);
        else if (schemaContains(navigate, "href")) args.put("href", url);
        else args.put("target", url);
        JsonNode result = mcp.callTool(navigate.getName(), args);
        if (isToolFailure(result)) evidence.add("retryResult=" + compact(extractText(result), 350));
        return result;
    }

    private static boolean clickQuietly(McpClient mcp,
                                        McpToolCatalog catalog,
                                        String selector,
                                        int timeoutMs,
                                        List<String> evidence) {
        Optional<McpTool> click = catalog.clickTool();
        if (click.isEmpty()) return false;
        try {
            Map<String, Object> args = new LinkedHashMap<>();
            if (schemaContains(click.get(), "selector")) args.put("selector", selector);
            else if (schemaContains(click.get(), "target")) args.put("target", selector);
            else return false;
            if (schemaContains(click.get(), "timeout")) args.put("timeout", timeoutMs);
            JsonNode result = mcp.callTool(click.get().getName(), args);
            boolean success = !isToolFailure(result);
            evidence.add("click(" + selector + ")=" + success);
            return success;
        } catch (Exception e) {
            evidence.add("click(" + selector + ")=false:" + compact(e.getMessage(), 180));
            return false;
        }
    }

    private static boolean evaluateInterstitialQuietly(McpClient mcp,
                                                       McpToolCatalog catalog,
                                                       List<String> evidence) {
        Optional<McpTool> evaluate = catalog.evaluateTool();
        if (evaluate.isEmpty()) return false;
        String script = """
                (async () => {
                  const visible = element => {
                    if (!element) return false;
                    const style = getComputedStyle(element);
                    const rect = element.getBoundingClientRect();
                    return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
                  };
                  const details = document.querySelector('#details-button,button[id*=details],button[class*=advanced],#advancedButton');
                  if (details && visible(details)) details.click();
                  await new Promise(resolve => setTimeout(resolve, 250));
                  const proceed = document.querySelector('#proceed-link,a[id*=proceed],button[id*=proceed],a[href*=proceed]');
                  if (proceed && visible(proceed)) {
                    proceed.click();
                    return JSON.stringify({ok:true,strategy:'certificate-interstitial-dom'});
                  }
                  return JSON.stringify({ok:false,title:document.title,text:(document.body?.innerText||'').slice(0,500)});
                })()
                """;
        try {
            Map<String, Object> args = new LinkedHashMap<>();
            if (schemaContains(evaluate.get(), "expression")) args.put("expression", script);
            else if (schemaContains(evaluate.get(), "script")) args.put("script", script);
            else if (schemaContains(evaluate.get(), "code")) args.put("code", script);
            else return false;
            JsonNode result = mcp.callTool(evaluate.get().getName(), args);
            String resultText = extractText(result).toLowerCase(Locale.ROOT).replaceAll("\\s+", "");
            boolean success = !isToolFailure(result) &&
                    (resultText.contains("\"ok\":true") || resultText.contains("ok:true"));
            evidence.add("evaluateInterstitial=" + success);
            return success;
        } catch (Exception e) {
            evidence.add("evaluateInterstitial=false:" + compact(e.getMessage(), 180));
            return false;
        }
    }

    private static boolean typeBypassPhraseQuietly(McpClient mcp,
                                                   McpToolCatalog catalog,
                                                   List<String> evidence) {
        Optional<McpTool> keys = catalog.findByName("browser_keys");
        if (keys.isEmpty()) return false;
        try {
            for (char character : "thisisunsafe".toCharArray()) {
                Map<String, Object> args = new LinkedHashMap<>();
                if (schemaContains(keys.get(), "keys")) args.put("keys", String.valueOf(character));
                else if (schemaContains(keys.get(), "key")) args.put("key", String.valueOf(character));
                else return false;
                JsonNode result = mcp.callTool(keys.get().getName(), args);
                if (isToolFailure(result)) return false;
            }
            evidence.add("typedChromeBypassPhrase=true");
            return true;
        } catch (Exception e) {
            evidence.add("typedChromeBypassPhrase=false:" + compact(e.getMessage(), 180));
            return false;
        }
    }

    private static void callWaitQuietly(McpClient mcp,
                                        McpToolCatalog catalog,
                                        List<String> evidence) {
        try {
            if (catalog.waitTool().isPresent()) {
                JsonNode result = mcp.callTool(catalog.waitTool().get().getName(), Map.of());
                evidence.add("waitAfterProceed=" + !isToolFailure(result));
            }
        } catch (Exception e) {
            evidence.add("waitAfterProceed=false:" + compact(e.getMessage(), 150));
        }
    }

    private static String readPageState(McpClient mcp, McpToolCatalog catalog) {
        StringBuilder state = new StringBuilder();
        appendToolText(mcp, catalog.urlTool(), state);
        appendToolText(mcp, catalog.titleTool(), state);
        appendToolText(mcp, catalog.textTool(), state);
        return state.toString();
    }

    private static void appendToolText(McpClient mcp,
                                       Optional<McpTool> tool,
                                       StringBuilder state) {
        if (tool.isEmpty()) return;
        try {
            JsonNode result = mcp.callTool(tool.get().getName(), Map.of());
            state.append(' ').append(extractText(result));
        } catch (Exception ignored) { }
    }

    static boolean containsPrivacyMarker(String value) {
        String lower = value == null ? "" : value.toLowerCase(Locale.ROOT);
        return PRIVACY_MARKERS.stream().anyMatch(lower::contains);
    }

    private static boolean matchesTargetUrl(String state, String targetUrl) {
        if (state == null || targetUrl == null) return false;
        try {
            URI target = URI.create(targetUrl.trim());
            String host = target.getHost();
            if (host == null || host.isBlank()) return state.contains(targetUrl);
            String lower = state.toLowerCase(Locale.ROOT);
            if (!lower.contains(host.toLowerCase(Locale.ROOT))) return false;
            String path = target.getPath();
            return path == null || path.isBlank() || "/".equals(path) || lower.contains(path.toLowerCase(Locale.ROOT));
        } catch (Exception ignored) {
            return state.contains(targetUrl);
        }
    }

    static boolean isToolFailure(JsonNode result) {
        if (result == null || result.isMissingNode() || result.isNull()) return false;
        if (result.path("isError").asBoolean(false)) return true;
        String text = extractText(result).toLowerCase(Locale.ROOT);
        return text.contains("failed to navigate") || text.contains("bidi error") ||
                text.contains("timed out") || text.contains("timeout") ||
                text.contains("unable to navigate") || text.contains("cannot navigate");
    }

    private static ObjectNode syntheticSuccess(ObjectMapper mapper,
                                               String url,
                                               List<String> evidence) {
        ObjectNode out = mapper.createObjectNode();
        out.put("isError", false);
        ArrayNode content = out.putArray("content");
        content.addObject()
                .put("type", "text")
                .put("text", "Internal certificate warning bypassed and target page verified: " + url);
        out.put("certificateRecovery", true);
        out.put("evidence", String.join("; ", evidence));
        return out;
    }

    private static boolean schemaContains(McpTool tool, String property) {
        if (tool == null || property == null || tool.getInputSchema() == null) return false;
        JsonNode properties = tool.getInputSchema().path("properties");
        if (properties.has(property)) return true;
        return tool.getInputSchema().toString().toLowerCase(Locale.ROOT)
                .contains("\"" + property.toLowerCase(Locale.ROOT) + "\"");
    }

    static String extractText(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return "";
        if (node.isTextual()) return node.asText();
        StringBuilder out = new StringBuilder();
        if (node.isArray()) {
            node.forEach(child -> {
                String text = extractText(child);
                if (!text.isBlank()) out.append(' ').append(text);
            });
        } else if (node.isObject()) {
            node.fields().forEachRemaining(entry -> {
                if ("data".equalsIgnoreCase(entry.getKey()) && entry.getValue().isTextual()
                        && entry.getValue().asText().length() > 5_000) return;
                String text = extractText(entry.getValue());
                if (!text.isBlank()) out.append(' ').append(text);
            });
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static String compact(String value, int max) {
        if (value == null) return "";
        String oneLine = value.replaceAll("\\s+", " ").trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "...";
    }
}
