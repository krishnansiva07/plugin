package com.itps.vibium.model;

/** Optional cookie supplied by the user and added after the first page navigation. */
public class AdditionalCookie {
    private String name;
    private String value;

    public AdditionalCookie() { }

    public AdditionalCookie(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
}
