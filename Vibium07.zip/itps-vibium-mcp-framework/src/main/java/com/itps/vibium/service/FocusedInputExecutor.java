package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RunConfig;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deterministic typing for steps such as {@code Type "BCEF"} after a field was clicked. */
final class FocusedInputExecutor {
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");
    private final ObjectMapper mapper;

    FocusedInputExecutor(ObjectMapper mapper) { this.mapper = Objects.requireNonNull(mapper, "mapper"); }

    boolean supports(String instruction) {
        String lower = LiveXPathActionExecutor.normalizeSmartQuotes(instruction == null ? "" : instruction)
                .trim().toLowerCase(Locale.ROOT);
        if (!(lower.startsWith("type ") || lower.startsWith("enter ") || lower.startsWith("fill ") || lower.startsWith("input "))) return false;
        return !containsAny(lower, " xpath", " selector", " into ", " in field", " in the ");
    }

    Execution execute(McpClient mcp, McpToolCatalog catalog, String instruction, RunConfig config) throws Exception {
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("Focused-input typing requires Vibium browser_evaluate."));
        McpTool fill = catalog.fillTool().orElse(null);
        String value = extractValue(instruction);
        if (value.isBlank()) throw new IllegalArgumentException("Unable to extract text to type from step: " + instruction);

        int timeoutMs = Math.max(5_000, Math.max(1, config.getStepTimeoutSeconds()) * 1_000);
        int attempts = Math.max(2, Math.min(4, config.getRetryCount() + 2));
        String marker = "itps-focus-" + UUID.randomUUID().toString().replace("-", "");
        ObjectNode audit = mapper.createObjectNode();
        audit.put("strategy", "FOCUSED_INPUT_NATIVE_FILL");
        audit.put("value", value);
        audit.put("timeoutMs", timeoutMs);
        audit.put("attemptLimit", attempts);
        ArrayNode phases = audit.putArray("phases");
        Exception lastError = null;

        try {
            for (int attempt = 1; attempt <= attempts; attempt++) {
                cleanup(mcp, evaluate, marker);
                JsonNode resolved = resolveFocusedInput(mcp, evaluate, marker, timeoutMs);
                ObjectNode resolutionPhase = phase("RESOLVE_FOCUSED_INPUT", resolved, attempt);
                phases.add(resolutionPhase);
                if (!resolved.path("found").asBoolean(false)) {
                    lastError = new IllegalStateException("NO_FOCUSED_OR_ACTIVE_COMBOBOX_INPUT: " + compact(resolved.toString(), 3_000) +
                            ". Prefer: Type \"" + value + "\" using xpath=\"...\".");
                    if (attempt < attempts) { sleep(Math.max(150, config.getRetryDelayMs())); continue; }
                    throw lastError;
                }

                String selector = "[data-itps-action-id=\"" + marker + "\"]";
                String toolName = evaluate.getName();
                Map<String, Object> args = Map.of("phase", "DOM_FILL_FALLBACK");
                JsonNode raw = mapper.createObjectNode();
                String interactionMode = "";

                try {
                    if (fill != null && resolved.path("nativeReachable").asBoolean(false) && acceptsSelector(fill)) {
                        args = fillArgs(fill, selector, value, timeoutMs);
                        raw = mcp.callTool(fill.getName(), args);
                        assertToolSuccess(fill.getName(), raw);
                        toolName = fill.getName();
                        interactionMode = "NATIVE_VIBIUM_FILL";
                    } else {
                        args = evaluateArgs(evaluate, domFillScript(marker, value));
                        raw = mcp.callTool(evaluate.getName(), args);
                        assertToolSuccess(evaluate.getName(), raw);
                        JsonNode unwrapped = unwrapJsonString(raw);
                        if (!unwrapped.path("performed").asBoolean(false))
                            throw new IllegalStateException("Focused input DOM fill fallback failed: " + compact(unwrapped.toString(), 2_000));
                        interactionMode = "DOM_FILL_FALLBACK";
                    }

                    sleep(Math.min(800, Math.max(180, config.getRetryDelayMs())));
                    JsonNode verified = evaluateJson(mcp, evaluate, verifyScript(marker, value));
                    ObjectNode verificationPhase = phase("VERIFY_FINAL_INPUT_VALUE", verified, attempt);
                    verificationPhase.put("interactionMode", interactionMode);
                    phases.add(verificationPhase);
                    if (!verified.path("confirmed").asBoolean(false)) {
                        throw new IllegalStateException("TEXT_WAS_NOT_APPLIED_TO_FOCUSED_INPUT: " + compact(verified.toString(), 3_000));
                    }

                    audit.put("interactionMode", interactionMode);
                    audit.set("finalResolution", resolved);
                    audit.set("finalVerification", verified);
                    ObjectNode action = mapper.createObjectNode();
                    action.put("type", "FOCUSED_INPUT_FILL");
                    action.put("value", value);
                    return new Execution("FOCUSED_INPUT_NATIVE_FILL", action.toString(), toolName,
                            mapper.writeValueAsString(List.of(args)), compact(raw.toString(), 10_000),
                            "The current active/expanded combobox input was freshly resolved, filled, and verified as '" + value + "'.", audit);
                } catch (Exception actionError) {
                    lastError = actionError;
                    ObjectNode errorPhase = mapper.createObjectNode();
                    errorPhase.put("name", "FOCUSED_INPUT_ATTEMPT_FAILED");
                    errorPhase.put("attempt", attempt);
                    errorPhase.put("error", compact(actionError.getMessage(), 2_000));
                    phases.add(errorPhase);
                    if (attempt < attempts) sleep(Math.max(150, config.getRetryDelayMs()));
                }
            }
            throw lastError == null ? new IllegalStateException("Focused input execution failed without diagnostic") : lastError;
        } finally {
            cleanup(mcp, evaluate, marker);
        }
    }

    private JsonNode resolveFocusedInput(McpClient mcp, McpTool evaluate, String marker, int timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        JsonNode last = mapper.createObjectNode();
        while (System.currentTimeMillis() < deadline) {
            last = evaluateJson(mcp, evaluate, resolveScript(marker));
            if (last.path("found").asBoolean(false)) return last;
            sleep(120);
        }
        return last;
    }

    private String resolveScript(String marker) {
        return """
                (()=>{
                  const marker=%s;
                  const visible=e=>{if(!e||!(e instanceof Element)||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const editable=e=>!!e&&e.matches?.('input:not([type="hidden"]):not([disabled]),textarea:not([disabled]),[contenteditable="true"]');
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  const allRoots=[];for(const d of docs)allRoots.push(...roots(d));
                  const deepQuery=selector=>{const out=[];for(const r of allRoots){try{out.push(...r.querySelectorAll(selector));}catch(ignore){}}return out;};
                  for(const r of allRoots)for(const old of r.querySelectorAll?.(`[data-itps-action-id="${marker}"]`)||[])old.removeAttribute('data-itps-action-id');
                  let target=null,reason='';
                  for(const r of allRoots){const a=r.activeElement;if(editable(a)&&visible(a)){target=a;reason='DEEP_ACTIVE_ELEMENT';break;}}
                  if(!target){
                    const overlays=deepQuery('[role="listbox"],.cdk-overlay-pane,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown').filter(visible).sort((a,b)=>Number(b.style?.zIndex||0)-Number(a.style?.zIndex||0));
                    for(const root of overlays){const i=[...root.querySelectorAll('input:not([type="hidden"]),textarea,[contenteditable="true"]')].find(e=>editable(e)&&visible(e));if(i){target=i;reason='ACTIVE_OVERLAY_INPUT';break;}}
                  }
                  if(!target){
                    const expanded=deepQuery('[role="combobox"][aria-expanded="true"],.ng-select.ng-select-opened,.ant-select-open,.p-inputwrapper-focus').filter(visible);
                    for(const c of expanded){const i=[...c.querySelectorAll('input:not([type="hidden"]),textarea,[contenteditable="true"]')].find(e=>editable(e)&&visible(e));if(i){target=i;reason='EXPANDED_COMBOBOX_INPUT';break;}}
                  }
                  if(!target)return JSON.stringify({found:false,reason:'NO_ACTIVE_EDITABLE_INPUT',active:document.activeElement?{tag:document.activeElement.tagName,id:document.activeElement.id||'',class:String(document.activeElement.className||'').slice(0,150)}:null});
                  target.setAttribute('data-itps-action-id',marker);target.focus?.({preventScroll:true});
                  return JSON.stringify({found:true,reason,nativeReachable:target.ownerDocument===document&&target.getRootNode()===document,tag:target.tagName,id:target.id||'',role:target.getAttribute?.('role')||'',currentValue:String(target.value||'')});
                })()
                """.formatted(js(marker));
    }

    private String domFillScript(String marker, String value) {
        return """
                (()=>{const marker=%s,value=%s;const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const n of out[i].querySelectorAll?.('*')||[])if(n.shadowRoot)out.push(n.shadowRoot);return out;};let e=null;for(const d of docs){for(const r of roots(d)){e=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(e)break;}if(e)break;}if(!e)return JSON.stringify({performed:false,reason:'MARKER_NOT_FOUND'});e.focus();if(e.isContentEditable)e.textContent=value;else{const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;if(setter)setter.call(e,value);else e.value=value;}try{e.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:value}));}catch(ignore){e.dispatchEvent(new Event('input',{bubbles:true,composed:true}));}e.dispatchEvent(new Event('change',{bubbles:true,composed:true}));return JSON.stringify({performed:true,finalValue:String(e.value||e.textContent||'')});})()
                """.formatted(js(marker), js(value));
    }

    private String verifyScript(String marker, String value) {
        return """
                (()=>{const marker=%s,wanted=%s,norm=v=>String(v??'').replace(/\\s+/g,' ').trim();const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const n of out[i].querySelectorAll?.('*')||[])if(n.shadowRoot)out.push(n.shadowRoot);return out;};let e=null;for(const d of docs){for(const r of roots(d)){e=r.querySelector?.(`[data-itps-action-id="${marker}"]`)||r.activeElement;if(e&&('value'in e||e.isContentEditable))break;}if(e&&('value'in e||e.isContentEditable))break;}const finalValue=e&&('value'in e)?String(e.value||''):String(e?.textContent||'');return JSON.stringify({confirmed:norm(finalValue)===norm(wanted),finalValue,wanted,tag:e?.tagName||''});})()
                """.formatted(js(marker), js(value));
    }

    private void cleanup(McpClient mcp, McpTool evaluate, String marker) {
        try {
            evaluateJson(mcp, evaluate, """
                    (()=>{const marker=%s;const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const n of out[i].querySelectorAll?.('*')||[])if(n.shadowRoot)out.push(n.shadowRoot);return out;};let removed=0;for(const d of docs)for(const r of roots(d))for(const e of r.querySelectorAll?.(`[data-itps-action-id="${marker}"]`)||[]){e.removeAttribute('data-itps-action-id');removed++;}return JSON.stringify({removed});})()
                    """.formatted(js(marker)));
        } catch (Exception ignored) { }
    }

    private ObjectNode phase(String name, JsonNode details, int attempt) {
        ObjectNode phase = mapper.createObjectNode();
        phase.put("name", name);
        phase.put("attempt", attempt);
        phase.set("details", details == null ? mapper.nullNode() : details);
        return phase;
    }

    private String extractValue(String instruction) {
        String normalized = LiveXPathActionExecutor.normalizeSmartQuotes(instruction);
        Matcher quoted = QUOTED.matcher(normalized);
        if (quoted.find()) return quoted.group(1).trim();
        Matcher plain = Pattern.compile("(?i)^(?:type|enter|fill|input)\\s+(.+)$").matcher(normalized.trim());
        return plain.find() ? plain.group(1).trim() : "";
    }

    private boolean acceptsSelector(McpTool tool) {
        return schemaContains(tool, "selector") || schemaContains(tool, "locator") || schemaContains(tool, "target");
    }

    private Map<String, Object> fillArgs(McpTool tool, String selector, String value, int timeoutMs) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "selector")) args.put("selector", selector);
        else if (schemaContains(tool, "locator")) args.put("locator", selector);
        else args.put("target", selector);
        if (schemaContains(tool, "text")) args.put("text", value);
        else if (schemaContains(tool, "value")) args.put("value", value);
        else if (schemaContains(tool, "input")) args.put("input", value);
        else args.put("text", value);
        if (schemaContains(tool, "timeout")) args.put("timeout", timeoutMs);
        return args;
    }

    private JsonNode evaluateJson(McpClient mcp, McpTool evaluate, String script) throws Exception {
        JsonNode raw = mcp.callTool(evaluate.getName(), evaluateArgs(evaluate, script));
        assertToolSuccess(evaluate.getName(), raw);
        return unwrapJsonString(raw);
    }

    private Map<String, Object> evaluateArgs(McpTool evaluate, String script) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(evaluate, "expression")) args.put("expression", script);
        else if (schemaContains(evaluate, "script")) args.put("script", script);
        else args.put("code", script);
        return args;
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        List<String> texts = new ArrayList<>(); collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String t : texts) { String s=t==null?"":t.trim(); if(s.startsWith("{")||s.startsWith("["))try{return mapper.readTree(s);}catch(Exception ignored){} }
        return raw == null ? mapper.createObjectNode() : raw;
    }
    private void collectText(JsonNode n,List<String> out){if(n==null)return;if(n.isTextual())out.add(n.asText());else if(n.isArray())for(JsonNode c:n)collectText(c,out);else if(n.isObject())n.fields().forEachRemaining(e->collectText(e.getValue(),out));}
    private void assertToolSuccess(String tool,JsonNode result){if(result==null)return;if(result.path("isError").asBoolean(false))throw new IllegalStateException("MCP tool failed for "+tool+": "+compact(result.toString(),2000));String t=extractText(result).toLowerCase(Locale.ROOT);for(String f:List.of("invalid selector","timed out","timeout","element not found","exception","detached"))if(t.contains(f))throw new IllegalStateException("MCP tool failed for "+tool+": "+compact(t,2000));}
    private String extractText(JsonNode n){if(n==null)return"";if(n.isValueNode())return n.asText("");StringBuilder b=new StringBuilder();if(n.isArray())for(JsonNode c:n)b.append(' ').append(extractText(c));else n.fields().forEachRemaining(e->b.append(' ').append(extractText(e.getValue())));return b.toString();}
    private boolean schemaContains(McpTool t,String term){return t!=null&&t.getInputSchema()!=null&&t.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));}
    private boolean containsAny(String text,String...terms){for(String term:terms)if(text.contains(term))return true;return false;}
    private String js(String v){try{return mapper.writeValueAsString(v==null?"":v);}catch(Exception e){return"\"\"";}}
    private String compact(String t,int max){if(t==null)return"";String c=t.replaceAll("\\s+"," ").trim();return c.length()<=max?c:c.substring(0,max)+"...";}
    private void sleep(long millis){try{Thread.sleep(Math.max(1,millis));}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException("Interrupted while resolving focused input",e);}}

    record Execution(String planSource, String actionJson, String toolName, String toolArguments,
                     String mcpResult, String evidence, JsonNode audit) { }
}
