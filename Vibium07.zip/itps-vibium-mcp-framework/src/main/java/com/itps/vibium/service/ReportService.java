package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.itps.vibium.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ReportService {
    private final ObjectMapper mapper;

    public ReportService() {
        mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    public void writeReports(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        List<String> failures = new ArrayList<>();

        attempt("detailed attachment HTML", failures, () -> writeDetailedHtml(status, runDir.resolve("report.html")));
        attempt("Outlook body HTML", failures, () -> writeOutlookHtml(status, runDir.resolve("outlook-report.html")));
        attempt("standalone screenshot HTML", failures, () -> writeScreenshotHtml(status, runDir, runDir.resolve("screenshots-report.html")));
        attempt("Excel report", failures, () -> writeExcel(status, runDir.resolve("report.xlsx")));
        attempt("screenshots ZIP", failures, () -> zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip")));
        attempt("JSON report", failures, () -> mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("report.json").toFile(), status));

        if (!failures.isEmpty()) {
            Files.writeString(runDir.resolve("report-generation.log"), String.join(System.lineSeparator(), failures), StandardCharsets.UTF_8);
        }
        if (!Files.exists(runDir.resolve("report.html"))) {
            throw new IllegalStateException("Detailed report could not be generated: " + String.join(" | ", failures));
        }
    }

    public void writeFallbackHtml(RunStatus status, Path runDir, Exception error) throws Exception {
        Files.createDirectories(runDir);
        String body = "<header><div class='brand'>ITPS VIBIUM Framework</div><h1>Automation report</h1></header>" +
                "<section class='panel message'><h2>Report generation problem</h2><p>Run: " + esc(status == null ? "" : status.getRunId()) + "</p><pre>" + esc(error == null ? "Unknown error" : error.toString()) + "</pre></section>";
        if (!Files.exists(runDir.resolve("report.html"))) {
            Files.writeString(runDir.resolve("report.html"), shell("Automation Report", body), StandardCharsets.UTF_8);
        }
        if (!Files.exists(runDir.resolve("outlook-report.html"))) {
            String outlook = "<!doctype html><html><body style='font-family:Arial,sans-serif'><h2>Automation Report</h2><p>Report generation failed for run "
                    + esc(status == null ? "" : status.getRunId()) + ".</p></body></html>";
            Files.writeString(runDir.resolve("outlook-report.html"), outlook, StandardCharsets.UTF_8);
        }
    }

    /** Full HTML intended to be attached to an email. It contains every scenario, every rerun attempt and all step details. */
    private void writeDetailedHtml(RunStatus s, Path file) throws Exception {
        StringBuilder cards = new StringBuilder();
        for (ScenarioResult r : s.getScenarios()) {
            String status = normalizedStatus(r.getStatus());
            String recovery = recoveryType(r);
            cards.append("<article class='scenario-card' data-status='").append(escAttr(status))
                    .append("' data-recovery='").append(escAttr(recovery)).append("'><div class='scenario-head'><div><h2>")
                    .append(esc(r.getName())).append("</h2><p>").append(esc(r.getId())).append(" · ")
                    .append(formatDuration(r.getDurationMs())).append(" · Attempts ").append(Math.max(0, r.getAttemptCount()))
                    .append("/").append(Math.max(1, r.getMaxAttempts())).append("</p></div><span class='pill ")
                    .append(statusClass(status)).append("'>").append(esc(status)).append("</span></div>");
            if (notBlank(r.getErrorMessage())) {
                cards.append("<div class='error-box'>").append(esc(r.getErrorMessage())).append("</div>");
            }
            cards.append(renderAttempts(r));
            cards.append("</article>");
        }

        String body = header(s, "Automation report — detailed attachment") +
                "<section class='filters'><input id='q' placeholder='Search scenario, test ID, instruction or error'>" +
                "<select id='statusFilter'><option value=''>All statuses</option><option>PASSED</option><option>PASSED_HEALED</option><option>PASSED_AFTER_RERUN</option><option>FAILED</option><option>PENDING</option></select>" +
                "<select id='recoveryFilter'><option value=''>All execution types</option><option value='CLEAN'>Clean pass</option><option value='HEALED'>LangGraph healed</option><option value='RERUN'>Passed after rerun</option><option value='FAILED'>Failed</option><option value='PENDING'>Pending/not executed</option></select></section>" +
                "<section id='scenarioList'>" + cards + "</section>" + detailedFilterScript();
        Files.writeString(file, shell("Automation Report - Detailed", body), StandardCharsets.UTF_8);
    }

    private String renderAttempts(ScenarioResult result) {
        List<ScenarioAttemptResult> attempts = result.getAttempts();
        if (attempts == null || attempts.isEmpty()) {
            ScenarioAttemptResult only = new ScenarioAttemptResult();
            only.setAttemptNo(Math.max(1, result.getAttemptCount()));
            only.setStatus(result.getStatus());
            only.setDurationMs(result.getDurationMs());
            only.setErrorMessage(result.getErrorMessage());
            only.setSteps(result.getSteps());
            attempts = List.of(only);
        }
        StringBuilder html = new StringBuilder("<div class='attempts'>");
        for (ScenarioAttemptResult attempt : attempts) {
            String attemptStatus = normalizedStatus(attempt.getStatus());
            html.append("<details class='attempt' ").append(attempt.getAttemptNo() == attempts.size() ? "open" : "")
                    .append("><summary>Attempt ").append(attempt.getAttemptNo()).append(" · <span class='pill ")
                    .append(statusClass(attemptStatus)).append("'>").append(esc(attemptStatus)).append("</span> · ")
                    .append(formatDuration(attempt.getDurationMs())).append("</summary>");
            if (notBlank(attempt.getErrorMessage())) html.append("<div class='error-box'>").append(esc(attempt.getErrorMessage())).append("</div>");
            html.append(renderStepTable(attempt.getSteps()));
            html.append("</details>");
        }
        return html.append("</div>").toString();
    }

    private String renderStepTable(List<StepResult> steps) {
        if (steps == null || steps.isEmpty()) return "<p class='muted'>No step details were recorded.</p>";
        StringBuilder rows = new StringBuilder();
        for (StepResult st : steps) {
            String status = normalizedStatus(st.getStatus());
            rows.append("<tr><td>").append(st.getStepNo()).append("</td><td>").append(esc(st.getInstruction())).append("</td><td><span class='pill ")
                    .append(statusClass(status)).append("'>").append(esc(status)).append("</span></td><td>")
                    .append(esc(st.getPlanSource())).append("</td><td>").append(esc(st.getToolName())).append("</td><td>")
                    .append(esc(shortText(st.getEvidence(), 700))).append("</td><td><pre>").append(esc(st.getHealingHistory())).append("</pre></td><td>")
                    .append(formatDuration(st.getDurationMs())).append("</td><td>")
                    .append(esc(st.getErrorMessage())).append("</td></tr>");
        }
        return "<div class='table-panel'><table class='step-table'><thead><tr><th>#</th><th>Instruction</th><th>Status</th><th>Plan</th><th>MCP tool</th><th>Evidence</th><th>Healing / LangGraph history</th><th>Duration</th><th>Error</th></tr></thead><tbody>" + rows + "</tbody></table></div>";
    }

    /**
     * Standalone screenshot attachment. Images are embedded as data URIs so the report remains
     * viewable after it is attached to an email; it has no dependency on framework HTTP links.
     */
    private void writeScreenshotHtml(RunStatus status, Path runDir, Path file) throws Exception {
        Path screenshotDir = runDir.resolve("screenshots").normalize();
        StringBuilder cards = new StringBuilder();
        int imageCount = 0;

        for (ScenarioResult scenario : status.getScenarios()) {
            List<ScenarioAttemptResult> attempts = scenario.getAttempts();
            if (attempts == null || attempts.isEmpty()) {
                ScenarioAttemptResult only = new ScenarioAttemptResult();
                only.setAttemptNo(Math.max(1, scenario.getAttemptCount()));
                only.setStatus(scenario.getStatus());
                only.setSteps(scenario.getSteps());
                attempts = List.of(only);
            }
            for (ScenarioAttemptResult attempt : attempts) {
                List<StepResult> steps = attempt.getSteps() == null ? List.of() : attempt.getSteps();
                for (StepResult step : steps) {
                    if (step == null || !notBlank(step.getScreenshot())) continue;
                    Path image = screenshotDir.resolve(step.getScreenshot()).normalize();
                    if (!image.startsWith(screenshotDir) || !Files.isRegularFile(image)) continue;
                    byte[] bytes = Files.readAllBytes(image);
                    if (bytes.length == 0) continue;
                    String mime = imageMime(image);
                    String data = Base64.getEncoder().encodeToString(bytes);
                    imageCount++;
                    String stepStatus = normalizedStatus(step.getStatus());
                    cards.append("<article class='screenshot-card'><div class='screenshot-meta'><h2>")
                            .append(esc(scenario.getName())).append("</h2><p>")
                            .append(esc(scenario.getId())).append(" · Attempt ").append(attempt.getAttemptNo())
                            .append(" · Step ").append(step.getStepNo()).append(" · <span class='pill ")
                            .append(statusClass(stepStatus)).append("'>").append(esc(stepStatus)).append("</span></p><p>")
                            .append(esc(step.getInstruction())).append("</p></div><img class='screenshot-image' alt='Screenshot for ")
                            .append(escAttr(scenario.getId())).append(" step ").append(step.getStepNo())
                            .append("' src='data:").append(mime).append(";base64,").append(data).append("'></article>");
                }
            }
        }

        String content = imageCount == 0
                ? "<section class='panel message'><h2>No screenshots captured</h2><p>The selected screenshot mode did not produce any screenshot files for this run.</p></section>"
                : "<section class='screenshot-summary panel'>Embedded screenshots: <b>" + imageCount + "</b>. This file is standalone and safe to attach.</section><section class='screenshot-grid'>" + cards + "</section>";
        String body = header(status, "Automation report — screenshots") + content;
        Files.writeString(file, shell("Automation Report - Screenshots", body), StandardCharsets.UTF_8);
    }

    private String imageMime(Path image) {
        String name = image == null ? "" : image.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
        if (name.endsWith(".gif")) return "image/gif";
        if (name.endsWith(".webp")) return "image/webp";
        return "image/png";
    }

    /** Outlook-safe email body: inline styling, no JavaScript, no complex layout, maximum 25 scenario rows. */
    private void writeOutlookHtml(RunStatus s, Path file) throws Exception {
        int executed = s.getExecuted();
        double passPercentage = executed == 0 ? 0.0 : (s.getPassed() * 100.0 / executed);
        List<ScenarioResult> ordered = new ArrayList<>(s.getScenarios());
        ordered.sort(Comparator.comparingInt(this::outlookPriority));
        if (ordered.size() > 25) ordered = new ArrayList<>(ordered.subList(0, 25));

        String cell = "border:1px solid #b8c9c2;padding:7px 9px;font-family:Arial,sans-serif;font-size:12px;text-align:left;";
        String head = cell + "background:#eaf5f0;font-weight:bold;color:#164b39;";
        StringBuilder overallRows = new StringBuilder();
        int serial = 1;
        for (ScenarioResult r : ordered) {
            overallRows.append("<tr><td style='").append(cell).append("'>").append(serial++).append("</td><td style='").append(cell).append("'>")
                    .append(esc(r.getName())).append("</td><td style='").append(cell).append("'>").append(esc(outlookStatus(r))).append("</td></tr>");
        }

        String html = "<!doctype html><html><head><meta charset='utf-8'><title>Automation Report</title></head>" +
                "<body style='font-family:Arial,sans-serif;color:#202124;margin:0;padding:8px'>" +
                "<h2 style='font-family:Arial,sans-serif;color:#005b3e;margin:0 0 12px'>Automation Report</h2>" +
                "<table role='presentation' cellpadding='0' cellspacing='0' style='border-collapse:collapse;width:100%;max-width:760px;margin-bottom:16px'>" +
                "<tr><th style='" + head + "'>Total Cases</th><th style='" + head + "'>No. of Cases Executed</th><th style='" + head + "'>No. of Cases Passed</th><th style='" + head + "'>Pass Percentage</th></tr>" +
                "<tr><td style='" + cell + "'>" + s.getTotal() + "</td><td style='" + cell + "'>" + executed + "</td><td style='" + cell + "'>" + s.getPassed() + "</td><td style='" + cell + "'>" + String.format(Locale.ROOT, "%.2f%%", passPercentage) + "</td></tr></table>" +
                "<h3 style='font-family:Arial,sans-serif;color:#005b3e;margin:0 0 8px'>Overall Report</h3>" +
                "<table role='presentation' cellpadding='0' cellspacing='0' style='border-collapse:collapse;width:100%;max-width:760px'>" +
                "<tr><th style='" + head + "width:60px'>S.No</th><th style='" + head + "'>Scenario Name</th><th style='" + head + "width:120px'>Status</th></tr>" + overallRows + "</table>" +
                (s.getScenarios().size() > 25 ? "<p style='font-family:Arial,sans-serif;font-size:11px;color:#66756f'>Showing 25 scenarios. See the attached detailed report for all cases.</p>" : "") +
                "</body></html>";
        Files.writeString(file, html, StandardCharsets.UTF_8);
    }

    private int outlookPriority(ScenarioResult r) {
        String status = normalizedStatus(r == null ? null : r.getStatus());
        if ("FAILED".equals(status)) return 0;
        if ("PASSED_AFTER_RERUN".equals(status)) return 1;
        if ("PASSED_HEALED".equals(status)) return 2;
        if (status.startsWith("PASSED")) return 3;
        return 4;
    }

    private String outlookStatus(ScenarioResult r) {
        String status = normalizedStatus(r == null ? null : r.getStatus());
        int attempts = r == null ? 0 : Math.max(0, r.getAttemptCount());
        if ("PASSED_AFTER_RERUN".equals(status)) return "PASS (RERUN " + attempts + ")";
        if ("PASSED_HEALED".equals(status)) return "PASS (HEALED)";
        if (status.startsWith("PASSED")) return "PASS";
        if ("FAILED".equals(status)) return attempts > 1 ? "FAIL (" + attempts + " ATTEMPTS)" : "FAIL";
        return status;
    }

    private String header(RunStatus s, String title) {
        String status = shortRunStatus(s);
        return "<header><div class='brand'>ITPS VIBIUM · Agentic Step LangGraph</div><h1>" + esc(title) + "</h1><p>" + esc(s.getRunId()) + " · " + status + " · " + fmt(s.getStartedAt()) + "</p></header>" +
                "<section class='kpis'><div><span>Total</span><b>" + s.getTotal() + "</b></div><div><span>Executed</span><b>" + s.getExecuted() + "</b></div><div><span>Passed</span><b>" + s.getPassed() + "</b></div><div><span>Failed</span><b>" + s.getFailed() + "</b></div><div><span>Pass %</span><b>" + String.format(Locale.ROOT, "%.2f%%", s.getPassPercentage()) + "</b></div></section>";
    }

    private String shell(String title, String body) {
        return "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>" + esc(title) + "</title><style>" + css() + "</style></head><body><main>" + body + "</main></body></html>";
    }

    private String css() {
        return ":root{--g:#007a53;--d:#004a34;--bg:#f4f7f5;--line:#dce7e2;--red:#b42318;--ok:#027a48;--amber:#9a6700}*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Segoe UI,Arial;color:#14251f}main{padding:24px;max-width:1700px;margin:auto}header{background:linear-gradient(135deg,var(--d),var(--g));color:white;padding:22px 25px;border-radius:16px}.brand{font-size:11px;letter-spacing:.12em;text-transform:uppercase}h1{margin:6px 0 2px;font-size:25px}header p{margin:0;opacity:.86}.kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:11px;margin:16px 0}.kpis div,.panel,.filters,.links,.scenario-card{background:white;border:1px solid var(--line);border-radius:13px;padding:13px}.kpis span{display:block;color:#65746f;font-size:11px;text-transform:uppercase}.kpis b{display:block;font-size:22px;margin-top:4px}.filters{display:flex;gap:9px;align-items:center;margin-bottom:13px;position:sticky;top:0;z-index:5}.filters input{flex:1;min-width:260px;padding:10px;border:1px solid var(--line);border-radius:8px}.filters select,.btn{padding:9px;border:1px solid var(--line);border-radius:8px;background:white}.btn,a{color:var(--g);font-weight:700;text-decoration:none}.scenario-card{margin-bottom:12px}.scenario-head{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.scenario-head h2{font-size:17px;margin:0}.scenario-head p{font-size:11px;color:#65746f;margin:4px 0 0}.attempt{margin-top:10px;border-top:1px solid var(--line);padding-top:10px}.attempt summary{cursor:pointer;font-weight:700}.table-panel,.panel{overflow:auto;margin-top:10px}.wide{max-height:76vh}table{width:100%;border-collapse:collapse;table-layout:fixed;min-width:1250px}th,td{padding:8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:11px;overflow-wrap:anywhere}th{position:sticky;top:0;background:#f8fbfa;z-index:1;font-size:9px;text-transform:uppercase}.step-table th:nth-child(1){width:45px}.step-table th:nth-child(2){width:250px}.step-table th:nth-child(3){width:115px}.step-table th:nth-child(4){width:140px}.step-table th:nth-child(5){width:120px}.step-table th:nth-child(6){width:240px}.step-table th:nth-child(7){width:260px}.step-table th:nth-child(8){width:80px}.step-table th:nth-child(9){width:240px}.screenshot-summary{margin:16px 0}.screenshot-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:14px}.screenshot-card{background:white;border:1px solid var(--line);border-radius:13px;padding:13px;break-inside:avoid}.screenshot-meta h2{font-size:16px;margin:0}.screenshot-meta p{font-size:11px;color:#65746f;margin:5px 0}.screenshot-image{display:block;width:100%;height:auto;margin-top:10px;border:1px solid var(--line);border-radius:8px}.pill{display:inline-block;padding:4px 8px;border-radius:999px;font-size:10px;font-weight:800}.pass{background:#e7f8ef;color:var(--ok)}.fail{background:#fee4e2;color:var(--red)}.live{background:#fff4d6;color:var(--amber)}.pending{background:#eef2f0;color:#65746f}.error-box{margin-top:10px;padding:9px;background:#fff5f4;border:1px solid #ffd2ce;color:var(--red);border-radius:8px;font-size:11px;white-space:pre-wrap}.muted{color:#65746f}pre{white-space:pre-wrap;word-break:break-word;max-width:420px;max-height:180px;overflow:auto;margin:0;font:10px Consolas}.links{display:flex;gap:15px;margin-top:13px}.message{padding:20px}@media(max-width:900px){main{padding:12px}.kpis{grid-template-columns:1fr 1fr}.filters{flex-direction:column;align-items:stretch;position:static}.scenario-head{flex-direction:column}}";
    }

    private String detailedFilterScript() {
        return "<script>const q=document.getElementById('q'),sf=document.getElementById('statusFilter'),rf=document.getElementById('recoveryFilter');function f(){const x=q.value.toLowerCase(),s=sf.value,r=rf.value;document.querySelectorAll('.scenario-card').forEach(c=>{const ok=(!x||c.innerText.toLowerCase().includes(x))&&(!s||c.dataset.status===s)&&(!r||c.dataset.recovery===r);c.style.display=ok?'':'none'})}q.addEventListener('input',f);sf.addEventListener('change',f);rf.addEventListener('change',f)</script>";
    }

    private String recoveryType(ScenarioResult r) {
        String status = normalizedStatus(r == null ? null : r.getStatus());
        if ("FAILED".equals(status)) return "FAILED";
        if ("PASSED_AFTER_RERUN".equals(status) || (r != null && r.getAttemptCount() > 1)) return "RERUN";
        boolean healed = r != null && r.getAttempts() != null && r.getAttempts().stream()
                .flatMap(a -> a.getSteps() == null ? java.util.stream.Stream.<StepResult>empty() : a.getSteps().stream())
                .anyMatch(StepResult::isHealed);
        if (!healed && r != null && r.getSteps() != null) healed = r.getSteps().stream().anyMatch(StepResult::isHealed);
        if (healed || "PASSED_HEALED".equals(status)) return "HEALED";
        if (status.startsWith("PASSED")) return "CLEAN";
        return "PENDING";
    }

    private String statusClass(String status) {
        if (status == null) return "pending";
        if (status.startsWith("PASSED")) return "pass";
        if ("FAILED".equals(status) || status.startsWith("SKIPPED")) return "fail";
        if ("RUNNING".equals(status) || "RERUNNING".equals(status)) return "live";
        return "pending";
    }


    private void writeExcel(RunStatus status, Path path) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            Sheet summary = wb.createSheet("Results");
            String[] headers = {"Execution Date", "Test ID", "Test Name", "Status", "Attempts", "Duration", "Error"};
            Row header = summary.createRow(0);
            for (int i = 0; i < headers.length; i++) header.createCell(i).setCellValue(headers[i]);
            int rowNo = 1;
            for (ScenarioResult result : status.getScenarios()) {
                Row row = summary.createRow(rowNo++);
                row.createCell(0).setCellValue(fmt(status.getStartedAt()));
                row.createCell(1).setCellValue(result.getId());
                row.createCell(2).setCellValue(result.getName());
                row.createCell(3).setCellValue(normalizedStatus(result.getStatus()));
                row.createCell(4).setCellValue(result.getAttemptCount());
                row.createCell(5).setCellValue(formatDuration(result.getDurationMs()));
                row.createCell(6).setCellValue(nullSafe(result.getErrorMessage()));
            }

            Sheet logs = wb.createSheet("Technical Logs");
            String[] logHeaders = {"Execution Date", "Test ID", "Test Name", "Attempt", "Step", "Instruction", "Plan", "MCP Tool", "Arguments", "Page Inventory", "Evidence", "Healing", "Status", "Duration", "Screenshot", "Error"};
            Row logHeader = logs.createRow(0);
            for (int i = 0; i < logHeaders.length; i++) logHeader.createCell(i).setCellValue(logHeaders[i]);
            rowNo = 1;
            for (ScenarioResult result : status.getScenarios()) {
                List<ScenarioAttemptResult> attempts = result.getAttempts();
                if (attempts == null || attempts.isEmpty()) {
                    ScenarioAttemptResult a = new ScenarioAttemptResult();
                    a.setAttemptNo(Math.max(1, result.getAttemptCount()));
                    a.setSteps(result.getSteps());
                    attempts = List.of(a);
                }
                for (ScenarioAttemptResult attempt : attempts) {
                    for (StepResult step : attempt.getSteps()) {
                        Row row = logs.createRow(rowNo++);
                        row.createCell(0).setCellValue(fmt(status.getStartedAt()));
                        row.createCell(1).setCellValue(result.getId());
                        row.createCell(2).setCellValue(result.getName());
                        row.createCell(3).setCellValue(attempt.getAttemptNo());
                        row.createCell(4).setCellValue(step.getStepNo());
                        row.createCell(5).setCellValue(nullSafe(step.getInstruction()));
                        row.createCell(6).setCellValue(nullSafe(step.getPlanSource()));
                        row.createCell(7).setCellValue(nullSafe(step.getToolName()));
                        row.createCell(8).setCellValue(excelSafe(step.getToolArguments()));
                        row.createCell(9).setCellValue(excelSafe(step.getPageInventory()));
                        row.createCell(10).setCellValue(excelSafe(step.getEvidence()));
                        row.createCell(11).setCellValue(excelSafe(step.getHealingHistory()));
                        row.createCell(12).setCellValue(normalizedStatus(step.getStatus()));
                        row.createCell(13).setCellValue(formatDuration(step.getDurationMs()));
                        row.createCell(14).setCellValue(nullSafe(step.getScreenshot()));
                        row.createCell(15).setCellValue(excelSafe(step.getErrorMessage()));
                    }
                }
            }
            for (int i = 0; i < 7; i++) summary.setColumnWidth(i, i == 2 || i == 6 ? 12000 : (i == 0 ? 6500 : 5000));
            for (int i = 0; i < 16; i++) logs.setColumnWidth(i, i == 9 ? 16000 : (i == 0 ? 6500 : 7000));
            try (OutputStream output = Files.newOutputStream(path)) { wb.write(output); }
        }
    }

    private void zipScreenshots(Path dir, Path zip) throws Exception {
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(zip))) {
            if (!Files.isDirectory(dir)) return;
            try (var paths = Files.walk(dir)) {
                for (Path path : paths.filter(Files::isRegularFile).toList()) {
                    output.putNextEntry(new ZipEntry(dir.relativize(path).toString().replace('\\', '/')));
                    Files.copy(path, output);
                    output.closeEntry();
                }
            }
        }
    }

    private void attempt(String name, List<String> failures, CheckedRunnable action) {
        try { action.run(); }
        catch (Exception e) { failures.add(name + ": " + e); }
    }

    private String shortRunStatus(RunStatus status) {
        if (status == null) return "UNKNOWN";
        if ("FAILED".equalsIgnoreCase(status.getStatus()) || "COMPLETED_WITH_FAILURES".equalsIgnoreCase(status.getStatus())) return "FAILED";
        if (status.getFailed() > 0) return "FAILED";
        if (status.getTotal() > 0 && status.getExecuted() == status.getTotal() && status.getPassed() == status.getTotal()) return "PASSED";
        return status.getStatus() == null ? "COMPLETED" : status.getStatus().toUpperCase(Locale.ROOT);
    }

    private String normalizedStatus(String status) {
        if (status == null || status.isBlank()) return "PENDING";
        String value = status.trim().toUpperCase(Locale.ROOT);
        if ("PASSED_HEALED".equals(value) || "PASSED_AFTER_RERUN".equals(value)) return value;
        if (value.startsWith("PASSED")) return "PASSED";
        if ("FAILED".equals(value)) return "FAILED";
        return value;
    }

    private boolean notBlank(String value) { return value != null && !value.isBlank(); }
    private String formatDuration(long millis) { return millis < 1000 ? millis + " ms" : String.format(Locale.ROOT, "%.1f s", millis / 1000.0); }
    private String shortText(String value, int limit) { String v = nullSafe(value).replaceAll("\\s+", " ").trim(); return v.length() <= limit ? v : v.substring(0, limit - 3) + "..."; }
    private String excelSafe(String value) { String v = nullSafe(value); return v.length() > 32000 ? v.substring(0, 32000) : v; }
    private String fmt(Instant instant) { return instant == null ? "" : DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss").withZone(ZoneId.systemDefault()).format(instant); }
    private String nullSafe(String value) { return value == null ? "" : value; }
    private String esc(String value) { return nullSafe(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;"); }
    private String escAttr(String value) { return esc(value).replace("`", "&#96;"); }

    @FunctionalInterface
    private interface CheckedRunnable { void run() throws Exception; }
}
