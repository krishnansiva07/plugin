package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RunConfig;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Executes dropdown/combobox selection as a stateful transaction.
 *
 * <p>The transaction deliberately does not depend on an LLM-generated stale DOM map:</p>
 * <ol>
 *   <li>Resolve and mark the trigger (or a directly supplied option XPath).</li>
 *   <li>Click exactly once using the native Vibium click tool whenever possible.</li>
 *   <li>Re-query the live DOM after the overlay opens.</li>
 *   <li>Scope option lookup to the active listbox/overlay and support filtering/virtual scroll.</li>
 *   <li>Click the option exactly once and prove the selected value.</li>
 * </ol>
 */
final class EnterpriseDropdownExecutor {
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");
    private static final List<String> LOCATOR_TOKENS = List.of(
            "triggerxpath", "optionxpath", "verifyxpath", "selectedxpath", "xpath");

    private final ObjectMapper mapper;

    EnterpriseDropdownExecutor(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    boolean supports(String instruction) {
        Request request = parse(instruction);
        if (request.value().isBlank()) return false;
        String lower = request.english().toLowerCase(Locale.ROOT);
        boolean dropdownContext = containsAny(lower,
                "dropdown", "drop down", "combobox", "combo box", "listbox",
                "visible option", "from visible text", "from the options", "from options");
        boolean selectVerb = containsAny(lower, "select", "choose", "pick");
        boolean setPattern = lower.matches(".*\\bset\\b.+\\bto\\b.+") &&
                !containsAny(lower, "checkbox", "radio", "toggle", "switch");
        boolean clickOption = containsAny(lower, "click", "tap") &&
                containsAny(lower, "option", "from visible text", "visible value", "from the list");
        boolean locatorSaysDropdown = !request.optionXPath().isBlank() ||
                ((!request.triggerXPath().isBlank() || !request.genericXPath().isBlank()) && selectVerb);
        boolean semanticFieldSelection = selectVerb && containsAny(lower, " from ", " in ") &&
                !containsAny(lower, "checkbox", "radio", "toggle", "switch", "tab", "row", "table", "text field");
        return dropdownContext || setPattern || clickOption || locatorSaysDropdown || semanticFieldSelection;
    }

    Execution execute(McpClient mcp, McpToolCatalog catalog, String instruction, RunConfig config) throws Exception {
        Request request = parse(instruction);
        if (request.value().isBlank()) {
            throw new IllegalArgumentException("Unable to determine the dropdown value from step: " + instruction);
        }
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("Enterprise dropdown execution requires Vibium browser_evaluate."));
        McpTool click = catalog.clickTool().orElseThrow(() ->
                new IllegalStateException("Enterprise dropdown execution requires Vibium browser_click."));

        int timeoutMs = Math.max(5_000, Math.max(1, config.getStepTimeoutSeconds()) * 1_000);
        String transactionId = "itps-" + UUID.randomUUID().toString().replace("-", "");
        String triggerMarker = transactionId + "-trigger";
        String optionMarker = transactionId + "-option";

        ObjectNode audit = mapper.createObjectNode();
        audit.put("transactionId", transactionId);
        audit.put("field", request.field());
        audit.put("value", request.value());
        audit.put("genericXPath", request.genericXPath());
        audit.put("triggerXPath", request.triggerXPath());
        audit.put("optionXPath", request.optionXPath());
        audit.put("verifyXPath", request.verifyXPath());
        audit.put("timeoutMs", timeoutMs);
        ArrayNode phases = audit.putArray("phases");
        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> arguments = new ArrayList<>();
        List<String> results = new ArrayList<>();

        try {
        JsonNode resolved = evaluateJson(mcp, evaluate, resolveControlScript(request, triggerMarker));
        phases.add(phase("RESOLVE_CONTROL", resolved));
        results.add(compact(resolved.toString(), 5_000));
        tools.add(evaluate.getName());
        arguments.add(Map.of("phase", "RESOLVE_CONTROL"));
        requireTrue(resolved.path("found").asBoolean(false),
                "Dropdown trigger/option was not resolved. Details=" + compact(resolved.toString(), 3_000));

        if (resolved.path("alreadySelected").asBoolean(false)) {
            JsonNode verified = verifyWithRetry(mcp, evaluate, request, triggerMarker, timeoutMs);
            phases.add(phase("VERIFY_ALREADY_SELECTED", verified));
            requireTrue(verified.path("selected").asBoolean(false),
                    "Dropdown appeared already selected but strict verification failed. Details=" + compact(verified.toString(), 3_000));
            cleanupMarkers(mcp, evaluate, triggerMarker, optionMarker);
            return execution(request, audit, tools, arguments, results,
                    "Dropdown value was already selected and was verified exactly as '" + request.value() + "'.");
        }

        String kind = resolved.path("kind").asText("trigger");
        if ("native-select".equals(kind)) {
            JsonNode selected = evaluateJson(mcp, evaluate, nativeSelectScript(triggerMarker, request.value()));
            phases.add(phase("NATIVE_SELECT", selected));
            results.add(compact(selected.toString(), 5_000));
            tools.add(evaluate.getName());
            arguments.add(Map.of("phase", "NATIVE_SELECT", "value", request.value()));
            requireTrue(selected.path("selected").asBoolean(false),
                    "Native SELECT did not apply value '" + request.value() + "'. Details=" + compact(selected.toString(), 3_000));
        } else if ("option".equals(kind)) {
            String directOptionXPath = !request.optionXPath().isBlank() ? request.optionXPath() : request.genericXPath();
            JsonNode optionClick = clickLiveOptionWithRetry(mcp, evaluate, request, triggerMarker,
                    directOptionXPath, timeoutMs, phases, "DIRECT_OPTION_XPATH");
            phases.add(phase("CLICK_DIRECT_OPTION", optionClick));
            tools.add(evaluate.getName());
            arguments.add(Map.of("phase", "DIRECT_OPTION_XPATH", "xpath", directOptionXPath));
            results.add(compact(optionClick.toString(), 5_000));
        } else {
            ClickOutcome triggerClick = clickMarkedOnce(mcp, catalog, click, evaluate, triggerMarker,
                    resolved.path("nativeReachable").asBoolean(true), timeoutMs, "OPEN_DROPDOWN");
            phases.add(phase("OPEN_DROPDOWN", triggerClick.result()));
            tools.add(triggerClick.tool());
            arguments.add(triggerClick.arguments());
            results.add(compact(triggerClick.result().toString(), 5_000));

            // This is the critical fresh-DOM boundary. The option is never resolved from the
            // pre-click snapshot. Every poll operates on the currently rendered overlay.
            JsonNode optionClick = clickLiveOptionWithRetry(mcp, evaluate, request, triggerMarker,
                    request.optionXPath(), timeoutMs, phases, "SELECT_OPTION");
            phases.add(phase("SELECT_OPTION", optionClick));
            tools.add(evaluate.getName());
            arguments.add(Map.of("phase", "SELECT_OPTION", "optionXPath", request.optionXPath()));
            results.add(compact(optionClick.toString(), 5_000));
        }

        JsonNode verified = verifyWithRetry(mcp, evaluate, request, triggerMarker, timeoutMs);
        phases.add(phase("VERIFY_SELECTED_VALUE", verified));
        results.add(compact(verified.toString(), 5_000));
        tools.add(evaluate.getName());
        arguments.add(Map.of("phase", "VERIFY_SELECTED_VALUE", "expected", request.value()));
        requireTrue(verified.path("selected").asBoolean(false),
                "Option click completed, but the field value was not proven as '" + request.value() + "'. Details=" + compact(verified.toString(), 4_000));

        cleanupMarkers(mcp, evaluate, triggerMarker, optionMarker);
        String strategy = request.hasUserLocator() ? "ENTERPRISE_DROPDOWN_USER_XPATH" : "ENTERPRISE_DROPDOWN_SEMANTIC";
        audit.put("strategy", strategy);
        return execution(request, audit, tools, arguments, results,
                "Dropdown transaction passed: field='" + displayField(request.field()) +
                        "', selectedValue='" + request.value() + "', verification=" +
                        verified.path("strategy").asText("exact-value") + ".");
        } finally {
            cleanupMarkers(mcp, evaluate, triggerMarker, optionMarker);
        }
    }

    private Execution execution(Request request, ObjectNode audit, List<String> tools,
                                List<Map<String, Object>> args, List<String> results, String evidence) throws Exception {
        ObjectNode action = mapper.createObjectNode();
        action.put("type", "DROPDOWN_TRANSACTION");
        action.put("field", request.field());
        action.put("value", request.value());
        action.put("triggerXPath", request.effectiveTriggerXPath());
        action.put("optionXPath", request.optionXPath());
        action.put("verifyXPath", request.verifyXPath());
        String source = request.hasUserLocator() ? "ENTERPRISE_DROPDOWN_USER_XPATH" : "ENTERPRISE_DROPDOWN_SEMANTIC";
        return new Execution(source, action.toString(), String.join(" → ", tools),
                mapper.writeValueAsString(args), String.join("\n---\n", results), evidence, audit);
    }


    /**
     * Re-resolves the option and clicks it inside the same browser operation. This avoids
     * data-itps marker races when Angular replaces a search-result node between render cycles.
     */
    private JsonNode clickLiveOptionWithRetry(McpClient mcp, McpTool evaluate, Request request,
                                              String triggerMarker, String explicitOptionXPath,
                                              int timeoutMs, ArrayNode phases, String phaseName) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        JsonNode last = mapper.createObjectNode();
        int poll = 0;
        while (System.currentTimeMillis() < deadline) {
            poll++;
            last = evaluateJson(mcp, evaluate,
                    liveOptionClickScript(request, triggerMarker, explicitOptionXPath, poll));
            if (last.path("clicked").asBoolean(false)) {
                if (last.path("interactionConfirmed").asBoolean(false)) return last;
                throw new IllegalStateException("Option click was dispatched once, but Angular did not confirm selection. The framework will not double-click the same option. Details="
                        + compact(last.toString(), 5_000));
            }
            if (poll == 1 || poll % 5 == 0) {
                ObjectNode wait = phase("WAIT_LIVE_OPTION", last);
                wait.put("poll", poll);
                wait.put("requestedPhase", phaseName);
                phases.add(wait);
            }
            sleep(Math.min(300, Math.max(100, timeoutMs / 80)));
        }
        throw new IllegalStateException("Option '" + request.value() + "' was not resolved and clicked from the live Angular overlay. Details="
                + compact(last.toString(), 5_000));
    }

    private String liveOptionClickScript(Request request, String triggerMarker,
                                         String explicitOptionXPath, int poll) {
        return """
                (async () => {
                  const wanted=%s, optionXPath=%s, triggerMarker=%s, poll=%d;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
                  const raf=()=>new Promise(r=>requestAnimationFrame(()=>r()));
                  const visible=e=>{if(!e||!(e instanceof Element)||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const enabled=e=>!(e.disabled||e.getAttribute?.('aria-disabled')==='true'||e.classList?.contains('disabled')||e.classList?.contains('mat-mdc-option-disabled'));
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument)}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  const deepQuery=selector=>{const out=[];for(const d of docs)for(const r of roots(d)){try{out.push(...r.querySelectorAll(selector))}catch(ignore){}}return out;};
                  const xpathAll=xp=>{const out=[];if(!xp)return out;for(const d of docs)for(const root of roots(d)){try{const x=d.evaluate(xp,root,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++){const n=x.snapshotItem(i),e=n instanceof Element?n:n?.parentElement;if(e&&!out.includes(e))out.push(e)}}catch(ignore){}}return out;};
                  const text=e=>norm(e?.innerText||e?.textContent||e?.getAttribute?.('aria-label'));
                  const optionSelector='[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-option,.ant-select-item-option,.select2-results__option,option,li[role="option"],li[data-value]';
                  const overlaySelector='[role="listbox"],.cdk-overlay-pane,.mat-mdc-select-panel,.mat-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown,.dropdown-menu,[class*="dropdown-panel"]';
                  const trigger=deepQuery(`[data-itps-action-id="${triggerMarker}"]`)[0]||null;
                  const controlled=new Set();if(trigger)for(const a of ['aria-controls','aria-owns'])for(const id of String(trigger.getAttribute?.(a)||'').split(/\\s+/))if(id)controlled.add(id);
                  const overlays=deepQuery(overlaySelector).filter(visible).sort((a,b)=>{
                    const ac=controlled.has(a.id)?1:0,bc=controlled.has(b.id)?1:0;if(ac!==bc)return bc-ac;
                    const az=Number(a.ownerDocument.defaultView.getComputedStyle(a).zIndex)||0,bz=Number(b.ownerDocument.defaultView.getComputedStyle(b).zIndex)||0;if(az!==bz)return bz-az;
                    return (b.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_FOLLOWING)?1:-1;
                  });
                  const activeRoot=overlays.find(e=>controlled.has(e.id))||overlays[0]||null;
                  const promote=e=>e?.matches?.(optionSelector)?e:(e?.closest?.(optionSelector)||e);
                  const resolve=()=>{
                    let raw=optionXPath?xpathAll(optionXPath):[];
                    let candidates=raw.map(promote).filter(visible).filter(enabled);
                    if(activeRoot&&candidates.some(e=>activeRoot===e||activeRoot.contains(e)))candidates=candidates.filter(e=>activeRoot===e||activeRoot.contains(e));
                    if(!candidates.length){
                      const pool=activeRoot?[...activeRoot.querySelectorAll(optionSelector)]:deepQuery(optionSelector);
                      candidates=pool.filter(visible).filter(enabled).filter(e=>text(e)===norm(wanted));
                    }
                    candidates=[...new Set(candidates)].sort((a,b)=>{
                      const ae=text(a)===norm(wanted)?0:1,be=text(b)===norm(wanted)?0:1;if(ae!==be)return ae-be;
                      const ar=norm(a.getAttribute?.('role'))==='option'?0:1,br=norm(b.getAttribute?.('role'))==='option'?0:1;if(ar!==br)return ar-br;
                      const aa=a.getBoundingClientRect(),bb=b.getBoundingClientRect();return aa.width*aa.height-bb.width*bb.height;
                    });
                    return {rawCount:raw.length,candidates};
                  };
                  let current=resolve();
                  if(current.candidates.length){
                    // Angular may replace the result after an async search response. Wait briefly,
                    // then resolve once more and click the fresh node immediately.
                    await raf();await raf();await sleep(40);
                    current=resolve();
                    const option=current.candidates[0];
                    if(option){
                      option.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});await raf();
                      const fresh=resolve().candidates[0];
                      if(!fresh)return JSON.stringify({clicked:false,reason:'OPTION_REPLACED_DURING_STABILITY_CHECK',poll});
                      const r=fresh.getBoundingClientRect(),x=Math.max(r.left+1,Math.min(r.right-1,r.left+r.width/2)),y=Math.max(r.top+1,Math.min(r.bottom-1,r.top+r.height/2));
                      const top=fresh.ownerDocument.elementFromPoint(x,y),hit=!!top&&(top===fresh||fresh.contains(top));
                      if(!hit)return JSON.stringify({clicked:false,reason:'OPTION_HIT_TEST_FAILED',poll,top:top?.tagName||'',text:(fresh.innerText||fresh.textContent||'').trim()});
                      fresh.focus?.({preventScroll:true});
                      const common={bubbles:true,cancelable:true,composed:true,view:fresh.ownerDocument.defaultView,clientX:x,clientY:y,button:0,buttons:1};
                      try{fresh.dispatchEvent(new PointerEvent('pointerdown',{...common,pointerId:1,pointerType:'mouse',isPrimary:true}))}catch(ignore){}
                      fresh.dispatchEvent(new MouseEvent('mousedown',common));
                      try{fresh.dispatchEvent(new PointerEvent('pointerup',{...common,buttons:0,pointerId:1,pointerType:'mouse',isPrimary:true}))}catch(ignore){}
                      fresh.dispatchEvent(new MouseEvent('mouseup',{...common,buttons:0}));
                      const overlayWasVisible=!!activeRoot&&visible(activeRoot);
                      const expandedBefore=trigger?.getAttribute?.('aria-expanded')||'';
                      // Exactly one click event on the newly resolved option.
                      fresh.click();
                      let selected=false,triggerCollapsed=false,overlayClosed=false;
                      const confirmUntil=Date.now()+2200;
                      while(Date.now()<confirmUntil){
                        selected=fresh.isConnected&&(fresh.getAttribute?.('aria-selected')==='true'||fresh.classList?.contains('selected')||fresh.classList?.contains('ng-option-selected')||fresh.classList?.contains('p-highlight')||fresh.classList?.contains('mat-mdc-option-active'));
                        triggerCollapsed=!!trigger&&trigger.getAttribute?.('aria-expanded')==='false';
                        overlayClosed=overlayWasVisible&&(!activeRoot?.isConnected||!visible(activeRoot));
                        if(selected||triggerCollapsed||overlayClosed)break;
                        await sleep(100);
                      }
                      const confirmed=selected||triggerCollapsed||overlayClosed;
                      const confirmationStrategy=selected?'OPTION_SELECTED_STATE':triggerCollapsed?'COMBOBOX_COLLAPSED':overlayClosed?'ACTIVE_OVERLAY_CLOSED':'NOT_CONFIRMED';
                      return JSON.stringify({clicked:true,interactionConfirmed:confirmed,confirmationStrategy,selected,triggerCollapsed,overlayClosed,expandedBefore,mode:'LIVE_RESOLVE_AND_CLICK_SAME_CALL',poll,optionXPath,userXPathPriority:!!optionXPath,rawXPathMatches:current.rawCount,candidateCount:current.candidates.length,tag:fresh.tagName,role:fresh.getAttribute?.('role')||'',optionText:(fresh.innerText||fresh.textContent||'').trim().slice(0,300),overlay:activeRoot?{tag:activeRoot.tagName,id:activeRoot.id||'',class:String(activeRoot.className||'').slice(0,180)}:null,hitTestPassed:true});
                    }
                  }
                  let filtered=false,scrolled=false,scrollTop=-1,scrollHeight=-1;
                  const filterRoot=activeRoot||trigger?.closest?.('ng-select,.ng-select,p-dropdown,p-select,.ant-select,.select2-container')||trigger?.ownerDocument||document;
                  const input=[...(filterRoot.querySelectorAll?.('input:not([type="hidden"]),[contenteditable="true"]')||[])].find(visible);
                  if(input&&poll<=2&&input.getAttribute('data-itps-filtered-for')!==wanted){
                    input.setAttribute('data-itps-filtered-for',wanted);input.focus();
                    const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input),'value')?.set;
                    if(setter)setter.call(input,wanted);else input.value=wanted;
                    try{input.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:wanted}))}catch(ignore){input.dispatchEvent(new Event('input',{bubbles:true,composed:true}))}
                    input.dispatchEvent(new Event('change',{bubbles:true,composed:true}));filtered=true;
                  }
                  if(activeRoot){
                    const scrollables=[activeRoot,...activeRoot.querySelectorAll('*')].filter(e=>e.scrollHeight>e.clientHeight+5);
                    const viewport=scrollables.sort((a,b)=>(b.clientHeight||0)-(a.clientHeight||0))[0];
                    if(viewport){const before=viewport.scrollTop;if(poll===1&&viewport.scrollTop>0)viewport.scrollTop=0;else viewport.scrollTop=Math.min(viewport.scrollHeight,viewport.scrollTop+Math.max(120,viewport.clientHeight*.8));viewport.dispatchEvent(new Event('scroll',{bubbles:true}));scrolled=viewport.scrollTop!==before;scrollTop=viewport.scrollTop;scrollHeight=viewport.scrollHeight;}
                  }
                  return JSON.stringify({clicked:false,reason:'OPTION_NOT_RENDERED_YET',poll,wanted,optionXPath,userXPathPriority:!!optionXPath,rawXPathMatches:current.rawCount,candidateCount:current.candidates.length,controlled:[...controlled],overlayCount:overlays.length,activeOverlay:activeRoot?{tag:activeRoot.tagName,id:activeRoot.id||'',class:String(activeRoot.className||'').slice(0,160)}:null,filtered,scrolled,scrollTop,scrollHeight,visibleOptions:(activeRoot?[...activeRoot.querySelectorAll(optionSelector)]:[]).filter(visible).map(e=>(e.innerText||e.textContent||'').trim()).slice(0,30)});
                })()
                """.formatted(js(request.value()), js(explicitOptionXPath), js(triggerMarker), poll);
    }

    private JsonNode locateOptionWithRetry(McpClient mcp, McpTool evaluate, Request request,
                                           String triggerMarker, String optionMarker, int timeoutMs,
                                           ArrayNode phases) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        JsonNode last = mapper.createObjectNode();
        int poll = 0;
        while (System.currentTimeMillis() < deadline) {
            poll++;
            last = evaluateJson(mcp, evaluate,
                    locateOptionScript(request, triggerMarker, optionMarker, poll));
            if (last.path("found").asBoolean(false)) {
                ObjectNode foundPhase = phase("FRESH_DOM_OPTION_RESOLUTION", last);
                foundPhase.put("poll", poll);
                phases.add(foundPhase);
                return last;
            }
            if (poll == 1 || poll % 5 == 0) {
                ObjectNode waitPhase = phase("WAIT_OPTION_RENDER", last);
                waitPhase.put("poll", poll);
                phases.add(waitPhase);
            }
            sleep(Math.min(300, Math.max(100, timeoutMs / 80)));
        }
        return last;
    }

    private JsonNode verifyWithRetry(McpClient mcp, McpTool evaluate, Request request,
                                     String triggerMarker, int timeoutMs) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        JsonNode last = mapper.createObjectNode();
        while (System.currentTimeMillis() < deadline) {
            last = evaluateJson(mcp, evaluate, verifySelectionScript(request, triggerMarker));
            if (last.path("selected").asBoolean(false)) return last;
            sleep(200);
        }
        return last;
    }

    private ClickOutcome clickMarkedOnce(McpClient mcp, McpToolCatalog catalog, McpTool click,
                                         McpTool evaluate, String marker, boolean nativeReachable,
                                         int timeoutMs, String phase) throws Exception {
        String selector = "[data-itps-action-id=\"" + marker + "\"]";
        if (nativeReachable) {
            Map<String, Object> args = selectorArgs(click, selector, timeoutMs);
            try {
                JsonNode result = mcp.callTool(click.getName(), args);
                assertToolSuccess(click.getName(), result);
                ObjectNode wrapped = mapper.createObjectNode();
                wrapped.put("clicked", true);
                wrapped.put("mode", "NATIVE_VIBIUM_POINTER");
                wrapped.put("phase", phase);
                wrapped.put("selector", selector);
                wrapped.set("raw", result == null ? mapper.nullNode() : result);
                return new ClickOutcome(click.getName(), args, wrapped);
            } catch (Exception nativeFailure) {
                // A native pointer command can time out after the browser has already processed the
                // click. Probe the live state before retrying so an Angular trigger/option is never
                // toggled by an accidental second click.
                JsonNode completionProbe = evaluateJson(mcp, evaluate, clickCompletionProbeScript(marker, phase));
                if (completionProbe.path("completed").asBoolean(false)) {
                    ObjectNode wrapped = mapper.createObjectNode();
                    wrapped.put("clicked", true);
                    wrapped.put("mode", "NATIVE_CLICK_STATE_CONFIRMED_AFTER_ERROR");
                    wrapped.put("phase", phase);
                    wrapped.put("nativeError", compact(nativeFailure.getMessage(), 1_500));
                    wrapped.set("completionProbe", completionProbe);
                    return new ClickOutcome(evaluate.getName(), Map.of("phase", phase, "marker", marker), wrapped);
                }
                JsonNode fallback = evaluateJson(mcp, evaluate, clickMarkerScript(marker));
                requireTrue(fallback.path("clicked").asBoolean(false),
                        "Native Vibium click and single-click DOM fallback both failed. Native error=" +
                                nativeFailure.getMessage() + "; fallback=" + compact(fallback.toString(), 2_000));
                ObjectNode wrapped = mapper.createObjectNode();
                wrapped.put("clicked", true);
                wrapped.put("mode", "SINGLE_DOM_CLICK_FALLBACK");
                wrapped.put("phase", phase);
                wrapped.put("nativeError", compact(nativeFailure.getMessage(), 1_500));
                wrapped.set("completionProbe", completionProbe);
                wrapped.set("fallback", fallback);
                return new ClickOutcome(evaluate.getName(), Map.of("phase", phase, "marker", marker), wrapped);
            }
        }
        JsonNode fallback = evaluateJson(mcp, evaluate, clickMarkerScript(marker));
        requireTrue(fallback.path("clicked").asBoolean(false),
                "Element was inside an iframe/shadow root and the single-click fallback failed: " + compact(fallback.toString(), 2_000));
        return new ClickOutcome(evaluate.getName(), Map.of("phase", phase, "marker", marker), fallback);
    }

    private Map<String, Object> selectorArgs(McpTool tool, String selector, int timeoutMs) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "selector")) args.put("selector", selector);
        else if (schemaContains(tool, "locator")) args.put("locator", selector);
        else if (schemaContains(tool, "target")) args.put("target", selector);
        else if (schemaContains(tool, "ref")) args.put("ref", selector);
        else args.put("selector", selector);
        if (schemaContains(tool, "timeout")) args.put("timeout", timeoutMs);
        return args;
    }

    private JsonNode evaluateJson(McpClient mcp, McpTool evaluate, String script) throws Exception {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(evaluate, "expression")) args.put("expression", script);
        else if (schemaContains(evaluate, "script")) args.put("script", script);
        else args.put("code", script);
        JsonNode raw = mcp.callTool(evaluate.getName(), args);
        assertToolSuccess(evaluate.getName(), raw);
        return unwrapJsonString(raw);
    }

    private void cleanupMarkers(McpClient mcp, McpTool evaluate, String... markers) {
        try {
            String joined = mapper.writeValueAsString(Arrays.asList(markers));
            evaluateJson(mcp, evaluate, """
                    (() => {
                      const markers = %s;
                      const walk = root => {
                        const found=[];
                        if (root.querySelectorAll) found.push(...root.querySelectorAll('[data-itps-action-id]'));
                        for (const e of [...(root.querySelectorAll?.('*') || [])]) if (e.shadowRoot) found.push(...walk(e.shadowRoot));
                        return found;
                      };
                      const docs=[document];
                      for(let i=0;i<docs.length;i++) for(const f of docs[i].querySelectorAll('iframe,frame')) {
                        try { if(f.contentDocument && !docs.includes(f.contentDocument)) docs.push(f.contentDocument); } catch(ignore) {}
                      }
                      let removed=0;
                      for(const d of docs) for(const e of walk(d)) if(markers.includes(e.getAttribute('data-itps-action-id'))) {
                        e.removeAttribute('data-itps-action-id'); removed++;
                      }
                      return JSON.stringify({removed});
                    })()
                    """.formatted(joined));
        } catch (Exception ignored) {
            // Cleanup is best effort and must not hide a verified successful user action.
        }
    }

    private String resolveControlScript(Request request, String marker) {
        return """
                (() => {
                  const field=%s, value=%s, genericXPath=%s, triggerXPath=%s, optionXPath=%s, marker=%s, directOptionIntent=%s;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const visible=e=>{ if(!e||!(e instanceof Element))return false; const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e); return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0; };
                  const enabled=e=>!(e.disabled||e.getAttribute?.('aria-disabled')==='true'||e.classList?.contains('disabled')||e.classList?.contains('mat-mdc-option-disabled'));
                  const docs=[document];
                  for(let i=0;i<docs.length;i++) for(const f of docs[i].querySelectorAll('iframe,frame')) { try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){} }
                  const roots=d=>{const out=[d]; for(let i=0;i<out.length;i++){const all=out[i].querySelectorAll?.('*')||[]; for(const e of all)if(e.shadowRoot)out.push(e.shadowRoot);} return out;};
                  const deepQuery=(selector)=>{const out=[]; for(const d of docs)for(const r of roots(d)){try{out.push(...r.querySelectorAll(selector));}catch(ignore){}} return out;};
                  const xpathAll=xp=>{const out=[]; if(!xp)return out; for(const d of docs){try{const x=d.evaluate(xp,d,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)out.push(x.snapshotItem(i));}catch(ignore){}} return out;};
                  const text=e=>norm(e?.innerText||e?.textContent||e?.value||e?.getAttribute?.('aria-label'));
                  const selectedValues=e=>{
                    const vals=[]; if(!e)return vals;
                    if('value' in e&&String(e.value||'').trim())vals.push(String(e.value));
                    for(const a of ['aria-valuetext','data-value','title']){const v=e.getAttribute?.(a);if(v)vals.push(v);}
                    for(const n of e.querySelectorAll?.('.ng-value-label,.ng-value,.mat-mdc-select-value-text,.mat-select-value-text,.p-dropdown-label,.p-select-label,.ant-select-selection-item,.select2-selection__rendered,[aria-selected="true"],option:checked')||[]) {
                      const v=n.innerText||n.textContent||n.value;if(String(v||'').trim())vals.push(String(v));
                    }
                    return vals;
                  };
                  const exactSelected=e=>selectedValues(e).some(v=>norm(v)===norm(value));
                  const classify=e=>{
                    const role=norm(e.getAttribute?.('role')), tag=norm(e.tagName), cls=norm(e.className);
                    if(role==='option'||tag==='option'||tag==='mat-option'||cls.includes('ng-option'))return 'option';
                    if(tag==='select')return 'native-select';
                    return 'trigger';
                  };
                  let matches=[];
                  const suppliedTrigger=triggerXPath||genericXPath;
                  if(optionXPath)matches=xpathAll(optionXPath).filter(visible);
                  if(!matches.length&&suppliedTrigger)matches=xpathAll(suppliedTrigger).filter(visible);
                  let target=matches.find(enabled)||matches[0]||null;
                  let source=optionXPath&&target?'OPTION_XPATH':suppliedTrigger&&target?'USER_XPATH':'SEMANTIC_LABEL';
                  const clickableOptionSelector='[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-option,.ant-select-item-option,.select2-results__option,li[role="option"],option';
                  if(target){
                    const optionParent=target.matches?.(clickableOptionSelector)?target:target.closest?.(clickableOptionSelector);
                    if(optionParent&&(optionXPath||directOptionIntent||text(target)===norm(value))){
                      target=optionParent;
                      source=(source==='SEMANTIC_LABEL'?'ACTIVE_OVERLAY_OPTION_TEXT':source+'_PROMOTED_TO_CLICKABLE_OPTION');
                    }
                  }
                  if(!target&&directOptionIntent){
                    const optionSelector='[role="option"],mat-option,.mat-mdc-option,.ng-option,.p-dropdown-item,.p-select-option,.ant-select-item-option,.select2-results__option,li[role="option"],[class*="option"]';
                    const options=deepQuery(optionSelector).filter(visible).filter(enabled).filter(e=>text(e)===norm(value));
                    const active=options.filter(e=>e.closest('[role="listbox"],.cdk-overlay-pane,.mat-mdc-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.ant-select-dropdown,.select2-dropdown,.dropdown-menu'));
                    target=(active.length===1?active[0]:options.length===1?options[0]:null);
                    if(target)source='ACTIVE_OVERLAY_OPTION_TEXT';
                  }
                  if(!target){
                    const selectors='select,ng-select,.ng-select,mat-select,.mat-mdc-select,[role="combobox"],p-dropdown,p-select,.p-dropdown,.p-select,.ant-select,.select2-container,input[aria-autocomplete="list"],button[aria-haspopup="listbox"],[aria-haspopup="listbox"]';
                    const candidates=deepQuery(selectors).filter(visible).filter(enabled);
                    const labels=deepQuery('label,.form-label,[class*="label"],[aria-label]').filter(visible);
                    const exactLabel=labels.find(e=>norm(e.innerText||e.textContent||e.getAttribute('aria-label'))===norm(field));
                    const scored=candidates.map((e,index)=>{
                      let score=0;
                      const attrs=[e.id,e.getAttribute?.('name'),e.getAttribute?.('aria-label'),e.getAttribute?.('placeholder'),e.getAttribute?.('data-testid')].map(norm);
                      if(field&&attrs.some(v=>v===norm(field)))score+=100;
                      if(field&&attrs.some(v=>v.includes(norm(field))))score+=45;
                      if(exactLabel){
                        const id=exactLabel.getAttribute?.('for'); if(id&&e.id===id)score+=160;
                        const box=exactLabel.closest('.form-group,.form-field,.field,[class*="field"],[class*="form"],td,div');
                        if(box&&(box===e||box.contains(e)))score+=90;
                        const lr=exactLabel.getBoundingClientRect(),er=e.getBoundingClientRect();
                        const distance=Math.abs(lr.left-er.left)+Math.abs(lr.top-er.top); score+=Math.max(0,40-Math.floor(distance/20));
                      }
                      const context=norm(e.closest('.form-group,.form-field,.field,[class*="field"],td,div')?.innerText||'');
                      if(field&&context.includes(norm(field)))score+=35;
                      if(candidates.length===1)score+=20;
                      return {e,score,index};
                    }).sort((a,b)=>b.score-a.score||a.index-b.index);
                    if(scored.length&&(scored[0].score>0||(!field&&scored.length===1)))target=scored[0].e;
                    if(!target&&candidates.length===1)target=candidates[0];
                    if(!target)return JSON.stringify({found:false,reason:'NO_UNAMBIGUOUS_COMBOBOX',field,value,candidateCount:candidates.length,topCandidates:scored.slice(0,5).map(x=>({score:x.score,tag:x.e.tagName,id:x.e.id||'',aria:x.e.getAttribute('aria-label')||''}))});
                  }
                  target.setAttribute('data-itps-action-id',marker);
                  const root=target.getRootNode();
                  const nativeReachable=target.ownerDocument===document&&root===document;
                  const kind=classify(target);
                  const selected=kind!=='option'&&exactSelected(target);
                  return JSON.stringify({found:true,source,kind,nativeReachable,alreadySelected:selected,matched:matches.length||1,tag:target.tagName,role:target.getAttribute?.('role')||'',id:target.id||'',selectedValues:selectedValues(target),text:text(target).slice(0,300)});
                })()
                """.formatted(js(request.field()), js(request.value()), js(request.genericXPath()),
                js(request.triggerXPath()), js(request.optionXPath()), js(marker), directOptionIntent(request.english()));
    }

    private boolean directOptionIntent(String english) {
        String lower = english == null ? "" : english.toLowerCase(Locale.ROOT);
        return containsAny(lower, "click", "tap") &&
                containsAny(lower, "option", "from visible text", "visible value", "from the list");
    }

    private String nativeSelectScript(String marker, String wantedValue) {
        return """
                (() => {
                  const marker=%s,wanted=%s,norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const allDocs=[document];for(let i=0;i<allDocs.length;i++)for(const f of allDocs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!allDocs.includes(f.contentDocument))allDocs.push(f.contentDocument)}catch(ignore){}}
                  let select=null;for(const d of allDocs){select=d.querySelector(`[data-itps-action-id="${marker}"]`);if(select)break;}
                  if(!select||select.tagName!=='SELECT')return JSON.stringify({selected:false,reason:'MARKED_NATIVE_SELECT_NOT_FOUND'});
                  const option=[...select.options].find(o=>norm(o.textContent)===norm(wanted)||norm(o.value)===norm(wanted));
                  if(!option)return JSON.stringify({selected:false,reason:'NATIVE_OPTION_NOT_FOUND',available:[...select.options].map(o=>o.textContent.trim()).slice(0,100)});
                  select.value=option.value;option.selected=true;
                  select.dispatchEvent(new Event('input',{bubbles:true,composed:true}));
                  select.dispatchEvent(new Event('change',{bubbles:true,composed:true}));
                  return JSON.stringify({selected:norm(select.options[select.selectedIndex]?.textContent)===norm(wanted)||norm(select.value)===norm(wanted),value:select.value,text:select.options[select.selectedIndex]?.textContent||'',strategy:'NATIVE_SELECT_CHANGE_EVENT'});
                })()
                """.formatted(js(marker), js(wantedValue));
    }

    private String locateOptionScript(Request request, String triggerMarker, String optionMarker, int poll) {
        return """
                (() => {
                  const wanted=%s,optionXPath=%s,triggerMarker=%s,optionMarker=%s,poll=%d;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const visible=e=>{if(!e||!(e instanceof Element))return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const enabled=e=>!(e.disabled||e.getAttribute?.('aria-disabled')==='true'||e.classList?.contains('disabled')||e.classList?.contains('mat-mdc-option-disabled'));
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument)}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  const deepQuery=(selector,baseDocs=docs)=>{const out=[];for(const d of baseDocs)for(const r of roots(d)){try{out.push(...r.querySelectorAll(selector))}catch(ignore){}}return out;};
                  const xpathAll=xp=>{const out=[];if(!xp)return out;for(const d of docs){try{const x=d.evaluate(xp,d,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)out.push(x.snapshotItem(i));}catch(ignore){}}return out;};
                  const text=e=>norm(e?.innerText||e?.textContent||e?.getAttribute?.('aria-label'));
                  let trigger=deepQuery(`[data-itps-action-id="${triggerMarker}"]`)[0]||null;
                  const controlled=new Set();if(trigger)for(const a of ['aria-controls','aria-owns'])for(const id of String(trigger.getAttribute?.(a)||'').split(/\\s+/))if(id)controlled.add(id);
                  let candidates=optionXPath?xpathAll(optionXPath).filter(visible).filter(enabled):[];
                  let activeRoot=null;
                  const overlaySelector='[role="listbox"],.cdk-overlay-pane,.mat-mdc-select-panel,.mat-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown,.dropdown-menu,[class*="overlay"],[class*="dropdown-panel"]';
                  const overlays=deepQuery(overlaySelector).filter(visible).sort((a,b)=>{
                    const ac=controlled.has(a.id)?1:0,bc=controlled.has(b.id)?1:0;if(ac!==bc)return bc-ac;
                    const az=Number(a.ownerDocument.defaultView.getComputedStyle(a).zIndex)||0,bz=Number(b.ownerDocument.defaultView.getComputedStyle(b).zIndex)||0;
                    if(az!==bz)return bz-az;return (b.compareDocumentPosition(a)&Node.DOCUMENT_POSITION_FOLLOWING)?1:-1;
                  });
                  activeRoot=overlays.find(e=>controlled.has(e.id))||overlays[0]||null;
                  if(!candidates.length){
                    const optionSelector='[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.ant-select-item-option,.select2-results__option,option,li[data-value],li[role="option"],[class*="option"]';
                    const pool=activeRoot?[...activeRoot.querySelectorAll(optionSelector)]:deepQuery(optionSelector);
                    candidates=pool.filter(visible).filter(enabled).filter(e=>text(e)===norm(wanted));
                  }
                  candidates=[...new Set(candidates)].sort((a,b)=>{
                    const ar=norm(a.getAttribute?.('role'))==='option'?0:1,br=norm(b.getAttribute?.('role'))==='option'?0:1;
                    return ar-br||(a.getBoundingClientRect().width*a.getBoundingClientRect().height)-(b.getBoundingClientRect().width*b.getBoundingClientRect().height);
                  });
                  const option=candidates[0];
                  if(option){
                    const row=option.closest?.('[role="option"],mat-option,.mat-mdc-option,.ng-option,.p-dropdown-item,.p-select-option,.ant-select-item-option,.select2-results__option,li')||option;
                    row.setAttribute('data-itps-action-id',optionMarker);
                    return JSON.stringify({found:true,nativeReachable:row.ownerDocument===document&&row.getRootNode()===document,optionText:(row.innerText||row.textContent||'').trim(),candidateCount:candidates.length,overlay:activeRoot?{tag:activeRoot.tagName,id:activeRoot.id||'',class:String(activeRoot.className||'').slice(0,200)}:null,role:row.getAttribute?.('role')||'',tag:row.tagName});
                  }
                  let filtered=false,scrolled=false,scrollTop=-1,scrollHeight=-1;
                  const filterRoot=activeRoot||trigger?.closest?.('ng-select,.ng-select,p-dropdown,p-select,.ant-select,.select2-container')||trigger?.ownerDocument||document;
                  const input=[...(filterRoot.querySelectorAll?.('input:not([type="hidden"]),[contenteditable="true"]')||[])].find(visible);
                  if(input&&poll<=2&&input.getAttribute('data-itps-filtered-for')!==wanted){
                    input.setAttribute('data-itps-filtered-for',wanted);input.focus();
                    const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input),'value')?.set;
                    if(setter)setter.call(input,wanted);else input.value=wanted;
                    input.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:wanted}));
                    input.dispatchEvent(new Event('change',{bubbles:true,composed:true}));filtered=true;
                  }
                  if(activeRoot){
                    const scrollables=[activeRoot,...activeRoot.querySelectorAll('*')].filter(e=>e.scrollHeight>e.clientHeight+5);
                    const viewport=scrollables.sort((a,b)=>(b.clientHeight||0)-(a.clientHeight||0))[0];
                    if(viewport){const before=viewport.scrollTop;if(poll===1&&viewport.scrollTop>0)viewport.scrollTop=0;else viewport.scrollTop=Math.min(viewport.scrollHeight,viewport.scrollTop+Math.max(120,viewport.clientHeight*.8));viewport.dispatchEvent(new Event('scroll',{bubbles:true}));scrolled=viewport.scrollTop!==before;scrollTop=viewport.scrollTop;scrollHeight=viewport.scrollHeight;}
                  }
                  return JSON.stringify({found:false,reason:'OPTION_NOT_RENDERED_YET',wanted,controlled:[...controlled],overlayCount:overlays.length,activeOverlay:activeRoot?{tag:activeRoot.tagName,id:activeRoot.id||'',class:String(activeRoot.className||'').slice(0,160)}:null,filtered,scrolled,scrollTop,scrollHeight,visibleOptions:(activeRoot?[...activeRoot.querySelectorAll('[role="option"],mat-option,.ng-option,li')]:[]).filter(visible).map(e=>(e.innerText||e.textContent||'').trim()).slice(0,30)});
                })()
                """.formatted(js(request.value()), js(request.optionXPath()), js(triggerMarker), js(optionMarker), poll);
    }

    private String verifySelectionScript(Request request, String triggerMarker) {
        return """
                (() => {
                  const field=%s,wanted=%s,verifyXPath=%s,triggerXPath=%s,marker=%s;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const visible=e=>{if(!e||!(e instanceof Element))return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument)}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  const deepQuery=selector=>{const out=[];for(const d of docs)for(const r of roots(d)){try{out.push(...r.querySelectorAll(selector))}catch(ignore){}}return out;};
                  const xpathAll=xp=>{const out=[];if(!xp)return out;for(const d of docs){try{const x=d.evaluate(xp,d,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)out.push(x.snapshotItem(i));}catch(ignore){}}return out;};
                  const values=e=>{
                    const out=[];if(!e)return out;
                    if('value' in e&&String(e.value||'').trim())out.push({source:'value',value:String(e.value)});
                    if(e.tagName==='SELECT'&&e.selectedIndex>=0)out.push({source:'selectedOption',value:e.options[e.selectedIndex]?.textContent||''});
                    for(const a of ['aria-valuetext','data-value']){const v=e.getAttribute?.(a);if(v)out.push({source:a,value:v});}
                    for(const n of e.querySelectorAll?.('.ng-value-label,.ng-value,.mat-mdc-select-value-text,.mat-select-value-text,.p-dropdown-label,.p-select-label,.ant-select-selection-item,.select2-selection__rendered,[class*="single-value"],[class*="selected-value"],option:checked')||[]) {
                      const v=n.innerText||n.textContent||n.value;if(String(v||'').trim())out.push({source:'selectedChild:'+n.className,value:String(v)});
                    }
                    const own=(e.innerText||e.textContent||'').trim();if(own&&own.length<200)out.push({source:'ownText',value:own});
                    return out;
                  };
                  const exact=entries=>entries.find(x=>norm(x.value)===norm(wanted));
                  let verificationTargets=verifyXPath?xpathAll(verifyXPath):[];
                  if(verificationTargets.length){
                    const evidence=verificationTargets.flatMap(values);const hit=exact(evidence);
                    return JSON.stringify({selected:!!hit,strategy:'VERIFY_XPATH_EXACT',matched:hit||null,evidence:evidence.slice(0,30),targetCount:verificationTargets.length});
                  }
                  let trigger=deepQuery(`[data-itps-action-id="${marker}"]`)[0]||null;
                  if(!trigger&&triggerXPath)trigger=xpathAll(triggerXPath).find(visible)||null;
                  let candidates=[];if(trigger)candidates.push(trigger,trigger.closest?.('ng-select,.ng-select,mat-select,p-dropdown,p-select,.p-dropdown,.p-select,.ant-select,.select2-container,[role="combobox"],.form-field,.form-group')||trigger);
                  const comboSelector='select,ng-select,.ng-select,mat-select,.mat-mdc-select,[role="combobox"],p-dropdown,p-select,.p-dropdown,.p-select,.ant-select,.select2-container,input[aria-autocomplete="list"]';
                  const combos=deepQuery(comboSelector).filter(visible);
                  if(field){
                    for(const e of combos){
                      const attrs=[e.id,e.getAttribute?.('name'),e.getAttribute?.('aria-label'),e.getAttribute?.('placeholder')].map(norm);
                      const context=norm(e.closest?.('.form-group,.form-field,.field,[class*="field"],td,div')?.innerText||'');
                      if(attrs.some(v=>v===norm(field)||v.includes(norm(field)))||context.includes(norm(field)))candidates.push(e);
                    }
                  }
                  if(!candidates.length)candidates.push(...combos);
                  candidates=[...new Set(candidates.filter(Boolean))];
                  const evidence=candidates.flatMap(e=>values(e).map(v=>({...v,tag:e.tagName,id:e.id||'',aria:e.getAttribute?.('aria-label')||''})));
                  let hit=exact(evidence);
                  if(!hit){
                    const selectedOptions=deepQuery('[role="option"][aria-selected="true"],.ng-option-selected,.mat-mdc-option-active,.p-highlight,option:checked');
                    const selectedEvidence=selectedOptions.flatMap(values);const optionHit=exact(selectedEvidence);
                    if(optionHit){hit={...optionHit,source:'selectedOptionState'};evidence.push(...selectedEvidence);}
                  }
                  const expanded=trigger?.getAttribute?.('aria-expanded')||'';
                  return JSON.stringify({selected:!!hit,strategy:hit?'SCOPED_EXACT_SELECTED_VALUE':'NO_EXACT_SELECTED_VALUE',matched:hit||null,expected:wanted,field,candidateCount:candidates.length,ariaExpanded:expanded,evidence:evidence.slice(0,60)});
                })()
                """.formatted(js(request.field()), js(request.value()), js(request.verifyXPath()),
                js(request.effectiveTriggerXPath()), js(triggerMarker));
    }

    private String clickCompletionProbeScript(String marker, String phase) {
        return """
                (() => {
                  const marker=%s,phase=%s;
                  const visible=e=>{if(!e||!(e instanceof Element))return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument)}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  let target=null;for(const d of docs){for(const r of roots(d)){target=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(target)break;}if(target)break;}
                  const overlays=[];for(const d of docs)for(const r of roots(d))try{overlays.push(...r.querySelectorAll('[role="listbox"],.cdk-overlay-pane,.mat-mdc-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.ant-select-dropdown,.select2-dropdown,.dropdown-menu'))}catch(ignore){}
                  const visibleOverlays=overlays.filter(visible);
                  if(phase==='OPEN_DROPDOWN'){
                    const expanded=target?.getAttribute?.('aria-expanded')==='true';
                    return JSON.stringify({completed:expanded||visibleOverlays.length>0,expanded,visibleOverlayCount:visibleOverlays.length,targetPresent:!!target});
                  }
                  const selected=target?.getAttribute?.('aria-selected')==='true'||target?.classList?.contains('selected')||target?.classList?.contains('p-highlight')||target?.classList?.contains('ng-option-selected');
                  const detached=!target;
                  return JSON.stringify({completed:selected,selected,detached,targetPresent:!!target,visibleOverlayCount:visibleOverlays.length,note:detached?'DETACHED_IS_NOT_SUCCESS':null});
                })()
                """.formatted(js(marker), js(phase));
    }

    private String clickMarkerScript(String marker) {
        return """
                (() => {
                  const marker=%s;
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument)}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  let e=null;for(const d of docs){for(const r of roots(d)){e=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(e)break;}if(e)break;}
                  if(!e)return JSON.stringify({clicked:false,reason:'MARKER_NOT_FOUND',marker});
                  if(e.disabled||e.getAttribute?.('aria-disabled')==='true')return JSON.stringify({clicked:false,reason:'DISABLED'});
                  e.scrollIntoView({block:'center',inline:'center',behavior:'instant'});e.focus?.({preventScroll:true});
                  const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2;
                  const top=e.ownerDocument.elementFromPoint(x,y);const hit=!!top&&(top===e||e.contains(top));
                  if(!hit)return JSON.stringify({clicked:false,reason:'HIT_TEST_FAILED',top:top?.tagName||'',marker});
                  const target=top&&e.contains(top)?top:e;
                  const common={bubbles:true,cancelable:true,composed:true,view:e.ownerDocument.defaultView,clientX:x,clientY:y,button:0,buttons:1};
                  try{target.dispatchEvent(new PointerEvent('pointerdown',{...common,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                  target.dispatchEvent(new MouseEvent('mousedown',common));
                  try{target.dispatchEvent(new PointerEvent('pointerup',{...common,buttons:0,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                  target.dispatchEvent(new MouseEvent('mouseup',{...common,buttons:0}));
                  // Exactly one click. Do not dispatch click and then call click() again.
                  target.click();
                  return JSON.stringify({clicked:true,mode:'SINGLE_DOM_CLICK',hitTestPassed:true,tag:e.tagName,role:e.getAttribute?.('role')||'',text:(e.innerText||e.textContent||'').trim().slice(0,200)});
                })()
                """.formatted(js(marker));
    }

    private ObjectNode phase(String name, JsonNode details) {
        ObjectNode phase = mapper.createObjectNode();
        phase.put("name", name);
        phase.set("details", details == null ? mapper.nullNode() : details);
        return phase;
    }

    Request parse(String instruction) {
        String raw = LiveXPathActionExecutor.normalizeSmartQuotes(instruction == null ? "" : instruction).trim();
        String english = englishBeforeLocators(raw);
        String triggerXPath = extractNamedLocator(raw, "triggerxpath");
        String optionXPath = extractNamedLocator(raw, "optionxpath");
        String verifyXPath = firstNonBlank(extractNamedLocator(raw, "verifyxpath"), extractNamedLocator(raw, "selectedxpath"));
        String genericXPath = extractNamedLocator(raw, "xpath");
        if (optionXPath.isBlank() && looksLikeOptionXPath(genericXPath)) {
            optionXPath = genericXPath;
            genericXPath = "";
        }
        String value = extractValue(english);
        String field = extractField(english);
        return new Request(raw, english, field, value, genericXPath, triggerXPath, optionXPath, verifyXPath);
    }

    private boolean looksLikeOptionXPath(String xpath) {
        if (xpath == null || xpath.isBlank()) return false;
        String lower = xpath.toLowerCase(Locale.ROOT);
        return containsAny(lower, "role='option'", "role=\"option\"", "mat-option", "ng-option",
                "p-dropdown-item", "p-select-option", "listbox-option", "option[") ||
                lower.matches(".*(?:^|/)(?:option|li)(?:\\[|$).*" );
    }

    private String extractValue(String english) {
        if (english == null) return "";
        Matcher setQuoted = Pattern.compile("(?i)\\bset\\s+[\\\"']?[^\\\"']+?[\\\"']?\\s+to\\s+[\\\"']([^\\\"']+)[\\\"']").matcher(english);
        if (setQuoted.find()) return setQuoted.group(1).trim();
        Matcher actionQuoted = Pattern.compile("(?i)\\b(?:select|choose|pick|click|tap)\\s+[\\\"']([^\\\"']+)[\\\"']").matcher(english);
        if (actionQuoted.find()) return actionQuoted.group(1).trim();
        Matcher visibleQuoted = Pattern.compile("(?i)(?:visible\\s+(?:text|value|option)|option)\\s+[\\\"']([^\\\"']+)[\\\"']").matcher(english);
        if (visibleQuoted.find()) return visibleQuoted.group(1).trim();
        Matcher setPlain = Pattern.compile("(?i)\\bset\\s+.+?\\s+to\\s+([A-Za-z0-9._/ -]{1,80}?)(?:\\s*$|\\s+(?:using|with)\\b)").matcher(english.trim());
        if (setPlain.find()) return cleanToken(setPlain.group(1));
        Matcher actionPlain = Pattern.compile("(?i)\\b(?:select|choose|pick|click|tap)\\s+([A-Za-z0-9._/-]+)\\s+(?:from|in)\\b").matcher(english);
        if (actionPlain.find()) return cleanToken(actionPlain.group(1));
        Matcher optionPlain = Pattern.compile("(?i)\\b(?:visible\\s+(?:text|value|option)|option)\\s+([A-Za-z0-9._/-]+)").matcher(english);
        if (optionPlain.find()) return cleanToken(optionPlain.group(1));
        Matcher q = QUOTED.matcher(english);
        return q.find() ? q.group(1).trim() : "";
    }

    private String extractField(String english) {
        if (english == null) return "";
        Matcher set = Pattern.compile("(?i)\\bset\\s+[\\\"']?(.+?)[\\\"']?\\s+to\\s+").matcher(english);
        if (set.find()) return cleanField(set.group(1));
        Matcher from = Pattern.compile("(?i)\\b(?:from|in)\\s+(?:the\\s+)?(?:field\\s+)?[\\\"']?(.+?)[\\\"']?(?:\\s+(?:dropdown|drop\\s*down|combobox|combo\\s*box|field|list))?(?:\\s*$|\\s+(?:using|with)\\b)").matcher(english.trim());
        if (from.find()) return cleanField(from.group(1));
        Matcher named = Pattern.compile("(?i)\\b(?:dropdown|combobox|combo\\s*box|field)\\s+[\\\"']([^\\\"']+)[\\\"']").matcher(english);
        if (named.find()) return cleanField(named.group(1));
        return "";
    }

    private String cleanField(String field) {
        if (field == null) return "";
        return field.replaceAll("(?i)^(?:the|field)\\s+", "")
                .replaceAll("(?i)\\s+(?:dropdown|drop\\s*down|combobox|combo\\s*box|field|list)$", "")
                .replaceAll("^[\\\"']|[\\\"']$", "").replaceAll("\\s+", " ").trim();
    }

    private String cleanToken(String value) {
        return value == null ? "" : value.replaceAll("^[\\\"']|[\\\"']$", "").trim();
    }

    private String englishBeforeLocators(String raw) {
        String lower = raw.toLowerCase(Locale.ROOT);
        int earliest = raw.length();
        for (String token : LOCATOR_TOKENS) {
            for (String prefix : List.of("[" + token + "=", token + "=", token + ":", "using " + token, "following " + token)) {
                int i = lower.indexOf(prefix);
                if (i >= 0) earliest = Math.min(earliest, i);
            }
        }
        return raw.substring(0, earliest).trim();
    }

    private String extractNamedLocator(String raw, String name) {
        if (raw == null || raw.isBlank()) return "";
        String lower = raw.toLowerCase(Locale.ROOT);
        int marker = -1;
        int start = -1;
        for (String token : List.of("[" + name + "=", name + "=", name + ":", "using " + name, "following " + name)) {
            int i = indexOfLocatorToken(lower, token, name);
            if (i >= 0 && (marker < 0 || i < marker)) {
                marker = i;
                start = i + token.length();
            }
        }
        if (marker < 0) return "";
        while (start < raw.length() && (Character.isWhitespace(raw.charAt(start)) || raw.charAt(start) == '=' || raw.charAt(start) == ':')) start++;
        if (start >= raw.length()) return "";
        char quote = raw.charAt(start);
        if (quote == '\'' || quote == '"') {
            for (int i = start + 1; i < raw.length(); i++) {
                if (raw.charAt(i) == quote && raw.charAt(i - 1) != '\\') return raw.substring(start + 1, i).trim();
            }
            return "";
        }
        int end = raw.length();
        if (raw.charAt(marker) == '[') {
            int close = raw.indexOf(']', start);
            if (close > start) end = close;
        } else {
            String remainingLower = lower.substring(start);
            for (String other : LOCATOR_TOKENS) {
                if (other.equals(name)) continue;
                for (String prefix : List.of(" " + other + "=", " using " + other, " following " + other)) {
                    int i = remainingLower.indexOf(prefix);
                    if (i >= 0) end = Math.min(end, start + i);
                }
            }
        }
        return raw.substring(start, end).trim();
    }


    private int indexOfLocatorToken(String lower, String token, String name) {
        int from = 0;
        while (from < lower.length()) {
            int index = lower.indexOf(token, from);
            if (index < 0) return -1;
            if (!"xpath".equals(name) || index == 0 || !Character.isLetterOrDigit(lower.charAt(index - 1))) return index;
            from = index + 1;
        }
        return -1;
    }

    private String js(String value) {
        try {
            return mapper.writeValueAsString(value == null ? "" : value);
        } catch (Exception e) {
            return "\"\"";
        }
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty result");
        List<String> texts = new ArrayList<>();
        collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String trimmed = text == null ? "" : text.trim();
            if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) continue;
            try {
                return mapper.readTree(trimmed);
            } catch (Exception ignored) {
            }
        }
        return raw;
    }

    private void collectText(JsonNode node, List<String> output) {
        if (node == null) return;
        if (node.isTextual()) {
            output.add(node.asText());
        } else if (node.isArray()) {
            for (JsonNode child : node) collectText(child, output);
        } else if (node.isObject()) {
            node.fields().forEachRemaining(entry -> collectText(entry.getValue(), output));
        }
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) {
            throw new IllegalStateException("MCP tool returned isError=true for " + tool + ": " + compact(result.toString(), 2_000));
        }
        String text = extractText(result).toLowerCase(Locale.ROOT);
        for (String fatal : List.of("invalid selector", "timed out", "timeout", "element not found", "unable to click", "exception")) {
            if (text.contains(fatal)) throw new IllegalStateException("MCP tool failed for " + tool + ": " + compact(text, 2_000));
        }
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isValueNode()) return node.asText("");
        StringBuilder out = new StringBuilder();
        if (node.isArray()) for (JsonNode child : node) out.append(' ').append(extractText(child));
        else node.fields().forEachRemaining(entry -> out.append(' ').append(extractText(entry.getValue())));
        return out.toString();
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null &&
                tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private void requireTrue(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    private boolean containsAny(String text, String... terms) {
        String lower = text == null ? "" : text.toLowerCase(Locale.ROOT);
        for (String term : terms) if (lower.contains(term.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second == null ? "" : second;
    }

    private String displayField(String field) {
        return field == null || field.isBlank() ? "XPath/active combobox" : field;
    }

    private String compact(String text, int max) {
        if (text == null) return "";
        String compact = text.replaceAll("\\s+", " ").trim();
        return compact.length() <= max ? compact : compact.substring(0, max) + "...";
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    record Execution(String planSource, String actionJson, String toolName, String toolArguments,
                     String mcpResult, String evidence, JsonNode audit) {
    }

    private record ClickOutcome(String tool, Map<String, Object> arguments, JsonNode result) {
    }

    record Request(String raw, String english, String field, String value,
                           String genericXPath, String triggerXPath, String optionXPath,
                           String verifyXPath) {
        boolean hasUserLocator() {
            return !(genericXPath.isBlank() && triggerXPath.isBlank() && optionXPath.isBlank() && verifyXPath.isBlank());
        }

        String effectiveTriggerXPath() {
            return triggerXPath.isBlank() ? genericXPath : triggerXPath;
        }
    }
}
