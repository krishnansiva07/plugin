package com.itps.vibium.model;

import java.time.Instant;

public class RecordedAction {
    private int sequence;
    private String eventId;
    private Instant recordedAt;
    private String action;
    private String elementName;
    private String value;
    private String locatorType;
    private String locator;
    private String cssSelector;
    private String xpath;
    private String fallbackLocator;
    private String pageUrl;
    private String pageTitle;
    private String framePath;
    private boolean shadowDom;
    private boolean sensitive;
    private String prompt;

    public int getSequence() { return sequence; }
    public void setSequence(int sequence) { this.sequence = sequence; }
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    public Instant getRecordedAt() { return recordedAt; }
    public void setRecordedAt(Instant recordedAt) { this.recordedAt = recordedAt; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getElementName() { return elementName; }
    public void setElementName(String elementName) { this.elementName = elementName; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public String getLocatorType() { return locatorType; }
    public void setLocatorType(String locatorType) { this.locatorType = locatorType; }
    public String getLocator() { return locator; }
    public void setLocator(String locator) { this.locator = locator; }
    public String getCssSelector() { return cssSelector; }
    public void setCssSelector(String cssSelector) { this.cssSelector = cssSelector; }
    public String getXpath() { return xpath; }
    public void setXpath(String xpath) { this.xpath = xpath; }
    public String getFallbackLocator() { return fallbackLocator; }
    public void setFallbackLocator(String fallbackLocator) { this.fallbackLocator = fallbackLocator; }
    public String getPageUrl() { return pageUrl; }
    public void setPageUrl(String pageUrl) { this.pageUrl = pageUrl; }
    public String getPageTitle() { return pageTitle; }
    public void setPageTitle(String pageTitle) { this.pageTitle = pageTitle; }
    public String getFramePath() { return framePath; }
    public void setFramePath(String framePath) { this.framePath = framePath; }
    public boolean isShadowDom() { return shadowDom; }
    public void setShadowDom(boolean shadowDom) { this.shadowDom = shadowDom; }
    public boolean isSensitive() { return sensitive; }
    public void setSensitive(boolean sensitive) { this.sensitive = sensitive; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
}
