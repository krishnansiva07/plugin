(() => {
  'use strict';
  const VERSION = '1.0.0';
  const host = window;
  const now = () => Date.now();
  const normalize = value => String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  const short = (value, max = 120) => { const text = normalize(value); return text.length <= max ? text : text.slice(0, max - 3) + '...'; };
  const cssEscape = value => (window.CSS && CSS.escape) ? CSS.escape(String(value)) : String(value).replace(/[^a-zA-Z0-9_-]/g, ch => '\\' + ch);
  const attrEscape = value => String(value).replace(/\\/g, '\\\\').replace(/'/g, "\\'");

  if (!host.__itpsRecorder || host.__itpsRecorder.version !== VERSION) {
    let recoveredEvents = [];
    try { recoveredEvents = JSON.parse(host.sessionStorage.getItem('__itpsRecorderPending') || '[]'); if (!Array.isArray(recoveredEvents)) recoveredEvents = []; } catch (_) { recoveredEvents = []; }
    const recorder = {
      version: VERSION,
      sequence: 0,
      events: recoveredEvents,
      installedDocuments: new WeakSet(),
      pendingInputs: new Map(),
      lastEvent: null,

      persist() {
        try { host.sessionStorage.setItem('__itpsRecorderPending', JSON.stringify(this.events.slice(-200))); } catch (_) { }
      },

      isElement(value) { return !!value && value.nodeType === 1 && typeof value.tagName === 'string'; },
      isShadowRoot(value) { return !!value && value.nodeType === 11 && !!value.host; },

      isStableId(value) {
        const id = normalize(value);
        if (!id || id.length > 80) return false;
        return !(/(^ng-|^mat-|^ember|^react-select-|\d{5,}|[0-9a-f]{8}-[0-9a-f-]{20,}|_[0-9]{4,}$)/i.test(id));
      },

      isVisible(element) {
        if (!element || !this.isElement(element)) return false;
        const view = element.ownerDocument && element.ownerDocument.defaultView;
        const style = view ? view.getComputedStyle(element) : null;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && (!style || (style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0));
      },

      isUnique(root, selector) {
        try { return !!selector && root.querySelectorAll(selector).length === 1; }
        catch (_) { return false; }
      },

      stableAttribute(element) {
        for (const name of ['data-testid', 'data-test', 'data-qa', 'data-cy', 'data-automation-id', 'automation-id']) {
          const value = element.getAttribute && element.getAttribute(name);
          if (normalize(value)) return { name, value: normalize(value) };
        }
        return null;
      },

      simpleCss(element, root) {
        if (!element || !this.isElement(element)) return '';
        const tag = element.tagName.toLowerCase();
        const id = element.id;
        if (this.isStableId(id)) {
          const selector = '#' + cssEscape(id);
          if (this.isUnique(root, selector)) return selector;
        }
        const stable = this.stableAttribute(element);
        if (stable) {
          const selector = `[${stable.name}='${attrEscape(stable.value)}']`;
          if (this.isUnique(root, selector)) return selector;
        }
        for (const name of ['name', 'aria-label', 'placeholder', 'title']) {
          const value = normalize(element.getAttribute && element.getAttribute(name));
          if (!value || value.length > 100) continue;
          const selector = `${tag}[${name}='${attrEscape(value)}']`;
          if (this.isUnique(root, selector)) return selector;
        }
        const role = normalize(element.getAttribute && element.getAttribute('role'));
        const aria = normalize(element.getAttribute && element.getAttribute('aria-label'));
        if (role && aria) {
          const selector = `[role='${attrEscape(role)}'][aria-label='${attrEscape(aria)}']`;
          if (this.isUnique(root, selector)) return selector;
        }
        return '';
      },

      cssPathWithin(element, root) {
        const simple = this.simpleCss(element, root);
        if (simple) return simple;
        const parts = [];
        let current = element;
        for (let depth = 0; current && this.isElement(current) && depth < 6; depth++) {
          const stable = this.simpleCss(current, root);
          if (stable) {
            parts.unshift(stable);
            const candidate = parts.join(' > ');
            if (this.isUnique(root, candidate)) return candidate;
            break;
          }
          let part = current.tagName.toLowerCase();
          const classes = [...current.classList].filter(c => c && !/(active|focus|hover|selected|open|ng-|mat-|dirty|touched|valid|invalid|inserted)/i.test(c)).slice(0, 2);
          if (classes.length) part += classes.map(c => '.' + cssEscape(c)).join('');
          const parent = current.parentElement;
          if (parent) {
            const siblings = [...parent.children].filter(x => x.tagName === current.tagName);
            if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
          }
          parts.unshift(part);
          const candidate = parts.join(' > ');
          if (this.isUnique(root, candidate)) return candidate;
          current = parent;
          if (this.isShadowRoot(root) && current === root.host) break;
        }
        return parts.join(' > ');
      },

      cssSelector(element) {
        if (!element || !this.isElement(element)) return '';
        const root = element.getRootNode();
        if (this.isShadowRoot(root)) {
          const hostSelector = this.cssSelector(root.host);
          const inner = this.cssPathWithin(element, root);
          return hostSelector && inner ? `${hostSelector} >>> ${inner}` : inner;
        }
        return this.cssPathWithin(element, element.ownerDocument);
      },

      xpathLiteral(value) {
        const text = String(value);
        if (!text.includes("'")) return `'${text}'`;
        if (!text.includes('"')) return `"${text}"`;
        return 'concat(' + text.split("'").map((p, i) => (i ? `,"'",'${p}'` : `'${p}'`)).join('') + ')';
      },

      xpath(element) {
        if (!element || !this.isElement(element)) return '';
        if (this.isShadowRoot(element.getRootNode())) return '';
        const tag = element.tagName.toLowerCase();
        if (this.isStableId(element.id)) return `//*[@id=${this.xpathLiteral(element.id)}]`;
        const stable = this.stableAttribute(element);
        if (stable) return `//*[@${stable.name}=${this.xpathLiteral(stable.value)}]`;
        for (const name of ['name', 'aria-label', 'placeholder', 'title']) {
          const value = normalize(element.getAttribute(name));
          if (value && value.length <= 100) {
            const candidate = `//${tag}[@${name}=${this.xpathLiteral(value)}]`;
            try { if (element.ownerDocument.evaluate(`count(${candidate})`, element.ownerDocument, null, XPathResult.NUMBER_TYPE, null).numberValue === 1) return candidate; }
            catch (_) { }
          }
        }
        const text = short(element.innerText || element.textContent, 100);
        const role = normalize(element.getAttribute('role'));
        if (text && ['button', 'a', 'option', 'label', 'span', 'div', 'li'].includes(tag)) {
          const candidate = `//${tag}[normalize-space(.)=${this.xpathLiteral(text)}]`;
          try { if (element.ownerDocument.evaluate(`count(${candidate})`, element.ownerDocument, null, XPathResult.NUMBER_TYPE, null).numberValue === 1) return candidate; }
          catch (_) { }
        }
        if (role && text) {
          const candidate = `//*[@role=${this.xpathLiteral(role)} and normalize-space(.)=${this.xpathLiteral(text)}]`;
          try { if (element.ownerDocument.evaluate(`count(${candidate})`, element.ownerDocument, null, XPathResult.NUMBER_TYPE, null).numberValue === 1) return candidate; }
          catch (_) { }
        }
        const parts = [];
        let current = element;
        while (current && current.nodeType === 1 && current !== element.ownerDocument.documentElement) {
          const currentTag = current.tagName.toLowerCase();
          const siblings = current.parentElement ? [...current.parentElement.children].filter(x => x.tagName === current.tagName) : [];
          parts.unshift(currentTag + (siblings.length > 1 ? `[${siblings.indexOf(current) + 1}]` : ''));
          if (this.isStableId(current.id)) {
            parts.unshift(`*[@id=${this.xpathLiteral(current.id)}]`);
            return '//' + parts.join('/');
          }
          current = current.parentElement;
        }
        return '/' + ['html', ...parts].join('/');
      },

      labelText(element) {
        if (!element) return '';
        const aria = normalize(element.getAttribute && element.getAttribute('aria-label'));
        if (aria) return aria;
        const labelledBy = normalize(element.getAttribute && element.getAttribute('aria-labelledby'));
        if (labelledBy) {
          const value = labelledBy.split(/\s+/).map(id => element.ownerDocument.getElementById(id)).filter(Boolean).map(x => normalize(x.innerText || x.textContent)).join(' ');
          if (value) return value;
        }
        if (element.labels && element.labels.length) {
          const value = [...element.labels].map(x => normalize(x.innerText || x.textContent)).join(' ');
          if (value) return value;
        }
        const wrapping = element.closest && element.closest('label');
        if (wrapping) {
          const value = normalize(wrapping.innerText || wrapping.textContent);
          if (value) return value;
        }
        return '';
      },

      elementName(element) {
        if (!element) return 'element';
        const label = this.labelText(element);
        if (label) return short(label, 90);
        for (const name of ['title', 'placeholder', 'alt', 'name']) {
          const value = normalize(element.getAttribute && element.getAttribute(name));
          if (value) return short(value, 90);
        }
        const text = normalize(element.innerText || element.textContent);
        if (text) return short(text, 90);
        if (element.type === 'submit' && element.value) return short(element.value, 90);
        if (this.isStableId(element.id)) return element.id;
        return element.tagName ? element.tagName.toLowerCase() : 'element';
      },

      sensitiveValue(element, raw) {
        const type = normalize(element && element.type).toLowerCase();
        const metadata = normalize([element && element.name, element && element.id, element && element.autocomplete, element && element.placeholder, element && element.getAttribute && element.getAttribute('aria-label')].join(' ')).toLowerCase();
        if (type === 'password' || /(password|passwd|pwd)/.test(metadata)) return { sensitive: true, value: '${PASSWORD}' };
        if (/(one-time-code|otp|verification code)/.test(metadata)) return { sensitive: true, value: '${OTP}' };
        if (/(cvv|cvc|security code)/.test(metadata)) return { sensitive: true, value: '${CVV}' };
        if (/(token|secret|api key|authorization)/.test(metadata)) return { sensitive: true, value: '${SECRET}' };
        if (/(card number|credit card|pan number)/.test(metadata)) return { sensitive: true, value: '${CARD_NUMBER}' };
        return { sensitive: false, value: short(raw, 500) };
      },

      framePath(doc) {
        const parts = [];
        let view = doc.defaultView;
        while (view && view.frameElement) {
          const frame = view.frameElement;
          parts.unshift(this.cssSelector(frame) || frame.tagName.toLowerCase());
          try { view = frame.ownerDocument.defaultView; } catch (_) { break; }
        }
        return parts.join(' -> ');
      },

      actionableFromEvent(event) {
        const path = event.composedPath ? event.composedPath() : [event.target];
        const elements = path.filter(node => this.isElement(node));
        const first = elements[0];
        if (!first) return null;
        const customControl = first.closest && first.closest('ng-select,[role="combobox"],mat-select,.mat-mdc-select,.mat-select');
        if ((event.type === 'click' || event.type === 'dblclick') && customControl && this.isVisible(customControl)) return customControl;
        for (const element of elements) {
          if (element.matches && element.matches('button,a,input,select,textarea,option,[role="button"],[role="option"],[role="menuitem"],[role="tab"],[role="checkbox"],[role="radio"],[contenteditable="true"],[onclick],[tabindex],ng-select,mat-option,datatable-body-cell')) {
            return element;
          }
        }
        return first;
      },

      locatorFor(element) {
        const css = this.cssSelector(element);
        const xpath = this.xpath(element);
        const stableCss = css && (/^#|^\[data-|\[name=|\[aria-label=|\[placeholder=|\[title=/.test(css)) && !/:nth-of-type/.test(css);
        const textPreferred = xpath && /normalize-space|@role/.test(xpath) && ['option', 'a', 'button', 'li'].includes((element.tagName || '').toLowerCase());
        const locatorType = textPreferred || !css ? 'XPATH' : 'CSS';
        const locator = locatorType === 'XPATH' ? xpath : css;
        const fallback = locatorType === 'XPATH' ? css : xpath;
        return { locatorType, locator: locator || fallback || '', css, xpath, fallback: fallback || '', stableCss };
      },

      push(action, element, rawValue) {
        if (!element || !element.ownerDocument) return;
        const locator = this.locatorFor(element);
        if (!locator.locator) return;
        const protectedValue = this.sensitiveValue(element, rawValue == null ? '' : rawValue);
        if (action === 'DOUBLE_CLICK') {
          const cutoff = now() - 1_000;
          for (let i = this.events.length - 1; i >= 0; i--) {
            const previous = this.events[i];
            const recorded = Date.parse(previous.recordedAt || '') || 0;
            if (recorded < cutoff) break;
            if (previous.action === 'CLICK' && previous.locator === locator.locator) {
              this.events.splice(i, 1);
              break;
            }
          }
        }
        const event = {
          eventId: `${Date.now()}-${++this.sequence}`,
          recordedAt: new Date().toISOString(),
          action,
          elementName: this.elementName(element),
          value: protectedValue.value,
          sensitive: protectedValue.sensitive,
          locatorType: locator.locatorType,
          locator: locator.locator,
          cssSelector: locator.css || '',
          xpath: locator.xpath || '',
          fallbackLocator: locator.fallback || '',
          pageUrl: String(element.ownerDocument.location && element.ownerDocument.location.href || ''),
          pageTitle: String(element.ownerDocument.title || ''),
          framePath: this.framePath(element.ownerDocument),
          shadowDom: this.isShadowRoot(element.getRootNode())
        };
        const signature = `${event.action}|${event.locator}|${event.value}`;
        if (this.lastEvent && this.lastEvent.signature === signature && now() - this.lastEvent.time < 300) return;
        this.lastEvent = { signature, action: event.action, locator: event.locator, time: now() };
        this.events.push(event);
        this.persist();
      },

      scheduleInput(element) {
        const existing = this.pendingInputs.get(element);
        if (existing) clearTimeout(existing.timer);
        const capture = () => {
          this.pendingInputs.delete(element);
          this.push(element.type === 'file' ? 'UPLOAD' : 'TYPE', element, element.type === 'file' ? '${FILE_PATH}' : (element.value != null ? element.value : element.textContent));
        };
        const timer = setTimeout(capture, 550);
        this.pendingInputs.set(element, { timer, capture });
      },

      flushPendingInputs() {
        for (const pending of [...this.pendingInputs.values()]) {
          clearTimeout(pending.timer);
          pending.capture();
        }
      },

      installDocument(doc) {
        if (!doc || this.installedDocuments.has(doc)) return;
        this.installedDocuments.add(doc);
        const trusted = event => event && event.isTrusted !== false;

        doc.addEventListener('click', event => {
          if (!trusted(event)) return;
          this.flushPendingInputs();
          const element = this.actionableFromEvent(event);
          if (!element || element.closest && element.closest('[data-itps-recorder-ignore]')) return;
          if (event.detail === 0 && this.lastEvent?.action === 'PRESS' && now() - this.lastEvent.time < 700) return;
          const tag = (element.tagName || '').toLowerCase();
          const type = normalize(element.type).toLowerCase();
          if (tag === 'select' || tag === 'option' || type === 'checkbox' || type === 'radio' || type === 'file') return;
          if ((tag === 'input' || tag === 'textarea' || element.isContentEditable) && !['button', 'submit', 'reset', 'image'].includes(type) && !element.closest('ng-select,[role="combobox"]')) return;
          this.push('CLICK', element, '');
        }, true);

        doc.addEventListener('dblclick', event => {
          if (!trusted(event)) return;
          this.flushPendingInputs();
          const element = this.actionableFromEvent(event);
          if (element) this.push('DOUBLE_CLICK', element, '');
        }, true);

        doc.addEventListener('input', event => {
          if (!trusted(event)) return;
          const element = event.target;
          if (['input','textarea'].includes((element.tagName || '').toLowerCase()) || element.isContentEditable) this.scheduleInput(element);
        }, true);

        doc.addEventListener('change', event => {
          if (!trusted(event)) return;
          this.flushPendingInputs();
          const element = event.target;
          if (!this.isElement(element)) return;
          const tag = (element.tagName || '').toLowerCase();
          const type = normalize(element.type).toLowerCase();
          if (tag === 'select') {
            const option = element.options && element.selectedIndex >= 0 ? element.options[element.selectedIndex] : null;
            this.push('SELECT', element, option ? normalize(option.textContent || option.value) : element.value);
          } else if (type === 'checkbox' || type === 'radio') {
            this.push(element.checked ? 'CHECK' : 'UNCHECK', element, String(!!element.checked));
          } else if (type === 'file') {
            this.push('UPLOAD', element, '${FILE_PATH}');
          } else if (['input','textarea'].includes(tag)) {
            this.scheduleInput(element);
          }
        }, true);

        doc.addEventListener('keydown', event => {
          if (!trusted(event) || !['Enter', 'Tab', 'Escape'].includes(event.key)) return;
          this.flushPendingInputs();
          const element = this.actionableFromEvent(event);
          if (element) this.push('PRESS', element, event.key);
        }, true);
      },

      scanDocuments(doc) {
        this.installDocument(doc);
        for (const frame of doc.querySelectorAll('iframe,frame')) {
          try { if (frame.contentDocument) this.scanDocuments(frame.contentDocument); } catch (_) { }
        }
      }
    };
    host.__itpsRecorder = recorder;
  }

  const recorder = host.__itpsRecorder;
  recorder.scanDocuments(document);
  recorder.flushPendingInputs();
  const events = recorder.events.splice(0, recorder.events.length);
  try { host.sessionStorage.removeItem('__itpsRecorderPending'); } catch (_) { }
  return JSON.stringify({
    version: recorder.version,
    installed: true,
    url: String(location.href || ''),
    title: String(document.title || ''),
    events
  });
})()
