#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v mvn >/dev/null 2>&1 || { echo "ERROR: Maven is not available in PATH."; exit 1; }
exec mvn clean package
