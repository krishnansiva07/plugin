'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');

const bridgeScript = path.join(__dirname, 'local-mcp-bridge.js');

test('parallel clients receive distinct live MCP child sessions', { timeout: 15000 }, async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'itps-mcp-bridge-'));
  const fakeMcp = path.join(tempDir, 'fake-mcp.js');
  fs.writeFileSync(fakeMcp, `
    const readline = require('node:readline');
    console.error('FAKE_SESSION=' + (process.env.VIBIUM_SESSION || 'missing'));
    const input = readline.createInterface({ input: process.stdin });
    input.on('line', line => {
      const request = JSON.parse(line);
      if (!Object.prototype.hasOwnProperty.call(request, 'id')) return;
      const result = request.method === 'initialize'
        ? { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'fake-vibium', version: 'test' } }
        : request.method === 'tools/list' ? { tools: [] } : {};
      process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: request.id, result }) + '\\n');
    });
  `, 'utf8');

  const port = await availablePort();
  const configPath = path.join(tempDir, 'bridge-config.json');
  fs.writeFileSync(configPath, JSON.stringify({
    host: '127.0.0.1',
    port,
    maxClients: 4,
    childStartupSpacingMs: 10,
    windowsCommand: process.execPath,
    macCommand: process.execPath,
    command: process.execPath,
    args: [fakeMcp, 'mcp', '--screenshot-dir', path.join(tempDir, 'screenshots')],
    workingDirectory: tempDir,
    skipBrowserDownload: true
  }), 'utf8');

  const bridge = spawn(process.execPath, [bridgeScript], {
    env: { ...process.env, ITPS_MCP_BRIDGE_CONFIG: configPath },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  bridge.stdout.on('data', chunk => { output += chunk.toString('utf8'); });
  bridge.stderr.on('data', chunk => { output += chunk.toString('utf8'); });

  try {
    await waitFor(() => output.includes('Status    : READY'), 5000, () => output);
    const responses = await Promise.all([0, 1, 2].map(() => initialize(port)));
    assert.equal(responses.length, 3);
    for (const response of responses) {
      assert.equal(response.result.serverInfo.name, 'fake-vibium');
    }
    await waitFor(() => (output.match(/FAKE_SESSION=itps-/g) || []).length >= 3, 5000, () => output);
    const sessions = [...output.matchAll(/FAKE_SESSION=(itps-[^\s]+)/g)].map(match => match[1]);
    assert.equal(new Set(sessions).size, 3, output);
  } finally {
    bridge.kill('SIGTERM');
    await new Promise(resolve => bridge.once('exit', resolve));
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
});

function availablePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}

function initialize(port) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host: '127.0.0.1', port });
    let buffer = '';
    socket.setTimeout(5000, () => socket.destroy(new Error('MCP initialize timed out')));
    socket.once('error', reject);
    socket.on('data', chunk => {
      buffer += chunk.toString('utf8');
      const newline = buffer.indexOf('\n');
      if (newline < 0) return;
      const response = JSON.parse(buffer.slice(0, newline));
      socket.end();
      resolve(response);
    });
    socket.once('connect', () => socket.write(`${JSON.stringify({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'test', version: '1' } }
    })}\n`));
  });
}

async function waitFor(predicate, timeoutMs, diagnostic) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  throw new Error(`Timed out waiting for condition. Output:\n${diagnostic()}`);
}
