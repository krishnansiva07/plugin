@echo off
powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('127.0.0.1',8765); Write-Host 'READY: Local MCP bridge is listening on 127.0.0.1:8765' -ForegroundColor Green; exit 0}catch{Write-Host 'NOT READY: Start start-local-mcp-windows.cmd first.' -ForegroundColor Red; exit 1}finally{$c.Close()}"
pause
