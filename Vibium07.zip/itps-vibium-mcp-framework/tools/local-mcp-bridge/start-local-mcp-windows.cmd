@echo off
setlocal
cd /d "%~dp0"

echo Checking Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not available in PATH.
  echo Install Node.js or add node.exe to PATH, then reopen Command Prompt.
  pause
  exit /b 1
)

echo Starting the local Vibium MCP bridge...
node local-mcp-bridge.js
set EXIT_CODE=%ERRORLEVEL%
echo.
echo Local MCP bridge stopped with exit code %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
