'use strict';

/**
 * Local TCP bridge for Vibium's stdio MCP server.
 *
 * Why it exists:
 * Vibium MCP uses JSON-RPC over stdio. A Java JAR cannot attach to the stdin/stdout
 * of a Vibium process that was started manually in another terminal. This bridge is
 * started manually and exposes a localhost TCP socket. Each Java connection receives
 * its own Vibium MCP child process, which permits isolated tests to run in parallel.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const bridgeDir = __dirname;
const configPath = process.env.ITPS_MCP_BRIDGE_CONFIG
  ? path.resolve(process.env.ITPS_MCP_BRIDGE_CONFIG)
  : path.join(bridgeDir, 'local-mcp-config.json');

function fail(message) {
  console.error(`[ITPS MCP BRIDGE] ERROR: ${message}`);
  process.exit(1);
}

function loadConfig() {
  if (!fs.existsSync(configPath)) fail(`Configuration file not found: ${configPath}`);
  try {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (error) {
    fail(`Invalid JSON in ${configPath}: ${error.message}`);
  }
}

function resolveMaybeRelative(value, baseDir) {
  if (!value) return value;
  if (path.isAbsolute(value)) return value;
  // Bare commands such as vibium.cmd, vibium, node, or npx are resolved from PATH.
  if (!value.includes('/') && !value.includes('\\')) return value;
  return path.resolve(baseDir, value);
}

function commandExists(command) {
  if (!command) return false;
  if (path.isAbsolute(command) || command.includes('/') || command.includes('\\')) return fs.existsSync(command);
  const lookup = process.platform === 'win32' ? 'where' : 'which';
  return spawnSync(lookup, [command], { stdio: 'ignore', shell: process.platform === 'win32' }).status === 0;
}

const config = loadConfig();
const configDir = path.dirname(configPath);
const host = String(process.env.ITPS_MCP_HOST || config.host || '127.0.0.1');
const port = Number(process.env.ITPS_MCP_PORT || config.port || 8765);
const configuredCommand = process.env.VIBIUM_MCP_COMMAND
  || (process.platform === 'win32' ? config.windowsCommand : config.macCommand)
  || config.command;

function discoverCommand() {
  const names = process.platform === 'win32'
    ? ['vibium.cmd', 'vibe-check.cmd']
    : ['vibium', 'vibe-check'];
  const relativeCandidates = process.platform === 'win32'
    ? [
        '../vibium-portable/node_modules/.bin/vibium.cmd',
        '../vibium-portable/node_modules/.bin/vibe-check.cmd',
        '../node_modules/.bin/vibium.cmd',
        '../node_modules/.bin/vibe-check.cmd',
        '../vibium.cmd',
        '../vibe-check.cmd'
      ]
    : [
        '../vibium-portable/node_modules/.bin/vibium',
        '../vibium-portable/node_modules/.bin/vibe-check',
        '../node_modules/.bin/vibium',
        '../node_modules/.bin/vibe-check',
        '../vibium',
        '../vibe-check'
      ];
  const candidates = [];
  if (configuredCommand) candidates.push(resolveMaybeRelative(configuredCommand, configDir));
  relativeCandidates.forEach(value => candidates.push(resolveMaybeRelative(value, configDir)));
  names.forEach(value => candidates.push(value));
  return candidates.find(commandExists) || candidates[0];
}

const command = discoverCommand();
const args = Array.isArray(config.args) ? config.args.map(String) : ['mcp'];
const cwd = resolveMaybeRelative(config.workingDirectory || '.', configDir);
const skipBrowserDownload = config.skipBrowserDownload !== false;
const maxClients = Number(config.maxClients || 4);
const childStartupSpacingMs = Number(config.childStartupSpacingMs ?? 250);
const logDir = path.join(bridgeDir, 'logs');
const runtimeDir = path.join(bridgeDir, 'runtime');

if (!Number.isInteger(port) || port < 1 || port > 65535) fail(`Invalid port: ${port}`);
if (!Number.isInteger(maxClients) || maxClients < 1 || maxClients > 16) fail(`Invalid maxClients: ${maxClients}`);
if (!Number.isInteger(childStartupSpacingMs) || childStartupSpacingMs < 0 || childStartupSpacingMs > 5000) {
  fail(`Invalid childStartupSpacingMs: ${childStartupSpacingMs}`);
}
if (!commandExists(command)) {
  fail(`Vibium command not found: ${command}\nEdit ${configPath} and set windowsCommand/macCommand to the command that works manually.`);
}
fs.mkdirSync(logDir, { recursive: true });
fs.mkdirSync(runtimeDir, { recursive: true });
fs.mkdirSync(path.join(cwd, 'mcp-screenshots'), { recursive: true });

const active = new Map();
let sessionCounter = 0;
let shuttingDown = false;
let nextChildStartAt = 0;

function timestamp() {
  return new Date().toISOString();
}

function appendLog(text) {
  const logFile = path.join(logDir, `local-mcp-${new Date().toISOString().slice(0, 10)}.log`);
  fs.appendFileSync(logFile, `${timestamp()} ${text}\n`, 'utf8');
}

function stopChild(child) {
  if (!child || child.killed) return;
  try {
    if (process.platform === 'win32' && child.pid) {
      spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    } else if (child.pid) {
      child.kill('SIGTERM');
      setTimeout(() => {
        try { if (!child.killed) child.kill('SIGKILL'); } catch (_) { }
      }, 1500).unref();
    }
  } catch (_) { }
}

function readVibiumVersion() {
  try {
    const result = spawnSync(command, ['--version'], {
      cwd,
      env: { ...process.env, VIBIUM_SKIP_BROWSER_DOWNLOAD: '1' },
      encoding: 'utf8',
      shell: process.platform === 'win32',
      timeout: 10000,
      windowsHide: true
    });
    return String(result.stdout || result.stderr || '').trim().split(/\r?\n/)[0] || 'unknown';
  } catch (_) {
    return 'unknown';
  }
}

function scheduleChildStart(callback) {
  const now = Date.now();
  const scheduledAt = Math.max(now, nextChildStartAt);
  nextChildStartAt = scheduledAt + childStartupSpacingMs;
  const timer = setTimeout(callback, Math.max(0, scheduledAt - now));
  if (typeof timer.unref === 'function') timer.unref();
}

function compactDiagnostic(value, max = 3000) {
  const text = String(value || '').replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
  return text.length <= max ? text : `${text.slice(0, max)}...`;
}

function rejectJsonRpcClient(socket, message) {
  let pending = '';
  const timeout = setTimeout(() => {
    if (!socket.destroyed) socket.end(`ITPS_BRIDGE_ERROR: ${message}\n`);
  }, 5000);
  if (typeof timeout.unref === 'function') timeout.unref();
  socket.on('data', (chunk) => {
    pending += chunk.toString('utf8');
    let newline;
    while ((newline = pending.indexOf('\n')) >= 0) {
      const line = pending.slice(0, newline).trim();
      pending = pending.slice(newline + 1);
      if (!line) continue;
      try {
        const request = JSON.parse(line);
        if (Object.prototype.hasOwnProperty.call(request, 'id')) {
          clearTimeout(timeout);
          socket.end(`${JSON.stringify({
            jsonrpc: '2.0',
            id: request.id,
            error: { code: -32002, message }
          })}\n`);
          return;
        }
      } catch (_) { }
    }
  });
}

function argsForSession(sessionId) {
  const sessionScreenshotDir = path.join(cwd, 'mcp-screenshots', sessionId);
  fs.mkdirSync(sessionScreenshotDir, { recursive: true });
  const sessionArgs = [...args];
  const flagIndex = sessionArgs.findIndex(value => value.toLowerCase() === '--screenshot-dir');
  if (flagIndex >= 0) {
    if (flagIndex + 1 < sessionArgs.length) sessionArgs[flagIndex + 1] = sessionScreenshotDir;
    else sessionArgs.push(sessionScreenshotDir);
  } else {
    sessionArgs.push('--screenshot-dir', sessionScreenshotDir);
  }
  return sessionArgs;
}

const server = net.createServer((socket) => {
  const remote = `${socket.remoteAddress || 'local'}:${socket.remotePort || ''}`;
  if (active.size >= maxClients) {
    const message = `ITPS MCP bridge is busy: ${active.size}/${maxClients} browser sessions are active. Close an old recorder/run or increase maxClients.`;
    appendLog(`Rejected client ${remote}; ${active.size}/${maxClients} browser sessions are active.`);
    rejectJsonRpcClient(socket, message);
    return;
  }

  const sessionOrdinal = ++sessionCounter;
  const sessionId = `${Date.now()}-${sessionOrdinal}`;
  const sessionArgs = argsForSession(sessionId);
  const sessionRuntimeDir = path.join(runtimeDir, sessionId);
  fs.mkdirSync(sessionRuntimeDir, { recursive: true });
  const state = {
    socket,
    child: null,
    initialized: false,
    initializeRequestId: undefined,
    stderr: '',
    failureReported: false
  };
  active.set(sessionId, state);
  socket.setKeepAlive(true);
  socket.setNoDelay(true);
  socket.pause();
  let requestBuffer = '';
  socket.on('data', (chunk) => {
    requestBuffer += chunk.toString('utf8');
    let newline;
    while ((newline = requestBuffer.indexOf('\n')) >= 0) {
      const line = requestBuffer.slice(0, newline).trim();
      requestBuffer = requestBuffer.slice(newline + 1);
      if (!line) continue;
      try {
        const request = JSON.parse(line);
        if (request.method === 'initialize' && Object.prototype.hasOwnProperty.call(request, 'id')) {
          state.initializeRequestId = request.id;
        }
      } catch (_) { }
    }
  });
  socket.on('error', (error) => appendLog(`Client socket error: ${error.message}`));
  socket.on('close', () => {
    appendLog(`Client disconnected ${remote}`);
    try { if (state.child) state.child.stdin.end(); } catch (_) { }
    stopChild(state.child);
    active.delete(sessionId);
  });

  console.log(`[ITPS MCP BRIDGE] Java client connected (${remote}, session ${sessionId}). Queuing isolated Vibium MCP...`);
  appendLog(`Client connected ${remote}; session=${sessionId}; queued ${command} ${sessionArgs.join(' ')}`);

  scheduleChildStart(() => {
    if (socket.destroyed || !active.has(sessionId)) return;
    const env = {
      ...process.env,
      VIBIUM_SESSION: `itps-${sessionOrdinal}-${sessionId}`.slice(0, 64),
      ITPS_VIBIUM_SESSION_ID: sessionId,
      VIBIUM_CHROMEDRIVER_LOG_DIR: sessionRuntimeDir
    };
    if (skipBrowserDownload) env.VIBIUM_SKIP_BROWSER_DOWNLOAD = '1';

    console.log(`[ITPS MCP BRIDGE] Starting Vibium MCP session ${sessionId}...`);
    appendLog(`Spawning session=${sessionId}; VIBIUM_SESSION=${env.VIBIUM_SESSION}; command=${command} ${sessionArgs.join(' ')}`);
    const child = spawn(command, sessionArgs, {
      cwd,
      env,
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: process.platform === 'win32',
      windowsHide: false
    });
    state.child = child;
    socket.pipe(child.stdin);
    child.stdout.pipe(socket);
    socket.resume();

    let responseBuffer = '';
    child.stdout.on('data', (chunk) => {
      responseBuffer += chunk.toString('utf8');
      let newline;
      while ((newline = responseBuffer.indexOf('\n')) >= 0) {
        const line = responseBuffer.slice(0, newline).trim();
        responseBuffer = responseBuffer.slice(newline + 1);
        if (!line) continue;
        try {
          const response = JSON.parse(line);
          if (state.initializeRequestId !== undefined
              && String(response.id) === String(state.initializeRequestId)
              && response.result) {
            state.initialized = true;
          }
        } catch (_) { }
      }
    });

    child.stderr.on('data', (chunk) => {
      const text = chunk.toString('utf8').replace(/\s+$/, '');
      if (!text) return;
      state.stderr = compactDiagnostic(`${state.stderr} ${text}`);
      console.error(`[VIBIUM ${sessionId}] ${text}`);
      appendLog(`[VIBIUM STDERR session=${sessionId}] ${text}`);
    });

    child.on('error', (error) => {
      console.error(`[ITPS MCP BRIDGE] Unable to start Vibium MCP session ${sessionId}: ${error.message}`);
      appendLog(`Child process error session=${sessionId}: ${error.stack || error.message}`);
      if (!socket.destroyed && !state.failureReported && state.initializeRequestId !== undefined) {
        state.failureReported = true;
        socket.write(`${JSON.stringify({
          jsonrpc: '2.0',
          id: state.initializeRequestId,
          error: { code: -32001, message: `Vibium MCP child could not start: ${compactDiagnostic(error.message)}` }
        })}\n`);
      }
      if (!socket.destroyed) socket.end();
    });

    child.on('exit', (code, signal) => {
      const diagnostic = state.stderr
        ? `; Vibium stderr: ${state.stderr}`
        : '; inspect tools/local-mcp-bridge/logs for Vibium stderr';
      appendLog(`Vibium MCP exited session=${sessionId} code=${code} signal=${signal || ''}${diagnostic}`);
      if (!socket.destroyed && !state.initialized && !state.failureReported
          && state.initializeRequestId !== undefined) {
        state.failureReported = true;
        socket.write(`${JSON.stringify({
          jsonrpc: '2.0',
          id: state.initializeRequestId,
          error: {
            code: -32001,
            message: `Vibium MCP session exited during initialization (code=${code}, signal=${signal || 'none'})${diagnostic}`
          }
        })}\n`);
      } else if (!socket.destroyed && !state.initialized) {
        socket.write(`ITPS_BRIDGE_CHILD_EXIT: code=${code}, signal=${signal || 'none'}${diagnostic}\n`);
      }
      if (!socket.destroyed) socket.end();
      active.delete(sessionId);
      console.log(`[ITPS MCP BRIDGE] Vibium MCP session ${sessionId} ended. Active sessions: ${active.size}.`);
    });
  });
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') fail(`Port ${host}:${port} is already in use. Close the old bridge or change the port in local-mcp-config.json and application-local.properties.`);
  fail(error.stack || error.message);
});

server.listen(port, host, () => {
  const vibiumVersion = readVibiumVersion();
  console.log('============================================================');
  console.log(' ITPS LOCAL VIBIUM MCP BRIDGE');
  console.log('============================================================');
  console.log(` Listening : ${host}:${port}`);
  console.log(` Vibium    : ${command}`);
  console.log(` Version   : ${vibiumVersion}`);
  console.log(` Arguments : ${args.join(' ')}`);
  console.log(` Max users : ${maxClients} simultaneous browser sessions`);
  console.log(` Isolation : unique VIBIUM_SESSION per browser; ${childStartupSpacingMs} ms startup spacing`);
  console.log(` Config    : ${configPath}`);
  console.log(' Status    : READY - keep this window open');
  console.log(' Next      : start the framework JAR, then click Run Tests');
  console.log('============================================================');
  appendLog(`Bridge listening on ${host}:${port}; command=${command}; version=${vibiumVersion}; args=${args.join(' ')}; maxClients=${maxClients}; startupSpacingMs=${childStartupSpacingMs}`);
});

function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n[ITPS MCP BRIDGE] ${signal} received. Closing...`);
  for (const session of active.values()) {
    try { session.socket.destroy(); } catch (_) { }
    stopChild(session.child);
  }
  active.clear();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', (error) => {
  appendLog(`Uncaught exception: ${error.stack || error.message}`);
  console.error(error);
});
