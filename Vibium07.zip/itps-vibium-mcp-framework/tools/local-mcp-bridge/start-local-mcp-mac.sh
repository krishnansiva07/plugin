#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is not available in PATH."; exit 1; }
echo "Starting the local Vibium MCP bridge..."
exec node local-mcp-bridge.js
