@echo off
setlocal
cd /d "%~dp0"
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
where java >nul 2>nul || (echo ERROR: Java 17 is not available in PATH.& exit /b 1)
where mvn >nul 2>nul || (echo ERROR: Maven is not available in PATH.& exit /b 1)
echo Starting ITPS VIBIUM Framework at http://localhost:8090
mvn spring-boot:run
endlocal
