# Agentic Step Live Execution and Reporting

This source package keeps Agentic Step (LangGraph4j) as the only test execution engine.

## Added

- Real-time scenario lifecycle in the UI: PENDING -> RUNNING/RERUNNING -> final status.
- Live Total, Executed, Passed, Failed, Running, Pending and Pass Percentage counters.
- Immediate full-scenario rerun count selectable from 0 to 5.
- Full rerun attempt audit. A later successful attempt is reported as PASSED_AFTER_RERUN.
- Detailed attachment HTML (`report.html`) for every scenario/attempt/step with search and filters.
- Outlook-safe HTML (`outlook-report.html`) with the requested summary and a maximum of 25 scenario rows.
- Scenario attempt details in Excel/JSON output.

## Retry separation

- `retryCount`: LangGraph/self-healing retry inside an individual failed step.
- `failedScenarioRerunCount`: reruns the complete scenario immediately after it still ends FAILED.

## Outlook body

Table 1:
- Total Cases
- No. of Cases Executed
- No. of Cases Passed
- Pass Percentage (Passed / Executed x 100)

Table 2:
- S.No
- Scenario Name
- Status

At most 25 scenarios are included in the Outlook body. The detailed attachment contains all scenarios.
