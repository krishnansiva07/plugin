#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export VIBIUM_SKIP_BROWSER_DOWNLOAD=1
command -v java >/dev/null || { echo "ERROR: Java 17 is not available in PATH."; exit 1; }
command -v mvn >/dev/null || { echo "ERROR: Maven is not available in PATH."; exit 1; }
echo "Starting ITPS VIBIUM Framework at http://localhost:8090"
exec mvn spring-boot:run
