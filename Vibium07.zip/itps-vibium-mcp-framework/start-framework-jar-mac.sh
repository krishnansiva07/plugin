#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v java >/dev/null 2>&1 || { echo "ERROR: Java 17 or later is not available in PATH."; exit 1; }
[[ -d target ]] || { echo "ERROR: target directory does not exist. Build the project first."; exit 1; }
JAR_FILE="$(find target -maxdepth 1 -type f -name 'itps-vibium-mcp-framework-*.jar' ! -name '*original*' | head -1 || true)"
[[ -n "$JAR_FILE" ]] || { echo "ERROR: Framework JAR not found under target."; exit 1; }
echo "Starting framework with external local MCP mode: $JAR_FILE"
exec java -jar "$JAR_FILE" --spring.config.additional-location=optional:file:./config/application-local.properties
