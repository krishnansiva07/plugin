#!/usr/bin/env bash
set -euo pipefail
exec "$(dirname "$0")/tools/local-mcp-bridge/start-local-mcp-mac.sh"
