# Parallel browser pool + reporting fixes

## Execution
- Parallel execution no longer enables `Separate browser for each test`.
- Parallel execution now creates a fixed pool of 2/3/4 browser/MCP workers (bounded by scenario count).
- Browser workers are reused for the entire scenario queue.
- Immediate failed-scenario reruns execute inside the same worker/browser that ran the failed attempt.
- Parallel mode therefore never creates one new browser per scenario.
- `Separate browser for each test` remains available only for non-parallel/sequential execution.
- Parallel/separate execution uses process-stdio MCP sessions so each browser worker is isolated.

## Reports
- `report.html` remains the detailed attachment report, but is now standalone and contains no relative links to Outlook/screenshots/other artifacts.
- Screenshot links/column were removed from the detailed report.
- `outlook-report.html` remains the lightweight Outlook body report and is opened from the framework UI only.
- Added `screenshots-report.html`: screenshots are embedded as Base64 data URIs so the HTML can be emailed as a standalone attachment without broken HTTP links.
- `screenshots.zip` remains available separately.

## Tests/build fixes
- Parallel runner tests were aligned with the fixed browser-pool behavior.
- Added a 2-browser/6-scenario test that verifies only two MCP/browser processes are launched.
- Added a forced first-attempt failure test that verifies the immediate scenario rerun succeeds on the same browser worker and no extra process is created.
- Added a report attachment test verifying detailed HTML contains no Outlook/screenshot links and screenshot HTML embeds the image.
- Deterministic Agentic-Step actions can run without an LLM in unit tests; natural-language actions still enforce LLM configuration in `planStep()`.
