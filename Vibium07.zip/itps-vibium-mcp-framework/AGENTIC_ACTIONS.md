# Agentic Step Execution (LangGraph4j)

Agentic Step (LangGraph) is the only test execution engine in this version.

## Per-step flow

```text
START
  ↓
PLAN
  ↓
EXECUTE + VALIDATE
  ├─ success ─────────────→ SUCCESS → END
  └─ failure
       ↓
    HEAL / RE-PLAN
       ↓
    EXECUTE + VALIDATE
       ├─ success ─────────→ SUCCESS → END
       └─ retry exhausted ─→ FAILURE → END
```

LangGraph owns orchestration and bounded recovery. Existing Vibium MCP execution, XPath/CSS priority, visible-text handling, focused inputs, enterprise dropdowns, cookie handling and evidence validation remain unchanged.

## Two different retry levels

`retryCount` controls healing/re-planning inside one failed step.

`failedScenarioRerunCount` controls immediate reruns of the complete scenario after all step-level recovery has still left that scenario FAILED. Values are bounded to 0-5.

Every full scenario attempt is retained in the detailed report. A scenario that succeeds on a later full rerun is reported as `PASSED_AFTER_RERUN`.

## Live execution status

When a run is created, every selected scenario is immediately published as `PENDING`. During execution the backend updates the same run snapshot with:

- `PENDING`
- `RUNNING`
- `RERUNNING`
- `PASSED`
- `PASSED_HEALED`
- `PASSED_AFTER_RERUN`
- `FAILED`

The UI polls the existing run-status endpoint and shows total, executed, passed, failed, running, pending, pass percentage and each case's current status/attempt while the run is active.

## Reports

Two HTML outputs are generated:

1. `report.html` — detailed attachment report for all cases, all attempts and step-level evidence. It supports search, status filtering and recovery-type filtering.
2. `outlook-report.html` — lightweight Outlook-safe email body with only the requested summary table and a maximum of 25 scenario rows.

The Outlook summary uses pass percentage = passed / executed × 100.

## Dependency

Only LangGraph4j core is required for the graph layer:

```xml
<dependency>
    <groupId>org.bsc.langgraph4j</groupId>
    <artifactId>langgraph4j-core</artifactId>
    <version>1.8.24</version>
</dependency>
```

No Python LangGraph service, LangChain4j, vector database, checkpoint database or separate agent server is required.
