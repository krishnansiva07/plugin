@echo off
call "%~dp0tools\local-mcp-bridge\start-local-mcp-windows.cmd"
