@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo ERROR: Java 17 or later is not available in PATH.& pause& exit /b 1)

set "JAR_FILE="
for %%F in (target\itps-vibium-mcp-framework-*.jar) do (
  if exist "%%F" (
    echo %%~nxF | findstr /I /V "original" >nul && set "JAR_FILE=%%F"
  )
)
if not defined JAR_FILE (
  echo ERROR: Framework JAR was not found under target.
  echo Run build-windows.cmd on a machine with Maven, or copy the packaged JAR into target.
  pause
  exit /b 1
)

echo Starting framework with external local MCP mode...
echo JAR: %JAR_FILE%
echo Open http://localhost:8090 after startup.
java -jar "%JAR_FILE%" --spring.config.additional-location=optional:file:./config/application-local.properties
set EXIT_CODE=%ERRORLEVEL%
pause
exit /b %EXIT_CODE%
