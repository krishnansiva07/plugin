@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo ERROR: Java 17 or later is not available in PATH.& pause& exit /b 1)
where mvn >nul 2>nul || (echo ERROR: Maven is not available in PATH.& pause& exit /b 1)
call mvn clean package
if errorlevel 1 (pause& exit /b 1)
echo Build completed. Use start-local-mcp-windows.cmd first, then start-framework-jar-windows.cmd.
pause
