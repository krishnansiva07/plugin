let astraRecording = false;
let astraActionConfig = null;
let lastInputTimers = new WeakMap();
let highlighted;

chrome.storage.local.get(['astraRecording','astraActionConfig'], data => {
  astraRecording = Boolean(data.astraRecording);
  astraActionConfig = data.astraActionConfig || null;
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'ASTRA_RECORDING_STATE') {
    astraRecording = Boolean(msg.recording);
    astraActionConfig = msg.actionConfig;
  }
});

function onCaptureEvent(e) {
  if (!astraRecording || !astraActionConfig) return;
  const target = getUsefulTarget(e.target);
  if (!target || shouldIgnore(target)) return;

  const selected = astraActionConfig.actionType;
  const eventType = e.type;

  // Respect action-first model. For text actions, capture input/change. For click-ish actions, capture click/dblclick/contextmenu.
  const textActions = ['TYPE','CLEAR_AND_TYPE','JS_FILL_TEXT','PASTE_TEXT','SLOW_TYPE'];
  const clickActions = ['CLICK','HOVER_AND_CLICK','SCROLL_AND_CLICK','JS_CLICK','DOUBLE_CLICK','RIGHT_CLICK','DROPDOWN','CHECKBOX_RADIO','ASSERT_ONLY','CUSTOM','UPLOAD'];
  const keyActions = ['KEYBOARD'];

  if (textActions.includes(selected) && !['input','change'].includes(eventType)) return;
  if (clickActions.includes(selected) && !['click','dblclick','contextmenu','change'].includes(eventType)) return;
  if (keyActions.includes(selected) && eventType !== 'keydown') return;

  if (textActions.includes(selected)) {
    clearTimeout(lastInputTimers.get(target));
    lastInputTimers.set(target, setTimeout(() => capture(target, e), 450));
    return;
  }
  capture(target, e);
}

function capture(target, e) {
  const snapshot = buildElementSnapshot(target);
  const actualCapturedEvent = {
    eventType: e.type,
    inputType: e.inputType || null,
    key: e.key || null,
    valuePolicy: buildValuePolicy(target)
  };
  const intent = buildIntent(astraActionConfig, snapshot);
  const automationHints = buildAutomationHints(astraActionConfig, snapshot);
  highlight(target);
  chrome.runtime.sendMessage({
    type: 'ASTRA_CAPTURED_ACTION',
    page: { url: location.href, title: document.title },
    selectedAction: astraActionConfig,
    actualCapturedEvent,
    intent,
    elementSnapshot: snapshot,
    automationHints
  }).catch(() => {});
}

document.addEventListener('click', onCaptureEvent, true);
document.addEventListener('dblclick', onCaptureEvent, true);
document.addEventListener('contextmenu', onCaptureEvent, true);
document.addEventListener('input', onCaptureEvent, true);
document.addEventListener('change', onCaptureEvent, true);
document.addEventListener('keydown', onCaptureEvent, true);

function getUsefulTarget(el) {
  if (!el || el.nodeType !== 1) return null;
  return el.closest('button,a,input,textarea,select,[role="button"],[role="link"],[role="textbox"],[role="combobox"],[role="checkbox"],[role="radio"],[contenteditable="true"],[data-testid],[data-test],[data-qa],[data-cy]') || el;
}

function shouldIgnore(el) {
  if (!el || el === document.body || el === document.documentElement) return true;
  const tag = el.tagName.toLowerCase();
  if (['html','body','script','style','meta','link'].includes(tag)) return true;
  return false;
}

function buildElementSnapshot(el) {
  const targetElement = getTargetElement(el);
  const locatorCandidates = computeLocators(el, targetElement);
  const rankedLocators = rankLocators(locatorCandidates, el);
  const recommended = rankedLocators[0] || null;
  const warnings = buildWarnings(el, rankedLocators, targetElement);
  return {
    targetElement,
    locatorCandidates,
    rankedLocators,
    recommendedLocator: recommended,
    locatorWarnings: warnings,
    domContext: buildDomContext(el),
    advancedContext: {
      frameContext: getFrameContext(),
      shadowDomContext: getShadowDomContext(el),
      tableContext: getTableContext(el)
    }
  };
}

function getTargetElement(el) {
  const tag = el.tagName.toLowerCase();
  const text = normalizeText(el.innerText || el.textContent || '');
  const dataAttrs = {};
  for (const a of el.attributes || []) {
    if (a.name.startsWith('data-')) dataAttrs[a.name] = a.value;
  }
  return {
    tag,
    elementType: getElementType(el),
    id: el.getAttribute('id') || '',
    name: el.getAttribute('name') || '',
    className: compactClass(el.className || ''),
    type: el.getAttribute('type') || '',
    href: el.getAttribute('href') || '',
    linkText: tag === 'a' ? text : null,
    partialLinkText: tag === 'a' && text ? text.slice(0, Math.min(30, text.length)) : null,
    visibleText: text.slice(0, 140),
    label: findLabel(el),
    placeholder: el.getAttribute('placeholder') || '',
    title: el.getAttribute('title') || '',
    ariaLabel: el.getAttribute('aria-label') || '',
    role: getRole(el),
    dataAttributes: dataAttrs,
    isContentEditable: el.isContentEditable || false,
    isVisible: isVisible(el)
  };
}

function getElementType(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === 'input') return el.type || 'input';
  if (tag === 'select') return 'native-select';
  if (tag === 'textarea') return 'textarea';
  if (tag === 'a') return 'link';
  if (tag === 'button') return 'button';
  if (el.getAttribute('role')) return el.getAttribute('role');
  if (el.isContentEditable) return 'contenteditable';
  return tag;
}

function getRole(el) {
  return el.getAttribute('role') || implicitRole(el);
}

function implicitRole(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === 'button') return 'button';
  if (tag === 'a' && el.href) return 'link';
  if (tag === 'select') return 'combobox';
  if (tag === 'textarea') return 'textbox';
  if (tag === 'input') {
    if (['button','submit','reset'].includes(el.type)) return 'button';
    if (el.type === 'checkbox') return 'checkbox';
    if (el.type === 'radio') return 'radio';
    return 'textbox';
  }
  return '';
}

function computeLocators(el, meta) {
  const out = {};
  const dataPriority = ['data-testid','data-test','data-qa','data-cy','data-automation','data-test-id'];
  for (const d of dataPriority) {
    const v = el.getAttribute(d);
    if (v) out[d] = makeCandidate(d, `[${d}='${cssEscape(v)}']`, v, el);
  }
  if (meta.id) out.id = makeCandidate('id', `#${cssEscape(meta.id)}`, meta.id, el);
  if (meta.name) out.name = makeCandidate('name', `[name='${cssEscape(meta.name)}']`, meta.name, el);
  if (meta.ariaLabel) out.ariaLabel = makeCandidate('aria-label', `[aria-label='${cssEscape(meta.ariaLabel)}']`, meta.ariaLabel, el);
  if (meta.placeholder) out.placeholder = makeCandidate('placeholder', `[placeholder='${cssEscape(meta.placeholder)}']`, meta.placeholder, el);
  if (meta.label) out.label = { strategy:'label', value: meta.label, selector: null, unique: countLabels(meta.label) === 1, score: 0, reason: 'Associated visible label' };
  if (meta.linkText) out.linkText = { strategy:'linkText', value: meta.linkText, selector: null, unique: countLinkText(meta.linkText, false) === 1, score: 0, reason:'Anchor link text' };
  if (meta.partialLinkText) out.partialLinkText = { strategy:'partialLinkText', value: meta.partialLinkText, selector: null, unique: countLinkText(meta.partialLinkText, true) === 1, score: 0, reason:'Partial anchor link text' };
  if (meta.className) {
    const cls = String(meta.className).split(/\s+/).filter(Boolean)[0];
    if (cls) out.className = makeCandidate('className', `.${cssEscape(cls)}`, cls, el);
  }
  out.cssSelector = makeCandidate('cssSelector', buildCssSelector(el), buildCssSelector(el), el);
  out.xpath = { strategy:'xpath', value: buildXPath(el), selector: buildXPath(el), unique: countXPath(buildXPath(el)) === 1, score: 0, reason:'Generic XPath fallback' };
  const contextXpath = buildContextXPath(el, meta);
  if (contextXpath) out.contextXPath = { strategy:'contextXPath', value: contextXpath, selector: contextXpath, unique: countXPath(contextXpath) === 1, score: 0, reason:'Context-aware XPath with nearby form/heading/text' };
  if (meta.visibleText && ['button','a'].includes(meta.tag)) {
    out.text = { strategy:'text', value: meta.visibleText, selector: null, unique: countText(meta.visibleText, meta.tag) === 1, score: 0, reason:'Visible element text' };
  }
  out.tagName = { strategy:'tagName', value: meta.tag, selector: meta.tag, unique: document.getElementsByTagName(meta.tag).length === 1, score: 0, reason:'Tag name fallback only' };
  return out;
}

function makeCandidate(strategy, selector, value, el) {
  return { strategy, value, selector, unique: countCss(selector) === 1, score: 0, reason: '' };
}

function rankLocators(candidates, el) {
  const base = {
    'data-testid': 98, 'data-test': 97, 'data-qa': 97, 'data-cy': 96, 'data-automation': 95, 'data-test-id': 96,
    id: 90, name: 86, 'aria-label': 84, label: 88, placeholder: 78, linkText: 82, partialLinkText: 68,
    cssSelector: 72, xpath: 66, contextXPath: 78, text: 74, className: 45, tagName: 15
  };
  return Object.values(candidates).map(c => {
    let score = base[c.strategy] ?? 50;
    let reason = defaultReason(c.strategy);
    if (!c.unique) { score -= 25; reason += '; not unique'; }
    if (isDynamic(c.value)) { score -= 30; reason += '; appears dynamic'; }
    if (String(c.value || '').length > 90) { score -= 8; reason += '; long locator'; }
    if (c.strategy === 'className' && /^(ng-|css-|sc-|chakra-|Mui|ant-|mat-|v-)/.test(String(c.value))) { score -= 20; reason += '; framework/generated class risk'; }
    score = Math.max(1, Math.min(100, score));
    return { ...c, score, recommended: false, reason };
  }).sort((a,b) => b.score - a.score).map((c, i) => ({ ...c, recommended: i === 0 }));
}

function buildWarnings(el, ranked, meta) {
  const warnings = [];
  if (!ranked.length) warnings.push('No locator candidates found. Manual locator may be required.');
  const best = ranked[0];
  if (best && best.score < 60) warnings.push('Best locator confidence is low. Add data-testid/data-qa if possible.');
  for (const c of ranked) {
    if (isDynamic(c.value)) warnings.push(`${c.strategy} appears dynamic: ${c.value}`);
  }
  if (meta.className && meta.className.split(/\s+/).length > 5) warnings.push('Element has many classes; class locator may be brittle.');
  if (meta.tag === 'div' && ['combobox','listbox'].includes(meta.role)) warnings.push('Custom dropdown detected. Native Select handling may not work.');
  if (!meta.visibleText && !meta.label && !meta.ariaLabel && !meta.placeholder && !meta.id && !meta.name) warnings.push('Element has weak human-readable identity.');
  return [...new Set(warnings)].slice(0, 8);
}

function buildDomContext(el) {
  const form = el.closest('form');
  const modal = el.closest('[role="dialog"], .modal, [aria-modal="true"]');
  const heading = nearestHeading(el);
  const parent = nearestMeaningfulParent(el);
  return {
    nearestHeading: heading,
    nearestForm: form ? summarizeElement(form, 'form') : null,
    nearestModal: modal ? summarizeElement(modal, 'modal') : null,
    parentContext: parent ? summarizeElement(parent, 'parent') : null,
    parentSummary: normalizeText((parent || form || el.parentElement || el).innerText || '').slice(0, 260),
    relationshipContext: {
      nearestLabel: findLabel(el),
      aboveText: nearbyText(el, 'above'),
      belowText: nearbyText(el, 'below'),
      leftText: nearbyText(el, 'left'),
      rightText: nearbyText(el, 'right')
    },
    parentChain: parentChain(el, 3)
  };
}

function summarizeElement(el, kind) {
  if (!el) return null;
  return {
    kind,
    tag: el.tagName.toLowerCase(),
    id: el.id || '',
    name: el.getAttribute('name') || '',
    role: el.getAttribute('role') || '',
    classHint: compactClass(el.className || ''),
    textSummary: normalizeText(el.innerText || '').slice(0, 180),
    cssSelector: buildCssSelector(el),
    xpath: buildXPath(el)
  };
}

function parentChain(el, max) {
  const chain = [];
  let p = el.parentElement;
  while (p && p !== document.body && chain.length < max) {
    chain.push(summarizeElement(p, `parent-${chain.length + 1}`));
    p = p.parentElement;
  }
  return chain;
}

function getFrameContext() {
  return {
    insideIframe: window.top !== window.self,
    frameUrl: window.location.href,
    iframeName: window.name || null,
    note: window.top !== window.self ? 'Element captured inside iframe. Automation must switch to frame before interaction.' : null
  };
}

function getShadowDomContext(el) {
  const root = el.getRootNode && el.getRootNode();
  const inside = root && root.toString && root.toString() === '[object ShadowRoot]';
  const host = inside ? root.host : null;
  return {
    insideShadowDom: Boolean(inside),
    hostTag: host ? host.tagName.toLowerCase() : null,
    hostLocator: host ? buildCssSelector(host) : null,
    note: inside ? 'Element is inside Shadow DOM. Automation must pierce or handle shadow root depending on framework.' : null
  };
}

function getTableContext(el) {
  const table = el.closest('table');
  if (!table) return null;
  const cell = el.closest('td,th');
  const row = el.closest('tr');
  const headers = Array.from(table.querySelectorAll('thead th')).map(h => normalizeText(h.innerText));
  const cells = row ? Array.from(row.children) : [];
  const colIndex = cell ? cells.indexOf(cell) : -1;
  const related = {};
  if (row && headers.length) {
    Array.from(row.children).forEach((td, i) => { if (headers[i]) related[headers[i]] = normalizeText(td.innerText).slice(0, 80); });
  }
  return {
    tableSummary: normalizeText(table.caption?.innerText || nearestHeading(table) || '').slice(0, 100),
    rowIndex: row ? Array.from(table.querySelectorAll('tr')).indexOf(row) : -1,
    columnIndex: colIndex,
    columnName: headers[colIndex] || null,
    rowText: row ? normalizeText(row.innerText).slice(0, 220) : null,
    relatedCellValues: related
  };
}

function buildValuePolicy(el) {
  const cfg = astraActionConfig?.options || {};
  const raw = 'value' in el ? el.value : '';
  const sensitive = isSensitive(el, raw);
  if (!raw) return { captured: false, maskedValue: null, reason: 'No entered value captured' };
  if (cfg.maskEnteredValue || cfg.treatValueAsTestDataVariable || sensitive) {
    return { captured: false, maskedValue: variableNameFor(el), reason: sensitive ? 'Sensitive value masked' : 'Configured to use test data variable' };
  }
  return { captured: true, value: raw, reason: 'Value captured because masking is disabled' };
}

function variableNameFor(el) {
  const label = findLabel(el) || el.name || el.id || el.placeholder || el.type || 'VALUE';
  return `<TEST_DATA_${label.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_|_$/g, '')}>`;
}

function isSensitive(el, value) {
  const t = (el.type || '').toLowerCase();
  const n = `${el.name || ''} ${el.id || ''} ${el.placeholder || ''}`.toLowerCase();
  return t === 'password' || /password|pwd|otp|token|secret|email|phone|mobile|aadhaar|ssn|card|cvv|pin/.test(n) || /^\d{6,}$/.test(value || '');
}

function buildIntent(cfg, snapshot) {
  const action = cfg.actionType;
  const el = snapshot.targetElement;
  const name = el.label || el.ariaLabel || el.placeholder || el.visibleText || el.name || el.id || el.tag;
  const actionText = ({
    CLICK:'Click', HOVER_AND_CLICK:'Hover and click', SCROLL_AND_CLICK:'Scroll and click', JS_CLICK:'JavaScript click', DOUBLE_CLICK:'Double click', RIGHT_CLICK:'Right click', TYPE:'Type into', CLEAR_AND_TYPE:'Clear and type into', JS_FILL_TEXT:'JavaScript fill', PASTE_TEXT:'Paste into', SLOW_TYPE:'Slow type into', DROPDOWN:'Handle dropdown', CHECKBOX_RADIO:'Select checkbox/radio', KEYBOARD:'Keyboard action on', UPLOAD:'Upload file using', ASSERT_ONLY:'Assert element', CUSTOM:'Custom action on'
  })[action] || action;
  return `${actionText} ${name}`.trim();
}

function buildAutomationHints(cfg, snapshot) {
  const opts = cfg.options || {};
  const hints = [];
  if (opts.scrollBeforeAction) hints.push('Scroll element into view before action');
  if (opts.hoverBeforeAction) hints.push('Mouse hover before action');
  if (opts.useJavaScriptExecutor) hints.push('Use JavaScript executor for interaction');
  if (opts.doubleClick) hints.push('Perform double click');
  if (opts.clearBeforeTyping) hints.push('Clear existing value before typing');
  if (opts.pressTabAfter) hints.push('Press Tab after action');
  if (opts.pressEnterAfter) hints.push('Press Enter after action');
  if (cfg.comments?.dropdownComment) hints.push(`Dropdown handling: ${cfg.comments.dropdownComment}`);
  if (cfg.comments?.automationComment) hints.push(cfg.comments.automationComment);
  return {
    preferredInteraction: cfg.actionType,
    requiresScroll: opts.scrollBeforeAction || cfg.actionType === 'SCROLL_AND_CLICK',
    requiresHoverBeforeClick: opts.hoverBeforeAction || cfg.actionType === 'HOVER_AND_CLICK',
    requiresJavaScriptExecutor: opts.useJavaScriptExecutor || ['JS_CLICK','JS_FILL_TEXT'].includes(cfg.actionType),
    requiresDoubleClick: opts.doubleClick || cfg.actionType === 'DOUBLE_CLICK',
    keyboardAfterAction: opts.pressTabAfter ? 'TAB' : opts.pressEnterAfter ? 'ENTER' : null,
    waitBeforeActionMs: opts.waitBeforeActionMs,
    waitAfterActionMs: opts.waitAfterActionMs,
    notes: hints
  };
}

function findLabel(el) {
  if (!el) return '';
  if (el.id) {
    const label = document.querySelector(`label[for='${cssEscape(el.id)}']`);
    if (label) return normalizeText(label.innerText);
  }
  const wrapping = el.closest('label');
  if (wrapping) return normalizeText(wrapping.innerText);
  const aria = el.getAttribute('aria-labelledby');
  if (aria) {
    const txt = aria.split(/\s+/).map(id => document.getElementById(id)?.innerText || '').join(' ');
    if (normalizeText(txt)) return normalizeText(txt);
  }
  const parent = el.parentElement;
  if (parent) {
    const prev = el.previousElementSibling;
    if (prev && ['label','span','div'].includes(prev.tagName.toLowerCase())) return normalizeText(prev.innerText).slice(0, 80);
    const label = parent.querySelector('label');
    if (label) return normalizeText(label.innerText).slice(0, 80);
  }
  return '';
}

function nearestHeading(el) {
  const headings = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]')).filter(isVisible);
  if (!headings.length) return null;
  const er = el.getBoundingClientRect();
  let best = null, bestDist = Infinity;
  for (const h of headings) {
    const r = h.getBoundingClientRect();
    const dy = er.top - r.bottom;
    const dist = Math.abs(dy) + Math.abs(er.left - r.left) * 0.15;
    if (dy >= -80 && dist < bestDist) { best = h; bestDist = dist; }
  }
  return best ? normalizeText(best.innerText).slice(0, 120) : null;
}

function nearestMeaningfulParent(el) {
  return el.closest('[data-testid],[data-test],[data-qa],[role="dialog"],[role="group"],section,article,form,.card,.panel,.modal,.container') || el.parentElement;
}

function nearbyText(el, direction) {
  const r = el.getBoundingClientRect();
  const nodes = Array.from(document.body.querySelectorAll('label,span,div,p,td,th')).filter(n => n !== el && isVisible(n));
  let best = '', bestScore = Infinity;
  for (const n of nodes) {
    const t = normalizeText(n.innerText || n.textContent || '');
    if (!t || t.length > 80) continue;
    const nr = n.getBoundingClientRect();
    let valid = false, score = Infinity;
    if (direction === 'above') { valid = nr.bottom <= r.top; score = r.top - nr.bottom + Math.abs(r.left - nr.left) * .3; }
    if (direction === 'below') { valid = nr.top >= r.bottom; score = nr.top - r.bottom + Math.abs(r.left - nr.left) * .3; }
    if (direction === 'left') { valid = nr.right <= r.left && Math.abs(nr.top - r.top) < 40; score = r.left - nr.right; }
    if (direction === 'right') { valid = nr.left >= r.right && Math.abs(nr.top - r.top) < 40; score = nr.left - r.right; }
    if (valid && score < bestScore) { best = t; bestScore = score; }
  }
  return best || '';
}

function buildCssSelector(el) {
  if (el.id && !isDynamic(el.id)) return `${el.tagName.toLowerCase()}#${cssEscape(el.id)}`;
  const data = ['data-testid','data-test','data-qa','data-cy'].find(d => el.getAttribute(d));
  if (data) return `${el.tagName.toLowerCase()}[${data}='${cssEscape(el.getAttribute(data))}']`;
  if (el.getAttribute('name')) return `${el.tagName.toLowerCase()}[name='${cssEscape(el.getAttribute('name'))}']`;
  let path = [];
  let cur = el;
  while (cur && cur.nodeType === 1 && cur !== document.body && path.length < 5) {
    let part = cur.tagName.toLowerCase();
    if (cur.className && typeof cur.className === 'string') {
      const stable = cur.className.split(/\s+/).filter(c => c && !isDynamic(c))[0];
      if (stable) part += `.${cssEscape(stable)}`;
    }
    const parent = cur.parentElement;
    if (parent) {
      const same = Array.from(parent.children).filter(x => x.tagName === cur.tagName);
      if (same.length > 1) part += `:nth-of-type(${same.indexOf(cur) + 1})`;
    }
    path.unshift(part);
    cur = cur.parentElement;
  }
  return path.join(' > ');
}

function buildXPath(el) {
  if (el.id && !isDynamic(el.id)) return `//${el.tagName.toLowerCase()}[@id='${xq(el.id)}']`;
  const data = ['data-testid','data-test','data-qa','data-cy'].find(d => el.getAttribute(d));
  if (data) return `//${el.tagName.toLowerCase()}[@${data}='${xq(el.getAttribute(data))}']`;
  if (el.getAttribute('name')) return `//${el.tagName.toLowerCase()}[@name='${xq(el.getAttribute('name'))}']`;
  const text = normalizeText(el.innerText || el.textContent || '');
  if (text && text.length < 80) return `//${el.tagName.toLowerCase()}[normalize-space()='${xq(text)}']`;
  let parts = [];
  let cur = el;
  while (cur && cur.nodeType === 1 && cur !== document.body) {
    const ix = Array.from(cur.parentNode ? cur.parentNode.children : []).filter(n => n.tagName === cur.tagName).indexOf(cur) + 1;
    parts.unshift(`${cur.tagName.toLowerCase()}[${ix}]`);
    cur = cur.parentElement;
  }
  return '/' + parts.join('/');
}

function buildContextXPath(el, meta) {
  const form = el.closest('form');
  const heading = nearestHeading(el);
  const text = meta.visibleText || meta.label || meta.ariaLabel || meta.placeholder;
  if (form && text) return `//form[contains(normalize-space(), '${xq((heading || '').slice(0,30))}')]//${meta.tag}[contains(normalize-space(), '${xq(text.slice(0,40))}') or @placeholder='${xq(text)}' or @aria-label='${xq(text)}']`;
  return null;
}

function countCss(selector) { try { return document.querySelectorAll(selector).length; } catch { return 0; } }
function countXPath(xpath) { try { return document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength; } catch { return 0; } }
function countText(text, tag) { return Array.from(document.querySelectorAll(tag || '*')).filter(e => normalizeText(e.innerText || e.textContent) === text).length; }
function countLinkText(text, partial) { return Array.from(document.querySelectorAll('a')).filter(a => partial ? normalizeText(a.innerText).includes(text) : normalizeText(a.innerText) === text).length; }
function countLabels(text) { return Array.from(document.querySelectorAll('label')).filter(l => normalizeText(l.innerText) === text).length; }
function isVisible(el) { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; }
function normalizeText(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function compactClass(s) { return String(s || '').split(/\s+/).filter(Boolean).slice(0, 6).join(' '); }
function cssEscape(s) { return String(s).replace(/'/g, "\\'").replace(/\\/g, "\\\\"); }
function xq(s) { return String(s || '').replace(/'/g, "&apos;"); }
function isDynamic(v) { v = String(v || ''); return /[0-9a-f]{8}-[0-9a-f]{4}/i.test(v) || /\d{4,}/.test(v) || /(ember|react-select|ext-gen|mat-input|ng-|radix-|headlessui|generated|uuid|random)/i.test(v) || /^[a-zA-Z]+[-_][a-zA-Z0-9]{8,}$/.test(v); }
function defaultReason(strategy) {
  return ({'data-testid':'Stable test id','data-test':'Stable test attr','data-qa':'Stable QA attr','data-cy':'Stable Cypress attr',id:'Readable id',name:'Name attribute',label:'Associated label','aria-label':'Accessibility label',placeholder:'Placeholder text',linkText:'Link text',partialLinkText:'Partial link text',cssSelector:'CSS selector',xpath:'XPath fallback',contextXPath:'Context-aware XPath',text:'Visible text',className:'Class name',tagName:'Tag fallback'})[strategy] || 'Locator candidate';
}
function highlight(el) {
  try {
    if (highlighted) highlighted.remove();
    const r = el.getBoundingClientRect();
    highlighted = document.createElement('div');
    highlighted.style.cssText = `position:fixed;z-index:2147483647;left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px;border:3px solid #28c76f;border-radius:6px;pointer-events:none;box-shadow:0 0 0 4px rgba(40,199,111,.18);`;
    document.documentElement.appendChild(highlighted);
    setTimeout(() => { if (highlighted) highlighted.remove(); highlighted = null; }, 900);
  } catch {}
}
