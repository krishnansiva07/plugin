const $ = (id) => document.getElementById(id);
let recording = false;
let steps = [];
let session = null;

const DEFAULT_SESSION = () => ({
  schemaVersion: 'astra-ai.advanced-ui-recorder.v2',
  recorderName: 'Astra-Ai Advanced UI Recorder',
  recordingMode: 'action-first-generic-dom-intelligence',
  createdAt: new Date().toISOString(),
  startUrl: '',
  pageTitle: '',
  description: 'Framework-neutral UI automation recording with action options, assertions, locators, compact DOM snapshots, and automation hints.'
});

function getActionConfig() {
  return {
    actionType: $('actionType').value,
    options: {
      scrollBeforeAction: $('scrollBefore').checked,
      hoverBeforeAction: $('hoverBefore').checked,
      useJavaScriptExecutor: $('useJs').checked,
      doubleClick: $('doubleClick').checked,
      clearBeforeTyping: $('clearBefore').checked,
      pressTabAfter: $('tabAfter').checked,
      pressEnterAfter: $('enterAfter').checked,
      optionalStep: $('optionalStep').checked,
      screenshotRequired: $('screenshotRequired').checked,
      maskEnteredValue: $('maskValue').checked,
      treatValueAsTestDataVariable: $('testDataVariable').checked,
      waitBeforeActionMs: Number($('waitBefore').value || 0),
      waitAfterActionMs: Number($('waitAfter').value || 0)
    },
    comments: {
      automationComment: $('automationComment').value.trim(),
      dropdownStrategy: $('dropdownStrategy').value,
      dropdownComment: $('dropdownComment').value.trim()
    },
    assertion: {
      required: $('assertionRequired').checked,
      assertionType: $('assertionType').value,
      assertionComment: $('assertionComment').value.trim()
    }
  };
}

function setStatus(on) {
  recording = on;
  $('status').textContent = on ? 'Recording' : 'Stopped';
  $('status').className = on ? 'status on' : 'status off';
}

async function saveState() {
  await chrome.storage.local.set({ astraSession: session, astraSteps: steps, astraRecording: recording, astraActionConfig: getActionConfig() });
}

async function loadState() {
  const data = await chrome.storage.local.get(['astraSession','astraSteps','astraRecording']);
  session = data.astraSession || DEFAULT_SESSION();
  steps = data.astraSteps || [];
  setStatus(Boolean(data.astraRecording));
  render();
}

function updateActionDefaults() {
  const action = $('actionType').value;
  const isDropdown = action === 'DROPDOWN';
  $('dropdownBox').style.display = isDropdown ? 'block' : 'none';

  if (action === 'SCROLL_AND_CLICK') $('scrollBefore').checked = true;
  if (action === 'HOVER_AND_CLICK') $('hoverBefore').checked = true;
  if (action === 'JS_CLICK' || action === 'JS_FILL_TEXT') $('useJs').checked = true;
  if (action === 'DOUBLE_CLICK') $('doubleClick').checked = true;
  if (action === 'CLEAR_AND_TYPE') $('clearBefore').checked = true;
}

async function sendRecordingStateToTabs() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  for (const tab of tabs) {
    if (tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: 'ASTRA_RECORDING_STATE', recording, actionConfig: getActionConfig() }).catch(() => {});
    }
  }
}

function buildExport() {
  const high = steps.filter(s => (s.elementSnapshot?.recommendedLocator?.score || 0) >= 85).length;
  const medium = steps.filter(s => { const sc = s.elementSnapshot?.recommendedLocator?.score || 0; return sc >= 60 && sc < 85; }).length;
  const low = steps.length - high - medium;
  const warnings = steps.reduce((n, s) => n + (s.elementSnapshot?.locatorWarnings?.length || 0), 0);
  return {
    ...session,
    exportedAt: new Date().toISOString(),
    totalSteps: steps.length,
    steps,
    summary: {
      actionsCaptured: [...new Set(steps.map(s => s.selectedAction?.actionType))],
      locatorQuality: { highConfidence: high, mediumConfidence: medium, lowConfidence: low },
      warningsCount: warnings,
      assertionSteps: steps.filter(s => s.assertion?.required).length,
      optionalSteps: steps.filter(s => s.selectedAction?.options?.optionalStep).length
    }
  };
}

function compactSteps() {
  return steps.map(s => ({
    step: s.step,
    action: s.selectedAction?.actionType,
    intent: s.intent,
    recommendedLocator: s.elementSnapshot?.recommendedLocator,
    assertion: s.assertion,
    automationComment: s.selectedAction?.comments?.automationComment || '',
    dropdownComment: s.selectedAction?.comments?.dropdownComment || '',
    warnings: s.elementSnapshot?.locatorWarnings || []
  }));
}

function render() {
  $('stepCount').textContent = steps.length;
  $('stepsList').innerHTML = '';
  steps.slice().reverse().forEach(s => {
    const loc = s.elementSnapshot?.recommendedLocator;
    const div = document.createElement('div');
    div.className = 'step-item';
    div.innerHTML = `
      <div class="step-head">#${s.step} ${escapeHtml(s.selectedAction?.actionType || '')} <span class="badge">${escapeHtml(s.actualCapturedEvent?.eventType || '')}</span></div>
      <div>${escapeHtml(s.intent || '')}</div>
      <div class="step-meta">Best: ${escapeHtml(loc ? `${loc.strategy}: ${loc.value}` : 'N/A')}</div>
      ${s.assertion?.required ? `<div class="step-meta">Assertion: ${escapeHtml(s.assertion.assertionComment || s.assertion.assertionType)}</div>` : ''}
    `;
    $('stepsList').appendChild(div);
  });
  const last = steps[steps.length - 1];
  if (!last) {
    $('lastCapture').className = 'last-capture empty';
    $('lastCapture').textContent = 'No element captured yet.';
  } else {
    const loc = last.elementSnapshot?.recommendedLocator;
    const warnings = last.elementSnapshot?.locatorWarnings || [];
    $('lastCapture').className = 'last-capture';
    $('lastCapture').innerHTML = `
      <strong>${escapeHtml(last.intent || '')}</strong><br/>
      <div class="locator">${escapeHtml(loc ? `${loc.strategy}: ${loc.value}` : 'No recommended locator')}</div>
      <div>Score: <span class="score">${loc?.score ?? 'N/A'}</span></div>
      <div>Element: ${escapeHtml(last.elementSnapshot?.targetElement?.tag || '')} ${escapeHtml(last.elementSnapshot?.targetElement?.elementType || '')}</div>
      <div>Context: ${escapeHtml(last.elementSnapshot?.domContext?.nearestHeading || last.elementSnapshot?.domContext?.nearestForm || 'N/A')}</div>
      ${warnings.length ? `<div class="warn">Warnings: ${escapeHtml(warnings.join('; '))}</div>` : `<div class="score">Warnings: none</div>`}
    `;
  }
  $('jsonOutput').value = JSON.stringify(buildExport(), null, 2);
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function download(filename, text) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'ASTRA_CAPTURED_ACTION') {
    const step = {
      step: steps.length + 1,
      recordedAt: new Date().toISOString(),
      page: msg.page,
      selectedAction: msg.selectedAction,
      assertion: msg.selectedAction?.assertion,
      actualCapturedEvent: msg.actualCapturedEvent,
      intent: msg.intent,
      elementSnapshot: msg.elementSnapshot,
      automationHints: msg.automationHints
    };
    if (!session.startUrl && msg.page?.url) {
      session.startUrl = msg.page.url;
      session.pageTitle = msg.page.title || '';
    }
    steps.push(step);
    saveState();
    render();
  }
});

$('startBtn').addEventListener('click', async () => { setStatus(true); await saveState(); await sendRecordingStateToTabs(); });
$('stopBtn').addEventListener('click', async () => { setStatus(false); await saveState(); await sendRecordingStateToTabs(); });
$('clearBtn').addEventListener('click', async () => { steps = []; session = DEFAULT_SESSION(); await saveState(); render(); });
$('actionType').addEventListener('change', async () => { updateActionDefaults(); await saveState(); await sendRecordingStateToTabs(); });
document.querySelectorAll('input,select,textarea').forEach(el => el.addEventListener('change', async () => { await saveState(); await sendRecordingStateToTabs(); }));
$('assertionRequired').addEventListener('change', () => {
  const enabled = $('assertionRequired').checked;
  $('assertionType').disabled = !enabled;
  $('assertionComment').disabled = !enabled;
  $('assertionArea').className = enabled ? '' : 'disabled-area disabled';
});
$('copyJsonBtn').addEventListener('click', async () => { const txt = JSON.stringify(buildExport(), null, 2); await navigator.clipboard.writeText(txt); $('jsonOutput').value = txt; });
$('downloadJsonBtn').addEventListener('click', () => download(`astra-ai-ui-recording-${Date.now()}.json`, JSON.stringify(buildExport(), null, 2)));
$('copyCompactBtn').addEventListener('click', async () => { const txt = JSON.stringify(compactSteps(), null, 2); await navigator.clipboard.writeText(txt); $('jsonOutput').value = txt; });

loadState().then(updateActionDefaults);
