# Astra-Ai Advanced UI Recorder v2

A framework-neutral Chrome Extension for recording UI automation steps with advanced element locator intelligence.

## Purpose

This recorder is designed for automation testers working with any automation language or tool:

- Java Selenium
- Python Selenium
- C# Selenium
- Playwright
- Cypress
- WebdriverIO
- Robot Framework
- Any custom UI automation generator

It does not generate framework-specific code. It captures high-quality, generic automation evidence.

## Key Concept

This is an action-first recorder.

1. Select the action before using the application.
2. Configure advanced options such as JavaScript executor, scroll, hover, Tab, Enter, clear, waits, optional step.
3. Enable assertion if needed.
4. Perform the action in the application.
5. Recorder captures action + element + locators + DOM context + comments.

## Advanced Action Types

- Click only
- Mouse hover and click
- Scroll down and click
- JavaScript executor click
- Double click
- Right click
- Type text
- Clear and type
- JavaScript executor fill text
- Paste text
- Type slowly
- Dropdown / combobox
- Checkbox / radio
- Keyboard action
- Upload file
- Assertion only
- Custom action

## Locator Intelligence Captured

For each element, the extension computes:

- id
- name
- CSS selector
- XPath
- context-aware XPath
- link text
- partial link text
- class name
- tag name
- data-testid
- data-test
- data-qa
- data-cy
- aria-label
- label text
- placeholder
- visible text

Each locator is scored using:

- uniqueness
- stability
- dynamic ID risk
- readability
- automation friendliness
- context quality

## DOM Snapshot Strategy

The recorder does not store the full DOM.

It stores compact DOM intelligence:

- target element details
- parent chain up to 3 levels
- nearest form
- nearest heading
- nearest modal
- nearby text relationship
- table row/column context
- iframe context
- shadow DOM context

This keeps JSON small and useful for LLM or any automation generator.

## Assertion Support

Each step has:

- Assertion required checkbox
- Assertion type dropdown
- Assertion comment textbox

Assertion types include:

- Element should be visible
- Text should be displayed
- URL should contain
- Page title should contain
- Field value should equal
- Checkbox should be selected
- Dropdown value should be selected
- Table row should exist
- Error message should be displayed
- Success message should be displayed

## Install

1. Extract this folder.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Enable Developer mode.
5. Click Load unpacked.
6. Select this folder.
7. Open your application.
8. Click the extension icon.
9. Start recording.

## Export

Use:

- Copy JSON
- Download JSON
- Copy Compact Steps

The output is generic and can be consumed by any framework generator.
