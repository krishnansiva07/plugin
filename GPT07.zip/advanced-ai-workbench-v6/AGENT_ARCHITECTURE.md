# Java 17 General Agent Architecture

```text
Browser UI
 ├─ Chat / Analyze / Agent
 ├─ API key / model / vision model
 ├─ documents / images / logs / recorded JSON
 ├─ mapped project OR no project (scratch workspace)
 ├─ Allow / Ask / Deny permissions
 └─ Agent console + Stop + Approve/Deny
                     │
                     ▼
               Spring Boot / Java 17
                     │
       ┌─────────────┼──────────────────┐
       │ AgentRunRegistry               │
       │ Conversation / H2              │
       │ Context / file extraction      │
       │ Project index                  │
       │ Approval service               │
       │ OpenAI-compatible LLM client   │
       └─────────────┬──────────────────┘
                     │
                 AgentService
                     │
              MODEL DECISION LOOP
                     │
      ┌──────────────┼────────────────────────┐
      │ discovery    │ workspace              │ execution
      │ plan         │ edit/write             │ build
      │ inspect      │ mkdir                  │ tests
      │ list/glob    │ move/delete            │ command
      │ search/read  │ staged baseline        │ status/diff
      └──────────────┴────────────────────────┘
                     │
              real tool observation
                     │
                model decides again
                     │
              Completion Guard
                     │
              staged project patch
                     │
      SHA-256 preflight → backup → apply
```

## Agent run lifecycle

```text
CREATE RUN ID
    ↓
RUNNING
    ↓
prepare mapped mirror OR empty scratch workspace
    ↓
set/refresh plan
    ↓
inspect/read/search
    ↓
permission-controlled action
    ↓
real tool result
    ↓
model reasons again
    ↓
change made?
    ├─ no  → continue/final
    └─ yes → detected verification required
                 ↓
            build / validate
                 ↓
       test-related request?
            ├─ yes → tests
            └─ no
                 ↓
            changed files / diff
                 ↓
                FINAL
                 ↓
            COMPLETED
```

Terminal states are `completed`, `failed` and `cancelled`. A late Stop request cannot change an already terminal run.

## Cancellation

The run registry owns the active process reference. Stop performs three things:

1. marks the Agent Run cancelled,
2. cancels pending approval waits and the in-flight asynchronous LLM request,
3. forcibly terminates the tracked process and descendants.

Every tool boundary checks the cancellation token before continuing.

## Workspace model

### Existing mapped local project

```text
real trusted project
      ↓ copy source/config/resources (dependency/build output directories skipped)
temporary run mirror
      ↓ agent tools
staged changes
      ↓ explicit review
SHA-256 baseline preflight
      ↓
backup original targets
      ↓
apply
```

The runner can reuse an existing local `node_modules` or Python virtual environment through process environment paths so large dependency trees do not need to be copied into every mirror.

### Scratch project

```text
no project mapped
      ↓
empty temporary workspace
      ↓
agent creates complete project
      ↓
verification when supported
      ↓
Review / Download ZIP
```

## Monorepo support

`inspect_project` discovers build descriptors below the workspace root. `run_build`, `run_tests` and `run_command` accept a relative `cwd`, so a model can work independently in paths such as:

```text
backend/
frontend/
infra/
e2e/
```

The `cwd` is normalized and must remain inside the isolated workspace.

## Patch model

Each change is represented by:

```text
path
content
baselineHash
 deleted
```

A rename is represented safely as a delete of the old path plus creation/update of the new path. Deletions are backed up before apply. Downloaded patch ZIPs include `.agent-deletions.txt` when deletion operations exist.

Before any local apply happens, **all files are preflighted**. If one baseline no longer matches, nothing is written and the API returns HTTP 409 Conflict.

## Completion guard

The Java host does not rely only on the prompt to verify work. After changes, a detected build/validation must be attempted after the latest change when command execution is permitted. For test-related requests, a detected test runner must also be attempted.

The guard verifies that work was attempted, not that it passed. A legitimate unresolved build failure remains visible to the user rather than being mislabeled as success.

## Command security boundary

`ProcessBuilder` commands are executed without a general shell. The runner rejects command chaining, pipes, redirects, parent paths, absolute paths, inline interpreter programs, package publishing and selected destructive operations.

This prevents many accidental escapes, but builds and project scripts are executable code. The Java application does **not** claim OS-level sandboxing. Production environments that execute untrusted repositories should run the entire workbench/agent worker inside an OS/container sandbox with restricted mounts, network and credentials.

## Provider model

`AgentService` uses strict JSON envelopes over an OpenAI-compatible chat completion endpoint:

```json
{"type":"tool","tool":"read_file","reason":"Inspect implementation","args":{"path":"src/App.java"}}
```

or:

```json
{"type":"final","message":"..."}
```

The Java loop, permissions and tools remain provider-owned by the application rather than by one model vendor.

## Natural next extensions

The architecture is ready for additional **separate permissioned tool providers**, for example:

- LSP/navigation/diagnostics
- MCP tool registry
- browser/web research tool
- GitHub/GitLab pull-request tools
- Jira/Confluence tools
- database read/query tools
- container-isolated execution workers
- resumable agent sessions
- subagent delegation

Those should be explicit tools with scopes and permissions, not arbitrary hidden shell access.
