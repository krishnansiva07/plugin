# Architecture

See `AGENT_ARCHITECTURE.md` for the V6 Chat / Analyze / Agent architecture and permission/approval flow.

V6 remains a single Java 17 / Spring Boot application with:

- ChatGPT-style web UI
- OpenAI-compatible model client
- H2 chat history
- uploaded-file extraction and image/vision routing
- project indexing and local workspace mapping
- Java agent loop with staged tools
- Allow / Ask / Deny permission engine
- live SSE agent activity and approvals
- real Excel and patch ZIP artifacts
