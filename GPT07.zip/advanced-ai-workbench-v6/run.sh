#!/usr/bin/env bash
set -e
if [ ! -f target/advanced-ai-chat-1.3.1-SNAPSHOT.jar ]; then
  mvn clean package
fi
java -jar target/advanced-ai-chat-1.3.1-SNAPSHOT.jar
