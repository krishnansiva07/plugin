# Sample prompts — V6

## General development

`Analyze this repository and explain the request flow from the REST controller to the database. Do not change anything.`

`Fix the NullPointerException described in the uploaded log. Inspect the mapped project, make the smallest justified change, run the relevant tests, and show me the final diff.`

`Refactor the payment client so timeout/retry configuration comes from application properties. Update callers and tests, then build the project.`

`Add a new REST endpoint for retrieving order status using the existing architecture and naming conventions. Do not introduce a new framework.`

## Data / SQL

`Inspect the uploaded CSV and the mapped SQL project. Identify why the reconciliation query misses duplicate transaction IDs and propose a corrected query in Analyze mode.`

`Update the SQL migration to add the new status column, update repository mappings, and run the project tests.`

## Documentation

`Read the mapped project and update README.md with the actual local setup, build, run and API usage instructions. Keep it concise and verify commands against the project files.`

## Code review

`Review the mapped project for concurrency problems in the ingestion pipeline. Read only; rank findings by severity and cite exact files/methods.`

## Screenshot / image

`Analyze this error screenshot and explain the likely root cause. If the project is mapped, correlate the visible stack trace with the source files.`

## Recorded JSON / test automation

`Use the uploaded recorder JSON and mapped project. Focus only on Place Order from Add to Cart through Order Confirmation. Identify current automated coverage and missing functional, negative and validation cases.`

`Implement the missing Place Order automation using existing page objects and test data. Run the relevant tests, fix failures caused by your changes, and show the final diff.`

`Generate the missing Place Order cases in Excel format using these columns: Test Case ID, Scenario, Preconditions, Steps, Test Data, Expected Result, Priority.`
