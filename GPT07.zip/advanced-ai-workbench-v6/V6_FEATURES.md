# V6 — General-purpose Workbench Features

## Product scope

V6 is a **general AI workbench with a local project agent**. It is not limited to QA or automation. Test automation is one supported specialization.

## Modes

### Chat
- ChatGPT-style conversation and streaming.
- History and context management.
- File and image attachments.
- Code fences with copy/download.
- Markdown tables and Excel export.
- Uses mapped project context as reference but does not execute tools.

### Analyze
- Strictly read-only.
- Works on source code, architecture, requirements, images, JSON/CSV, SQL, logs, configuration, documentation and test assets.
- Can compare files and explain root cause, flows, dependencies, risks and suggested changes.
- No file edits or command execution.

### Agent
- General-purpose iterative workspace agent.
- Reads/searches/globs relevant files instead of dumping the full repository into every prompt.
- Creates a short plan for multi-step work.
- Performs exact edits or creates files in an isolated temporary mirror.
- Can build/test supported project types and inspect failures.
- Can run allowlisted local commands with permission controls.
- Shows tool activity and approvals in the UI.
- Produces staged changes for diff/review/apply.

## Supported workspace work

Examples include:
- feature implementation
- bug fixing
- refactoring
- API integration
- SQL/data work
- documentation
- DevOps/configuration
- code review
- project analysis
- test automation
- recorded-flow test generation

## Build/test auto-detection

- Maven
- Gradle
- npm
- Python / pytest
- Go
- Rust/Cargo
- .NET
- Makefile

## Generic image understanding

The Vision model is no longer prompted only as a UI-testing extractor. It can interpret screenshots, diagrams, code/error screenshots, tables, charts, requirements and other visual software/document context relevant to the request.

## Generic Excel output

Excel export is no longer branded as only “test cases”. Any Markdown table can become a real `.xlsx`. Test-case sheet naming/default columns are applied only when the content actually looks like test cases.

## OpenCode-style controls

- File edits: Allow / Ask / Deny
- Shell/build/tests: Allow / Ask / Deny
- Diff/status: Allow / Ask / Deny
- Optional auto-approval for actions marked Ask
- Temporary workspace isolation
- Review before applying changed files
- Backup before overwriting originals
