# V6 scope decision

Advanced AI Workbench V6 is intentionally domain-neutral.

**Core product:** Chat + read-only analysis + local workspace agent.

**Automation/testing:** a first-class use case, not the identity of the product.

The same agent loop can work on application development, API work, data/SQL, scripting, configuration, documentation, DevOps and QA because the tools operate on project files and commands rather than test-specific abstractions.
