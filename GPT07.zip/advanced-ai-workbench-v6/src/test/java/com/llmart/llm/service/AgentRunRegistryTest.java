package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunRegistryTest {
    @Test
    void tracksPlanLifecycleAndCancellation() {
        AgentRunRegistry registry = new AgentRunRegistry();
        String runId = registry.create();
        registry.start(runId);
        registry.setPlan(runId, List.of("Inspect", "Edit", "Validate"));

        Map<String,Object> running = registry.snapshot(runId);
        assertEquals("running", running.get("status"));
        assertEquals(List.of("Inspect", "Edit", "Validate"), running.get("plan"));

        assertTrue(registry.cancel(runId));
        Map<String,Object> cancelled = registry.snapshot(runId);
        assertEquals("cancelled", cancelled.get("status"));
        assertTrue((Boolean) cancelled.get("cancelled"));
        assertThrows(AgentRunRegistry.AgentCancelledException.class, () -> registry.throwIfCancelled(runId));
    }

    @Test
    void completedRunIsReportedAsCompleted() {
        AgentRunRegistry registry = new AgentRunRegistry();
        String runId = registry.create();
        registry.start(runId);
        registry.complete(runId);
        assertEquals("completed", registry.snapshot(runId).get("status"));
    }
}
