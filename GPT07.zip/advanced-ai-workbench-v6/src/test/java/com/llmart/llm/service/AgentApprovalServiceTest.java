package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;

class AgentApprovalServiceTest {
    @Test
    void approvalCanBeResolved() throws Exception {
        AgentApprovalService service = new AgentApprovalService();
        AgentApprovalService.Approval approval = service.create("run-1", "edit_file", "Edit a file");
        ExecutorService executor = Executors.newSingleThreadExecutor();
        try {
            Future<Boolean> future = executor.submit(() -> service.await(approval.id(), Duration.ofSeconds(2)));
            assertTrue(service.resolve(approval.id(), true));
            assertTrue(future.get(2, TimeUnit.SECONDS));
        } finally {
            executor.shutdownNow();
        }
    }
}
