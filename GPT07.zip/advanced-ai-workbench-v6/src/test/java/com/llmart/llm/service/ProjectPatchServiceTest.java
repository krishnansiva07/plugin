package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.*;

class ProjectPatchServiceTest {
    @Test
    void zipIncludesChangedFilesAndDeletionManifest() throws Exception {
        ProjectPatchService service = new ProjectPatchService();
        ProjectPatchRequest request = new ProjectPatchRequest("demo", List.of(
                new ProjectPatchRequest.ProjectPatchFile("src/App.java", "class App {}", "abc", false),
                new ProjectPatchRequest.ProjectPatchFile("src/Old.java", null, "def", true)
        ));

        byte[] bytes = service.zip(request);
        boolean appFound = false;
        String deletions = null;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                byte[] data = zip.readAllBytes();
                if (entry.getName().equals("src/App.java")) {
                    appFound = true;
                    assertEquals("class App {}", new String(data, StandardCharsets.UTF_8));
                }
                if (entry.getName().equals(".agent-deletions.txt")) {
                    deletions = new String(data, StandardCharsets.UTF_8);
                }
            }
        }
        assertTrue(appFound);
        assertNotNull(deletions);
        assertTrue(deletions.contains("src/Old.java"));
    }
}
