package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

@Service
public class ProjectPatchService {
    public byte[] zip(ProjectPatchRequest request) throws Exception {
        if (request == null || request.files() == null || request.files().isEmpty()) {
            throw new IllegalArgumentException("No project changes were provided");
        }
        try (ByteArrayOutputStream out = new ByteArrayOutputStream(); ZipOutputStream zip = new ZipOutputStream(out, StandardCharsets.UTF_8)) {
            Set<String> used = new HashSet<>();
            List<String> deletions = new ArrayList<>();
            for (ProjectPatchRequest.ProjectPatchFile file : request.files()) {
                if (file == null || file.path() == null || file.path().isBlank()) continue;
                String path = normalize(file.path());
                if (!used.add(path)) continue;
                if (file.deleted()) {
                    deletions.add(path);
                    continue;
                }
                ZipEntry entry = new ZipEntry(path);
                zip.putNextEntry(entry);
                zip.write((file.content() == null ? "" : file.content()).getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
            if (!deletions.isEmpty()) {
                ZipEntry manifest = new ZipEntry(".agent-deletions.txt");
                zip.putNextEntry(manifest);
                zip.write(("Delete these files when applying this patch:\n" + String.join("\n", deletions) + "\n").getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
            zip.finish();
            return out.toByteArray();
        }
    }

    private String normalize(String raw) {
        String p = raw.replace('\\', '/').replaceAll("^/+", "");
        if (p.isBlank() || p.startsWith("../") || p.contains("/../") || p.endsWith("/..")) {
            throw new SecurityException("Invalid patch path: " + raw);
        }
        return p;
    }
}
