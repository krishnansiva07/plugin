package com.llmart.llm.service;

public class ProjectPatchConflictException extends RuntimeException {
    public ProjectPatchConflictException(String message) { super(message); }
}
