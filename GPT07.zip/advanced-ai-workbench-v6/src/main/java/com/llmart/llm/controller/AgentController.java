package com.llmart.llm.controller;

import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentApprovalService approvals;
    private final AgentService agents;

    public AgentController(AgentApprovalService approvals, AgentService agents) {
        this.approvals = approvals;
        this.agents = agents;
    }

    @PostMapping("/approvals/{id}")
    public Map<String, Object> resolve(@PathVariable String id, @RequestBody Map<String, Object> body) {
        boolean approved = Boolean.TRUE.equals(body.get("approved"));
        boolean resolved = approvals.resolve(id, approved);
        return Map.of("resolved", resolved, "approved", approved);
    }

    @PostMapping("/runs/{id}/cancel")
    public Map<String,Object> cancel(@PathVariable String id) {
        return Map.of("cancelled", agents.cancel(id), "runId", id);
    }

    @GetMapping("/runs/{id}")
    public Map<String,Object> status(@PathVariable String id) {
        return agents.status(id);
    }
}
