package com.llmart.llm.service;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.repository.FileRepository;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.file.*;
import java.util.*;

@Service
public class FileService {
    private final FileRepository repository;
    private final ConversationService conversations;
    private final Path uploadRoot;
    private final Tika tika = new Tika();

    public FileService(FileRepository repository, ConversationService conversations,
                       @Value("${app.upload-dir:./data/uploads}") String uploadDir) {
        this.repository = repository;
        this.conversations = conversations;
        this.uploadRoot = Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    public FileDto save(String conversationId, MultipartFile file) throws Exception {
        conversations.require(conversationId);
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("Empty file");
        Files.createDirectories(uploadRoot.resolve(conversationId));

        String id = UUID.randomUUID().toString();
        String original = sanitizeName(Optional.ofNullable(file.getOriginalFilename()).orElse("upload.bin"));
        Path target = uploadRoot.resolve(conversationId).resolve(id + "-" + original).normalize();
        if (!target.startsWith(uploadRoot)) throw new SecurityException("Invalid file path");
        file.transferTo(target);

        String mime = file.getContentType();
        if (mime == null || mime.isBlank() || "application/octet-stream".equalsIgnoreCase(mime)) {
            try { mime = tika.detect(target); } catch (Exception e) { mime = "application/octet-stream"; }
        }
        // Browser MIME metadata is not always reliable. Prefer content detection when it identifies an image.
        try {
            String detected = tika.detect(target);
            if (detected != null && detected.startsWith("image/")) mime = detected;
        } catch (Exception ignored) {}
        String extracted = "";
        if (!mime.startsWith("image/") && !mime.startsWith("audio/") && !mime.startsWith("video/")) {
            try {
                // Preserve raw JSON/code/recording structure instead of letting document parsing flatten it.
                // This is especially important for recorded browser-flow JSON used for scoped test generation.
                if (isPlainTextFile(original, mime)) {
                    extracted = Files.readString(target);
                } else {
                    try (InputStream in = Files.newInputStream(target)) {
                        extracted = tika.parseToString(in);
                    }
                }
                if (extracted.length() > 2_000_000) extracted = extracted.substring(0, 2_000_000);
            } catch (Exception ignored) {
                extracted = "";
            }
        }

        FileEntity entity = repository.save(new FileEntity(id, conversationId, original, target.toString(),
                mime, file.getSize(), extracted));
        return dto(entity);
    }


    public List<FileDto> listForConversation(String conversationId) {
        conversations.require(conversationId);
        return repository.findByConversationId(conversationId).stream()
                .sorted(Comparator.comparing(FileEntity::getCreatedAt))
                .map(this::dto)
                .toList();
    }

    public List<FileEntity> entitiesForConversation(String conversationId) {
        conversations.require(conversationId);
        return repository.findByConversationId(conversationId).stream()
                .sorted(Comparator.comparing(FileEntity::getCreatedAt))
                .toList();
    }

    public FileEntity require(String id) {
        return repository.findById(id).orElseThrow(() -> new NoSuchElementException("File not found"));
    }

    public void cacheExtractedText(String id, String text) {
        FileEntity entity = require(id);
        String value = text == null ? "" : text;
        if (value.length() > 250_000) value = value.substring(0, 250_000);
        entity.updateExtractedText(value);
        repository.save(entity);
    }

    public List<FileEntity> requireForConversation(String conversationId, List<String> ids) {
        if (ids == null || ids.isEmpty()) return List.of();
        List<FileEntity> out = new ArrayList<>();
        for (String id : ids) {
            FileEntity f = require(id);
            if (!Objects.equals(f.getConversationId(), conversationId)) throw new SecurityException("File belongs to another conversation");
            out.add(f);
        }
        return out;
    }

    public FileSystemResource resource(String id) {
        FileEntity f = require(id);
        return new FileSystemResource(f.getStoredPath());
    }

    public FileDto dto(FileEntity f) {
        return new FileDto(f.getId(), f.getOriginalName(), f.getMimeType(), f.getSizeBytes(),
                f.getExtractedText() == null ? 0 : f.getExtractedText().length());
    }

    private boolean isPlainTextFile(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("text/") || m.contains("json") || m.contains("xml") || m.contains("yaml")) return true;
        return n.matches(".*\\.(json|jsonl|txt|md|csv|xml|html?|css|js|jsx|ts|tsx|java|kt|py|sql|ya?ml|properties|feature|robot|sh|ps1|bat|cmd)$");
    }

    private String sanitizeName(String name) {
        return name.replaceAll("[^a-zA-Z0-9._ -]", "_").replace("..", "_");
    }
}
