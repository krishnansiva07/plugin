package com.llmart.llm.service;

import com.llmart.llm.dto.*;
import com.llmart.llm.entity.*;
import com.llmart.llm.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.security.MessageDigest;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class ProjectService {
    private static final int MAX_FILE_CHARS = 2_000_000;
    private static final int MAX_INDEX_FILES = 3000;
    private static final long MAX_INDEX_BYTES = 1_500_000;
    private static final long MAX_INDEX_CHARS = 30_000_000;
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle", ".idea",
            ".next", "coverage", ".advanced-ai-chat-backup"
    );
    private static final Set<String> SECRET_NAMES = Set.of(".env", "credentials", "secrets", "id_rsa", "id_ed25519");
    private static final Set<String> TEXT_EXT = Set.of(
            "java","kt","kts","groovy","scala","xml","html","htm","css","scss","sass","less","js","jsx","ts","tsx",
            "py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp","cs","sql","graphql","gql","json","jsonl",
            "yml","yaml","toml","ini","conf","config","properties","md","txt","csv","feature","robot","sh","bash","zsh",
            "ps1","bat","cmd","gradle","mvn","jsp","ftl","mustache","vue","svelte"
    );

    private final ProjectWorkspaceRepository projects;
    private final ProjectFileRepository files;
    private final ConversationService conversations;

    public ProjectService(ProjectWorkspaceRepository projects, ProjectFileRepository files, ConversationService conversations) {
        this.projects = projects;
        this.files = files;
        this.conversations = conversations;
    }

    public ProjectDto create(String conversationId, String name) {
        conversations.require(conversationId);
        String safeName = safeName(name, "Project");
        return dto(projects.save(new ProjectWorkspaceEntity(UUID.randomUUID().toString(), conversationId, safeName)));
    }

    @Transactional
    public ProjectDto createLocal(String conversationId, String rawPath, String name) {
        conversations.require(conversationId);
        Path root = validateLocalRoot(rawPath);
        String fallback = root.getFileName() == null ? "Local project" : root.getFileName().toString();
        ProjectWorkspaceEntity entity = projects.save(new ProjectWorkspaceEntity(
                UUID.randomUUID().toString(), conversationId, safeName(name, fallback), root.toString()));
        return indexLocal(entity);
    }

    @Transactional
    public ProjectDto rescanLocal(String projectId) {
        ProjectWorkspaceEntity entity = require(projectId);
        if (!entity.hasLocalPath()) throw new IllegalArgumentException("This workspace is browser-indexed, not a local-path workspace");
        return indexLocal(entity);
    }

    public ProjectWorkspaceEntity require(String id) {
        return projects.findById(id).orElseThrow(() -> new NoSuchElementException("Project workspace not found"));
    }

    public ProjectDto get(String id) { return dto(require(id)); }

    public List<ProjectDto> listForConversation(String conversationId) {
        conversations.require(conversationId);
        return projects.findByConversationIdOrderByUpdatedAtDesc(conversationId).stream().map(this::dto).toList();
    }

    @Transactional
    public ProjectDto upsertFiles(String projectId, ProjectUploadBatch batch) {
        ProjectWorkspaceEntity project = require(projectId);
        if (batch == null || batch.files() == null || batch.files().isEmpty()) return dto(project);
        if (batch.files().size() > 100) throw new IllegalArgumentException("Upload at most 100 project files per batch");
        for (ProjectFileUpload item : batch.files()) {
            if (item == null) continue;
            upsert(projectId, item.relativePath(), item.mimeType(), item.size(), item.content());
        }
        project.touch();
        projects.save(project);
        return dto(project);
    }

    public List<ProjectFileEntity> fileEntities(String projectId) {
        require(projectId);
        return files.findByProjectId(projectId).stream()
                .sorted(Comparator.comparing(ProjectFileEntity::getRelativePath, String.CASE_INSENSITIVE_ORDER)).toList();
    }

    @Transactional
    public ProjectDto clearFiles(String projectId) {
        ProjectWorkspaceEntity project = require(projectId);
        files.deleteByProjectId(projectId);
        project.touch(); projects.save(project);
        return dto(project);
    }

    @Transactional
    public Map<String,Object> applyLocalPatch(String projectId, ProjectPatchRequest request) throws IOException {
        ProjectWorkspaceEntity project = require(projectId);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("Direct apply requires a local-path workspace");
        if (request == null || request.files() == null || request.files().isEmpty()) return Map.of("applied", 0);
        Path root = validateLocalRoot(project.getLocalPath());
        String stamp = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(java.time.ZoneId.systemDefault()).format(Instant.now());
        Path backupRoot = root.resolve(".advanced-ai-chat-backup").resolve(stamp).normalize();

        // Preflight every file before writing anything. This prevents an agent patch from silently
        // overwriting a file the user changed after the agent created its isolated mirror.
        List<String> conflicts = new ArrayList<>();
        for (ProjectPatchRequest.ProjectPatchFile change : request.files()) {
            if (change == null || change.baselineHash() == null || change.baselineHash().isBlank()) continue;
            String relative = normalizeRelativePath(change.path());
            Path target = root.resolve(relative).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Path escapes project: " + relative);
            String current = Files.exists(target) && Files.isRegularFile(target)
                    ? Files.readString(target, StandardCharsets.UTF_8) : null;
            if (!Objects.equals(change.baselineHash(), sha256(current))) conflicts.add(relative);
        }
        if (!conflicts.isEmpty()) {
            throw new ProjectPatchConflictException("Patch conflict: these files changed after the agent run started: " + String.join(", ", conflicts));
        }

        int applied = 0;
        for (ProjectPatchRequest.ProjectPatchFile change : request.files()) {
            if (change == null) continue;
            String relative = normalizeRelativePath(change.path());
            Path target = root.resolve(relative).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Path escapes project: " + relative);
            if (Files.exists(target) && Files.isRegularFile(target)) {
                Path backup = backupRoot.resolve(relative).normalize();
                if (!backup.startsWith(backupRoot)) throw new SecurityException("Invalid backup path");
                Files.createDirectories(backup.getParent());
                Files.copy(target, backup, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
            }
            if (change.deleted()) {
                Files.deleteIfExists(target);
            } else {
                Files.createDirectories(target.getParent());
                Files.writeString(target, change.content() == null ? "" : change.content(), StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            }
            applied++;
        }
        indexLocal(project);
        return Map.of("applied", applied, "backup", backupRoot.toString());
    }

    @Transactional
    public void deleteForConversation(String conversationId) {
        for (ProjectWorkspaceEntity project : projects.findByConversationIdOrderByUpdatedAtDesc(conversationId)) {
            files.deleteByProjectId(project.getId()); projects.deleteById(project.getId());
        }
    }

    @Transactional
    public void delete(String id) { require(id); files.deleteByProjectId(id); projects.deleteById(id); }

    public void requireConversation(String projectId, String conversationId) {
        ProjectWorkspaceEntity p = require(projectId);
        if (!Objects.equals(p.getConversationId(), conversationId)) throw new SecurityException("Project workspace belongs to another conversation");
    }

    private ProjectDto indexLocal(ProjectWorkspaceEntity project) {
        Path root = validateLocalRoot(project.getLocalPath());
        files.deleteByProjectId(project.getId());
        final int[] count = {0};
        final long[] chars = {0};
        try {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(root)) {
                        String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                    }
                    if (count[0] >= MAX_INDEX_FILES || chars[0] >= MAX_INDEX_CHARS) return FileVisitResult.TERMINATE;
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path path, BasicFileAttributes attrs) {
                    if (count[0] >= MAX_INDEX_FILES || chars[0] >= MAX_INDEX_CHARS) return FileVisitResult.TERMINATE;
                    if (Files.isSymbolicLink(path)) return FileVisitResult.CONTINUE;
                    String relative = root.relativize(path).toString().replace('\\','/');
                    if (!eligibleTextPath(relative) || attrs.size() > MAX_INDEX_BYTES) return FileVisitResult.CONTINUE;
                    try {
                        String content = Files.readString(path, StandardCharsets.UTF_8);
                        if (content.indexOf('\0') >= 0) return FileVisitResult.CONTINUE;
                        int room = (int)Math.min(Integer.MAX_VALUE, MAX_INDEX_CHARS - chars[0]);
                        if (content.length() > room) content = content.substring(0, room);
                        upsert(project.getId(), relative, mime(relative), attrs.size(), redact(content));
                        chars[0] += content.length();
                        count[0]++;
                    } catch (Exception ignored) { }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            throw new IllegalStateException("Unable to index local project: " + e.getMessage(), e);
        }
        project.touch(); projects.save(project);
        return dto(project);
    }

    private void upsert(String projectId, String rawPath, String mimeType, Long sizeBytes, String rawContent) {
        String path = normalizeRelativePath(rawPath);
        String content = rawContent == null ? "" : rawContent;
        if (content.length() > MAX_FILE_CHARS) content = content.substring(0, MAX_FILE_CHARS) + "\n/* [File truncated while indexing] */";
        long size = sizeBytes == null ? content.length() : Math.max(0, sizeBytes);
        String mime = mimeType == null ? "text/plain" : mimeType;
        Optional<ProjectFileEntity> existing = files.findByProjectIdAndRelativePath(projectId, path);
        if (existing.isPresent()) { existing.get().update(mime, size, content); files.save(existing.get()); }
        else files.save(new ProjectFileEntity(UUID.randomUUID().toString(), projectId, path, mime, size, content));
    }

    private ProjectDto dto(ProjectWorkspaceEntity entity) {
        List<ProjectFileEntity> list = files.findByProjectId(entity.getId());
        long totalBytes = list.stream().mapToLong(ProjectFileEntity::getSizeBytes).sum();
        long chars = list.stream().mapToLong(f -> f.getTextContent() == null ? 0 : f.getTextContent().length()).sum();
        return new ProjectDto(entity.getId(), entity.getConversationId(), entity.getName(), list.size(), totalBytes, chars,
                entity.getLocalPath(), entity.hasLocalPath(), entity.getCreatedAt(), entity.getUpdatedAt());
    }

    public boolean eligibleTextPath(String relative) {
        String normalized = relative.replace('\\','/');
        for (String part : normalized.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) return false;
        String name = Path.of(normalized).getFileName().toString().toLowerCase(Locale.ROOT);
        if (SECRET_NAMES.contains(name) || name.startsWith(".env.") || name.matches(".*\\.(pem|p12|pfx|jks|keystore|key|crt|cer)$")) return false;
        if (Set.of("pom.xml","package.json","package-lock.json","yarn.lock","pnpm-lock.yaml","gradlew","gradlew.bat","dockerfile","makefile","jenkinsfile",".gitignore",".dockerignore").contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && TEXT_EXT.contains(name.substring(dot + 1));
    }

    private String redact(String text) {
        if (text == null) return "";
        String result = text;
        result = result.replaceAll("(?im)^([\\w.-]*(?:api[_-]?key|token|password|secret)[\\w.-]*\\s*[=:]\\s*)([^\\s#]+)", "$1[REDACTED]");
        result = result.replaceAll("(?i)(Bearer\\s+)[A-Za-z0-9._~+/-]{16,}", "$1[REDACTED]");
        return result;
    }

    private String mime(String path) {
        String low = path.toLowerCase(Locale.ROOT);
        if (low.endsWith(".json")) return "application/json";
        if (low.endsWith(".xml")) return "application/xml";
        if (low.endsWith(".html") || low.endsWith(".htm")) return "text/html";
        if (low.endsWith(".css")) return "text/css";
        if (low.endsWith(".js") || low.endsWith(".jsx")) return "text/javascript";
        if (low.endsWith(".ts") || low.endsWith(".tsx")) return "text/typescript";
        if (low.endsWith(".md")) return "text/markdown";
        return "text/plain";
    }

    private Path validateLocalRoot(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Local project path is required");
        Path root = Path.of(raw.trim()).toAbsolutePath().normalize();
        if (!Files.exists(root) || !Files.isDirectory(root)) throw new IllegalArgumentException("Project path is not a directory: " + root);
        return root;
    }

    private String sha256(String value) {
        if (value == null) return "__MISSING__";
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Unable to calculate patch hash", e);
        }
    }

    private String safeName(String name, String fallback) {
        String safe = name == null || name.isBlank() ? fallback : name.strip();
        return safe.length() > 300 ? safe.substring(0,300) : safe;
    }

    private String normalizeRelativePath(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Project file path is required");
        String p = raw.replace('\\','/').replaceAll("^/+", "");
        while (p.contains("//")) p = p.replace("//", "/");
        if (p.isBlank() || p.equals(".") || p.startsWith("../") || p.contains("/../") || p.endsWith("/..")) throw new SecurityException("Invalid project file path: " + raw);
        if (p.length() > 1200) throw new IllegalArgumentException("Project file path is too long");
        return p;
    }
}
