package com.llmart.llm.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import com.llmart.llm.service.ProjectPatchConflictException;

import java.util.Map;
import java.util.NoSuchElementException;

@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(ProjectPatchConflictException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String, String> conflict(ProjectPatchConflictException e) { return Map.of("message", e.getMessage()); }

    @ExceptionHandler({IllegalArgumentException.class, NoSuchElementException.class, SecurityException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> badRequest(Exception e) { return Map.of("message", e.getMessage()); }
}
