package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import com.llmart.llm.entity.ProjectFileEntity;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class AgentWorkspaceService {
    private static final int MAX_READ_CHARS = 300_000;
    private static final int MAX_WRITE_CHARS = 2_000_000;
    private static final int MAX_TOOL_OUTPUT = 55_000;
    private static final long MAX_LOCAL_COPY_BYTES = 700L * 1024 * 1024;
    private static final int MAX_LOCAL_COPY_FILES = 20_000;
    private static final Pattern TOKEN_PATTERN = Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s]+)");
    private static final Set<String> COMMAND_ALLOWLIST = Set.of(
            "mvn", "mvnw", "./mvnw", "mvnw.cmd", "java", "javac",
            "gradle", "gradlew", "./gradlew", "gradlew.bat",
            "npm", "npm.cmd", "npx", "npx.cmd", "node", "pnpm", "pnpm.cmd", "yarn", "yarn.cmd",
            "python", "python3", "pytest", "git", "go", "cargo", "dotnet", "make", "cmake",
            "php", "composer", "ruby", "bundle", "rake", "dart", "flutter", "swift", "terraform",
            "ant", "sbt", "bazel", "bazelisk", "meson", "ninja", "zig", "mix", "rebar3", "stack", "cabal",
            "bash", "sh", "pwsh", "powershell", "perl", "lua", "rscript"
    );
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", ".ssh", ".aws", ".azure", ".gcloud", ".gnupg", "node_modules", ".venv", "venv", "target", "build", "dist", "out", ".gradle", ".idea", ".next", "coverage", ".advanced-ai-chat-backup"
    );
    private static final Set<String> SENSITIVE_NAMES = Set.of(
            ".env", "credentials", "secrets", "id_rsa", "id_ed25519", "known_hosts"
    );
    private static final Set<String> PROJECT_DESCRIPTOR_NAMES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
            "package.json", "pyproject.toml", "requirements.txt", "setup.py", "pytest.ini", "go.mod",
            "cargo.toml", "composer.json", "gemfile", "rakefile", "pubspec.yaml", "package.swift",
            "makefile", "cmakelists.txt", "main.tf", "build.xml", "build.sbt", "workspace", "workspace.bazel",
            "module.bazel", "meson.build", "build.zig", "mix.exs", "rebar.config", "stack.yaml"
    );

    private final ProjectService projects;
    private final AgentRunRegistry runs;
    private final Path workspaceRoot;

    public AgentWorkspaceService(ProjectService projects, AgentRunRegistry runs,
                                 @Value("${app.agent-workspace-dir:./data/agent-workspaces}") String workspaceDir) {
        this.projects = projects;
        this.runs = runs;
        this.workspaceRoot = Path.of(workspaceDir).toAbsolutePath().normalize();
    }

    public Workspace prepare(String projectId, String runId) throws IOException {
        ProjectWorkspaceEntity project = projects.require(projectId);
        Files.createDirectories(workspaceRoot);
        Path root = workspaceRoot.resolve(projectId).resolve(UUID.randomUUID().toString()).normalize();
        if (!root.startsWith(workspaceRoot)) throw new SecurityException("Invalid agent workspace path");
        Files.createDirectories(root);
        Map<String,String> baseline = new LinkedHashMap<>();
        Path sourceRoot = null;

        if (project.hasLocalPath()) {
            Path source = Path.of(project.getLocalPath()).toAbsolutePath().normalize();
            sourceRoot = source;
            copyLocalTree(source, root);
        } else {
            for (ProjectFileEntity file : projects.fileEntities(projectId)) {
                String relative = normalizeRelative(file.getRelativePath());
                String content = file.getTextContent() == null ? "" : file.getTextContent();
                baseline.put(relative, content);
                Path target = resolve(root, relative);
                Files.createDirectories(target.getParent());
                Files.writeString(target, content, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            }
        }
        makeWrappersExecutable(root);
        return new Workspace(projectId, runId, root, baseline, project.hasLocalPath(), sourceRoot);
    }

    public Workspace prepareScratch(String runId) throws IOException {
        Files.createDirectories(workspaceRoot);
        Path root = workspaceRoot.resolve("scratch").resolve(UUID.randomUUID().toString()).normalize();
        if (!root.startsWith(workspaceRoot)) throw new SecurityException("Invalid scratch workspace path");
        Files.createDirectories(root);
        return new Workspace(null, runId, root, new LinkedHashMap<>(), false, null);
    }

    private void copyLocalTree(Path source, Path destination) throws IOException {
        if (!Files.isDirectory(source)) throw new IllegalArgumentException("Local project directory is unavailable: " + source);
        final long[] bytes = {0}; final int[] count = {0};
        Files.walkFileTree(source, EnumSet.noneOf(FileVisitOption.class), Integer.MAX_VALUE, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                if (!dir.equals(source)) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                }
                Path rel = source.relativize(dir);
                Files.createDirectories(destination.resolve(rel));
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                if (count[0] >= MAX_LOCAL_COPY_FILES || bytes[0] >= MAX_LOCAL_COPY_BYTES) return FileVisitResult.TERMINATE;
                long size = attrs.size();
                if (bytes[0] + size > MAX_LOCAL_COPY_BYTES) return FileVisitResult.CONTINUE;
                Path rel = source.relativize(file);
                String relative = rel.toString().replace('\\','/');
                if (isSensitiveRelative(relative)) return FileVisitResult.CONTINUE;
                Path target = destination.resolve(rel).normalize();
                if (!target.startsWith(destination)) throw new SecurityException("Invalid copied project path");
                Files.createDirectories(target.getParent());
                Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                bytes[0] += size; count[0]++;
                return FileVisitResult.CONTINUE;
            }
        });
    }

    public String inspectProject(Workspace ws) throws IOException {
        List<String> descriptors = findProjectDescriptors(ws, 5, 80);
        Map<String,Integer> extensions = new LinkedHashMap<>();
        int totalFiles = 0;
        try (Stream<Path> stream = Files.walk(ws.root)) {
            for (Path path : stream.filter(Files::isRegularFile).limit(20_000).toList()) {
                totalFiles++;
                String name = path.getFileName().toString();
                int dot = name.lastIndexOf('.');
                String ext = dot > 0 ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "[none]";
                extensions.merge(ext, 1, Integer::sum);
            }
        }
        List<Map.Entry<String,Integer>> top = extensions.entrySet().stream()
                .sorted((a,b) -> Integer.compare(b.getValue(), a.getValue())).limit(12).toList();
        String languages = top.stream().map(e -> e.getKey()+"="+e.getValue()).collect(Collectors.joining(", "));
        return "Workspace type: " + (ws.localMirror ? "local-path mirror" : "browser-indexed mirror") +
                "\nDetected descriptors: " + (descriptors.isEmpty() ? "[none]" : String.join(", ", descriptors)) +
                "\nFiles scanned: " + totalFiles +
                "\nTop file extensions: " + (languages.isBlank() ? "[none]" : languages) +
                "\nBuild capability: " + buildCapability(ws) +
                "\nTest capability: " + testCapability(ws);
    }

    public String listTree(Workspace ws, String prefix, int maxEntries) throws IOException {
        String normalizedPrefix = prefix == null ? "" : prefix.replace('\\','/').replaceAll("^/+", "");
        int cap = Math.max(1, Math.min(3000, maxEntries));
        List<String> rows = new ArrayList<>();
        try (Stream<Path> stream = Files.walk(ws.root)) {
            for (Path path : stream.filter(p -> !p.equals(ws.root)).toList()) {
                String relative = ws.root.relativize(path).toString().replace('\\','/');
                if (!normalizedPrefix.isBlank() && !relative.startsWith(normalizedPrefix)) continue;
                if (containsSkippedSegment(relative)) continue;
                rows.add((Files.isDirectory(path) ? "[D] " : "[F] ") + relative);
                if (rows.size() >= cap) break;
            }
        }
        if (rows.isEmpty()) return "[No matching workspace entries]";
        if (rows.size() >= cap) rows.add("... [tree truncated]");
        return String.join("\n", rows);
    }

    private boolean containsSkippedSegment(String relative) {
        if (isSensitiveRelative(relative)) return true;
        for (String part : relative.replace('\\','/').split("/")) {
            if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private boolean isSensitiveRelative(String relative) {
        String normalized = relative.replace('\\','/');
        String name = Path.of(normalized).getFileName().toString().toLowerCase(Locale.ROOT);
        return SENSITIVE_NAMES.contains(name) || name.startsWith(".env.") ||
                name.matches(".*\\.(pem|p12|pfx|jks|keystore|key|crt|cer)$");
    }

    public String listFiles(Workspace ws, String prefix) throws IOException {
        String normalizedPrefix = prefix == null ? "" : prefix.replace('\\','/').replaceAll("^/+", "");
        List<String> paths = textPaths(ws).stream().filter(p -> normalizedPrefix.isBlank() || p.startsWith(normalizedPrefix)).limit(1000).toList();
        String body = String.join("\n", paths);
        if (paths.size() >= 1000) body += "\n... [file list truncated]";
        return body.isBlank() ? "[No matching project files]" : body;
    }

    public String glob(Workspace ws, String pattern, int maxMatches) throws IOException {
        String value = pattern == null || pattern.isBlank() ? "**/*" : pattern.replace('\\','/');
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + value);
        int cap = Math.max(1, Math.min(500, maxMatches));
        List<String> result = new ArrayList<>();
        for (String path : textPaths(ws)) {
            if (matcher.matches(Path.of(path))) result.add(path);
            if (result.size() >= cap) break;
        }
        return result.isEmpty() ? "[No files match glob: " + value + "]" : String.join("\n", result);
    }

    public String readFile(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file) || !Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        if (!projects.eligibleTextPath(relative) && !ws.touched.contains(relative)) throw new IllegalArgumentException("File is not a supported text/source file: " + relative);
        String text = Files.readString(file, StandardCharsets.UTF_8);
        if (text.length() > MAX_READ_CHARS) text = text.substring(0, MAX_READ_CHARS) + "\n[... file truncated by agent tool ...]";
        return "FILE: " + relative + "\n" + text;
    }

    public String readFiles(Workspace ws, List<String> paths) throws IOException {
        if (paths == null || paths.isEmpty()) throw new IllegalArgumentException("paths are required");
        StringBuilder out = new StringBuilder();
        for (String path : paths.stream().limit(8).toList()) {
            if (!out.isEmpty()) out.append("\n\n");
            out.append(readFile(ws, path));
            if (out.length() > MAX_TOOL_OUTPUT) break;
        }
        return clip(out.toString());
    }

    public String search(Workspace ws, String query, int maxMatches) throws IOException {
        if (query == null || query.isBlank()) throw new IllegalArgumentException("search_project requires query");
        String needle = query.toLowerCase(Locale.ROOT);
        int cap = Math.max(1, Math.min(120, maxMatches));
        StringBuilder out = new StringBuilder(); int matches = 0;
        for (String relative : textPaths(ws)) {
            Path file = resolve(ws.root, relative); List<String> lines;
            try { lines = Files.readAllLines(file, StandardCharsets.UTF_8); } catch (Exception ignored) { continue; }
            for (int i=0;i<lines.size();i++) {
                if (!lines.get(i).toLowerCase(Locale.ROOT).contains(needle)) continue;
                int start=Math.max(0,i-2), end=Math.min(lines.size()-1,i+2);
                out.append("\n--- ").append(relative).append(':').append(i+1).append(" ---\n");
                for (int n=start;n<=end;n++) out.append(n+1).append(" | ").append(lines.get(n)).append('\n');
                matches++;
                if (matches>=cap || out.length()>=MAX_TOOL_OUTPUT) return clip(out.toString());
            }
        }
        return matches==0 ? "[No matches for: " + query + "]" : clip(out.toString());
    }

    public String writeFile(Workspace ws, String rawPath, String content) throws IOException {
        String relative = normalizeRelative(rawPath); String value = content == null ? "" : content;
        if (value.length() > MAX_WRITE_CHARS) throw new IllegalArgumentException("Agent file is too large to write: " + relative);
        captureBaseline(ws, relative);
        Path file = resolve(ws.root, relative); Files.createDirectories(file.getParent());
        Files.writeString(file, value, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative); ws.markChanged(); if (isWrapper(relative)) makeExecutable(file);
        return "Wrote " + relative + " (" + value.length() + " chars)";
    }

    public String makeDirectory(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path dir = resolve(ws.root, relative);
        if (Files.exists(dir) && !Files.isDirectory(dir)) throw new FileAlreadyExistsException(relative);
        Files.createDirectories(dir);
        return "Created directory " + relative;
    }

    public String deleteFile(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        captureBaseline(ws, relative);
        Files.delete(file);
        ws.touched.add(relative);
        ws.markChanged();
        return "Deleted " + relative;
    }

    public String moveFile(Workspace ws, String rawSource, String rawTarget, boolean overwrite) throws IOException {
        String source = normalizeRelative(rawSource);
        String target = normalizeRelative(rawTarget);
        if (source.equals(target)) return "Source and target are the same: " + source;
        Path sourceFile = resolve(ws.root, source);
        Path targetFile = resolve(ws.root, target);
        if (!Files.isRegularFile(sourceFile)) throw new NoSuchFileException(source);
        if (Files.exists(targetFile) && !overwrite) throw new FileAlreadyExistsException(target);
        captureBaseline(ws, source);
        captureBaseline(ws, target);
        Files.createDirectories(targetFile.getParent());
        if (overwrite) Files.move(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
        else Files.move(sourceFile, targetFile);
        ws.touched.add(source);
        ws.touched.add(target);
        ws.markChanged();
        if (isWrapper(target)) makeExecutable(targetFile);
        return "Moved " + source + " -> " + target;
    }

    public String editFile(Workspace ws, String rawPath, String oldText, String newText, boolean replaceAll) throws IOException {
        String relative = normalizeRelative(rawPath); Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        String current = Files.readString(file, StandardCharsets.UTF_8);
        if (oldText == null || oldText.isEmpty()) throw new IllegalArgumentException("oldText is required");
        int first = current.indexOf(oldText);
        if (first < 0) throw new IllegalArgumentException("oldText was not found in " + relative);
        if (!replaceAll && current.indexOf(oldText, first + oldText.length()) >= 0) throw new IllegalArgumentException("oldText occurs more than once; provide more surrounding context or set replaceAll=true");
        captureBaseline(ws, relative);
        String replacement = newText == null ? "" : newText;
        String updated = replaceAll ? current.replace(oldText, replacement) : current.substring(0, first) + replacement + current.substring(first + oldText.length());
        Files.writeString(file, updated, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative); ws.markChanged();
        return "Edited " + relative + " (" + (replaceAll ? "all matching occurrences" : "1 occurrence") + ")";
    }

    private void captureBaseline(Workspace ws, String relative) throws IOException {
        if (ws.baseline.containsKey(relative)) return;
        Path file = resolve(ws.root, relative);
        if (Files.exists(file) && Files.isRegularFile(file)) ws.baseline.put(relative, Files.readString(file, StandardCharsets.UTF_8));
        else ws.baseline.put(relative, null);
    }

    public String changedFiles(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> changes = changes(ws);
        if (changes.isEmpty()) return "[No source files changed in the isolated workspace]";
        return changes.stream().map(f -> f.deleted() ? f.path() + " (deleted)" : f.path() + " (" + (f.content()==null?0:f.content().length()) + " chars)").collect(Collectors.joining("\n"));
    }

    public String gitStatus(Workspace ws) throws IOException {
        if (ws.touched.isEmpty()) return "working tree clean (agent workspace)";
        List<String> rows = new ArrayList<>();
        for (String relative : ws.touched) {
            Path file = resolve(ws.root, relative);
            String old = ws.baseline.get(relative);
            if (!Files.exists(file) && old != null) rows.add("D  " + relative);
            else if (old == null && Files.exists(file)) rows.add("A  " + relative);
            else rows.add("M  " + relative);
        }
        return String.join("\n", rows);
    }

    public String gitDiff(Workspace ws, String requestedPath) throws IOException {
        List<String> targets = requestedPath == null || requestedPath.isBlank() ? new ArrayList<>(ws.touched) : List.of(normalizeRelative(requestedPath));
        if (targets.isEmpty()) return "[No staged changes]";
        StringBuilder out = new StringBuilder();
        for (String relative : targets) {
            if (!ws.touched.contains(relative)) continue;
            Path file = resolve(ws.root, relative); String before = ws.baseline.get(relative);
            String after = Files.exists(file) ? Files.readString(file, StandardCharsets.UTF_8) : "";
            out.append("--- a/").append(relative).append("\n+++ b/").append(relative).append("\n");
            out.append("@@ original @@\n").append(before == null ? "[new file]\n" : before).append("\n@@ updated @@\n").append(after).append("\n");
            if (out.length() > MAX_TOOL_OUTPUT) break;
        }
        return clip(out.toString());
    }

    public List<ProjectPatchRequest.ProjectPatchFile> changes(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> result = new ArrayList<>();
        for (String relative : ws.touched) {
            Path file = resolve(ws.root, relative);
            String before = ws.baseline.get(relative);
            if (!Files.exists(file)) {
                if (before != null) result.add(new ProjectPatchRequest.ProjectPatchFile(relative, null, baselineHash(ws, relative), true));
                continue;
            }
            if (!Files.isRegularFile(file)) continue;
            String current = Files.readString(file, StandardCharsets.UTF_8);
            if (!Objects.equals(before, current)) result.add(new ProjectPatchRequest.ProjectPatchFile(relative, current, baselineHash(ws, relative), false));
        }
        result.sort(Comparator.comparing(ProjectPatchRequest.ProjectPatchFile::path, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    public CommandResult runBuild(Workspace ws, String workingDirectory, boolean allowed) throws Exception {
        requireCommands(allowed);
        Path base = resolveWorkingDirectory(ws, workingDirectory);
        CommandResult result;
        if (Files.exists(base.resolve("pom.xml"))) {
            result=run(ws,List.of("mvn","-q","-DskipTests","package"),Duration.ofMinutes(6),base);
            if (commandMissing(result) && Files.exists(base.resolve(isWindows()?"mvnw.cmd":"mvnw"))) result=run(ws,List.of(isWindows()?"mvnw.cmd":"./mvnw","-q","-DskipTests","package"),Duration.ofMinutes(6),base);
        } else if (Files.exists(base.resolve("build.gradle")) || Files.exists(base.resolve("build.gradle.kts"))) {
            result=run(ws,List.of("gradle","build","-x","test"),Duration.ofMinutes(6),base);
            if (commandMissing(result) && Files.exists(base.resolve(isWindows()?"gradlew.bat":"gradlew"))) result=run(ws,List.of(isWindows()?"gradlew.bat":"./gradlew","build","-x","test"),Duration.ofMinutes(6),base);
        } else if (Files.exists(base.resolve("package.json"))) {
            result=run(ws,List.of(detectJsPackageManager(base),"run","build"),Duration.ofMinutes(6),base);
        } else if (Files.exists(base.resolve("go.mod"))) result=run(ws,List.of("go","build","./..."),Duration.ofMinutes(6),base);
        else if (Files.exists(base.resolve("Cargo.toml"))) result=run(ws,List.of("cargo","build"),Duration.ofMinutes(7),base);
        else if (hasRootSuffix(base,".sln") || hasRootSuffix(base,".csproj")) result=run(ws,List.of("dotnet","build"),Duration.ofMinutes(7),base);
        else if (Files.exists(base.resolve("pyproject.toml")) || Files.exists(base.resolve("setup.py")) || Files.exists(base.resolve("requirements.txt"))) {
            result=run(ws,List.of("python","-m","compileall","."),Duration.ofMinutes(5),base);
            if (commandMissing(result)) result=run(ws,List.of("python3","-m","compileall","."),Duration.ofMinutes(5),base);
        } else if (Files.exists(base.resolve("composer.json"))) result=run(ws,List.of("composer","validate","--no-check-publish"),Duration.ofMinutes(5),base);
        else if (Files.exists(base.resolve("pubspec.yaml"))) {
            result=run(ws,List.of("flutter","analyze"),Duration.ofMinutes(7),base);
            if (commandMissing(result)) result=run(ws,List.of("dart","analyze"),Duration.ofMinutes(5),base);
        } else if (Files.exists(base.resolve("Package.swift"))) result=run(ws,List.of("swift","build"),Duration.ofMinutes(7),base);
        else if (Files.exists(base.resolve("main.tf")) || hasRootSuffix(base,".tf")) result=run(ws,List.of("terraform","validate"),Duration.ofMinutes(5),base);
        else if (Files.exists(base.resolve("CMakeLists.txt"))) {
            CommandResult configure=run(ws,List.of("cmake","-S",".","-B",".agent-cmake-build"),Duration.ofMinutes(5),base);
            result = configure.exitCode()==0 ? combine(configure, run(ws,List.of("cmake","--build",".agent-cmake-build"),Duration.ofMinutes(7),base)) : configure;
        } else if (Files.exists(base.resolve("build.xml"))) result=run(ws,List.of("ant","-q","compile"),Duration.ofMinutes(7),base);
        else if (Files.exists(base.resolve("build.sbt"))) result=run(ws,List.of("sbt","-batch","compile"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("WORKSPACE")) || Files.exists(base.resolve("WORKSPACE.bazel")) || Files.exists(base.resolve("MODULE.bazel"))) {
            result=run(ws,List.of("bazel","build","//..."),Duration.ofMinutes(10),base);
            if (commandMissing(result)) result=run(ws,List.of("bazelisk","build","//..."),Duration.ofMinutes(10),base);
        } else if (Files.exists(base.resolve("meson.build"))) {
            CommandResult configure=run(ws,List.of("meson","setup","--wipe",".agent-meson-build"),Duration.ofMinutes(5),base);
            result=configure.exitCode()==0?combine(configure,run(ws,List.of("meson","compile","-C",".agent-meson-build"),Duration.ofMinutes(7),base)):configure;
        } else if (Files.exists(base.resolve("build.zig"))) result=run(ws,List.of("zig","build"),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("mix.exs"))) result=run(ws,List.of("mix","compile"),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("rebar.config"))) result=run(ws,List.of("rebar3","compile"),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("stack.yaml"))) result=run(ws,List.of("stack","build"),Duration.ofMinutes(10),base);
        else if (hasRootSuffix(base,".cabal")) result=run(ws,List.of("cabal","build","all"),Duration.ofMinutes(10),base);
        else if (Files.exists(base.resolve("Makefile")) || Files.exists(base.resolve("makefile"))) result=run(ws,List.of("make"),Duration.ofMinutes(7),base);
        else result=new CommandResult(-1,"No supported build/validation descriptor found in " + displayCwd(ws, base) + ". Use inspect_project/list_tree and specify cwd for a nested project.",Duration.ZERO);
        ws.recordBuild(result);
        return result;
    }

    public CommandResult runBuild(Workspace ws, boolean allowed) throws Exception { return runBuild(ws, "", allowed); }

    public CommandResult runTests(Workspace ws, String workingDirectory, boolean allowed) throws Exception {
        requireCommands(allowed);
        Path base = resolveWorkingDirectory(ws, workingDirectory);
        CommandResult result;
        if (Files.exists(base.resolve("pom.xml"))) {
            result=run(ws,List.of("mvn","-q","test"),Duration.ofMinutes(8),base);
            if (commandMissing(result) && Files.exists(base.resolve(isWindows()?"mvnw.cmd":"mvnw"))) result=run(ws,List.of(isWindows()?"mvnw.cmd":"./mvnw","-q","test"),Duration.ofMinutes(8),base);
        } else if (Files.exists(base.resolve("build.gradle")) || Files.exists(base.resolve("build.gradle.kts"))) {
            result=run(ws,List.of("gradle","test"),Duration.ofMinutes(8),base);
            if (commandMissing(result) && Files.exists(base.resolve(isWindows()?"gradlew.bat":"gradlew"))) result=run(ws,List.of(isWindows()?"gradlew.bat":"./gradlew","test"),Duration.ofMinutes(8),base);
        } else if (Files.exists(base.resolve("package.json"))) result=run(ws,List.of(detectJsPackageManager(base),"test"),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("go.mod"))) result=run(ws,List.of("go","test","./..."),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("Cargo.toml"))) result=run(ws,List.of("cargo","test"),Duration.ofMinutes(9),base);
        else if (hasRootSuffix(base,".sln") || hasRootSuffix(base,".csproj")) result=run(ws,List.of("dotnet","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("pyproject.toml")) || Files.exists(base.resolve("pytest.ini")) || Files.exists(base.resolve("tests"))) {
            result=run(ws,List.of("pytest","-q"),Duration.ofMinutes(8),base);
            if (commandMissing(result)) result=run(ws,List.of("python","-m","pytest","-q"),Duration.ofMinutes(8),base);
            if (commandMissing(result)) result=run(ws,List.of("python3","-m","pytest","-q"),Duration.ofMinutes(8),base);
        } else if (Files.exists(base.resolve("pubspec.yaml"))) result=run(ws,List.of("flutter","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("Package.swift"))) result=run(ws,List.of("swift","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("Rakefile"))) result=run(ws,List.of("rake","test"),Duration.ofMinutes(8),base);
        else if (Files.exists(base.resolve("build.xml"))) result=run(ws,List.of("ant","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("build.sbt"))) result=run(ws,List.of("sbt","-batch","test"),Duration.ofMinutes(10),base);
        else if (Files.exists(base.resolve("WORKSPACE")) || Files.exists(base.resolve("WORKSPACE.bazel")) || Files.exists(base.resolve("MODULE.bazel"))) {
            result=run(ws,List.of("bazel","test","//..."),Duration.ofMinutes(12),base);
            if (commandMissing(result)) result=run(ws,List.of("bazelisk","test","//..."),Duration.ofMinutes(12),base);
        } else if (Files.exists(base.resolve("meson.build"))) {
            CommandResult configure=run(ws,List.of("meson","setup","--wipe",".agent-meson-build"),Duration.ofMinutes(5),base);
            result=configure.exitCode()==0?combine(configure,run(ws,List.of("meson","test","-C",".agent-meson-build"),Duration.ofMinutes(9),base)):configure;
        } else if (Files.exists(base.resolve("build.zig"))) result=run(ws,List.of("zig","build","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("mix.exs"))) result=run(ws,List.of("mix","test"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("rebar.config"))) result=run(ws,List.of("rebar3","eunit"),Duration.ofMinutes(9),base);
        else if (Files.exists(base.resolve("stack.yaml"))) result=run(ws,List.of("stack","test"),Duration.ofMinutes(11),base);
        else if (hasRootSuffix(base,".cabal")) result=run(ws,List.of("cabal","test","all"),Duration.ofMinutes(11),base);
        else if (Files.exists(base.resolve("Makefile")) || Files.exists(base.resolve("makefile"))) result=run(ws,List.of("make","test"),Duration.ofMinutes(8),base);
        else result=new CommandResult(-1,"No supported test runner detected in " + displayCwd(ws, base) + ". Use inspect_project/list_tree and specify cwd for a nested project.",Duration.ZERO);
        ws.recordTests(result);
        return result;
    }

    public CommandResult runTests(Workspace ws, boolean allowed) throws Exception { return runTests(ws, "", allowed); }

    public CommandResult runCommand(Workspace ws, String command, String workingDirectory, boolean allowed) throws Exception {
        requireCommands(allowed);
        if (command == null || command.isBlank()) throw new IllegalArgumentException("run_command requires command");
        if (command.contains("\n") || command.contains("\r") || command.matches(".*[;&|><`].*")) throw new SecurityException("Shell operators, redirects and command chaining are not allowed");
        List<String> parts=splitCommand(command); if (parts.isEmpty()) throw new IllegalArgumentException("Command is empty");
        String executable=parts.get(0).toLowerCase(Locale.ROOT);
        if (!COMMAND_ALLOWLIST.contains(executable)) throw new SecurityException("Command is not allowlisted: " + parts.get(0));
        if (executable.equals("git")) {
            if (parts.size()<2 || !(parts.get(1).equals("status") || parts.get(1).equals("diff"))) throw new SecurityException("Only git status and git diff are allowed through run_command");
        }
        blockInlineInterpreterCode(executable, parts);
        validateCommandSemantics(executable, parts);
        validateCommandPaths(ws, parts);
        Path cwd = resolveWorkingDirectory(ws, workingDirectory);
        return run(ws, parts, Duration.ofMinutes(6), cwd);
    }

    public CommandResult runCommand(Workspace ws, String command, boolean allowed) throws Exception {
        return runCommand(ws, command, "", allowed);
    }

    public String completionGuard(Workspace ws, boolean commandsAllowed, boolean testsRequested) throws IOException {
        if (ws.changeVersion == 0) return "";
        if (!commandsAllowed) return "";
        if (!"none".equals(buildCapability(ws)) && ws.lastBuildAttemptVersion < ws.changeVersion) {
            return "Source/configuration files changed after the last build/validation attempt. Run run_build before finalizing, or explain why command execution is unavailable.";
        }
        if (testsRequested && !"none".equals(testCapability(ws)) && ws.lastTestAttemptVersion < ws.changeVersion) {
            return "The user requested test-related work and files changed after the last test attempt. Run run_tests before finalizing, or report the unresolved test-runner limitation.";
        }
        return "";
    }

    public String verificationSummary(Workspace ws) {
        if (ws.changeVersion == 0) return "No workspace files were changed.";
        String build = ws.lastBuildAttemptVersion < ws.changeVersion ? "not run after latest change" : (ws.lastBuildExitCode == 0 ? "passed" : "failed (exit " + ws.lastBuildExitCode + ")");
        String tests = ws.lastTestAttemptVersion < ws.changeVersion ? "not run after latest change" : (ws.lastTestExitCode == 0 ? "passed" : "failed (exit " + ws.lastTestExitCode + ")");
        return "Verification: build/validation=" + build + "; tests=" + tests;
    }

    public void cleanup(Workspace ws) {
        if (ws==null) return;
        try (Stream<Path> stream=Files.walk(ws.root)) {
            stream.sorted(Comparator.reverseOrder()).forEach(path->{ try { Files.deleteIfExists(path); } catch(Exception ignored){} });
        } catch(Exception ignored){}
    }

    private CommandResult run(Workspace ws,List<String> command,Duration timeout) throws Exception {
        return run(ws, command, timeout, ws.root);
    }

    private CommandResult run(Workspace ws,List<String> command,Duration timeout,Path workingDirectory) throws Exception {
        runs.throwIfCancelled(ws.runId);
        List<String> effective=new ArrayList<>(command);
        if (!isWindows() && (effective.get(0).equals("./mvnw") || effective.get(0).equals("./gradlew"))) makeExecutable(workingDirectory.resolve(effective.get(0).substring(2)));
        Path log=Files.createTempFile(ws.root,".agent-command-",".log"); ProcessBuilder builder;
        if (isWindows() && (effective.get(0).endsWith(".cmd") || effective.get(0).endsWith(".bat") || Set.of("mvn","gradle","npm","npx","pnpm","yarn").contains(effective.get(0)))) {
            List<String> cmd=new ArrayList<>(); cmd.add("cmd.exe"); cmd.add("/d"); cmd.add("/c"); cmd.addAll(effective); builder=new ProcessBuilder(cmd);
        } else builder=new ProcessBuilder(effective);
        builder.directory(workingDirectory.toFile()); builder.redirectErrorStream(true); builder.redirectOutput(log.toFile());
        sanitizeEnvironment(builder.environment());
        configureDependencyEnvironment(ws, workingDirectory, builder.environment());
        long start=System.nanoTime(); Process process;
        try { process=builder.start(); } catch(IOException e) { Files.deleteIfExists(log); return new CommandResult(127,"Unable to start command: "+String.join(" ",command)+"\n"+e.getMessage(),Duration.ZERO); }
        runs.registerProcess(ws.runId, process);
        boolean completed=false; boolean cancelled=false; long deadline=System.nanoTime()+timeout.toNanos();
        try {
            while (System.nanoTime() < deadline) {
                if (process.waitFor(250, TimeUnit.MILLISECONDS)) { completed=true; break; }
                try { runs.throwIfCancelled(ws.runId); } catch (AgentRunRegistry.AgentCancelledException e) { cancelled=true; break; }
            }
            if(!completed){ process.destroyForcibly(); process.waitFor(5,TimeUnit.SECONDS); }
        } finally { runs.clearProcess(ws.runId, process); }
        if (cancelled) throw new AgentRunRegistry.AgentCancelledException("Agent run was cancelled while command was executing");
        int exit=completed?process.exitValue():124; String output;
        try { output=Files.readString(log,StandardCharsets.UTF_8); } catch(Exception e){ output="[Command output unavailable: "+e.getMessage()+"]"; }
        Files.deleteIfExists(log); Duration elapsed=Duration.ofNanos(System.nanoTime()-start);
        return new CommandResult(exit,clip("$ "+String.join(" ",command)+"\n"+(completed?"":"[Timed out after "+timeout.toSeconds()+"s]\n")+output),elapsed);
    }

    private void sanitizeEnvironment(Map<String,String> env) {
        env.entrySet().removeIf(e -> {
            String key=e.getKey().toUpperCase(Locale.ROOT);
            if (Set.of("PATH","JAVA_HOME","M2_HOME","GRADLE_HOME","NODE_HOME","SYSTEMROOT","WINDIR","COMSPEC","PATHEXT","TEMP","TMP","TMPDIR","HOME","USERPROFILE").contains(key)) return false;
            return key.contains("TOKEN") || key.contains("SECRET") || key.contains("PASSWORD") || key.endsWith("_KEY") || key.startsWith("AWS_") || key.startsWith("AZURE_") || key.startsWith("GITHUB_") || key.startsWith("GOOGLE_");
        });
    }

    private void configureDependencyEnvironment(Workspace ws, Path workingDirectory, Map<String,String> env) {
        if (ws.sourceRoot == null) return;
        Path relative = ws.root.relativize(workingDirectory);
        Path sourceWorkingDirectory = ws.sourceRoot.resolve(relative).normalize();
        if (!sourceWorkingDirectory.startsWith(ws.sourceRoot) || !Files.isDirectory(sourceWorkingDirectory)) sourceWorkingDirectory = ws.sourceRoot;
        String pathKey = env.keySet().stream().filter(k -> k.equalsIgnoreCase("PATH")).findFirst().orElse("PATH");
        String existingPath = env.getOrDefault(pathKey, "");
        List<String> prepend = new ArrayList<>();

        Path nodeModules = sourceWorkingDirectory.resolve("node_modules");
        if (!Files.isDirectory(nodeModules)) nodeModules = ws.sourceRoot.resolve("node_modules");
        if (Files.isDirectory(nodeModules)) {
            Path bin = nodeModules.resolve(".bin");
            if (Files.isDirectory(bin)) prepend.add(bin.toString());
            env.put("NODE_PATH", nodeModules.toString());
        }

        Path venv = Files.isDirectory(sourceWorkingDirectory.resolve(".venv")) ? sourceWorkingDirectory.resolve(".venv") :
                Files.isDirectory(sourceWorkingDirectory.resolve("venv")) ? sourceWorkingDirectory.resolve("venv") :
                Files.isDirectory(ws.sourceRoot.resolve(".venv")) ? ws.sourceRoot.resolve(".venv") :
                Files.isDirectory(ws.sourceRoot.resolve("venv")) ? ws.sourceRoot.resolve("venv") : null;
        if (venv != null) {
            Path bin = venv.resolve(isWindows() ? "Scripts" : "bin");
            if (Files.isDirectory(bin)) prepend.add(bin.toString());
            env.put("VIRTUAL_ENV", venv.toString());
        }

        if (!prepend.isEmpty()) {
            String prefix = String.join(java.io.File.pathSeparator, prepend);
            env.put(pathKey, existingPath.isBlank() ? prefix : prefix + java.io.File.pathSeparator + existingPath);
        }
    }

    private void blockInlineInterpreterCode(String executable, List<String> parts) {
        if (parts.size() < 2) return;
        String second=parts.get(1).toLowerCase(Locale.ROOT);
        if ((executable.equals("python") || executable.equals("python3")) && (second.equals("-c") || second.equals("-"))) throw new SecurityException("Inline Python execution is blocked; run project scripts/files instead");
        if (executable.equals("node") && (second.equals("-e") || second.equals("--eval") || second.equals("-p") || second.equals("--print"))) throw new SecurityException("Inline Node execution is blocked; run project scripts/files instead");
        if (executable.equals("ruby") && second.equals("-e")) throw new SecurityException("Inline Ruby execution is blocked");
        if (executable.equals("php") && second.equals("-r")) throw new SecurityException("Inline PHP execution is blocked");
    }

    private void validateCommandSemantics(String executable, List<String> parts) {
        if (parts.size() < 2) return;
        String sub = parts.get(1).toLowerCase(Locale.ROOT);
        // run_command is intentionally for project-local inspection/execution, not environment mutation or publishing.
        // Standard run_build/run_tests may still resolve dependencies through the project's own build tool.
        if (Set.of("npm","npm.cmd","pnpm","pnpm.cmd","yarn","yarn.cmd").contains(executable) &&
                Set.of("install","i","add","remove","rm","uninstall","update","upgrade","publish","link","unlink").contains(sub))
            throw new SecurityException("Package installation/publishing is blocked in run_command; use an existing project environment or install dependencies outside the agent workspace");
        if (executable.equals("npx") || executable.equals("npx.cmd")) {
            if (!parts.contains("--no-install")) throw new SecurityException("npx is allowed only with --no-install to prevent implicit downloads");
        }
        if (executable.equals("composer") && Set.of("install","update","require","remove","global","create-project").contains(sub))
            throw new SecurityException("Composer dependency/environment mutation is blocked in run_command");
        if (executable.equals("bundle") && Set.of("install","update","add","remove","config").contains(sub))
            throw new SecurityException("Bundler dependency/environment mutation is blocked in run_command");
        if (executable.equals("cargo") && Set.of("install","uninstall","publish","login","owner","yank").contains(sub))
            throw new SecurityException("Cargo installation/publishing is blocked in run_command");
        if (executable.equals("terraform") && Set.of("apply","destroy","import","taint","untaint","state","force-unlock").contains(sub))
            throw new SecurityException("Destructive or remote Terraform mutation is blocked in run_command");
        if (executable.equals("dotnet") && sub.equals("nuget") && parts.stream().map(v->v.toLowerCase(Locale.ROOT)).anyMatch(v->v.equals("push")||v.equals("delete")))
            throw new SecurityException("NuGet publishing/deletion is blocked in run_command");
        if (Set.of("bash","sh").contains(executable)) {
            if (Set.of("-c","--command","-s").contains(sub)) throw new SecurityException("Inline shell execution is blocked; run a project-local script file instead");
            String script = parts.stream().skip(1).filter(v -> !v.startsWith("-")).findFirst().orElse("");
            if (script.isBlank() || !(script.endsWith(".sh") || script.endsWith(".bash"))) throw new SecurityException("Shell commands must execute a relative .sh/.bash project script");
        }
        if (Set.of("pwsh","powershell").contains(executable)) {
            if (parts.stream().map(v->v.toLowerCase(Locale.ROOT)).anyMatch(v->Set.of("-command","-c","-encodedcommand","-enc").contains(v)))
                throw new SecurityException("Inline PowerShell execution is blocked; use -File with a project-local .ps1 script");
            int fileIndex=-1; for(int i=1;i<parts.size();i++) if(parts.get(i).equalsIgnoreCase("-File")){fileIndex=i;break;}
            if (fileIndex<0 || fileIndex+1>=parts.size() || !parts.get(fileIndex+1).toLowerCase(Locale.ROOT).endsWith(".ps1"))
                throw new SecurityException("PowerShell commands must use -File with a relative project .ps1 script");
        }
    }

    private Path resolveWorkingDirectory(Workspace ws, String raw) {
        if (raw == null || raw.isBlank() || raw.equals(".")) return ws.root;
        String relative = normalizeRelative(raw);
        Path dir = resolve(ws.root, relative);
        if (!Files.isDirectory(dir)) throw new IllegalArgumentException("Working directory does not exist in the workspace: " + relative);
        return dir;
    }

    private String displayCwd(Workspace ws, Path base) {
        String rel = ws.root.relativize(base).toString().replace('\\','/');
        return rel.isBlank() ? "." : rel;
    }

    private void validateCommandPaths(Workspace ws, List<String> parts) {
        for (int i=1;i<parts.size();i++) {
            String arg=parts.get(i);
            if (arg.startsWith("-") || arg.equals("." ) || arg.equals("./")) continue;
            if (arg.contains("..")) throw new SecurityException("Parent-path arguments are not allowed in agent commands: " + arg);
            try {
                Path candidate=Path.of(arg);
                if (candidate.isAbsolute()) throw new SecurityException("Absolute-path arguments are not allowed in agent commands: " + arg);
            } catch (InvalidPathException ignored) { }
        }
    }

    private String detectJsPackageManager(Path base) {
        if (Files.exists(base.resolve("pnpm-lock.yaml"))) return isWindows()?"pnpm.cmd":"pnpm";
        if (Files.exists(base.resolve("yarn.lock"))) return isWindows()?"yarn.cmd":"yarn";
        return isWindows()?"npm.cmd":"npm";
    }

    private String buildCapability(Workspace ws) throws IOException {
        if (Files.exists(ws.root.resolve("pom.xml"))) return "maven";
        if (Files.exists(ws.root.resolve("build.gradle")) || Files.exists(ws.root.resolve("build.gradle.kts"))) return "gradle";
        if (Files.exists(ws.root.resolve("package.json"))) return "javascript-package-manager";
        if (Files.exists(ws.root.resolve("go.mod"))) return "go";
        if (Files.exists(ws.root.resolve("Cargo.toml"))) return "cargo";
        if (hasRootSuffix(ws.root,".sln") || hasRootSuffix(ws.root,".csproj")) return "dotnet";
        if (Files.exists(ws.root.resolve("pyproject.toml")) || Files.exists(ws.root.resolve("setup.py")) || Files.exists(ws.root.resolve("requirements.txt"))) return "python-compile";
        if (Files.exists(ws.root.resolve("composer.json"))) return "composer-validate";
        if (Files.exists(ws.root.resolve("pubspec.yaml"))) return "flutter/dart-analyze";
        if (Files.exists(ws.root.resolve("Package.swift"))) return "swift";
        if (Files.exists(ws.root.resolve("main.tf")) || hasRootSuffix(ws.root,".tf")) return "terraform-validate";
        if (Files.exists(ws.root.resolve("CMakeLists.txt"))) return "cmake";
        if (Files.exists(ws.root.resolve("build.xml"))) return "ant";
        if (Files.exists(ws.root.resolve("build.sbt"))) return "sbt";
        if (Files.exists(ws.root.resolve("WORKSPACE")) || Files.exists(ws.root.resolve("WORKSPACE.bazel")) || Files.exists(ws.root.resolve("MODULE.bazel"))) return "bazel";
        if (Files.exists(ws.root.resolve("meson.build"))) return "meson";
        if (Files.exists(ws.root.resolve("build.zig"))) return "zig";
        if (Files.exists(ws.root.resolve("mix.exs"))) return "elixir-mix";
        if (Files.exists(ws.root.resolve("rebar.config"))) return "erlang-rebar3";
        if (Files.exists(ws.root.resolve("stack.yaml")) || hasRootSuffix(ws.root,".cabal")) return "haskell";
        if (Files.exists(ws.root.resolve("Makefile")) || Files.exists(ws.root.resolve("makefile"))) return "make";
        if (!findProjectDescriptors(ws, 5, 1).isEmpty()) return "nested/multi-project (specify cwd)";
        return "none";
    }

    private String testCapability(Workspace ws) throws IOException {
        if (Files.exists(ws.root.resolve("pom.xml"))) return "maven";
        if (Files.exists(ws.root.resolve("build.gradle")) || Files.exists(ws.root.resolve("build.gradle.kts"))) return "gradle";
        if (Files.exists(ws.root.resolve("package.json"))) return "javascript-package-manager";
        if (Files.exists(ws.root.resolve("go.mod"))) return "go";
        if (Files.exists(ws.root.resolve("Cargo.toml"))) return "cargo";
        if (hasRootSuffix(ws.root,".sln") || hasRootSuffix(ws.root,".csproj")) return "dotnet";
        if (Files.exists(ws.root.resolve("pyproject.toml")) || Files.exists(ws.root.resolve("pytest.ini")) || Files.exists(ws.root.resolve("tests"))) return "pytest";
        if (Files.exists(ws.root.resolve("pubspec.yaml"))) return "flutter";
        if (Files.exists(ws.root.resolve("Package.swift"))) return "swift";
        if (Files.exists(ws.root.resolve("Rakefile"))) return "rake";
        if (Files.exists(ws.root.resolve("build.xml"))) return "ant";
        if (Files.exists(ws.root.resolve("build.sbt"))) return "sbt";
        if (Files.exists(ws.root.resolve("WORKSPACE")) || Files.exists(ws.root.resolve("WORKSPACE.bazel")) || Files.exists(ws.root.resolve("MODULE.bazel"))) return "bazel";
        if (Files.exists(ws.root.resolve("meson.build"))) return "meson";
        if (Files.exists(ws.root.resolve("build.zig"))) return "zig";
        if (Files.exists(ws.root.resolve("mix.exs"))) return "elixir-mix";
        if (Files.exists(ws.root.resolve("rebar.config"))) return "erlang-rebar3";
        if (Files.exists(ws.root.resolve("stack.yaml")) || hasRootSuffix(ws.root,".cabal")) return "haskell";
        if (Files.exists(ws.root.resolve("Makefile")) || Files.exists(ws.root.resolve("makefile"))) return "make";
        if (!findProjectDescriptors(ws, 5, 1).isEmpty()) return "nested/multi-project (specify cwd)";
        return "none";
    }

    private List<String> findProjectDescriptors(Workspace ws, int maxDepth, int maxMatches) throws IOException {
        List<String> result = new ArrayList<>();
        try (Stream<Path> stream = Files.walk(ws.root, Math.max(1, maxDepth))) {
            for (Path path : stream.filter(Files::isRegularFile).toList()) {
                String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                boolean descriptor = PROJECT_DESCRIPTOR_NAMES.contains(name) || name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".cabal");
                if (!descriptor && name.endsWith(".tf")) descriptor = true;
                if (!descriptor) continue;
                String relative = ws.root.relativize(path).toString().replace('\\','/');
                if (containsSkippedSegment(relative)) continue;
                result.add(relative);
                if (result.size() >= Math.max(1, maxMatches)) break;
            }
        }
        result.sort(String.CASE_INSENSITIVE_ORDER);
        return result;
    }

    private CommandResult combine(CommandResult first, CommandResult second) {
        return new CommandResult(second.exitCode(), first.output()+"\n\n"+second.output(), first.elapsed().plus(second.elapsed()));
    }

    public String baselineHash(Workspace ws, String relative) {
        String value=ws.baseline.get(relative);
        return sha256(value);
    }

    private String sha256(String value) {
        if (value == null) return "__MISSING__";
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            byte[] bytes=digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch(Exception e) { throw new IllegalStateException("Unable to calculate SHA-256", e); }
    }

    private boolean hasRootSuffix(Path root, String suffix) throws IOException {
        try (Stream<Path> stream = Files.list(root)) {
            String low = suffix.toLowerCase(Locale.ROOT);
            return stream.filter(Files::isRegularFile).anyMatch(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(low));
        }
    }

    private boolean commandMissing(CommandResult result) {
        if(result==null) return true; if(result.exitCode()==127 || result.exitCode()==9009) return true;
        String text=result.output()==null?"":result.output().toLowerCase(Locale.ROOT);
        return text.contains("not recognized as an internal or external command") || text.contains("command not found") || text.contains("unable to start command");
    }

    private void requireCommands(boolean allowed){ if(!allowed) throw new SecurityException("Agent command execution is disabled by permissions"); }
    private List<String> splitCommand(String command){ List<String> result=new ArrayList<>(); Matcher matcher=TOKEN_PATTERN.matcher(command.trim()); while(matcher.find()){ String token=matcher.group(1)!=null?matcher.group(1):matcher.group(2)!=null?matcher.group(2):matcher.group(3); if(token!=null&&!token.isBlank()) result.add(token);} return result; }

    private List<String> textPaths(Workspace ws) throws IOException {
        try(Stream<Path> stream=Files.walk(ws.root)){
            return stream.filter(Files::isRegularFile).map(ws.root::relativize).map(Path::toString).map(p->p.replace('\\','/'))
                    .filter(p->projects.eligibleTextPath(p) || ws.touched.contains(p)).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        }
    }

    private String normalizeRelative(String raw){ if(raw==null||raw.isBlank()) throw new IllegalArgumentException("Project path is required"); String p=raw.replace('\\','/').replaceAll("^/+",""); while(p.contains("//"))p=p.replace("//","/"); if(p.isBlank()||p.equals(".")||p.startsWith("../")||p.contains("/../")||p.endsWith("/..")||p.contains("\u0000")) throw new SecurityException("Invalid project path: "+raw); if(p.length()>1200) throw new IllegalArgumentException("Project path is too long"); return p; }
    private Path resolve(Path root,String relative){
        Path result=root.resolve(relative).normalize();
        if(!result.startsWith(root)) throw new SecurityException("Path escapes the isolated project workspace: "+relative);
        try {
            Path rootReal=root.toRealPath();
            if(Files.isSymbolicLink(result)) throw new SecurityException("Symbolic-link file targets are not allowed in agent file tools: "+relative);
            Path probe=Files.exists(result,LinkOption.NOFOLLOW_LINKS)?result:result.getParent();
            while(probe!=null&&!Files.exists(probe,LinkOption.NOFOLLOW_LINKS)) probe=probe.getParent();
            if(probe!=null){
                if(Files.isSymbolicLink(probe) && probe.equals(result)) throw new SecurityException("Symbolic-link file targets are not allowed in agent file tools: "+relative);
                Path real=probe.toRealPath();
                if(!real.startsWith(rootReal)) throw new SecurityException("Resolved path escapes the isolated project workspace: "+relative);
            }
        } catch(SecurityException e){ throw e; }
        catch(IOException e){ throw new SecurityException("Unable to validate workspace path: "+relative, e); }
        return result;
    }
    private boolean isWindows(){ return System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win"); }
    private boolean isWrapper(String path){ return path.endsWith("mvnw")||path.endsWith("gradlew"); }
    private void makeWrappersExecutable(Path root){ for(String name:List.of("mvnw","gradlew")){ Path path=root.resolve(name); if(Files.exists(path))makeExecutable(path);} }
    private void makeExecutable(Path path){ try{ Set<PosixFilePermission> perms=Files.getPosixFilePermissions(path); perms.add(PosixFilePermission.OWNER_EXECUTE); Files.setPosixFilePermissions(path,perms);}catch(Exception ignored){try{path.toFile().setExecutable(true,true);}catch(Exception ignoredAgain){}} }
    private String clip(String text){ if(text==null)return""; if(text.length()<=MAX_TOOL_OUTPUT)return text; int head=MAX_TOOL_OUTPUT*2/3, tail=MAX_TOOL_OUTPUT-head-80; return text.substring(0,head)+"\n... [tool output clipped] ...\n"+text.substring(Math.max(head,text.length()-tail)); }

    public static final class Workspace {
        private final String projectId; private final String runId; private final Path root; private final Map<String,String> baseline; private final LinkedHashSet<String> touched=new LinkedHashSet<>(); private final boolean localMirror; private final Path sourceRoot;
        private long changeVersion=0; private long lastBuildAttemptVersion=-1; private long lastTestAttemptVersion=-1; private int lastBuildExitCode=Integer.MIN_VALUE; private int lastTestExitCode=Integer.MIN_VALUE;
        private Workspace(String projectId,String runId,Path root,Map<String,String> baseline,boolean localMirror,Path sourceRoot){this.projectId=projectId;this.runId=runId;this.root=root;this.baseline=baseline;this.localMirror=localMirror;this.sourceRoot=sourceRoot;}
        private void markChanged(){ changeVersion++; }
        private void recordBuild(CommandResult result){ lastBuildAttemptVersion=changeVersion; lastBuildExitCode=result==null?Integer.MIN_VALUE:result.exitCode(); }
        private void recordTests(CommandResult result){ lastTestAttemptVersion=changeVersion; lastTestExitCode=result==null?Integer.MIN_VALUE:result.exitCode(); }
        public String projectId(){return projectId;} public String runId(){return runId;} public Path root(){return root;} public boolean localMirror(){return localMirror;}
    }
    public record CommandResult(int exitCode,String output,Duration elapsed){ public String asToolText(){return "exitCode="+exitCode+"; elapsedMs="+elapsed.toMillis()+"\n"+output;} }
}
