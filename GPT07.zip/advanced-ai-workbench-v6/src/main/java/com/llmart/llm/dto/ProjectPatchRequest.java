package com.llmart.llm.dto;

import java.util.List;

public record ProjectPatchRequest(String projectName, List<ProjectPatchFile> files) {
    /**
     * A staged project change. deleted=true represents a file deletion; content is ignored in that case.
     * The compatibility constructors keep older browser/client payloads working.
     */
    public record ProjectPatchFile(String path, String content, String baselineHash, boolean deleted) {
        public ProjectPatchFile(String path, String content) { this(path, content, null, false); }
        public ProjectPatchFile(String path, String content, String baselineHash) { this(path, content, baselineHash, false); }
    }
}
