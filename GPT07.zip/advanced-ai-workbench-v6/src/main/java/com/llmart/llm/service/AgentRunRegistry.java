package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class AgentRunRegistry {
    private final Map<String, RunState> runs = new ConcurrentHashMap<>();

    public String create() {
        cleanupOldRuns();
        String id = UUID.randomUUID().toString();
        runs.put(id, new RunState(id));
        return id;
    }

    public void start(String runId) {
        require(runId).status.set("running");
    }

    public void complete(String runId) {
        RunState state = runs.get(runId);
        if (state != null && !state.cancelled.get()) state.status.set("completed");
    }

    public void fail(String runId) {
        RunState state = runs.get(runId);
        if (state != null && !state.cancelled.get()) state.status.set("failed");
    }

    public boolean cancel(String runId) {
        RunState state = runs.get(runId);
        if (state == null || isTerminal(state.status.get())) return false;
        state.cancelled.set(true);
        state.status.set("cancelled");
        Process process = state.activeProcess.getAndSet(null);
        if (process != null) destroyTree(process);
        return true;
    }

    public boolean isCancelled(String runId) {
        RunState state = runs.get(runId);
        return state != null && state.cancelled.get();
    }

    public void throwIfCancelled(String runId) {
        RunState state = require(runId);
        if (state.cancelled.get()) throw new AgentCancelledException("Agent run was cancelled");
        if (Thread.currentThread().isInterrupted()) throw new AgentCancelledException("Agent run was interrupted");
    }

    public void registerProcess(String runId, Process process) {
        RunState state = require(runId);
        throwIfCancelled(runId);
        state.activeProcess.set(process);
    }

    public void clearProcess(String runId, Process process) {
        RunState state = runs.get(runId);
        if (state != null) state.activeProcess.compareAndSet(process, null);
    }

    public void setPlan(String runId, List<String> items) {
        RunState state = require(runId);
        state.plan = items == null ? List.of() : List.copyOf(items);
    }

    public Map<String, Object> snapshot(String runId) {
        RunState state = require(runId);
        return Map.of(
                "runId", state.id,
                "status", state.status.get(),
                "cancelled", state.cancelled.get(),
                "startedAt", state.startedAt.toString(),
                "plan", new ArrayList<>(state.plan)
        );
    }

    public void remove(String runId) {
        runs.remove(runId);
    }

    private boolean isTerminal(String status) {
        return "completed".equals(status) || "failed".equals(status) || "cancelled".equals(status);
    }

    private void cleanupOldRuns() {
        if (runs.size() < 500) return;
        Instant cutoff = Instant.now().minus(Duration.ofHours(24));
        for (Map.Entry<String, RunState> entry : runs.entrySet()) {
            RunState state = entry.getValue();
            if (isTerminal(state.status.get()) && state.startedAt.isBefore(cutoff)) runs.remove(entry.getKey(), state);
        }
        if (runs.size() <= 1000) return;
        // Hard cap protection for a server that has been kept alive for a very long time.
        runs.entrySet().stream()
                .filter(entry -> isTerminal(entry.getValue().status.get()))
                .sorted(Map.Entry.comparingByValue((a,b) -> a.startedAt.compareTo(b.startedAt)))
                .limit(Math.max(0, runs.size() - 800L))
                .map(Map.Entry::getKey)
                .toList()
                .forEach(runs::remove);
    }

    private RunState require(String runId) {
        RunState state = runs.get(runId);
        if (state == null) throw new IllegalArgumentException("Agent run not found: " + runId);
        return state;
    }

    private void destroyTree(Process process) {
        try {
            process.descendants().forEach(handle -> {
                try { handle.destroyForcibly(); } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
        try { process.destroyForcibly(); } catch (Exception ignored) { }
    }

    private static final class RunState {
        private final String id;
        private final Instant startedAt = Instant.now();
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final AtomicReference<String> status = new AtomicReference<>("created");
        private final AtomicReference<Process> activeProcess = new AtomicReference<>();
        private volatile List<String> plan = List.of();

        private RunState(String id) { this.id = id; }
    }

    public static final class AgentCancelledException extends RuntimeException {
        public AgentCancelledException(String message) { super(message); }
    }
}
