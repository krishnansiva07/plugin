package com.llmart.llm.dto;

public record ChatSettings(
        String baseUrl,
        String model,
        String visionModel,
        Double temperature,
        Integer maxTokens,
        Integer contextChars,
        String systemPrompt,
        Boolean useFileContext,
        Integer agentMaxSteps,
        Boolean agentAllowCommands,
        String agentEditPermission,
        String agentShellPermission,
        String agentGitPermission,
        Boolean agentAutoApprove
) {
    public double safeTemperature() { return temperature == null ? 0.7 : Math.max(0.0, Math.min(2.0, temperature)); }
    public int safeMaxTokens() { return maxTokens == null ? 4096 : Math.max(64, Math.min(32768, maxTokens)); }
    public int safeContextChars() { return contextChars == null ? 64000 : Math.max(4000, Math.min(500000, contextChars)); }
    public boolean fileContextEnabled() { return useFileContext == null || useFileContext; }
    public boolean hasDedicatedVisionModel() { return visionModel != null && !visionModel.isBlank(); }
    public int safeAgentMaxSteps() { return agentMaxSteps == null ? 30 : Math.max(3, Math.min(60, agentMaxSteps)); }
    public boolean agentCommandsAllowed() { return agentAllowCommands == null || Boolean.TRUE.equals(agentAllowCommands); }
    public String editPermission() { return normalizePermission(agentEditPermission, "ask"); }
    public String shellPermission() {
        if (!agentCommandsAllowed()) return "deny";
        return normalizePermission(agentShellPermission, "ask");
    }
    public String gitPermission() { return normalizePermission(agentGitPermission, "allow"); }
    public boolean autoApproveAgent() { return Boolean.TRUE.equals(agentAutoApprove); }

    private String normalizePermission(String value, String fallback) {
        if (value == null) return fallback;
        String p = value.trim().toLowerCase();
        return (p.equals("allow") || p.equals("ask") || p.equals("deny")) ? p : fallback;
    }
}
