package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.BooleanSupplier;
import java.util.concurrent.*;
import java.util.stream.Stream;

@Service
public class OpenAiCompatibleClient {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public OpenAiCompatibleClient(HttpClient httpClient, ObjectMapper objectMapper) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
    }

    public String stream(String apiKey, ChatSettings settings, List<Map<String, Object>> messages,
                         Consumer<String> onToken) throws Exception {
        validate(settings);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", settings.model());
        body.put("messages", messages);
        body.put("temperature", settings.safeTemperature());
        body.put("max_tokens", settings.safeMaxTokens());
        body.put("stream", true);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(chatCompletionsUrl(settings.baseUrl())))
                .timeout(Duration.ofMinutes(5))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "text/event-stream, application/json")
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        HttpResponse<Stream<String>> response = httpClient.send(request, HttpResponse.BodyHandlers.ofLines());
        StringBuilder complete = new StringBuilder();
        List<String> errorLines = new ArrayList<>();

        try (Stream<String> lines = response.body()) {
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                lines.limit(30).forEach(errorLines::add);
                throw new IllegalStateException("LLM HTTP " + response.statusCode() + ": " + String.join(" ", errorLines));
            }

            Iterator<String> iterator = lines.iterator();
            while (iterator.hasNext()) {
                String line = iterator.next();
                if (line == null || line.isBlank() || line.startsWith(":")) continue;
                String data = line.startsWith("data:") ? line.substring(5).trim() : line.trim();
                if ("[DONE]".equals(data)) break;

                JsonNode json;
                try { json = objectMapper.readTree(data); }
                catch (Exception ignored) { continue; }

                JsonNode choices = json.path("choices");
                if (!choices.isArray() || choices.isEmpty()) continue;
                JsonNode choice = choices.get(0);
                JsonNode content = choice.path("delta").path("content");
                if (content.isMissingNode() || content.isNull()) content = choice.path("message").path("content");

                if (content.isTextual()) append(content.asText(), complete, onToken);
                else if (content.isArray()) {
                    for (JsonNode item : content) {
                        String token = item.path("text").asText("");
                        if (!token.isEmpty()) append(token, complete, onToken);
                    }
                }
            }
        }
        return complete.toString();
    }


    public String complete(String apiKey, String baseUrl, String model, int maxTokens,
                           List<Map<String, Object>> messages) throws Exception {
        return complete(apiKey, baseUrl, model, maxTokens, messages, () -> false);
    }

    public String complete(String apiKey, String baseUrl, String model, int maxTokens,
                           List<Map<String, Object>> messages, BooleanSupplier cancelled) throws Exception {
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Model name is required");
        if (cancelled != null && cancelled.getAsBoolean()) throw new AgentRunRegistry.AgentCancelledException("Agent run was cancelled before the LLM request");

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("messages", messages);
        body.put("temperature", 0.1);
        body.put("max_tokens", Math.max(256, Math.min(32768, maxTokens)));
        body.put("stream", false);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(chatCompletionsUrl(baseUrl)))
                .timeout(Duration.ofMinutes(5))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        CompletableFuture<HttpResponse<String>> future = httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());
        HttpResponse<String> response;
        try {
            while (true) {
                if (cancelled != null && cancelled.getAsBoolean()) {
                    future.cancel(true);
                    throw new AgentRunRegistry.AgentCancelledException("Agent run was cancelled during the LLM request");
                }
                try {
                    response = future.get(150, TimeUnit.MILLISECONDS);
                    break;
                } catch (TimeoutException ignored) {
                    // Poll cancellation without blocking for the full provider timeout.
                }
            }
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof Exception exception) throw exception;
            throw new IllegalStateException("LLM request failed", cause);
        } catch (InterruptedException e) {
            future.cancel(true);
            Thread.currentThread().interrupt();
            throw new AgentRunRegistry.AgentCancelledException("Agent LLM request was interrupted");
        }

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            String error = response.body() == null ? "" : response.body();
            if (error.length() > 1500) error = error.substring(0, 1500);
            throw new IllegalStateException("LLM HTTP " + response.statusCode() + ": " + error);
        }
        JsonNode json = objectMapper.readTree(response.body());
        JsonNode choices = json.path("choices");
        if (!choices.isArray() || choices.isEmpty()) throw new IllegalStateException("LLM returned no choices");
        JsonNode content = choices.get(0).path("message").path("content");
        if (content.isTextual()) return content.asText();
        if (content.isArray()) {
            StringBuilder out = new StringBuilder();
            for (JsonNode item : content) {
                String text = item.path("text").asText("");
                if (!text.isBlank()) {
                    if (!out.isEmpty()) out.append('\n');
                    out.append(text);
                }
            }
            return out.toString();
        }
        return content.asText("");
    }

    private void append(String token, StringBuilder complete, Consumer<String> onToken) {
        complete.append(token);
        onToken.accept(token);
    }

    private void validate(ChatSettings s) {
        if (s.baseUrl() == null || s.baseUrl().isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (s.model() == null || s.model().isBlank()) throw new IllegalArgumentException("Model name is required");
    }

    private String chatCompletionsUrl(String baseUrl) {
        String base = baseUrl.trim().replaceAll("/+$", "");
        if (base.endsWith("/chat/completions")) return base;
        return base + "/chat/completions";
    }
}
