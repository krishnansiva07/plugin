package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class ChatService {
    private final ConversationService conversations;
    private final FileService files;
    private final ContextService contextService;
    private final ProjectService projects;
    private final OpenAiCompatibleClient llm;
    private final AgentService agentService;

    public ChatService(ConversationService conversations, FileService files,
                       ContextService contextService, ProjectService projects,
                       OpenAiCompatibleClient llm, AgentService agentService) {
        this.conversations = conversations;
        this.files = files;
        this.contextService = contextService;
        this.projects = projects;
        this.llm = llm;
        this.agentService = agentService;
    }

    public SseEmitter stream(String apiKey, ChatRequest request) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required");
        SseEmitter emitter = new SseEmitter(1_200_000L);
        final String agentRunId = request.chatMode() == ChatMode.AGENT ? agentService.createRun() : null;
        if (agentRunId != null) {
            emitter.onTimeout(() -> agentService.cancel(agentRunId));
        }

        CompletableFuture.runAsync(() -> {
            try {
                ConversationEntity conversation = conversations.getOrCreate(request.conversationId());
                MessageEntity userMessage;

                if (request.isRegenerate()) {
                    userMessage = conversations.lastUserMessage(conversation.getId());
                    conversations.removeMessagesAfter(conversation.getId(), userMessage.getId());
                } else {
                    List<String> attachmentIds = request.attachmentIds() == null ? List.of() : request.attachmentIds();
                    files.requireForConversation(conversation.getId(), attachmentIds);
                    String userText = request.message();
                    if ((userText == null || userText.isBlank()) && attachmentIds.isEmpty()) {
                        throw new IllegalArgumentException("Message or attachment is required");
                    }
                    if (userText == null || userText.isBlank()) {
                        userText = "Please analyze the attached file(s).";
                    }
                    userMessage = conversations.addMessage(conversation.getId(), "user", userText.strip(), attachmentIds);
                }

                if (request.projectId() != null && !request.projectId().isBlank()) {
                    projects.requireConversation(request.projectId(), conversation.getId());
                }

                ChatMode mode = request.chatMode();
                Map<String,Object> meta = new java.util.LinkedHashMap<>();
                meta.put("conversationId", conversation.getId());
                meta.put("userMessageId", userMessage.getId());
                meta.put("mode", mode.wireName());
                if (agentRunId != null) meta.put("agentRunId", agentRunId);
                emitter.send(SseEmitter.event().name("meta").data(meta));

                List<Map<String, Object>> context = contextService.build(
                        conversation.getId(), userMessage, request.settings(), request.projectId(), apiKey, mode);

                String answer;
                if (mode == ChatMode.AGENT) {
                    AgentService.AgentResult result = agentService.run(agentRunId, apiKey, request, context, event -> {
                        try {
                            emitter.send(SseEmitter.event().name("agent_step").data(event));
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                    answer = result.answer();
                    emitter.send(SseEmitter.event().name("token").data(Map.of("text", visibleAgentAnswer(answer))));
                    if (!result.changes().isEmpty()) {
                        emitter.send(SseEmitter.event().name("agent_patch").data(Map.of("count", result.changes().size())));
                    }
                } else {
                    answer = llm.stream(apiKey, request.settings(), context, token -> {
                        try {
                            emitter.send(SseEmitter.event().name("token").data(Map.of("text", token)));
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }

                MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                MessageDto dto = conversations.messageDto(assistant);
                emitter.send(SseEmitter.event().name("done").data(dto));
                emitter.complete();
            } catch (Exception e) {
                if (agentRunId != null) agentService.failRun(agentRunId);
                try { emitter.send(SseEmitter.event().name("error").data(Map.of("message", safeMessage(e)))); }
                catch (Exception ignored) {}
                emitter.completeWithError(e);
            }
        });
        return emitter;
    }

    private String visibleAgentAnswer(String value) {
        if (value == null) return "";
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "").strip();
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isBlank()) return e.getClass().getSimpleName();
        return m.length() > 1500 ? m.substring(0, 1500) : m;
    }
}
