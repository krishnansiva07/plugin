package com.llmart.llm.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.regex.Pattern;

@Service
public class ExcelExportService {
    private static final Pattern SEPARATOR = Pattern.compile("^\\s*\\|?\\s*:?-{3,}:?\\s*(\\|\\s*:?-{3,}:?\\s*)+\\|?\\s*$");

    public byte[] fromMarkdown(String title, String markdown) throws Exception {
        String source = markdown == null ? "" : markdown;
        List<TableData> tables = extractTables(source);

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            CellStyle header = createHeaderStyle(workbook);
            CellStyle body = createBodyStyle(workbook);

            if (tables.isEmpty()) {
                Sheet sheet = workbook.createSheet("Generated Content");
                Row h = sheet.createRow(0);
                Cell hc = h.createCell(0);
                hc.setCellValue(safeTitle(title));
                hc.setCellStyle(header);
                String[] lines = source.split("\\R", -1);
                int rowIndex = 1;
                for (String line : lines) {
                    if (line.isBlank()) continue;
                    Row row = sheet.createRow(rowIndex++);
                    Cell cell = row.createCell(0);
                    cell.setCellValue(stripMarkdown(line));
                    cell.setCellStyle(body);
                }
                sheet.setColumnWidth(0, 120 * 256);
                sheet.createFreezePane(0, 1);
            } else {
                Set<String> usedNames = new HashSet<>();
                for (int i = 0; i < tables.size(); i++) {
                    TableData table = tables.get(i);
                    String preferred = i == 0 ? preferredFirstSheet(title, table.headers()) : "Table " + (i + 1);
                    String sheetName = uniqueSheetName(preferred, usedNames);
                    Sheet sheet = workbook.createSheet(sheetName);
                    int maxCols = table.headers().size();
                    Row headerRow = sheet.createRow(0);
                    for (int c = 0; c < maxCols; c++) {
                        Cell cell = headerRow.createCell(c);
                        cell.setCellValue(cleanCell(table.headers().get(c)));
                        cell.setCellStyle(header);
                    }
                    int r = 1;
                    for (List<String> values : table.rows()) {
                        Row row = sheet.createRow(r++);
                        for (int c = 0; c < maxCols; c++) {
                            Cell cell = row.createCell(c);
                            cell.setCellValue(c < values.size() ? cleanCell(values.get(c)) : "");
                            cell.setCellStyle(body);
                        }
                    }
                    sheet.createFreezePane(0, 1);
                    sheet.setAutoFilter(new org.apache.poi.ss.util.CellRangeAddress(0, Math.max(0, r - 1), 0, Math.max(0, maxCols - 1)));
                    for (int c = 0; c < maxCols; c++) {
                        sheet.autoSizeColumn(c);
                        int width = Math.min(sheet.getColumnWidth(c) + 768, 55 * 256);
                        sheet.setColumnWidth(c, Math.max(width, 12 * 256));
                    }
                }
            }
            workbook.write(out);
            return out.toByteArray();
        }
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true);
        setBorders(style);
        return style;
    }

    private CellStyle createBodyStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setWrapText(true);
        setBorders(style);
        return style;
    }

    private void setBorders(CellStyle style) {
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        short gray = IndexedColors.GREY_25_PERCENT.getIndex();
        style.setTopBorderColor(gray);
        style.setBottomBorderColor(gray);
        style.setLeftBorderColor(gray);
        style.setRightBorderColor(gray);
    }

    private List<TableData> extractTables(String markdown) {
        List<String> lines = Arrays.asList(markdown.split("\\R", -1));
        List<TableData> tables = new ArrayList<>();
        for (int i = 0; i + 1 < lines.size(); i++) {
            if (!looksLikeRow(lines.get(i)) || !SEPARATOR.matcher(lines.get(i + 1)).matches()) continue;
            List<String> headers = parseRow(lines.get(i));
            if (headers.size() < 2) continue;
            List<List<String>> rows = new ArrayList<>();
            int j = i + 2;
            while (j < lines.size() && looksLikeRow(lines.get(j))) {
                List<String> row = parseRow(lines.get(j));
                if (row.size() >= 2) rows.add(normalize(row, headers.size()));
                j++;
            }
            tables.add(new TableData(headers, rows));
            i = j - 1;
        }
        return tables;
    }

    private boolean looksLikeRow(String line) {
        if (line == null) return false;
        String s = line.trim();
        return s.contains("|") && !s.startsWith("```");
    }

    private List<String> parseRow(String line) {
        String s = line.trim();
        if (s.startsWith("|")) s = s.substring(1);
        if (s.endsWith("|")) s = s.substring(0, s.length() - 1);
        List<String> values = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean escaped = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (escaped) {
                cell.append(ch);
                escaped = false;
            } else if (ch == '\\') {
                escaped = true;
            } else if (ch == '|') {
                values.add(cell.toString().trim());
                cell.setLength(0);
            } else {
                cell.append(ch);
            }
        }
        if (escaped) cell.append('\\');
        values.add(cell.toString().trim());
        return values;
    }

    private List<String> normalize(List<String> values, int size) {
        List<String> result = new ArrayList<>(size);
        for (int i = 0; i < size; i++) result.add(i < values.size() ? values.get(i) : "");
        return result;
    }

    private String cleanCell(String value) {
        String s = value == null ? "" : value.trim();
        s = s.replaceAll("^`|`$", "");
        s = s.replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n");
        s = s.replace("**", "");
        if (s.length() > 32700) s = s.substring(0, 32680) + "… [truncated]";
        return s;
    }

    private String stripMarkdown(String line) {
        String value = line.replaceFirst("^\\s{0,3}#{1,6}\\s+", "")
                .replaceFirst("^\\s*[-*+]\\s+", "")
                .replace("**", "")
                .replace("`", "");
        return value.length() > 32700 ? value.substring(0, 32680) + "… [truncated]" : value;
    }

    private String safeTitle(String title) {
        if (title == null || title.isBlank()) return "Generated Content";
        return title.length() > 200 ? title.substring(0, 200) : title;
    }

    private String preferredFirstSheet(String title, List<String> headers) {
        boolean looksLikeTests = headers.stream().map(String::toLowerCase).anyMatch(h -> h.contains("test case") || h.equals("scenario") || h.contains("expected result"));
        if (looksLikeTests) return "Test Cases";
        if (title != null && !title.isBlank()) {
            String clean = stripMarkdown(title).replaceAll("[\\\\/?*\\[\\]:]", "_").trim();
            if (!clean.isBlank()) return clean.length() > 31 ? clean.substring(0, 31) : clean;
        }
        return "Data";
    }

    private String uniqueSheetName(String preferred, Set<String> used) {
        String base = preferred.replaceAll("[\\\\/?*\\[\\]:]", "_");
        if (base.length() > 31) base = base.substring(0, 31);
        String candidate = base;
        int n = 2;
        while (!used.add(candidate.toLowerCase(Locale.ROOT))) {
            String suffix = " " + n++;
            candidate = base.substring(0, Math.min(base.length(), 31 - suffix.length())) + suffix;
        }
        return candidate;
    }

    private record TableData(List<String> headers, List<List<String>> rows) {}
}
