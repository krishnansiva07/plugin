# V6 Java 17 General Agent — validation

The generation environment does not contain Maven, so a dependency-resolved `mvn clean test package` cannot be truthfully reported from this environment.

Validation performed while assembling this build:

- Java target in `pom.xml` remains Java 17.
- `pom.xml` XML parsing — passed.
- `node --check src/main/resources/static/app.js` — passed after Agent Run, cancellation, conflict and deletion UI changes.
- Java 17 `javac -proc:none` syntax-oriented pass over the source tree — no Java parser/syntax errors detected. Missing Spring/Jackson/JPA types are expected without Maven-resolved dependencies.
- Isolated Java 17 compile checks with minimal stubs were used for the Agent Run / approval / workspace / LLM-client core.
- Agent Run + Approval runtime smoke test — passed.
- Patch format now supports baseline hashes plus explicit deletions.
- Browser patch parser/apply code supports conflict checks, creates backups and rescans after rename/deletion.
- Source ZIP checked to exclude generated `.class`, build and temporary analysis files.

Two JUnit tests are included for Agent Run state/cancellation and approval resolution. Additional tests cover patch ZIP deletion metadata in this updated package.

Recommended final verification on a machine with Maven/network access:

```bash
mvn clean test package
```

Then run:

```bash
java -jar target/advanced-ai-chat-1.3.1-SNAPSHOT.jar
```

Suggested smoke scenarios:

1. Agent without mapped project → create a small Java 17 Maven project → Review files → Download ZIP.
2. Map an existing Maven project → Ask permission → edit → build → tests → diff → Apply.
3. Start a long build → Stop → confirm the Agent Run becomes cancelled and the process ends.
4. Start an agent edit, manually change the same original file, then Apply → expect HTTP 409 conflict and no partial writes.
5. Ask agent to rename/delete a file → review patch → apply → confirm backup and project reindex.
6. Map a monorepo → ask agent to build/test a nested `backend` or `frontend` using relative `cwd`.
