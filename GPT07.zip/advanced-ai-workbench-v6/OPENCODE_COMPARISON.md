# OpenCode-style comparison

| Capability | V6 |
|---|---|
| Chat sessions/history | Yes |
| Chat / read-only analysis / general workspace agent modes | Yes |
| Read/list/glob/grep-like project tools | Yes |
| Exact file edit and full file write | Yes |
| Build/test/allowlisted command execution | Yes |
| Allow / Ask / Deny permissions | Yes |
| Live approval during agent run | Yes |
| Agent activity / tool console | Yes |
| Git-like status/diff of staged agent changes | Yes |
| Context compaction for tool runs | Yes |
| Local workspace mirror | Yes |
| Review patch before touching original | Yes |
| Automatic backup before apply | Yes |
| General project/file analysis | Yes
| Recorded JSON + mapped project analysis | Yes |
| Screenshot/vision analysis | Yes, when a vision-capable model is configured |
| Generic Excel export + test-case generation | Yes |
| Native function-calling required | No |
| Full arbitrary shell / PTY | No — intentionally restricted |
| File deletion/move by agent | No — intentionally not exposed |
| LSP protocol integration | Not yet |
| MCP servers/custom tool marketplace | Not yet |
| IDE extension/TUI | Not yet |
| Multi-subagent delegation | Not yet |
