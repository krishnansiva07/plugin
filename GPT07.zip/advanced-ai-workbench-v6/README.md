# Advanced AI Workbench V6 — Java 17 General Agent

Advanced AI Workbench is a **general-purpose local workspace agent hosted by Java 17 / Spring Boot**. It is not tied to Selenium, Playwright, test automation, or even Java projects.

The same application provides three modes:

- **Chat** — normal conversation, coding, files, images and downloadable artifacts.
- **Analyze** — read-only analysis of projects, documents, screenshots, logs, JSON/CSV, SQL and requirements.
- **Agent** — iterative tool-using work: understand → plan → inspect → change → execute → observe → repair → verify → diff → review/apply.

Test automation remains one capability, not the product boundary.

## What the Agent can work on

The Java 17 host can inspect and change any supported text-based/mixed repository. Built-in build/test detection covers common ecosystems including:

- Java/Kotlin/Groovy/Scala-style repositories through Maven, Gradle, Ant and SBT
- JavaScript/TypeScript through npm, pnpm and Yarn
- Python / pytest
- Go
- Rust / Cargo
- .NET
- C/C++ through Make, CMake and Meson
- PHP / Composer
- Ruby / Rake
- Dart / Flutter
- Swift Package Manager
- Terraform validation
- Bazel/Bazelisk
- Zig
- Elixir / Mix
- Erlang / rebar3
- Haskell / Stack or Cabal
- Documentation, SQL, YAML/TOML/properties, CI/CD files, Dockerfiles, scripts and mixed monorepos

If a repository has multiple applications, build/test/command tools accept a relative `cwd` so the model can operate in the correct subproject.

## Agent can also create a project from zero

A mapped project is no longer required. If Agent mode starts without one, the backend creates an empty temporary **scratch workspace**. The agent can create a complete project there and return the staged files as a downloadable ZIP.

Examples:

```text
Create a Java 17 Spring Boot REST API with JWT authentication, PostgreSQL, tests and Docker files. Build it and fix compilation failures.
```

```text
Create a TypeScript CLI from these requirements. Add tests and README and validate it.
```

## Agent tools

The model uses a provider-neutral JSON tool protocol implemented by the Java application:

### Reasoning / discovery
- `set_plan`
- `inspect_project`
- `list_tree`
- `list_project`
- `glob_project`
- `search_project`
- `read_file`
- `read_files`

### Workspace changes
- `edit_file`
- `write_file`
- `make_directory`
- `move_file`
- `delete_file`

### Verification / execution
- `run_build` — optional relative `cwd`
- `run_tests` — optional relative `cwd`
- `run_command` — allowlisted command, optional relative `cwd`
- `changed_files`
- `git_status`
- `git_diff`

The LLM chooses the next tool after seeing the real result of the previous tool. This is a real iterative agent loop, not a fixed Java workflow that only asks the model for generated code.

## Reliability controls added to V6

### First-class Agent Run
Every Agent request receives a run ID and runtime state. The backend tracks running/completed/failed/cancelled state, the current plan, pending approvals and the active OS process.

### Real cancellation
**Stop** cancels the active LLM request, releases approval waits and terminates the currently tracked build/test/command process tree.

### Completion guard
When the agent changes source/configuration and an applicable build/validation is detected, it is prompted to verify after the latest change before declaring completion. Test-related work also requires a test attempt when a test runner is detected.

A failed build/test may still be reported as unresolved/blocked; it is never converted into a false pass.

### Conflict-safe Apply
Each staged file contains a SHA-256 hash of its baseline. Before Apply, the application verifies every target. If you changed a file after the agent started, Apply returns a conflict instead of silently overwriting your newer work.

Existing files are backed up under:

```text
.advanced-ai-chat-backup/<timestamp>/...
```

Delete and rename operations are also staged, conflict-checked and backed up.

### Context hygiene
Large hidden patch payloads are kept for UI review but removed from later LLM history. This prevents an old staged file version from contaminating reasoning on a newer project state.

### Safer command runner
Commands execute from the temporary project mirror with:

- Allow / Ask / Deny permission policy
- no shell chaining, redirects or pipes
- no absolute/parent-path arguments
- blocked inline Python/Node/Ruby/PHP/shell/PowerShell code execution
- blocked package publishing and destructive Terraform/Git operations
- sensitive cloud/token/password environment variables removed from child processes
- explicit process timeouts and cancellation
- reuse of an already-existing local `node_modules` / Python virtual environment where appropriate, without copying dependency trees into the patch

Build/test tools may execute project code. **This is not an OS-level Docker/VM sandbox. Only map projects you trust.**

## Permissions

Settings provide separate **Allow / Ask / Deny** controls for:

- file edits
- shell / build / tests
- diff / status

With **Ask**, the same agent run pauses, the UI shows Approve / Deny, and execution resumes after the decision.

## Project access

### Local workspace path — best for Agent mode

Open **Open project → Local workspace path** and map a trusted folder, for example:

```text
C:\work\customer-portal
```

or:

```text
/home/me/customer-portal
```

The backend builds an isolated temporary mirror. Agent changes occur there first. You can review, download or explicitly apply them later.

### Browser folder picker

The browser folder picker indexes supported files without sending an absolute filesystem path to the backend. File changes can still be reviewed/applied from the browser when the File System Access API is available. Build fidelity can be lower than a local-path workspace because binary/dependency resources are not all mirrored.

## Model configuration

Configure:

- API key
- OpenAI-compatible Base URL
- reasoning/chat model
- optional vision-capable model

The agent loop itself is provider-neutral and does not require native function-calling support.

## Example general-purpose request

```text
Analyze this repository first.
Find why the application fails during startup.
Trace the failure into the relevant configuration and source code.
Make only the required fixes.
Run the correct build and tests from the appropriate subproject.
If something fails, inspect it and continue fixing it.
Show me the final diff and verification status.
```

## Example test-automation request

```text
Use the uploaded recorded JSON and this mapped project.
Find the checkout flow and existing coverage.
Generate only missing functional/negative cases.
Update the existing framework using its conventions.
Run the relevant tests, repair failures and show the final diff.
```

## Build the Java 17 application

Requirements:

- JDK 17+
- Maven 3.9+ (or add/use the Maven Wrapper in your environment)

```bash
mvn clean test package
```

Run:

```bash
java -jar target/advanced-ai-chat-1.3.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Current boundary

This release is a **general-purpose software/workspace agent**. It does not yet provide unrestricted computer control, browser automation as an agent tool, MCP servers, LSP, external SaaS credentials, cloud mutation tools or subagent delegation. Those should be separate permissioned tool providers rather than hidden inside unrestricted shell execution.
