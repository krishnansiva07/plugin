#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TEMP" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPlanRelevance.java" \
  "$BASE/qa/plan-relevance/AgentPlanRelevanceSmoke.java"
java -cp "$TEMP" com.llmart.llm.service.AgentPlanRelevanceSmoke
