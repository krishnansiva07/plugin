package com.llmart.llm.service;

import java.util.List;

public class AgentPlanRelevanceSmoke {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String brd = "Create a Consolidated Business Requirements Document. Inputs: use Jira mcp to get all jira details " +
                "include images and screenshots. Jira IDs: BMSA-6110,BMSA-6593,BMSA-6603,BMSA-6606,BMSA-6698," +
                "BMSA-7833,BMSA-7885,BMSA-7886,BMSA-7887,BMSA-7888,BMSA-7889,BMSA-7890,BMSA-7891," +
                "BMSA-7893,BMSA-7894,BMSA-7895,BMSA-7896,BMSA-7901. Step 1: Get descriptions, comments, " +
                "attachments, and screenshots. Step 2: synthesize and consolidate. Step 3: generate Word .docx " +
                "and Markdown .md documents in the workspace.";
        check(AgentPlanRelevance.isExternalDocumentRequest(brd), "BRD not recognized as document artifact");
        check(AgentPlanRelevance.explicitWorkItemCount(brd) == 0, "Jira IDs treated as item counts");
        List<String> broken = List.of(
                "Inventory complete requested scope and initialize durable work-item ledger\nValidate: ledger coverage is complete",
                "Process first bounded batch using project conventions\nValidate: changes match the active batch",
                "Continue the remaining batches using compile/type/static checks\nValidate: structural errors fixed",
                "Drain failed items\nValidate: no pending work",
                "Final project verification on changed code and review diff\nValidate: compile passes");
        check(!AgentPlanRelevance.validate(brd, "external_document", broken).isEmpty(), "Wrong generic fallback accepted");
        List<String> correct = List.of(
                "Retrieve the specified Jira issues via Jira MCP with descriptions, comments, attachments and screenshots\nValidate: each key has an extraction result",
                "Analyze requirements and image contents with provenance\nValidate: traceable business rules",
                "Merge and consolidate overlaps into one requirements specification\nValidate: conflicts and duplicates documented",
                "Generate Word .docx and Markdown .md in the workspace\nValidate: both files exist",
                "Final verification: review source Jira issue coverage and Word/Markdown completeness\nValidate: evidence trace and documents checked");
        check(AgentPlanRelevance.validate(brd, "external_document", correct).isEmpty(), "Relevant plan rejected");
        check(!AgentPlanRelevance.validate(brd, "external_document", List.of(
                "Retrieve Jira MCP tickets, comments, attachments and screenshots\nValidate: all read",
                "documentation_inventory full source repository\nValidate: inventoried",
                "Merge consolidated requirements\nValidate: merged",
                "Generate Word docx and Markdown md\nValidate: saved",
                "Final verification: review output\nValidate: verified")).isBlank(), "Wrong documentation_inventory route was accepted");
        check(!AgentPlanRelevance.validate("Compare Java project with Jira MCP", "analysis", List.of(
                "Read Java project source\nValidate: read",
                "Final verify code differences\nValidate: reviewed")).isBlank(), "MCP source was omitted in read-only analysis");
        List<String> noImages = List.of(
                "Retrieve Jira MCP tickets, comments and attachments\nValidate: issues read",
                "Consolidate requirements and merge overlaps\nValidate: merged",
                "Generate Word .docx and Markdown .md\nValidate: outputs exist",
                "Final verification: review issue coverage\nValidate: outputs reviewed");
        check(AgentPlanRelevance.validate(brd, "external_document", noImages).contains("screenshot"), "Missing screenshots missed");
        check(AgentPlanRelevance.explicitWorkItemCount("Migrate 1200 files of Selenium to Playwright") == 1200, "Large migration size missing");
        check(AgentPlanRelevance.explicitWorkItemCount("BMSA-7924 and 50 tests to migrate") == 50, "Explicit test count missing");
        check(AgentPlanRelevance.explicitWorkItemCount("Debug BMSA-7924 on 2026-10-12") == 0, "Dates / issue numbers treated as scale");
        check(!AgentPlanRelevance.isExternalDocumentRequest("Migrate Java Selenium TestNG Cucumber to Playwright TS"), "Migration misclassified");
        check(!AgentPlanRelevance.isExternalDocumentRequest("Fix login bug in Java REST API"), "Bugfix misclassified");
        check(!AgentPlanRelevance.isExternalDocumentRequest("Analyze UI to API flow for alert calculation"), "Read-only analysis misclassified");
        check(AgentPlanRelevance.isReadOnlyAnalysisRequest("Analyze UI/API/data flow for alert KPI calculation"), "Flow investigation not read-only");
        check(AgentPlanRelevance.isReadOnlyAnalysisRequest("Compare the workspace against Jira MCP and identify gaps"), "Jira gap comparison not read-only");
        check(!AgentPlanRelevance.isReadOnlyAnalysisRequest("Analyze and fix failing login automation"), "Fix task incorrectly read-only");
        check(!AgentPlanRelevance.isReadOnlyAnalysisRequest("Run the 50 Playwright test cases"), "Testing run incorrectly read-only");
        check(!AgentPlanRelevance.validate("Analyze UI/API flow", "analysis", List.of("Inventory and initialize work-item ledger", "Final project compilation")).isEmpty(), "Wrong generic analysis fallback accepted");
        check(!AgentPlanRelevance.isExternalDocumentRequest("Run Playwright MCP automation tests"), "Test task misclassified");
        check(!AgentPlanRelevance.isExternalDocumentRequest("Generate functional documentation for the entire Java codebase"), "Repo docs misclassified");
        check(AgentPlanRelevance.validate("Create business requirements document", "external_document",
                List.of("Review requirements\nValidate: checked", "Generate Word document\nValidate: output created", "Final verify output\nValidate: checked")).isEmpty(), "Short non-MCP doc incorrectly rejected");
        check(AgentPlanRelevance.validate("Document full codebase", "documentation", List.of("Inspect repo", "Final validation")).contains("documentation_inventory"), "Repo documentation gate lost");
        System.out.println("PASS: Jira count isolation, task categories, artifact evidence, required outputs, invalid plan rejection, repository documentation guard");
    }
}
