package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

class DocumentationIntelligenceServiceTest {
    @TempDir Path temp;

    @Test
    void inventoryEvidenceValidationAndResumeCreateARealCompletionGate() throws Exception {
        Path repo = temp.resolve("repo");
        Files.createDirectories(repo.resolve("src/main/java/com/acme/service"));
        Files.createDirectories(repo.resolve("src/main/java/com/acme/controller"));
        Files.createDirectories(repo.resolve("src/test/java/com/acme"));
        Files.writeString(repo.resolve("pom.xml"), "<project><modelVersion>4.0.0</modelVersion></project>");
        Files.writeString(repo.resolve("src/main/java/com/acme/Application.java"), "package com.acme; public class Application { public static void main(String[] a){} }");
        Files.writeString(repo.resolve("src/main/java/com/acme/service/OrderService.java"), "package com.acme.service; public class OrderService { public void placeOrder(){} }");
        Files.writeString(repo.resolve("src/main/java/com/acme/controller/OrderController.java"), "package com.acme.controller; public class OrderController { }");
        Files.writeString(repo.resolve("src/test/java/com/acme/OrderServiceTest.java"), "package com.acme; class OrderServiceTest { }");

        Path docsStore = temp.resolve("documentation-store");
        AgentRunService runs = new AgentRunService(temp.resolve("run-store"));
        AgentRunService.AgentRun run = runs.start("conversation-docs", "project-docs");
        DocumentationIntelligenceService service = new DocumentationIntelligenceService(new ObjectMapper(), docsStore.toString());
        AgentWorkspaceService.Workspace ws = workspace("project-docs", repo);

        String inventory = service.inventory(ws, run, 500);
        List<String> moduleIds = moduleIds(inventory);
        assertFalse(moduleIds.isEmpty());
        assertFalse(run.documentationCoverageComplete());
        assertFalse(run.documentationValidated());

        List<String> evidence = new ArrayList<>();
        for (String moduleId : moduleIds) {
            String context = service.moduleContext(ws, run, moduleId, 200, 4);
            String path = firstFile(context);
            assertNotNull(path, "Every discovered module must expose at least one owned source/config/test file");
            evidence.add(path);
            service.recordModule(ws, run, moduleId,
                    "This module contributes implemented repository behavior and is documented from the supplied source evidence. Functional intent not proven by code is explicitly treated as unknown.",
                    "This module contains concrete implementation, configuration, interface, data or test responsibilities derived from the inspected repository evidence.",
                    List.of(path), List.of("Repository relationship derived from module boundaries"), List.of());
        }
        assertTrue(run.documentationCoverageComplete(), run::documentationCoverageSummary);
        assertFalse(run.documentationValidated());

        String evidenceIndex = evidence.stream().distinct().map(p -> "- " + p).reduce("", (a,b) -> a + b + "\n");
        Files.writeString(repo.resolve("FUNCTIONAL_DOCUMENTATION.md"), longFunctionalDocument(evidenceIndex));
        Files.writeString(repo.resolve("TECHNICAL_DOCUMENTATION.md"), longTechnicalDocument(evidenceIndex));

        String validation = service.validate(ws, run, "FUNCTIONAL_DOCUMENTATION.md", "TECHNICAL_DOCUMENTATION.md", "");
        assertTrue(validation.startsWith("PASS"), validation);
        assertTrue(run.documentationValidated());

        // A later workspace mutation invalidates the prior PASS so the final plan step cannot close on stale docs.
        run.markMutation(false);
        assertFalse(run.documentationValidated());

        // Revalidate, then verify a new run for the same unchanged repository can reuse durable module knowledge.
        validation = service.validate(ws, run, "FUNCTIONAL_DOCUMENTATION.md", "TECHNICAL_DOCUMENTATION.md", "");
        assertTrue(validation.startsWith("PASS"), validation);
        AgentRunService.AgentRun resumed = runs.start("conversation-docs-resumed", "project-docs");
        DocumentationIntelligenceService reloaded = new DocumentationIntelligenceService(new ObjectMapper(), docsStore.toString());
        String resumedInventory = reloaded.inventory(ws, resumed, 500);
        assertFalse(moduleIds(resumedInventory).isEmpty());
        assertTrue(resumed.documentationCoverageComplete(), resumed::documentationCoverageSummary);
        assertFalse(resumed.documentationValidated(), "A resumed run must revalidate final output files even when module knowledge is safely reused");
    }

    @Test
    void nonexistentEvidenceCannotMarkModuleComplete() throws Exception {
        Path repo = temp.resolve("repo2");
        Files.createDirectories(repo.resolve("src"));
        Files.writeString(repo.resolve("src/App.java"), "class App {}");
        AgentRunService runs = new AgentRunService(temp.resolve("runs2"));
        AgentRunService.AgentRun run = runs.start("c2", "p2");
        DocumentationIntelligenceService service = new DocumentationIntelligenceService(new ObjectMapper(), temp.resolve("cache2").toString());
        AgentWorkspaceService.Workspace ws = workspace("p2", repo);
        String moduleId = moduleIds(service.inventory(ws, run, 500)).get(0);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.recordModule(ws, run, moduleId,
                "Application behavior is represented by this module and requires valid source evidence before it can complete.",
                "Application implementation is represented by this module and requires a real workspace path as evidence.",
                List.of("src/Missing.java"), List.of(), List.of()));
        assertTrue(ex.getMessage().contains("does not exist"));
        assertFalse(run.documentationCoverageComplete());
    }

    private List<String> moduleIds(String inventory) {
        Matcher matcher = Pattern.compile("(?m)^\\d+\\.\\s+([^\\s]+)\\s+—").matcher(inventory);
        List<String> out = new ArrayList<>();
        while (matcher.find()) out.add(matcher.group(1));
        return out;
    }

    private String firstFile(String moduleContext) {
        Matcher matcher = Pattern.compile("(?m)^-\\s+([^\\r\\n]+)$").matcher(moduleContext);
        return matcher.find() ? matcher.group(1).strip() : null;
    }

    private String longFunctionalDocument(String evidenceIndex) {
        String detail = "The repository behavior is described from implementation evidence. Each workflow, business rule, integration boundary, validation, error path, and security statement is limited to what the inspected source proves. Unknown business intent is explicitly retained as an unknown rather than inferred. ".repeat(7);
        return """
                # Functional Documentation
                ## Executive Summary
                %s
                ## Purpose, Scope and Repository Boundary
                %s
                ## Actors / Users / External Systems
                Code-defined callers and external systems are described where evidence exists.
                ## Functional Capability Map
                Functional capabilities are mapped to their owning modules and evidence.
                ## End-to-End Functional Workflows
                %s
                ## Business Rules and Validations
                Business rules and validation behavior are source-derived.
                ## Inputs, Outputs and Data Movement
                Inputs, outputs and data movement are traced through implementation boundaries.
                ## External Integrations and Dependencies
                Integration boundaries are documented from code and configuration.
                ## Scheduled / Background / Event-Driven Functional Behaviour
                Background behavior is documented when present; otherwise it is explicitly marked not observed.
                ## Error, Retry and User-Visible Failure Behaviour
                Error and retry behavior is based on repository evidence.
                ## Functional Security / Authorization Behaviour
                Security behavior is documented without exposing secret values.
                ## Functional Traceability Matrix
                Every discovered module is represented by the coverage ledger.
                ## Known Gaps, Unknowns and Out-of-Repository Behaviour
                Business facts not provable from the repository remain unknown.
                ## Source Evidence Index
                %s
                """.formatted(detail, detail, detail, evidenceIndex);
    }

    private String longTechnicalDocument(String evidenceIndex) {
        String detail = "The technical architecture is reconstructed from concrete module, component, API, data, configuration, security, logging, testing and deployment evidence. Relationships are described as implemented, while external runtime facts that are absent from the repository are explicitly identified as unknown. ".repeat(7);
        return """
                # Technical Documentation
                ## Executive Technical Summary
                %s
                ## System Context and Solution Architecture
                %s
                ## Technology Stack and Build/Runtime Model
                Build descriptors and source language evidence define the technology stack.
                ## Repository / Module Map
                All discovered modules are represented in the deterministic coverage ledger.
                ## Component Responsibilities and Dependency Relationships
                Components and dependencies are derived from implementation evidence.
                ## Entry Points, APIs and Interfaces
                APIs and interfaces are documented from source entry points.
                ## Domain/Data Model, Persistence and Storage
                Data and persistence behavior are described when present.
                ## Messaging, Events, Queues and Scheduled Jobs
                Event and scheduled behavior are described when present.
                ## External Integrations
                Dependencies and integration boundaries are evidence-backed.
                ## Configuration, Profiles, Secrets Boundaries and Environment Behaviour
                Configuration is described without exposing secret values.
                ## Authentication, Authorization and Security Controls
                Security controls are source-derived.
                ## Error/Exception/Retry/Resilience Design
                Exception and resilience behavior is source-derived.
                ## Logging, Monitoring and Observability
                Logging and monitoring behavior is documented from implementation evidence.
                ## Concurrency, Performance and Scalability Considerations Supported by Source Evidence
                Performance statements are limited to source evidence.
                ## CI/CD, Packaging and Deployment
                Build and deployment behavior is documented from repository artifacts.
                ## Testing Strategy and Test Architecture
                Testing architecture and test evidence are documented.
                ## Extension Points / Maintainability Notes
                Extension points are based on observed design boundaries.
                ## Known Technical Risks, Unknowns and External Boundaries
                Runtime facts outside the repository remain unknown.
                ## Source Evidence Index
                %s
                """.formatted(detail, detail, evidenceIndex);
    }

    @SuppressWarnings("unchecked")
    private AgentWorkspaceService.Workspace workspace(String projectId, Path root) throws Exception {
        Constructor<?> ctor = AgentWorkspaceService.Workspace.class.getDeclaredConstructors()[0];
        ctor.setAccessible(true);
        return (AgentWorkspaceService.Workspace) ctor.newInstance(projectId, root.toAbsolutePath().normalize(), Map.of(), Map.of(), Map.of(), null);
    }
}
