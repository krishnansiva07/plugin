package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/**
 * Deterministic repository-wide documentation orchestration support.
 *
 * The model is responsible for understanding implementation semantics, but this service owns the parts that must
 * not depend on model memory: repository inventory, module coverage, persisted module knowledge, evidence checks,
 * professional document structure and the final completion gate.
 */
@Service
public class DocumentationIntelligenceService {
    private static final int MAX_INVENTORY_FILES = 100_000;
    private static final int DEFAULT_MAX_MODULES = 1_000;
    private static final int HARD_MAX_MODULES = 5_000;
    private static final int MAX_MODULE_CONTEXT_FILES = 500;
    private static final int MAX_MODULE_EXCERPTS = 16;
    private static final int MAX_EXCERPT_CHARS = 6_000;
    private static final int MAX_KNOWLEDGE_CHARS = 120_000;

    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle", ".idea", ".next",
            "coverage", ".advanced-ai-chat-backup", ".agent-build", ".agent-home", ".venv", "venv", "env", "vendor",
            ".terraform", ".dart_tool", ".tox", ".pytest_cache", "__pycache__", ".mypy_cache", ".ruff_cache", ".cache",
            "bin", "obj", "pods", "deriveddata", ".build"
    );
    private static final Set<String> RELEVANT_EXTENSIONS = Set.of(
            "java","kt","kts","groovy","scala","js","jsx","ts","tsx","mjs","cjs","py","rb","php","go","rs",
            "c","cc","cpp","cxx","h","hpp","cs","fs","fsx","vb","swift","dart","r","lua","pl","pm","ex","exs",
            "clj","cljs","sql","graphql","gql","proto","thrift","vue","svelte","jsp","ftl","mustache","tf","hcl","bzl",
            "sh","bash","zsh","ps1","bat","cmd","xml","json","jsonl","yml","yaml","toml","ini","conf","config","properties",
            "md","adoc","rst","txt","feature","robot","gradle","sbt","html","htm","css","scss","sass","less"
    );
    private static final Set<String> BUILD_FILES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json",
            "pyproject.toml", "setup.py", "go.mod", "cargo.toml", "makefile", "cmakelists.txt", "composer.json",
            "gemfile", "mix.exs", "build.sbt", "gradlew", "mvnw"
    );
    private static final List<String> SOURCE_ROOTS = List.of(
            "src/main/java", "src/main/kotlin", "src/main/scala", "src/main/groovy",
            "src/main/resources", "src/test/java", "src/test/kotlin", "src/test/scala", "src/test/resources",
            "src", "app", "lib", "server", "client", "backend", "frontend", "services", "packages", "modules", "tests", "test"
    );

    private final ObjectMapper objectMapper;
    private final Path storeDir;
    private final Map<String, DocumentationState> cache = new ConcurrentHashMap<>();

    public DocumentationIntelligenceService(ObjectMapper objectMapper) {
        this(objectMapper, System.getProperty("advanced.ai.documentationStore", "./data/documentation-runs"));
    }

    DocumentationIntelligenceService(ObjectMapper objectMapper, String storePath) {
        this.objectMapper = objectMapper;
        this.storeDir = Path.of(storePath == null || storePath.isBlank() ? "./data/documentation-runs" : storePath)
                .toAbsolutePath().normalize();
        try { Files.createDirectories(storeDir); } catch (Exception ignored) { }
    }

    public String inventory(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, int requestedMaxModules) throws IOException {
        Objects.requireNonNull(ws, "workspace");
        Objects.requireNonNull(run, "run");
        int maxModules = requestedMaxModules <= 0 ? DEFAULT_MAX_MODULES : Math.min(HARD_MAX_MODULES, Math.max(10, requestedMaxModules));
        DocumentationState prior = latestCompatibleState(ws.root(), run.id());
        Set<String> priorGeneratedOutputs = prior == null ? Set.of() : new LinkedHashSet<>(prior.outputPaths());
        Inventory inventory = discover(ws.root(), maxModules, priorGeneratedOutputs);
        LinkedHashMap<String, ModuleState> modules = new LinkedHashMap<>();
        for (ModuleSeed seed : inventory.modules()) {
            ModuleState preserved = reusableModule(prior, seed);
            modules.put(seed.id(), preserved != null ? preserved : new ModuleState(seed.id(), seed.title(), seed.root(), seed.category(), "pending",
                    seed.fileCount(), List.of(), "", "", List.of(), List.of(), ""));
        }
        DocumentationState state = new DocumentationState(run.id(), ws.root().toString(), Instant.now().toString(),
                inventory.filesScanned(), inventory.truncated(), modules, false, "", List.of());
        cache.put(run.id(), state);
        persist(state);

        run.configureDocumentationMode(true);
        run.initializeWorkItems(modules.values().stream().map(ModuleState::title).toList(), Math.max(3, Math.min(20, run.workItemBatchSize())));
        for (ModuleState module : modules.values()) {
            if ("completed".equals(module.status()) || "excluded".equals(module.status())) {
                syncWorkItem(run, module.title(), "completed", "Restored unchanged documentation knowledge from prior interrupted run");
            }
        }
        String summary = coverageSummary(state);
        run.updateDocumentationCoverage(coverageComplete(state), summary);
        run.updateDocumentationValidation(false, "Repository inventory was initialized/refreshed; final documentation validation is required for this run.");
        return inventoryReport(state);
    }

    public String coverage(AgentRunService.AgentRun run, String statusFilter, int offset, int limit) {
        DocumentationState state = requireState(run.id());
        boolean complete = coverageComplete(state);
        String summary = coverageSummary(state);
        run.updateDocumentationCoverage(complete, summary);

        String filter = statusFilter == null ? "" : statusFilter.strip().toLowerCase(Locale.ROOT);
        int skip = Math.max(0, offset);
        int max = limit <= 0 ? 50 : Math.min(200, limit);
        StringBuilder out = new StringBuilder(summary).append('\n');
        int matched = 0, emitted = 0;
        for (ModuleState module : state.modules().values()) {
            if (!filter.isBlank() && !filter.equals(module.status())) continue;
            if (matched++ < skip) continue;
            if (emitted++ >= max) break;
            out.append(module.id()).append(" [").append(module.status()).append("] ")
                    .append(module.title()).append(" · ").append(module.fileCount()).append(" files");
            if (!module.note().isBlank()) out.append(" — ").append(module.note());
            out.append('\n');
        }
        if (emitted == 0) out.append("[No matching documentation modules]\n");
        if (state.inventoryTruncated()) out.append("WARNING: repository inventory was truncated; successful documentation completion is intentionally blocked. Re-run documentation_inventory with a larger supported scope or reduce generated/vendor content.\n");
        return out.toString().stripTrailing();
    }

    public String moduleContext(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String moduleId,
                                int requestedMaxFiles, int requestedExcerptFiles) throws IOException {
        DocumentationState state = requireState(run.id());
        ModuleState module = requireModule(state, moduleId);
        int maxFiles = requestedMaxFiles <= 0 ? 180 : Math.min(MAX_MODULE_CONTEXT_FILES, Math.max(20, requestedMaxFiles));
        int excerptFiles = requestedExcerptFiles <= 0 ? 8 : Math.min(MAX_MODULE_EXCERPTS, Math.max(0, requestedExcerptFiles));
        Path moduleRoot = resolveRelative(ws.root(), module.root());
        List<Path> files = relevantFiles(moduleRoot, ws.root(), MAX_INVENTORY_FILES);
        if ("configuration".equals(module.category())) {
            files = files.stream().filter(p -> isConfigurationEvidence(moduleRoot, p)).toList();
        } else {
            files = ownedModuleFiles(ws.root(), state, module, files);
        }

        StringBuilder out = new StringBuilder();
        out.append("DOCUMENTATION MODULE\n")
                .append("id: ").append(module.id()).append('\n')
                .append("title: ").append(module.title()).append('\n')
                .append("root: ").append(module.root()).append('\n')
                .append("category: ").append(module.category()).append('\n')
                .append("inventoryFileCount: ").append(module.fileCount()).append('\n')
                .append("status: ").append(module.status()).append("\n\n")
                .append("FILES (bounded; use read/grep/lsp for deeper evidence):\n");

        List<Path> ordered = new ArrayList<>(files);
        ordered.sort(Comparator.comparingInt(this::documentationImportance).reversed().thenComparing(Path::toString));
        for (int i = 0; i < Math.min(maxFiles, ordered.size()); i++) {
            Path p = ordered.get(i);
            out.append("- ").append(rel(ws.root(), p)).append('\n');
        }
        if (ordered.size() > maxFiles) out.append("... ").append(ordered.size() - maxFiles).append(" more file(s); use glob/grep/read for targeted inspection.\n");

        if (excerptFiles > 0) {
            out.append("\nHIGH-SIGNAL EXCERPTS:\n");
            int added = 0;
            for (Path file : ordered) {
                if (added >= excerptFiles) break;
                if (!safeTextFile(file)) continue;
                String text;
                try { text = Files.readString(file, StandardCharsets.UTF_8); } catch (Exception ignored) { continue; }
                if (text.isBlank()) continue;
                out.append("\n--- ").append(rel(ws.root(), file)).append(" ---\n")
                        .append(clip(text, MAX_EXCERPT_CHARS)).append('\n');
                added++;
            }
        }
        out.append("\nRECORDING REQUIREMENT: after analysis, call documentation_record_module with concise functional + technical summaries, cross-module relationships, unknowns, and real evidencePaths from this workspace. A module is not counted complete until that record succeeds.");
        return clip(out.toString(), 90_000);
    }

    public String recordModule(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String moduleId,
                               String functionalSummary, String technicalSummary, List<String> evidencePaths,
                               List<String> relationships, List<String> unknowns) throws IOException {
        DocumentationState state = requireState(run.id());
        ModuleState old = requireModule(state, moduleId);
        String functional = clean(functionalSummary, 20_000);
        String technical = clean(technicalSummary, 24_000);
        if (functional.length() < 20) throw new IllegalArgumentException("functionalSummary is too short; describe implemented capabilities/flows/rules or explicitly state that the module has no direct functional behavior");
        if (technical.length() < 20) throw new IllegalArgumentException("technicalSummary is too short; describe actual components/interfaces/data/configuration/operations");
        List<String> evidence = validateEvidence(ws.root(), state, old, evidencePaths);
        if (evidence.isEmpty()) throw new IllegalArgumentException("At least one real source evidence path is required before a documentation module can complete");
        ModuleState updated = new ModuleState(old.id(), old.title(), old.root(), old.category(), "completed", old.fileCount(),
                evidence, functional, technical, cleanList(relationships, 100, 1000), cleanList(unknowns, 100, 1000),
                "Evidence-backed module analysis recorded");
        DocumentationState next = replaceModule(state, updated, false, "", state.outputPaths());
        cache.put(run.id(), next);
        persist(next);
        syncWorkItem(run, old.title(), "completed", "Documentation module recorded with " + evidence.size() + " evidence path(s)");
        boolean complete = coverageComplete(next);
        String summary = coverageSummary(next);
        run.updateDocumentationCoverage(complete, summary);
        run.updateDocumentationValidation(false, "Module knowledge changed; final documentation validation must be rerun.");
        return "Recorded " + old.id() + " as completed. " + summary;
    }

    public String excludeModule(AgentRunService.AgentRun run, String moduleId, String reason) throws IOException {
        DocumentationState state = requireState(run.id());
        ModuleState old = requireModule(state, moduleId);
        String note = clean(reason, 2_000);
        if (note.length() < 10) throw new IllegalArgumentException("A concrete exclusion reason is required");
        ModuleState updated = new ModuleState(old.id(), old.title(), old.root(), old.category(), "excluded", old.fileCount(),
                List.of(), "", "", List.of(), List.of(), note);
        DocumentationState next = replaceModule(state, updated, false, "", state.outputPaths());
        cache.put(run.id(), next);
        persist(next);
        syncWorkItem(run, old.title(), "completed", "Documentation scope exclusion: " + note);
        boolean complete = coverageComplete(next);
        String summary = coverageSummary(next);
        run.updateDocumentationCoverage(complete, summary);
        run.updateDocumentationValidation(false, "Coverage changed; final documentation validation must be rerun.");
        return "Excluded " + old.id() + " from documentation scope with reason. " + summary;
    }

    public String knowledge(AgentRunService.AgentRun run, String query, int requestedMaxModules) {
        DocumentationState state = requireState(run.id());
        int maxModules = requestedMaxModules <= 0 ? 200 : Math.min(500, Math.max(1, requestedMaxModules));
        String q = query == null ? "" : query.strip().toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder();
        out.append("DOCUMENTATION KNOWLEDGE\n").append(coverageSummary(state)).append("\n\n");
        int emitted = 0;
        for (ModuleState module : state.modules().values()) {
            if (!Set.of("completed", "excluded").contains(module.status())) continue;
            String searchable = (module.title() + " " + module.root() + " " + module.functionalSummary() + " " + module.technicalSummary() + " " + String.join(" ", module.relationships())).toLowerCase(Locale.ROOT);
            if (!q.isBlank() && !searchable.contains(q)) continue;
            if (emitted++ >= maxModules) break;
            out.append("## ").append(module.title()).append(" [").append(module.status()).append("]\n")
                    .append("id: ").append(module.id()).append("\nroot: ").append(module.root()).append("\ncategory: ").append(module.category()).append('\n');
            if ("excluded".equals(module.status())) {
                out.append("exclusion: ").append(module.note()).append("\n\n");
                continue;
            }
            out.append("functional: ").append(module.functionalSummary()).append('\n')
                    .append("technical: ").append(module.technicalSummary()).append('\n');
            if (!module.relationships().isEmpty()) out.append("relationships:\n- ").append(String.join("\n- ", module.relationships())).append('\n');
            if (!module.unknowns().isEmpty()) out.append("unknowns:\n- ").append(String.join("\n- ", module.unknowns())).append('\n');
            out.append("evidence:\n- ").append(String.join("\n- ", module.evidencePaths())).append("\n\n");
            if (out.length() >= MAX_KNOWLEDGE_CHARS) {
                out.append("[Knowledge output clipped; call documentation_knowledge with a query to retrieve a narrower subset.]\n");
                break;
            }
        }
        if (emitted == 0) out.append("[No matching completed module knowledge]\n");
        return clip(out.toString(), MAX_KNOWLEDGE_CHARS);
    }

    public String template() {
        return """
                PROFESSIONAL REPOSITORY DOCUMENTATION TEMPLATE

                Create two Markdown source documents unless the user explicitly requested a combined document. Keep statements evidence-backed and mark anything not provable from available sources as Unknown / External dependency.

                FUNCTIONAL DOCUMENT — mandatory structure
                1. Executive Summary
                2. Purpose, Scope and Repository Boundary
                3. Actors / Users / External Systems
                4. Functional Capability Map (capability -> owning module -> evidence)
                5. End-to-End Functional Workflows (numbered steps; include Mermaid flow/sequence diagrams where useful)
                6. Business Rules and Validations
                7. Inputs, Outputs and Data Movement
                8. External Integrations and Dependencies
                9. Scheduled / Background / Event-Driven Functional Behaviour
                10. Error, Retry and User-Visible Failure Behaviour
                11. Functional Security / Authorization Behaviour
                12. Functional Traceability Matrix
                13. Known Gaps, Unknowns and Out-of-Repository Behaviour
                14. Source Evidence Index

                TECHNICAL DOCUMENT — mandatory structure
                1. Executive Technical Summary
                2. System Context and Solution Architecture
                3. Technology Stack and Build/Runtime Model
                4. Repository / Module Map
                5. Component Responsibilities and Dependency Relationships
                6. Entry Points, APIs and Interfaces
                7. Domain/Data Model, Persistence and Storage
                8. Messaging, Events, Queues and Scheduled Jobs
                9. External Integrations
                10. Configuration, Profiles, Secrets Boundaries and Environment Behaviour
                11. Authentication, Authorization and Security Controls
                12. Error/Exception/Retry/Resilience Design
                13. Logging, Monitoring and Observability
                14. Concurrency, Performance and Scalability Considerations Supported by Source Evidence
                15. CI/CD, Packaging and Deployment
                16. Testing Strategy and Test Architecture
                17. Extension Points / Maintainability Notes
                18. Known Technical Risks, Unknowns and External Boundaries
                19. Source Evidence Index

                QUALITY RULES
                - Cover every documentation_inventory module or explicitly list its approved exclusion reason.
                - Important claims cite real relative source paths; the final Source Evidence Index must include at least one evidence path for every completed module.
                - Separate what the code proves from inferred/unknown business intent.
                - Describe actual current behavior, not a proposed redesign, unless the user asked for recommendations.
                - Prefer diagrams for architecture, major workflow, integration and sequence relationships, but keep the surrounding text self-contained.
                - Do not expose secrets or copy credentials/config values; describe secret boundaries and key names only when safe.
                - Avoid enormous class-by-class dumps. Explain responsibilities and relationships, then use appendices/evidence indexes for traceability.
                """;
    }

    public String validate(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                           String functionalPath, String technicalPath, String combinedPath) throws IOException {
        DocumentationState state = requireState(run.id());
        List<String> failures = new ArrayList<>();
        if (!coverageComplete(state)) failures.add("Repository documentation coverage is incomplete: " + coverageSummary(state));
        if (state.inventoryTruncated()) failures.add("Repository inventory was truncated, so complete coverage cannot be proven.");

        String functionalText = "";
        String technicalText = "";
        List<String> outputs = new ArrayList<>();
        String combined = clean(combinedPath, 1000);
        if (!combined.isBlank()) {
            Path file = resolveRelative(ws.root(), combined);
            functionalText = technicalText = readDocumentationFile(file, failures, "combined");
            if (!functionalText.isBlank()) outputs.add(rel(ws.root(), file));
        } else {
            String fp = clean(functionalPath, 1000);
            String tp = clean(technicalPath, 1000);
            if (fp.isBlank()) failures.add("functionalPath is required unless combinedPath is supplied");
            else {
                Path file = resolveRelative(ws.root(), fp);
                functionalText = readDocumentationFile(file, failures, "functional");
                if (!functionalText.isBlank()) outputs.add(rel(ws.root(), file));
            }
            if (tp.isBlank()) failures.add("technicalPath is required unless combinedPath is supplied");
            else {
                Path file = resolveRelative(ws.root(), tp);
                technicalText = readDocumentationFile(file, failures, "technical");
                if (!technicalText.isBlank()) outputs.add(rel(ws.root(), file));
            }
        }

        validateFunctionalStructure(functionalText, failures);
        validateTechnicalStructure(technicalText, failures);
        String combinedDocuments = functionalText + "\n" + technicalText;
        validateEvidenceCoverage(state, combinedDocuments, failures);
        validateExclusionCoverage(state, combinedDocuments, failures);

        boolean pass = failures.isEmpty();
        String summary = pass
                ? "PASS — repository coverage is complete, required functional/technical sections are present, and every completed module is traceable to source evidence."
                : "FAIL — " + String.join(" | ", failures);
        DocumentationState next = new DocumentationState(state.runId(), state.projectRoot(), state.inventoryAt(), state.filesScanned(),
                state.inventoryTruncated(), state.modules(), pass, summary, List.copyOf(outputs));
        cache.put(run.id(), next);
        persist(next);
        run.updateDocumentationCoverage(coverageComplete(next), coverageSummary(next));
        run.updateDocumentationValidation(pass, summary);
        run.markVerificationAttempt(pass, "documentation_validate: " + summary);
        if (pass) run.clearVerificationFailures();
        else run.recordVerificationFailures(summary);
        return summary + (outputs.isEmpty() ? "" : "\nValidated outputs:\n- " + String.join("\n- ", outputs));
    }

    private Inventory discover(Path root, int maxModules, Set<String> excludedRelativePaths) throws IOException {
        List<Path> files = relevantFiles(root, root, MAX_INVENTORY_FILES + 1);
        if (excludedRelativePaths != null && !excludedRelativePaths.isEmpty()) {
            files = files.stream().filter(path -> !excludedRelativePaths.contains(rel(root, path))).toList();
        }
        boolean fileTruncated = files.size() > MAX_INVENTORY_FILES;
        if (fileTruncated) files = new ArrayList<>(files.subList(0, MAX_INVENTORY_FILES));

        LinkedHashSet<Path> buildRoots = new LinkedHashSet<>();
        buildRoots.add(root);
        for (Path file : files) if (isBuildDescriptor(file)) buildRoots.add(file.getParent());
        List<Path> orderedBuildRoots = buildRoots.stream().sorted(Comparator.comparingInt(Path::getNameCount).reversed()).toList();

        List<ModuleSeed> seeds = new ArrayList<>();
        for (Path buildRoot : orderedBuildRoots) {
            List<Path> assigned = new ArrayList<>();
            for (Path file : files) {
                if (!file.startsWith(buildRoot)) continue;
                Path nearest = nearestBuildRoot(file, orderedBuildRoots, root);
                if (buildRoot.equals(nearest)) assigned.add(file);
            }
            if (assigned.isEmpty()) continue;
            addModuleSeedsForBuildRoot(root, buildRoot, assigned, seeds);
            if (seeds.size() > maxModules) break;
        }

        // Deterministic de-duplication by category + root path.
        LinkedHashMap<String, ModuleSeed> unique = new LinkedHashMap<>();
        for (ModuleSeed seed : seeds) unique.putIfAbsent(seed.category() + "|" + seed.root(), seed);
        List<ModuleSeed> finalSeeds = new ArrayList<>(unique.values());
        finalSeeds.sort(Comparator.comparing(ModuleSeed::root).thenComparing(ModuleSeed::category));
        boolean moduleTruncated = finalSeeds.size() > maxModules;
        if (moduleTruncated) finalSeeds = new ArrayList<>(finalSeeds.subList(0, maxModules));
        return new Inventory(List.copyOf(finalSeeds), files.size(), fileTruncated || moduleTruncated);
    }

    private void addModuleSeedsForBuildRoot(Path workspaceRoot, Path buildRoot, List<Path> assigned, List<ModuleSeed> out) {
        String buildRel = rel(workspaceRoot, buildRoot);
        Map<String,List<Path>> bySourceRoot = new LinkedHashMap<>();
        List<Path> configurationFiles = new ArrayList<>();
        for (Path file : assigned) {
            String within = rel(buildRoot, file);
            String sourceRoot = matchingSourceRoot(within);
            if (sourceRoot == null) configurationFiles.add(file);
            else bySourceRoot.computeIfAbsent(sourceRoot, ignored -> new ArrayList<>()).add(file);
        }

        for (Map.Entry<String,List<Path>> entry : bySourceRoot.entrySet()) {
            Path sourceRoot = buildRoot.resolve(entry.getKey()).normalize();
            List<Path> sourceFiles = entry.getValue();
            boolean packageLike = entry.getKey().contains("/java") || entry.getKey().contains("/kotlin") || entry.getKey().contains("/scala") || entry.getKey().equals("src");
            List<Path> groups = packageLike ? splitSourceArea(sourceRoot, sourceFiles) : List.of(sourceRoot);
            for (Path group : groups) {
                List<Path> ownedFiles = sourceFiles.stream()
                        .filter(p -> p.startsWith(group))
                        .filter(p -> groups.stream().noneMatch(other -> !other.equals(group) && other.startsWith(group) && p.startsWith(other)))
                        .toList();
                long count = ownedFiles.size();
                if (count <= 0) continue;
                String category = entry.getKey().contains("test") || entry.getKey().equals("tests") || entry.getKey().equals("test") ? "tests"
                        : entry.getKey().contains("resources") ? "resources" : "code";
                String groupRel = rel(workspaceRoot, group);
                String title = (buildRel.equals(".") ? "" : buildRel + " · ") + category + " · " + groupRel;
                out.add(new ModuleSeed(stableId(category + "|" + groupRel), title, groupRel, category, (int)Math.min(Integer.MAX_VALUE, count),
                        latestModifiedMillis(ownedFiles)));
            }
        }

        if (!configurationFiles.isEmpty()) {
            String rootRel = buildRel;
            String title = (buildRel.equals(".") ? "workspace" : buildRel) + " · build/configuration";
            out.add(new ModuleSeed(stableId("configuration|" + rootRel), title, rootRel, "configuration", configurationFiles.size(),
                    latestModifiedMillis(configurationFiles)));
        }
        if (bySourceRoot.isEmpty() && configurationFiles.isEmpty()) {
            out.add(new ModuleSeed(stableId("module|" + buildRel), buildRel + " · module", buildRel, "code", assigned.size(),
                    latestModifiedMillis(assigned)));
        }
    }

    private List<Path> splitSourceArea(Path sourceRoot, List<Path> files) {
        List<List<String>> parentSegments = new ArrayList<>();
        for (Path file : files) {
            Path parent = file.getParent();
            if (parent == null || !parent.startsWith(sourceRoot)) continue;
            Path relative = sourceRoot.relativize(parent);
            List<String> seg = new ArrayList<>();
            for (Path part : relative) seg.add(part.toString());
            parentSegments.add(seg);
        }
        if (parentSegments.isEmpty()) return List.of(sourceRoot);
        int common = commonPrefix(parentSegments);
        LinkedHashSet<String> nextSegments = new LinkedHashSet<>();
        for (List<String> seg : parentSegments) if (seg.size() > common) nextSegments.add(seg.get(common));
        if (nextSegments.size() < 2 || nextSegments.size() > 60) return List.of(sourceRoot);
        List<Path> groups = new ArrayList<>();
        Path commonRoot = sourceRoot;
        if (!parentSegments.get(0).isEmpty()) {
            for (int i = 0; i < common && i < parentSegments.get(0).size(); i++) commonRoot = commonRoot.resolve(parentSegments.get(0).get(i));
        }
        // Preserve files that live directly at the shared package root (for example Application.java) as their
        // own deterministic scope instead of silently dropping them between child package buckets.
        boolean hasDirectFiles = parentSegments.stream().anyMatch(parts -> parts.size() == common);
        if (hasDirectFiles) groups.add(commonRoot.normalize());
        for (String next : nextSegments) groups.add(commonRoot.resolve(next).normalize());
        return groups;
    }

    private int commonPrefix(List<List<String>> values) {
        if (values.isEmpty()) return 0;
        int max = values.stream().mapToInt(List::size).min().orElse(0);
        int common = 0;
        for (; common < max; common++) {
            String value = values.get(0).get(common);
            boolean all = true;
            for (List<String> parts : values) if (!Objects.equals(value, parts.get(common))) { all = false; break; }
            if (!all) break;
        }
        return common;
    }

    private String matchingSourceRoot(String path) {
        String normalized = path.replace('\\','/');
        for (String root : SOURCE_ROOTS) {
            if (normalized.equals(root) || normalized.startsWith(root + "/")) return root;
        }
        return null;
    }

    private Path nearestBuildRoot(Path file, List<Path> roots, Path fallback) {
        for (Path root : roots) if (file.startsWith(root)) return root;
        return fallback;
    }

    private List<Path> relevantFiles(Path scanRoot, Path workspaceRoot, int max) throws IOException {
        List<Path> out = new ArrayList<>();
        if (!Files.isDirectory(scanRoot)) return out;
        Files.walkFileTree(scanRoot, EnumSet.noneOf(FileVisitOption.class), 24, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (!dir.equals(scanRoot)) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name) || Files.isSymbolicLink(dir)) return FileVisitResult.SKIP_SUBTREE;
                }
                return out.size() >= max ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (out.size() >= max) return FileVisitResult.TERMINATE;
                if (attrs.isRegularFile() && !Files.isSymbolicLink(file) && !skipped(workspaceRoot, file) && isRelevant(file)) out.add(file);
                return out.size() >= max ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
            }
        });
        return out;
    }

    private boolean skipped(Path root, Path path) {
        Path rel;
        try { rel = root.relativize(path); } catch (Exception e) { return true; }
        for (Path part : rel) if (SKIP_DIRS.contains(part.toString().toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean isRelevant(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (BUILD_FILES.contains(name) || name.endsWith(".csproj") || name.endsWith(".fsproj") || name.equals("dockerfile")) return true;
        int dot = name.lastIndexOf('.');
        return dot >= 0 && RELEVANT_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private boolean isBuildDescriptor(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        return BUILD_FILES.contains(name) || name.endsWith(".csproj") || name.endsWith(".fsproj");
    }

    private boolean isConfigurationEvidence(Path moduleRoot, Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (isBuildDescriptor(file) || name.equals("dockerfile") || name.startsWith("application.") || name.startsWith("bootstrap.")) return true;
        String rel = rel(moduleRoot, file);
        int depth = rel.equals(".") ? 0 : rel.split("/").length;
        if (depth > 3) return false;
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1);
        return Set.of("xml","json","yml","yaml","toml","ini","conf","config","properties","tf","hcl","gradle","md","txt","sh","ps1","bat","cmd").contains(ext);
    }

    private int documentationImportance(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        String value = file.toString().toLowerCase(Locale.ROOT).replace('\\','/');
        int score = 0;
        if (BUILD_FILES.contains(name) || name.endsWith(".csproj")) score += 100;
        if (name.contains("application") || name.contains("main") || name.contains("controller") || name.contains("route") || name.contains("api")) score += 60;
        if (name.contains("service") || name.contains("handler") || name.contains("usecase") || name.contains("manager")) score += 50;
        if (name.contains("repository") || name.contains("dao") || name.contains("entity") || name.contains("model") || name.contains("schema")) score += 40;
        if (name.contains("config") || name.contains("security") || name.contains("auth")) score += 35;
        if (value.contains("/test/") || value.contains("/tests/") || value.contains("src/test")) score += 25;
        if (name.endsWith(".md")) score += 15;
        return score;
    }

    private List<String> validateEvidence(Path workspaceRoot, DocumentationState state, ModuleState module, List<String> rawEvidence) throws IOException {
        LinkedHashSet<String> clean = new LinkedHashSet<>();
        Path moduleRoot = resolveRelative(workspaceRoot, module.root());
        for (String raw : rawEvidence == null ? List.<String>of() : rawEvidence) {
            if (raw == null || raw.isBlank()) continue;
            Path path = resolveRelative(workspaceRoot, raw);
            if (!Files.isRegularFile(path)) throw new IllegalArgumentException("Evidence path does not exist or is not a file: " + raw);
            if (!path.startsWith(moduleRoot) && !"configuration".equals(module.category())) {
                throw new IllegalArgumentException("Evidence path is outside documentation module " + module.id() + ": " + raw);
            }
            if (!"configuration".equals(module.category()) && !belongsToModule(workspaceRoot, state, module, path)) {
                throw new IllegalArgumentException("Evidence path belongs to a nested documentation module rather than " + module.id() + ": " + raw);
            }
            clean.add(rel(workspaceRoot, path));
            if (clean.size() >= 100) break;
        }
        return List.copyOf(clean);
    }

    private List<Path> ownedModuleFiles(Path workspaceRoot, DocumentationState state, ModuleState module, List<Path> files) throws IOException {
        if (files == null || files.isEmpty()) return List.of();
        return files.stream().filter(path -> {
            try { return belongsToModule(workspaceRoot, state, module, path); }
            catch (Exception ignored) { return false; }
        }).toList();
    }

    private boolean belongsToModule(Path workspaceRoot, DocumentationState state, ModuleState module, Path path) throws IOException {
        Path moduleRoot = resolveRelative(workspaceRoot, module.root());
        if (!path.startsWith(moduleRoot)) return false;
        for (ModuleState other : state.modules().values()) {
            if (Objects.equals(other.id(), module.id()) || !Objects.equals(other.category(), module.category())) continue;
            Path otherRoot = resolveRelative(workspaceRoot, other.root());
            if (otherRoot.equals(moduleRoot) || !otherRoot.startsWith(moduleRoot)) continue;
            if (path.startsWith(otherRoot)) return false;
        }
        return true;
    }

    private void syncWorkItem(AgentRunService.AgentRun run, String title, String status, String note) {
        for (Map<String,Object> item : run.workItemsSnapshot(5000)) {
            if (!Objects.equals(title, String.valueOf(item.get("title")))) continue;
            run.updateWorkItems(List.of(String.valueOf(item.get("id"))), status, note);
            return;
        }
    }

    private boolean coverageComplete(DocumentationState state) {
        if (state == null || state.inventoryTruncated() || state.modules().isEmpty()) return false;
        boolean anyCompleted = false;
        for (ModuleState module : state.modules().values()) {
            if ("completed".equals(module.status())) {
                anyCompleted = true;
                if (module.evidencePaths().isEmpty() || module.functionalSummary().isBlank() || module.technicalSummary().isBlank()) return false;
            } else if (!"excluded".equals(module.status())) return false;
        }
        return anyCompleted;
    }

    private String coverageSummary(DocumentationState state) {
        long completed = state.modules().values().stream().filter(m -> "completed".equals(m.status())).count();
        long excluded = state.modules().values().stream().filter(m -> "excluded".equals(m.status())).count();
        long pending = state.modules().size() - completed - excluded;
        long evidence = state.modules().values().stream().mapToLong(m -> m.evidencePaths().size()).sum();
        int percent = state.modules().isEmpty() ? 0 : (int)Math.floor(((completed + excluded) * 100.0) / state.modules().size());
        return "Documentation coverage: " + (completed + excluded) + "/" + state.modules().size() + " modules closed (" + percent + "%)" +
                "; completed=" + completed + "; excluded=" + excluded + "; pending=" + pending + "; evidencePaths=" + evidence +
                (state.inventoryTruncated() ? "; inventoryTruncated=true" : "");
    }

    private String inventoryReport(DocumentationState state) {
        StringBuilder out = new StringBuilder("DOCUMENTATION INVENTORY INITIALIZED\n")
                .append("repository: ").append(state.projectRoot()).append('\n')
                .append("relevantFilesScanned: ").append(state.filesScanned()).append('\n')
                .append("modulesDiscovered: ").append(state.modules().size()).append('\n')
                .append("inventoryTruncated: ").append(state.inventoryTruncated()).append("\n\n")
                .append(coverageSummary(state)).append("\n\nMODULES:\n");
        int i = 1;
        for (ModuleState module : state.modules().values()) {
            out.append(i++).append(". ").append(module.id()).append(" — ").append(module.title())
                    .append(" [").append(module.category()).append(", ").append(module.fileCount()).append(" files]\n");
        }
        out.append("\nProcess modules in bounded batches. Call documentation_module before documenting a module, then documentation_record_module with real evidence paths.");
        return clip(out.toString(), 90_000);
    }

    private void validateFunctionalStructure(String text, List<String> failures) {
        if (text == null || text.length() < 1_500) { failures.add("Functional documentation is missing or too small to represent repository-wide coverage."); return; }
        requireTerms(text, failures, "functional", List.of("scope", "functional", "workflow", "business", "integration", "error", "security", "evidence"));
    }

    private void validateTechnicalStructure(String text, List<String> failures) {
        if (text == null || text.length() < 1_500) { failures.add("Technical documentation is missing or too small to represent repository-wide coverage."); return; }
        requireTerms(text, failures, "technical", List.of("architecture", "module", "component", "api", "data", "configuration", "security", "logging", "testing", "deployment", "evidence"));
    }

    private void requireTerms(String text, List<String> failures, String kind, List<String> terms) {
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> missing = terms.stream().filter(t -> !lower.contains(t)).toList();
        if (!missing.isEmpty()) failures.add(kind + " documentation is missing expected sections/concepts: " + String.join(", ", missing));
    }

    private void validateEvidenceCoverage(DocumentationState state, String documents, List<String> failures) {
        String normalized = documents == null ? "" : documents.replace('\\','/');
        List<String> uncovered = new ArrayList<>();
        for (ModuleState module : state.modules().values()) {
            if (!"completed".equals(module.status())) continue;
            boolean cited = module.evidencePaths().stream().anyMatch(normalized::contains);
            if (!cited) uncovered.add(module.id() + " (expected one of: " + String.join(", ", module.evidencePaths().stream().limit(3).toList()) + ")");
            if (uncovered.size() >= 20) break;
        }
        if (!uncovered.isEmpty()) failures.add("Final documents do not trace every completed module to source evidence: " + String.join("; ", uncovered));
    }

    private void validateExclusionCoverage(DocumentationState state, String documents, List<String> failures) {
        String normalized = documents == null ? "" : documents.toLowerCase(Locale.ROOT);
        List<String> missing = new ArrayList<>();
        for (ModuleState module : state.modules().values()) {
            if (!"excluded".equals(module.status())) continue;
            String id = module.id().toLowerCase(Locale.ROOT);
            String title = module.title().toLowerCase(Locale.ROOT);
            String reason = module.note().toLowerCase(Locale.ROOT);
            String reasonPrefix = reason.length() > 40 ? reason.substring(0, 40) : reason;
            boolean represented = normalized.contains(id) || (!title.isBlank() && normalized.contains(title)) ||
                    (!reasonPrefix.isBlank() && normalized.contains(reasonPrefix));
            if (!represented) missing.add(module.id());
            if (missing.size() >= 20) break;
        }
        if (!missing.isEmpty()) failures.add("Final documents do not list approved documentation exclusions and reasons for: " + String.join(", ", missing));
    }

    private String readDocumentationFile(Path file, List<String> failures, String kind) throws IOException {
        if (!Files.isRegularFile(file)) { failures.add(kind + " documentation file does not exist: " + file); return ""; }
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (!(name.endsWith(".md") || name.endsWith(".txt") || name.endsWith(".adoc") || name.endsWith(".rst"))) {
            failures.add(kind + " documentation validation currently requires a text/Markdown source file (.md/.txt/.adoc/.rst): " + file);
            return "";
        }
        return Files.readString(file, StandardCharsets.UTF_8);
    }

    private DocumentationState replaceModule(DocumentationState state, ModuleState module, boolean validated, String validationSummary, List<String> outputPaths) {
        LinkedHashMap<String,ModuleState> next = new LinkedHashMap<>(state.modules());
        next.put(module.id(), module);
        return new DocumentationState(state.runId(), state.projectRoot(), state.inventoryAt(), state.filesScanned(), state.inventoryTruncated(),
                next, validated, validationSummary == null ? "" : validationSummary, outputPaths == null ? List.of() : List.copyOf(outputPaths));
    }

    private DocumentationState latestCompatibleState(Path projectRoot, String currentRunId) {
        if (!Files.isDirectory(storeDir)) return null;
        DocumentationState best = null;
        Instant bestAt = Instant.EPOCH;
        try (Stream<Path> stream = Files.list(storeDir)) {
            for (Path file : stream.filter(p -> p.getFileName().toString().endsWith(".json")).toList()) {
                try {
                    DocumentationState candidate = objectMapper.readValue(file.toFile(), DocumentationState.class);
                    if (candidate == null || Objects.equals(currentRunId, candidate.runId())) continue;
                    if (!Objects.equals(projectRoot.toAbsolutePath().normalize().toString(), Path.of(candidate.projectRoot()).toAbsolutePath().normalize().toString())) continue;
                    Instant at = Instant.parse(candidate.inventoryAt());
                    if (at.isAfter(bestAt)) { bestAt = at; best = candidate; }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return best;
    }

    private ModuleState reusableModule(DocumentationState prior, ModuleSeed seed) {
        if (prior == null) return null;
        ModuleState old = prior.modules().get(seed.id());
        if (old == null || !("completed".equals(old.status()) || "excluded".equals(old.status()))) return null;
        if (!Objects.equals(old.root(), seed.root()) || !Objects.equals(old.category(), seed.category()) || old.fileCount() != seed.fileCount()) return null;
        try {
            long inventoryMillis = Instant.parse(prior.inventoryAt()).toEpochMilli();
            if (seed.latestModifiedMillis() > inventoryMillis) return null;
            if ("completed".equals(old.status())) {
                if (old.evidencePaths().isEmpty() || old.functionalSummary().isBlank() || old.technicalSummary().isBlank()) return null;
                Path root = Path.of(prior.projectRoot()).toAbsolutePath().normalize();
                for (String evidence : old.evidencePaths()) {
                    Path path = root.resolve(evidence).normalize();
                    if (!path.startsWith(root) || !Files.isRegularFile(path)) return null;
                }
            }
            return old;
        } catch (Exception ignored) {
            return null;
        }
    }

    private long latestModifiedMillis(List<Path> files) {
        long latest = 0L;
        for (Path file : files == null ? List.<Path>of() : files) {
            try { latest = Math.max(latest, Files.getLastModifiedTime(file).toMillis()); } catch (Exception ignored) { }
        }
        return latest;
    }

    private DocumentationState requireState(String runId) {
        DocumentationState state = cache.get(runId);
        if (state != null) return state;
        Path file = storeDir.resolve(runId + ".json");
        if (!Files.isRegularFile(file)) throw new IllegalStateException("Documentation inventory is not initialized. Call documentation_inventory first.");
        try {
            state = objectMapper.readValue(file.toFile(), DocumentationState.class);
            cache.put(runId, state);
            return state;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to load persisted documentation state: " + e.getMessage(), e);
        }
    }

    private ModuleState requireModule(DocumentationState state, String moduleId) {
        String id = moduleId == null ? "" : moduleId.strip();
        ModuleState module = state.modules().get(id);
        if (module == null) throw new IllegalArgumentException("Unknown documentation module id: " + moduleId + ". Use documentation_coverage to list current module ids.");
        return module;
    }

    private void persist(DocumentationState state) throws IOException {
        Files.createDirectories(storeDir);
        Path target = storeDir.resolve(state.runId() + ".json");
        Path tmp = storeDir.resolve(state.runId() + ".json.tmp");
        objectMapper.writerWithDefaultPrettyPrinter().writeValue(tmp.toFile(), state);
        try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
    }

    private Path resolveRelative(Path root, String raw) throws IOException {
        String value = raw == null || raw.isBlank() || raw.equals(".") ? "." : raw.replace('\\','/');
        Path resolved = root.resolve(value).normalize();
        if (!resolved.startsWith(root)) throw new IllegalArgumentException("Path escapes workspace: " + raw);
        return resolved;
    }

    private String rel(Path root, Path path) {
        try {
            String value = root.relativize(path).toString().replace('\\','/');
            return value.isBlank() ? "." : value;
        } catch (Exception e) { return path.toString().replace('\\','/'); }
    }

    private String stableId(String value) {
        String clean = value == null ? "module" : value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("(^-+|-+$)", "");
        if (clean.length() > 44) clean = clean.substring(0, 44);
        if (clean.isBlank()) clean = "module";
        return clean + "-" + Integer.toUnsignedString(Objects.hashCode(value), 36);
    }

    private boolean safeTextFile(Path file) {
        try {
            if (Files.size(file) > 512L * 1024L) return false;
        } catch (Exception e) { return false; }
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1);
        return RELEVANT_EXTENSIONS.contains(ext) || BUILD_FILES.contains(name) || name.equals("dockerfile");
    }

    private String clean(String value, int max) {
        if (value == null) return "";
        String out = value.strip();
        return out.length() <= max ? out : out.substring(0, max);
    }

    private List<String> cleanList(List<String> values, int maxItems, int maxChars) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (String value : values == null ? List.<String>of() : values) {
            String clean = clean(value, maxChars);
            if (!clean.isBlank()) out.add(clean);
            if (out.size() >= maxItems) break;
        }
        return List.copyOf(out);
    }

    private String clip(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, Math.max(0, max - 30)) + "\n...[documentation output clipped]";
    }

    private record ModuleSeed(String id, String title, String root, String category, int fileCount, long latestModifiedMillis) { }
    private record Inventory(List<ModuleSeed> modules, int filesScanned, boolean truncated) { }

    public record ModuleState(String id, String title, String root, String category, String status, int fileCount,
                              List<String> evidencePaths, String functionalSummary, String technicalSummary,
                              List<String> relationships, List<String> unknowns, String note) {
        public ModuleState {
            evidencePaths = evidencePaths == null ? List.of() : List.copyOf(evidencePaths);
            relationships = relationships == null ? List.of() : List.copyOf(relationships);
            unknowns = unknowns == null ? List.of() : List.copyOf(unknowns);
            functionalSummary = functionalSummary == null ? "" : functionalSummary;
            technicalSummary = technicalSummary == null ? "" : technicalSummary;
            note = note == null ? "" : note;
            status = status == null ? "pending" : status;
            category = category == null ? "code" : category;
            root = root == null || root.isBlank() ? "." : root;
            title = title == null ? id : title;
        }
    }

    public record DocumentationState(String runId, String projectRoot, String inventoryAt, int filesScanned,
                                     boolean inventoryTruncated, LinkedHashMap<String, ModuleState> modules,
                                     boolean validated, String validationSummary, List<String> outputPaths) {
        public DocumentationState {
            modules = modules == null ? new LinkedHashMap<>() : new LinkedHashMap<>(modules);
            validationSummary = validationSummary == null ? "" : validationSummary;
            outputPaths = outputPaths == null ? List.of() : List.copyOf(outputPaths);
        }
    }
}
