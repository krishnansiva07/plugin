# ELIYA Documentation Intelligence - Implementation & Validation

## Scope implemented
ELIYA now has a dedicated large-codebase documentation workflow instead of treating documentation as a normal coding/migration task.

### Runtime/orchestration
- Detects repository documentation creation requests such as functional documentation, technical documentation, architecture docs and codebase docs while avoiding ordinary input-document analysis.
- Uses a documentation-specific 5-stage fallback plan: repository inventory -> bounded module analysis -> relationship/flow synthesis -> document generation -> final documentation validation.
- Adds eight dedicated tools:
  - `documentation_inventory`
  - `documentation_coverage`
  - `documentation_module`
  - `documentation_record_module`
  - `documentation_exclude_module`
  - `documentation_knowledge`
  - `documentation_template`
  - `documentation_validate`
- Documentation completion is coverage/evidence driven. Compile/test is not substituted for documentation validation unless separately requested.

### Repository coverage engine
- Deterministic repository scan with generated/vendor/build-directory pruning.
- Supports up to 100,000 relevant scanned files and up to 5,000 documentation modules. A truncated inventory intentionally blocks successful completion.
- Partitions build roots, source roots, tests, resources and configuration into bounded documentation scopes.
- Handles classes/files directly at a common package root without losing them between nested package scopes.
- Prevents nested documentation scopes from being double-counted in module context.
- Every discovered module is represented in the existing durable work-item ledger.
- A module becomes complete only after an evidence-backed functional + technical summary is recorded using real workspace file paths.
- Modules can be excluded only with a concrete reason; final documents must represent approved exclusions.

### Durable knowledge / long-run recovery
- Module summaries are persisted outside the user's workspace under the ELIYA documentation-run store.
- A later run for the same unchanged repository can reuse completed/excluded module knowledge instead of restarting from zero.
- Reuse requires the same module identity/file count, source timestamps not newer than the prior inventory, and existing evidence files.
- Previously generated validated documentation outputs are excluded from a resumed source inventory so ELIYA does not treat its own output as new application scope.
- A resumed run still requires final document revalidation before completion.

### Functional documentation template
The built-in template requires:
1. Executive Summary
2. Purpose, Scope and Repository Boundary
3. Actors / Users / External Systems
4. Functional Capability Map
5. End-to-End Functional Workflows
6. Business Rules and Validations
7. Inputs, Outputs and Data Movement
8. External Integrations and Dependencies
9. Scheduled / Background / Event-Driven Functional Behaviour
10. Error, Retry and User-Visible Failure Behaviour
11. Functional Security / Authorization Behaviour
12. Functional Traceability Matrix
13. Known Gaps, Unknowns and Out-of-Repository Behaviour
14. Source Evidence Index

### Technical documentation template
The built-in template requires:
1. Executive Technical Summary
2. System Context and Solution Architecture
3. Technology Stack and Build/Runtime Model
4. Repository / Module Map
5. Component Responsibilities and Dependency Relationships
6. Entry Points, APIs and Interfaces
7. Domain/Data Model, Persistence and Storage
8. Messaging, Events, Queues and Scheduled Jobs
9. External Integrations
10. Configuration, Profiles, Secrets Boundaries and Environment Behaviour
11. Authentication, Authorization and Security Controls
12. Error/Exception/Retry/Resilience Design
13. Logging, Monitoring and Observability
14. Concurrency, Performance and Scalability Considerations Supported by Source Evidence
15. CI/CD, Packaging and Deployment
16. Testing Strategy and Test Architecture
17. Extension Points / Maintainability Notes
18. Known Technical Risks, Unknowns and External Boundaries
19. Source Evidence Index

### Completion and safety gates
- `documentation_validate` fails if repository coverage is incomplete or inventory was truncated.
- It fails if functional/technical documents are missing/too small or lack required concepts.
- It fails if a completed module has no source path represented in final documentation.
- It fails if approved exclusions are not represented in final documentation.
- The final approved plan step cannot complete until documentation coverage is complete and `documentation_validate` has passed.
- The Agent run itself cannot finish successfully while documentation coverage/validation is incomplete.
- Any workspace mutation after a documentation PASS automatically invalidates that PASS and requires `documentation_validate` again.

### UI visibility
The existing Agent run UI now displays:
- work-item completion count,
- Documentation coverage pending / complete,
- Documentation validation pending / passed,
- coverage/validation summary text in the Documentation Intelligence status panel.

## Files added/changed
- Added `src/main/java/com/llmart/llm/service/DocumentationIntelligenceService.java`
- Updated `AgentService.java`
- Updated `AgentRunService.java`
- Updated `AgentToolRegistry.java`
- Updated `src/main/resources/static/app.js`
- Added `DocumentationIntelligenceServiceTest.java`
- Updated `AgentServiceCompatibilityTest.java`
- Updated `AgentToolRegistryTest.java`

## Validation performed in this environment
| Check | Result |
| --- | --- |
| Documentation core Java 17 type compilation with minimal Spring/Jackson/workspace stubs | **PASS** |
| Isolated documentation behavioral smoke test | **PASS** — 5 deterministic scopes, evidence-backed completion, 100% coverage, final validation PASS, post-validation mutation invalidation |
| Java parse checks for changed production/test sources | **PASS** |
| `node --check src/main/resources/static/app.js` | **PASS** |
| `node --check src/main/resources/static/markdown.js` | **PASS** |
| Existing deletion approval / rollback offline smoke | **PASS** |
| Existing Vision adapter offline smoke | **PASS** |
| Existing UI/API contract smoke (11 checks) | **PASS** |
| Existing deletion approval popup JS regression | **PASS** |
| Tool registry consistency | **PASS** — 78 unique tools, 8 documentation tools, no duplicate tool names; every core tool exists in registry |
| Full Maven compile/JUnit | **BLOCKED BY ENVIRONMENT** |

## Maven limitation
`./mvnw -version` was attempted. This environment has no installed Maven and the wrapper cannot bootstrap Maven because DNS resolution for `repo.maven.apache.org` fails (`curl: (6) Could not resolve host`). Therefore this package is source/isolated-validation complete here, but a real project-wide Maven compilation and full JUnit run still must be executed in the normal development environment with dependency access.

Recommended final verification there:
```bash
./mvnw clean package
./mvnw -Pfull-tests test
```
