package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.McpTool;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PlaywrightToolAdapterTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void currentMcpUsesRealRefNotSelectorSyntax() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"ref":{"type":"string"}},"required":["element","ref"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        Map<String,Object> args = adapter.click("BCEF", "e42", false);
        assertEquals("e42", args.get("ref"));
        assertFalse(args.containsKey("target"));
    }

    @Test
    void legacyTargetSchemaStillWorks() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"target":{"type":"string"}},"required":["element","target"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        Map<String,Object> args = adapter.click("BCEF", "text=BCEF", false);
        assertEquals("text=BCEF", args.get("target"));
    }

    @Test
    void browserTypeUsesSingleFieldSchema() throws Exception {
        McpTool type = new McpTool("browser_type", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"ref":{"type":"string"},"text":{"type":"string"}},"required":["element","ref","text"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(type));
        Map<String,Object> args = adapter.type("Start date", "e9", "01/07/2026");
        assertEquals("01/07/2026", args.get("text"));
        assertFalse(args.containsKey("fields"));
    }
}
