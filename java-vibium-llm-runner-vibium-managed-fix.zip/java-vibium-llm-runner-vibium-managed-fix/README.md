# Java Vibium LLM Runner - Managed Browser Fix

This version removes the invalid local ChromeDriver/CDP bridge mode.

## Why the earlier version failed

The previous workaround started `chromedriver.exe`, created a WebDriver session, then passed the returned `webSocketUrl` to Vibium. That URL is already tied to an existing WebDriver BiDi session. Vibium starts by creating its own BiDi session, so the browser/driver returns:

```text
BiDi error: session not created
pipe closed
```

So ChromeDriver can start successfully and still Vibium fails immediately. This is not a test-case problem and not an LLM-token problem.

## Supported modes in this build

1. **Vibium Managed Chrome for Testing** - recommended pure Vibium Java mode.
2. **Remote WebDriver BiDi Connect** - only for a remote provider that accepts Vibium's BiDi session creation. Do not paste Chrome DevTools `/json/version` or `/devtools/browser/...` URL.

## Important limitation

Current Vibium Java `StartOptions.executablePath` points to the Vibium binary, not to `chrome.exe` or `chromedriver.exe`. Local browser executable path is therefore not used in pure Vibium Java managed mode.

## Corporate network fix

Vibium Java checks whether Chrome for Testing is installed and, if missing, runs Vibium install. On corporate networks this can fail if these domains are blocked:

- `googlechromelabs.github.io`
- `storage.googleapis.com`
- `github.com`
- `repo.maven.apache.org`

Best fix: allow the above domains, or install/copy Vibium cache from a machine where `vibium install` works. On Windows the cache is normally:

```text
%LOCALAPPDATA%\vibium\chrome-for-testing\<version>\chrome-win64\chrome.exe
```

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Recommended UI selection

```text
Browser launch mode = Vibium Managed Chrome for Testing
```

Do not use ChromeDriver path for pure Vibium Java.
