# ELIYA28 — Confluence Composer and Agentic documentation (source integration)

Starting point: ELIYA27 Presentation Quality Upgrade; original Chat, Agent, workspace/indexing, MCP and presentation code remain in place. Formatter19 served as the reference for portable Confluence HTML, safe structures and HTML/plain-text clipboard semantics. Formatter19's second LLM connection and dependency graph were not copied.

## Use

- **Direct:** Sidebar → Confluence Composer → paste text / Use latest answer → choose theme → Format & preview → Copy for Confluence. A completed assistant answer also has a **Confluence** action. The copy operation attempts HTML and plain text together, with a visibly labeled plain-text fallback; Download HTML is available.
- **Entire workspace:** Set the main local workspace path, switch to Agent, use Prompt library → **Create Complete Confluence Documentation from Entire Workspace**. Agent should inventory and explore the repository with existing tools, generate evidence-based `docs/confluence/*.md`, call `confluence_compose` for each `.html`, then `confluence_validate`. Open the relevant `.md` with Composer → Load .md → Format & preview → Copy.
- **Read only references:** existing reference-folder behavior is unchanged. `confluence_compose` can write only within the active writable workspace and uses the existing file-edit permission and change journal.

## Implementation / limits

New files: `ConfluenceComposerService`, `ConfluenceComposerController`, `confluence-composer.js`. Integration: `AgentToolRegistry`, `AgentWorkspaceService`, `AgentService`, `index.html`, `app.js`, `app.css`, guide, prompts and tests. Formatting supports Markdown headings, numbered/bulleted lists, paragraphs, simple tables, code fences, inline bold/italics/code, safe HTTP(S) links and blockquotes. No Confluence macros, native diagrams, cloud publication, automatic factual editing or end-to-end proof of codebase coverage. Plain-text fallback is not a guarantee of rich paste. Import accepts only relative `.md`/`.txt` paths in the active local workspace and rejects symlinks.

For Java 17 builds, run `mvn -Pfull-tests clean test` (if Maven and dependencies are available), then `mvn -DskipTests package`; from Windows, use the provided Maven wrapper only if it is fully configured. Offline quality checks: `node --test src/test/js/*.js`, `node --check src/main/resources/static/{app,confluence-composer,prompt-catalog}.js`, `bash qa/offline-smoke/run.sh`, and `bash qa/confluence-smoke/run.sh`.

**Validation boundary:** Offline syntax tests and focused standalone Java tests do not prove the complete Spring/POI app has compiled and started. Verify full Maven compilation and browser clipboard behavior on your target OS + Confluence editor before production distribution.

---

# ELIYA24 — manual folder entry, HTML guide and expanded prompt library (October 2026)

**This section supersedes older Browse/picker instructions further down this historical README.** Browse project and Browse reference are no longer displayed in the UI. Use **Enter path** to set the main editable workspace and **Reference path** to attach up to five read-only supporting folders with unique aliases. Native folder-picker backend code is retained for compatibility but is not called by the current UI. All path entry and alias renaming now use a labeled in-app modal instead of JavaScript `window.prompt`.

**HTML guide:** Open **How to use Eliya** directly after Settings in the sidebar, or the link inside Settings. The file is served at `/how-to-use-eliya.html` and can also be opened standalone from `src/main/resources/static/how-to-use-eliya.html`.

**Folder terms:** `Workspace [workspace]` is the selected main project. `Reference [LegacySelenium]` is a read-only reference registered with alias `LegacySelenium`. A prompt can say: `Compare Workspace [workspace] with Reference [LegacySelenium]; implement changes only in Workspace [workspace].` The path-entry modal previews this syntax. The path must exist on the Java server's computer.

**Prompt library:** 116 total templates (17 original + 99 additional) with task-specific titles, purposes, mode labels, search and category filters, **Use prompt** and **Copy**. Chat-oriented new templates open Chat; Agent-oriented templates open Agent. When available, the active project path and single-reference alias/path replace template placeholders. Fill in other `<...>` inputs before submitting. New catalog source: `src/main/resources/static/prompt-catalog.js`.

**Validation:** `node --check` for both JS files; manual-path and library source contracts; the existing offline smoke tests where compatible. A full packaged JAR requires Maven and resolvable dependencies; do not interpret static checks as proof that the entire app compiles or runs on all supported operating systems.

---

# ELIYA23 browse and workspace indexing correction

This source update targets two separate regressions:

- **Folder chooser:** On Windows, Browse now opens the in-JVM Java Swing directory chooser (system look and feel) instead of launching a PowerShell/Windows Forms worker. macOS continues to use the native AWT directory chooser; Linux uses Zenity/KDialog where available and falls back to Swing when it has a desktop. A failed Browse no longer automatically opens a delayed JavaScript `window.prompt`; use the explicit **Enter path** button instead. Browse only works when the browser and ELIYA JVM are on the same computer. Initial GUI launch can still vary by OS/desktop; under a headless/server process use Enter path.
- **Source coverage:** The local retrieval index uses the previous full-text scanner's default **1,500,000-byte per-source-file** limit, supports its source/config/test extensions (including `.feature`, `.robot` and `.csv`), and walks up to 48 directory levels. Build/cache/VCS folders, unsafe secret files, unsupported files and oversized files remain excluded intentionally. Optional override: `-Deliya.index.maxFileBytes=...` (maximum 8,000,000). Office/PDF extraction has its separate `-Deliya.index.maxDocumentBytes=...` bound.
- **Index telemetry:** Workspace status includes scanned/indexed counts, oversized/unsupported/unreadable file counts, ignored directory count, and incomplete-scan status. Excluded directory contents are not included in visited-file counts; the displayed file count is eligible indexed files, not every filesystem entry.
- **Retrieval quality:** Match terms are derived from entire eligible plain-text source files (within the size limit), including late-file symbols and camelCase/underscore identifiers. Chat receives matching code plus surrounding lines rather than only an 8,000-character cached opening excerpt. Cached excerpts remain bounded, and LLM context is still limited: for full repository-wide analysis use Agent file tools. There is no guarantee of accurate answers without the relevant retrieved evidence.

**After installing:** Start ELIYA, select the same local project, then click **Rescan** and wait for the folder status to say Ready. Check the skipped-file breakdown before comparing the count with your older version. An exact previous count is not guaranteed if it included excluded folders, oversized files, unreadable content or a different root.

**Validation scope:** JS regression tests and isolated Java 17 compilation of the changed picker/index components were run; a synthetic 1,099-file index/retrieval smoke test passed. These are *not* a complete Maven/Spring Boot build or an on-device Windows/macOS GUI test, because the packaging environment has no Maven dependencies and cannot reach Maven Central. Build/run the full project in a Maven-enabled Java 17 environment with `mvn -Pfull-tests clean package` before distributing the JAR.

---

# Document-only workspaces

The local workspace index includes source code, text files and bounded text extraction
from `.docx`, `.pdf`, `.xlsx` and `.pptx`. When a workspace only contains Word
documents, the Workspace counter reports the indexed documents once background
indexing completes. The index stores a bounded text excerpt for Chat retrieval;
embedded diagrams, images and image-only scanned documents still require the
Agent's document/vision analysis and are not represented by indexed text characters.

The optional Java properties `eliya.index.maxDocumentBytes` (default: 8,000,000)
and `eliya.index.maxFileBytes` (default: 1,500,000) independently bound document
and source-code indexing. Files beyond their respective limits are skipped.
After upgrading an existing JAR, restart ELIYA and reselect the folder or use
the local workspace rescan action to rebuild the index.

<!-- Consolidated user guide and historical implementation/validation reports. The historical sections record results from different revisions; do not interpret them as proof that the latest source passed a full Maven build or live Jira test. -->

> **Single-document package:** All previous root-level Markdown documentation, validation reports and checksum manifests are consolidated below. The application source, tests and launch scripts are unchanged. Historical validation results may refer to earlier revisions; the complete Maven build and live Jira integration must be verified in your environment.

> **Enhancement source candidate:** This ZIP includes the optional two-model Vision/Agent architecture,
> local persistent document knowledge, native-MCP image interpretation and gated deletion approval with
> bounded rollback. It is **not a build-verified release**: the packaging environment could not access
> Maven Central. Read [ENHANCEMENT_IMPLEMENTATION_STATUS.md](#doc-enhancement-implementation-status)
> and [ENHANCEMENT_VALIDATION_REPORT.md](#doc-enhancement-validation-report) before building or running.
> In particular, deletion approval is not an OS-level sandbox for arbitrary scripts or remote side effects.

# ELIYA

Java 17 local coding/workspace assistant with two modes: **Chat** and **Agent**.

## Named reference folders in Chat and Agent

Use **Browse reference** or **Reference path**, choose a folder and give it a unique prompt name such as `LegacySelenium` or `Requirements`. The label is stored with the browser's shared reference selection and used in both Chat and Agent. The pencil icon renames a reference without reindexing. Names must start with a letter and use only letters, digits, underscores or hyphens, with a maximum of 40 characters. `workspace` is reserved.

Example prompt: "Compare `LegacySelenium` with the active project. Use `Requirements` to find missing tests, but change files only in my active project." Chat retrieves relevant snippets from the named references; when one or more names are mentioned, those references are prioritized over unmentioned references. In Agent with an active writable project, `resource_catalog` exposes each named reference under its lowercase tool alias (for example `@legacyselenium`) as a **read-only** resource. Names are aliases for the selected physical folders, not copies of those folders. References remain read-only through managed tools; arbitrary shell commands and external scripts are not fully sandboxed.

A Chat-only reference question does not require a writable project. Agent file access to selected local reference folders currently requires an active project for its workspace resource tools; Agent's external-only mode remains available separately for MCP/documents.

## What Agent mode does

Agent works directly on the user-selected local project. There is no temporary mirror or delayed apply phase.

1. Resolve the project path from the prompt/current project.
2. Discover project instructions, build metadata, resources, MCP/LSP status and a local retrieval index.
3. Use the single selected **Agent model** to create a structured sequential plan.
4. Show the plan for review/approval unless plan approval is disabled.
5. Lock the approved plan and execute exactly one active step at a time.
6. Read/search only the evidence needed for the active step, batch independent reads, and edit the live workspace.
7. For focused/normal tasks, defer compile/test/check/run until the final verification step unless an intermediate verifier is explicitly required.
8. For genuinely large tasks, switch on durable batching: inventory work items, process a bounded batch at a time, checkpoint risky batches, run cheap structural checks at batch boundaries, and keep failed items in a targeted recovery queue.
9. Require the latest changed workspace revision to pass a real verifier before successful completion.
10. Persist durable run/progress/work-item state; after an application restart, a new run for the same conversation/project inherits the interrupted large-task ledger.

The same selected Agent model owns planning, execution and verification reasoning. **There is no model fallback chain.** Chat has its own independently selected model.



## File-deletion approvals (Agent mode)

Open **Settings → Agent execution**. The option **Confirm file removal / destructive copy or move** is enabled by default (you can disable it explicitly). It is independent of plan approval, general tool permissions and **Auto-approve actions whose permission is set to Ask**.

When enabled, ELIYA shows a dedicated approval request listing the file paths affected by an explicit `delete`, `resource_delete`, a structured or OpenAI-style `apply_patch` deletion, `move` / `resource_move`, overwriting `copy` / `resource_copy`, or a `workspace_rollback` that would remove files. Select **Keep files / deny** or **Approve these file changes once**. There is no "allow for this run" option for file deletion. The backend rejects forged run-wide approval for these requests. If affected paths change while the user is reviewing, the operation requires fresh approval. Read-only tools and ordinary non-destructive edits are not interrupted.

Known destructive shell statements (e.g., `rm`, `del`, `Remove-Item`, `git clean`, `git reset --hard`) are rejected while protection is enabled; use explicit file tools instead. MCP tools with deletion-style names require a dedicated once-only confirmation. **Scope:** this is an application-level guard on ELIYA's built-in operations, not a filesystem sandbox. Build/test scripts, arbitrary spawned programs, indirect shell operations, and unknown external MCP tools may delete files internally without ELIYA identifying each path. For absolute protection, run such tools under OS-enforced filesystem isolation with read-only mounts or scoped permissions, or disable untrusted external execution.

The optional flag is sent as `agentConfirmFileDeletion` in ChatSettings requests; older clients that omit it default to **enabled**.

## Large task manager

ELIYA uses the existing fast execution path for small and medium work. Large-task orchestration is activated only when task scale is explicit (for example dozens/hundreds of cases), the request is broad framework/migration work, or repository evidence shows a wide change surface.

Large-task mode adds:

- a master sequential plan plus a separate durable **work-item ledger**
- default bounded batches (normally 8-10 items)
- workload-based progress such as `187/220 work items completed`
- `workspace_checkpoint` / `workspace_rollback` for risky batch boundaries
- cheap compile/type/static checks between meaningful batches rather than full regression after every edit
- automatic capture and deterministic clustering of verifier failure output
- failed-only recovery using `work_items_read(status=failed)` and `verification_failures`
- successful-completion gates that prevent a run from reporting success while pending/failed items or verifier failures remain
- durable work-item recovery after application restart
- a larger but still bounded active evidence preload for large tasks
- configurable repository-index limits through `eliya.index.maxFiles`, `eliya.index.maxScannedFiles`, and `eliya.index.maxFileBytes`

The selected Agent model remains a single model. Large-task management is runtime orchestration, not a multi-model fallback chain, so normal tasks do not incur the extra batching/checkpoint overhead.


## Speed design

The current runtime keeps the existing plan-first architecture while reducing unnecessary work:

- **Incremental retrieval-index refresh for direct edits.** `edit`, `write`, `copy`, `move`, `delete`, and `apply_patch` refresh only known changed paths instead of invalidating and rebuilding the whole workspace index.
- **Safe full invalidation for unknown shell mutations.** `bash`/resource commands can change arbitrary files, so a detected unknown shell mutation still invalidates the index for correctness.
- **Active-step evidence cache.** Retrieval hints plus bounded current-file evidence are reused while the active plan step and workspace revision are unchanged.
- **Parallel reads.** Independent read/search tool calls can run together before the next model turn.
- **Bounded context.** Old/oversized tool observations are pruned; durable plan/workspace facts are re-injected separately.
- **Plan-boundary checkpoints.** Oversized completed-step transcript history is compacted before the next plan step without forcing an extra model summary call in the normal case.
- **Deterministic final verification completion.** When the final approved step is the verification step and the latest revision passes a real verifier, the runtime closes that step directly instead of calling a completion critic.
- **No extra final completion-model round trip.** When all approved steps are complete and the latest workspace revision is verified, the runtime finishes from those deterministic facts.
- **Provider/model errors stop.** Authentication, unavailable model, rate/provider failures and other model/provider errors stop the Agent run instead of switching models or starting an expensive recovery replan.
- **One context-overflow recovery.** A genuine context-window overflow may compact once and retry the same selected Agent model. If it still fails, the run stops.
- **No-op aware editing.** An edit that already matches the workspace does not create a fake mutation revision.

These optimizations reduce latency without removing plan approval, sequential execution, live-workspace editing, or revision-aware verification.

## Error and recovery behavior

There are two different failure classes:

### Model/provider failure

The run stops immediately and preserves current workspace/run state. No alternate model is selected and no recovery replan is launched.

A context-window overflow is the single exception: the runtime may compact once and retry the **same** model.

### Coding/tool failure

Normal coding failures remain recoverable inside the active plan step. Examples include:

- compile/test failure caused by the current change
- stale exact-text edit
- wrong locator/path assumption
- command/tool schema mismatch that can be corrected locally
- non-actionable/duplicate model output while the provider itself is healthy

The agent can inspect the real error, change strategy and continue the same approved step. Productive work does not have a fixed step ceiling; no-progress guards prevent endless repetition.

## Context and token management

The live workspace and durable run state are authoritative; the full project is not resent every turn.

The runtime uses:

- provider/model context-window hints or configured per-model context values
- token estimation including tool schemas
- bounded tool-output history
- superseded runtime-steering cleanup
- durable objective/plan/revision/verification state outside chat history
- deterministic context checkpoints
- periodic semantic compaction only when useful
- one forced compaction attempt for context overflow
- local lexical retrieval plus bounded current-file evidence

Default recent-context and safety-buffer settings remain configurable in Settings.

## Planning and sequential execution

The selected Agent model receives live evidence and returns a structured plan. The harness checks that:

- the plan size matches the task profile
- each step contains validation evidence
- the final step is a dedicated compile/test/check/run verification phase

If the model returns structurally unusable plan output while the provider is healthy, a deterministic evidence-safe fallback plan may be used. A genuine provider/model call error does **not** trigger that fallback; the run stops.

After approval:

- only one step is `in_progress`
- later steps remain locked
- implementation steps advance from real tool/workspace evidence
- the final verification step cannot complete until the latest required workspace revision has passed a real verifier
- successful final verification can close the final step deterministically
- successful completion becomes 100%; blocked/failed/cancelled states do not masquerade as success

## Workspace retrieval

`WorkspaceRetrievalIndexService` maintains a local lexical index for relevant source/text files while skipping common build/vendor/cache directories.

Normal direct mutations update only changed entries. This is especially important for large Java automation repositories where repeatedly walking thousands of files after every edit adds avoidable latency.

The runtime still performs a full invalidation when a shell/resource command may have changed unknown paths.

## Tool execution

The compact default Agent surface includes workspace inspection, list/glob/grep/read tools, edit/write/patch, build/test/check/bash, workspace diff/status, TODO plan progress, resource tools, MCP/LSP discovery and targeted tool loading.

Multiple independent read-only calls may execute in parallel. Mutations remain ordered and are observed by the revision/verification state machine.

## Remote MCP (Jira / Confluence / DevOps tools)

ELIYA can now be configured once from **Settings → Remote MCP** and then reuse the existing generic MCP tool path automatically. No Jira- or Confluence-specific agent logic is added, so the current planning/execution architecture is unchanged.

For the ITG DevOps MCP shown in the supplied OpenCode configuration, enter:

```text
Connection name: itg-devops
Type: remote (handled by the UI)
Server URL: https://devops-itg.mcp.cib.echonet/
Timeout: 100000 ms
Headers as applicable:
  user-id
  jira-token
  confluence-token
  gitlab-token       (optional)
  sonarqube-token    (optional)
```

Use **Test connection & discover tools** to perform a real MCP initialize + `tools/list` exchange. A successful test shows the number and names of tools returned by the server. After saving, the same configuration is available to both Chat and Agent mode.

- **Chat mode** automatically activates a lightweight MCP tool loop for Jira/Confluence/GitLab/SonarQube-style requests and exposes only discovered read/search operations. Ordinary Chat prompts keep the existing streaming path. External write/update operations stay in Agent mode.
- **Agent mode with a workspace** keeps the existing workspace architecture and combines local files/tools with MCP and uploaded requirement documents. MCP schemas stay deferred and are loaded when needed through `tool_search`.
- **Agent mode without a workspace** is now valid for Jira/Confluence/MCP analysis and uploaded requirement-document work. It exposes MCP plus attachment read/search tools and never invents local workspace operations.
- A remembered workspace is not forced onto a clearly Jira/Confluence/document-only analysis request. If the prompt asks to inspect/implement/fix/migrate/compare against the project, the workspace remains active and the Agent can combine all sources.

Example prompts after configuration:

```text
Chat: Read Jira ABC-1234 and explain the acceptance criteria.

Agent (no workspace required): Read Jira ABC-1234 and the linked Confluence pages,
then produce an analysis report with risks, dependencies and missing requirements.

Agent (workspace + MCP + requirement document): Read Jira PAY-4582, its related Confluence documentation
and the attached requirement file. Compare them with the current Playwright workspace, identify missing
automation coverage, prepare the plan, and implement it after approval.

Agent write action: Add the final automation execution summary as a comment to Jira ABC-1234.
```

The ELIYA-managed MCP file is stored outside the project at:

```text
Windows: %USERPROFILE%\.eliya\mcp.json
Linux/macOS: ~/.eliya/mcp.json
```

Secret header values are never returned by the configuration API or inserted into model prompts. The Settings UI only reports whether a header is already configured; leaving a saved token field blank preserves the existing value. On POSIX filesystems ELIYA restricts the managed file to the current user when supported. Workspace `.agents/mcp.json` and `.opencode/mcp.json` files remain supported and continue to override user-level configuration by server name.

## Verification model

A workspace mutation increments the run mutation revision when the change requires verification. The runtime records verifier attempts against that revision.

A successful completion requires the latest required revision to be verified. Small changes should use the smallest high-signal verifier that proves the requested behavior; broad builds/tests are used when the scope requires them.

## UI

The main UI contains only **Chat** and **Agent** modes.

- Chat model and Agent model are selected independently.
- Agent uses one selected Chat/Agent-capable model for the whole task.
- Image understanding belongs to Chat mode; Agent remains focused on repository/tool work.
- Chat document attachments are extracted locally before the LLM call, so the selected provider does not need a native file-upload API. Supported readable formats include DOC/DOCX/DOCM, PDF with embedded text, XLS/XLSX/XLSM, PPT/PPTX/PPTM, RTF, OpenDocument files, TXT/Markdown/CSV/JSON/XML/HTML/YAML and common source/configuration files. HTML is parsed as document content (scripts/styles/raw tags are not sent as the page text).
- Current-message documents are always treated as direct context. If an older upload has no cached extraction, Chat automatically retries extraction before sending. If extraction still fails, the request stops with a clear application error instead of allowing the model to claim it cannot access the attachment.
- The attachment chip shows extraction readiness and extracted character count before the message is sent. Image-only/scanned PDFs require OCR and are reported as unreadable rather than silently guessed.
- Chat streaming coalesces tiny provider deltas for smoother rendering, understands standard SSE event/data framing, and keeps server generation independent from browser transport disconnects. The Stop button uses explicit Chat cancellation.
- Assistant messages and complete conversations can be downloaded as PDF; Markdown tables support rendered `<br>` line breaks in the UI.
- Office Open XML files (`.docx`, `.xlsx`, `.pptx`) are classified before generic XML/text handling, preventing binary ZIP containers from being decoded as UTF-8 text (the `Input length = 4` upload failure).
- Settings and model-library state are persisted when browser storage is available and fall back to in-memory state when storage is restricted.
- The Agent card displays plan progress, live activity, active step, verification and terminal state.
- **Clear history** deletes all chat and durable Agent-run history (including orphaned run journals) after confirmation while preserving model/API settings and the remembered active local workspace. Active/stale runs are tombstoned so they cannot recreate cleared history while unwinding.
- Workspace finalization is hash-based and binary-safe: a reporting/diff problem cannot turn an already completed execution into a false FAILED result.

## Durable data

Default per-user data location:

```text
Windows: %USERPROFILE%\.advanced-ai-workbench\
Linux/macOS: ~/.advanced-ai-workbench/
  data/
    chatdb.mv.db
    uploads/
    agent-cache/
    agent-runs/
  cache/
  logs/
```

Locations can be overridden with the existing application/system properties.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access on first use so the included wrapper can bootstrap Maven

Linux/macOS:

```bash
./mvnw clean package
java -jar target/eliya.jar
```

Windows:

```bat
mvnw.cmd clean package
java -jar target\eliya.jar
```

## Validation

The included validation scripts now run the full test suite by default.

Linux/macOS:

```bash
./validate-local.sh
```

Windows:

```bat
validate-local.bat
```

Validation performs:

1. Java availability
2. JavaScript syntax checks when Node is installed
3. Maven availability/bootstrap
4. clean package
5. `-Pfull-tests test`

For an explicitly fast local smoke check only:

```bash
FAST_VALIDATION=1 ./validate-local.sh
```

or on Windows:

```bat
set FAST_VALIDATION=1
validate-local.bat
```

Do not treat `FAST_VALIDATION=1` as a release/full validation.

## Source integrity

`SOURCE_MANIFEST_SHA256.txt` contains SHA-256 hashes for the shipped source/configuration files. It is regenerated only after final packaging changes so the manifest describes the actual package contents.

## Key source areas

```text
src/main/java/com/llmart/llm/service/AgentService.java
  orchestration, plan execution, context preparation, model-error behavior,
  completion gates, tool observation

src/main/java/com/llmart/llm/service/AgentRunService.java
  durable run state, sequential plan gate, mutation/verification revisions,
  progress and persistence

src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
  local lexical retrieval, full indexing and incremental changed-path refresh

src/main/java/com/llmart/llm/service/ContextWindowManager.java
  token estimation, pruning and compaction

src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
  OpenAI-compatible transport and tool/JSON/plain protocol compatibility

src/main/resources/static/app.js
src/main/resources/static/index.html
  Chat/Agent UI, settings, SSE progress and model selection
```

## Recommended performance comparison

When comparing this build with another coding agent on the same repository/model/task, record:

- total duration
- model-call count
- provider-reported input/output tokens
- number of retrieval/index rebuilds
- repeated read/search calls
- tool-action count
- time from final successful verifier to terminal completion
- whether the requested task actually completed correctly

The intended improvement is lower harness overhead and fewer redundant model turns **without reducing task-completion quality or verification safety**.


## Multimodal workspace knowledge and deletion approval (source preview)

This updated **source preview** provides independently editable Agentic and optional Vision
model inputs in Agent mode, plus a Workspace Knowledge panel for local DOCX, XLSX, PPTX,
PDF, text and image evidence. With the project selected, choose a compatible Agentic model,
optionally provide a Vision model/endpoint/key, then use **Analyse Workspace**. You can also
ask Agent mode to analyse relevant documents and then generate test cases from their indexed
requirements. Chat continues to use its own selected model.

When **Confirm file deletion** is enabled, ELIYA captures a bounded pre-execution source
snapshot, pauses for exact-file approval, and enforces a backend 60-second limit. Rejection
or timeout stops the run and attempts to restore tracked source files. The dialog includes
full resolved paths, file hashes and countdown. Keep `app.data-dir` outside all writable
workspaces. In protected mode, MCP tools that are not explicitly read-only are blocked.

**This is not an OS-enforced sandbox.** Arbitrary scripts/builds/test runners and external
processes may still have destructive side effects; excluded dependency/build trees and
external systems are not restored by the source snapshot. Review
[IMPLEMENTATION_STATUS.md](#doc-implementation-status) before enabling this on real projects.

Offline smoke checks can run with only JDK 17+ and Bash:

```bash
bash qa/offline-smoke/run.sh
bash qa/offline-smoke/vision.sh
```

With internet-enabled Maven 3.9+ and Java 17, run `validate-local.bat` on Windows or
`validate-local.sh` on macOS/Linux. The included GitHub Actions workflow runs all tests
(`-Pfull-tests`) and publishes `target/eliya.jar` **only if the complete Maven build succeeds**.

## Portable database (Windows, macOS, Linux)

ELIYA uses its own bundled H2 database and stores local application history in
`~/.advanced-ai-workbench/data/chatdb` by default. No Oracle database, external
JDBC driver or host-specific `SPRING_DATASOURCE_*` settings are required. The
same `target/eliya.jar` can be run using Java 17+ on each supported OS. For
architecture and validation details, see [PORTABLE_DATABASE_FIX.md](#doc-portable-database-fix).

---

## Consolidated implementation and validation notes

The following records are retained for traceability. Use the main guide above for everyday setup and operation.

- [AGENTSERVICE_FIX_NOTES.md](#doc-agentservice-fix-notes)
- [BASELINE_SOURCE_MANIFEST_SHA256.txt](#doc-baseline-source-manifest-sha256)
- [BASELINE_VALIDATION_REPORT.txt](#doc-baseline-validation-report)
- [BROWSE_AND_INDEX_HANG_FIX.md](#doc-browse-and-index-hang-fix)
- [BROWSE_PATH_ERROR_FIX.md](#doc-browse-path-error-fix)
- [COMPILE_FIX_VALIDATION_REPORT.md](#doc-compile-fix-validation-report)
- [DOCUMENTATION_INTELLIGENCE_SOURCE_SHA256.txt](#doc-documentation-intelligence-source-sha256)
- [DOCUMENTATION_INTELLIGENCE_VALIDATION_REPORT.md](#doc-documentation-intelligence-validation-report)
- [ENHANCEMENT_IMPLEMENTATION_STATUS.md](#doc-enhancement-implementation-status)
- [ENHANCEMENT_SOURCE_SHA256.txt](#doc-enhancement-source-sha256)
- [ENHANCEMENT_VALIDATION_REPORT.md](#doc-enhancement-validation-report)
- [FOLDER_PICKER_STARTUP_PERFORMANCE_FIX.md](#doc-folder-picker-startup-performance-fix)
- [IMPLEMENTATION_STATUS.md](#doc-implementation-status)
- [MCP_CHAT_JIRA_TICKETS_FIX.md](#doc-mcp-chat-jira-tickets-fix)
- [MCP_CHAT_JQL_RECOVERY_FIX.md](#doc-mcp-chat-jql-recovery-fix)
- [MCP_CHAT_PERFORMANCE_FIX.md](#doc-mcp-chat-performance-fix)
- [NAMED_REFERENCES_IMPLEMENTATION.md](#doc-named-references-implementation)
- [PORTABLE_DATABASE_FIX.md](#doc-portable-database-fix)
- [PORTABLE_DATABASE_VALIDATION_REPORT.md](#doc-portable-database-validation-report)
- [SHARED_FOLDERS_IMPLEMENTATION_AND_VALIDATION.md](#doc-shared-folders-implementation-and-validation)
- [SPRING_STARTUP_BOOT_FIX.md](#doc-spring-startup-boot-fix)
- [WORKSPACE_CHAT_OVERVIEW_FIX.md](#doc-workspace-chat-overview-fix)


---

<a id="doc-agentservice-fix-notes"></a>
### AGENTSERVICE_FIX_NOTES.md

#### AgentService.java targeted repair (source candidate)

##### Confirmed Java 17 compilation defect

In `AgentService.run`, the `onStep` parameter was reassigned to wrap the original event handler, and then the newly introduced document-analysis progress lambda captured `onStep`. Java requires captured local variables to be final or effectively final. The former source could therefore fail with:

`local variables referenced from a lambda expression must be final or effectively final`

**Repair:** Capture a final alias, `documentProgress`, immediately before invoking `workspaceKnowledge.analyse(...)` and use that alias from the callback. Existing logging and UI forwarding are preserved; no execution logic was changed.

##### Completed limited checks

- JDK compiler API parsed all project Java files with `--release 17` (syntax check only).
- `bash qa/offline-smoke/run.sh` passed: isolated approval and rollback tests.
- `bash qa/offline-smoke/vision.sh` passed: isolated Vision adapter tests.
- `python3 qa/offline-smoke/ui-contract.py` passed 11 static UI/API contracts.
- JavaScript source syntax checks passed.

**Release status: NOT VERIFIED.** Full Maven compilation/type checking, full JUnit regression, live MCP/LLM calls, full protected Agent run and executable JAR generation have not been performed. The environment does not contain Maven/dependency cache. Other integration defects may remain. Keep deletion approval enabled only for disposable test workspaces until end-to-end security validation is complete.

---

<a id="doc-baseline-source-manifest-sha256"></a>
### BASELINE_SOURCE_MANIFEST_SHA256.txt

```text
5b4a645d4d4e12d5dcd497b0f09880ae6c1b4c97e4e85a58c6bc3e90d276ef12  ./README.md
189db9fb67ebe177e1aa0c472560245edaa8a7bd8b26045cb6bf98353f105f36  ./VALIDATION_REPORT.txt
93539789c63c440e59975faca25882f7f788e11344101e4c2678dfecca009238  ./mvnw
3d17e93ded0a41bcca8481de2cbfcbc2632ed364fb1f194eee4e2041c53c659d  ./mvnw.cmd
96220216e35ef65a6ec8a0d71015358e702318586fb0caaf8e0814492a239132  ./pom.xml
dd4b5681119d497f642d018324d20572b18cc94c94dd6b0cf51177615ed9806e  ./run.bat
6aceeb9f78f93087f9aa96c3644b346a265a105d24824c1aa8503517a103c3b4  ./run.sh
2c403a73bc273d47599c924364242e2828e8c609e3fa8df42ff54e44519c9496  ./src/main/java/com/llmart/llm/LlmApplication.java
f98caed7fe3cf4e26243a05a15f85dc88c965da4c7ef99686ab0cdfb9a44f6ea  ./src/main/java/com/llmart/llm/config/AppConfig.java
4483942ecd270565915509e1047fb8c2746e05ebed71a11bbae759ba651b9ee8  ./src/main/java/com/llmart/llm/config/AppPathResolver.java
b8a150b77d41e58798dcb833fcd726ab090c4460f640afd3d5019d08f07abf0c  ./src/main/java/com/llmart/llm/controller/AgentController.java
d629b0cf5675076db789c6675427893cd168414c57eda65f18405975c73bdd7a  ./src/main/java/com/llmart/llm/controller/ApiExceptionHandler.java
191114edbd1ea0b15233acd90bc200756a586e94891d1314fc9768238945043b  ./src/main/java/com/llmart/llm/controller/ArtifactController.java
42817f58cad56971356ee6410b371ba5cbad8e031efcd7fcb7c9fa0c0d865114  ./src/main/java/com/llmart/llm/controller/ChatController.java
0bbeefa929d4edf018dee8b9fa760898489a6431ac9d02ecf2cdda329a12d2f8  ./src/main/java/com/llmart/llm/controller/ConversationController.java
d7cd3e63906d79e24d52b7f35d8cd02a2909a1b76476fccd596db41796ce2406  ./src/main/java/com/llmart/llm/controller/FileController.java
21790b2233638fdcfdf2cfa3e448fe95b83fae258c068a226c48dae804803110  ./src/main/java/com/llmart/llm/controller/McpController.java
aab1e04c1cd617baf6642f71c398d6f8b85ef81d7c752222e4d255079ecc743b  ./src/main/java/com/llmart/llm/controller/ProjectController.java
e4fdc0e778ea4c057aaa013c7e3d5e73ebafe96fdd53002206c444afc15dbbe8  ./src/main/java/com/llmart/llm/dto/ChatMode.java
31f91f8b1db0b25b2e729ee73b8f957b6a705128043fb58025cc13b5597e5368  ./src/main/java/com/llmart/llm/dto/ChatRequest.java
56489ef8f582ad5f45cc71a6efe597b6614adefd57e7556691628cb4ce105c5d  ./src/main/java/com/llmart/llm/dto/ChatSettings.java
f0c7333b2fb95deed8ddc01075a1e3ac24a8a5e95cdda34300dae68b85dd73ed  ./src/main/java/com/llmart/llm/dto/ConversationDto.java
e160b0f6ad25188d29e8099afd1e6cf156d2aa4287f40d8e49eef541a9744972  ./src/main/java/com/llmart/llm/dto/ExcelExportRequest.java
5f47845cefca0a28ed0bb8f06cfdeb0135d0fbf92362b1980717a858836ee748  ./src/main/java/com/llmart/llm/dto/FileDto.java
0a085ea11600c0bc0f416baea45aeea8be381bb6b1a249856c1e6464db2c8da7  ./src/main/java/com/llmart/llm/dto/MessageDto.java
cec82cb0383d649d80bb74d2b06b1f4f2f11176d004081725a24f83f598b29bb  ./src/main/java/com/llmart/llm/dto/ProjectDto.java
705cf8c8dc327cade691c2b052bd4193adfeacd4397e171a50d3917e9ca3ce19  ./src/main/java/com/llmart/llm/dto/ProjectFileUpload.java
f98338bbb8d25319cbb145c0c17c832465db6b765ad535ec3d85d76b9303770d  ./src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java
2544fa42101de0dcfe295d22ce8af9dd0f3b0fa74d3f98444cf9e1ce7db848f2  ./src/main/java/com/llmart/llm/dto/ProjectUploadBatch.java
f51e077cb1a56c1cef2450508ed51f7bcb1ff554b6dffad72437b015a19ae2f4  ./src/main/java/com/llmart/llm/entity/ConversationEntity.java
b7ad960ed9f989934525b0794e499ec44008444774b3b782bb4669b5a7630bd9  ./src/main/java/com/llmart/llm/entity/FileEntity.java
2c53591fbcff3a40a470e56509d081d7a2ca6f3151ddecd70ac3bb5ab1c175fd  ./src/main/java/com/llmart/llm/entity/MessageEntity.java
0228201d2cca02a2a595c6dd561866cc51f9597d9ac78eff3b7b45e79c42f3c4  ./src/main/java/com/llmart/llm/entity/ProjectFileEntity.java
debbb80abe56f4d579d2a7316fb6eee1b4b7987dd36167929c77842715af6ac0  ./src/main/java/com/llmart/llm/entity/ProjectWorkspaceEntity.java
25d60a8159ba948454fe32b59efefdf55ce843d479c44438871533f724224bf3  ./src/main/java/com/llmart/llm/repository/ConversationRepository.java
5fd45a03590d5f0a1405a53fc06012ca79e1cd9afd9a373b40e8ca17b11bb391  ./src/main/java/com/llmart/llm/repository/FileRepository.java
fdcf2534462418c948b371a6a8a3083851e433e427dfb647086df547235ee0ac  ./src/main/java/com/llmart/llm/repository/MessageRepository.java
fcb3c920cf0419feb867370102213e9a53c15e56553977c6aece9c129668c449  ./src/main/java/com/llmart/llm/repository/ProjectFileRepository.java
495e3301684c69de86425ee38a3e66071f73fa428840235d08a3c7cdb6e0f451  ./src/main/java/com/llmart/llm/repository/ProjectWorkspaceRepository.java
288928b164e864549e83cad60873fb5739497a08eb3365918236f1606cab2a04  ./src/main/java/com/llmart/llm/service/AgentApprovalService.java
3e8248a5f3fdb28b6e62238666e23ef01c7a61dcaf2ca00a90de768e3bb033af  ./src/main/java/com/llmart/llm/service/AgentCancelledException.java
ee957dbb1d2cfa62aa9494f50a3b5b8df491741f7a82f3be3b022c1b6f36bb14  ./src/main/java/com/llmart/llm/service/AgentDeletionCommandGuard.java
919d89344d2c658a0051ae4bdd3707a104b70326bfa18e411c8c2499b90dc861  ./src/main/java/com/llmart/llm/service/AgentProfileService.java
a32382ecc4ba4186ddd148ca34d3503abb554987c6b95efc2d8e84aaa9a0260d  ./src/main/java/com/llmart/llm/service/AgentRunService.java
bdf531621577e4102398db67b2350bb57a1cf7b60b2ac2121341a9e870e12ffe  ./src/main/java/com/llmart/llm/service/AgentService.java
f64a111adafb62f7b816516b21bcd5d24b747b8ac18ed52df4e2e04e1cb8e09e  ./src/main/java/com/llmart/llm/service/AgentToolRegistry.java
e8e72fbe24718e15a7470797174ac75f46c8e85fe1bb1a1a8d8e1b05442922ae  ./src/main/java/com/llmart/llm/service/AgentWorkspaceService.java
34840a115035d6010dff553fae3a2ec39780fc6fc81e5c23f7dd511c21c2369e  ./src/main/java/com/llmart/llm/service/BoundedCommandOutput.java
97376b4e701358d644b4a10c14013a46262466147daf327b69782d44f48ddee3  ./src/main/java/com/llmart/llm/service/ChatMcpService.java
1094a8df62956cb03ae755022dedee745e41842f15017c438a4e93b7585b48df  ./src/main/java/com/llmart/llm/service/ChatService.java
d595627446c08dc3734b537c6a782d971d678ae059cb22ab6a4d8ffd475dcdaf  ./src/main/java/com/llmart/llm/service/ContextService.java
cf3094079f586605b99c0ac69b32dfd5e94f9db3548d14fe229f8e988a19eb2c  ./src/main/java/com/llmart/llm/service/ContextWindowManager.java
3410f8e203964d35eb4f8bd35a23362d749b31bf1338074f2a6850341f65f030  ./src/main/java/com/llmart/llm/service/ConversationService.java
1f78301634fa731dc1edeb2bf599d2ab4f0420e5f1920446ce75294df6c77014  ./src/main/java/com/llmart/llm/service/ExcelExportService.java
470006657b3ff82c53ffb0538802c4d241ddecfcfb70b372518b98216131410d  ./src/main/java/com/llmart/llm/service/FileContextSelector.java
3d243338b348bfb3d96488f2b560466eea86d3b27d462e04dc519f3431c4d253  ./src/main/java/com/llmart/llm/service/FileService.java
32a27a6c98c883d6295f9fdf343fa1a08d43bb9d97b941a4e157bac1a8b4b69c  ./src/main/java/com/llmart/llm/service/Hashing.java
4a6f9e046a8ed6c6d4207c82753f13e1c493443dd142e8e527e2a4da06253894  ./src/main/java/com/llmart/llm/service/ImageUnderstandingService.java
3eba882df30b9028f45a86827c1d8804e62bcc430edb9e48f4440e16494e3059  ./src/main/java/com/llmart/llm/service/LspManager.java
fd9fee464c1a8ab31ac6d241cbeed0b256e71e7f498a67fd83524ba7e8a3b731  ./src/main/java/com/llmart/llm/service/McpManager.java
1ca55beb403eca4f0c29045ebf3b16a6bef00538dce50ab4f1d2e173e7136dc8  ./src/main/java/com/llmart/llm/service/ModelCapabilityRegistry.java
ea8106eb7b93cf0cd81ca6eec3ac0c983c83edfd2e5d6c25ebb77b514843f851  ./src/main/java/com/llmart/llm/service/ModelProbeService.java
c9816ad48954c3b34058ce5c9dee73914b11f17147783f9431887f80cf45ff8c  ./src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
5506f9b6ce057acfacbee93f10cd5dcd2e915211c40870bec088b6e7d9b9bbdc  ./src/main/java/com/llmart/llm/service/PatchConflictException.java
45be1b8fe7db6f4a56c5ea545976e5dfacb36ebe32181cf17c4823490993c039  ./src/main/java/com/llmart/llm/service/PdfExportService.java
edba4f4e0dcd1406695472b06276acca1ab0d06bc43e3ee4e80acd989b97b214  ./src/main/java/com/llmart/llm/service/ProjectContextService.java
17d2f3e421a6daf46805f09adefc35c3ed8c3a4c56636a90a95f10cdbb90c791  ./src/main/java/com/llmart/llm/service/ProjectPatchService.java
ef05e2a132b2dcf31ee523d1dbe84086c94bd997a8de7c9e46fb4968d57f3d32  ./src/main/java/com/llmart/llm/service/ProjectService.java
21a592a642c1cdfe383c24dc8df123cd822f771a92d1f4921406f239ed1bf216  ./src/main/java/com/llmart/llm/service/PromptResourceResolver.java
3b868b3ae99cb49cbf6506c4eb38678d6135af81df7cbaab44d51f5af5fe6e24  ./src/main/java/com/llmart/llm/service/WorkspaceProfileService.java
8e177fd79e9058428caa867c6df21cc8c3096307babe9ab28c93f8080dcbb33a  ./src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
4ebb0fff90e98c3334cd1984a6648fdeb2317ab563631f04d477adac4d91efc9  ./src/main/resources/application.properties
4741420a64ae7ae20e34a7baa5ca2e2e217b2546ed38d0f097b4b4faee2da662  ./src/main/resources/static/app.css
d6d13d6ea2cbbdcfa1ec5471505e1468e585222cf3543f85cc79cc6d7eb30119  ./src/main/resources/static/app.js
bb9de8f6a65557a31bd6020f02ab89236994cd11df8a53bf6e7a9a8e06480096  ./src/main/resources/static/index.html
7ee02bd43edc472a77f2bfa1c3c8a9942b80199a0e6af83bc9b6342040172053  ./src/main/resources/static/markdown.js
75adcf15944400667cc446e0f6eb1199ae596f9f36bd7d4395b3519c71cf7d71  ./src/test/java/com/llmart/llm/controller/ConversationControllerHistoryTest.java
b00eb46a2f7d423713b13370b93e292de798554c723a6b7ffe618273f5f26993  ./src/test/java/com/llmart/llm/dto/ProjectPatchRequestTest.java
bac5dbda43bec46f9558a4775b0d915866160bb41ed6202d09baf9a2f3b8ce46  ./src/test/java/com/llmart/llm/service/AgentFileDeletionApprovalTest.java
084dd015af757cc8438e0cc8f7b8d1e8d455dd66facd7aea4f1043c2629d8875  ./src/test/java/com/llmart/llm/service/AgentRunServiceHistoryTest.java
4fa2e52567976692ec149de6b8c8ee4c7720282992fee6ffbb28b6914b4f9b6e  ./src/test/java/com/llmart/llm/service/AgentRunServiceTest.java
317dffb067a402c95ec2f226276eb15dd271fec92d6b65ad01071891e20e54de  ./src/test/java/com/llmart/llm/service/AgentServiceCompatibilityTest.java
7c4d30f23a5b705e5009590a26e4d51290dccbfa316db80191a5fec114df5d7c  ./src/test/java/com/llmart/llm/service/AgentToolRegistryTest.java
401e5f8085619412b405cfbcdde23026aafc2b7f17772b8977567efe2056d44a  ./src/test/java/com/llmart/llm/service/AgentWorkspaceServiceCommandExecutionTest.java
4238d28faa0f18b2f06528a548bdd1f0bae24741f0342a9e11a208de277291e3  ./src/test/java/com/llmart/llm/service/AgentWorkspaceServiceMultiResourceTest.java
a95f74eea29ffe7d649f0a6286239adf25c27dcebaababa453b662b7064c046b  ./src/test/java/com/llmart/llm/service/BoundedCommandOutputTest.java
dd8004b0f7028c8238088b2982c63169f4f0618a82ac14cced9d593e76ff9b2a  ./src/test/java/com/llmart/llm/service/ChatMcpServiceTest.java
5ab705c7ba73ea08b43aea06f4a65796522d47e320dd8ac9b0fbedf951c4933d  ./src/test/java/com/llmart/llm/service/ChatServiceWorkspaceRoutingTest.java
4b065f59209af14ba7887a7c46899dd6c876bc97a5dc6c2bb58009946b5bc5af  ./src/test/java/com/llmart/llm/service/ContextWindowManagerTest.java
2e97b66b47b578a5ced6f75d97555d327310b170317a8ffd72c095a17da48275  ./src/test/java/com/llmart/llm/service/FileServiceDocumentExtractionTest.java
2d3aaf8de13dddd5e3fe1d3129cf7091a365f679432f3cde34839fb4e553b69e  ./src/test/java/com/llmart/llm/service/HashingTest.java
9792921140530da6f3fb720af49c9772700f81c3d63d7507749be86f1f191152  ./src/test/java/com/llmart/llm/service/McpManagerManualConfigTest.java
3a7f382b556e2344ba8dfc6a2be880e59c0d0f6b9d5640fa54fb31ba924c90b7  ./src/test/java/com/llmart/llm/service/ModelCapabilityRegistryTest.java
4d356be0b0c8172ca49c6a0afe9287c3ec6b44fa7df4acefa265959ff8388c0d  ./src/test/java/com/llmart/llm/service/OpenAiCompatibleClientCapabilityTest.java
e7164948694f75e9f70f41d8024c60e375a08e4ef1091657b4698770ac33d6d0  ./src/test/java/com/llmart/llm/service/PdfExportServiceTest.java
a89c5365fb98c5bf1a91e252a887cb48d635269205dbf01f0c0f0418fc961573  ./src/test/java/com/llmart/llm/service/ProjectPatchServiceTest.java
a9704f18ddc8ed7d76153f6629f388b1dc01b1082134e2d932b7ead89b1fddeb  ./src/test/java/com/llmart/llm/service/PromptResourceResolverTest.java
15d092f2b4819cdacc7f0f7eb0617aa543c33a706f1fc1c01cd997b527d11613  ./validate-local.bat
6f2ed384a09ba1011f561ebc8afbe927dad0063c24039b3254ba6cc685c2b698  ./validate-local.sh
```

---

<a id="doc-baseline-validation-report"></a>
### BASELINE_VALIDATION_REPORT.txt

```text
ELIYA - File Deletion Permission Guard Update
Validation date: 2026-09-25

Changes inspected
-----------------
- Existing Agent edit permission covered delete/apply_patch alongside normal edits. It defaulted to Allow,
  the permission controls were hidden, and an Ask grant could be auto-approved or allowed for an entire run.
- Added independent opt-in/out deletion guard, enabled by default, with a visible Settings checkbox.
- Added exact-path/version read-only preflight for direct delete, resource_delete, patch deletions, move,
  copy-with-overwrite and file removal during checkpoint rollback.
- Added once-only backend approval that cannot be converted into an allow-for-this-run grant,
  including via forged HTTP action=run requests.
- Prevented obvious destructive shell syntax from bypassing the explicit-file approval path.
- Added dedicated per-operation approval buttons and a polling/reconnect-safe UI fallback.
- Added focused JUnit coverage and usage guidance in README.md.

Validation performed for this new change
----------------------------------------
PASS - node --check src/main/resources/static/app.js.
PASS - Java 17 standalone compilation of AgentDeletionCommandGuard.java.
PASS - Java 17 standalone compilation of actual AgentApprovalService.java using minimal framework/run stubs.
PASS - Java 17 standalone compilation of actual ChatSettings.java + ModelCapabilityRegistry.java with annotation stub.
PASS - 8 command-classifier smoke assertions (known deletes and harmless commands).
PASS - 6 approval-service smoke assertions (run-wide grant denied for deletion, allowed for normal approvals).
PASS - 2 ChatSettings reflection assertions (missing flag defaults enabled; explicit false disables).
ADDED (NOT EXECUTED) - AgentFileDeletionApprovalTest.java JUnit regression tests for file preflight,
  patches, copy/move impact, shell guard and approval semantics.
NOT RUN - Full Maven compilation / Spring integration suite. Maven/dependency bootstrap needs
  access to repo.maven.apache.org, which is not resolvable in this execution environment.

Limits
------
This is a guard for ELIYA-built-in mutations and obvious destructive shell syntax, not an OS-enforced
sandbox. Scripts/builds/test runners and external MCP implementations can remove files internally,
which cannot be fully predicted or intercepted by an application-level file-tool preflight.

================ PREVIOUS RELEASE VALIDATION (BEFORE THIS CHANGE) ================

ELIYA - Chat Stability, HTML Parsing, Streaming and PDF Export Patch
Validation date: 2026-09-22

Implemented
-----------
1. Chat/Agent transport stability
   - Browser/SSE timeout, completion or network disconnect no longer cancels an active Agent run.
   - Chat generation is also independent from an accidental browser/SSE disconnect and can finish/persist server-side.
   - The Chat Stop button now uses an explicit /api/chat/cancel endpoint, so user cancellation is distinct from network failure.
   - Partial Chat output is retained when the user explicitly stops generation.
   - Frontend attempts to recover a persisted Chat response after a transport interruption.

2. Smoother and more tolerant Chat streaming
   - Small provider deltas are coalesced before browser delivery to reduce excessive SSE/UI churn.
   - OpenAI-compatible SSE parsing now handles event/id/comment/keep-alive lines, multi-line data payloads, [DONE], provider error events and newline-delimited JSON gateways.
   - Provider generation is no longer aborted merely because an SSE send to the browser fails.

3. Markdown table <br> rendering
   - <br>, <br/> and <br /> generated inside Markdown table cells render as actual line breaks.
   - Only the safe BR tag is preserved; other raw HTML is still escaped by the Markdown renderer.

4. HTML attachment parsing
   - .html/.htm, text/html and XHTML uploads are routed through Apache Tika document parsing instead of Files.readString(...).
   - This prevents raw HTML markup/scripts/styles from being treated as the document body sent to Chat.
   - A regression test was added for HTML extraction behavior.

5. PDF download
   - Added per-assistant-message PDF download.
   - Added full-conversation PDF export beside Markdown and JSON.
   - PDF generation is local and dependency-free (no cloud PDF service and no new Maven dependency).
   - Export supports headings, paragraphs, code/table-like monospaced lines and multipage A4 output.

Validation performed
--------------------
PASS - JavaScript syntax: node --check src/main/resources/static/app.js
PASS - JavaScript syntax: node --check src/main/resources/static/markdown.js
PASS - Functional Markdown renderer check: table cell `one<br>two` renders with a real <br> and is not escaped as &lt;br&gt;.
PASS - Standalone Java compile of PdfExportService using minimal local framework/DTO stubs.
PASS - PDF generation smoke test: valid %PDF-1.4 output generated.
PASS - pdfinfo validation: 1-page A4 PDF, PDF 1.4, not encrypted.
PASS - PDF render verification using /home/oai/skills/pdfs/scripts/render_pdf.py; rendered PNG inspected successfully.
PASS - Java grammar/syntax screening of all modified Java sources with javac parse stage; no grammar errors detected.
PASS - Source-level verification that HTML detection is evaluated before generic plain-text handling and HTML was removed from the plain-text extension path.
ADDED - FileServiceDocumentExtractionTest HTML regression test.
ADDED - PdfExportServiceTest PDF regression test.

Full Maven build limitation in this validation container
--------------------------------------------------------
The bundled validator attempted to bootstrap Apache Maven 3.9.11, but this container cannot resolve
repo.maven.apache.org. Exact environment error: `curl: (6) Could not resolve host: repo.maven.apache.org`.
Therefore the full Spring Boot package and JUnit suite could not be executed here, and this report does not claim
that they were. Run `validate-local.bat` or `validate-local.sh` on a machine with Maven/dependency access for the
complete dependency build/test suite.


6. Visible backend/connection status for Agent runs
   - Added a persistent Agent runtime status panel showing Backend, Connection, Current step, Last backend activity and Run ID.
   - Successful /api/agent/runs/{runId} polls mark the backend reachable and keep status/activity current.
   - A frontend SSE/network break now keeps durable backend polling alive instead of stopping the watcher.
   - While detached, the UI shows `Stream disconnected · polling backend`; the Stop button still targets the active backend run.
   - Transient status-endpoint failures are shown separately from stream disconnects.
   - SSE application/server errors are explicitly distinguished from transport/network failures so real agent errors are not mislabeled as network issues.
   - Any backend `finishedAt` state is treated as terminal even if the final assistant response could not be persisted, preventing endless frontend polling.
   - Historical Agent runs show persisted backend state when reopened.

Additional validation for backend status patch
----------------------------------------------
PASS - node --check src/main/resources/static/app.js
PASS - tinycss2 parse of src/main/resources/static/app.css: 0 CSS parse errors.
PASS - Static invariant checks for all five status-panel fields.
PASS - Durable run polling endpoint remains wired to /api/agent/runs/{runId}.
PASS - Network-detach path preserves the Agent watcher and active run id.
PASS - Explicit Stop path still calls /api/agent/runs/{runId}/cancel.
PASS - Server SSE error events are tagged and excluded from transport-failure recovery.
PASS - Backend finishedAt is authoritative for stopping the watcher.
PARTIAL - validate-local.sh passes Java availability and frontend syntax, then cannot bootstrap Maven because this container cannot resolve repo.maven.apache.org.


7. Generic workspace-finalization false-failure fix + Clear history
-----------------------------------------------------------------
Implemented:
- Agent runs now capture a run-start SHA-256 byte baseline for the workspace (skipping dependency/build/VCS directories already excluded by the agent). Filesystem watcher events are treated as activity only; final change state is determined by current bytes versus the run-start hash.
- A file touched and later restored to its run-start bytes is no longer reported as a final modification.
- Workspace finalization never blindly decodes arbitrary touched files as UTF-8. Binary, malformed UTF-8, and files larger than the bounded text-reporting threshold stay hash-tracked while their text diff is omitted.
- Execution/verification outcome is authoritative. Workspace diff/change-summary/report-decoration failures are non-fatal reporting warnings and cannot turn a successful execution into a false FAILED result.
- The SSE terminal error path no longer calls completeWithError after text/event-stream has been committed; it emits the SSE error event when possible and completes the stream safely. This prevents the secondary HttpMessageNotWritableException/LinkedHashMap converter failure seen in the screenshot.
- Added a visible Clear history button in the sidebar with confirmation. It clears conversations plus durable Agent-run history but keeps model/API settings and the remembered local workspace.
- Clear-history backend also removes orphaned run files and tombstones deleted run ids so an already-unwinding worker cannot recreate cleared .properties/.events files.
- Single-chat deletion also removes that chat's durable Agent-run history.

Regression coverage added:
- Git cleanup matching the reported command (`git reset HEAD && git restore . && git clean -fd`) with tracked text, invalid-UTF-8/binary content and an untracked file.
- Touched-then-restored file produces zero final delta when final bytes equal the run-start bytes.
- Per-conversation durable Agent-run history deletion.
- Full history clearing, including orphaned on-disk run history.
- Conversation clear-history controller behavior.

Additional validation performed:
PASS - node --check src/main/resources/static/app.js
PASS - node --check src/main/resources/static/markdown.js
PASS - tinycss2 parse of src/main/resources/static/app.css: 0 CSS parse errors.
PASS - Static invariants for run-start hashing, bounded safe text reads, non-fatal finalization, safe SSE completion, Clear-history endpoint/button and persistence tombstones.
PASS - Source check confirms ChatService contains no completeWithError call in the committed SSE path.
PASS - Standalone Java 17 compile + executable smoke test of AgentRunService clear-history logic using a minimal Spring annotation stub: loaded runs and an orphaned run were removed, and a stale run object could not recreate its history after clear.
PASS - Java 17 grammar/syntax screening of all Java files modified by this patch: 0 grammar-pattern errors. Unresolved dependency symbols are expected because the Maven dependency classpath is unavailable in this container.

Full Maven/JUnit limitation:
The full `./mvnw -Pfull-tests test` attempt could not bootstrap Maven because this validation container cannot resolve repo.maven.apache.org. Exact error: `curl: (6) Could not resolve host: repo.maven.apache.org`. Therefore this package does not claim that the full Maven/JUnit suite ran here. The added regression tests are included and should run through `validate-local.sh` / `validate-local.bat` on a machine with Maven/dependency access.


8. Manual Remote MCP Configuration (Jira / Confluence / DevOps)
---------------------------------------------------------------
Validation date: 2026-09-23

Implemented:
- Added a Settings → Remote MCP section. Users can configure a remote MCP URL, connection name,
  timeout and the ITG DevOps headers: user-id, jira-token, confluence-token, gitlab-token and
  sonarqube-token.
- Added Test connection & discover tools. The test performs a real MCP initialize + initialized
  notification + tools/list discovery and reports connection/tool-discovery status without exposing
  saved header values.
- Added a Clear MCP configuration action.
- Added a user-level ELIYA-managed MCP file at ~/.eliya/mcp.json (Windows: %USERPROFILE%\.eliya\mcp.json).
  This stays outside the workspace and is merged into the existing MCP discovery pipeline.
- Existing workspace .agents/mcp.json and .opencode/mcp.json support remains unchanged and retains
  higher precedence by server name.
- Extended generic remote MCP parsing to support HTTP headers, so OpenCode-style `type: remote`,
  `headers` and `timeout` (milliseconds) configurations work correctly.
- Preserved backward compatibility for existing `timeoutSeconds` configurations by converting them
  to milliseconds internally.
- Remote MCP headers are sent on initialize, notifications, tools/list and tools/call requests.
- MCP configuration changes invalidate/close cached sessions so changed tokens/URL are used by the
  very next Agent run; application restart is not required.
- Saved secret values are not returned by /api/mcp/config. Blank token fields preserve existing
  values, preventing Settings from accidentally erasing credentials. HTTP MCP error text is also
  redacted against configured secret values before being surfaced.
- POSIX file permissions are restricted to owner read/write when supported.
- No Jira/Confluence-specific logic was added to AgentService. The existing McpManager catalog,
  deferred tool_search mechanism and normal MCP tool execution path are reused, so the current
  plan/approval/execution/verification architecture is preserved.
- Added McpManagerManualConfigTest covering user-level persistence, secret non-exposure, preservation
  of saved token values, custom-header forwarding, live MCP tool discovery and injection into the
  existing dynamic MCP catalog.

Validation performed in this container:
PASS - node --check src/main/resources/static/app.js
PASS - tinycss2 parse of src/main/resources/static/app.css: 0 CSS parse errors.
PASS - HTML ID/static wiring check for all new MCP settings controls; no duplicate IDs and no
       unexpected unresolved direct element references.
PASS - pom.xml XML parse.
PASS - Secret-leak static scan: no test credential values are present in shipped main source/docs.
PASS - Java 17 javac compile of the modified MCP manager, new MCP controller and new MCP regression
       test against minimal API/framework stubs. This validates Java-17 syntax and the modified
       class contracts without requiring the unavailable Maven dependency classpath.
PASS - Source-diff scope check: AgentService, AgentRunService, workspace execution, model routing and
       other existing architecture files are byte-for-byte unchanged from ELIYA07. Only MCP manager,
       MCP controller, MCP regression test, Settings UI/CSS/JS and documentation were changed.
PASS - validate-local.sh reached Java and frontend validation successfully before Maven bootstrap.

Full Maven/JUnit limitation:
The bundled validator attempted to bootstrap Apache Maven 3.9.11, but this container cannot resolve
repo.maven.apache.org. Exact environment error: `curl: (6) Could not resolve host: repo.maven.apache.org`.
Therefore the full Spring Boot package/JUnit suite could not be executed here and this report does not
claim that it ran. Run validate-local.bat or validate-local.sh on the target machine with Maven or
repository/proxy access to execute the complete dependency build and McpManagerManualConfigTest.


8. ELIYA09 - MCP in Chat + Agent, optional Agent workspace (2026-09-23)
-------------------------------------------------------------------
Implemented:
- Chat mode now has a lightweight MCP tool loop for Jira/Confluence/GitLab/SonarQube/MCP-oriented prompts.
- Ordinary non-MCP Chat prompts retain the existing provider streaming path; MCP is activated only when the prompt indicates external DevOps evidence is needed.
- Chat MCP is intentionally read/search only. It uses MCP readOnlyHint when supplied and conservative tool-name inference when an internal MCP server omits annotations. Mutating external operations remain Agent-only so the existing Agent permission/approval flow remains authoritative.
- Chat emits MCP activity SSE events while tools are being called and grounds external facts in retrieved MCP evidence rather than model memory.
- Agent workspace is now optional. A blank projectId routes to a dedicated no-workspace Agent path that exposes MCP plus attachment list/read/search and supports Jira/Confluence/requirement-document analysis/report generation.
- The existing workspace Agent path is retained for code work. If a workspace is selected/mentioned, Agent can combine the live project with Jira, Confluence, MCP and uploaded requirement documents using the existing planning, approval, editing and verification architecture.
- A remembered workspace no longer forces clearly external-only Jira/Confluence/document analysis into repository mode. Prompts containing project/code/implementation/migration/test intent keep the workspace active.
- McpManager catalog/call/status/config discovery now accepts a null workspace context by using the user home as the MCP configuration context. This enables Chat and no-workspace Agent without changing workspace-bound MCP behavior.
- No-workspace Agent still honors plan approval, MCP permission settings, cancellation, provider recovery/fallback behavior, context compaction and durable run progress.
- Failed/cancelled no-workspace runs do not mark remaining plan steps completed.
- README updated with Chat, Agent-with-workspace and Agent-without-workspace usage examples.

Regression tests added/extended:
- ChatMcpServiceTest: MCP prompt detection vs ordinary Chat prompts.
- ChatServiceWorkspaceRoutingTest: external-only Jira/Confluence/document requests detach remembered workspace; mixed MCP + project/code requests retain it.
- McpManagerManualConfigTest: null-workspace catalog discovery, Chat read-only classification and a real mock tools/call round trip.

Validation performed in this container:
PASS - node --check src/main/resources/static/app.js
PASS - node --check src/main/resources/static/markdown.js
PASS - tinycss2 parse of src/main/resources/static/app.css: 0 CSS parse errors.
PASS - pom.xml XML parse.
PASS - Source contract checks for: Chat MCP invocation, ordinary Chat streaming fallback, optional Agent workspace routing, no-workspace MCP/attachment tools, retained workspace execution path, null-workspace MCP support, Chat read-only MCP guard, and UI/context instructions.
PASS - Focused Java 17 compile of the new ChatMcpService against minimal local stubs mirroring the exact OpenAiCompatibleClient/McpManager/ChatRequest method contracts used by the class.
PASS - javac Java-17 grammar/type screening of all modified Java sources; dependency-resolution errors were expected because Maven dependencies are unavailable, and no parser/duplicate/incompatible-signature diagnostic patterns were detected in the changed source.
PASS - javac grammar screening of the new/modified MCP regression tests; only unavailable dependency/JUnit symbols were reported.

Full Maven/JUnit limitation:
The bundled validator attempted to bootstrap Apache Maven 3.9.11, but this container cannot resolve
repo.maven.apache.org. Exact environment error: `curl: (6) Could not resolve host: repo.maven.apache.org`.
Therefore the complete Spring Boot dependency build and JUnit suite could not be executed in this container and this
report does not claim that they ran. Run `validate-local.bat` or `validate-local.sh` on the target corporate machine
with Maven/repository/proxy access for the final dependency build and full test suite.
```

---

<a id="doc-browse-and-index-hang-fix"></a>
### BROWSE_AND_INDEX_HANG_FIX.md

#### ELIYA — folder-picker, project-indexing, and Chat responsiveness fix

##### Issues traced in the preceding source

1. `/api/local-folders/browse` tried synchronous Swing `JFileChooser` from a servlet request on Windows/Linux. Swing file-system enumeration, inaccessible network mounts, modal focus and a 5-minute native fallback could leave the request running and prevent the next chooser from opening.
2. `POST /api/projects/local` invoked `ProjectService.createLocal` (transactional recursive file walk, H2 insert/update for as many as 3,000 full source files), then `WorkspaceRetrievalIndexService.warmRoot` (a *second* recursive scan) **before returning** to the UI.
3. Chat selected its project context by deserializing all H2 `ProjectFileEntity` contents, scoring each, then retrieving a second copy from the filesystem index. This work was performed before answering each question.
4. Agent startup independently called `workspaceRetrieval.warm(ws)`, which could start another full scan while initial indexing was in progress.

##### Implemented changes

- On Windows use Windows Forms folder picker through PowerShell; on macOS use `osascript`; on Linux use `zenity` or `kdialog`. No blocking Swing fallback. Only one desktop dialog is allowed at a time; a second call returns HTTP 409 `PICKER_BUSY`. A picker that cannot launch returns an actionable HTTP 503 and the UI switches to **Enter path**. The OS dialog process is bounded to 90 seconds; the browser fetch is bounded to 95 seconds.
- Local project/reference registration only validates and saves the canonical local path. `LocalProjectIndexService` queues a single bounded background indexing worker. Folder addition returns immediately instead of waiting for the file scan. The index has a status endpoint: `GET /api/projects/{id}/index-status` with `queued`, `indexing`, `completed`, or `failed`, file counts and a detail message. Rescan is background work as well.
- Local source files are **not copied a second time into H2**. Chat uses a bounded, cached local retrieval index. For browser-uploaded (nonlocal) projects, the original database-backed project context is preserved. Existing H2 records and conversation history are not deleted by this change.
- On every new JVM startup, previously selected projects and reference folders are re-indexed in the background; selected names and paths remain shared by Chat and Agent. Querying a project while its index is pending tells the user that code evidence is not ready, rather than blocking the request or inventing source-code details.
- Agent startup uses any completed cached retrieval index and otherwise continues with its live workspace tools. It no longer duplicates the initial scan. Agent write operations retain their existing safety checks and run-start baseline hashing; the latter still has a cost on very large projects.
- The UI does not disable Chat while folder indexing runs. Folder buttons re-enable after registration, independent of the indexing job. Read-only reference names are preserved.

##### Known limitations and boundaries

- Native OS graphical folder pickers **must** run in an interactive logged-in desktop session of the machine hosting ELIYA. Headless/remote/browser-on-different-machine environments must use **Enter path**. Native Windows and macOS graphical behaviour still needs manual testing on those operating systems.
- The code index is bounded and based on lexical retrieval with limited samples. It cannot guarantee an answer to every question about arbitrarily large files or unindexed images; Agent can inspect live source files and optional document/vision analysis remains separate.
- H2 still stores conversations and other application data. Old locally indexed source rows are deliberately left untouched for data preservation, but are no longer loaded on every Chat question.
- A network filesystem that stalls during I/O can keep the *single background index worker* occupied. It will not block folder registration or ordinary UI calls, but jobs may remain queued behind it.

##### Validation run in this environment

- `node --check src/main/resources/static/app.js`
- `node --test src/test/js/*.test.js` — eight UI tests pass.
- Java 17 isolated compile/test: actual `WorkspaceRetrievalIndexService` and `LocalProjectIndexService`, with minimal Spring/client stubs, successfully indexed a synthetic 1,000-file project in the background; registration completed quickly, cached retrieval found the requested file, duplicate registration did not rescan.
- Java 17 isolated compile/test: actual `LocalFolderPickerController`, with minimal Spring/servlet stubs, rejected concurrent picker requests, handled a headless environment gracefully and checked same-origin requests.

**Not yet validated:** complete Maven/Spring Boot compilation, H2 integration under the real application, actual LLM provider response, and native macOS/Windows desktop dialogs. Maven and the required cached dependencies are not installed in the current environment. On a development machine with Java 17 and Maven, run `mvn -Pfull-tests clean verify` and manually exercise Browse twice, Chat during indexing and Chat after indexing with a representative repository before distributing the JAR.

---

<a id="doc-browse-path-error-fix"></a>
### BROWSE_PATH_ERROR_FIX.md

#### Browse path error fix (October 1, 2026)

##### Cause in the preceding source
`POST /api/local-folders/browse` used only Swing `JFileChooser` and let `IllegalStateException`, `HeadlessException`, dialog startup failures and OS/desktop errors propagate to Spring as HTTP 500. A rejected origin also propagated as an unhandled `SecurityException` and could show the same generic error.

##### Changes
- Browse uses macOS `osascript` native folder selection first; Windows and Linux retain Swing and have native fallback via PowerShell or `zenity` (when available) if Swing is unavailable. This still requires a graphical user session on the ELIYA backend machine.
- Expected desktop failures return HTTP 503 `{ "code":"PICKER_UNAVAILABLE", "message":"..." }` instead of HTTP 500. Browser UI automatically opens the existing `Enter path` / `Reference path` prompt. Cancellation does not invoke a fallback prompt.
- Non-local and origin-mismatched requests return structured HTTP 403 messages. No remote user may open the local system's native dialog.
- Selected folders are canonicalized and validated before being passed to the existing project-indexing pipeline. The project/references and indexing behavior are unchanged.

##### Run and verify
1. Build with JDK 17 and Maven: `./mvnw -Pfull-tests clean verify` (if the machine has Maven/network access).
2. Start the newly built `target/eliya.jar` on the same computer as the browser. Open ELIYA at its local address, e.g. `http://localhost:8080`.
3. Click `Browse project` or `Browse reference`, choose a folder, and confirm indexing and named-reference selection work.
4. In a non-graphical environment, Browse now explains why it cannot open and prompts for `Enter path` instead. Use an absolute path on the **machine running ELIYA**.
5. If the folder dialog opens but registering/indexing the selected project still returns an error, consult the ELIYA process log; this is a different endpoint, `/api/projects/local`.

##### Validation in this environment
- `javac --release 17` isolated compile of the picker and request/response contract, plus Java headless/loopback/origin smoke checks.
- `node --check` of the browser JavaScript and `node --test` of UI tests, including 503 fallback/cancellation and existing named references, workspace and deletion-approval tests.
- Full Maven build and graphical Windows/macOS dialog tests are not possible in the current Linux/headless environment. No prebuilt JAR is included; the ZIP is updated source.

---

<a id="doc-compile-fix-validation-report"></a>
### COMPILE_FIX_VALIDATION_REPORT.md

#### ELIYA consolidated compile-fix validation

Date: 2026-09-30

##### Fixes applied

1. `AgentService.java`
   - Added missing `java.io.IOException` import required by the protected rollback catch path.
   - No execution, approval, rollback or vision behavior was changed by this fix.

2. `WorkspaceKnowledgeService.java`
   - `candidates` is captured by the `SimpleFileVisitor`; it is now final/effectively final.
   - Removed reassignment of the captured variable.
   - Added a separate `documentsToProcess` list for the `MAX_DOCS` bounded subset.
   - The workspace scan behavior is preserved: discover documents, warn when over the cap, process at most `MAX_DOCS`.

##### Validation performed in this environment

PASS - `WorkspaceKnowledgeService.java` compiled with Java 17 using minimal dependency stubs, `-Xlint:all -Werror`.

PASS - Java 17 whole-source compiler screening reached semantic analysis for all main Java sources. No source-local syntax/semantic patterns were detected for:
- non-final/effectively-final captured variables,
- unreported checked exceptions,
- duplicate local declarations,
- missing return statements,
- illegal starts / parse termination,
- bad operand or dereference errors.

The whole-source compile cannot complete here because Spring Boot/Jackson/POI/PDFBox/Tika/JPA dependencies are not installed and this container cannot access Maven Central. Those missing dependency symbols are expected environment errors, not proof of application-source compilation success.

PASS - `node --check src/main/resources/static/app.js`.

PASS - `node src/test/js/deletion_approval_ui.test.js`.

PASS - CSS parse check (`app.css`): 0 parse errors.

PASS - `qa/offline-smoke/run.sh`: deletion approval TTL, single-use permission, rollback, outside-root snapshot and command guard.

PASS - `qa/offline-smoke/vision.sh`: model-independent Vision adapter, batching, missing configuration and partial-failure reporting.

PASS - `qa/offline-smoke/ui-contract.py`: 11 UI/API contract checks.

##### Required final build certification

A dependency-backed Maven build still must be run on a machine with Maven Central/corporate repository access:

Windows:

```bat
mvnw.cmd -Pfull-tests clean package
```

Linux/macOS:

```bash
./mvnw -Pfull-tests clean package
```

Only a successful Maven build can certify that there are no remaining compilation or dependency-integration errors. This package is therefore a **consolidated compile-fix source candidate**, not a falsely claimed fully compiled release.

---

<a id="doc-documentation-intelligence-source-sha256"></a>
### DOCUMENTATION_INTELLIGENCE_SOURCE_SHA256.txt

```text
3761d064f95ea88833615a2b0766ebcc1c8c0f876bc1f7eb6f6a97674b51f2eb  src/main/java/com/llmart/llm/service/DocumentationIntelligenceService.java
f7618f71cac2b5d89e3ad381399f575b63a1cce2c6969874891c7ece5dbf7399  src/main/java/com/llmart/llm/service/AgentService.java
d4cde0e171846113caebc694835c055e0ba1734cb0198606224afe130fcfb9b2  src/main/java/com/llmart/llm/service/AgentRunService.java
52b7d4f082f9e43f7b5d47da3b91608c9e7435f470b49767e72beeb50e9b31e8  src/main/java/com/llmart/llm/service/AgentToolRegistry.java
b239a1c355b7f7a8363530260231ac71a9a4af7114b3eab225c300eed2fe946d  src/main/resources/static/app.js
f28a4fc9458779695e47111520ba0e4c4a7555a00834c805596940ece1e0e52c  src/test/java/com/llmart/llm/service/DocumentationIntelligenceServiceTest.java
```

---

<a id="doc-documentation-intelligence-validation-report"></a>
### DOCUMENTATION_INTELLIGENCE_VALIDATION_REPORT.md

#### ELIYA Documentation Intelligence - Implementation & Validation

##### Scope implemented
ELIYA now has a dedicated large-codebase documentation workflow instead of treating documentation as a normal coding/migration task.

###### Runtime/orchestration
- Detects repository documentation creation requests such as functional documentation, technical documentation, architecture docs and codebase docs while avoiding ordinary input-document analysis.
- Uses a documentation-specific 5-stage fallback plan: repository inventory -> bounded module analysis -> relationship/flow synthesis -> document generation -> final documentation validation.
- Adds eight dedicated tools:
  - `documentation_inventory`
  - `documentation_coverage`
  - `documentation_module`
  - `documentation_record_module`
  - `documentation_exclude_module`
  - `documentation_knowledge`
  - `documentation_template`
  - `documentation_validate`
- Documentation completion is coverage/evidence driven. Compile/test is not substituted for documentation validation unless separately requested.

###### Repository coverage engine
- Deterministic repository scan with generated/vendor/build-directory pruning.
- Supports up to 100,000 relevant scanned files and up to 5,000 documentation modules. A truncated inventory intentionally blocks successful completion.
- Partitions build roots, source roots, tests, resources and configuration into bounded documentation scopes.
- Handles classes/files directly at a common package root without losing them between nested package scopes.
- Prevents nested documentation scopes from being double-counted in module context.
- Every discovered module is represented in the existing durable work-item ledger.
- A module becomes complete only after an evidence-backed functional + technical summary is recorded using real workspace file paths.
- Modules can be excluded only with a concrete reason; final documents must represent approved exclusions.

###### Durable knowledge / long-run recovery
- Module summaries are persisted outside the user's workspace under the ELIYA documentation-run store.
- A later run for the same unchanged repository can reuse completed/excluded module knowledge instead of restarting from zero.
- Reuse requires the same module identity/file count, source timestamps not newer than the prior inventory, and existing evidence files.
- Previously generated validated documentation outputs are excluded from a resumed source inventory so ELIYA does not treat its own output as new application scope.
- A resumed run still requires final document revalidation before completion.

###### Functional documentation template
The built-in template requires:
1. Executive Summary
2. Purpose, Scope and Repository Boundary
3. Actors / Users / External Systems
4. Functional Capability Map
5. End-to-End Functional Workflows
6. Business Rules and Validations
7. Inputs, Outputs and Data Movement
8. External Integrations and Dependencies
9. Scheduled / Background / Event-Driven Functional Behaviour
10. Error, Retry and User-Visible Failure Behaviour
11. Functional Security / Authorization Behaviour
12. Functional Traceability Matrix
13. Known Gaps, Unknowns and Out-of-Repository Behaviour
14. Source Evidence Index

###### Technical documentation template
The built-in template requires:
1. Executive Technical Summary
2. System Context and Solution Architecture
3. Technology Stack and Build/Runtime Model
4. Repository / Module Map
5. Component Responsibilities and Dependency Relationships
6. Entry Points, APIs and Interfaces
7. Domain/Data Model, Persistence and Storage
8. Messaging, Events, Queues and Scheduled Jobs
9. External Integrations
10. Configuration, Profiles, Secrets Boundaries and Environment Behaviour
11. Authentication, Authorization and Security Controls
12. Error/Exception/Retry/Resilience Design
13. Logging, Monitoring and Observability
14. Concurrency, Performance and Scalability Considerations Supported by Source Evidence
15. CI/CD, Packaging and Deployment
16. Testing Strategy and Test Architecture
17. Extension Points / Maintainability Notes
18. Known Technical Risks, Unknowns and External Boundaries
19. Source Evidence Index

###### Completion and safety gates
- `documentation_validate` fails if repository coverage is incomplete or inventory was truncated.
- It fails if functional/technical documents are missing/too small or lack required concepts.
- It fails if a completed module has no source path represented in final documentation.
- It fails if approved exclusions are not represented in final documentation.
- The final approved plan step cannot complete until documentation coverage is complete and `documentation_validate` has passed.
- The Agent run itself cannot finish successfully while documentation coverage/validation is incomplete.
- Any workspace mutation after a documentation PASS automatically invalidates that PASS and requires `documentation_validate` again.

###### UI visibility
The existing Agent run UI now displays:
- work-item completion count,
- Documentation coverage pending / complete,
- Documentation validation pending / passed,
- coverage/validation summary text in the Documentation Intelligence status panel.

##### Files added/changed
- Added `src/main/java/com/llmart/llm/service/DocumentationIntelligenceService.java`
- Updated `AgentService.java`
- Updated `AgentRunService.java`
- Updated `AgentToolRegistry.java`
- Updated `src/main/resources/static/app.js`
- Added `DocumentationIntelligenceServiceTest.java`
- Updated `AgentServiceCompatibilityTest.java`
- Updated `AgentToolRegistryTest.java`

##### Validation performed in this environment
| Check | Result |
| --- | --- |
| Documentation core Java 17 type compilation with minimal Spring/Jackson/workspace stubs | **PASS** |
| Isolated documentation behavioral smoke test | **PASS** — 5 deterministic scopes, evidence-backed completion, 100% coverage, final validation PASS, post-validation mutation invalidation |
| Java parse checks for changed production/test sources | **PASS** |
| `node --check src/main/resources/static/app.js` | **PASS** |
| `node --check src/main/resources/static/markdown.js` | **PASS** |
| Existing deletion approval / rollback offline smoke | **PASS** |
| Existing Vision adapter offline smoke | **PASS** |
| Existing UI/API contract smoke (11 checks) | **PASS** |
| Existing deletion approval popup JS regression | **PASS** |
| Tool registry consistency | **PASS** — 78 unique tools, 8 documentation tools, no duplicate tool names; every core tool exists in registry |
| Full Maven compile/JUnit | **BLOCKED BY ENVIRONMENT** |

##### Maven limitation
`./mvnw -version` was attempted. This environment has no installed Maven and the wrapper cannot bootstrap Maven because DNS resolution for `repo.maven.apache.org` fails (`curl: (6) Could not resolve host`). Therefore this package is source/isolated-validation complete here, but a real project-wide Maven compilation and full JUnit run still must be executed in the normal development environment with dependency access.

Recommended final verification there:
```bash
./mvnw clean package
./mvnw -Pfull-tests test
```

##### Spring startup constructor fix
A runtime startup failure reported after packaging was traced to Spring constructor selection for `DocumentationIntelligenceService`. The service has both a production `ObjectMapper` constructor and a package-private storage-path constructor used by tests. The production constructor is now explicitly annotated `@Autowired`, and a regression test asserts the injection constructor remains selected. An isolated Java 17 compile and reflection check passed. Full Spring Boot startup still requires a normal Maven-enabled environment.

---

<a id="doc-enhancement-implementation-status"></a>
### ENHANCEMENT_IMPLEMENTATION_STATUS.md

#### ELIYA — implementation status for the 41 enhancement requirements

**Artifact classification: SOURCE / VALIDATION CANDIDATE, NOT A VERIFIED EXECUTABLE RELEASE.**

This package is an updated source tree derived from the provided `ELIYA10(1).zip`. It contains meaningful implementations of the two-model multimodal workflow, a workspace knowledge API and UI, and a gated file-deletion approval/rollback mechanism. An actual Maven application build, live-model integration test and full regression suite could **not** run in the packaging environment because Maven was unavailable and Maven Central DNS resolution failed. Do not deploy it as a production-validated binary until those tests pass.

##### Requirements traceability

Status terminology: **Implemented in source** = substantive code exists but integration has not been build-verified. **Partial / existing** = some code exists but the entire requested guarantee is not delivered. **Not verified** = test/configuration requires a live environment.

| IDs | Scope | Status | Where/how |
| --- | --- | --- | --- |
| 1–5 | Separate optional Agentic and Vision models; Chat untouched; editable providers | Implemented in source / live compatibility not verified | `ChatSettings`, `VisionDocumentService`, `ContextService`, `app.js`, `index.html`; actual endpoint support established by image request, not model-name heuristics. |
| 6–10 | Document inventory, visual detection, mixed Word/PDF/Excel/PowerPoint, compatible vision conversion | Implemented in source with explicit format limits | `WorkspaceDocumentScanner` and `VisionDocumentService`; scanned/vector PDF pages rendered, PPTX slides rendered, embedded Word/Excel images extracted. Unsupported charts, unusual embedded objects, text truncation and image limits are explicitly reported. Provider-native full-document binary is not assumed. |
| 11 | Jira/Confluence and MCP image evidence | Partial | `McpManager.callWithVisualEvidence` interprets **native MCP image content blocks** from configured sources. Jira/Confluence image URLs or attachment IDs must be fetched via suitable MCP tools that return image blocks; automatic arbitrary URL/attachment downloading and durable remote-content sync are not built. |
| 12–16 | Durable unified local knowledge, incremental cache, scoped retrieval/source references | Implemented for local workspace documents; remote persistence partial | `WorkspaceKnowledgeService`, `KnowledgeController`, `knowledge_search`/`knowledge_read`; remote MCP visual evidence is passed into the active run, not persisted as an ACL-aware remote index. Source hash and per-workspace storage used for local entries. |
| 17–22 | Complexity, phased planning, complex paths, project exploration, checkpoints and constraints | Partial / existing ELIYA mechanisms retained | Existing `AgentService`, `AgentWorkspaceService`, `AgentRunService`, workspace source retrieval and plan approval preserved. Added document evidence before planning and knowledge tools. Broad replacement of existing large-task optimizer and universal constraint engine not independently implemented/verified. |
| 23–25 | Context/performance | Partial | Content-hash document reuse, batch image processing (three images/request), bounded context retrieval, early skipped-subtree scanning. Not benchmarked for very large monorepos, large remote sources or provider latency. |
| 26–29 | UI model selection, knowledge panel, status, execution/approval visibility | Implemented in source | Updated static HTML/CSS/JS, existing Agent activity integration. UI popup logic independently tested in Node; browser/E2E unverified. |
| 30–32 | Completeness, verification, full regression coverage | Partial / NOT VERIFIED | Image-locator acknowledgement required by Vision response; document warnings and partial status, new JUnit tests and standalone security harness added. Complete Java integration suite not run. Model answers still require human review for critical requirements. |
| 33–35 | Compatibility, validation and executable release | Partial / RELEASE BLOCKER | Java 17 syntax parsed for 96 source/test files; JS syntax and isolated UI test passed; direct local safety classes compiled and harness passed. Full Maven packaging and live integrations blocked; **no executable JAR is included**. |
| 36–39 | Optional deletion approval, popup, pause, backend 60-second timeout | Implemented in source / integration not verified | `AgentService`, `AgentApprovalService`, `AgentRunService`, modal and JS. File-list display is bounded; oversized operations must be split. Backend TTL prevents stale approval. |
| 40 | Rollback on refusal/timeout | Implemented for bounded managed-local snapshot; NOT universal | `ProtectedRunSnapshotService` restores binary/text files and removes new files under captured local roots; standalone Java harness passed. Excluded build/dependency directories, external MCP actions, concurrent writers and side effects outside managed roots cannot be transactionally restored. Missing/oversized baselines fail before protected execution. |
| 41 | Eliminate all tool/script/shell bypasses | **PARTIAL — SECURITY LIMITATION** | Managed delete/move/patch tools are preflighted and explicit destructive shell syntax / obvious remote MCP mutations blocked. **Arbitrary scripts, build plugins, obfuscated commands and unrestricted shell processes are not OS-sandboxed and may evade static detection.** Do not treat the deletion feature as a hardened no-bypass sandbox. |

##### Safety-critical caveats

- The approval timeout is a backend 60-second deadline. The popup countdown does not grant authority; no response triggers rollback and task stop in the managed local flow.
- An approval is specific to the displayed affected paths and SHA-256 content versions. Deletion lists over 50 entries / 12,000 characters are blocked rather than shown in truncated form.
- The rollback baseline is limited to 35,000 files / 750 MB and excludes Git metadata and generated/dependency folders. It may be inadequate for certain repositories; the run refuses to start when it exceeds the configured cap.
- Arbitrary OS shell/process execution prevents a guarantee that every destructive side effect can be intercepted or reverted. **Use trusted/disposable workspaces, backups and restrictive process permissions until a separately designed OS-level sandbox/transaction gate is implemented.**
- Never grant MCP tools with remote mutation permissions when local rollback is expected to include their effects. Read-only MCP is preferred.
- The Vision Model's acknowledgement of each image is *coverage evidence*, not a guarantee that all visible requirements were semantically understood.

##### Build and validation instructions

On a machine with JDK 17+, a working Maven/Maven Central connection, and required corporate proxy settings:

```bash
./mvnw -Pfull-tests clean package
node --check src/main/resources/static/app.js
node src/test/js/deletion_approval_ui.test.js
java -jar target/eliya.jar
```

Windows: substitute `mvnw.cmd -Pfull-tests clean package`. Set up both LLM endpoints in Settings and run controlled mixed-document and permission/rollback tests **before production use**.

##### Suggested acceptance tests on a disposable project

1. Set one Agentic model and independently select a vision-capable model/provider; confirm Chat configuration is unaffected.
2. Use a workspace containing a text-only document, DOCX with embedded screenshots and vector/scanned PDF; analyse workspace, inspect image coverage; restart application and verify indexed knowledge persists.
3. Request test-case generation using **two indexed documents plus a PDF** and check each generated case cites its actual source evidence.
4. Switch Vision models, modify exactly one source document and confirm incremental cache invalidation, no unacknowledged image listed as analysed.
5. Configure Jira/Confluence MCP to return native image content blocks and verify image descriptions; separately test URL-only images to observe the known limitation.
6. Test deletion approval: single-file, patch-delete, overwrite and move; approve once; reject on next operation; wait 60 seconds; restart/reconnect the UI during pending approval; verify the managed workspace is restored byte-for-byte.
7. Verify blocked oversized deletion previews and intentional limitations on arbitrary shell commands, external effects and shared/concurrent workspace modifications.
8. Re-run the existing full ELIYA test suite and real large migration prompts, including task resume and reporting.

---

<a id="doc-enhancement-source-sha256"></a>
### ENHANCEMENT_SOURCE_SHA256.txt

```text
c15f7d13d11a6bc558e1b7d14bd9ac83eb22942b974185c7ad33d3fdeb499304  .github/workflows/verify-eliya.yml
56fc3cad7483df04e0f684bb6107c13fd7f565b4e17f8c25980b1e4ae7c4c5d0  BASELINE_SOURCE_MANIFEST_SHA256.txt
189db9fb67ebe177e1aa0c472560245edaa8a7bd8b26045cb6bf98353f105f36  BASELINE_VALIDATION_REPORT.txt
3d5586463fc4b0b0f84ecb03c9e3f5657b9e300445a4aa7f83e4ca48d27c52a5  ENHANCEMENT_IMPLEMENTATION_STATUS.md
c735ff7b734e254f51883d4e3ffcc8d3567c0dfa683aaf6db534c06c1dfd1b67  ENHANCEMENT_VALIDATION_REPORT.md
3c0e38eb4c485853e4157e0928737d5991b02c4edda15f7ba92591c8cde8c608  IMPLEMENTATION_STATUS.md
b17b1ebfe57d507e129f93f076eda365436bef0f5ff08e51bc239a95b904b95a  README.md
93539789c63c440e59975faca25882f7f788e11344101e4c2678dfecca009238  mvnw
3d17e93ded0a41bcca8481de2cbfcbc2632ed364fb1f194eee4e2041c53c659d  mvnw.cmd
80201d2e537cf4e58a9c412d2eca7b76e7e00147b3952783fe33fe65d4028909  pom.xml
4809d811601053e1a1acd0f89015d730d842a22d361d638642f15f946cccf5c4  qa/offline-smoke/run.sh
3130597676308d8c037fe4f2b81f233057410e8b0ab8b01b7837a90b7c3a3d50  qa/offline-smoke/ui-contract.py
6a8f81cc571123c827474a2234e64ffb4ac94f89cf83dbd442a3a4b8b1d8af28  qa/offline-smoke/vision.sh
dd4b5681119d497f642d018324d20572b18cc94c94dd6b0cf51177615ed9806e  run.bat
6aceeb9f78f93087f9aa96c3644b346a265a105d24824c1aa8503517a103c3b4  run.sh
2c403a73bc273d47599c924364242e2828e8c609e3fa8df42ff54e44519c9496  src/main/java/com/llmart/llm/LlmApplication.java
f98caed7fe3cf4e26243a05a15f85dc88c965da4c7ef99686ab0cdfb9a44f6ea  src/main/java/com/llmart/llm/config/AppConfig.java
4483942ecd270565915509e1047fb8c2746e05ebed71a11bbae759ba651b9ee8  src/main/java/com/llmart/llm/config/AppPathResolver.java
b8a150b77d41e58798dcb833fcd726ab090c4460f640afd3d5019d08f07abf0c  src/main/java/com/llmart/llm/controller/AgentController.java
d629b0cf5675076db789c6675427893cd168414c57eda65f18405975c73bdd7a  src/main/java/com/llmart/llm/controller/ApiExceptionHandler.java
191114edbd1ea0b15233acd90bc200756a586e94891d1314fc9768238945043b  src/main/java/com/llmart/llm/controller/ArtifactController.java
42817f58cad56971356ee6410b371ba5cbad8e031efcd7fcb7c9fa0c0d865114  src/main/java/com/llmart/llm/controller/ChatController.java
0bbeefa929d4edf018dee8b9fa760898489a6431ac9d02ecf2cdda329a12d2f8  src/main/java/com/llmart/llm/controller/ConversationController.java
d7cd3e63906d79e24d52b7f35d8cd02a2909a1b76476fccd596db41796ce2406  src/main/java/com/llmart/llm/controller/FileController.java
59a524ea729a086dc9b5ae1bc4af65c03d9cbfc946258221773202dd265ac07c  src/main/java/com/llmart/llm/controller/KnowledgeController.java
21790b2233638fdcfdf2cfa3e448fe95b83fae258c068a226c48dae804803110  src/main/java/com/llmart/llm/controller/McpController.java
aab1e04c1cd617baf6642f71c398d6f8b85ef81d7c752222e4d255079ecc743b  src/main/java/com/llmart/llm/controller/ProjectController.java
e4fdc0e778ea4c057aaa013c7e3d5e73ebafe96fdd53002206c444afc15dbbe8  src/main/java/com/llmart/llm/dto/ChatMode.java
31f91f8b1db0b25b2e729ee73b8f957b6a705128043fb58025cc13b5597e5368  src/main/java/com/llmart/llm/dto/ChatRequest.java
18a0f8daa04e36150839e409d685065f6da293d07322c81997c271bdc58f6db6  src/main/java/com/llmart/llm/dto/ChatSettings.java
f0c7333b2fb95deed8ddc01075a1e3ac24a8a5e95cdda34300dae68b85dd73ed  src/main/java/com/llmart/llm/dto/ConversationDto.java
e160b0f6ad25188d29e8099afd1e6cf156d2aa4287f40d8e49eef541a9744972  src/main/java/com/llmart/llm/dto/ExcelExportRequest.java
5f47845cefca0a28ed0bb8f06cfdeb0135d0fbf92362b1980717a858836ee748  src/main/java/com/llmart/llm/dto/FileDto.java
0a085ea11600c0bc0f416baea45aeea8be381bb6b1a249856c1e6464db2c8da7  src/main/java/com/llmart/llm/dto/MessageDto.java
cec82cb0383d649d80bb74d2b06b1f4f2f11176d004081725a24f83f598b29bb  src/main/java/com/llmart/llm/dto/ProjectDto.java
705cf8c8dc327cade691c2b052bd4193adfeacd4397e171a50d3917e9ca3ce19  src/main/java/com/llmart/llm/dto/ProjectFileUpload.java
f98338bbb8d25319cbb145c0c17c832465db6b765ad535ec3d85d76b9303770d  src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java
2544fa42101de0dcfe295d22ce8af9dd0f3b0fa74d3f98444cf9e1ce7db848f2  src/main/java/com/llmart/llm/dto/ProjectUploadBatch.java
f51e077cb1a56c1cef2450508ed51f7bcb1ff554b6dffad72437b015a19ae2f4  src/main/java/com/llmart/llm/entity/ConversationEntity.java
b7ad960ed9f989934525b0794e499ec44008444774b3b782bb4669b5a7630bd9  src/main/java/com/llmart/llm/entity/FileEntity.java
2c53591fbcff3a40a470e56509d081d7a2ca6f3151ddecd70ac3bb5ab1c175fd  src/main/java/com/llmart/llm/entity/MessageEntity.java
0228201d2cca02a2a595c6dd561866cc51f9597d9ac78eff3b7b45e79c42f3c4  src/main/java/com/llmart/llm/entity/ProjectFileEntity.java
debbb80abe56f4d579d2a7316fb6eee1b4b7987dd36167929c77842715af6ac0  src/main/java/com/llmart/llm/entity/ProjectWorkspaceEntity.java
25d60a8159ba948454fe32b59efefdf55ce843d479c44438871533f724224bf3  src/main/java/com/llmart/llm/repository/ConversationRepository.java
5fd45a03590d5f0a1405a53fc06012ca79e1cd9afd9a373b40e8ca17b11bb391  src/main/java/com/llmart/llm/repository/FileRepository.java
fdcf2534462418c948b371a6a8a3083851e433e427dfb647086df547235ee0ac  src/main/java/com/llmart/llm/repository/MessageRepository.java
fcb3c920cf0419feb867370102213e9a53c15e56553977c6aece9c129668c449  src/main/java/com/llmart/llm/repository/ProjectFileRepository.java
495e3301684c69de86425ee38a3e66071f73fa428840235d08a3c7cdb6e0f451  src/main/java/com/llmart/llm/repository/ProjectWorkspaceRepository.java
00b0118bc63c5244124afdd4d1c817cdf35b10f97381d262d21f49499865fd57  src/main/java/com/llmart/llm/service/AgentApprovalService.java
eda2cb5edfc92e5bf7971aecdc90d8b2d6e7cebf5c79b98868b1558f3a9a58ba  src/main/java/com/llmart/llm/service/AgentApprovalTimeoutException.java
3e8248a5f3fdb28b6e62238666e23ef01c7a61dcaf2ca00a90de768e3bb033af  src/main/java/com/llmart/llm/service/AgentCancelledException.java
ee957dbb1d2cfa62aa9494f50a3b5b8df491741f7a82f3be3b022c1b6f36bb14  src/main/java/com/llmart/llm/service/AgentDeletionCommandGuard.java
919d89344d2c658a0051ae4bdd3707a104b70326bfa18e411c8c2499b90dc861  src/main/java/com/llmart/llm/service/AgentProfileService.java
ae56c4693283f70af50c39dec52572273af492188b67c4a3953e4e3ad9082a7b  src/main/java/com/llmart/llm/service/AgentRunService.java
5b73abfab406e3908146acc144a9f493a24efeee936be2ce360b5b93839112b3  src/main/java/com/llmart/llm/service/AgentService.java
cbcf149f9cfdccc08a33ee0409baf6fd65bae88d12ba33765725c4c625c7dce4  src/main/java/com/llmart/llm/service/AgentToolRegistry.java
fd97249bd11d758cfaa1ba84796f2583f6229aded308e8652c53c22644bb8680  src/main/java/com/llmart/llm/service/AgentWorkspaceService.java
34840a115035d6010dff553fae3a2ec39780fc6fc81e5c23f7dd511c21c2369e  src/main/java/com/llmart/llm/service/BoundedCommandOutput.java
97376b4e701358d644b4a10c14013a46262466147daf327b69782d44f48ddee3  src/main/java/com/llmart/llm/service/ChatMcpService.java
1094a8df62956cb03ae755022dedee745e41842f15017c438a4e93b7585b48df  src/main/java/com/llmart/llm/service/ChatService.java
788f7c22ffa951e7653fc26b3321644ef8dfd8fcdeca1d385216f047face6d38  src/main/java/com/llmart/llm/service/ContextService.java
cf3094079f586605b99c0ac69b32dfd5e94f9db3548d14fe229f8e988a19eb2c  src/main/java/com/llmart/llm/service/ContextWindowManager.java
3410f8e203964d35eb4f8bd35a23362d749b31bf1338074f2a6850341f65f030  src/main/java/com/llmart/llm/service/ConversationService.java
1f78301634fa731dc1edeb2bf599d2ab4f0420e5f1920446ce75294df6c77014  src/main/java/com/llmart/llm/service/ExcelExportService.java
470006657b3ff82c53ffb0538802c4d241ddecfcfb70b372518b98216131410d  src/main/java/com/llmart/llm/service/FileContextSelector.java
3d243338b348bfb3d96488f2b560466eea86d3b27d462e04dc519f3431c4d253  src/main/java/com/llmart/llm/service/FileService.java
32a27a6c98c883d6295f9fdf343fa1a08d43bb9d97b941a4e157bac1a8b4b69c  src/main/java/com/llmart/llm/service/Hashing.java
4a6f9e046a8ed6c6d4207c82753f13e1c493443dd142e8e527e2a4da06253894  src/main/java/com/llmart/llm/service/ImageUnderstandingService.java
3eba882df30b9028f45a86827c1d8804e62bcc430edb9e48f4440e16494e3059  src/main/java/com/llmart/llm/service/LspManager.java
452de867dc68bd88a72e0aa511c64df3fab03a7545a9ad55912ba1af449b6ec6  src/main/java/com/llmart/llm/service/McpManager.java
1ca55beb403eca4f0c29045ebf3b16a6bef00538dce50ab4f1d2e173e7136dc8  src/main/java/com/llmart/llm/service/ModelCapabilityRegistry.java
ea8106eb7b93cf0cd81ca6eec3ac0c983c83edfd2e5d6c25ebb77b514843f851  src/main/java/com/llmart/llm/service/ModelProbeService.java
c9816ad48954c3b34058ce5c9dee73914b11f17147783f9431887f80cf45ff8c  src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
5506f9b6ce057acfacbee93f10cd5dcd2e915211c40870bec088b6e7d9b9bbdc  src/main/java/com/llmart/llm/service/PatchConflictException.java
45be1b8fe7db6f4a56c5ea545976e5dfacb36ebe32181cf17c4823490993c039  src/main/java/com/llmart/llm/service/PdfExportService.java
edba4f4e0dcd1406695472b06276acca1ab0d06bc43e3ee4e80acd989b97b214  src/main/java/com/llmart/llm/service/ProjectContextService.java
17d2f3e421a6daf46805f09adefc35c3ed8c3a4c56636a90a95f10cdbb90c791  src/main/java/com/llmart/llm/service/ProjectPatchService.java
ef05e2a132b2dcf31ee523d1dbe84086c94bd997a8de7c9e46fb4968d57f3d32  src/main/java/com/llmart/llm/service/ProjectService.java
21a592a642c1cdfe383c24dc8df123cd822f771a92d1f4921406f239ed1bf216  src/main/java/com/llmart/llm/service/PromptResourceResolver.java
bd4f1ba8a9618509fe4fd37fb79b602e2c2a324151f268717412a039d6ca4406  src/main/java/com/llmart/llm/service/ProtectedRollbackException.java
5aaa63683abeceaefb4ab57e21d93fb76dd47fc9ca53b261f52efda97c9a727d  src/main/java/com/llmart/llm/service/ProtectedRunSnapshotService.java
8537f08d3ac3223fe1514b5d1bb31caed5cb536c97a370eebfde2fb05e03c71a  src/main/java/com/llmart/llm/service/VisionDocumentService.java
0c3291f7c1abc2f89fcc1a57748a2bfb0ead4fa2a977ce04c8a1ef88f11945dc  src/main/java/com/llmart/llm/service/VisualImageAdapter.java
582fd69d127a5f0b60cc9dcfc919b44665ed8ed84ed1ddeae915123a3c457873  src/main/java/com/llmart/llm/service/WorkspaceDocumentScanner.java
be6cebed8d5346db098d9fa36da142458bbc9d3a3a2c4d5d27bec2c44df3e1bd  src/main/java/com/llmart/llm/service/WorkspaceKnowledgeService.java
3b868b3ae99cb49cbf6506c4eb38678d6135af81df7cbaab44d51f5af5fe6e24  src/main/java/com/llmart/llm/service/WorkspaceProfileService.java
8e177fd79e9058428caa867c6df21cc8c3096307babe9ab28c93f8080dcbb33a  src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
4ebb0fff90e98c3334cd1984a6648fdeb2317ab563631f04d477adac4d91efc9  src/main/resources/application.properties
c74e6471cd4878653d7e338e51ead0c628b889092d2562e3ec0d04ca6f697bb5  src/main/resources/static/app.css
e40459513924f99d4cd81ae907cd5ad163a34b47290e31f9ddeae7dc9ead7ce3  src/main/resources/static/app.js
fd25b2cf639e52331f66385e91efc2a07fdbef192a242d5f5cc02a88b19faad3  src/main/resources/static/index.html
7ee02bd43edc472a77f2bfa1c3c8a9942b80199a0e6af83bc9b6342040172053  src/main/resources/static/markdown.js
75adcf15944400667cc446e0f6eb1199ae596f9f36bd7d4395b3519c71cf7d71  src/test/java/com/llmart/llm/controller/ConversationControllerHistoryTest.java
b00eb46a2f7d423713b13370b93e292de798554c723a6b7ffe618273f5f26993  src/test/java/com/llmart/llm/dto/ProjectPatchRequestTest.java
2e14b3f07557e28dd0f47be758ee07a481c6c32fdb3a461a24f35b50c4c34fe6  src/test/java/com/llmart/llm/service/AgentApprovalExpiryTest.java
bac5dbda43bec46f9558a4775b0d915866160bb41ed6202d09baf9a2f3b8ce46  src/test/java/com/llmart/llm/service/AgentFileDeletionApprovalTest.java
084dd015af757cc8438e0cc8f7b8d1e8d455dd66facd7aea4f1043c2629d8875  src/test/java/com/llmart/llm/service/AgentRunServiceHistoryTest.java
4fa2e52567976692ec149de6b8c8ee4c7720282992fee6ffbb28b6914b4f9b6e  src/test/java/com/llmart/llm/service/AgentRunServiceTest.java
4d7c79b2e5d3976f6773cd06fdf2f7cdee206726c54a23b0dfee7a96b93b8569  src/test/java/com/llmart/llm/service/AgentServiceCompatibilityTest.java
7c4d30f23a5b705e5009590a26e4d51290dccbfa316db80191a5fec114df5d7c  src/test/java/com/llmart/llm/service/AgentToolRegistryTest.java
401e5f8085619412b405cfbcdde23026aafc2b7f17772b8977567efe2056d44a  src/test/java/com/llmart/llm/service/AgentWorkspaceServiceCommandExecutionTest.java
4238d28faa0f18b2f06528a548bdd1f0bae24741f0342a9e11a208de277291e3  src/test/java/com/llmart/llm/service/AgentWorkspaceServiceMultiResourceTest.java
a95f74eea29ffe7d649f0a6286239adf25c27dcebaababa453b662b7064c046b  src/test/java/com/llmart/llm/service/BoundedCommandOutputTest.java
dd8004b0f7028c8238088b2982c63169f4f0618a82ac14cced9d593e76ff9b2a  src/test/java/com/llmart/llm/service/ChatMcpServiceTest.java
5ab705c7ba73ea08b43aea06f4a65796522d47e320dd8ac9b0fbedf951c4933d  src/test/java/com/llmart/llm/service/ChatServiceWorkspaceRoutingTest.java
cf79d63a4a287001e6c52809a5af7c8ea42483b592663d6780af2b13ce2621f9  src/test/java/com/llmart/llm/service/ContextWindowManagerTest.java
2e97b66b47b578a5ced6f75d97555d327310b170317a8ffd72c095a17da48275  src/test/java/com/llmart/llm/service/FileServiceDocumentExtractionTest.java
2d3aaf8de13dddd5e3fe1d3129cf7091a365f679432f3cde34839fb4e553b69e  src/test/java/com/llmart/llm/service/HashingTest.java
9792921140530da6f3fb720af49c9772700f81c3d63d7507749be86f1f191152  src/test/java/com/llmart/llm/service/McpManagerManualConfigTest.java
612a2d6f9fb558cb5805af88fe2ecedeb48228bf9162eb97f5c166f76deaa4af  src/test/java/com/llmart/llm/service/ModelCapabilityRegistryTest.java
4d356be0b0c8172ca49c6a0afe9287c3ec6b44fa7df4acefa265959ff8388c0d  src/test/java/com/llmart/llm/service/OpenAiCompatibleClientCapabilityTest.java
e7164948694f75e9f70f41d8024c60e375a08e4ef1091657b4698770ac33d6d0  src/test/java/com/llmart/llm/service/PdfExportServiceTest.java
a89c5365fb98c5bf1a91e252a887cb48d635269205dbf01f0c0f0418fc961573  src/test/java/com/llmart/llm/service/ProjectPatchServiceTest.java
a9704f18ddc8ed7d76153f6629f388b1dc01b1082134e2d932b7ead89b1fddeb  src/test/java/com/llmart/llm/service/PromptResourceResolverTest.java
629a219850e7a884e265c46420ebc3ac09d4ca186ebd4d0b8374d6fe37487379  src/test/java/com/llmart/llm/service/ProtectedRunSnapshotServiceTest.java
32748da68358cde2d896bc6bee642becbde107daf26ab15b7278282b29b95894  src/test/java/com/llmart/llm/service/WorkspaceDocumentScannerTest.java
23827ff719a294b207b8c794e73474587fe217437e9b5f9907c08e6603f7145e  src/test/js/deletion_approval_ui.test.js
15d092f2b4819cdacc7f0f7eb0617aa543c33a706f1fc1c01cd997b527d11613  validate-local.bat
6f2ed384a09ba1011f561ebc8afbe927dad0063c24039b3254ba6cc685c2b698  validate-local.sh
```

---

<a id="doc-enhancement-validation-report"></a>
### ENHANCEMENT_VALIDATION_REPORT.md

#### Validation report — ELIYA source enhancement candidate

##### Executed in this packaging environment

| Check | Result | Method |
| --- | --- | --- |
| Java 17 parsing | **PASS (syntax only)** | JDK Compiler API parsed 96 production/test Java files with `--release 17`; 0 syntax errors. Parsing does NOT establish type correctness or runtime compatibility. |
| Java safety component compilation | **PASS (isolated)** | Real `ProtectedRunSnapshotService`, `AgentApprovalService`, exception and image normalizer compiled with Java 17 using minimal framework stubs. Does NOT compile the Spring application. |
| Isolated rollback behavior | **PASS** | Modified text + deleted binary + newly created nested file restored/removed by actual snapshot service; baseline disposed after success. |
| Isolated approval TTL | **PASS** | Actual approval service rejected `RUN` grant for deletion; unanswered short-TTL request threw timeout; token could not be reused. Test uses milliseconds solely for speed; application config uses 60 seconds. |
| JS source syntax | **PASS** | `node --check` for both `app.js` and `markdown.js`. |
| Deletion approval modal | **PASS (isolated UI logic)** | `node src/test/js/deletion_approval_ui.test.js` verified popup contents/countdown, one-click REST action, closure and expiration disabled state. |
| Static HTML ID wiring | **PASS for new controls** | 11 additional UI/API source checks passed, including full-path confirmation and backend 60-second TTL wiring. Existing dynamic IDs are created at runtime. |
| Application Maven build / full JUnit | **BLOCKED — NOT EXECUTED** | `./mvnw -Pfull-tests clean package` attempted; Maven not installed and DNS for `repo.maven.apache.org` unavailable (`curl: (6) Could not resolve host`). |
| Live vision endpoint, Jira/Confluence, protected full Agent run | **NOT EXECUTED** | Requires real configured endpoints, eligible MCP access and integration test environment. |

##### Added regression test sources

- `WorkspaceDocumentScannerTest.java`: DOCX embedded picture and context, text-only PDF, vector flow PDF, text/image mixed selection.
- `AgentApprovalExpiryTest.java`: exclusive one-time deletion grant, TTL expiry and nonreuse.
- `ProtectedRunSnapshotServiceTest.java`: binary/text/nested-file rollback and duplicate snapshot protection.
- `src/test/js/deletion_approval_ui.test.js`: isolated modal state and actions.

Additional isolated validation: `bash qa/offline-smoke/run.sh` (real safety classes), `bash qa/offline-smoke/vision.sh` (real Vision adapter with simulated model), and `python3 qa/offline-smoke/ui-contract.py` (11 checks) all passed.

**Release decision: NOT YET PRODUCTION-VALIDATED.** The ZIP contains buildable-intent source and tests, not a verified JAR. Run full Maven compilation/tests; resolve any integration failures and address arbitrary-shell sandboxing before describing file-deletion protection as impossible to bypass.

---

<a id="doc-folder-picker-startup-performance-fix"></a>
### FOLDER_PICKER_STARTUP_PERFORMANCE_FIX.md

#### Native folder picker startup and reuse — ELIYA21 follow-up (October 1, 2026)

##### Root cause in the supplied source

`POST /api/local-folders/browse` correctly selected a platform-specific picker, but **each Windows click launched a new PowerShell process** and loaded Windows Forms before the dialog could appear. Every macOS click similarly launched a new `osascript` process. The HTTP request stayed open until the user closed the dialog, with a 90-second process timeout and 95-second UI timeout. A second click could be rejected while the previous dialog remained active. This is distinct from indexing, which is already queued *after* folder registration.

##### Changes

- **Windows:** The Spring controller starts a daemon warm-up thread for one STA PowerShell/Windows Forms worker on application startup. The worker stays alive between Browse project and Browse reference requests, retaining the last chosen directory. Calls use a simple line-oriented protocol (`OPEN`/`ELIYA_SELECTED:<base64 UTF-8>`/`ELIYA_CANCELLED`) rather than starting PowerShell on each click. The backend waits at most 12 seconds for initial readiness, 90 seconds for manual selection. If the worker dies, errors or times out, its process is destroyed; the next Browse click starts a fresh worker. `@PreDestroy` cleans it up on application shutdown.
- **macOS:** Uses AWT `FileDialog` in directory-only mode, backed by the OS-native Cocoa dialog in the running JVM. No per-click AppleScript process is launched. It retains the last selected directory and restores the macOS file-dialog system property after closing.
- **Linux:** Prioritizes KDE's `kdialog` on KDE and `zenity` on other graphical desktops, retaining the alternative fallback. Both remain subprocesses, but unlike PowerShell they do not require loading Windows Forms.
- **UI:** Manual Enter path remains available. The browser timeout is 110 seconds, long enough to cover a cold 12-second startup plus a 90-second Windows selection. Failing to open the desktop picker still falls back to Enter path, and cancelling selection does **not** register or index a folder.
- **Isolation and safety:** Browse performs no project tree walk, MCP discovery, AI request or indexing. The endpoint remains loopback-only with a same-origin check and permits only one picker at a time. Selected folders are validated and canonicalized after selection, and the existing background project indexing behavior is preserved.

##### Validation completed here

- `qa/offline-smoke/folder-picker.sh` compiles the *actual controller* with `javac --release 17` and minimal Spring/Jakarta signature stubs. It uses a fake native PowerShell protocol on Linux to validate background warm-up, process reuse across Browse clicks, paths containing spaces, concurrent-click rejection (409), cancellation (200/cancelled), and localhost/origin checks.
- `node --check src/main/resources/static/app.js` and `node --test src/test/js/*.test.js` passed (eight UI tests).
- `bash qa/offline-smoke/run.sh` passed the independent agent safety smoke checks.

##### What still requires real-machine testing

A full Maven/Spring Boot build was **not run** because Maven and project dependencies are unavailable here, and Maven Central DNS is inaccessible. GUI dialogs were **not** tested on actual Windows, macOS, or a GUI Linux desktop. The Windows fake transport validates our Java protocol, not Windows PowerShell/Windows Forms behavior. Rebuild the project on Java 17 with `./mvnw -Pfull-tests clean verify` or `mvnw.cmd -Pfull-tests clean verify`, then manually open project and reference pickers twice on each target OS, checking focus, selection, cancellation, and headless/remote fallback before distributing the JAR. The OS itself may still delay a dialog if shell extensions, mapped network drives, or corporate security software block UI initialization; this change removes repeated process cold starts but cannot guarantee a fixed opening time on every machine.

---

<a id="doc-implementation-status"></a>
### IMPLEMENTATION_STATUS.md

#### ELIYA — 41-change implementation and validation status

**Package classification:** updated Java 17 source package, **NOT** a production-approved or executable-JAR release.

This package extends the existing ELIYA application in place. The 41 IDs below refer to the
agreed requirements. "Code present" means an implementation can be inspected in this source,
not that a complete Spring Boot build or end-to-end provider test succeeded. "Partial" flags a
material limitation. Do not interpret this table as a claim that the entire roadmap is complete.

| ID | Requirement | Code status | Evidence / outstanding limitation |
|---:|---|---|---|
| 1 | Agentic + Vision roles | Code present | Agent mode has independent optional vision model setting. |
| 2 | Preserve normal Chat model | Code present | Existing Chat settings retained; regression suite pending. |
| 3 | Optional Vision | Code present | Text-only flow does not require a configured Vision model. |
| 4 | Dynamic model capabilities | Partial | User-editable models and runtime gateway attempt; automatic provider-specific capability discovery is not universal. |
| 5 | Independent providers/endpoints | Code present | Separate Vision endpoint/key, falling back to Agent connection. |
| 6 | Workspace document discovery | Code present | Local source discovery with limits. |
| 7 | Visual content detection | Partial | PDF raster/vector heuristics and modern Office embedded media; unsupported embedded shapes/charts may need conversion. |
| 8 | Text/vision routing | Code present | Java scanner and Vision adapter. |
| 9 | Multiple formats | Partial | DOCX/XLSX/PPTX/PDF/images/text; legacy binary Office and exotic formats not guaranteed. |
| 10 | Complete-document multimodal analysis | Partial | Bounded context plus related images in multimodal batches; arbitrary gateway native full-DOCX/PDF upload not implemented. |
| 11 | Jira/Confluence images | Partial | MCP image result blocks are analysed; actual attachments depend on the MCP server exposing their bytes. |
| 12 | Persistent local knowledge | Code present | Source-hashed durable workspace records on local disk. |
| 13 | Unified workspace/MCP/code evidence | Partial | Workspace knowledge and code retrieval cooperate; remote MCP evidence is returned to Agent but not fully versioned as persistent remote index. |
| 14 | Changed-document reanalysis | Code present | Content hashing and per-source replacement. |
| 15 | Context retrieval | Code present | Budgeted lexical retrieval and exact-source chunk reads; no embedding/vector reranking. |
| 16 | Source references and history | Code present | Local source locators, warnings, model signatures, persistent run journal. |
| 17 | Task-complexity recognition | Partial | Existing large-task heuristics; no measured difficulty predictor. |
| 18 | Phase-based plans | Code present | Existing plan-first runtime, durable work ledger, user approval. |
| 19 | Nested workspace path handling | Code present | Existing validated path/resolved workspace interfaces; Windows integration not tested here. |
| 20 | Progressive workspace exploration | Code present | Existing profile/retrieval, targeted read and deferred tool discovery. |
| 21 | Checkpoints and recovery | Code present | Existing durable steps, revision-aware retries and checkpoints. |
| 22 | Explicit constraint verification | Partial | Prompt + final verifier and diff tools; arbitrary natural-language constraints cannot be proven automatically. |
| 23 | Task-aware context | Code present | Existing token-aware context plus new source knowledge. |
| 24 | Batching and caching | Code present | Vision batches, source hashes, active-step cache. |
| 25 | Long-running optimisations | Partial | Existing checkpoints/batching; no benchmark on target hardware/provider. |
| 26 | Agent dual-model controls | Code present | Agent Vision and Agentic inputs. |
| 27 | Knowledge view | Code present | Workspace Knowledge panel and API. |
| 28 | Image/analysis progress | Code present | Per-source counts, status, warnings and job polling. |
| 29 | Progress/recovery controls | Code present | Existing agent execution progress and backend run tracking. |
| 30 | Document completeness verification | Partial | Counts per-image locator acknowledgement and reports gaps; model acknowledgement is not proof of semantic accuracy. |
| 31 | Execution verification | Partial | Existing compile/run/test verification loops; full user-constraint proof not implemented. |
| 32 | Regression testing | Partial | JUnit tests added but full Maven/Spring suite not executable here. |
| 33 | Existing architecture integration | Code present | Changes use existing services/controller/API architecture; integration build pending. |
| 34 | Backward compatibility | Partial | Legacy settings/controllers retained; MCP tools without readOnlyHint are intentionally blocked in protected mode. |
| 35 | Fully validated executable package | NOT COMPLETE | JavaScript, Java grammar and isolated Java smoke tests passed; Maven missing, dependency download blocked. |
| 36 | Deletion approval setting | Code present | Separate confirm-file-deletion flag (enabled by default). |
| 37 | Full-path approval popup | Code present | Per-operation UI dialog, full resolved file paths, exact-file hashes. |
| 38 | Suspend for approval | Code present | Backend awaits a one-operation decision; no run-wide deletion grant. |
| 39 | 60-second expiration | Code present | Backend expires decisions, frontend shows countdown. |
| 40 | Automatic rollback | Partial | Local source-tree baseline snapshots; dependency/build folders, external MCP actions and arbitrary child processes are not fully transactional. |
| 41 | Deletion bypass prevention | Partial | Built-in file tools have preflight, risky shell syntax is denied, writable/unannotated MCP tools are denied in protected mode. An application-level checker is not an OS sandbox and cannot intercept every destructive script. |

##### What was actually validated in this environment

- **PASS**: `node --check` for the application and Markdown renderer JavaScript.
- **PASS**: CSS stylesheet parsed without syntax errors.
- **PASS**: `javac` parser accepted all Java source/test files at the Java 17 grammar level. This is *not* symbol resolution or dependency compilation.
- **PASS**: Actual `AgentApprovalService`, `ProtectedRunSnapshotService` and shell guard passed isolated Java 17 smoke checks using minimal framework stubs.
- **PASS**: Actual `VisionDocumentService` and image encoding adapter passed isolated Java 17 smoke checks with a simulated model response.
- **PASS**: 11 frontend-to-backend source-contract checks for model selectors, knowledge routes, deletion popup, backend deadline and rollback wiring.
- **NOT RUN**: Full Maven build, Spring Boot start, JUnit integration, real Windows workspace test, live Vision provider test and Jira/Confluence MCP integration; the container lacks Maven/dependencies and cannot reach Maven Central.

##### Safety and release blockers

1. **Do not deploy as a trusted deletion-proof product yet.** For a strict guarantee, execute *all* shell/build/test/MCP activity under OS-level confinement or prohibit it in protected mode. Merely detecting suspicious command names cannot provide full file-system isolation.
2. Ensure snapshot storage (`app.data-dir`) is **outside all writable project/reference directories**. The code fails closed on an overlap. The protected snapshot tracks selected source trees and has an explicit 750 MB / 35,000-file limit.
3. Protected rollback can affect concurrent external edits in the same workspace; avoid working on the same source tree from another editor/process during a protected run.
4. Test the selected Vision endpoint with representative DOCX/PDF screenshots. Endpoints vary: this package uses text-plus-image messages rather than assuming universal native document upload support.
5. To produce an executable Java 17 JAR, push this source package to a GitHub repository and run **Verify and package ELIYA** manually, or run `validate-local.bat` on a Windows machine with working Maven Central access. Do not use the JAR until the full workflow is green and protection gaps are assessed.

---

<a id="doc-mcp-chat-jira-tickets-fix"></a>
### MCP_CHAT_JIRA_TICKETS_FIX.md

#### ELIYA21 — Chat MCP Jira routing and readiness correction

##### Reported symptom

Settings can successfully test a configured MCP server while Chat answers a query such as "What is the recent tickets in BMSA" without querying Jira. The settings transport check was not an end-to-end Chat read. The Chat router recognized the singular `ticket` but not plural `tickets`, and skipped MCP for such prompts.

##### Changes

- `ChatMcpService`: recognizes plural ticket/issue/story/bug/epic and backlog/sprint queries alongside Jira issue IDs and explicitly named sources. Local questions about how integrations are implemented still use the indexed workspace, not live MCP.
- Live ticket queries with no enabled MCP server return a clear configuration diagnostic instead of silently switching to the LLM's unguided answer.
- Selects read-only external tools and gives search/list/query/find priority for ticket collection queries. Preserves a maximum of 24 tool definitions, existing safe limits and streaming.
- MCP protocol errors and read failures are not counted as verified evidence. Visible status includes tool availability; a failed lookup explains that no verified live data was retrieved.
- `McpManager` Settings test now reports **total discovered tools** separately from **read/search tools allowed in Chat**. A transport connection with zero allowed read tools is visibly not Chat-ready.
- The Settings labels identify Chat's read-only support and Agent's permissions separately.
- Regression tests cover plural ticket routing, disabled connection diagnostics, read-only tool exposure, successful external reads and streaming, as well as the existing workspace/UI/deletion-approval tests.

##### How to verify on the machine running ELIYA

1. Stop the previous JAR, build the packaged source and launch it. Reload the browser to clear stale JS.
2. In Settings, enable the MCP server, click **Test connection & discover tools**, and confirm both **Server connected** and **Chat read/search tools > 0**. Look for a Jira search/list tool in the returned names.
3. In Chat, ask: "List the five most recently updated Jira tickets for BMSA, including key, summary, status and updated date." The UI should show MCP discovery/read tool status, then a tool-backed answer.
4. Ask "How is Jira MCP implemented in this source code?" with a selected project. This should use workspace retrieval instead of a live Jira query.
5. Disable the MCP server and repeat the tickets prompt: Chat must report no MCP server enabled; it must not invent a live ticket list.

##### Limitations

- A green server connection only proves server/tool discovery; each Jira call still requires sufficient per-source permissions, usable tool input schema and an available Jira tool on the configured MCP server.
- This package was tested offline with a fake MCP server/tool and fake model. The live corporate MCP, configured model and a complete dependency-resolved Maven build were not available here. No runnable JAR is included.

---

<a id="doc-mcp-chat-jql-recovery-fix"></a>
### MCP_CHAT_JQL_RECOVERY_FIX.md

#### ELIYA21 – Jira MCP search syntax recovery

##### Observed symptom

Chat now chooses a Jira MCP read/search tool but Jira rejects the model-generated search input with a query syntax error. Some MCP implementations return this error inside text content even when their MCP `isError` flag is false. Prior Chat processing could mistakenly treat that text as successfully retrieved evidence.

##### Implementation

- `ChatMcpService.java` continues to use dynamic tool discovery and its existing read-only Chat allowlist. The discovered tool's `function.parameters.properties` determines whether a field is actually a JQL field (`jql`, `jqlQuery`, `jql_query`, or a query field whose description explicitly says JQL). Other MCP tool inputs are never rewritten.
- An *obviously natural-language* value in a discovered JQL field is converted before the MCP call. Already structured JQL is preserved.
- If Jira still reports a recognizable JQL syntax error, Chat attempts at most **one correction during that read call**, using the user's original prompt and the same discovered tool/schema.
- Explicit issue key: `key = BMSA-123`; explicit project: `project = BMSA ORDER BY updated DESC`; no project/key: `updated >= -30d ORDER BY updated DESC`. The actual project key is taken only from the original prompt, not guessed from the prior workspace or chat context.
- A Jira syntax error in `isError=false` text is *not* considered verified evidence. Successful recovered tool output is used for the existing streamed synthesis; failed recovery is reported clearly.
- Permission/authentication failures (401/403) and missing-project errors do not trigger a syntax-repair retry. The UI emits `preparing`, `running`, `retrying` and `error/success` activity as relevant.
- The recovery is conservative. Other MCP servers or Jira tools without a discoverable JQL input schema are not modified. It does not resolve invalid project keys, unavailable Jira permissions, or servers using different/custom query languages.

##### Source files

- `src/main/java/com/llmart/llm/service/ChatMcpService.java`
- `src/main/java/com/llmart/llm/service/JiraJqlRecovery.java` (new Java 17-only helper)
- `qa/offline-smoke/chat-mcp-routing.sh` (expanded mocked Chat, Jira MCP and SSE checks)
- `qa/offline-smoke/jira-jql.sh` (new deterministic JQL and error-classification checks)

##### Local validation

Focused tests include: workspace question routing, plural tickets, Chat read-only filtering, proper tool-backed response streaming, proactive JQL preparation, one retry after syntax failure with `isError=false`, 403 no-retry, disabled MCP diagnostics, fallback JQL selection for no project, explicit project and issue key. The existing UI/loader, folder-picker, deletion-approval, static source contract and JS syntax checks were also run.

**Not validated here:** full dependency-resolved Maven packaging or real live calls to your corporate Jira MCP server. The deliverable is source code, not a compiled JAR. Java 17 source was compiled against focused offline stubs, not full Spring/Jackson dependencies.

##### Verification in your environment

1. Rebuild ELIYA and restart the JAR. Refresh the browser (Ctrl+F5).
2. Test the MCP server in Settings and confirm a Jira search/read tool is listed.
3. In Chat ask `List the five most recently updated Jira tickets in project BMSA with key, summary, status and updated date` (only if BMSA is the real Jira project key).
4. Check the visible MCP activity: it should prepare JQL when needed, call the real read tool, and stream a data-backed response. If Jira rejects the request, check its returned error and the selected tool schema. For 401/403, check your permissions rather than changing JQL.

---

<a id="doc-mcp-chat-performance-fix"></a>
### MCP_CHAT_PERFORMANCE_FIX.md

#### ELIYA21 – MCP Chat routing, performance and loader changes

##### Changed components

- `ChatService.java`: routes MCP decisions using the **original user message**, not enlarged source-code or attachment context. Emits `chat_status` before context building, during MCP operations and before regular LLM streaming. For MCP responses, forwards token callbacks to the same buffered SSE transport and persists the completed assistant response.
- `ChatMcpService.java`: uses explicit user intent, selects relevant **read-only** tools (up to 24 definitions per request), allows bounded tool calls (16) and model iterations (7), avoids an unnecessary second evidence-retrieval prompt after a successful tool call, and streams the final synthesis using the configured Chat model after the initial successful tool round. Tool errors, timeouts and exhausted budgets produce visible text instead of an indefinitely waiting Chat.
- `McpManager.java`: caches Chat discovery for 60 seconds (8 seconds after unavailable-server diagnostics), invalidates the cache when managed configuration changes or stdio tools change, and bounds foreground discovery to 15 seconds. Discovery that takes longer continues on the daemon discovery thread so a subsequent request may reuse its result. Chat read calls are bounded separately to 25 seconds. The existing Agent-side tool-discovery interface remains unchanged.
- `app.js` / `app.css`: displays a spinner, animated dots and live activity text until the first Chat token arrives. Status changes do not clear the loader. First token replaces the loader, streaming continues in the normal Markdown view. Agent UI is unchanged.

##### Expected behavior

| Request | Execution |
|---|---|
| How is Deep Search implemented? | Indexed project + Chat model; MCP is not invoked. |
| How is Jira integration implemented in our source code? | Indexed project + Chat model. |
| Read Jira PAY-123 | Jira MCP read tool(s), then streaming answer. |
| Search Confluence for the SEPA design | Confluence MCP read tool(s), then streaming answer. |
| Compare project code to Jira acceptance criteria | Indexed project + Jira MCP + Chat model. |

The current fast path synthesizes its final answer after the first successful MCP tool round. If a search result does not include enough detail for a complete answer, the model is instructed to state what evidence remains missing. A request may invoke multiple independent tools in one model round, but calls within that round are executed sequentially to avoid overloading servers. MCP discovery timing and actual model latency remain dependent on the connected servers and provider.

##### Adjustable Java system properties (optional)

- `-Deliya.chat.mcp.discoveryTimeoutMillis=15000` – foreground discovery limit in milliseconds, clamped to 2000–60000.
- `-Deliya.chat.mcp.toolTimeoutMillis=25000` – each Chat MCP read limit in milliseconds, clamped to 2000–120000.

Server configuration and Agent mode retain their existing behaviors. When a foreground discovery limit is reached, the tool list is not fabricated: Chat reports a discovery-in-progress diagnostic and the user can retry.

##### Validation performed here

1. Offline Java 17 isolated compile + behavior test of modified `ChatMcpService`, with controlled MCP and LLM doubles: **PASS** (local routing, external routing, read-only exposure, loading events, first tool round, genuine streaming token callbacks).
2. Node JavaScript parser: **PASS** (`node --check` on `app.js`).
3. Node Chat loader behavior test: **PASS** (spinner survives progress events and disappears on the first token).
4. Existing standalone deletion-approval / protected-snapshot smoke test: **PASS**.
5. Existing UI/API source contracts: **11 PASS**.
6. Existing Spring constructor source contract: **PASS**.
7. Existing vision-adapter standalone smoke test: **PASS**.
8. `javac` parser checks of modified `McpManager` and `ChatService`: no Java syntax errors detected; their full type-check/build cannot be completed here because Maven, Spring, Jackson and the other runtime dependencies are not installed or cached.

###### Build on a machine with Maven dependency access

```bash
mvn -B -DskipTests package
#### To run the optional full test profile:
mvn -B -Pfull-tests test
java -jar target/eliya.jar
```

**Delivery scope:** updated source project and offline test scripts. A compiled, fully integration-tested runnable JAR is *not* included, because the required Maven dependency artifacts are unavailable in this execution environment. Live verification against your Jira/Confluence MCP endpoint and model must be performed in the deployment environment. The code does not claim to guarantee a response-time SLA for inaccessible or slow external providers.

---

<a id="doc-named-references-implementation"></a>
### NAMED_REFERENCES_IMPLEMENTATION.md

#### Named reference folders — implementation and validation

##### User flow

1. Choose **Browse reference** or **Reference path**, then enter a unique prompt name such as `LegacySelenium`.
2. The selected folder is indexed using the existing local indexing mechanism. The name is saved with the read-only reference in browser storage shared by Chat and Agent and preserved across conversations.
3. Click the pencil icon on a reference chip to rename it. Renaming does not recreate the index or change the folder path.
4. Prompt by name, e.g. `Use LegacySelenium for migration patterns and Requirements for missing cases. Apply changes only to the active project.`

##### Runtime behavior

- The UI sends both the selected project IDs and a project-ID-to-name mapping. Server validation ensures referenced IDs are selected, names are unique simple identifiers, and a reference cannot be named `workspace`.
- Chat retrieves the named sources when the user names one or more references, and includes the name in the evidence heading. If none are named, selected reference retrieval retains previous broad-search behavior.
- Agent appends the named reference-to-physical-path mapping to the effective run prompt. Resource resolution preserves the explicit read-only role and assigns the lowercase prompt name as its resource alias, e.g. `@legacyselenium`.
- The selected reference label takes precedence over a less restrictive label for the same physical path, preventing promotion to a writable secondary project through a duplicate path line. This does not sandbox arbitrary shell commands.
- Existing unnamed references loaded from previous browser storage receive a sanitized folder-based default. User-specified aliases do not change the underlying project/index ID.

##### Validation

- Node UI test suite: project selection, named reference persistence, rename without reindex, duplicate-name protection, reference separation and existing deletion-approval controls.
- Java 17 isolated compilation: `ChatRequest` and `PromptResourceResolver`; isolated execution: named alias resolution, read-only status, physical path matching, and priority of the read-only named label over an earlier differently labelled path.
- Full Maven/Spring Boot compilation and application integration tests **not completed** in this environment because Maven/dependencies were unavailable. Do not treat this source ZIP as a verified executable JAR.

---

<a id="doc-portable-database-fix"></a>
### PORTABLE_DATABASE_FIX.md

#### ELIYA portable database fix (Windows / macOS / Linux)

##### Root cause

Spring Boot's default datasource configuration can be overridden by host environment
variables such as `SPRING_DATASOURCE_DRIVER_CLASS_NAME=oracle.jdbc.OracleDriver`.
A developer running the very same JAR on another machine can therefore get
`Cannot load driver class: oracle.jdbc.OracleDriver`, followed by a Hibernate
`Unable to determine Dialect without JDBC metadata` error if only the driver
property is overridden.

##### Fix

- `PortableDatabaseConfiguration` defines an **application-owned**, primary H2
  datasource. Spring Boot backs off from creating its generic datasource, and
  host `SPRING_DATASOURCE_*` settings cannot silently change the driver, URL,
  username or password.
- Hibernate dialect is pinned to H2 in both app configuration and a Hibernate
  properties customizer.
- Database files remain at the existing `app.database.path`, which normally
  resolves to `<user-home>/.advanced-ai-workbench/data/chatdb` on all supported
  operating systems. This preserves the user's local history across JAR upgrades.
- The database parent folder is created when needed. Directory permission
  problems fail with an actionable message instead of a generic JDBC error.
- H2 is packaged as a runtime dependency in `pom.xml`, unchanged.
- No UI, chat, agent, workspace or file-deletion behavior was modified.

##### Developer instructions

With Java 17+ available, run **the same built JAR** on any of the three OSes:

```sh
java -jar eliya.jar
```

No JDBC drivers, database server or per-machine datasource arguments are needed.

A user who intentionally needs a different *H2 storage path* can set the
application-specific JVM option `-Dapp.database.path=/path/to/chatdb` before
`-jar` (do not use `SPRING_DATASOURCE_URL`). Do not delete existing database
files when upgrading. Avoid starting multiple concurrent ELIYA copies against
one profile without coordinating access.

##### Verification

`PortableDatabaseConfigurationTest` injects Oracle URL/driver/username and
Oracle JPA dialect into an isolated Spring application context, then confirms
that ELIYA still connects to H2, uses the H2 dialect, and persists the DB.

To run on a machine with Maven/Java and dependency access:

```sh
./mvnw clean package
./mvnw -Pfull-tests test
java -jar target/eliya.jar
```

---

<a id="doc-portable-database-validation-report"></a>
### PORTABLE_DATABASE_VALIDATION_REPORT.md

#### Portable database validation report

##### Tests completed in this environment

- PASS: Java source for `PortableDatabaseConfiguration` compiled with `javac 21`
  against minimal Hikari/Spring API stubs. This validates the new class's
  Java syntax and basic API contracts, **not** the production Spring/H2 linkage.
- PASS: Offline execution of the new datasource class with test doubles:
  unrelated Oracle driver/URL system properties were ignored; H2 URL, driver,
  credentials and dialect were selected; parent directory was created; paths
  with spaces worked; invalid directory failed with a clear message.
- PASS: Frontend `app.js` and `markdown.js` syntax checked with Node.
- PASS: `application.properties` has an H2 JPA dialect, no bindable
  `spring.datasource.*` properties, and retains the previous port 8090.
- ADDED (not executed here): Spring Boot integration regression test,
  `PortableDatabaseConfigurationTest`, uses a real H2 connection while Oracle
  settings are supplied via Spring's environment.

##### Remaining release checks (required on a build machine)

The environment has no Maven, Maven dependency cache or network access to
Maven Central; **a full Maven compile, integration test, running JAR, or actual
Mac/Windows startup test could not be performed here**.

Run these commands on a build machine with Java 17+ and Maven access:

```sh
./mvnw clean package
./mvnw -Pfull-tests test
java -jar target/eliya.jar
```

On Windows use `mvnw.cmd` in place of `./mvnw`. Copy the *resulting* same JAR
to a Mac and validate it starts with `java -jar eliya.jar` without flags even
when unrelated `SPRING_DATASOURCE_*` variables are defined.

---

<a id="doc-shared-folders-implementation-and-validation"></a>
### SHARED_FOLDERS_IMPLEMENTATION_AND_VALIDATION.md

#### Shared folder selection and automatic code indexing

##### What changed

- Both **Chat** and **Agent** now display the same **SHARED FOLDERS** controls above the composer.
- **Browse project** opens the operating system's native directory picker using Java Swing on the same desktop on which the ELIYA JVM runs. **Enter path** is available when ELIYA runs headlessly or the system cannot show a chooser. Paths must refer to the Java process's own filesystem; browser security prevents an ordinary web directory upload from revealing a reliable absolute path.
- **Browse reference** / **Reference path** can add up to five reference folders. Reference selection is persisted separately from the active writable project, survives conversation and mode changes, and can be removed with ×. In Agent mode reference folders are exposed through resolver-issued **read-only** resource aliases; this does not turn them into writable workspaces. Local program/shell access is not an OS sandbox: users should enable appropriate permissions for untrusted commands.
- Project and reference folder selection calls the existing project indexing pipeline and also builds/refres​hes the in-memory lexical code-retrieval index. Chat receives query-relevant code snippets from the selected project and reference projects. Agent continues to use its full workspace tools and now also receives selected reference paths as explicit read-only resources. If no project is selected, Agent's pre-existing MCP/document-only mode remains available.
- The selected project is shared across existing/new chats and both modes, as before. Selections are browser-specific; project file indexes live in the pre-existing H2 database, while the fast retrieval index is in process memory and rebuilt on selection or first retrieval after restarting ELIYA. **Rescan** refreshes both primary-project indexes after external changes.
- Built-in secret filenames (`.env`, private keys and keystores) and build/vendor/cache folders are excluded from the new lexical code index. Retrieved snippets get basic key/token/password/Bearer redaction. Existing project-index redaction remains in place.

##### Using it

1. Start ELIYA on your computer with Java 17; open its local application in a browser.
2. Select **Browse project** and choose your source code folder. Leave the picker open until you have selected a directory and the UI displays the indexed-file count. If the native picker is unavailable, use **Enter path** with a local absolute directory path.
3. Optionally add one or more **Browse reference** paths. A chip under the buttons lists each read-only reference. Ask Chat about code, architecture or tests, or switch to Agent and ask for analysis or permitted changes. No need to paste the project path again.
4. Press **Rescan** for source changes performed outside ELIYA's agent or after selecting different branches. For images and documents requiring visual interpretation, use the separate **Analyse Workspace** workflow with a configured vision model.

##### Boundaries

- Local project DB indexing currently caps at 3,000 text files / 30 million extracted text characters. The separate lexical retrieval index defaults to 16,000 supported code/config/text files (50,000 scanned files, maximum directory depth 12 and 192 KB per source file); Java system properties can tune the lexical limits. A repository can be larger than either index. Retrieval sends only a bounded selection of relevant evidence to the model; it cannot guarantee answers to every question about unseen files. Agent's live read/search tools can inspect files outside the bounded preloaded Chat context.
- References are read-only through ELIYA's managed resource tools; unrestricted external shell/scripts are **not** fully sandboxed. Use OS permissions and the existing deletion/command approvals where applicable.
- Swing desktop picker requires a graphical desktop session and local ELIYA backend. Remote/headless deployments must use **Enter path** with a path that exists on the backend machine.

##### Validation performed here

- `node --check src/main/resources/static/app.js` — passed.
- `node --test src/test/js/*.js` — passed (shared folder project/reference flows plus existing deletion-approval UI).
- Java 17 **isolated** source compilation passed for `WorkspaceRetrievalIndexService`, `PromptResourceResolver`, `LocalFolderPickerController` and `ChatRequest` with narrowly scoped framework stubs. Isolated execution validated retrieval, refreshed indexing, hidden-secret exclusion and read-only Agent resource routing.
- Full Maven/Spring Boot compile and Java unit suite were **not run**: Maven is not preinstalled in this sandbox and `./mvnw` could not resolve `repo.maven.apache.org` to install Maven. **No runnable JAR is claimed or included.** On a machine with Maven/dependency access, run `./mvnw -Pfull-tests clean verify`; the executable JAR is generated at `target/eliya.jar` if all checks pass.

---

<a id="doc-spring-startup-boot-fix"></a>
### SPRING_STARTUP_BOOT_FIX.md

#### ELIYA Documentation Intelligence - Spring Startup Boot Fix

##### Reported failure
Application startup failed while Spring created the bean chain:
`ChatController -> AgentService -> DocumentationIntelligenceService`.
The root cause shown in the startup stack trace was:
`Failed to instantiate DocumentationIntelligenceService: No default constructor found`.

##### Root cause
`DocumentationIntelligenceService` intentionally has two constructors:
1. the production constructor accepting Spring's `ObjectMapper`, and
2. a package-private constructor accepting `ObjectMapper + storePath` for deterministic tests/custom storage.

With more than one constructor and no explicitly selected injection constructor, Spring did not know which constructor should be used and fell back to looking for a default constructor, which does not exist.

##### Fix
The production constructor is now explicitly marked with Spring `@Autowired`:

```java
@Autowired
public DocumentationIntelligenceService(ObjectMapper objectMapper) {
    this(objectMapper, System.getProperty("advanced.ai.documentationStore", "./data/documentation-runs"));
}
```

The package-private constructor remains available for tests and does not participate in Spring injection.

##### Regression protection
`DocumentationIntelligenceServiceTest` now contains a regression test asserting that the public `ObjectMapper` constructor is explicitly annotated with `@Autowired`.

##### Validation performed here
- Java 17 isolated compile of `DocumentationIntelligenceService` with minimal dependency stubs: PASS.
- Reflection boot-wiring check: PASS; exactly one constructor is marked for Spring injection.
- Source diff confirms the production change is limited to constructor wiring plus the regression test.

##### Environment limitation
A complete Maven/Spring Boot build cannot be executed in this sandbox because Maven is not installed and Maven Central DNS/bootstrap access is unavailable. On a normal development machine, run:

```bash
./mvnw clean package
./mvnw -Pfull-tests test
java -jar target/eliya.jar
```

The original failure occurs during Spring bean construction, so successful application startup is the most important verification after rebuilding the JAR.

---

<a id="doc-workspace-chat-overview-fix"></a>
### WORKSPACE_CHAT_OVERVIEW_FIX.md

#### ELIYA21 — Local workspace/Chat overview fix

##### Reproduction

Register a local workspace using Browse or Enter path, wait until 87 files are indexed, then ask Chat: "Can you check how the attached project works?"

##### Confirmed defects

1. `ProjectService.dto()` returned `0` for local indexed characters by design even when the in-memory lexical index held file excerpts. This produced the misleading `87 files · 0 indexed chars` UI.
2. `WorkspaceRetrievalIndexService.retrieveCachedRoot()` required matching non-stopword search terms. Generic project questions ("how does this project work?") had no hits and returned an empty string, causing the model to report no project context.
3. When project-context retrieval raised an exception, `ContextService` discarded the exception and silently sent no project evidence to the model.

##### Changes

- Track and expose nonzero cached **sampled** character counts in `IndexStats`, project DTO and index-status response. Label this metric honestly in the UI as `indexed sample chars` (the index is deliberately bounded, not a full byte-for-byte source copy).
- For broad overview and zero-hit questions, provide a cached file tree plus bounded excerpts of README, build/configuration files and source entry points; preserve targeted lexical retrieval for specific code questions.
- Explicitly distinguish an active local workspace from a chat attachment in model context. Missing/empty indexes and retrieval errors now result in a clear status message instead of silently disappearing.
- Keep indexing asynchronous and use cached samples for overview construction: the Chat servlet never starts an extra repository scan. Existing folder picker performance changes remain intact.
- Updated browser polling to refresh the file count and sampled-character count after indexing finishes, and to report a folder with zero eligible files.

##### Validation

- `node --check src/main/resources/static/app.js` — passed.
- `node --test src/test/js/*.test.js` — all 8 browser/approval tests passed.
- Java 17 smoke compilation of the actual modified retrieval class using minimal dependency stubs — passed.
- Java 17 retrieval smoke cases (registered folder, nonzero sampled chars, generic overview, precise symbol retrieval, unmatched-query fallback) — passed.
- Added `WorkspaceRetrievalIndexOverviewTest` with JUnit regression cases for the complete Maven environment.

**Limitations:** No full Maven dependency installation is available in this container, so a complete Maven build and end-to-end real LLM/Windows/macOS smoke test have **not** been performed. This archive is source code, not a newly built JAR. Rebuild the project and restart ELIYA; refresh the browser (Ctrl+F5) so the updated UI is loaded. If a restored project is not yet Ready, wait for the index to finish before asking Chat about it.



### ELIYA27: editable visual components and layout safeguards

ELIYA27 extends `presentation_create` without changing the existing Agent, Chat, MCP, workspace or reference-alias interfaces. Existing prompts with only `title`, `bullets` and `templateSlide` remain valid. For one richer **native editable visual per slide**, add:

- `"chart":{"type":"column","labels":["Jan","Feb"],"series":[{"name":"Passed","values":[80,95]},{"name":"Failed","values":[5,2]}]}`. Types: `bar`, `column`, `stacked_bar`, `stacked_column`, `line` (1–7 categories, 1–4 series). Bars, labels, legend, data points and connectors are individually editable PowerPoint shapes. They are **not** Excel-data-linked PowerPoint charts. Unsupported pie, donut, 3D and similar charts fail explicitly; no silent screenshot fallback.
- `"table":{"headers":["System","Count"],"rows":[["API","100"],["UI","45"]]}`. Adds a fully editable PowerPoint table (up to 7 columns and 9 data rows).
- `"diagram":{"type":"flow","nodes":["Kafka","Flink","Elasticsearch"]}`. Types: `flow`, `timeline`, `cycle` (2–6 nodes). Diagrams consist of editable PowerPoint shapes and connectors; they are not native Microsoft SmartArt.

Supply only one of `chart`, `table` or `diagram` in each slide object. Original charts/tables and text-bearing grouped drawings are removed from cloned slides so **old data is not carried forward**; relevant replacement content must be supplied. Reference images are retained and explicitly flagged for checking, because the tool cannot infer whether a particular photo/diagram is merely decorative. The reference presentation remains read-only and is never overwritten.

**Layout repair** is deliberately bounded: the generator resizes/repositions the title/body boxes, auto-fits font sizes and rejects content that would become too small or overflow. It does not claim to redesign arbitrary author-created PowerPoint layouts. Structural validation checks titles, bullet contents, table values, chart legends/categories, diagram nodes, bounds and probable text-box collisions.

**Visual checks:** `presentation_preview` uses LibreOffice when available to render slides to PNG/PDF, verify page count and flag near-blank output (`AUTO_CHECK_PASS_REVIEW_REQUIRED`). Without LibreOffice, Apache POI attempts cross-platform Java2D PNG rendering (`JAVA_RENDER_REVIEW_REQUIRED`); if neither renderer works, the tool reports `UNAVAILABLE`. A `preview-report.json` is saved beside preview assets in `.eliya-presentation-previews/<deck-name>/`. These machine checks do **not** prove professional aesthetic quality, precise PowerPoint fidelity, or brand compliance. Examine each preview in a vision-capable workflow or PowerPoint. Complete Java build and slide-rendering tests must be run in a dependency-enabled Java 17 environment; the JavaScript/syntax checks alone do not establish binary compatibility.

## Presentation Intelligence — reference-based editable PowerPoint (ELIYA26)

This additive feature leaves existing Chat, Agent, MCP, workspace, reference-path and approval flows unchanged. It provides five Agent tools, already in the built-in tool catalog:

- `presentation_source_extract(sourceAlias, sourcePath?, maxChars?)`: use Apache Tika to extract bounded source text from DOCX/PDF/PPTX and other supported document types by their registered alias. This does not interpret embedded images or diagrams; use Eliya’s existing vision/document-analysis flow for those.
- `presentation_inspect(templateAlias, templatePath?)`: read the slide geometry and visual/text-frame inventory of a model `.pptx`. Use `resource_catalog` to obtain aliases. Omit `templatePath` for a standalone PPTX reference; use a relative path for a reference directory. `templateAlias=workspace` also accepts a workspace-relative path.
- `presentation_create(templateAlias, templatePath?, outputPath, slides, overwrite=false)`: select a 1-based reference `templateSlide` for each item in the `slides` array. Each item contains an editable `title` and an optional `bullets` array. The generated deck retains the source deck's page dimensions, slide masters, theme, available logos/decorative shapes and native PowerPoint components. It replaces reference narrative with editable text and performs a structural QA check *before* publishing the file to the active writable workspace. The sidecar `<outputPath>.quality.json` includes warnings and distinguishes structural QA from visual review. Existing outputs are never replaced without `overwrite=true`. Reference files are never edited.
- `presentation_validate(outputPath)`: reopen and check the output for slide count, missing editable text, out-of-bounds text boxes, approximate text overflow and overlapping text frames. It cannot guarantee visual fidelity or correctness of externally supplied facts.
- `presentation_preview(outputPath)`: if LibreOffice/soffice is installed, render a PDF and per-slide PNG previews to `.eliya-presentation-previews/<basename>` for inspection. On systems without LibreOffice, this tool reports `UNAVAILABLE` and the user must inspect the PPTX visually in PowerPoint. The output report must not claim visual validation unless the slides have actually been reviewed.

Example Agent instruction: `Workspace path: C:\Presentations\Output. Reference path: C:\References; alias: SlidesDesign; templatePath: Corporate.pptx. Content: @SlidesContent. Create 10 editable slides at review.pptx using SlidesDesign. Inspect the reference, produce a slide plan, select a templateSlide for each slide, generate, validate and preview; report any limitations.`

**Practical limits:** model references must be editable `.pptx` rather than PDFs or flattened slide images. Slide-generation layouts containing existing charts or tables are rejected to avoid accidentally carrying obsolete data. Existing grouped drawings and pictures are retained as reference assets and flagged for review. Very dense slides are rejected or warned about instead of silently shrinking text to unreadable sizes. This is an initial template-first generation engine, not a guarantee of pixel-identical design or semantically perfect replacement of arbitrary SmartArt and embedded objects. LibreOffice is an optional preview dependency and is not bundled with the JAR.


### Building / validating this source package

Run `./mvnw -Pfull-tests -Dmaven.test.skip=false clean verify` (or `mvn -Pfull-tests -Dmaven.test.skip=false clean verify` with Maven installed) with Java 17+ and dependency access. The dedicated `PresentationIntelligenceServiceTest` and `PresentationWorkspaceSafetyTest` check native PPTX creation, preservation of reference content, relative-path confinement, no implicit overwriting and structural QA. Run the existing Node UI suite using `node --test src/test/js/*.test.js`. Open the generated PPTX in PowerPoint and review the slide previews to complete the visual QA gate. This source distribution does not bundle a built JAR or LibreOffice.
