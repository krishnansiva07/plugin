package com.llmart.llm;

import com.llmart.llm.config.AppPathResolver;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LlmApplication {
    public static void main(String[] args) {
        AppPathResolver.initializeSystemProperties(LlmApplication.class);
        SpringApplication.run(LlmApplication.class, args);
    }
}
