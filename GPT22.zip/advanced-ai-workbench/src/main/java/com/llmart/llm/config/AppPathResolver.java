package com.llmart.llm.config;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Resolves portable application-owned paths.
 * <p>
 * When running from a packaged jar, all writable data should live beside the jar,
 * so users can move the application folder anywhere and run it without editing
 * any paths. When running from an IDE or exploded classes, we fall back to the
 * current working directory for developer convenience.
 */
public final class AppPathResolver {

    private AppPathResolver() {
    }

    public static Path resolveApplicationRoot(Class<?> applicationClass) {
        try {
            URL location = applicationClass.getProtectionDomain().getCodeSource().getLocation();
            if (location != null) {
                Path codeSourcePath = Paths.get(location.toURI()).toAbsolutePath().normalize();
                if (Files.isRegularFile(codeSourcePath)) {
                    return safeCreateDirectories(codeSourcePath.getParent());
                }
                String normalized = codeSourcePath.toString().replace('\\', '/');
                if (normalized.endsWith("/target/classes") || normalized.endsWith("/build/classes/java/main")) {
                    Path parent = codeSourcePath.getParent();
                    if (parent != null) {
                        Path maybeProjectRoot = parent.getParent();
                        if (maybeProjectRoot != null) {
                            return safeCreateDirectories(maybeProjectRoot.toAbsolutePath().normalize());
                        }
                    }
                }
                return safeCreateDirectories(codeSourcePath);
            }
        } catch (URISyntaxException | RuntimeException ignored) {
            // Fall through to working directory fallback.
        }
        return safeCreateDirectories(Paths.get("").toAbsolutePath().normalize());
    }

    public static void initializeSystemProperties(Class<?> applicationClass) {
        Path appRoot = resolveApplicationRoot(applicationClass);
        Path dataDir = safeCreateDirectories(appRoot.resolve("data"));
        Path logsDir = safeCreateDirectories(appRoot.resolve("logs"));
        Path cacheDir = safeCreateDirectories(appRoot.resolve("cache"));
        Path uploadsDir = safeCreateDirectories(dataDir.resolve("uploads"));
        Path agentCacheDir = safeCreateDirectories(dataDir.resolve("agent-cache"));
        Path agentRunStoreDir = safeCreateDirectories(dataDir.resolve("agent-runs"));

        setIfMissing("app.root", appRoot.toString());
        setIfMissing("app.data-dir", dataDir.toString());
        setIfMissing("app.logs-dir", logsDir.toString());
        setIfMissing("app.cache-dir", cacheDir.toString());
        setIfMissing("app.database.path", dataDir.resolve("chatdb").toString());
        setIfMissing("app.upload-dir", uploadsDir.toString());
        setIfMissing("app.agent-cache-dir", agentCacheDir.toString());
        setIfMissing("advanced.ai.agentRunStore", agentRunStoreDir.toString());
    }

    private static void setIfMissing(String key, String value) {
        String existing = System.getProperty(key);
        if (existing == null || existing.isBlank()) {
            System.setProperty(key, value);
        }
    }

    private static Path safeCreateDirectories(Path path) {
        try {
            Files.createDirectories(path);
        } catch (Exception ignored) {
            // Best effort only; actual startup will fail later if the path is unusable.
        }
        return path.toAbsolutePath().normalize();
    }
}
