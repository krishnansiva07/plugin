package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ELIYA147: evidence-backed test-result ledger for Agent runs.
 * Only completed test-runner tool events count. A model statement, read-only
 * inspection, command exit zero without a test summary, or a browser click
 * cannot create a passing-test claim. One record per actual completed runner.
 */
final class AgentTestOutcomeEvidence {
    private static final int MAX_RUNS = 18;
    private static final Pattern REQUEST = Pattern.compile(
            "(?i)\\b(?:run|execute|rerun|perform|launch|start)\\b.{0,75}\\b(?:tests?|" +
            "testcases?|test.cases?|scenarios?|specs?)\\b");
    private static final Pattern RUNNER_COMMAND = Pattern.compile(
            "(?i)(?:\\b(?:mvn|mvnw|gradle|gradlew)(?:\\.cmd|\\.bat)?\\b[^\\n]{0,140}\\b(?:test|verify|check|integrationTest)\\b|" +
            "\\b(?:npm|pnpm|yarn|bun)\\s+(?:run\\s+)?(?:test|check|spec)(?:\\b|:)|" +
            "\\b(?:npx|pnpm\\s+exec|yarn)\\s+(?:playwright|jest|vitest|cypress)\\b|" +
            "\\b(?:pytest|nosetests|jest|vitest|cucumber|playwright\\s+test)\\b|" +
            "\\bnode\\s+--test\\b|\\b(?:go\\s+test|dotnet\\s+test|cargo\\s+test)\\b)");
    private static final Pattern RUNNER = Pattern.compile("(?i)(?:^test$|^resource_test$|^mcp__.*(?:run|execute).*(?:test|spec).*|^mcp__.*(?:test|spec).*(?:run|execute).*)");
    private static final Pattern EXIT = Pattern.compile("(?:^|[;\\s])exitCode\\s*=\\s*(-?\\d+)\\s*;?");
    private static final Pattern SUREFIRE = Pattern.compile("(?i)Tests run:\\s*(\\d+)\\s*,\\s*Failures:\\s*(\\d+)\\s*,\\s*Errors:\\s*(\\d+)\\s*,\\s*Skipped:\\s*(\\d+)");
    private static final Pattern TESTNG = Pattern.compile("(?i)Total tests run:\\s*(\\d+)\\s*,\\s*Passes:\\s*(\\d+)\\s*,\\s*Failures:\\s*(\\d+)\\s*,\\s*Skips:\\s*(\\d+)");
    private static final Pattern JEST = Pattern.compile("(?im)^\\s*Tests:\\s*(?:(\\d+)\\s+failed,?\\s*)?(?:(\\d+)\\s+skipped,?\\s*)?(?:(\\d+)\\s+passed,?\\s*)?(\\d+)\\s+total\\b");
    private static final Pattern TAP = Pattern.compile("(?m)^\\s*#\\s*(tests|pass|fail|skipped)\\s+(\\d+)\\s*$");
    private static final Pattern PYTEST = Pattern.compile("(?im)(?:^|[= ])(\\d+)\\s+passed\\b(?:[^\\n]{0,120})");
    private static final Pattern PYTEST_FAILED = Pattern.compile("(?i)\\b(\\d+)\\s+failed\\b");
    private static final Pattern PYTEST_SKIPPED = Pattern.compile("(?i)\\b(\\d+)\\s+skipped\\b");
    private static final Pattern NO_TESTS = Pattern.compile("(?i)\\b(?:no tests? found|no tests? executed|no tests? were run|0 tests? (?:run|executed|passed)|0 passing|test files? not found)\\b");
    private static final Pattern SUMMARY = Pattern.compile("(?i)\\b(\\d+)\\s+(passed|failed|skipped|pending)\\b");
    private static final Pattern ACCEPTANCE_ID = Pattern.compile("(?i)\\b(?:AC|FR|NFR|TC|REQ)-[A-Z0-9]+(?:-[A-Z0-9]+)*\\b");
    private static final Pattern MANUAL = Pattern.compile("(?im)^.{0,80}(?:NOT APPLICABLE|NOT EXECUTED|MANUAL (?:TEST|CHECK)|BROWSER.*(?:PENDING|UNAVAILABLE)).{0,120}$");
    private static final Pattern ANSI = Pattern.compile("\\u001B\\[[0-9;]*[a-zA-Z]");
    private static final Pattern FAILURE_LINE = Pattern.compile("(?i)\\b(?:assertionerror|assertion failed|expected\\s*:|actual\\s*:|caused by:|\\[ERROR\\]|FAILED\\s+\\S|tests? failed)\\b");

    record TestRun(String tool, String command, String state, int passed, int failed,
                   int skipped, boolean countsKnown, String evidence, List<String> acceptanceIds,
                   List<String> manualChecks, List<String> failureLines) { }

    private final boolean requested;
    private final List<TestRun> runs = new ArrayList<>();
    private int omitted;

    AgentTestOutcomeEvidence(String objective) {
        requested = objective != null && REQUEST.matcher(objective).find();
    }

    boolean requested() { return requested; }
    boolean observed() { return !runs.isEmpty(); }
    boolean hasConfirmedRunner() {
        return runs.stream().anyMatch(r -> r.countsKnown() && r.passed() + r.failed() + r.skipped() > 0 &&
                (r.state().equals("PASSED") || r.state().equals("FAILED")));
    }

    /** Only the newest result per identical test command decides whether a rerun resolved it. */
    boolean hasFailedTests() {
        return latestRuns().stream().anyMatch(r -> r.failed() > 0 || r.state().equals("FAILED"));
    }

    private List<TestRun> latestRuns() {
        Map<String,TestRun> byCommand = new LinkedHashMap<>();
        for (TestRun r : runs) byCommand.put(r.tool() + "|" + r.command(), r);
        return List.copyOf(byCommand.values());
    }

    void observe(Map<String,Object> event) {
        if (event == null) return;
        String status = String.valueOf(event.getOrDefault("status", "")).toLowerCase(Locale.ROOT);
        if (!status.equals("success") && !status.equals("error")) return;
        String tool = String.valueOf(event.getOrDefault("tool", "")).toLowerCase(Locale.ROOT);
        String args = String.valueOf(event.getOrDefault("args", ""));
        String command = commandFromArgs(args);
        boolean runner = RUNNER.matcher(tool).matches();
        if ((tool.equals("bash") || tool.equals("resource_bash")) && RUNNER_COMMAND.matcher(command).find()) runner = true;
        if (!runner) return;
        if (runs.size() >= MAX_RUNS) { omitted++; return; }
        String output = ANSI.matcher(String.valueOf(event.getOrDefault("output", ""))).replaceAll("");
        String detail = String.valueOf(event.getOrDefault("detail", ""));
        // Some UI events clip stdout; this ledger is deliberately a conservative view.
        TestCounts counts = counts(output);
        Matcher exit = EXIT.matcher(output);
        boolean knownExit = exit.find();
        int exitCode = knownExit ? Integer.parseInt(exit.group(1)) : Integer.MIN_VALUE;
        boolean noTests = NO_TESTS.matcher(output).find() || (counts.known && counts.total() == 0);
        boolean bad = status.equals("error") || (knownExit && exitCode != 0) || counts.failed > 0;
        boolean credibleSuccess = !bad && !noTests && counts.known && counts.total() > 0 &&
                (knownExit && exitCode == 0 || tool.startsWith("mcp__") && status.equals("success"));
        String state = noTests ? "NO_TESTS" : bad ? "FAILED" : credibleSuccess ? "PASSED" : "UNVERIFIED";
        List<String> ids = matches(ACCEPTANCE_ID, output, 24);
        List<String> manual = matches(MANUAL, output, 6);
        List<String> failureLines = bad ? failureLines(output) : List.of();
        String proof = knownExit ? "exitCode=" + exitCode : "exit code not captured";
        if (counts.known) proof += "; runner summary parsed";
        else proof += "; no parseable test counts";
        if (!detail.isBlank() && bad) proof += "; " + clip(detail, 120);
        runs.add(new TestRun(tool, clip(command.isBlank() ? tool : command, 220), state,
                counts.passed, counts.failed, counts.skipped, counts.known, proof, ids, manual, failureLines));
    }

    /** True only if a test action was requested and no real runner observation supports completion. */
    boolean missingExecutionEvidence() {
        return requested && !hasConfirmedRunner();
    }

    String report() {
        if (!requested && !observed()) return "";
        StringBuilder out = new StringBuilder("## Integration / automated test evidence\n\n");
        if (runs.isEmpty()) {
            return out.append("**Not verified:** no completed test-runner tool call was recorded. " +
                    "A source inspection, model claim or browser interaction is not a test execution.\n\n" +
                    "**Next action:** run the configured project test command and capture its exit code and runner summary.").toString();
        }
        int passed = 0, failed = 0, skipped = 0;
        boolean anyCounts = false;
        Set<String> observedIds = new LinkedHashSet<>();
        Set<String> manual = new LinkedHashSet<>();
        // A rerun of the same command replaces its earlier count, but its history
        // is retained in the detailed run table. Distinct suites can still overlap.
        for (TestRun r : latestRuns()) {
            if (r.countsKnown()) {
                anyCounts = true;
                passed += r.passed(); failed += r.failed(); skipped += r.skipped();
            }
            observedIds.addAll(r.acceptanceIds());
            manual.addAll(r.manualChecks());
        }
        if (hasFailedTests()) out.append(missingExecutionEvidence()
                ? "**Automated result: test command failure; no executed test-case count verified.**\n\n"
                : "**Automated result: FAILED on the latest recorded run of at least one suite.**\n\n");
        else if (missingExecutionEvidence()) out.append("**Automated result: NOT VERIFIED.**\n\n");
        else out.append("**Automated result: recorded runner execution passed; acceptance coverage is a separate check.**\n\n");
        if (runs.size() > latestRuns().size())
            out.append("Earlier attempts (including failed ones) appear in the table; only each command's latest outcome contributes to the totals.\n\n");
        if (anyCounts) out.append("Runner-reported counts from the latest execution of each distinct command: **")
                .append(passed).append(" passed, ").append(failed).append(" failed, ")
                .append(skipped).append(" skipped**. Counts can overlap between reruns; they are not unique tests.\n\n");
        else out.append("**Case counts:** not established by runner output. No pass count is inferred from exit code alone.\n\n");
        out.append("| Run | Test command / runner | Outcome | Evidence |\n|---|---|---|---|\n");
        int n = 0;
        for (TestRun r : runs) out.append("| ").append(++n).append(" | `")
                .append(escape(r.command())).append("` | ").append(r.state())
                .append(" | ").append(escape(r.evidence())).append(" |\n");
        if (omitted > 0) out.append("\n").append(omitted).append(" additional runner records omitted to bound report size.\n");
        List<String> failureDetails = new ArrayList<>();
        for (TestRun r : latestRuns()) if (r.state().equals("FAILED")) {
            for (String line : r.failureLines()) if (failureDetails.size() < 8)
                failureDetails.add("- `" + escape(r.command()) + "`: " + escape(line));
        }
        if (!failureDetails.isEmpty()) {
            out.append("\n**Observed failure evidence (runner output):**\n");
            for (String line : failureDetails) out.append(line).append("\n");
        }
        if (!observedIds.isEmpty()) out.append("\n**Acceptance IDs appearing in runner logs (not a proven traceability map):** ")
                .append(String.join(", ", observedIds)).append(". Match each ID to the actual test assertion before claiming requirement coverage.\n");
        else out.append("\n**Acceptance-criteria mapping:** not established by test logs; do not assume every requirement was covered.\n");
        if (!manual.isEmpty()) {
            out.append("\n**Explicit manual / not-applicable items from runner logs:**\n");
            for (String row : manual) out.append("- ").append(clip(escape(row), 200)).append("\n");
        }
        out.append("\n**Limitations:** source inspection and passing non-test commands do not prove integration behavior; " +
                "browser-only checks, skipped tests and missing assertions remain unverified until executed. " +
                "Preserve any independent workspace verification failure reported elsewhere.\n");
        if (hasFailedTests()) out.append("\n**Next action:** inspect the failure evidence, correct the root cause, " +
                "then rerun the affected test command; do not report the behavior as passing yet.\n");
        else if (missingExecutionEvidence()) out.append("\n**Next action:** run the configured test suite and capture " +
                "an explicit test summary and process result.\n");
        else if (skipped > 0 || !manual.isEmpty()) out.append("\n**Next action:** execute or explicitly accept the outstanding " +
                "skipped/manual/browser checks; do not mark them PASS.\n");
        else out.append("\n**Next action:** review the requirement-to-assertion mapping and any " +
                "browser checks not exercised by this runner before release sign-off.\n");
        return out.toString().strip();
    }

    private record TestCounts(int passed, int failed, int skipped, boolean known) {
        int total() { return passed + failed + skipped; }
    }

    private static TestCounts counts(String text) {
        Matcher m = SUREFIRE.matcher(text);
        TestCounts latest = null;
        while (m.find()) {
            int total = toInt(m.group(1)), fail = toInt(m.group(2)) + toInt(m.group(3));
            latest = new TestCounts(Math.max(0, total - fail - toInt(m.group(4))), fail, toInt(m.group(4)), true);
        }
        if (latest != null) return latest;
        m = TESTNG.matcher(text);
        while (m.find()) latest = new TestCounts(toInt(m.group(2)), toInt(m.group(3)), toInt(m.group(4)), true);
        if (latest != null) return latest;
        m = JEST.matcher(text);
        while (m.find()) latest = new TestCounts(toInt(m.group(3)), toInt(m.group(1)), toInt(m.group(2)), true);
        if (latest != null) return latest;
        int tapTotal = -1, tapPass = -1, tapFail = -1, tapSkip = -1;
        m = TAP.matcher(text);
        while (m.find()) {
            int count = toInt(m.group(2));
            switch (m.group(1)) {
                case "tests" -> tapTotal = count;
                case "pass" -> tapPass = count;
                case "fail" -> tapFail = count;
                case "skipped" -> tapSkip = count;
                default -> { }
            }
        }
        if (tapTotal >= 0 && tapPass >= 0 && tapFail >= 0)
            return new TestCounts(tapPass, tapFail, Math.max(0, tapSkip), true);
        // pytest/Playwright concise summary: only trust it when an actual runner tool produced the line.
        m = PYTEST.matcher(text);
        while (m.find()) latest = new TestCounts(toInt(m.group(1)), 0, 0, true);
        if (latest != null) return new TestCounts(latest.passed(), firstCount(PYTEST_FAILED, text),
                firstCount(PYTEST_SKIPPED, text), true);
        // Count-only result is accepted only when it reports at least one explicit test state.
        int pass = 0, fail = 0, skipped = 0;
        boolean seen = false;
        m = SUMMARY.matcher(text);
        while (m.find()) {
            int count = toInt(m.group(1));
            switch (m.group(2).toLowerCase(Locale.ROOT)) {
                case "passed" -> { pass = count; seen = true; }
                case "failed" -> { fail = count; seen = true; }
                case "skipped", "pending" -> { skipped = count; seen = true; }
                default -> { }
            }
        }
        return new TestCounts(pass, fail, skipped, seen);
    }

    private static List<String> failureLines(String output) {
        List<String> lines = new ArrayList<>();
        for (String line : output.split("\\R")) {
            if (lines.size() >= 4) break;
            if (!FAILURE_LINE.matcher(line).find()) continue;
            String cleaned = line.strip().replaceAll("(?i)(?:bearer\\s+[A-Za-z0-9._-]+)", "Bearer [redacted]")
                    .replaceAll("(?i)(?:api[_-]?key|password|token)\\s*[:=]\\s*[^\\s,;]+", "[credential redacted]");
            if (!cleaned.isBlank()) lines.add(clip(cleaned, 250));
        }
        return List.copyOf(lines);
    }

    private static int firstCount(Pattern pattern, String text) {
        Matcher m = pattern.matcher(text);
        return m.find() ? toInt(m.group(1)) : 0;
    }
    private static int toInt(String text) {
        if (text == null) return 0;
        try { return Math.max(0, Math.min(1_000_000, Integer.parseInt(text))); }
        catch (NumberFormatException ex) { return 0; }
    }
    private static List<String> matches(Pattern pattern, String text, int limit) {
        Set<String> found = new LinkedHashSet<>();
        Matcher m = pattern.matcher(text);
        while (m.find() && found.size() < limit) found.add(m.group().trim().replace('|', '/'));
        return List.copyOf(found);
    }
    private static String commandFromArgs(String args) {
        if (args == null || args.isBlank()) return "";
        // Jackson JsonNode.toString() renders an object with a quoted command property.
        Matcher m = Pattern.compile("\\\"command\\\"\\s*:\\s*\\\"([^\\\"]{1,500})\\\"").matcher(args);
        return m.find() ? m.group(1).replace("\\\\n", " ") : args;
    }
    private static String escape(String text) {
        return text.replace('`', '\'').replace('|', '/').replace('\n', ' ').replace('\r', ' ');
    }
    private static String clip(String text, int limit) {
        if (text == null) return "";
        return text.length() <= limit ? text : text.substring(0, limit) + "…";
    }
}
