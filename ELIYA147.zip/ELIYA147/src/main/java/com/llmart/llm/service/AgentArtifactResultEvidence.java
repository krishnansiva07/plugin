package com.llmart.llm.service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * Read-only, bounded post-action evidence. A generated plan's content is the source
 * of the user-facing interpretation, not the model's earlier intention to write it.
 * The returned text is untrusted DATA for a separate, tool-free synthesis pass.
 */
final class AgentArtifactResultEvidence {
    private static final int MAX_FILES = 12;
    private static final int MAX_TOTAL_CHARS = 22_000;
    private static final int MAX_SINGLE_CHARS = 7_000;

    private AgentArtifactResultEvidence() { }

    /** Identify generated decision artefacts by actual file paths, not prompt vocabulary. */
    static boolean hasPlanningArtifacts(List<String> changedPaths) {
        if (changedPaths == null) return false;
        boolean plan = false, comparison = false;
        for (String path : changedPaths) {
            if (path == null) continue;
            String normalized = path.replace('\\', '/').toLowerCase(Locale.ROOT);
            if (normalized.matches("(?:.*/)?plan[a-z]\\.md")) plan = true;
            if (normalized.matches("(?:.*/)?(?:plan-)?comparison\\.md")) comparison = true;
        }
        return plan && comparison;
    }

    static String collect(Path workspace, List<String> changedPaths) {
        if (workspace == null || changedPaths == null || changedPaths.isEmpty()) return "";
        StringBuilder result = new StringBuilder();
        try {
            Path root = workspace.toRealPath();
            List<String> documents = new LinkedHashSet<>(changedPaths).stream()
                    .filter(path -> path != null && !path.isBlank())
                    .filter(path -> {
                        String lower = path.toLowerCase(Locale.ROOT);
                        return lower.endsWith(".md") || lower.endsWith(".markdown");
                    })
                    .sorted(Comparator.comparingInt(AgentArtifactResultEvidence::priority)
                            .thenComparing(String::compareToIgnoreCase))
                    .limit(MAX_FILES)
                    .toList();
            for (String raw : documents) {
                if (result.length() >= MAX_TOTAL_CHARS) break;
                // One unreadable/corrupt artifact must not hide all other read-back evidence.
                try {
                Path relative;
                try { relative = Path.of(raw); } catch (RuntimeException invalid) { continue; }
                if (relative.isAbsolute()) continue;
                Path candidate = root.resolve(relative).normalize();
                if (!candidate.startsWith(root)) continue;
                boolean linked = false;
                for (Path part = candidate; part != null && part.startsWith(root); part = part.getParent()) {
                    if (Files.isSymbolicLink(part)) { linked = true; break; }
                    if (part.equals(root)) break;
                }
                if (linked || !Files.isRegularFile(candidate, LinkOption.NOFOLLOW_LINKS) ||
                        !candidate.toRealPath().startsWith(root)) continue;
                long bytes = Files.size(candidate);
                if (bytes <= 0 || bytes > 256 * 1024) continue;
                byte[] data = Files.readAllBytes(candidate);
                String text;
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT)
                            .decode(ByteBuffer.wrap(data)).toString().strip();
                } catch (CharacterCodingException badUtf8) { continue; }
                if (text.isEmpty()) continue;
                int room = MAX_TOTAL_CHARS - result.length();
                if (room < 100) break;
                int limit = Math.min(MAX_SINGLE_CHARS, Math.max(0, room - raw.length() - 100));
                if (limit < 50) break;
                result.append("\n\nARTIFACT: ").append(raw.replace('`', ' '))
                        .append(" [").append(bytes).append(" UTF-8 bytes; actual read-back]\n")
                        .append(text, 0, Math.min(text.length(), limit));
                if (text.length() > limit) result.append("\n[artifact content excerpted; full file remains in workspace]");
                } catch (IOException | SecurityException unavailableArtifact) {
                    // Keep successfully read documents; never invent missing content.
                }
            }
        } catch (IOException | SecurityException unavailable) {
            return "";
        }
        return result.toString().strip();
    }

    private static int priority(String path) {
        String lower = path.replace('\\', '/').toLowerCase(Locale.ROOT);
        if (lower.endsWith("/comparison.md") || lower.endsWith("/plan-comparison.md")) return 0;
        if (lower.matches(".*/plan[a-z]\\.md")) return 1;
        if (lower.contains("/report") || lower.contains("/analysis")) return 2;
        return 3;
    }
}
