# Apache POI dependency fix

## Root cause

TCGen used Apache Tika 3.3.0 together with a directly pinned Apache POI `poi-ooxml` 5.2.5 dependency. Tika 3.3.0's Microsoft parser stack uses Apache POI 5.5.1 modules. Maven can therefore resolve a mixed POI runtime, which can fail with errors such as `NoClassDefFoundError` or `NoSuchMethodError` depending on which POI jar is loaded first on a machine.

## Fix applied

- POI core/OOXML/scratchpad/full/lite modules are pinned to 5.5.1.
- Log4j API/bridge version is aligned to 2.25.3 for the POI 5.5.1 stack.
- POI core and OOXML are explicit application dependencies.
- A compatibility test exercises XLSX creation, DOCX initialization and Tika parsing together.
- A startup verifier checks the loaded POI runtime and fails early with a clear message if an older external POI jar shadows the packaged version.
- README now instructs users to run the Spring Boot fat JAR with `java -jar` and not add external POI jars.

## Build verification command

```bash
mvn clean package -U
```

Then start only the packaged JAR:

```bash
java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar
```

Do not launch TCGen with a manually assembled classpath containing separate `poi*.jar` files.


## Additional Commons Lang runtime fix

Spring Boot 3.1.5 manages `org.apache.commons:commons-lang3` at 3.12.0 and
`commons-codec:commons-codec` at 1.15. The upgraded POI/Tika dependency family
requires newer Commons components. In particular,
`org.apache.commons.lang3.SystemProperties` was introduced in Commons Lang 3.13.0.

TCGen now explicitly pins:

- `commons-lang3` 3.20.0
- `commons-codec` 1.21.0

The startup compatibility verifier also checks that `SystemProperties` is loadable,
so an old external Commons Lang jar is detected immediately rather than failing on
the first request with `Handler dispatch failed`.
