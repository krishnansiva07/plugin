package com.llmart.llm.dependency;

import org.apache.poi.Version;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PoiDependencyCompatibilityTest {

    private static final String EXPECTED_POI_VERSION = "5.5.1";

    @Test
    void allRequiredPoiApisArePresentAndTikaCanParseGeneratedXlsx() throws Exception {
        assertEquals(EXPECTED_POI_VERSION, Version.getVersion(),
                "Unexpected Apache POI core version on the test classpath");

        // This class is absent from older POI cores and is the class that failed
        // at runtime when newer OOXML/Tika modules were mixed with an older poi jar.
        assertNotNull(Class.forName("org.apache.poi.logging.PoiLogManager"));

        // Spring Boot 3.1.5 otherwise pins commons-lang3 to 3.12.0, where
        // SystemProperties does not exist. This catches that mismatch at build time.
        assertNotNull(Class.forName("org.apache.commons.lang3.SystemProperties"));

        byte[] workbookBytes;
        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            workbook.createSheet("Compatibility")
                    .createRow(0)
                    .createCell(0)
                    .setCellValue("TCGen POI compatibility check");
            workbook.write(out);
            workbookBytes = out.toByteArray();
        }

        // Verify the Word OOXML module can initialize too.
        try (XWPFDocument ignored = new XWPFDocument()) {
            assertNotNull(ignored);
        }

        // Exercise Tika's Microsoft parser against an OOXML file so a POI/Tika
        // linkage mismatch fails during the build instead of on an end-user machine.
        AutoDetectParser parser = new AutoDetectParser();
        BodyContentHandler handler = new BodyContentHandler(-1);
        parser.parse(new ByteArrayInputStream(workbookBytes), handler, new Metadata(), new ParseContext());

        assertTrue(handler.toString().contains("TCGen POI compatibility check"));
    }
}
