package com.llmart.llm.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.net.URL;

/**
 * Fails fast with a useful message if an external/old Apache POI jar shadows
 * the version packaged with TCGen. This prevents a delayed NoClassDefFoundError
 * when a user first uploads an Excel or Word document.
 */
@Component
public class PoiRuntimeCompatibilityVerifier implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(PoiRuntimeCompatibilityVerifier.class);
    private static final String EXPECTED_POI_VERSION = "5.5.1";
    private static final String EXPECTED_COMMONS_LANG_VERSION = "3.20.0";

    @Override
    public void run(ApplicationArguments args) {
        Class<?> core = requireClass("org.apache.poi.poifs.filesystem.POIFSFileSystem", "POI core");
        Class<?> ooxml = requireClass("org.apache.poi.ooxml.POIXMLDocument", "POI OOXML");
        requireClass("org.apache.poi.logging.PoiLogManager", "POI logging API");
        Class<?> commonsLang = requireClass("org.apache.commons.lang3.SystemProperties",
                "Apache Commons Lang SystemProperties API");

        verifyVersion(core, "POI core");
        verifyVersion(ooxml, "POI OOXML");
        verifyCommonsLangVersion(commonsLang);

        log.info("Apache POI runtime verified: version {}; Commons Lang: {}",
                EXPECTED_POI_VERSION, EXPECTED_COMMONS_LANG_VERSION);
    }

    private Class<?> requireClass(String className, String component) {
        try {
            return Class.forName(className, false, Thread.currentThread().getContextClassLoader());
        } catch (ClassNotFoundException | LinkageError ex) {
            throw new IllegalStateException(
                    component + " is incompatible or missing. TCGen requires Apache POI " + EXPECTED_POI_VERSION
                            + ". Run the packaged application with 'java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar'"
                            + " and remove older external POI jars from the runtime classpath.", ex);
        }
    }

    private void verifyCommonsLangVersion(Class<?> clazz) {
        Package pkg = clazz.getPackage();
        String version = pkg == null ? null : pkg.getImplementationVersion();
        URL source = clazz.getProtectionDomain() != null && clazz.getProtectionDomain().getCodeSource() != null
                ? clazz.getProtectionDomain().getCodeSource().getLocation()
                : null;

        if (version != null && !EXPECTED_COMMONS_LANG_VERSION.equals(version)) {
            throw new IllegalStateException(
                    "Apache Commons Lang version mismatch. Expected " + EXPECTED_COMMONS_LANG_VERSION
                            + " but loaded " + version
                            + (source == null ? "" : " from " + source)
                            + ". Run only the packaged Spring Boot JAR and remove older external commons-lang3 jars.");
        }

        log.debug("Apache Commons Lang loaded from {} (implementation version: {})", source, version);
    }

    private void verifyVersion(Class<?> clazz, String component) {
        Package pkg = clazz.getPackage();
        String version = pkg == null ? null : pkg.getImplementationVersion();
        URL source = clazz.getProtectionDomain() != null && clazz.getProtectionDomain().getCodeSource() != null
                ? clazz.getProtectionDomain().getCodeSource().getLocation()
                : null;

        if (version != null && !EXPECTED_POI_VERSION.equals(version)) {
            throw new IllegalStateException(
                    component + " version mismatch. Expected " + EXPECTED_POI_VERSION + " but loaded " + version
                            + (source == null ? "" : " from " + source)
                            + ". Remove older Apache POI jars and run the Spring Boot fat JAR with java -jar.");
        }

        log.debug("{} loaded from {} (implementation version: {})", component, source, version);
    }
}
