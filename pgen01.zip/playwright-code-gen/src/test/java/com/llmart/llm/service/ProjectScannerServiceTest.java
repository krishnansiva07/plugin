package com.llmart.llm.service;

import com.llmart.llm.model.ProjectScanResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class ProjectScannerServiceTest {
    @TempDir Path temp;

    @Test
    void detectsPlaywrightTypescriptProjectAndFiles() throws Exception {
        Files.writeString(temp.resolve("package.json"), "{\"devDependencies\":{\"@playwright/test\":\"latest\"}}");
        Files.writeString(temp.resolve("playwright.config.ts"), "export default {};");
        Files.createDirectories(temp.resolve("pages"));
        Files.createDirectories(temp.resolve("tests"));
        Files.writeString(temp.resolve("pages/LoginPage.ts"), "export class LoginPage { async login() { await this.page.getByRole('button').click(); } }");
        Files.writeString(temp.resolve("tests/login.spec.ts"), "test('login', async ({ page }) => { await page.goto('/'); });");

        ProjectScannerService service = new ProjectScannerService();
        ReflectionTestUtils.setField(service, "maxFileReadChars", 25000);
        ReflectionTestUtils.setField(service, "maxScanFiles", 100);

        ProjectScanResult result = service.scan(temp.toString());
        assertTrue(result.isValidPlaywrightProject());
        assertEquals("Playwright Test", result.getTestRunner());
        assertEquals(1, result.getPageObjects().size());
        assertEquals(1, result.getSpecFiles().size());
    }
}
