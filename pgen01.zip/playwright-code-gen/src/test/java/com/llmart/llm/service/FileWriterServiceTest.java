package com.llmart.llm.service;

import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GenerateResponse;
import com.llmart.llm.model.GeneratedChange;
import com.llmart.llm.model.LlmChangeResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FileWriterServiceTest {
    @TempDir Path temp;

    @Test
    void dryRunDoesNotWrite() {
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setWriteMode("DRY_RUN");
        GeneratedChange change = new GeneratedChange();
        change.setOperation("CREATE");
        change.setFilePath("tests/new.spec.ts");
        change.setFullContent("test('x', async () => {});");
        LlmChangeResponse llm = new LlmChangeResponse();
        llm.setChanges(List.of(change));
        GenerateResponse response = new GenerateResponse();

        new FileWriterService().applyChanges(request, response, llm);
        assertFalse(Files.exists(temp.resolve("tests/new.spec.ts")));
        assertEquals(List.of("tests/new.spec.ts"), response.getFilesCreated());
    }

    @Test
    void writeCreatesFileWithoutBraceMerging() throws Exception {
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setWriteMode("WRITE");
        request.setBackupBeforeWrite(true);
        GeneratedChange change = new GeneratedChange();
        change.setOperation("CREATE");
        change.setFilePath("pages/NewPage.ts");
        change.setFullContent("export class NewPage { async open() {} }");
        LlmChangeResponse llm = new LlmChangeResponse();
        llm.setChanges(List.of(change));
        GenerateResponse response = new GenerateResponse();

        new FileWriterService().applyChanges(request, response, llm);
        assertEquals(change.getFullContent(), Files.readString(temp.resolve("pages/NewPage.ts")));
    }
}
