package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.llmart.llm.model.GenerateRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class RecordedJsonParserServiceTest {
    @TempDir Path temp;

    @Test
    void acceptsObjectJsonContent() {
        RecordedJsonParserService service = new RecordedJsonParserService();
        ReflectionTestUtils.setField(service, "maxRecordedJsonChars", 10000);
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setRecordedJsonContent("{\"steps\":[{\"action\":\"click\"}]}");

        JsonNode node = service.parse(request);
        assertTrue(node.isObject());
        assertEquals("click", node.get("steps").get(0).get("action").asText());
    }

    @Test
    void rejectsScalarJson() {
        RecordedJsonParserService service = new RecordedJsonParserService();
        ReflectionTestUtils.setField(service, "maxRecordedJsonChars", 10000);
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setRecordedJsonContent("\"hello\"");

        assertThrows(IllegalArgumentException.class, () -> service.parse(request));
    }
}
