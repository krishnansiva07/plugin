package com.llmart.llm.service;

import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GeneratedChange;
import com.llmart.llm.model.LlmChangeResponse;
import com.llmart.llm.model.ProjectScanResult;
import com.llmart.llm.model.ValidationResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PreWriteValidationServiceTest {
    @TempDir Path temp;

    @Test
    void validatesSafeFullFileUpdate() throws Exception {
        Files.createDirectories(temp.resolve("tests"));
        Files.writeString(temp.resolve("tests/a.spec.ts"), "old");
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setTargetModule("tests");

        GeneratedChange change = new GeneratedChange();
        change.setOperation("UPDATE");
        change.setFilePath("tests/a.spec.ts");
        change.setFullContent("import { test } from '@playwright/test';\ntest('a', async () => {});");
        LlmChangeResponse llm = new LlmChangeResponse();
        llm.setChanges(List.of(change));
        ProjectScanResult scan = new ProjectScanResult();
        scan.setValidPlaywrightProject(true);

        ValidationResult result = new PreWriteValidationService().validate(request, scan, llm);
        assertTrue(result.isPassed(), String.join("; ", result.getErrors()));
    }

    @Test
    void blocksTraversalAndMissingMethodsWhenDisabled() {
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(temp.toString());
        request.setGenerateMissingMethods(false);

        GeneratedChange change = new GeneratedChange();
        change.setOperation("CREATE");
        change.setFilePath("../evil.ts");
        change.setFullContent("export const x = 1;");
        LlmChangeResponse llm = new LlmChangeResponse();
        llm.setChanges(List.of(change));
        llm.setNewMethods(List.of("Page.newMethod"));
        ProjectScanResult scan = new ProjectScanResult();
        scan.setValidPlaywrightProject(true);

        ValidationResult result = new PreWriteValidationService().validate(request, scan, llm);
        assertFalse(result.isPassed());
        assertTrue(result.getErrors().stream().anyMatch(e -> e.contains("outside project") || e.contains("project-relative")));
        assertTrue(result.getErrors().stream().anyMatch(e -> e.contains("generateMissingMethods=false")));
    }
}
