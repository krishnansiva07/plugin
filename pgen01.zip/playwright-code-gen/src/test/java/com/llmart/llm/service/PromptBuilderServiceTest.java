package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.FileSummary;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.ProjectScanResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PromptBuilderServiceTest {
    @Test
    void promptHonorsRequestControlsAndRequiresFullContent() throws Exception {
        GenerateRequest request = new GenerateRequest();
        request.setUserInstruction("Generate payment flow");
        request.setTargetModule("tests/payments");
        request.setPreferredTestFile("tests/payments/pay.spec.ts");
        request.setPreferredPageObject("pages/PaymentPage.ts");
        request.setReuseExistingMethods(false);
        request.setGenerateMissingMethods(false);

        FileSummary relevant = new FileSummary();
        relevant.setRelativePath("tests/payments/pay.spec.ts");
        relevant.setType("SPEC");
        relevant.setSnippet("test('existing', async () => {});");
        ProjectScanResult scan = new ProjectScanResult();
        scan.getSpecFiles().add(relevant);

        String prompt = new PromptBuilderService().buildPrompt(request, scan,
                new ObjectMapper().readTree("{\"steps\":[]}"), List.of(relevant));

        assertTrue(prompt.contains("Target module: tests/payments"));
        assertTrue(prompt.contains("Do not reuse existing page-object action methods"));
        assertTrue(prompt.contains("Do not create new page-object/helper methods"));
        assertTrue(prompt.contains("COMPLETE final file"));
    }
}
