(() => {
    const $ = (id) => document.getElementById(id);
    const form = $('generatorForm');
    const fileInput = $('recordedJsonFile');
    const dropZone = $('dropZone');
    let selectedJsonFile = null;

    const savedModel = localStorage.getItem('playwrightCodeGen.model');
    const savedBaseUrl = localStorage.getItem('playwrightCodeGen.baseUrl');
    if (savedModel) $('modelName').value = savedModel;
    if (savedBaseUrl) $('baseUrl').value = savedBaseUrl;

    loadDefaults();
    checkService();

    $('toggleApiKey').addEventListener('click', () => {
        const field = $('apiKey');
        const show = field.type === 'password';
        field.type = show ? 'text' : 'password';
        $('toggleApiKey').textContent = show ? 'Hide' : 'Show';
    });

    $('browseJsonBtn').addEventListener('click', () => fileInput.click());
    dropZone.addEventListener('click', (event) => {
        if (event.target.closest('button')) return;
        fileInput.click();
    });
    dropZone.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            fileInput.click();
        }
    });
    fileInput.addEventListener('change', () => setSelectedFile(fileInput.files?.[0]));

    ['dragenter', 'dragover'].forEach(eventName => dropZone.addEventListener(eventName, event => {
        event.preventDefault();
        dropZone.classList.add('dragging');
    }));
    ['dragleave', 'drop'].forEach(eventName => dropZone.addEventListener(eventName, event => {
        event.preventDefault();
        dropZone.classList.remove('dragging');
    }));
    dropZone.addEventListener('drop', event => setSelectedFile(event.dataTransfer.files?.[0]));

    document.querySelectorAll('input[name="writeMode"]').forEach(radio => radio.addEventListener('change', updateMode));
    updateMode();

    $('testConnectionBtn').addEventListener('click', testConnection);
    form.addEventListener('submit', generateCode);


    async function loadDefaults() {
        try {
            const response = await fetch('/api/llm/defaults', { cache: 'no-store' });
            if (!response.ok) return;
            const defaults = await response.json();
            if (!savedModel && defaults.modelName) $('modelName').value = defaults.modelName;
            if (!savedBaseUrl && defaults.baseUrl) $('baseUrl').value = defaults.baseUrl;
            if (defaults.temperature != null && !$('temperature').dataset.userChanged) $('temperature').value = defaults.temperature;
            if (defaults.maxTokens != null && !$('maxTokens').dataset.userChanged) $('maxTokens').value = defaults.maxTokens;
        } catch (_) { }
    }

    async function checkService() {
        const pill = $('serviceStatus');
        try {
            const response = await fetch('/api/health', { cache: 'no-store' });
            const body = await response.json();
            if (response.ok && body.status === 'UP') {
                pill.className = 'status-pill success';
                pill.innerHTML = '<span class="dot"></span>Service ready';
            } else throw new Error('Service unavailable');
        } catch (_) {
            pill.className = 'status-pill failed';
            pill.innerHTML = '<span class="dot"></span>Service unavailable';
        }
    }

    function setSelectedFile(file) {
        if (!file) {
            selectedJsonFile = null;
            $('fileName').textContent = 'No file selected';
            return;
        }
        if (!file.name.toLowerCase().endsWith('.json')) {
            selectedJsonFile = null;
            $('fileName').textContent = 'Select a .json file';
            showInline('connectionMessage', 'Only JSON files are accepted.', 'failed');
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            selectedJsonFile = null;
            $('fileName').textContent = 'JSON file is too large';
            showInline('connectionMessage', 'JSON upload must be 5 MB or smaller.', 'failed');
            return;
        }
        selectedJsonFile = file;
        $('fileName').textContent = `${file.name} · ${formatBytes(file.size)}`;
    }

    function updateMode() {
        const mode = document.querySelector('input[name="writeMode"]:checked').value;
        $('dryRunLabel').classList.toggle('selected', mode === 'DRY_RUN');
        $('writeLabel').classList.toggle('selected', mode === 'WRITE');
        if (mode === 'WRITE') {
            $('modeHint').textContent = 'Write mode selected';
            $('modeDetail').textContent = 'The app validates a staged copy first, then writes only if validation passes. Keep backup enabled for existing files.';
        } else {
            $('modeHint').textContent = 'Safe review mode selected';
            $('modeDetail').textContent = 'Generated code will be validated in a temporary workspace and your project files will remain unchanged.';
        }
    }

    async function testConnection() {
        const button = $('testConnectionBtn');
        button.disabled = true;
        button.textContent = 'Testing…';
        hideInline('connectionMessage');
        saveNonSecretLlmSettings();
        try {
            const response = await fetch('/api/llm/health', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    apiKey: $('apiKey').value,
                    modelName: $('modelName').value.trim(),
                    baseUrl: $('baseUrl').value.trim(),
                    temperature: numberOrNull($('temperature').value),
                    maxTokens: integerOrNull($('maxTokens').value)
                })
            });
            const body = await response.json();
            if (body.status === 'UP') {
                showInline('connectionMessage', `Connection successful${body.model ? ` · ${body.model}` : ''}`, 'success');
            } else {
                showInline('connectionMessage', body.message || 'LLM connection failed.', 'failed');
            }
        } catch (error) {
            showInline('connectionMessage', `Connection check failed: ${error.message}`, 'failed');
        } finally {
            button.disabled = false;
            button.textContent = 'Test connection';
        }
    }

    async function generateCode(event) {
        event.preventDefault();
        if (!selectedJsonFile) {
            $('fileName').textContent = 'Please select recorded JSON';
            dropZone.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        if (!form.reportValidity()) return;

        const mode = document.querySelector('input[name="writeMode"]:checked').value;
        if (mode === 'WRITE') {
            const confirmed = window.confirm('WRITE will modify the selected Playwright project after validation passes. Continue?');
            if (!confirmed) return;
        }

        saveNonSecretLlmSettings();
        setGenerating(true);
        $('resultsSection').classList.add('hidden');

        const data = new FormData();
        data.append('projectPath', $('projectPath').value.trim());
        data.append('recordedJsonFile', selectedJsonFile, selectedJsonFile.name);
        data.append('userInstruction', $('userInstruction').value.trim());
        data.append('writeMode', mode);
        appendIfValue(data, 'targetModule', $('targetModule').value);
        appendIfValue(data, 'preferredTestFile', $('preferredTestFile').value);
        appendIfValue(data, 'preferredPageObject', $('preferredPageObject').value);
        data.append('reuseExistingMethods', String($('reuseExistingMethods').checked));
        data.append('generateMissingMethods', String($('generateMissingMethods').checked));
        data.append('runValidation', String($('runValidation').checked));
        data.append('backupBeforeWrite', String($('backupBeforeWrite').checked));
        data.append('generateHtmlReport', String($('generateHtmlReport').checked));
        appendIfValue(data, 'apiKey', $('apiKey').value);
        appendIfValue(data, 'modelName', $('modelName').value);
        appendIfValue(data, 'baseUrl', $('baseUrl').value);
        appendIfValue(data, 'temperature', $('temperature').value);
        appendIfValue(data, 'maxTokens', $('maxTokens').value);

        try {
            const response = await fetch('/api/generate/playwright/form', { method: 'POST', body: data });
            let body;
            try { body = await response.json(); }
            catch (_) { throw new Error(`Server returned HTTP ${response.status}`); }
            if (!response.ok && !body.status) throw new Error(body.message || `HTTP ${response.status}`);
            renderResults(body);
        } catch (error) {
            renderResults({
                status: 'FAILED',
                message: error.message,
                writeMode: mode,
                filesCreated: [], filesUpdated: [], warnings: [], proposedChanges: [],
                validation: { passed: false, runtimeValidationPerformed: false, errors: [error.message], warnings: [], commandResults: [] }
            });
        } finally {
            setGenerating(false);
        }
    }

    function renderResults(result) {
        const section = $('resultsSection');
        section.classList.remove('hidden');
        const success = result.status === 'SUCCESS';
        $('resultTitle').textContent = success ? 'Generation completed' : 'Generation stopped';
        $('resultMessage').textContent = result.message || '';
        const status = $('resultStatus');
        status.className = `status-pill ${success ? 'success' : 'failed'}`;
        status.textContent = result.status || 'UNKNOWN';

        const created = result.filesCreated || [];
        const updated = result.filesUpdated || [];
        const reused = result.reusedMethods || [];
        const added = result.newMethods || [];
        $('summaryCards').innerHTML = '';
        addSummary('Files created', created.length);
        addSummary('Files updated', updated.length);
        addSummary('Methods reused', reused.length);
        addSummary('Methods added', added.length);

        renderFiles(created, updated);
        renderValidation(result.validation || {});
        renderChanges(result.proposedChanges || []);
        renderWarnings(result.warnings || []);
        renderReports(result);
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function addSummary(label, value) {
        const card = document.createElement('div');
        card.className = 'summary-card';
        const strong = document.createElement('strong'); strong.textContent = value;
        const span = document.createElement('span'); span.textContent = label;
        card.append(strong, span);
        $('summaryCards').appendChild(card);
    }

    function renderFiles(created, updated) {
        const root = $('filesResult');
        root.innerHTML = '';
        if (!created.length && !updated.length) return addResultItem(root, 'No files proposed.', '');
        created.forEach(file => addResultItem(root, `CREATE · ${file}`, 'good'));
        updated.forEach(file => addResultItem(root, `UPDATE · ${file}`, 'good'));
    }

    function renderValidation(validation) {
        const root = $('validationResult');
        root.innerHTML = '';
        addResultItem(root, validation.passed ? 'Static validation passed' : 'Validation failed', validation.passed ? 'good' : 'bad');
        addResultItem(root,
            validation.runtimeValidationPerformed ? 'Runtime validation executed' : 'Runtime validation not executed',
            validation.runtimeValidationPerformed ? 'good' : 'warn');
        (validation.errors || []).forEach(error => addResultItem(root, error, 'bad'));
        (validation.warnings || []).forEach(warning => addResultItem(root, warning, 'warn'));
        (validation.commandResults || []).forEach(command => {
            const item = document.createElement('details');
            item.className = 'result-item';
            const summary = document.createElement('summary');
            summary.textContent = `${command.passed ? 'PASS' : 'FAIL'} · ${command.name || 'Validation command'}`;
            const pre = document.createElement('pre');
            pre.className = 'mono';
            pre.style.whiteSpace = 'pre-wrap';
            pre.textContent = `${command.command || ''}\n\n${command.output || '(no output)'}`;
            item.append(summary, pre);
            root.appendChild(item);
        });
    }

    function renderChanges(changes) {
        const root = $('codeChanges');
        root.innerHTML = '';
        if (!changes.length) return addResultItem(root, 'No code changes returned.', 'warn');
        changes.forEach(change => {
            const block = document.createElement('div');
            block.className = 'change-block';
            const head = document.createElement('div');
            head.className = 'change-head';
            const name = document.createElement('strong');
            name.textContent = `${change.operation || 'UPDATE'} · ${change.filePath || ''}`;
            const reason = document.createElement('span');
            reason.textContent = change.reason || '';
            head.append(name, reason);
            const details = document.createElement('details');
            const summary = document.createElement('summary');
            summary.textContent = 'View generated file';
            const pre = document.createElement('pre');
            pre.textContent = change.fullContent || '';
            details.append(summary, pre);
            block.append(head, details);
            root.appendChild(block);
        });
    }

    function renderWarnings(warnings) {
        const root = $('warningsResult');
        root.innerHTML = '';
        if (!warnings.length) return addResultItem(root, 'No warnings.', 'good');
        warnings.forEach(warning => addResultItem(root, warning, 'warn'));
    }

    function renderReports(result) {
        const root = $('reportPaths');
        root.innerHTML = '';
        const entries = [
            ['HTML report', result.reportHtmlPath],
            ['JSON report', result.reportJsonPath],
            ['Markdown summary', result.summaryMarkdownPath],
            ['Backup', result.backupPath]
        ].filter(([, value]) => value);
        if (!entries.length) return addResultItem(root, 'No report paths returned.', '');
        entries.forEach(([label, value]) => addResultItem(root, `${label}: ${value}`, ''));
    }

    function addResultItem(root, text, type) {
        const item = document.createElement('div');
        item.className = `result-item ${type || ''}`.trim();
        item.textContent = text;
        root.appendChild(item);
        return item;
    }

    function setGenerating(busy) {
        const button = $('generateBtn');
        button.disabled = busy;
        button.querySelector('.btn-label').textContent = busy ? 'Generating…' : 'Generate Code';
        button.querySelector('.spinner').classList.toggle('hidden', !busy);
    }

    function saveNonSecretLlmSettings() {
        const model = $('modelName').value.trim();
        const baseUrl = $('baseUrl').value.trim();
        if (model) localStorage.setItem('playwrightCodeGen.model', model);
        if (baseUrl) localStorage.setItem('playwrightCodeGen.baseUrl', baseUrl);
    }

    function showInline(id, text, type) {
        const element = $(id);
        element.textContent = text;
        element.className = `inline-message ${type}`;
    }
    function hideInline(id) { $(id).classList.add('hidden'); }
    function appendIfValue(data, key, value) { if (value != null && String(value).trim() !== '') data.append(key, String(value).trim()); }
    function numberOrNull(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }
    function integerOrNull(value) { const n = Number.parseInt(value, 10); return Number.isFinite(n) ? n : null; }
    function formatBytes(bytes) { if (bytes < 1024) return `${bytes} B`; if (bytes < 1024 * 1024) return `${(bytes/1024).toFixed(1)} KB`; return `${(bytes/1024/1024).toFixed(1)} MB`; }
})();
