package com.llmart.llm.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.List;

public class FileSummary {
    private String path;
    private String relativePath;
    private String type;
    private String className;
    private List<String> methods = new ArrayList<>();
    private List<String> locators = new ArrayList<>();
    private List<String> imports = new ArrayList<>();
    @JsonIgnore
    private String snippet;

    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public String getRelativePath() { return relativePath; }
    public void setRelativePath(String relativePath) { this.relativePath = relativePath; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public List<String> getMethods() { return methods; }
    public void setMethods(List<String> methods) { this.methods = methods; }
    public List<String> getLocators() { return locators; }
    public void setLocators(List<String> locators) { this.locators = locators; }
    public List<String> getImports() { return imports; }
    public void setImports(List<String> imports) { this.imports = imports; }
    public String getSnippet() { return snippet; }
    public void setSnippet(String snippet) { this.snippet = snippet; }
}
