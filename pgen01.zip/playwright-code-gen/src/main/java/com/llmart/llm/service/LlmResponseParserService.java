package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.LlmChangeResponse;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class LlmResponseParserService {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public LlmChangeResponse parse(String raw) {
        try {
            String json = extractJson(raw);
            LlmChangeResponse parsed = objectMapper.readValue(json, LlmChangeResponse.class);
            if (parsed.getChanges() == null) parsed.setChanges(new ArrayList<>());
            if (parsed.getReusedMethods() == null) parsed.setReusedMethods(new ArrayList<>());
            if (parsed.getNewMethods() == null) parsed.setNewMethods(new ArrayList<>());
            if (parsed.getWarnings() == null) parsed.setWarnings(new ArrayList<>());
            return parsed;
        } catch (Exception e) {
            throw new RuntimeException("LLM response is not valid expected JSON: " + e.getMessage() + ". Response preview: " + preview(raw), e);
        }
    }

    private String extractJson(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Empty LLM response");
        String cleaned = raw.trim();
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "");
            int last = cleaned.lastIndexOf("```");
            if (last >= 0) cleaned = cleaned.substring(0, last);
        }
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if (start >= 0 && end > start) return cleaned.substring(start, end + 1);
        return cleaned;
    }

    private String preview(String raw) {
        if (raw == null) return "(empty)";
        String clean = raw.replaceAll("\\s+", " ").trim();
        return clean.length() <= 1200 ? clean : clean.substring(0, 1200) + "...";
    }
}
