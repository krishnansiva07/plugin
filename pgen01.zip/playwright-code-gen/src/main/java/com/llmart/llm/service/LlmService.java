package com.llmart.llm.service;

import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.LlmConnectionRequest;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class LlmService {

    @Value("${llm.api-key:}")
    private String defaultApiKey;

    @Value("${llm.model-name:}")
    private String defaultModelName;

    @Value("${llm.base-url:http://localhost:11434/v1}")
    private String defaultBaseUrl;

    @Value("${llm.temperature:0.2}")
    private Double defaultTemperature;

    @Value("${llm.max-tokens:4096}")
    private Integer defaultMaxTokens;

    @Value("${llm.timeout-seconds:120}")
    private long timeoutSeconds;

    public String generate(String prompt, GenerateRequest request) {
        ChatLanguageModel model = buildModel(
                request.getApiKey(),
                request.getModelName(),
                request.getBaseUrl(),
                request.getTemperature(),
                request.getMaxTokens());
        try {
            return model.generate(prompt);
        } catch (Exception e) {
            throw new RuntimeException("LLM request failed: " + safeMessage(e), e);
        }
    }

    public Map<String, Object> defaults() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("modelName", defaultModelName == null ? "" : defaultModelName);
        result.put("baseUrl", defaultBaseUrl == null ? "" : defaultBaseUrl);
        result.put("temperature", defaultTemperature);
        result.put("maxTokens", defaultMaxTokens);
        result.put("apiKeyConfigured", defaultApiKey != null && !defaultApiKey.isBlank());
        return result;
    }

    public Map<String, Object> testConnection(LlmConnectionRequest request) {
        Map<String, Object> result = new LinkedHashMap<>();
        String modelName = resolveText(request == null ? null : request.getModelName(), defaultModelName);
        try {
            ChatLanguageModel model = buildModel(
                    request == null ? null : request.getApiKey(),
                    request == null ? null : request.getModelName(),
                    request == null ? null : request.getBaseUrl(),
                    request == null ? null : request.getTemperature(),
                    request == null ? null : request.getMaxTokens());
            String answer = model.generate("Reply with exactly OK");
            result.put("status", "UP");
            result.put("model", modelName);
            result.put("response", answer == null ? "" : answer.trim());
        } catch (Exception e) {
            result.put("status", "DOWN");
            result.put("model", modelName);
            result.put("message", safeMessage(e));
        }
        return result;
    }

    private ChatLanguageModel buildModel(String apiKey, String modelName, String baseUrl, Double temperature, Integer maxTokens) {
        String resolvedBaseUrl = resolveText(baseUrl, defaultBaseUrl);
        String resolvedModel = resolveText(modelName, defaultModelName);
        String resolvedKey = resolveText(apiKey, defaultApiKey);
        Double resolvedTemperature = temperature == null ? defaultTemperature : temperature;
        Integer resolvedMaxTokens = maxTokens == null ? defaultMaxTokens : maxTokens;

        if (resolvedBaseUrl.isBlank()) throw new IllegalArgumentException("LLM base URL is required.");
        if (!(resolvedBaseUrl.startsWith("http://") || resolvedBaseUrl.startsWith("https://"))) {
            throw new IllegalArgumentException("LLM base URL must start with http:// or https://");
        }
        if (resolvedModel.isBlank()) throw new IllegalArgumentException("LLM model name is required.");
        if (resolvedKey.isBlank()) resolvedKey = "not-required";
        if (resolvedTemperature < 0 || resolvedTemperature > 2) {
            throw new IllegalArgumentException("LLM temperature must be between 0 and 2.");
        }
        if (resolvedMaxTokens < 256 || resolvedMaxTokens > 32768) {
            throw new IllegalArgumentException("LLM max tokens must be between 256 and 32768.");
        }

        return OpenAiChatModel.builder()
                .apiKey(resolvedKey)
                .modelName(resolvedModel)
                .baseUrl(resolvedBaseUrl)
                .temperature(resolvedTemperature)
                .maxTokens(resolvedMaxTokens)
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .build();
    }

    private String resolveText(String requestValue, String defaultValue) {
        if (requestValue != null && !requestValue.isBlank()) return requestValue.trim();
        return defaultValue == null ? "" : defaultValue.trim();
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        if (message == null || message.isBlank()) return e.getClass().getSimpleName();
        return message.replaceAll("(?i)(api[-_ ]?key[=: ]+)[^,;\\s]+", "$1***");
    }
}
