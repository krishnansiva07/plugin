package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.llmart.llm.model.FileSummary;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.ProjectScanResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Service
public class FrameworkAnalyzerService {

    @Value("${app.max-relevant-files:12}")
    private int maxRelevantFiles;

    public List<FileSummary> selectRelevantFiles(ProjectScanResult scan, JsonNode recordedJson, GenerateRequest request) {
        String terms = (recordedJson.toString() + " " + nullToEmpty(request.getUserInstruction())).toLowerCase(Locale.ROOT);
        List<FileSummary> all = new ArrayList<>();
        all.addAll(scan.getPageObjects());
        all.addAll(scan.getSpecFiles());
        all.addAll(scan.getUtilityFiles());
        all.addAll(scan.getOtherFiles());

        String module = normalize(nullToEmpty(request.getTargetModule())).toLowerCase(Locale.ROOT);
        if (!module.isBlank()) {
            List<FileSummary> moduleFiles = all.stream()
                    .filter(f -> normalize(nullToEmpty(f.getRelativePath())).toLowerCase(Locale.ROOT).startsWith(trimSlashes(module) + "/")
                            || normalize(nullToEmpty(f.getRelativePath())).toLowerCase(Locale.ROOT).equals(trimSlashes(module)))
                    .toList();
            if (!moduleFiles.isEmpty()) all = new ArrayList<>(moduleFiles);
        }

        List<FileSummary> sorted = all.stream()
                .sorted(Comparator.comparingInt((FileSummary f) -> score(f, terms, request)).reversed())
                .limit(maxRelevantFiles)
                .toList();

        // Ensure explicitly preferred files are in context whenever they exist.
        List<FileSummary> selected = new ArrayList<>(sorted);
        addPreferred(selected, all, request.getPreferredTestFile());
        addPreferred(selected, all, request.getPreferredPageObject());
        return selected.stream().distinct().limit(maxRelevantFiles).toList();
    }

    private void addPreferred(List<FileSummary> selected, List<FileSummary> all, String preferred) {
        if (preferred == null || preferred.isBlank()) return;
        String normalized = normalize(preferred).toLowerCase(Locale.ROOT);
        all.stream()
                .filter(f -> {
                    String rel = normalize(nullToEmpty(f.getRelativePath())).toLowerCase(Locale.ROOT);
                    return rel.equals(normalized) || rel.endsWith("/" + normalized) || rel.endsWith(normalized);
                })
                .findFirst()
                .ifPresent(f -> {
                    selected.remove(f);
                    selected.add(0, f);
                });
    }

    private int score(FileSummary file, String terms, GenerateRequest request) {
        int score = 0;
        String rel = normalize(nullToEmpty(file.getRelativePath())).toLowerCase(Locale.ROOT);
        String methods = String.join(" ", file.getMethods()).toLowerCase(Locale.ROOT);
        String locators = String.join(" ", file.getLocators()).toLowerCase(Locale.ROOT);
        if ("PAGE_OBJECT".equals(file.getType())) score += 10;
        if ("SPEC".equals(file.getType())) score += 6;

        score += preferredBoost(rel, request.getPreferredTestFile());
        score += preferredBoost(rel, request.getPreferredPageObject());

        String module = normalize(nullToEmpty(request.getTargetModule())).toLowerCase(Locale.ROOT);
        if (!module.isBlank() && rel.contains(trimSlashes(module))) score += 40;

        for (String word : terms.split("[^a-zA-Z0-9]+")) {
            if (word.length() < 4) continue;
            if (rel.contains(word)) score += 5;
            if (methods.contains(word)) score += 4;
            if (locators.contains(word)) score += 4;
        }
        return score;
    }

    private int preferredBoost(String rel, String preferred) {
        if (preferred == null || preferred.isBlank()) return 0;
        String p = normalize(preferred).toLowerCase(Locale.ROOT);
        return rel.equals(p) || rel.endsWith("/" + p) || rel.endsWith(p) ? 1000 : 0;
    }

    private String trimSlashes(String s) {
        String value = s;
        while (value.startsWith("/")) value = value.substring(1);
        while (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private String normalize(String s) { return s.replace('\\', '/'); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }
}
