package com.llmart.llm.model;

import java.util.ArrayList;
import java.util.List;

public class GeneratedChange {
    private String operation;
    private String filePath;
    private String reason;
    private String fullContent;
    private List<CodeBlock> codeBlocks = new ArrayList<>();

    public String getOperation() { return operation; }
    public void setOperation(String operation) { this.operation = operation; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public String getFullContent() { return fullContent; }
    public void setFullContent(String fullContent) { this.fullContent = fullContent; }
    public List<CodeBlock> getCodeBlocks() { return codeBlocks; }
    public void setCodeBlocks(List<CodeBlock> codeBlocks) { this.codeBlocks = codeBlocks; }
}
