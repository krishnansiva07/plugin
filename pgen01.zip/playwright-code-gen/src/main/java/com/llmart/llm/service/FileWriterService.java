package com.llmart.llm.service;

import com.llmart.llm.model.GeneratedChange;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GenerateResponse;
import com.llmart.llm.model.LlmChangeResponse;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class FileWriterService {

    public void applyChanges(GenerateRequest request, GenerateResponse response, LlmChangeResponse llmResponse) {
        String mode = normalizeMode(request.getWriteMode());
        response.setWriteMode(mode);
        collectPreview(response, llmResponse);

        if (!"WRITE".equals(mode)) {
            response.getWarnings().add("DRY_RUN mode: source files were not modified.");
            return;
        }

        Path root = Paths.get(request.getProjectPath()).toAbsolutePath().normalize();
        Path backupDir = null;
        List<Path> createdDuringWrite = new ArrayList<>();
        try {
            if (request.isBackupBeforeWrite()) {
                backupDir = root.resolve(".playwright-code-gen-backup")
                        .resolve(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS")));
                Files.createDirectories(backupDir);
                response.setBackupPath(backupDir.toString());
            }

            for (GeneratedChange change : llmResponse.getChanges()) {
                Path target = safeTarget(root, change.getFilePath());
                boolean existed = Files.exists(target);
                if (existed && backupDir != null) {
                    Path backupTarget = backupDir.resolve(change.getFilePath()).normalize();
                    Files.createDirectories(backupTarget.getParent());
                    Files.copy(target, backupTarget, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
                Files.createDirectories(target.getParent());
                Files.writeString(target, change.getFullContent(), StandardCharsets.UTF_8);
                if (!existed) createdDuringWrite.add(target);
            }
        } catch (Exception e) {
            rollback(root, backupDir, createdDuringWrite, llmResponse);
            throw new RuntimeException("Unable to write generated changes. Any partially written files were rolled back where possible: " + e.getMessage(), e);
        }
    }

    public void applyToRoot(Path root, LlmChangeResponse llmResponse) {
        try {
            for (GeneratedChange change : llmResponse.getChanges()) {
                Path target = safeTarget(root, change.getFilePath());
                Files.createDirectories(target.getParent());
                Files.writeString(target, change.getFullContent(), StandardCharsets.UTF_8);
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to stage generated files for validation: " + e.getMessage(), e);
        }
    }

    private void rollback(Path root, Path backupDir, List<Path> createdDuringWrite, LlmChangeResponse llmResponse) {
        try {
            for (Path created : createdDuringWrite) Files.deleteIfExists(created);
            if (backupDir == null || !Files.exists(backupDir)) return;
            for (GeneratedChange change : llmResponse.getChanges()) {
                Path backup = backupDir.resolve(change.getFilePath()).normalize();
                if (Files.exists(backup)) {
                    Path target = safeTarget(root, change.getFilePath());
                    Files.createDirectories(target.getParent());
                    Files.copy(backup, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
            }
        } catch (Exception ignored) {
            // Original write exception is more useful to the caller; rollback is best effort.
        }
    }

    private void collectPreview(GenerateResponse response, LlmChangeResponse llmResponse) {
        for (GeneratedChange change : llmResponse.getChanges()) {
            String op = change.getOperation() == null ? "UPDATE" : change.getOperation().toUpperCase(Locale.ROOT);
            if ("CREATE".equals(op)) response.getFilesCreated().add(change.getFilePath());
            else response.getFilesUpdated().add(change.getFilePath());
        }
    }

    private Path safeTarget(Path root, String relativePath) {
        Path target = root.resolve(relativePath).normalize();
        if (!target.startsWith(root)) throw new IllegalStateException("Unsafe target path: " + relativePath);
        return target;
    }

    private String normalizeMode(String mode) {
        if (mode == null || mode.isBlank()) return "DRY_RUN";
        String normalized = mode.trim().toUpperCase(Locale.ROOT);
        if (!normalized.equals("DRY_RUN") && !normalized.equals("WRITE")) {
            throw new IllegalArgumentException("writeMode must be DRY_RUN or WRITE.");
        }
        return normalized;
    }
}
