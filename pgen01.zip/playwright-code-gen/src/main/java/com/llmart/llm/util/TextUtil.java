package com.llmart.llm.util;

import java.util.List;

public final class TextUtil {
    private TextUtil() {}

    public static String safe(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    public static String listToText(List<String> values) {
        if (values == null || values.isEmpty()) return "None";
        return String.join("\n", values);
    }

    public static String firstChars(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, max) + "\n...TRUNCATED...";
    }
}
