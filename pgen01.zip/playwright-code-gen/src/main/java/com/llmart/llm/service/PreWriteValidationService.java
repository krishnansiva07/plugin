package com.llmart.llm.service;

import com.llmart.llm.model.GeneratedChange;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.LlmChangeResponse;
import com.llmart.llm.model.ProjectScanResult;
import com.llmart.llm.model.ValidationResult;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;

@Service
public class PreWriteValidationService {

    public ValidationResult validate(GenerateRequest request, ProjectScanResult scan, LlmChangeResponse llmResponse) {
        ValidationResult result = new ValidationResult();
        if (scan == null || !scan.isValidPlaywrightProject()) {
            result.setPassed(false);
            result.getErrors().add("Selected directory is not a valid Playwright project.");
            return result;
        }
        if (llmResponse == null || llmResponse.getChanges() == null || llmResponse.getChanges().isEmpty()) {
            result.setPassed(false);
            result.getErrors().add("LLM returned no code changes.");
            return result;
        }

        Path root = Paths.get(request.getProjectPath()).toAbsolutePath().normalize();
        Path moduleRoot = resolveModuleRoot(root, request.getTargetModule(), result);
        Set<String> seenPaths = new HashSet<>();
        Set<String> pageObjectPaths = new HashSet<>();
        if (scan.getPageObjects() != null) {
            scan.getPageObjects().forEach(f -> pageObjectPaths.add(normalize(f.getRelativePath()).toLowerCase(Locale.ROOT)));
        }

        for (GeneratedChange change : llmResponse.getChanges()) {
            validateChange(root, moduleRoot, change, result, seenPaths);
            if (!request.isGenerateMissingMethods()) {
                validateNoNewPageMethods(root, change, pageObjectPaths, result);
            }
        }

        if (!request.isGenerateMissingMethods() && llmResponse.getNewMethods() != null && !llmResponse.getNewMethods().isEmpty()) {
            result.setPassed(false);
            result.getErrors().add("generateMissingMethods=false, but the LLM proposed new methods: " + String.join(", ", llmResponse.getNewMethods()));
        }
        if (!request.isReuseExistingMethods() && llmResponse.getReusedMethods() != null && !llmResponse.getReusedMethods().isEmpty()) {
            result.setPassed(false);
            result.getErrors().add("reuseExistingMethods=false, but the LLM reported reused methods: " + String.join(", ", llmResponse.getReusedMethods()));
        }

        validatePreferredFile(request.getPreferredTestFile(), root, "Preferred test file", result);
        validatePreferredFile(request.getPreferredPageObject(), root, "Preferred page object", result);
        return result;
    }

    private void validateChange(Path root, Path moduleRoot, GeneratedChange change, ValidationResult result, Set<String> seenPaths) {
        if (change == null || change.getFilePath() == null || change.getFilePath().isBlank()) {
            fail(result, "Generated change has an empty filePath.");
            return;
        }

        String relative = change.getFilePath().replace('\\', '/').trim();
        if (relative.startsWith("/") || relative.matches("^[A-Za-z]:.*")) {
            fail(result, "Generated file path must be project-relative: " + relative);
            return;
        }
        Path target = root.resolve(relative).normalize();
        if (!target.startsWith(root)) {
            fail(result, "Blocked unsafe path outside project: " + relative);
            return;
        }
        if (moduleRoot != null && !target.startsWith(moduleRoot)) {
            fail(result, "Generated file is outside targetModule: " + relative);
        }
        String lower = relative.toLowerCase(Locale.ROOT);
        if (!(lower.endsWith(".ts") || lower.endsWith(".tsx"))) {
            fail(result, "Only TypeScript source files (.ts/.tsx) may be generated: " + relative);
        }
        if (!seenPaths.add(target.toString())) {
            fail(result, "Duplicate generated change for file: " + relative);
        }

        String operation = change.getOperation() == null ? "" : change.getOperation().trim().toUpperCase(Locale.ROOT);
        if (!(operation.equals("CREATE") || operation.equals("UPDATE"))) {
            fail(result, "Unsupported operation for " + relative + ": " + change.getOperation());
        }
        if (operation.equals("UPDATE") && !Files.exists(target)) {
            fail(result, "UPDATE target does not exist: " + relative);
        }
        if (operation.equals("CREATE") && Files.exists(target)) {
            fail(result, "CREATE target already exists: " + relative + ". LLM must use UPDATE.");
        }

        String content = change.getFullContent();
        if (content == null || content.isBlank()) {
            fail(result, "Complete fullContent is required for: " + relative);
        } else {
            if (content.contains("```")) fail(result, "Markdown code fences are not allowed in fullContent: " + relative);
            if (content.indexOf('\0') >= 0) fail(result, "Null bytes are not allowed in generated content: " + relative);
        }
        if (change.getCodeBlocks() != null && !change.getCodeBlocks().isEmpty()) {
            result.getWarnings().add("Ignored legacy codeBlocks for " + relative + "; safe full-file writes are used instead.");
        }
    }

    private Path resolveModuleRoot(Path root, String targetModule, ValidationResult result) {
        if (targetModule == null || targetModule.isBlank()) return null;
        Path moduleRoot = root.resolve(targetModule).normalize();
        if (!moduleRoot.startsWith(root)) {
            fail(result, "targetModule resolves outside the selected project.");
            return root.resolve("__invalid_module__");
        }
        if (!Files.exists(moduleRoot) || !Files.isDirectory(moduleRoot)) {
            result.getWarnings().add("targetModule does not currently exist as a directory: " + targetModule);
        }
        return moduleRoot;
    }

    private void validatePreferredFile(String preferred, Path root, String label, ValidationResult result) {
        if (preferred == null || preferred.isBlank()) return;
        Path resolved = root.resolve(preferred).normalize();
        if (!resolved.startsWith(root)) {
            fail(result, label + " resolves outside the selected project.");
            return;
        }
        if (!Files.exists(resolved)) {
            result.getWarnings().add(label + " was not found and will be treated only as a generation preference: " + preferred);
        }
    }

    private void validateNoNewPageMethods(Path root, GeneratedChange change, Set<String> pageObjectPaths, ValidationResult result) {
        if (change == null || change.getFilePath() == null || change.getFullContent() == null) return;
        String relative = normalize(change.getFilePath()).toLowerCase(Locale.ROOT);
        boolean pageObject = pageObjectPaths.contains(relative) || relative.contains("/pages/") || relative.contains("pageobject") || relative.endsWith("page.ts") || relative.endsWith("page.tsx");
        if (!pageObject) return;
        String operation = change.getOperation() == null ? "" : change.getOperation().trim().toUpperCase(Locale.ROOT);
        if ("CREATE".equals(operation)) {
            fail(result, "generateMissingMethods=false, so creating a new page object is not allowed: " + change.getFilePath());
            return;
        }
        try {
            Path target = root.resolve(change.getFilePath()).normalize();
            if (!Files.exists(target)) return;
            String existing = Files.readString(target, StandardCharsets.UTF_8);
            Set<String> existingMethods = methodNames(existing);
            Set<String> generatedMethods = methodNames(change.getFullContent());
            generatedMethods.removeAll(existingMethods);
            generatedMethods.remove("constructor");
            if (!generatedMethods.isEmpty()) {
                fail(result, "generateMissingMethods=false, but new page-object methods were detected in " + change.getFilePath() + ": " + String.join(", ", generatedMethods));
            }
        } catch (Exception e) {
            result.getWarnings().add("Could not compare page-object methods for " + change.getFilePath() + ": " + e.getMessage());
        }
    }

    private Set<String> methodNames(String content) {
        Set<String> names = new HashSet<>();
        Matcher matcher = Pattern.compile("(?:public\\s+|private\\s+|protected\\s+)?(?:async\\s+)?([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\([^)]*\\)\\s*(?::[^\\{]+)?\\{").matcher(content);
        while (matcher.find()) {
            String name = matcher.group(1);
            if (!Set.of("if", "for", "while", "switch", "catch").contains(name)) names.add(name);
        }
        return names;
    }

    private String normalize(String value) {
        return value == null ? "" : value.replace('\\', '/');
    }

    private void fail(ValidationResult result, String message) {
        result.setPassed(false);
        result.getErrors().add(message);
    }
}
