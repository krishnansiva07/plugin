package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.FileSummary;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.ProjectScanResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class PromptBuilderService {
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${app.max-project-metadata-files:250}")
    private int maxProjectMetadataFiles = 250;

    public String buildPrompt(GenerateRequest request, ProjectScanResult scan, JsonNode recordedJson, List<FileSummary> relevantFiles) {
        try {
            String projectSummary = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(metadataOnly(scan));
            String relevant = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(relevantFiles);
            String reuseRule = request.isReuseExistingMethods()
                    ? "Reuse existing page-object/helper methods whenever they already satisfy the recorded action."
                    : "Do not reuse existing page-object action methods. Generate the required implementation while still following project conventions.";
            String missingRule = request.isGenerateMissingMethods()
                    ? "If a required reusable action method does not exist, you may add the smallest missing method in the appropriate page object/helper."
                    : "Do not create new page-object/helper methods. Use existing methods when allowed or implement the action directly in the test file.";

            return """
                    You are a senior Playwright TypeScript automation architect modifying an existing production test framework.

                    TASK:
                    Analyze the recorded UI JSON and only the supplied framework context. Produce the smallest correct Playwright TypeScript change set.

                    REQUIRED BEHAVIOR:
                    - %s
                    - %s
                    - Target module: %s
                    - Preferred test file: %s
                    - Preferred page object: %s

                    SAFETY AND QUALITY RULES:
                    1. Do not duplicate methods, locators, imports, fixtures, or tests.
                    2. Follow naming, fixture, assertion, test-data and page-object conventions from the relevant files.
                    3. Prefer Playwright locators in this order: getByTestId, getByRole, getByLabel, getByPlaceholder, getByText, CSS, XPath last.
                    4. Preserve existing behavior and unrelated code.
                    5. Only create or update .ts/.tsx source files under the selected project/module.
                    6. For EVERY CREATE or UPDATE change, return fullContent containing the COMPLETE final file. Do not return partial snippets.
                    7. codeBlocks must be an empty array. It exists only for response compatibility.
                    8. Use project-root-relative paths with forward slashes.
                    9. Do not write markdown fences inside fullContent.
                    10. If the requested behavior cannot be implemented safely from the supplied context, return no changes and explain why in warnings.
                    11. Return ONLY valid JSON. No markdown and no prose outside JSON.

                    USER INSTRUCTION:
                    %s

                    PROJECT METADATA (no source bodies):
                    %s

                    RELEVANT EXISTING FILES (source snippets included):
                    %s

                    RECORDED JSON:
                    %s

                    RETURN EXACT JSON SHAPE:
                    {
                      "changes": [
                        {
                          "operation": "CREATE or UPDATE",
                          "filePath": "relative/path/file.ts",
                          "reason": "why this file must change",
                          "fullContent": "complete final file content",
                          "codeBlocks": []
                        }
                      ],
                      "reusedMethods": ["Class.method"],
                      "newMethods": ["Class.method"],
                      "warnings": ["warning text"]
                    }
                    """.formatted(
                    reuseRule,
                    missingRule,
                    valueOrNone(request.getTargetModule()),
                    valueOrNone(request.getPreferredTestFile()),
                    valueOrNone(request.getPreferredPageObject()),
                    nullToEmpty(request.getUserInstruction()),
                    projectSummary,
                    relevant,
                    recordedJson.toString()
            );
        } catch (Exception e) {
            throw new RuntimeException("Unable to build LLM prompt", e);
        }
    }

    private Map<String, Object> metadataOnly(ProjectScanResult scan) {
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("language", scan.getLanguage());
        summary.put("automationTool", scan.getAutomationTool());
        summary.put("testRunner", scan.getTestRunner());
        summary.put("configFiles", scan.getConfigFiles());
        summary.put("pageObjects", metadata(scan.getPageObjects()));
        summary.put("specFiles", metadata(scan.getSpecFiles()));
        summary.put("utilityFiles", metadata(scan.getUtilityFiles()));
        summary.put("otherTypeScriptFiles", metadata(scan.getOtherFiles()));
        return summary;
    }

    private List<Map<String, Object>> metadata(List<FileSummary> files) {
        List<Map<String, Object>> result = new ArrayList<>();
        int count = 0;
        for (FileSummary file : files) {
            if (count++ >= maxProjectMetadataFiles) break;
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("relativePath", file.getRelativePath());
            item.put("type", file.getType());
            item.put("className", file.getClassName());
            item.put("methods", file.getMethods());
            item.put("locators", file.getLocators());
            item.put("imports", file.getImports());
            result.add(item);
        }
        return result;
    }

    private String valueOrNone(String s) { return s == null || s.isBlank() ? "(none)" : s.trim(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }
}
