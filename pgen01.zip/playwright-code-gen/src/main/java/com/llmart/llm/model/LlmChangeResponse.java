package com.llmart.llm.model;

import java.util.ArrayList;
import java.util.List;

public class LlmChangeResponse {
    private List<GeneratedChange> changes = new ArrayList<>();
    private List<String> reusedMethods = new ArrayList<>();
    private List<String> newMethods = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();

    public List<GeneratedChange> getChanges() { return changes; }
    public void setChanges(List<GeneratedChange> changes) { this.changes = changes; }
    public List<String> getReusedMethods() { return reusedMethods; }
    public void setReusedMethods(List<String> reusedMethods) { this.reusedMethods = reusedMethods; }
    public List<String> getNewMethods() { return newMethods; }
    public void setNewMethods(List<String> newMethods) { this.newMethods = newMethods; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
}
