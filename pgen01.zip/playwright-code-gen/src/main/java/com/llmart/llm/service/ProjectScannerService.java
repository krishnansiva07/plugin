package com.llmart.llm.service;

import com.llmart.llm.model.FileSummary;
import com.llmart.llm.model.ProjectScanResult;
import com.llmart.llm.util.TextUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

@Service
public class ProjectScannerService {

    @Value("${app.max-file-read-chars:25000}")
    private int maxFileReadChars;

    @Value("${app.max-scan-files:750}")
    private int maxScanFiles;

    public ProjectScanResult scan(String projectPath) {
        if (projectPath == null || projectPath.isBlank()) {
            throw new IllegalArgumentException("Project path is required.");
        }
        Path root = Paths.get(projectPath).toAbsolutePath().normalize();
        if (!Files.exists(root) || !Files.isDirectory(root)) {
            throw new IllegalArgumentException("Invalid project path: " + projectPath);
        }

        ProjectScanResult result = new ProjectScanResult();
        result.setProjectRoot(root.toString());

        addConfigIfExists(root, result, "package.json");
        addConfigIfExists(root, result, "tsconfig.json");
        addConfigIfExists(root, result, "playwright.config.ts");
        addConfigIfExists(root, result, "playwright.config.js");
        addConfigIfExists(root, result, "playwright.config.mts");

        result.setValidPlaywrightProject(isPlaywrightProject(root));
        if (!result.isValidPlaywrightProject()) {
            result.getWarnings().add("The selected directory does not look like a Playwright project. package.json must reference Playwright.");
        }

        try (Stream<Path> paths = Files.walk(root)) {
            List<Path> sourceFiles = paths
                    .filter(Files::isRegularFile)
                    .filter(this::isTypeScriptSource)
                    .filter(p -> !isIgnored(root, p))
                    .sorted(Comparator.comparing(Path::toString))
                    .limit(maxScanFiles)
                    .toList();

            for (Path file : sourceFiles) {
                FileSummary summary = summarize(root, file);
                String rel = normalize(summary.getRelativePath()).toLowerCase(Locale.ROOT);
                String content = summary.getSnippet() == null ? "" : summary.getSnippet();

                if (isSpec(rel, content)) {
                    summary.setType("SPEC");
                    result.getSpecFiles().add(summary);
                } else if (isPageObject(rel, content)) {
                    summary.setType("PAGE_OBJECT");
                    result.getPageObjects().add(summary);
                } else if (isUtility(rel, content)) {
                    summary.setType("UTILITY");
                    result.getUtilityFiles().add(summary);
                } else {
                    summary.setType("OTHER_TS");
                    result.getOtherFiles().add(summary);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Unable to scan project: " + e.getMessage(), e);
        }

        if (result.getConfigFiles().stream().anyMatch(c -> c.startsWith("playwright.config")) || result.isValidPlaywrightProject()) {
            result.setTestRunner("Playwright Test");
        }
        if (result.getPageObjects().isEmpty()) {
            result.getWarnings().add("No existing page objects were detected.");
        }
        if (totalSourceFiles(result) >= maxScanFiles) {
            result.getWarnings().add("Source scan reached the configured file limit of " + maxScanFiles + ". Narrow targetModule if needed.");
        }
        return result;
    }

    private boolean isPlaywrightProject(Path root) {
        Path packageJson = root.resolve("package.json");
        if (!Files.exists(packageJson)) return false;
        try {
            String packageText = Files.readString(packageJson, StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
            return packageText.contains("@playwright/test") || packageText.contains("\"playwright\"");
        } catch (IOException e) {
            return false;
        }
    }

    private int totalSourceFiles(ProjectScanResult result) {
        return result.getPageObjects().size() + result.getSpecFiles().size() + result.getUtilityFiles().size() + result.getOtherFiles().size();
    }

    private void addConfigIfExists(Path root, ProjectScanResult result, String file) {
        if (Files.exists(root.resolve(file))) result.getConfigFiles().add(file);
    }

    private boolean isTypeScriptSource(Path p) {
        String s = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return s.endsWith(".ts") || s.endsWith(".tsx");
    }

    private boolean isIgnored(Path root, Path p) {
        String rel = "/" + normalize(root.relativize(p).toString()) + "/";
        return rel.contains("/node_modules/") || rel.contains("/.git/") || rel.contains("/dist/") ||
                rel.contains("/build/") || rel.contains("/allure-results/") || rel.contains("/playwright-report/") ||
                rel.contains("/test-results/") || rel.contains("/.playwright-code-gen-backup/") || rel.contains("/.llm-backup/") || rel.contains("/playwright-code-gen-reports/") || rel.contains("/.playwright-code-gen-stage/");
    }

    private boolean isSpec(String rel, String content) {
        return rel.endsWith(".spec.ts") || rel.endsWith(".spec.tsx") || rel.endsWith(".test.ts") ||
                rel.endsWith(".test.tsx") || rel.contains("/tests/") || content.contains("test.describe(") || content.contains("test(");
    }

    private boolean isPageObject(String rel, String content) {
        return rel.contains("/pages/") || rel.contains("pageobject") || rel.contains("page-object") ||
                rel.endsWith("page.ts") || rel.endsWith("page.tsx") ||
                (content.contains("class ") && content.contains("Page") && (content.contains("Locator") || content.contains("getByRole") || content.contains("locator(")));
    }

    private boolean isUtility(String rel, String content) {
        return rel.contains("/utils/") || rel.contains("/util/") || rel.contains("/helpers/") ||
                rel.contains("/fixtures/") || rel.contains("helper") || rel.contains("fixture") || content.contains("test.extend<");
    }

    private FileSummary summarize(Path root, Path file) throws IOException {
        String content = Files.readString(file, StandardCharsets.UTF_8);
        FileSummary fs = new FileSummary();
        fs.setPath(file.toString());
        fs.setRelativePath(normalize(root.relativize(file).toString()));
        fs.setSnippet(TextUtil.firstChars(content, maxFileReadChars));
        fs.setClassName(firstMatch(content, "(?:export\\s+)?class\\s+([A-Za-z0-9_]+)"));
        fs.getMethods().addAll(matches(content, "(?:public\\s+|private\\s+|protected\\s+)?(?:async\\s+)?([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\([^)]*\\)\\s*(?::[^\\{]+)?\\{"));
        fs.getLocators().addAll(matches(content, "(?:readonly\\s+)?([A-Za-z_$][A-Za-z0-9_$]*)\\s*[:=][^;\\n]*(?:locator|getByRole|getByText|getByTestId|getByLabel|getByPlaceholder)"));
        fs.getImports().addAll(matches(content, "import\\s+.*?from\\s+['\"]([^'\"]+)['\"]"));
        return fs;
    }

    private String firstMatch(String content, String regex) {
        Matcher m = Pattern.compile(regex).matcher(content);
        return m.find() ? m.group(1) : "";
    }

    private List<String> matches(String content, String regex) {
        Matcher m = Pattern.compile(regex).matcher(content);
        java.util.ArrayList<String> values = new java.util.ArrayList<>();
        while (m.find()) {
            String v = m.group(1);
            if (!values.contains(v) && !v.equals("if") && !v.equals("for") && !v.equals("while") && !v.equals("switch")) values.add(v);
        }
        return values;
    }

    private String normalize(String value) {
        return value.replace('\\', '/');
    }
}
