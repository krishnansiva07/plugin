package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GenerateResponse;
import com.llmart.llm.model.GeneratedChange;
import com.llmart.llm.model.ValidationCommandResult;
import com.llmart.llm.model.ValidationResult;
import com.llmart.llm.util.TextUtil;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class HtmlReportService {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public void generateReports(GenerateRequest request, GenerateResponse response) {
        try {
            Path root = Paths.get(request.getProjectPath()).toAbsolutePath().normalize();
            if (!Files.exists(root) || !Files.isDirectory(root)) return;
            Path reportDir = root.resolve("playwright-code-gen-reports");
            Files.createDirectories(reportDir);
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"));

            Path html = reportDir.resolve("generation-report-" + timestamp + ".html");
            Path json = reportDir.resolve("generation-report-" + timestamp + ".json");
            Path md = reportDir.resolve("generation-summary-" + timestamp + ".md");

            // Set paths before serializing so the JSON report contains its own locations.
            response.setReportHtmlPath(html.toString());
            response.setReportJsonPath(json.toString());
            response.setSummaryMarkdownPath(md.toString());

            Files.writeString(html, buildHtml(request, response), StandardCharsets.UTF_8);
            Files.writeString(json, objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(response), StandardCharsets.UTF_8);
            Files.writeString(md, buildMarkdown(response), StandardCharsets.UTF_8);
        } catch (Exception e) {
            response.getWarnings().add("Report generation failed: " + e.getMessage());
        }
    }

    private String buildHtml(GenerateRequest request, GenerateResponse response) {
        StringBuilder html = new StringBuilder();
        html.append("""
                <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
                <title>Playwright code Gen Report</title>
                <style>
                body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f3fbf7;color:#15302a}header{background:#006f44;color:white;padding:24px 6vw}header h1{margin:0;font-size:25px}.wrap{max-width:1180px;margin:24px auto;padding:0 20px}.card{background:white;border:1px solid #dce7e2;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 8px 24px rgba(0,75,45,.06)}h2{font-size:17px;color:#006f44;margin:0 0 14px}.badge{display:inline-block;padding:6px 11px;border-radius:999px;font-weight:700;background:#e7f6ef;color:#005a37}.failed{background:#fff1f0;color:#b42318}.warn{background:#fff8e1;color:#755000}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #e5ede9;text-align:left;vertical-align:top}th{width:210px;color:#66756f}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f7faf8;border:1px solid #e2ebe7;border-radius:8px;padding:12px}.code{white-space:pre;overflow:auto;max-height:600px;background:#0f241e;color:#e6fff2}.change{border:1px solid #dce7e2;border-radius:9px;margin:12px 0;overflow:hidden}.change-head{padding:10px 12px;background:#f3fbf7;font-weight:700}.reason{font-weight:400;color:#66756f;margin-top:4px}.ok{color:#006f44;font-weight:700}.bad{color:#b42318;font-weight:700}footer{text-align:center;color:#66756f;padding:22px}
                </style></head><body><header><h1>Playwright code Gen</h1><div>Generation report</div></header><div class="wrap">
                """);

        String statusClass = "FAILED".equalsIgnoreCase(response.getStatus()) ? "badge failed" : "badge";
        html.append("<div class=\"card\"><span class=\"").append(statusClass).append("\">")
                .append(TextUtil.safe(response.getStatus())).append("</span><h2 style=\"margin-top:14px\">Summary</h2><table>")
                .append(row("Project path", request.getProjectPath()))
                .append(row("Write mode", response.getWriteMode()))
                .append(row("Target module", request.getTargetModule()))
                .append(row("Preferred test file", request.getPreferredTestFile()))
                .append(row("Preferred page object", request.getPreferredPageObject()))
                .append(row("Message", response.getMessage()))
                .append("</table></div>");

        html.append(section("Files created", TextUtil.listToText(response.getFilesCreated())));
        html.append(section("Files updated", TextUtil.listToText(response.getFilesUpdated())));
        html.append(section("Reused methods", TextUtil.listToText(response.getReusedMethods())));
        html.append(section("New methods", TextUtil.listToText(response.getNewMethods())));

        ValidationResult validation = response.getValidation();
        html.append("<div class=\"card\"><h2>Validation</h2>");
        if (validation != null) {
            html.append("<p class=\"").append(validation.isPassed() ? "ok" : "bad").append("\">Passed: ")
                    .append(validation.isPassed()).append("</p>")
                    .append("<p>Runtime validation performed: ").append(validation.isRuntimeValidationPerformed()).append("</p>")
                    .append("<h3>Errors</h3><pre>").append(TextUtil.safe(TextUtil.listToText(validation.getErrors()))).append("</pre>")
                    .append("<h3>Validation warnings</h3><pre>").append(TextUtil.safe(TextUtil.listToText(validation.getWarnings()))).append("</pre>");
            for (ValidationCommandResult command : validation.getCommandResults()) {
                html.append("<div class=\"change\"><div class=\"change-head\">")
                        .append(TextUtil.safe(command.getName())).append(" · ")
                        .append(command.isPassed() ? "PASS" : "FAIL")
                        .append("</div><pre>")
                        .append(TextUtil.safe(command.getCommand())).append("\n\n")
                        .append(TextUtil.safe(command.getOutput())).append("</pre></div>");
            }
        }
        html.append("</div>");

        html.append("<div class=\"card\"><h2>Proposed code</h2>");
        if (response.getProposedChanges() == null || response.getProposedChanges().isEmpty()) {
            html.append("<p>No code changes returned.</p>");
        } else {
            for (GeneratedChange change : response.getProposedChanges()) {
                html.append("<div class=\"change\"><div class=\"change-head\">")
                        .append(TextUtil.safe(change.getOperation())).append(" · ")
                        .append(TextUtil.safe(change.getFilePath()))
                        .append("<div class=\"reason\">").append(TextUtil.safe(change.getReason())).append("</div></div>")
                        .append("<pre class=\"code\">").append(TextUtil.safe(change.getFullContent())).append("</pre></div>");
            }
        }
        html.append("</div>");

        html.append(section("Warnings", TextUtil.listToText(response.getWarnings())));
        html.append(section("Backup location", response.getBackupPath() == null ? "None" : response.getBackupPath()));
        html.append("</div><footer>Playwright code Gen</footer></body></html>");
        return html.toString();
    }

    private String row(String key, String value) {
        return "<tr><th>" + TextUtil.safe(key) + "</th><td>" + TextUtil.safe(value) + "</td></tr>";
    }

    private String section(String title, String value) {
        return "<div class=\"card\"><h2>" + TextUtil.safe(title) + "</h2><pre>" + TextUtil.safe(value) + "</pre></div>";
    }

    private String buildMarkdown(GenerateResponse response) {
        StringBuilder md = new StringBuilder();
        md.append("# Playwright code Gen Summary\n\n")
                .append("Status: ").append(response.getStatus()).append("\n\n")
                .append("Write mode: ").append(response.getWriteMode()).append("\n\n")
                .append("## Files Created\n").append(TextUtil.listToText(response.getFilesCreated())).append("\n\n")
                .append("## Files Updated\n").append(TextUtil.listToText(response.getFilesUpdated())).append("\n\n")
                .append("## Reused Methods\n").append(TextUtil.listToText(response.getReusedMethods())).append("\n\n")
                .append("## New Methods\n").append(TextUtil.listToText(response.getNewMethods())).append("\n\n")
                .append("## Validation\n");
        if (response.getValidation() != null) {
            md.append("Passed: ").append(response.getValidation().isPassed()).append("\n\n")
                    .append("Runtime validation performed: ").append(response.getValidation().isRuntimeValidationPerformed()).append("\n\n")
                    .append("Errors:\n").append(TextUtil.listToText(response.getValidation().getErrors())).append("\n\n");
        }
        md.append("## Warnings\n").append(TextUtil.listToText(response.getWarnings())).append("\n");
        return md.toString();
    }
}
