package com.llmart.llm.model;

public class GenerateRequest {
    private String projectPath;
    private String recordedJsonPath;
    private String recordedJsonContent;
    private String userInstruction;
    private String writeMode = "DRY_RUN";
    private String targetModule;
    private String preferredTestFile;
    private String preferredPageObject;
    private boolean generateMissingMethods = true;
    private boolean reuseExistingMethods = true;
    private boolean backupBeforeWrite = true;
    private boolean runValidation = true;
    private boolean generateHtmlReport = true;

    // Optional per-request LLM settings. If blank, application/environment defaults are used.
    private String apiKey;
    private String modelName;
    private String baseUrl;
    private Double temperature;
    private Integer maxTokens;

    public String getProjectPath() { return projectPath; }
    public void setProjectPath(String projectPath) { this.projectPath = projectPath; }
    public String getRecordedJsonPath() { return recordedJsonPath; }
    public void setRecordedJsonPath(String recordedJsonPath) { this.recordedJsonPath = recordedJsonPath; }
    public String getRecordedJsonContent() { return recordedJsonContent; }
    public void setRecordedJsonContent(String recordedJsonContent) { this.recordedJsonContent = recordedJsonContent; }
    public String getUserInstruction() { return userInstruction; }
    public void setUserInstruction(String userInstruction) { this.userInstruction = userInstruction; }
    public String getWriteMode() { return writeMode; }
    public void setWriteMode(String writeMode) { this.writeMode = writeMode; }
    public String getTargetModule() { return targetModule; }
    public void setTargetModule(String targetModule) { this.targetModule = targetModule; }
    public String getPreferredTestFile() { return preferredTestFile; }
    public void setPreferredTestFile(String preferredTestFile) { this.preferredTestFile = preferredTestFile; }
    public String getPreferredPageObject() { return preferredPageObject; }
    public void setPreferredPageObject(String preferredPageObject) { this.preferredPageObject = preferredPageObject; }
    public boolean isGenerateMissingMethods() { return generateMissingMethods; }
    public void setGenerateMissingMethods(boolean generateMissingMethods) { this.generateMissingMethods = generateMissingMethods; }
    public boolean isReuseExistingMethods() { return reuseExistingMethods; }
    public void setReuseExistingMethods(boolean reuseExistingMethods) { this.reuseExistingMethods = reuseExistingMethods; }
    public boolean isBackupBeforeWrite() { return backupBeforeWrite; }
    public void setBackupBeforeWrite(boolean backupBeforeWrite) { this.backupBeforeWrite = backupBeforeWrite; }
    public boolean isRunValidation() { return runValidation; }
    public void setRunValidation(boolean runValidation) { this.runValidation = runValidation; }
    public boolean isGenerateHtmlReport() { return generateHtmlReport; }
    public void setGenerateHtmlReport(boolean generateHtmlReport) { this.generateHtmlReport = generateHtmlReport; }
    public String getApiKey() { return apiKey; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }
    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public Double getTemperature() { return temperature; }
    public void setTemperature(Double temperature) { this.temperature = temperature; }
    public Integer getMaxTokens() { return maxTokens; }
    public void setMaxTokens(Integer maxTokens) { this.maxTokens = maxTokens; }
}
