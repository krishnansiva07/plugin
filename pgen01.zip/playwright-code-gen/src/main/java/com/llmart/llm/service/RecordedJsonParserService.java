package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.GenerateRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class RecordedJsonParserService {
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${app.max-recorded-json-chars:1000000}")
    private int maxRecordedJsonChars;

    public JsonNode parse(GenerateRequest request) {
        try {
            String json = request.getRecordedJsonContent();
            if (json == null || json.isBlank()) {
                if (request.getRecordedJsonPath() == null || request.getRecordedJsonPath().isBlank()) {
                    throw new IllegalArgumentException("Upload a recorded JSON file or provide recordedJsonContent.");
                }
                Path jsonPath = Paths.get(request.getRecordedJsonPath()).toAbsolutePath().normalize();
                Path root = Paths.get(request.getProjectPath()).toAbsolutePath().normalize();
                if (!jsonPath.startsWith(root)) {
                    throw new IllegalArgumentException("recordedJsonPath must be inside the selected project. Use JSON upload for files stored elsewhere.");
                }
                if (!Files.exists(jsonPath) || !Files.isRegularFile(jsonPath)) {
                    throw new IllegalArgumentException("Recorded JSON path does not exist: " + request.getRecordedJsonPath());
                }
                json = Files.readString(jsonPath, StandardCharsets.UTF_8);
            }
            if (json.length() > maxRecordedJsonChars) {
                throw new IllegalArgumentException("Recorded JSON is too large. Maximum allowed characters: " + maxRecordedJsonChars);
            }
            JsonNode node = objectMapper.readTree(json);
            if (node == null || node.isNull()) throw new IllegalArgumentException("Recorded JSON is empty.");
            if (!(node.isObject() || node.isArray())) {
                throw new IllegalArgumentException("Recorded JSON root must be an object or array.");
            }
            if ((node.isObject() || node.isArray()) && node.size() == 0) {
                throw new IllegalArgumentException("Recorded JSON contains no data.");
            }
            return node;
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Unable to parse recorded JSON: " + e.getMessage(), e);
        }
    }
}
