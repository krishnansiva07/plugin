package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.llmart.llm.model.FileSummary;
import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GenerateResponse;
import com.llmart.llm.model.LlmChangeResponse;
import com.llmart.llm.model.ProjectScanResult;
import com.llmart.llm.model.ValidationResult;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class GenerationService {
    private final ProjectScannerService projectScannerService;
    private final RecordedJsonParserService recordedJsonParserService;
    private final FrameworkAnalyzerService frameworkAnalyzerService;
    private final PromptBuilderService promptBuilderService;
    private final LlmService llmService;
    private final LlmResponseParserService llmResponseParserService;
    private final PreWriteValidationService preWriteValidationService;
    private final RuntimeValidationService runtimeValidationService;
    private final FileWriterService fileWriterService;
    private final HtmlReportService htmlReportService;

    public GenerationService(ProjectScannerService projectScannerService,
                             RecordedJsonParserService recordedJsonParserService,
                             FrameworkAnalyzerService frameworkAnalyzerService,
                             PromptBuilderService promptBuilderService,
                             LlmService llmService,
                             LlmResponseParserService llmResponseParserService,
                             PreWriteValidationService preWriteValidationService,
                             RuntimeValidationService runtimeValidationService,
                             FileWriterService fileWriterService,
                             HtmlReportService htmlReportService) {
        this.projectScannerService = projectScannerService;
        this.recordedJsonParserService = recordedJsonParserService;
        this.frameworkAnalyzerService = frameworkAnalyzerService;
        this.promptBuilderService = promptBuilderService;
        this.llmService = llmService;
        this.llmResponseParserService = llmResponseParserService;
        this.preWriteValidationService = preWriteValidationService;
        this.runtimeValidationService = runtimeValidationService;
        this.fileWriterService = fileWriterService;
        this.htmlReportService = htmlReportService;
    }

    public GenerateResponse generate(GenerateRequest request) {
        GenerateResponse response = new GenerateResponse();
        normalizeAndValidateRequest(request, response);
        try {
            ProjectScanResult scan = projectScannerService.scan(request.getProjectPath());
            response.setDetectedFramework(scan);
            response.getWarnings().addAll(scan.getWarnings());
            if (!scan.isValidPlaywrightProject()) {
                throw new IllegalArgumentException("The selected project does not contain a Playwright dependency in package.json.");
            }

            JsonNode recorded = recordedJsonParserService.parse(request);
            List<FileSummary> relevantFiles = frameworkAnalyzerService.selectRelevantFiles(scan, recorded, request);
            String prompt = promptBuilderService.buildPrompt(request, scan, recorded, relevantFiles);

            String rawLlmResponse = llmService.generate(prompt, request);
            LlmChangeResponse llmChangeResponse = llmResponseParserService.parse(rawLlmResponse);
            response.setProposedChanges(llmChangeResponse.getChanges());
            response.setReusedMethods(llmChangeResponse.getReusedMethods());
            response.setNewMethods(llmChangeResponse.getNewMethods());
            if (llmChangeResponse.getWarnings() != null) response.getWarnings().addAll(llmChangeResponse.getWarnings());

            // Structural/path safety validation is mandatory and cannot be disabled.
            ValidationResult validation = preWriteValidationService.validate(request, scan, llmChangeResponse);
            if (validation.isPassed() && request.isRunValidation()) {
                runtimeValidationService.validateStagedProject(request, llmChangeResponse, validation);
            } else if (!request.isRunValidation()) {
                validation.getWarnings().add("Runtime TypeScript/Playwright validation was disabled. Structural safety validation still ran.");
            }
            response.setValidation(validation);

            if (!validation.isPassed()) {
                response.setStatus("FAILED");
                response.setMessage("Validation failed. No source files were written.");
            } else {
                fileWriterService.applyChanges(request, response, llmChangeResponse);
                response.setStatus("SUCCESS");
                response.setMessage("Generation completed in " + response.getWriteMode() + " mode.");
            }
        } catch (Exception e) {
            response.setStatus("FAILED");
            response.setMessage(safeMessage(e));
            if (response.getValidation() == null) response.setValidation(new ValidationResult());
            response.getValidation().setPassed(false);
            response.getValidation().getErrors().add(safeMessage(e));
        } finally {
            if (request != null && request.isGenerateHtmlReport() && request.getProjectPath() != null && !request.getProjectPath().isBlank()) {
                htmlReportService.generateReports(request, response);
            }
        }
        return response;
    }

    private void normalizeAndValidateRequest(GenerateRequest request, GenerateResponse response) {
        if (request == null) throw new IllegalArgumentException("Generation request is required.");
        String mode = request.getWriteMode() == null ? "DRY_RUN" : request.getWriteMode().trim().toUpperCase(Locale.ROOT);
        if (!mode.equals("DRY_RUN") && !mode.equals("WRITE")) throw new IllegalArgumentException("writeMode must be DRY_RUN or WRITE.");
        request.setWriteMode(mode);
        response.setWriteMode(mode);
        if (request.getProjectPath() == null || request.getProjectPath().isBlank()) throw new IllegalArgumentException("Project path is required.");
        if (request.getUserInstruction() == null || request.getUserInstruction().isBlank()) {
            request.setUserInstruction("Generate Playwright code for the recorded flow.");
        }
    }

    private String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.isBlank() ? e.getClass().getSimpleName() : message;
    }
}
