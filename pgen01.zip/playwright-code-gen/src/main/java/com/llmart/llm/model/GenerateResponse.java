package com.llmart.llm.model;

import java.util.ArrayList;
import java.util.List;

public class GenerateResponse {
    private String status;
    private String message;
    private String writeMode;
    private String reportHtmlPath;
    private String reportJsonPath;
    private String summaryMarkdownPath;
    private String backupPath;
    private List<String> filesCreated = new ArrayList<>();
    private List<String> filesUpdated = new ArrayList<>();
    private List<String> reusedMethods = new ArrayList<>();
    private List<String> newMethods = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();
    private List<GeneratedChange> proposedChanges = new ArrayList<>();
    private ValidationResult validation = new ValidationResult();
    private ProjectScanResult detectedFramework;

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getWriteMode() { return writeMode; }
    public void setWriteMode(String writeMode) { this.writeMode = writeMode; }
    public String getReportHtmlPath() { return reportHtmlPath; }
    public void setReportHtmlPath(String reportHtmlPath) { this.reportHtmlPath = reportHtmlPath; }
    public String getReportJsonPath() { return reportJsonPath; }
    public void setReportJsonPath(String reportJsonPath) { this.reportJsonPath = reportJsonPath; }
    public String getSummaryMarkdownPath() { return summaryMarkdownPath; }
    public void setSummaryMarkdownPath(String summaryMarkdownPath) { this.summaryMarkdownPath = summaryMarkdownPath; }
    public String getBackupPath() { return backupPath; }
    public void setBackupPath(String backupPath) { this.backupPath = backupPath; }
    public List<String> getFilesCreated() { return filesCreated; }
    public void setFilesCreated(List<String> filesCreated) { this.filesCreated = filesCreated; }
    public List<String> getFilesUpdated() { return filesUpdated; }
    public void setFilesUpdated(List<String> filesUpdated) { this.filesUpdated = filesUpdated; }
    public List<String> getReusedMethods() { return reusedMethods; }
    public void setReusedMethods(List<String> reusedMethods) { this.reusedMethods = reusedMethods; }
    public List<String> getNewMethods() { return newMethods; }
    public void setNewMethods(List<String> newMethods) { this.newMethods = newMethods; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
    public List<GeneratedChange> getProposedChanges() { return proposedChanges; }
    public void setProposedChanges(List<GeneratedChange> proposedChanges) { this.proposedChanges = proposedChanges == null ? new ArrayList<>() : proposedChanges; }
    public ValidationResult getValidation() { return validation; }
    public void setValidation(ValidationResult validation) { this.validation = validation; }
    public ProjectScanResult getDetectedFramework() { return detectedFramework; }
    public void setDetectedFramework(ProjectScanResult detectedFramework) { this.detectedFramework = detectedFramework; }
}
