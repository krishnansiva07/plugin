package com.llmart.llm.model;

import java.util.ArrayList;
import java.util.List;

public class ProjectScanResult {
    private boolean validPlaywrightProject;
    private String projectRoot;
    private String language = "TypeScript";
    private String automationTool = "Playwright";
    private String testRunner = "Unknown";
    private List<FileSummary> pageObjects = new ArrayList<>();
    private List<FileSummary> specFiles = new ArrayList<>();
    private List<FileSummary> utilityFiles = new ArrayList<>();
    private List<FileSummary> otherFiles = new ArrayList<>();
    private List<String> configFiles = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();

    public boolean isValidPlaywrightProject() { return validPlaywrightProject; }
    public void setValidPlaywrightProject(boolean validPlaywrightProject) { this.validPlaywrightProject = validPlaywrightProject; }
    public String getProjectRoot() { return projectRoot; }
    public void setProjectRoot(String projectRoot) { this.projectRoot = projectRoot; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
    public String getAutomationTool() { return automationTool; }
    public void setAutomationTool(String automationTool) { this.automationTool = automationTool; }
    public String getTestRunner() { return testRunner; }
    public void setTestRunner(String testRunner) { this.testRunner = testRunner; }
    public List<FileSummary> getPageObjects() { return pageObjects; }
    public void setPageObjects(List<FileSummary> pageObjects) { this.pageObjects = pageObjects; }
    public List<FileSummary> getSpecFiles() { return specFiles; }
    public void setSpecFiles(List<FileSummary> specFiles) { this.specFiles = specFiles; }
    public List<FileSummary> getUtilityFiles() { return utilityFiles; }
    public void setUtilityFiles(List<FileSummary> utilityFiles) { this.utilityFiles = utilityFiles; }
    public List<FileSummary> getOtherFiles() { return otherFiles; }
    public void setOtherFiles(List<FileSummary> otherFiles) { this.otherFiles = otherFiles; }
    public List<String> getConfigFiles() { return configFiles; }
    public void setConfigFiles(List<String> configFiles) { this.configFiles = configFiles; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
}
