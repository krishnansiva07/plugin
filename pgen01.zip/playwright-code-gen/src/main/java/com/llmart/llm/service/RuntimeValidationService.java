package com.llmart.llm.service;

import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.LlmChangeResponse;
import com.llmart.llm.model.ValidationCommandResult;
import com.llmart.llm.model.ValidationResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class RuntimeValidationService {
    private static final Set<String> SKIP_DIRS = Set.of(
            "node_modules", ".git", "dist", "build", "playwright-report", "test-results",
            "allure-results", ".playwright-code-gen-backup", ".llm-backup", "playwright-code-gen-reports", ".playwright-code-gen-stage"
    );

    private final FileWriterService fileWriterService;

    @Value("${app.validation-timeout-seconds:120}")
    private long validationTimeoutSeconds;

    @Value("${app.validation-max-output-chars:12000}")
    private int maxOutputChars;

    public RuntimeValidationService(FileWriterService fileWriterService) {
        this.fileWriterService = fileWriterService;
    }

    public void validateStagedProject(GenerateRequest request, LlmChangeResponse llmResponse, ValidationResult result) {
        if (!result.isPassed()) return;
        Path sourceRoot = Paths.get(request.getProjectPath()).toAbsolutePath().normalize();
        Path stageParent = sourceRoot.resolve(".playwright-code-gen-stage");
        Path stageRoot = stageParent.resolve(UUID.randomUUID().toString());
        try {
            Files.createDirectories(stageRoot);
            copyProject(sourceRoot, stageRoot);
            fileWriterService.applyToRoot(stageRoot, llmResponse);

            boolean ranAny = false;
            Path tsc = findLocalBinary(sourceRoot, "tsc");
            if (tsc != null && Files.exists(stageRoot.resolve("tsconfig.json"))) {
                ranAny = true;
                runCommand("TypeScript compile", tsc, List.of("--noEmit"), stageRoot, result);
            } else {
                result.getWarnings().add("TypeScript compile check skipped because local node_modules/.bin/tsc or tsconfig.json was not found.");
            }

            Path playwright = findLocalBinary(sourceRoot, "playwright");
            if (playwright != null) {
                ranAny = true;
                runCommand("Playwright discovery", playwright, List.of("test", "--list"), stageRoot, result);
            } else {
                String message = "Playwright runtime check could not run because node_modules/.bin/playwright was not found. Run npm install in the target project.";
                if ("WRITE".equalsIgnoreCase(request.getWriteMode())) {
                    result.setPassed(false);
                    result.getErrors().add(message + " WRITE is blocked while runtime validation is enabled.");
                } else {
                    result.getWarnings().add(message);
                }
            }
            result.setRuntimeValidationPerformed(ranAny);
        } catch (Exception e) {
            result.setPassed(false);
            result.getErrors().add("Runtime validation could not be completed: " + e.getMessage());
        } finally {
            deleteTree(stageRoot);
            try {
                if (Files.isDirectory(stageParent) && isDirectoryEmpty(stageParent)) Files.deleteIfExists(stageParent);
            } catch (Exception ignored) { }
        }
    }

    private void copyProject(Path sourceRoot, Path stageRoot) throws IOException {
        Files.walkFileTree(sourceRoot, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                if (!dir.equals(sourceRoot) && SKIP_DIRS.contains(dir.getFileName().toString())) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                Path relative = sourceRoot.relativize(dir);
                Files.createDirectories(stageRoot.resolve(relative));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                Path relative = sourceRoot.relativize(file);
                Files.copy(file, stageRoot.resolve(relative));
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private Path findLocalBinary(Path projectRoot, String name) {
        Path binDir = projectRoot.resolve("node_modules").resolve(".bin");
        if (isWindows()) {
            Path cmd = binDir.resolve(name + ".cmd");
            if (Files.exists(cmd)) return cmd;
            Path exe = binDir.resolve(name + ".exe");
            if (Files.exists(exe)) return exe;
        }
        Path unix = binDir.resolve(name);
        return Files.exists(unix) ? unix : null;
    }

    private void runCommand(String name, Path executable, List<String> args, Path workingDirectory, ValidationResult validation) {
        ValidationCommandResult commandResult = new ValidationCommandResult();
        commandResult.setName(name);
        commandResult.setExecuted(true);

        List<String> command = new ArrayList<>();
        if (isWindows() && executable.toString().toLowerCase(Locale.ROOT).endsWith(".cmd")) {
            command.add("cmd.exe");
            command.add("/c");
        }
        command.add(executable.toString());
        command.addAll(args);
        commandResult.setCommand(String.join(" ", command));

        Path log = null;
        try {
            log = Files.createTempFile("playwright-code-gen-validation-", ".log");
            ProcessBuilder builder = new ProcessBuilder(command);
            builder.directory(workingDirectory.toFile());
            builder.redirectErrorStream(true);
            builder.redirectOutput(log.toFile());
            Process process = builder.start();
            boolean finished = process.waitFor(validationTimeoutSeconds, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                commandResult.setPassed(false);
                commandResult.setOutput("Command timed out after " + validationTimeoutSeconds + " seconds.");
                validation.setPassed(false);
                validation.getErrors().add(name + " timed out.");
            } else {
                int exit = process.exitValue();
                commandResult.setExitCode(exit);
                String output = Files.readString(log, StandardCharsets.UTF_8);
                commandResult.setOutput(limit(output));
                commandResult.setPassed(exit == 0);
                if (exit != 0) {
                    validation.setPassed(false);
                    validation.getErrors().add(name + " failed with exit code " + exit + ". See validation output.");
                }
            }
        } catch (Exception e) {
            commandResult.setPassed(false);
            commandResult.setOutput(e.getMessage());
            validation.setPassed(false);
            validation.getErrors().add(name + " could not run: " + e.getMessage());
        } finally {
            validation.getCommandResults().add(commandResult);
            if (log != null) {
                try { Files.deleteIfExists(log); } catch (IOException ignored) { }
            }
        }
    }

    private String limit(String output) {
        if (output == null) return "";
        if (output.length() <= maxOutputChars) return output;
        return output.substring(0, maxOutputChars) + System.lineSeparator() + "... output truncated ...";
    }

    private void deleteTree(Path root) {
        if (root == null || !Files.exists(root)) return;
        try {
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.deleteIfExists(file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    Files.deleteIfExists(dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (Exception ignored) { }
    }

    private boolean isDirectoryEmpty(Path path) throws IOException {
        try (var stream = Files.list(path)) {
            return stream.findAny().isEmpty();
        }
    }

    private boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }
}
