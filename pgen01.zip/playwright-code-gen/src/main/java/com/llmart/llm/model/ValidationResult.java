package com.llmart.llm.model;

import java.util.ArrayList;
import java.util.List;

public class ValidationResult {
    private boolean passed = true;
    private boolean runtimeValidationPerformed;
    private List<String> errors = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();
    private List<ValidationCommandResult> commandResults = new ArrayList<>();

    public boolean isPassed() { return passed; }
    public void setPassed(boolean passed) { this.passed = passed; }
    public boolean isRuntimeValidationPerformed() { return runtimeValidationPerformed; }
    public void setRuntimeValidationPerformed(boolean runtimeValidationPerformed) { this.runtimeValidationPerformed = runtimeValidationPerformed; }
    public List<String> getErrors() { return errors; }
    public void setErrors(List<String> errors) { this.errors = errors; }
    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
    public List<ValidationCommandResult> getCommandResults() { return commandResults; }
    public void setCommandResults(List<ValidationCommandResult> commandResults) { this.commandResults = commandResults; }
}
