package com.llmart.llm.controller;

import com.llmart.llm.model.GenerateRequest;
import com.llmart.llm.model.GenerateResponse;
import com.llmart.llm.model.LlmConnectionRequest;
import com.llmart.llm.service.GenerationService;
import com.llmart.llm.service.LlmService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class GenerationController {
    private final GenerationService generationService;
    private final LlmService llmService;

    public GenerationController(GenerationService generationService, LlmService llmService) {
        this.generationService = generationService;
        this.llmService = llmService;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "service", "Playwright code Gen");
    }

    @GetMapping("/llm/defaults")
    public Map<String, Object> llmDefaults() {
        return llmService.defaults();
    }

    @PostMapping(value = "/llm/health", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> llmHealth(@RequestBody(required = false) LlmConnectionRequest request) {
        return llmService.testConnection(request);
    }

    @PostMapping(value = "/generate/playwright", consumes = MediaType.APPLICATION_JSON_VALUE)
    public GenerateResponse generateFromJson(@RequestBody GenerateRequest request) {
        return generationService.generate(request);
    }

    @PostMapping(value = "/generate/playwright/form", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public GenerateResponse generateFromForm(
            @RequestParam("projectPath") String projectPath,
            @RequestParam(value = "recordedJsonFile", required = false) MultipartFile recordedJsonFile,
            @RequestParam(value = "recordedJsonPath", required = false) String recordedJsonPath,
            @RequestParam(value = "userInstruction", defaultValue = "Generate Playwright code for the recorded flow.") String userInstruction,
            @RequestParam(value = "writeMode", defaultValue = "DRY_RUN") String writeMode,
            @RequestParam(value = "targetModule", required = false) String targetModule,
            @RequestParam(value = "preferredTestFile", required = false) String preferredTestFile,
            @RequestParam(value = "preferredPageObject", required = false) String preferredPageObject,
            @RequestParam(value = "generateMissingMethods", defaultValue = "true") boolean generateMissingMethods,
            @RequestParam(value = "reuseExistingMethods", defaultValue = "true") boolean reuseExistingMethods,
            @RequestParam(value = "backupBeforeWrite", defaultValue = "true") boolean backupBeforeWrite,
            @RequestParam(value = "runValidation", defaultValue = "true") boolean runValidation,
            @RequestParam(value = "generateHtmlReport", defaultValue = "true") boolean generateHtmlReport,
            @RequestParam(value = "apiKey", required = false) String apiKey,
            @RequestParam(value = "modelName", required = false) String modelName,
            @RequestParam(value = "baseUrl", required = false) String baseUrl,
            @RequestParam(value = "temperature", required = false) Double temperature,
            @RequestParam(value = "maxTokens", required = false) Integer maxTokens
    ) throws Exception {
        GenerateRequest request = new GenerateRequest();
        request.setProjectPath(projectPath);
        request.setRecordedJsonPath(recordedJsonPath);
        request.setUserInstruction(userInstruction);
        request.setWriteMode(writeMode);
        request.setTargetModule(targetModule);
        request.setPreferredTestFile(preferredTestFile);
        request.setPreferredPageObject(preferredPageObject);
        request.setGenerateMissingMethods(generateMissingMethods);
        request.setReuseExistingMethods(reuseExistingMethods);
        request.setBackupBeforeWrite(backupBeforeWrite);
        request.setRunValidation(runValidation);
        request.setGenerateHtmlReport(generateHtmlReport);
        request.setApiKey(apiKey);
        request.setModelName(modelName);
        request.setBaseUrl(baseUrl);
        request.setTemperature(temperature);
        request.setMaxTokens(maxTokens);

        if (recordedJsonFile != null && !recordedJsonFile.isEmpty()) {
            String name = recordedJsonFile.getOriginalFilename();
            if (name != null && !name.toLowerCase().endsWith(".json")) {
                throw new IllegalArgumentException("Recorded file must be a .json file.");
            }
            request.setRecordedJsonContent(new String(recordedJsonFile.getBytes(), StandardCharsets.UTF_8));
        }
        return generationService.generate(request);
    }
}
