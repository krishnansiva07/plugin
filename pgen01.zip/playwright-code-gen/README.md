# Playwright code Gen

Playwright code Gen is a local Spring Boot utility that converts recorded UI JSON into Playwright TypeScript changes while analyzing and reusing an existing framework.

## What it does

- Scans an existing Playwright TypeScript project.
- Detects test files, page objects, helpers, fixtures and other TypeScript files.
- Accepts recorded JSON through the web UI.
- Uses an OpenAI-compatible LLM endpoint with API key/model configuration from the UI or environment variables.
- Honors target module, preferred test file and preferred page object choices.
- Honors reuse-existing-methods and generate-missing-methods controls.
- Generates complete final file contents instead of inserting snippets at an unsafe brace position.
- Uses DRY_RUN by default so code can be reviewed without changing source files.
- Performs mandatory path/content safety validation.
- When runtime validation is enabled, stages the generated project under a temporary hidden project directory and runs local TypeScript compile and Playwright test discovery when those tools are available.
- Creates backups before WRITE when backup is enabled.
- Produces HTML, JSON and Markdown reports with generated code and validation output.
- Listens on localhost by default.

## Prerequisites

- Java 17 or later.
- Maven.
- An existing Playwright TypeScript project with `package.json` containing Playwright.
- Run `npm install` in the target Playwright project if you want TypeScript/Playwright runtime validation.
- Access to an OpenAI-compatible LLM endpoint.

## Build

From the Playwright code Gen project directory:

```bash
mvn clean test
mvn clean package
```

The runnable JAR is created as:

```text
target/playwright-code-gen.jar
```

## Start

```bash
java -jar target/playwright-code-gen.jar
```

Then open:

```text
http://localhost:8090
```

## UI usage

1. Enter the LLM API key, model and OpenAI-compatible base URL.
2. Select **Test connection** to verify the LLM before generation.
3. Enter the local root path of the existing Playwright project. It should contain `package.json`.
4. Optionally enter a target module, preferred test file or preferred page object.
5. Browse or drag-and-drop the recorded `.json` file.
6. Enter the generation instruction.
7. Keep **DRY_RUN** selected for the first generation.
8. Configure method reuse, missing-method generation, runtime validation, backup and report controls.
9. Select **Generate Code**.
10. Review the complete proposed files and validation output in the UI/report.
11. Switch to **WRITE** only when the DRY_RUN result is correct. WRITE validates the staged copy before modifying the real project when runtime validation is enabled.

## LLM configuration

The UI values are applied per request. The API key is not stored by the UI.

Optional environment defaults are also supported:

```text
LLM_API_KEY
LLM_MODEL_NAME
LLM_BASE_URL
LLM_TEMPERATURE
LLM_MAX_TOKENS
LLM_TIMEOUT_SECONDS
```

If environment defaults are configured, the UI can load the non-secret defaults. The API key value itself is never returned to the browser.

## Runtime validation behavior

The app always performs structural/path safety validation. That validation cannot be disabled.

When **Validate generated code** is enabled, Playwright code Gen creates a hidden temporary staging copy under the target project, applies the proposed full-file changes there, and attempts:

```text
TypeScript compiler: --noEmit
Playwright: test --list
```

The commands use the target project's local `node_modules/.bin` tools. If local dependencies are not installed, DRY_RUN clearly marks runtime checks as skipped. WRITE is blocked while runtime validation is enabled until the local Playwright binary is available. You can explicitly disable runtime validation if you intentionally want structural-only validation.

The staging directory is removed after validation. The scanner ignores any stale staging directory left after an unexpected process termination.

## WRITE safety

WRITE mode:

- permits only project-relative `.ts`/`.tsx` source changes;
- blocks traversal outside the selected project;
- honors target-module boundaries;
- requires complete final file content;
- rejects CREATE against an existing file and UPDATE against a missing file;
- blocks unsafe new page-object methods when missing-method generation is disabled;
- backs up existing files when backup is enabled;
- performs best-effort rollback if a write operation fails part way through.

Backups are stored under:

```text
.playwright-code-gen-backup/
```

Reports are stored under:

```text
playwright-code-gen-reports/
```

## REST endpoints

The UI uses these endpoints internally:

```text
GET  /api/health
GET  /api/llm/defaults
POST /api/llm/health
POST /api/generate/playwright
POST /api/generate/playwright/form
```

The service binds to `127.0.0.1` by default so it is not exposed to other machines unless you intentionally change that setting.
