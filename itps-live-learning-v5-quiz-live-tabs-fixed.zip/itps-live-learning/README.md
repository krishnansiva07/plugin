# ITPS Live Learning - V5 Quiz and Live Tab Fix

## What is fixed in V5

- Quiz questions are now generated with a unique focus for each question.
- Previous questions are sent to the backend so the LLM is instructed not to repeat them.
- If the LLM still repeats a question, the frontend replaces it with a unique fallback question.
- MCQ options are validated on both backend and frontend.
- Empty or missing options are automatically replaced with four meaningful options.
- `correctAnswer` is forced to match one available option.
- Tabs no longer show `[object Object]`.
- Tab names remain stable.
- If a tab has no content, the app generates that tab content live when clicked.
- Diagrams are now topic/subtopic specific, not one generic diagram for all pages.
- SQL fallback diagram uses SELECT -> FROM -> WHERE -> ORDER BY -> Result set.
- Programming topics keep coding exercises.
- BNP green theme, PDF download, certificate title editing, and code copy button are retained.

## Run

```bash
cd itps-live-learning
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

## LLM setup

Update:

```text
src/main/resources/application.properties
```

```properties
llm.api-key=YOUR_KEY
llm.model-name=devstral-medium-2512
llm.base-url=YOUR_BASE_URL
```
