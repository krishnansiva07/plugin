package com.llmart.llm.model;

public class LearningRequest {
    private String userPrompt;
    private String topic;
    private String subTopic;
    private String level = "Beginner";
    private String purpose = "General Learning";
    private String category;
    private Integer questionNumber;
    private Integer totalQuestions;
    private String questionType;
    private String previousQuestions;

    public String getUserPrompt() { return userPrompt; }
    public void setUserPrompt(String userPrompt) { this.userPrompt = userPrompt; }
    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }
    public String getSubTopic() { return subTopic; }
    public void setSubTopic(String subTopic) { this.subTopic = subTopic; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Integer getQuestionNumber() { return questionNumber; }
    public void setQuestionNumber(Integer questionNumber) { this.questionNumber = questionNumber; }
    public Integer getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(Integer totalQuestions) { this.totalQuestions = totalQuestions; }
    public String getQuestionType() { return questionType; }
    public void setQuestionType(String questionType) { this.questionType = questionType; }
    public String getPreviousQuestions() { return previousQuestions; }
    public void setPreviousQuestions(String previousQuestions) { this.previousQuestions = previousQuestions; }
}
