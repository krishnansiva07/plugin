package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.llmart.llm.model.LearningRequest;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class LearningService {
    private final ChatLanguageModel chatModel;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, JsonNode> contentCache = new ConcurrentHashMap<>();
    private final Map<String, JsonNode> quizCache = new ConcurrentHashMap<>();

    public LearningService(ChatLanguageModel chatModel) {
        this.chatModel = chatModel;
    }

    public JsonNode classify(LearningRequest request) {
        String prompt = """
                You are a learning request classifier.
                Classify the request into TECHNICAL, FUNCTIONAL, CONCEPTUAL, PROCESS, FINANCE, CUSTOM.
                Identify topic, level, purpose, whether code is needed, business flow is needed, and quiz should be enabled.
                Default purpose is General Learning. Do not assume automation/testing unless explicitly asked.
                Return only valid JSON. No markdown.
                User request: %s
                """.formatted(nullSafe(request.getUserPrompt(), request.getTopic()));
        return parseOrFallback(chatModel.generate(prompt), fallbackClassification(request));
    }

    public JsonNode roadmap(LearningRequest request) {
        JsonNode classification = classify(request);
        String prompt = """
                You are ITPS Live Learning roadmap generator and a real tutor.
                Generate only a roadmap, not full lesson content.
                Topic: %s
                Category: %s
                Requested depth: %s
                Purpose: %s

                Teaching rules:
                - Do not assume automation/testing.
                - Do not include interview preparation.
                - Think like a textbook author: teach basics first, then intermediate, then advanced.
                - Do not force exactly 10 modules. Choose the number based on the topic. Usually 12 to 18 modules for Complete, 7 to 10 for Beginner, 9 to 13 for Intermediate/Advanced.
                - Last module must be Quiz / Assessment.
                - Every module must be meaningful and teachable; no empty or generic module names.
                - Technical topics should include foundations, syntax/structure, practical examples, patterns, mistakes, practice, summary.
                - Functional/business topics should include purpose, actors/parties, lifecycle, step-by-step flow, exceptions, examples, summary.
                - Return only valid JSON with this exact shape:
                  {title, category, level, purpose, modules[{id,title,stage,description,status}]}
                - stage must be one of: Basics, Intermediate, Advanced, Assessment.
                """.formatted(
                text(classification, "topic", nullSafe(request.getTopic(), request.getUserPrompt())),
                text(classification, "category", "CUSTOM"),
                text(classification, "level", defaultValue(request.getLevel(), "Beginner")),
                text(classification, "purpose", defaultValue(request.getPurpose(), "General Learning"))
        );
        return parseOrFallback(chatModel.generate(prompt), fallbackRoadmap(request, classification));
    }

    public JsonNode content(LearningRequest request) {
        String key = String.join("|", defaultValue(request.getTopic(), "custom"), defaultValue(request.getSubTopic(), "overview"), defaultValue(request.getLevel(), "beginner"));
        if (contentCache.containsKey(key)) return contentCache.get(key);

        String category = defaultValue(request.getCategory(), "AUTO");
        String prompt = """
                You are ITPS Live Learning Tutor. Teach like a clear textbook teacher.
                Create rich one-screen lesson content as strict JSON. No markdown.
                Topic: %s
                Sub topic: %s
                Level: %s
                Purpose: %s
                Category hint: %s

                Return JSON with this exact shape:
                {
                  "topicType":"TECHNICAL or FUNCTIONAL or CUSTOM",
                  "title":"lesson title",
                  "shortSummary":"2 sentence learning objective",
                  "tabs":["Overview","Concepts","Example","Practice","Summary"],
                  "sections":[
                    {"tab":"Overview","heading":"...","type":"text","content":"..."},
                    {"tab":"Concepts","heading":"...","type":"steps","items":["..."]},
                    {"tab":"Example","heading":"...","type":"code","content":"..."}
                  ],
                  "diagram":{"type":"FLOW","nodes":[{"id":"1","label":"...","icon":"box"}],"edges":[{"from":"1","to":"2","label":"..."}]},
                  "relatedTopics":["..."],
                  "quickActions":["Explain Simpler","Generate Quiz","Download Page as PDF"]
                }

                Important JSON rules:
                - tabs must be an array of strings only. Never return objects inside tabs.
                - Every tab you return must have at least one matching section with the same tab value.
                - Do not return empty sections. If a subtopic has no content, do not include it.
                - sections must include a tab field.

                Teaching quality rules:
                - Do not assume automation/testing.
                - Explain from basics to the selected depth. Use simple English, but not shallow content.
                - For technical topics include concept, syntax, practical example, common mistakes, and one small practice task.
                - For programming/database topics include useful code/query examples.
                - For functional/business topics do not include code unless requested; include business purpose, actors, lifecycle, step-by-step flow, exceptions, key terms.
                - Avoid generic filler. Content must be specific to the requested topic and subtopic.
                - Diagram must be specific to this subtopic. Do not return a generic Basics -> Example -> Practice diagram unless the subtopic itself is about that flow.
                - For SQL topics, diagrams can show query execution/logical order or table-to-result flow.
                - For payment/business topics, diagrams can show actor-to-actor process flow.
                """.formatted(
                defaultValue(request.getTopic(), request.getUserPrompt()),
                defaultValue(request.getSubTopic(), "Overview"),
                defaultValue(request.getLevel(), "Beginner"),
                defaultValue(request.getPurpose(), "General Learning"),
                category
        );
        JsonNode result = parseOrFallback(chatModel.generate(prompt), fallbackContent(request));
        contentCache.put(key, result);
        return result;
    }

    public JsonNode quiz(LearningRequest request) {
        String prompt = """
                Create an ITPS Live Learning quiz for the topic.
                Topic: %s
                Level: %s
                Purpose: %s
                Generate 10 MCQ questions.
                Pass percentage is 80.
                Return only valid JSON:
                {quizId,title,passPercentage,questions[{questionId,question,options[],correctAnswer,explanation,linkedTopic}]}
                """.formatted(defaultValue(request.getTopic(), request.getUserPrompt()), defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getPurpose(), "General Learning"));
        JsonNode quiz = parseOrFallback(chatModel.generate(prompt), fallbackQuiz(request));
        quizCache.put(text(quiz, "quizId", "QUIZ-DEMO"), quiz);
        return quiz;
    }


    public JsonNode quizQuestion(LearningRequest request) {
        int qNo = request.getQuestionNumber() == null ? 1 : request.getQuestionNumber();
        int total = request.getTotalQuestions() == null ? 10 : request.getTotalQuestions();
        String qType = defaultValue(request.getQuestionType(), "MCQ").toUpperCase();
        String topic = defaultValue(request.getTopic(), request.getUserPrompt());
        String subTopic = defaultValue(request.getSubTopic(), "General");
        String focus = quizFocus(topic, subTopic, qNo, total, qType);

        String prompt;
        if ("CODING".equals(qType)) {
            prompt = """
                    Create one unique live coding exercise for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Focus for this question: %s
                    Level: %s
                    Question number: %d of %d
                    Previous questions already asked: %s
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, instruction, sampleSolution, linkedTopic}
                    Rules:
                    - Do not repeat previous questions.
                    - Keep the exercise small enough to solve in 5 to 10 minutes.
                    - sampleSolution must contain clean sample code/query relevant to the topic.
                    """.formatted(topic, subTopic, focus, defaultValue(request.getLevel(), "Beginner"), qNo, total, defaultValue(request.getPreviousQuestions(), "None"));
        } else {
            prompt = """
                    Create exactly one unique live MCQ question for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Focus for this question: %s
                    Level: %s
                    Category: %s
                    Question number: %d of %d
                    Previous questions already asked: %s
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, options[], correctAnswer, explanation, linkedTopic}
                    Rules:
                    - The question must be about the focus area above, not a generic definition.
                    - Do not repeat previous questions.
                    - options must contain exactly 4 meaningful options.
                    - correctAnswer must exactly match one option text.
                    - Do not leave options empty.
                    - Do not include testing/automation unless user purpose asks for it.
                    """.formatted(topic, subTopic, focus, defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getCategory(), "CUSTOM"), qNo, total, defaultValue(request.getPreviousQuestions(), "None"));
        }
        JsonNode parsed = parseOrFallback(chatModel.generate(prompt), fallbackQuizQuestion(request, qNo, total, qType));
        return validateQuizQuestion(parsed, request, qNo, total, qType, focus);
    }

    public JsonNode certificate(String learnerName, String courseTitle, String courseType, String level, int score, String certificateTitle) {
        ObjectNode node = mapper.createObjectNode();
        node.put("title", defaultValue(certificateTitle, "ITPS Live Certification"));
        node.put("learnerName", defaultValue(learnerName, "Learner"));
        node.put("courseTitle", defaultValue(courseTitle, "Live Learning Assessment"));
        node.put("score", score);
        node.put("passPercentage", 80);
        node.put("result", score >= 80 ? "PASS" : "RETAKE_REQUIRED");
        node.put("courseType", defaultValue(courseType, "General Learning"));
        node.put("level", defaultValue(level, "Beginner"));
        node.put("assessmentMode", "Live Quiz");
        node.put("completionDate", LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
        node.put("certificateId", "ITPS-" + System.currentTimeMillis());
        return node;
    }

    private JsonNode parseOrFallback(String response, JsonNode fallback) {
        try {
            String cleaned = response.replace("```json", "").replace("```", "").trim();
            int start = cleaned.indexOf('{');
            int end = cleaned.lastIndexOf('}');
            if (start >= 0 && end > start) cleaned = cleaned.substring(start, end + 1);
            return mapper.readTree(cleaned);
        } catch (Exception e) {
            return fallback;
        }
    }

    private JsonNode fallbackClassification(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        String prompt = nullSafe(r.getUserPrompt(), r.getTopic());
        String category = prompt.toLowerCase().matches(".*(java|spring|python|react|azure|api|docker|kafka|selenium).*" ) ? "TECHNICAL" : "FUNCTIONAL";
        n.put("topic", prompt.replace("I want to learn", "").trim());
        n.put("category", category);
        n.put("level", defaultValue(r.getLevel(), "Beginner"));
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        n.put("needsCode", category.equals("TECHNICAL"));
        n.put("needsBusinessFlow", category.equals("FUNCTIONAL"));
        n.put("quizEnabled", true);
        return n;
    }

    private JsonNode fallbackRoadmap(LearningRequest r, JsonNode c) {
        ObjectNode n = mapper.createObjectNode();
        String category = text(c, "category", "CUSTOM");
        String topic = text(c, "topic", nullSafe(r.getTopic(), r.getUserPrompt()));
        String level = defaultValue(r.getLevel(), "Complete");
        n.put("title", topic + " Learning Path");
        n.put("category", category);
        n.put("level", level);
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        var arr = n.putArray("modules");

        List<String[]> titles;
        if (category.equals("TECHNICAL")) {
            titles = List.of(
                    new String[]{"Basics", "What is " + topic + "?"},
                    new String[]{"Basics", "Why and where it is used"},
                    new String[]{"Basics", "Core terminology and building blocks"},
                    new String[]{"Basics", "Basic syntax and first example"},
                    new String[]{"Intermediate", "Common operations and practical usage"},
                    new String[]{"Intermediate", "Real-world example explained step by step"},
                    new String[]{"Intermediate", "Common mistakes and how to avoid them"},
                    new String[]{"Advanced", "Advanced concepts and best practices"},
                    new String[]{"Advanced", "Mini practice exercise"},
                    new String[]{"Advanced", "Summary and review"},
                    new String[]{"Assessment", "Quiz / Assessment"}
            );
        } else {
            titles = List.of(
                    new String[]{"Basics", "What is " + topic + "?"},
                    new String[]{"Basics", "Business purpose and real-life need"},
                    new String[]{"Basics", "Key parties and responsibilities"},
                    new String[]{"Intermediate", "End-to-end process flow"},
                    new String[]{"Intermediate", "Status lifecycle and important events"},
                    new String[]{"Intermediate", "Real-life business example"},
                    new String[]{"Advanced", "Exceptions, failures, returns, and edge cases"},
                    new String[]{"Advanced", "Rules, controls, and operational checks"},
                    new String[]{"Advanced", "Summary and review"},
                    new String[]{"Assessment", "Quiz / Assessment"}
            );
        }
        int i=1;
        for (String[] t: titles) {
            ObjectNode m=arr.addObject();
            m.put("id", "M"+i++);
            m.put("title", t[1]);
            m.put("stage", t[0]);
            m.put("description", "Learn " + t[1] + " for " + topic);
            m.put("status", "NOT_GENERATED");
        }
        return n;
    }

    private JsonNode fallbackContent(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        String category = defaultValue(r.getCategory(), "CUSTOM");
        String topic = defaultValue(r.getTopic(), "Topic");
        String sub = defaultValue(r.getSubTopic(), "Overview");
        boolean technical = category.equalsIgnoreCase("TECHNICAL") || topic.toLowerCase().matches(".*(java|python|sql|spring|react|api|database).*" );
        n.put("topicType", category);
        n.put("title", sub);
        n.put("shortSummary", "This lesson explains " + sub + " in a structured textbook style with examples, practice, and review points.");
        ArrayNode tabs = n.putArray("tabs");
        tabs.add("Overview").add("Key Concepts").add("Example").add("Practice").add("Summary");
        ArrayNode sections = n.putArray("sections");

        ObjectNode s1 = sections.addObject();
        s1.put("tab","Overview");
        s1.put("heading", "Simple Explanation");
        s1.put("type", "text");
        s1.put("content", sub + " is a focused part of " + topic + ". First understand what it means, then why it is used, then apply it in a small example.");

        ObjectNode s2 = sections.addObject();
        s2.put("tab","Key Concepts");
        s2.put("heading", technical ? "Core Technical Points" : "Business Concepts");
        s2.put("type", "steps");
        ArrayNode items=s2.putArray("items");
        items.add("Purpose: what problem this subtopic solves");
        items.add("Structure: the main parts involved");
        items.add("Flow: how it works step by step");
        items.add("Usage: where you will apply it in real work");

        ObjectNode s3 = sections.addObject();
        s3.put("tab","Example");
        s3.put("heading", technical ? "Working Example" : "Real-Life Example");
        s3.put("type", technical ? "code" : "text");
        if (topic.toLowerCase().contains("sql")) {
            s3.put("content", "-- Example for " + sub + "\nSELECT customer_id, customer_name, city\nFROM customers\nWHERE city = 'Paris'\nORDER BY customer_name ASC;");
        } else if (technical) {
            s3.put("content", "// Small example for " + sub + "\n// Replace this with topic-specific code from the live model response.");
        } else {
            s3.put("content", "Example: A learner follows the " + sub + " flow in " + topic + " from start to finish, identifies the parties involved, and understands the final outcome.");
        }

        ObjectNode s4 = sections.addObject();
        s4.put("tab","Practice");
        s4.put("heading", "Practice Task");
        s4.put("type", "text");
        s4.put("content", "Create your own small example for " + sub + " and explain each step in simple English.");

        ObjectNode s5 = sections.addObject();
        s5.put("tab","Summary");
        s5.put("heading", "Quick Recap");
        s5.put("type", "steps");
        ArrayNode rec=s5.putArray("items");
        rec.add("Know the purpose of " + sub);
        rec.add("Remember the key terms and flow");
        rec.add("Practice one realistic example");

        ObjectNode d = n.putObject("diagram");
        d.put("type", "FLOW");
        ArrayNode nodes = d.putArray("nodes");
        if (topic.toLowerCase().contains("sql")) {
            addNode(nodes,"1","SELECT columns","box"); addNode(nodes,"2","FROM table","box"); addNode(nodes,"3","WHERE filter","box"); addNode(nodes,"4","ORDER BY sort","box"); addNode(nodes,"5","Result set","box");
        } else if (technical) {
            addNode(nodes,"1","Concept","box"); addNode(nodes,"2","Syntax / Structure","box"); addNode(nodes,"3","Example","box"); addNode(nodes,"4","Practice","box");
        } else {
            addNode(nodes,"1","Need","user"); addNode(nodes,"2","Process","network"); addNode(nodes,"3","Validation","box"); addNode(nodes,"4","Outcome","box");
        }
        ArrayNode edges = d.putArray("edges");
        for (int i=1;i<nodes.size();i++) edges.addObject().put("from", String.valueOf(i)).put("to", String.valueOf(i+1)).put("label", "");

        n.putArray("relatedTopics").add(topic + " basics").add(sub + " example").add(sub + " common mistakes");
        n.putArray("quickActions").add("Explain Simpler").add("Generate Quiz").add("Download Page as PDF");
        return n;
    }

    private JsonNode fallbackQuiz(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        n.put("quizId", "QUIZ-DEMO"); n.put("title", defaultValue(r.getTopic(), "Topic") + " Quiz"); n.put("passPercentage", 80);
        var qs = n.putArray("questions");
        for (int i=1;i<=10;i++) { ObjectNode q=qs.addObject(); q.put("questionId", "Q"+i); q.put("question", "Sample question " + i + " for " + defaultValue(r.getTopic(), "topic") + "?"); q.putArray("options").add("Option A").add("Option B").add("Option C").add("Option D"); q.put("correctAnswer", "Option A"); q.put("explanation", "Option A is correct for this sample question."); q.put("linkedTopic", defaultValue(r.getTopic(), "topic")); }
        return n;
    }


    private JsonNode fallbackQuizQuestion(LearningRequest r, int qNo, int total, String qType) {
        ObjectNode q = mapper.createObjectNode();
        String topic = defaultValue(r.getTopic(), "topic");
        String sub = defaultValue(r.getSubTopic(), topic);
        String focus = quizFocus(topic, sub, qNo, total, qType);
        q.put("questionId", "Q" + qNo);
        q.put("questionType", qType);
        q.put("linkedTopic", sub);
        if ("CODING".equals(qType)) {
            q.put("question", "Create a small example for " + focus + ".");
            q.put("instruction", "Write a simple, readable answer. For SQL, write a query. For programming, write a small method or snippet.");
            if (topic.toLowerCase().contains("sql")) {
                q.put("sampleSolution", "SELECT column_name\nFROM table_name\nWHERE condition\nORDER BY column_name;");
            } else {
                q.put("sampleSolution", "// Write a small example here based on " + focus);
            }
        } else {
            q.put("question", "In " + topic + ", which option best matches: " + focus + "?");
            ArrayNode options = q.putArray("options");
            String correct = "It explains " + focus + " as part of " + topic;
            options.add(correct);
            options.add("It is unrelated to " + topic);
            options.add("It is only used for certificate generation");
            options.add("It always means the same thing in every subject");
            q.put("correctAnswer", correct);
            q.put("explanation", "This question checks your understanding of " + focus + " within " + topic + ".");
        }
        return q;
    }

    private JsonNode validateQuizQuestion(JsonNode parsed, LearningRequest r, int qNo, int total, String qType, String focus) {
        if (parsed == null || !parsed.isObject()) return fallbackQuizQuestion(r, qNo, total, qType);
        ObjectNode q = parsed.deepCopy();
        q.put("questionId", text(q, "questionId", "Q" + qNo));
        q.put("questionType", text(q, "questionType", qType).toUpperCase());
        q.put("linkedTopic", text(q, "linkedTopic", defaultValue(r.getSubTopic(), defaultValue(r.getTopic(), "topic"))));
        if (!q.hasNonNull("question") || q.get("question").asText().isBlank()) {
            q.put("question", "Question " + qNo + ": " + focus);
        }
        if ("CODING".equals(q.get("questionType").asText())) {
            if (!q.hasNonNull("instruction")) q.put("instruction", "Write a small working answer.");
            if (!q.hasNonNull("sampleSolution")) q.put("sampleSolution", "// Sample solution depends on the topic.");
            return q;
        }
        List<String> opts = new ArrayList<>();
        if (q.has("options") && q.get("options").isArray()) {
            for (JsonNode o : q.get("options")) {
                String val = o.asText("").trim();
                if (!val.isBlank() && !opts.contains(val)) opts.add(val);
            }
        }
        String topic = defaultValue(r.getTopic(), "topic");
        while (opts.size() < 4) {
            String candidate = switch (opts.size()) {
                case 0 -> "It explains " + focus + " as part of " + topic;
                case 1 -> "It is not related to " + topic;
                case 2 -> "It is only a certificate title";
                default -> "It can be skipped in this learning path";
            };
            if (!opts.contains(candidate)) opts.add(candidate);
        }
        ArrayNode arr = mapper.createArrayNode();
        opts.stream().limit(4).forEach(arr::add);
        q.set("options", arr);
        String correct = text(q, "correctAnswer", opts.get(0));
        if (!opts.contains(correct)) correct = opts.get(0);
        q.put("correctAnswer", correct);
        if (!q.hasNonNull("explanation")) q.put("explanation", "This checks the focus area: " + focus + ".");
        return q;
    }

    private String quizFocus(String topic, String subTopic, int qNo, int total, String qType) {
        List<String> technical = List.of("basic purpose", "key terminology", "syntax or structure", "how the flow works", "practical usage", "common mistake", "best practice", "scenario-based understanding", "small example", "summary check");
        List<String> functional = List.of("business purpose", "parties involved", "input information", "step-by-step flow", "status lifecycle", "exception scenario", "real-life example", "rules and controls", "common mistake", "summary check");
        boolean tech = topic.toLowerCase().matches(".*(java|python|javascript|typescript|sql|spring|react|api|database|coding|programming).*" );
        List<String> list = tech ? technical : functional;
        String base = list.get(Math.max(0, Math.min(qNo-1, list.size()-1)));
        return subTopic + " - " + base;
    }

    private void addNode(ArrayNode nodes, String id, String label, String icon) {
        ObjectNode node = nodes.addObject();
        node.put("id", id); node.put("label", label); node.put("icon", icon);
    }

    private String text(JsonNode node, String field, String def) { return node != null && node.has(field) ? node.get(field).asText(def) : def; }
    private String defaultValue(String v, String d) { return v == null || v.isBlank() ? d : v; }
    private String nullSafe(String a, String b) { return defaultValue(a, defaultValue(b, "Custom Topic")); }
}
