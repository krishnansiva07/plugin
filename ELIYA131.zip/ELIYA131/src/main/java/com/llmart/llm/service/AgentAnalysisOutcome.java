package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Last-mile read-only analysis delivery. No new model call, workspace scan or implicit edit.
 * Only recorded changed Markdown reports can replace the displayed report text.
 */
final class AgentAnalysisOutcome {
    private static final Pattern ANALYSIS_REQUEST = Pattern.compile(
            "(?i)\\b(?:analy[sz]e|analysis|review|investigate|compare|audit|assess|evaluate|explain|inspect|trace|architecture)\\b");
    private static final Pattern REPORT_REQUEST = Pattern.compile(
            "(?i)(?:\\b(?:save|write|create|generate|export|deliver)\\b.{0,100}\\b(?:markdown|\\.md|report)\\b|" +
            "\\b(?:markdown|md)\\s+(?:file|report|document)\\b|[a-zA-Z0-9_.-]+\\.md\\b)");
    private static final Pattern RECOMMENDATIONS = Pattern.compile(
            "(?im)^#{1,5}\\s*(?:key\\s+)?(?:recommendations?|suggested\\s+improvements?|next\\s+steps?|proposed\\s+fixes?)\\s*:?\\s*$");
    private static final Pattern BULLET = Pattern.compile("^\\s*(?:[-*]|[1-9][0-9]?[.)])\\s+(.{8,240})$");
    private static final Pattern HEADING = Pattern.compile("^\\s*#{1,6}\\s+.+");
    private AgentAnalysisOutcome() { }

    static boolean isAnalysis(String objective) {
        return objective != null && (AgentPlanRelevance.isReadOnlyAnalysisRequest(objective) ||
                AgentResultPresentation.isDeepAnalysis(objective) || ANALYSIS_REQUEST.matcher(objective).find());
    }

    static String recommendedAction(String objective, String answer) {
        if (!isAnalysis(objective) || !AgentResultPresentation.hasSubstantiveAnswer(answer) ||
                answer.contains("**Suggested next step:**")) return "";
        String[] lines = answer.split("\\R", 200);
        boolean inRecommendations = false;
        for (String line : lines) {
            if (RECOMMENDATIONS.matcher(line).matches()) { inRecommendations = true; continue; }
            if (inRecommendations && HEADING.matcher(line).matches()) break;
            if (!inRecommendations) continue;
            Matcher bullet = BULLET.matcher(line);
            if (bullet.matches()) {
                String item = bullet.group(1).replaceAll("[`*]", "").replaceAll("\\s+", " ").strip();
                // Do not turn text containing commands, links or explicit destruction into a
                // one-click follow-up. The proposed next action is a plan, not a file edit.
                if (item.length() < 12 || item.matches("(?i).*(?:https?://|\\b(?:delete|remove|drop|erase|format)\\b).*")) return "";
                item = item.length() > 155 ? item.substring(0, 152) + "…" : item;
                return "prepare a scoped implementation plan for this recommendation: " + item;
            }
        }
        return "";
    }

    /** Read *only* an output from the current run's changed-file inventory. */
    static Report verifiedMarkdownReport(Path root, String objective,
                                         List<ProjectPatchRequest.ProjectPatchFile> changes) {
        if (root == null || !isAnalysis(objective) || objective == null ||
                !REPORT_REQUEST.matcher(objective).find() || changes == null) return null;
        try {
            Path realRoot = root.toRealPath();
            for (ProjectPatchRequest.ProjectPatchFile file : changes) {
                if (file == null || file.path() == null || "delete".equalsIgnoreCase(file.operation()) ||
                        !file.path().toLowerCase(Locale.ROOT).endsWith(".md")) continue;
                String relative = file.path().replace('\\', '/');
                // When named, a different Markdown file must not masquerade as the output.
                Matcher named = Pattern.compile("(?i)\\b([a-z0-9_./-]+\\.md)\\b").matcher(objective.replace('\\', '/'));
                boolean explicit = false, matched = false;
                while (named.find()) {
                    explicit = true;
                    String name = named.group(1);
                    if (relative.equalsIgnoreCase(name) || relative.toLowerCase(Locale.ROOT).endsWith("/" + name.toLowerCase(Locale.ROOT))) matched = true;
                }
                if (explicit && !matched) continue;
                if (!explicit && !relative.toLowerCase(Locale.ROOT).matches(".*(analysis|review|report|architecture|flow|design|assessment|findings).*\\.md")) continue;
                Path target = realRoot.resolve(relative).normalize();
                if (!target.startsWith(realRoot) || !Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) continue;
                boolean hasLink = false;
                for (Path check = target; check != null && check.startsWith(realRoot); check = check.getParent()) {
                    if (Files.isSymbolicLink(check)) { hasLink = true; break; }
                    if (check.equals(realRoot)) break;
                }
                if (hasLink || !target.toRealPath().startsWith(realRoot)) continue;
                long bytes = Files.size(target);
                if (bytes < 120 || bytes > 200_000) continue;
                String text = Files.readString(target, StandardCharsets.UTF_8).strip();
                if (!AgentResultPresentation.hasSubstantiveAnswer(text)) continue;
                boolean clipped = text.length() > 26_000;
                if (clipped) text = text.substring(0, 26_000) +
                        "\n\n*Report preview truncated. The complete verified report is in `" + relative.replace("`", "") + "`.*";
                return new Report(relative, text, clipped);
            }
        } catch (Exception ignored) { /* A missing report is never claimed as verified. */ }
        return null;
    }

    record Report(String path, String content, boolean truncated) { }
}
