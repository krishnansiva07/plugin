# ELIYA130 — Analysis outcomes, continuity and execution visibility

**Base:** the user's ELIYA129_Terminal_Agent_Completion_Fixes.zip.  **Java target:** 17.

## User-visible behavior

### Analysis is a first-class deliverable

- The existing fast read-only analysis path is retained: read-only investigations skip the extra planning-model call and cannot edit workspace files by default.
- After successful analysis, Eliya keeps the substantive Markdown response directly in the conversation. It does not replace a useful answer with generic status output.
- If the analysis genuinely includes a `## Recommendations` / `## Next steps` section and an actionable recommendation, Eliya proposes a **scoped implementation plan** based on the actual first recommendation. No invented recommendation is added when the analysis has none.
- The suggestion is appended as `**Suggested next step:** ...` and uses the existing continuation flow. `yes`, `yes, only ...`, and `yes, but ...` continue that exact suggested next step with the user's additional restriction, in the same conversation. `no` takes no action. A suggestion without this explicit marker does not authorize execution.
- If the investigation cannot produce a grounded answer, the runtime now marks the analysis **blocked**, rather than treating the missing-evidence fallback as a successful answer.

### Report and conversation synchronization

- When the user explicitly asks for a Markdown analysis report and the current run actually created/updated that report, Eliya reads the file back and uses its content as the authoritative conversation answer, rather than launching an additional synthesis model call.
- This behavior only reads **recorded changed files** from the current run under the selected workspace. It rejects absolute/escaping paths, symlinks and missing/oversized files. A different named Markdown file cannot substitute for the requested output.
- A report file that is not created/updated by the run is never presented as a verified output. Requested PDF/Word/Excel artifacts still use existing file-generation and verification paths; this change does **not** claim to parse or synchronize those formats.
- If a report was saved but not verified, the next-step suggestion prioritizes verifying its source evidence rather than implying that all results are correct.

### Execution economy and measured timings

- Existing index-first retrieval, token compaction, read-only parallel tool batching, repeated-call detection, and read-only planning fast path remain enabled.
- A **new targeted retrieval optimization** avoids the second dependency-impact lookup for *simple factual read-only questions*. Architecture, lifecycle, flow, caller/dependency, `how`/`why`, and implementation questions continue to request dependency-impact evidence.
- New per-run stage timers: workspace resolution, planning/context preparation, source evidence retrieval, tool/command execution, verification, answer synthesis, and final reporting. Times are persisted with the run and surfaced in the Agent UI's execution details.
- Provider latency and total elapsed wall time are shown separately. They **overlap** other operations; values must not be summed into a claimed speedup. User-approval waiting and uninstrumented operations may account for remaining time.
- A report read-back bypasses unnecessary final answer synthesis when the source report already supplies the requested analysis.
- These are code-level changes. There is **no measured comparison** to ELIYA129 or OpenCode on a live user workload in this environment.

## Source locations changed

- `src/main/java/com/llmart/llm/service/AgentAnalysisOutcome.java` — report read-back and analysis-specific next steps.
- `src/main/java/com/llmart/llm/service/AgentCompletionNarrator.java` — analysis completion and continuation refinement.
- `src/main/java/com/llmart/llm/service/AgentResultPresentation.java` — missing-evidence fallback detection.
- `src/main/java/com/llmart/llm/service/AgentImpactRetrievalPolicy.java` — selective retrieval fast path.
- `src/main/java/com/llmart/llm/service/AgentStageMetrics.java` — durable timing counters.
- `src/main/java/com/llmart/llm/service/AgentRunService.java` — persistent measured stages and elapsed time.
- `src/main/java/com/llmart/llm/service/AgentService.java` — wiring at workspace setup, planning, retrieval, tool execution, answer recovery, Markdown read-back, and completion gate.
- `src/main/resources/static/app.js` — execution timing details in the Agent activity panel.
- `qa/eliya130` and existing Java smoke harnesses — regression coverage.

## How to test on a Windows workstation

1. Extract the ZIP and build with Java 17 and Maven: `mvn -B -DskipTests clean package` (or `mvn -Pfull-tests -Dmaven.test.skip=false clean verify` where dependencies are available).
2. Start the JAR and use an existing Java Selenium workspace. In the browser or CLI, ask `Analyse the existing WebDriver lifecycle and recommend improvements. Do not modify files.` Confirm a detailed grounded answer, no changes, a specific next-step proposal if recommendations exist, and timing details.
3. Reply `yes, only for parallel execution`. Confirm that Eliya continues the exact proposed next step within the same workspace and explains any uncertainty; it must not independently edit files if the accepted suggestion only requested a plan.
4. Ask `Analyse my current Selenium framework and generate docs/framework-analysis.md`. Confirm the saved Markdown file exists, is readable, and the conversation includes its actual content rather than a generic success message. Verify the file list and the exact path.
5. Ask for a simple factual query and a deep architecture/flow query; confirm that targeted source evidence and references remain correct and that the latter retains dependency analysis.
6. Run the **same** baseline test-case generation, migration and large-analysis prompts that were previously timed, with the same model/provider/hardware/workspace state. Record elapsed time, input/output tokens, provider latency, retrieval time, tool time, verification time, and finalization time. Compare medians over repeat runs. Do not assume a speedup without data.
7. Reload the UI and inspect persisted timing metrics and final answer. Validate `eliya analyse`, `eliya agent`, `/implement`, workspace isolation and OS launcher setup from a fresh IDE terminal.

## Local validation (source-level only)

- `qa/eliya130/run.sh`: **29 checks passed** (analysis, report source safety, next-step continuity, impact-policy and metrics).
- `qa/eliya129/run-completion-smoke.sh`: **20 checks passed**.
- `qa/eliya128/run-auto-setup-smoke.sh`: **36 assertions passed**, plus JAR path-detection smoke.
- `qa/eliya126/run-java-cli-smoke.sh`, `qa/eliya126/run-terminal-smoke.sh`, `qa/eliya127/run-rich-renderer-smoke.sh`: **passed**.
- `qa/token-usage-smoke/run.sh`, `qa/context-v35-smoke/run-state.sh`, `qa/completion-report-smoke/run.sh`: **passed**.
- JavaScript `node --check` and **15 of 16** current `.cjs` test scripts passed.
- `qa/eliya92-engine-selection/verify.cjs` fails on **pre-existing obsolete assertions**: it requires `eliyaExecutionEngine` selector and `app.js?v=96`, neither of which appears in unmodified ELIYA129 (`app.js?v=122`). This is not a newly introduced UI change. The old test is not silently patched to pass.
- **Full Maven compilation / packaged executable JAR: NOT VERIFIED.** Maven is absent and Maven Central DNS resolution fails here. **Windows/macOS/Linux live runtime with a real model: NOT VERIFIED.**

No credentials, developer keys, external MCP access rules, or new default file-edit permissions were added.
