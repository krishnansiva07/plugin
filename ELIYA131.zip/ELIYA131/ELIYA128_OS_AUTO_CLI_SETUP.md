# ELIYA128 — Automatic OS-specific terminal command setup

ELIYA128 extends ELIYA127. It keeps the rich terminal Analyse/Agent renderer and local workspace bridge, and removes the need to run a separate PowerShell installer for CLI registration.

## What happens when the JAR starts

1. `java -jar eliya.jar` boots the existing Spring Boot application.
2. Once the embedded server is ready, Eliya identifies the **actual executable JAR** (not the terminal's current project path) and determines the OS.
3. It registers a launcher under the **current user's account**. It does not require a PowerShell script or elevated privileges on normally configured systems.
4. Existing logic discovers the project, starts background indexing, and opens `http://127.0.0.1:8090/` using the OS browser integration.
5. Eliya prints the setup result. The browser shows a warning when automatic CLI registration is blocked.
6. After opening a new terminal, users can run `eliya`, `eliya analyse`, `eliya agent`, and `eliya implement` from the desired project directory.

**The JAR startup remains successful even when CLI registration is denied.** Eliya does not attempt to bypass organizational restrictions.

### Windows 10/11

- Writes `%LOCALAPPDATA%\Eliya\bin\eliya.cmd` with a launcher that points to the exact running JAR and Java runtime. The generated `.cmd` preserves the working directory and forwards arguments to `--eliya-cli`.
- Registers this directory in `HKCU\Environment\Path` using Java's `ProcessBuilder` and Microsoft's built-in `reg.exe` utility.
- Preserves pre-existing user PATH entries and the REG_SZ/REG_EXPAND_SZ registry type; does not touch the machine PATH.
- Never invokes `install-eliya-windows.ps1`, PowerShell's execution-policy settings, `setx` (which can truncate PATH), or administrator-only operations.
- Does not overwrite an existing unrelated `eliya.cmd`.
- **Important Windows limitation:** environmental changes are not retroactively injected into running shells or Explorer. Open a new terminal after first installation. Some corporate sessions need sign-out/sign-in for Explorer and IDEs to inherit the new user PATH. If IT blocks registry changes, the automatic setup reports this instead of changing security policy.

### macOS (zsh default)

- Writes an executable `~/.local/bin/eliya` launcher pointing to the running Java and JAR.
- Adds an idempotent PATH snippet to `~/.zshrc` and `~/.zprofile`. If the current shell is bash, it also configures `~/.bashrc` and an **existing** `~/.bash_profile`.
- Does not use `sudo`, Homebrew, external downloads, or overwrite an unrelated `eliya` launcher.

### Linux

- Writes executable `~/.local/bin/eliya` and updates `~/.profile` and `~/.bashrc`; when the active shell is zsh, it also configures zsh profiles.
- Does not use `sudo`, modify `/usr/bin` or `/usr/local/bin`, or change system shell configuration.

On macOS/Linux, a new terminal is also needed to load PATH changes; customized shells not covered above may require their own PATH setup.

## Running Eliya

Build and start using the JAR at its actual path (example uses `target/eliya.jar`):

```bash
java -jar target/eliya.jar
```

The browser opens automatically and the launcher is configured for the detected OS. **Start a new terminal** from the project directory:

```bash
eliya                # maps current project and opens or reuses Eliya
eliya analyse        # interactive read-only analysis
eliya agent          # interactive execution
eliya implement      # continue latest workspace analysis
eliya workspace      # show mapped workspace
eliya change workspace "/path/to/another-project"
```

Enter `/agent`, `/analyse`, or `/implement` inside an interactive terminal session to change workflow modes. CLI model requests still require configured API URL, API key and models in the browser Settings.

### Diagnostics

- Windows (new CMD): `where eliya`
- Windows (new PowerShell): `Get-Command eliya`
- macOS/Linux: `command -v eliya`
- Browser at startup: warns if registration was refused; the running-JAR console prints the result.
- If registration is blocked, users can still run `java -jar /absolute/path/to/eliya.jar --eliya-cli analyse` from a project directory. No policy bypass is attempted.
- To opt out: start with `java -Deliya.cli.auto-install=false -jar eliya.jar` or set environment variable `ELIYA_CLI_AUTO_SETUP=off` before starting the JAR.
- If another unrelated `eliya` command already takes precedence in PATH, verify which executable your shell resolves. Eliya does not remove or overwrite that command.

## Verification scope

Provided automated checks:

```bash
bash qa/eliya128/run-auto-setup-smoke.sh
bash qa/eliya126/run-java-cli-smoke.sh
bash qa/eliya126/run-terminal-smoke.sh
bash qa/eliya127/run-rich-renderer-smoke.sh
node --test src/test/js/*.test.js
```

The Java smoke tests check OS detection, path quoting, idempotence, non-overwrite of unrelated launcher, symlink migration from earlier releases, user-PATH preservation via simulated Windows registry commands, executable-JAR identification, POSIX launcher execution with a project path containing spaces, and CLI bridge authorization. They do **not** prove that Windows registry writes or browser/Agent execution succeed on the user's actual machine. This authoring environment does not have a functioning Maven installation, so full Spring Boot assembly and end-to-end Java 17 packaged-JAR startup are **not verified**.
