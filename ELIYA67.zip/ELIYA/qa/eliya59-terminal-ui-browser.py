"""Eliya59 browser UI acceptance smoke; live model calls replaced by deterministic mocks."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent.parent/'src/main/resources/static'
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=await browser.new_page(viewport={'width':1320,'height':850})
    page.set_default_timeout(8000)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    html=re.sub(r'<script src="[^"]+"></script>','',(root/'index.html').read_text())
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(root/'app.css').read_text())
    await page.evaluate('''() => {
      window.__req=[];window.__sessions=[];window.__detail={};
      window.fetch=async (url,opts={})=>{
        const path=String(url).split('?')[0],method=opts.method||'GET';let data={};
        try {data=JSON.parse(opts.body||'{}')} catch(_){}
        window.__req.push({path,method,data});
        let resp={};
        if(path==='/api/chat/stream')return new Response('event: done\\ndata: {\"content\":\"ok\"}\\n\\n',{status:200,headers:{'Content-Type':'text/event-stream'}});
        if(path==='/api/terminal/workspaces')resp=[{id:'w1',name:'Playwright',localPath:'/tmp/playwright'},{id:'w2',name:'Selenium',localPath:'/tmp/selenium'}];
        else if(path==='/api/terminal/sessions'&&method==='GET')resp=window.__sessions;
        else if(path==='/api/terminal/sessions'&&method==='POST'){
          const id='session-'+(window.__sessions.length+1);
          resp={id,model:data.settings.model,status:'running',projectId:data.projectId,referenceProjectIds:data.referenceProjectIds,referenceProjectNames:data.referenceProjectNames,queueCount:0};
          window.__sessions.unshift({...resp,prompt:data.message});
          window.__detail[id]={...resp,fullPrompt:data.message,turns:[{role:'user',content:data.message}],answer:'',queue:[],events:[],question:{},runId:''};
        }
        else if(path.endsWith('/message')&&method==='POST'){
          const id=path.split('/')[4],obj=window.__detail[id];
          obj.queue.push({id:'q'+obj.queue.length,prompt:data.message,projectId:data.projectId,model:data.settings.model});
          resp={...obj,queueCount:obj.queue.length};window.__sessions.find(s=>s.id===id).queueCount=obj.queue.length;
        }
        else if(path.startsWith('/api/terminal/sessions/') && path.split('/').length===5)resp=window.__detail[path.split('/')[4]]||{};
        else if(path==='/api/conversations'&&method==='POST')resp={id:'context'};
        else if(path==='/api/projects/local'&&method==='POST')resp={id:'w1',localPath:'/tmp/playwright',name:'Playwright'};
        else if(path==='/api/conversations')resp=[];
        return new Response(JSON.stringify(resp),{status:200,headers:{'Content-Type':'application/json'}});
      };
    }''')
    for file in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
      await page.add_script_tag(content=(root/file).read_text())
    assert not errors,errors
    await page.evaluate('''() => {state.config.apiKey='key';state.config.baseUrl='http://localhost';state.config.model='agent-1';state.config.chatModel='chat-1';state.project={id:'w1',name:'Playwright',localPath:'/tmp/playwright'};state.referenceProjects=[{id:'w2',name:'Legacy',path:'/tmp/selenium'}];state.modelCatalog.push({id:'vision-1',type:'vision',context:0});}''')
    await page.click('#launchTerminalBtn')
    await page.wait_for_function("() => document.querySelector('#terminalWorkspaceSelect').options.length===3")
    assert await page.locator('#terminalDock').is_visible()
    assert await page.locator('#terminalClose').is_visible()
    assert await page.locator('#terminalMinimize').is_visible()
    assert await page.locator('#terminalMaximize').is_visible()
    assert await page.locator('#terminalGitPanel').count()==0
    assert await page.locator('#terminalSkillPanel').count()==0
    assert not await page.locator('#terminalDuplicateTab').count()
    assert not await page.locator('#terminalForkTab').count()
    assert await page.locator('#terminalWorkspaceSelect').is_hidden()
    await page.click('#terminalConfigPanel summary')
    await page.wait_for_selector('#terminalReferenceChips [data-terminal-ref="w2"]')
    assert 'Legacy' in await page.locator('#terminalReferenceChips').inner_text()
    await page.locator('#terminalReferenceChips [data-terminal-ref="w2"]').check()
    await page.fill('#terminalModelSelect','agent-custom')
    await page.fill('#terminalTask','Investigate workspace')
    await page.press('#terminalTask','Shift+Enter')
    await page.type('#terminalTask',' and summarize')
    assert '\n' in await page.input_value('#terminalTask')
    await page.press('#terminalTask','Enter')
    await page.wait_for_selector('[data-terminal-tab="session-1"]')
    request=await page.evaluate("window.__req.find(r=>r.path==='/api/terminal/sessions'&&r.method==='POST').data")
    assert request['settings']['model']=='agent-custom',request
    assert request['referenceProjectNames']=={'w2':'Legacy'},request
    assert request['message'].startswith('Investigate workspace\n'),request
    await page.fill('#terminalTask','Run tests next')
    await page.press('#terminalTask','Enter')
    await page.wait_for_selector('[data-terminal-queue-item="q0"]')
    await page.click('#terminalMaximize')
    assert 'maximized' in await page.get_attribute('#terminalDock','class')
    await page.click('#terminalMaximize')
    assert 'maximized' not in await page.get_attribute('#terminalDock','class')
    await page.click('#terminalMinimize')
    assert await page.locator('#terminalDock').is_hidden()
    assert await page.locator('#terminalRestore').is_visible()
    await page.click('#terminalRestore')
    assert await page.locator('#terminalDock').is_visible()
    await page.click('[data-terminal-tab-close="session-1"]')
    assert await page.locator('[data-terminal-tab="session-1"]').count()==0
    assert await page.locator('#terminalReopenTabs').is_visible()
    await page.click('#terminalReopenTabs')
    await page.wait_for_selector('[data-terminal-tab="session-1"]')
    await page.click('#terminalNewTab')
    assert await page.locator('[data-terminal-draft]').is_visible()
    await page.click('#terminalClose')
    assert await page.locator('#terminalDock').is_hidden()
    await page.click('#launchTerminalBtn')
    assert await page.locator('#terminalMinimize').is_visible()
    dark=await page.locator('#terminalDock').evaluate('(e)=>getComputedStyle(e).backgroundColor')
    assert dark=='rgb(12, 15, 20)',dark
    await page.screenshot(path='/mnt/data/ELIYA59_terminal_preview.png')
    await page.click('#terminalClose')
    await page.evaluate("() => {syncSettingsUi();document.getElementById('modalBackdrop').classList.remove('hidden');}")
    assert await page.locator('#chatModelDropdown option').count()>1
    await page.select_option('#chatVisionDropdown','vision-1')
    assert await page.input_value('#chatVisionModelName')=='vision-1'
    await page.fill('#chatModel','my-editable-chat')
    assert await page.input_value('#chatModel')=='my-editable-chat'
    await page.screenshot(path='/mnt/data/ELIYA59_settings_preview.png')
    # Exercise actual Chat request shaping for separate Vision extraction and Chat completion models.
    await page.evaluate('''() => {
      document.getElementById('modalBackdrop').classList.add('hidden');
      state.mode='chat';state.config.chatVisionModel='vision-1';state.config.chatModel='text-only';state.config.model='agent-1';
      state.conversationId='context';state.project=null;
      state.attachments=[{id:'img-1',name:'mock.png',mimeType:'image/png',size:1250}];
      void sendMessage({overrideMessage:'Explain uploaded image'});
    }''')
    await page.wait_for_function("() => window.__req.some(r=>r.path==='/api/chat/stream')")
    chat=await page.evaluate("window.__req.find(r=>r.path==='/api/chat/stream').data")
    assert chat['mode']=='chat' and chat['settings']['chatModel']=='text-only' and chat['settings']['visionModel']=='vision-1',chat
    assert chat['attachmentIds']==['img-1'],chat

    assert not errors,errors
    print('PASS: 25 UI assertions · dark terminal, Enter/Shift+Enter, queued instructions, alias references, editable model, close/reopen tabs, minimize/maximize/restore, no page errors')
    await browser.close()
asyncio.run(main())
