"""ELIYA61 mocked Chromium smoke: terminal Markdown contrast and UI Agent clarification response."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent.parent/'src/main/resources/static'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1100,'height':840})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_default_timeout(12000)
  html=re.sub(r'<script src="[^"]+"></script>','',(root/'index.html').read_text())
  html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
  await page.set_content(html)
  await page.add_style_tag(content=(root/'app.css').read_text())
  await page.evaluate('''() => {
    window.__answers=[];
    window.fetch=async (url,opts={})=>{
      const method=opts.method||'GET';
      if(String(url).includes('/runs/test-run/answer') && method==='POST') {
        window.__answers.push(JSON.parse(opts.body));
        return new Response(JSON.stringify({answered:true}),{status:200,headers:{'Content-Type':'application/json'}});
      }
      return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
    }
  }''')
  for f in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
   await page.add_script_tag(content=(root/f).read_text())
  assert not errors,errors
  # This Markdown format was the screenshot defect: pale empty bars for inline code.
  contrast=await page.evaluate('''() => {
    const terminal=document.getElementById('terminalOutput');
    document.getElementById('terminalDock').classList.remove('hidden');
    terminal.innerHTML='<div class="terminal-message terminal-agent"><div class="terminal-message-text">'+
      MarkdownRenderer.render('Auth attempts: `Bearer` + `Authorization` + `X-API-Key`.')+'</div></div>';
    const code=terminal.querySelector('code.inline-code');
    return {text:code.textContent,color:getComputedStyle(code).color,
            background:getComputedStyle(code).backgroundColor,display:getComputedStyle(code).display,
            width:code.getBoundingClientRect().width};
  }''')
  assert contrast['text']=='Bearer',contrast
  assert contrast['color']=='rgb(228, 247, 255)',contrast
  assert contrast['background']=='rgb(40, 53, 68)',contrast
  assert contrast['width']>20,contrast
  await page.evaluate("document.getElementById('terminalDock').classList.add('hidden')")
  await page.evaluate('''() => {
    const entry={agentRunId:'test-run',mode:'agent',streaming:true,agentSteps:[],agentEventTotal:0,
        agentProgress:{percent:12,status:'running',phase:'needs_input',question:{kind:'clarification',
         id:'question-1',reason:'Which repo should run git status?',choices:['repo-a','repo-b','Cancel']}}};
    state.messages=[entry];
    document.getElementById('messages').innerHTML=agentStepsHtml(entry);
  }''')
  assert await page.locator('[data-agent-question-id="question-1"]').count()==1
  assert await page.locator('[data-agent-question-answer="repo-b"]').count()==1
  await page.locator('.agent-question-card textarea').fill('Use /workspace/repo-b')
  await page.locator('[data-agent-question-answer="repo-b"]').click()
  await page.wait_for_function('() => window.__answers.length === 1')
  answer=await page.evaluate('window.__answers[0]')
  assert answer=={'questionId':'question-1','choice':'repo-b','detail':'Use /workspace/repo-b'},answer
  await browser.close()
  print('PASS: readable Terminal inline code; ordinary Agent clarification UI renders and responds')
asyncio.run(main())
