package com.llmart.llm.service;

/** Extract one complete structured plan from common model response wrappers. */
final class AgentPlanJsonEnvelope {
    private AgentPlanJsonEnvelope() { }

    static String extract(String raw) {
        if (raw == null || raw.isBlank()) return "";
        String candidate = raw.strip();
        if (candidate.startsWith("```")) {
            int firstLine = candidate.indexOf('\n');
            if (firstLine >= 0) candidate = candidate.substring(firstLine + 1).strip();
            int fence = candidate.lastIndexOf("```");
            if (fence >= 0) candidate = candidate.substring(0, fence).strip();
        }
        int objectStart = candidate.indexOf('{');
        int arrayStart = candidate.indexOf('[');
        int start = objectStart < 0 ? arrayStart : arrayStart < 0 ? objectStart : Math.min(objectStart, arrayStart);
        if (start < 0) return candidate;
        char close = candidate.charAt(start) == '[' ? ']' : '}';
        int end = candidate.lastIndexOf(close);
        return end > start ? candidate.substring(start, end + 1) : candidate;
    }
}
