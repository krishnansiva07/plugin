'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const staticRoot = path.join(__dirname, '../../main/resources/static');
const app = fs.readFileSync(path.join(staticRoot,'app.js'),'utf8');
const html = fs.readFileSync(path.join(staticRoot,'index.html'),'utf8');
const controller = fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/controller/TerminalController.java'),'utf8');
const session = fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/service/TerminalSessionService.java'),'utf8');
const javaChat = fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/service/ChatService.java'),'utf8');
const patch = app.slice(app.indexOf('function stripProjectMarkers('), app.indexOf('const ACTIVE_LOCAL_WORKSPACE_KEY'));
const ctx = {};
vm.runInNewContext(patch, ctx);

test('a generated HTML file survives as a structured artifact after hidden marker removal', () => {
  const reply = '<!-- PROJECT_FILE_START:site/index.html -->\n```html\n<!doctype html><html><body>OK</body></html>\n```\n<!-- PROJECT_FILE_END -->';
  assert.equal(ctx.stripProjectMarkers(reply), '');
  const files = ctx.extractProjectFileChanges(reply);
  assert.equal(files.length,1);
  assert.equal(files[0].path,'site/index.html');
  assert.match(files[0].content,/<html><body>OK<\/body><\/html>/);
  assert.match(app,/generated file proposal/);
  assert.match(app,/data-preview-proposed-md/);
});

test('HTML artifact preview is sandboxed and has raw-source fallback', () => {
  assert.match(app,/setAttribute\('sandbox', ext === 'svg' \? '' : 'allow-scripts'\)/);
  assert.match(app,/frame.srcdoc =/);
  assert.match(app,/connect-src 'none'/);
  assert.match(app,/form-action 'none'/);
  assert.match(app,/markdownRawMode \|\| \(!isMarkdown && !isHtml\)/);
  assert.match(html,/Generated artifact preview/);
});

test('Terminal UI has independent dock and per-session input', () => {
  assert.match(html,/id="launchTerminalBtn"/);
  assert.match(html,/id="terminalDock"/);
  assert.match(html,/id="terminalTask"/);
  assert.match(html,/id="terminalTabs"/);
  assert.match(app,/function terminalPayload/);
  assert.match(app,/data-execute-terminal/);
});

test('terminal backend explicitly disables plan approval while using agent mode', () => {
  assert.match(session,/settings.put\("agentPlanApproval", false\)/);
  assert.match(session,/"agent", false, agentSettings/);
  assert.match(javaChat,/chatMode\(\)/);
  assert.match(javaChat,/agentService.run\(/);
  assert.match(controller,/@PostMapping\("\/sessions"\)/);
});

test('Terminal sessions are isolated and do not record model API keys in snapshots', () => {
  assert.match(session,/String conversationId = continuing != null \? continuing.conversationId/);
  assert.match(session,/conversationArchive.create\(\).getId\(\)/);
  assert.match(session,/newFixedThreadPool\(12/);
  assert.match(session,/status="interrupted"/);
  assert.doesNotMatch(session,/result.put\("apiKey"/);
});

test('generated text artifacts retain copy, download and verified preview actions', () => {
  assert.match(app,/data-download-proposed/);
  assert.match(app,/\/api\/agent\/runs\/\$\{encodeURIComponent\(runId\)\}\/artifacts/);
  assert.match(html,/Download file/);
});
