# ELIYA141 — Long-source viewer, contextual endings and Chat liveness

## Scope and provenance

Based on the ELIYA140 source ZIP, including the ELIYA139 viewer fixes. This release addresses the reported Markdown prompt fragments, large HTML views, canned end-of-chat questions, and UI stalls. It is a source patch, **not** a claimed validated Windows JAR release.

## Implemented changes

1. **Draft-first source viewer** (`app.js`, `response-artifacts.js`): During Markdown prompt or HTML generation, one persistent dark viewer provides **Expand**, **Copy current text** and **Save partial draft**. Live text is appended without reparsing huge fenced Markdown blocks. After completion, each generated document shows full source and relevant actions.
2. **Truthful partial downloads**: Interrupted Markdown/HTML is preserved and can be downloaded as `*.partial.md` or `*.partial.html`. Incomplete or invalid output is **not** labelled complete, and prompt implementation remains disabled until readiness checks pass. This fixes the previous paradox where the user could read incomplete content but could not save it.
3. **Long-output rendering**: UI refreshes during prompt/HTML generation keep the dark viewer, avoiding a switch back into fragmented Markdown/code cards. Completed Chat messages now use a cache keyed to their content and display state; this avoids repeated full Markdown/HTML work on unrelated chat refreshes. Agent/live messages intentionally bypass this cache.
4. **Real contextual follow-ups** (`conversation-intelligence.js`): Remove the browser's generic canned questions. Suggest a question only when the actual completed answer contains a concrete recommended action under a recommendations/next-steps heading. No follow-up is injected for a prompt/document generation request. Otherwise leave the response alone.
5. **Java completion cleanup** (`AgentService.java`, `AgentResultPresentation.java`, `AgentCompletionNarrator.java`): Do not append `Do you want to add anything?` or `Would you like me to do that?` automatically. Preserve grounded findings and user-requested deliverables, without inventing an additional generic question.
6. **Chat progress warning**: Ignore SSE network keepalive comments as evidence of model progress. When no token or changed retrieval/model status arrives for 90 seconds, show a non-blocking warning. At 180 seconds, offer **Stop and keep partial output**. Do **not** auto-cancel a slow task, and preserve the backend's durable answer recovery mechanisms.
7. **Prompt readiness false positive**: A prompt saying `do not leave TODO placeholders` is not automatically rejected. Actual placeholder lines still prevent Agent handoff.
8. **Cache-busting**: Refresh `app.js`, `response-artifacts.js`, and `conversation-intelligence.js` version tags in `index.html` to 141.

## Validated here

- `node --check` on updated browser JS: passed.
- `node --test src/test/js/*.test.js`: **124/124 passing**, including 8 new ELIYA141 tests (1,500-line Markdown, four independent prompts, 1,150-line HTML, incomplete drafts, source toolbar controls, grounded follow-up, Java source-contract checks, TODO false positives).
- A static long-viewer smoke fixture is supplied at `qa/eliya141-long-viewer-smoke.html`. The environment could not complete a headless Chromium navigation to this local fixture, so visual behavior is **not** verified.

## Not yet established

- Full `mvn clean package` compilation (Maven/dependencies unavailable here).
- Windows localhost:8090 browser usability with configured models, real output streams and files.
- Root cause of the original intermittent provider/model hangs. The UI now exposes inactivity, but the underlying hang still requires provider finish reason, backend timing trace, and status instrumentation.
- Server-side resumable artifact checkpoints. The current Chat service persists final responses or incomplete drafts on known failures, but does **not** persist an individual artifact on every streaming chunk. For truly robust 2,000+ line generation, follow the separate `ELIYA141_ARTIFACT_WORKSPACE_DESIGN.md` architecture.

## Windows acceptance checklist

1. Back up ELIYA140; extract ELIYA141 into a separate folder. `mvnw.cmd clean package` or Maven's usual verified build command. Start using the project's established launch process (localhost:8090).
2. Force-refresh the browser. Confirm `/app.js?v=141`, `/response-artifacts.js?v=141`, `/conversation-intelligence.js?v=141` are loaded (old cached client assets can mimic unresolved bugs).
3. In Analyse, ask for **one 1,500-line Markdown migration prompt**. Observe one dark viewer throughout generation. Copy and save the partial draft while generating, then download the final `.md`. Compare line count and last line across UI, clipboard and download.
4. Ask for **four different migration prompts**. Confirm four unique dark viewers and that Agent receives *only* the selected prompt. Never use an interrupted draft for Agent handoff.
5. Ask for a 1,100+ line HTML report; verify source view, `.html` download and isolated HTML preview. Force an interrupted generation and check `*.partial.html` download.
6. Ask a normal architecture explanation with no specific follow-up recommendation: confirm there is no canned `Do you want to add anything?` or generic question appended. A response with a concrete `## Recommendations` bullet may offer one relevant follow-up.
7. Simulate a slow Chat response. Confirm a warning after a period of no real progress (not merely SSE keepalive), followed by user-controlled cancellation, and verify any saved partial/durable response survives reopening.
8. Test 5+ large responses in one conversation. Confirm earlier source viewers do not flicker or reparse on every new token.

## Operational caution

Do not assume an unlimited-length answer from a single provider request. Provider limits, context windows and model output budgets still apply. Client-side support for 1,000+ lines does not guarantee the model produced all requested content. Verify completeness before claiming a file is ready or handing it to an Agent.
