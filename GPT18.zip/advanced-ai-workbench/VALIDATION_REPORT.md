# Validation Report

## Scope

Validation focused on the requested Agent behavior: plan-first execution, optional human approval before execution, prompt-driven project-path resolution, 10-attempt recovery, provider/tool compatibility recovery, duplicate-response suppression, direct workspace editing, verification-aware completion, and the Chat/Agent-only UI.

## Implemented behavior

- Every Agent run creates a concise execution plan before model-driven workspace actions.
- Plan approval is enabled by default. The Agent console shows the plan and waits for **Approve plan**; the setting can be disabled without disabling plan-first behavior.
- Approved plans are persisted in durable run state with `pending`, `in_progress`, `completed`, `blocked`, and `skipped` status support.
- A native `todo_update` tool lets the model update individual plan steps without replacing the whole plan.
- Explicit project paths in the prompt are authoritative for Agent mode and can switch the active workspace from an older UI-selected workspace.
- Common path labels are supported, including `Project path:`, `Project path =`, `Project path is`, backticks, normal quotes, and smart quotes.
- Adaptive non-actionable recovery is set to **10 attempts**.
- Retryable provider/transport failures are retried up to **10 times** with cancellable backoff.
- Duplicate non-actionable model responses are not repeatedly appended to context; recovery steering changes strategy.
- Repeated identical tool calls with identical outcomes are warned/suppressed before they can consume the full recovery budget.
- Provider tool-name drift is normalized, including noisy names such as `read/<channel>commentary` and `functions.read/<channel>commentary`.
- Generic `search` / `find` calls are mapped to built-in `grep`.
- Generic search arguments such as `query` are normalized to the required `pattern` argument.
- `apply_patch` accepts both the structured `changes` array and OpenAI-style `*** Begin Patch` text.
- Stale exact-text edits tolerate CRLF/LF differences and return a recovery-oriented message instructing the agent to re-read current text instead of retrying the same stale replacement.
- The core Agent protocol was reduced to outcome-oriented operating principles so the model has more implementation freedom while still respecting filesystem permissions and real verification.

## Validation performed in this environment

### Passed

- `node --check src/main/resources/static/app.js`
- `node --check src/main/resources/static/markdown.js`
- `bash -n run.sh`
- `bash -n validate-local.sh`
- `pom.xml` parsed as valid XML.
- `index.html` parsed successfully and UI audit confirmed only **Chat** and **Agent** modes; Analyze/Open-workspace/starter action menus are absent.
- Full main + test Java source was parsed with the Java compiler using `--release 17`; no Java syntax/language-structure diagnostics were found after excluding missing third-party dependency symbols.
- Targeted Java 17 runtime harness passed for:
  - noisy tool-name normalization
  - `search`/`find` alias mapping
  - `applypatch` alias mapping
  - `update_plan` -> `todo_update`
  - prompt project-path resolution for colon/equal/`is`/backtick/smart-quote forms
  - primary-project preference over a labelled read-only reference project
- Targeted Java 17 runtime harness passed for durable plan lifecycle:
  - plan creation
  - first-step start
  - plan item status updates
  - completion of open plan items
  - persistence/reload of plan state and terminal status
- Added dependency-backed unit tests for:
  - provider compatibility argument repair (`query` -> `pattern`, patch input)
  - noisy tool-name normalization
  - prompt-path label variants
  - plan persistence across reload
  - OpenAI-style patch text application
  - CRLF/LF edit compatibility

## Full Maven test/package attempt

`./mvnw -q test` was attempted after the code changes. This validation container has no Maven installation or local Maven repository, so the wrapper tried to bootstrap Maven 3.9.11. The environment cannot resolve `repo.maven.apache.org`, and the bootstrap stopped with:

```text
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore a dependency-backed Spring/Jackson/JUnit Maven build cannot be truthfully reported as executed here. This is the only validation item blocked by the container environment.

For a complete dependency-backed local check, run:

Windows:

```bat
validate-local.bat
```

Linux/macOS:

```bash
./validate-local.sh
```

Those scripts run frontend syntax checks, the complete Maven test suite, and then package `target/advanced-ai-workbench.jar`.

## Recommended first acceptance test

Use Agent mode with plan approval enabled and a prompt such as:

```text
Project path: C:\AgentTest
Analyze the complete project, fix the requested issue, add any necessary tests, run the relevant verification, repair failures, and finish only after the current workspace revision is verified.
```

Expected flow:

```text
resolve workspace -> create plan -> show plan -> Approve plan -> inspect -> edit/run -> verify/fix loop -> completion -> durable 100% status
```
