# Advanced AI Workbench Agent

Java 17 local coding and workspace agent with two interaction modes: **Chat** and **Agent**.

## Primary flow

Agent mode is designed for direct prompt-driven work:

1. Put an existing project or file path in the prompt.
2. The runtime resolves that explicit path as the primary live workspace, even if a different workspace was previously active.
3. Before any model-driven workspace action, the agent creates a concise execution plan.
4. By default the plan is shown in the Agent console and execution waits for **Approve plan**. This gate can be disabled in Settings while plan-first behavior remains enabled.
5. After approval, the agent follows the plan autonomously, adapting routine implementation details when real tool evidence requires a better route. Additional prompt paths are exposed as named resources with safe read/write roles.
6. The agent inspects targeted files, batches independent reads, edits the live workspace, executes the smallest useful build/test/check, repairs failures, and stops once the requested result is verified.
7. A durable run record drives the progress bar and final completion state, so a stale SSE connection does not leave the UI waiting for a manual Stop click.

If a follow-up Agent prompt has no path, the current live workspace can be reused. If a new explicit path is supplied, that prompt path is authoritative and switches the active workspace.

## Long-running context management

The runtime uses a compact active context rather than resending the full historical transcript on every model call:

- proactive token estimation before each model call
- tool-schema tokens included in the estimate
- automatic compaction before the provider context limit
- structured semantic continuation checkpoint
- deterministic checkpoint fallback if summarization is unavailable
- recent context tail retained after compaction
- bounded fresh tool output and smaller old-tool retention
- provider input/output/cache usage captured when returned
- context-overflow recovery with one forced compaction attempt
- up to 10 adaptive non-actionable recovery attempts before a run is declared blocked
- up to 10 transient provider retries for retryable transport/server failures
- repeated identical no-progress tool/model outcomes suppressed and redirected to a materially different strategy

Defaults are configurable in Settings. The default recent-context target is 8k tokens and the default safety buffer is 20k tokens.

## Speed and quality controls

The Agent protocol emphasizes high-signal work rather than activity for its own sake:

- independent read/search calls are batched in one model turn and executed in parallel when safe
- targeted grep/index/range reads are preferred over broad recursive file dumps
- unchanged files should not be re-read without a reason
- exploratory subagents can use fresh context for independent investigation
- edits are no-op aware, avoiding synthetic revisions when content already matches
- verification is revision-aware and only a real changed revision requires a new verifier
- the smallest verifier that proves the requested change is preferred before broader suites
- successful verification triggers a dedicated completion check instead of open-ended extra investigation
- transient provider retries are bounded and cancellable
- foreground commands use process pipes rather than temporary output files, avoiding Windows log-file sharing locks
- common provider tool-name/schema drift is repaired at the runtime boundary (`search`→`grep`, noisy `read/<channel>...` names, `query`→`pattern`, OpenAI-style patch text) instead of wasting retries
- stale exact-text edits explain that the file changed and direct the model to re-read current text before retrying

## Agent progress

The Agent console shows monotonic phase progress from startup through completion. Typical phases include planning, inspecting, editing, executing, verifying, reviewing, completion check, finalizing, completed, blocked, failed, or cancelled.

The percentage represents task phase progress, not an ETA. The terminal state becomes 100% only when the durable final response is available (or the run is terminally blocked/failed/cancelled).

## UI

The main UI intentionally contains only **Chat** and **Agent** modes. Workspace selection is not a sidebar workflow; supply filesystem paths in Agent prompts.

Settings include model connection, context/compaction controls, plan approval, permissions, MCP/subagent/LSP permissions, and optional additional shell commands.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access for the included Maven bootstrap script on first use

Windows:

```bat
validate-local.bat
run.bat
```

Linux/macOS:

```bash
./validate-local.sh
./run.sh
```

The packaged JAR name is:

```text
target/advanced-ai-workbench.jar
```

## Example Agent prompts

```text
Project path: C:\work\payments-ui
Fix the failing login flow shown in the console error below. Inspect the project, implement the smallest correct fix, run the relevant tests, repair any failures, and stop as soon as the requested change is verified.
```

```text
Primary project: C:\work\new-playwright
Reference project: C:\work\old-selenium
Recorded flow: C:\work\recordings\payment.json
Use the Selenium project and recording as reference only. Implement the equivalent flow in the primary project, run it, fix failures, and verify the final result.
```

See `SAMPLE_PROMPTS.md` for more examples.
