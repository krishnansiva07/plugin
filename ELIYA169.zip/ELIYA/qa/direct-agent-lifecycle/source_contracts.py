from pathlib import Path
r=Path(__file__).resolve().parents[2]
chat=(r/'src/main/java/com/llmart/llm/service/ChatService.java').read_text()
agent=(r/'src/main/java/com/llmart/llm/service/AgentService.java').read_text()
runs=(r/'src/main/java/com/llmart/llm/service/AgentRunService.java').read_text()
checks = {
 'run allocated before context': chat.index('agentRuns.start(')<chat.index('contextService.build('),
 'initial objective persisted': 'agentRun.setObjective(userMessage.getContent())' in chat,
 'explicit resume required': 'AgentDirectSubmissionPolicy.explicitInterruptedResume(' in chat,
 'inferred workspace bound': 'agentRun.bindInferredProject(effectiveProjectId)' in chat,
 'early execution failures saved': 'saveFailedAgentOutcome(agentRun, e, emitter, transportOpen)' in chat,
 'question observed in UI': '"agent_question"' in chat,
 'early failure status persists': 'run.markResponsePersisted(String.valueOf(saved.id()), answer);' in chat,
 'no independent task inheritance': 'return start(conversationId, projectId, false);' in runs,
 'planning provider recovery': 'awaitProviderRepair(run, onStep, 0, "planning", providerFailure)' in agent,
 'executor provider recovery': 'awaitProviderRepair(run, onStep, step, "execution", providerFailure)' in agent,
 'external provider recovery': 'awaitProviderRepair(run, onStep, step, "external analysis", providerFailure)' in agent,
 'external empty response recovery': 'awaitProviderRepair(run, onStep, step, "external analysis", emptyProvider)' in agent,
 'same scope retry only': '"User selected: Retry after fixing provider".equals(answer)' in agent,
 'model fallback existing': 'PROVIDER_MODEL_CYCLES = 3' in agent,
 'explicit permission gates': 'protectedSnapshots.begin(run.id()' in agent,
 'answer not fabricated': 'AgentResultPresentation' in agent,
}
for name, passed in checks.items():
    assert passed, name
print(f'PASS direct path source contracts: {len(checks)} checks')
