package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/** Runs against real AgentRunService and AgentQuestionService with isolated framework stubs. */
public final class DirectAgentSmoke {
    private static int count = 0;
    private static void ok(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        count++;
    }

    public static void main(String[] args) throws Exception {
        ok(AgentDirectSubmissionPolicy.explicitInterruptedResume("Resume the interrupted Agent task"), "explicit interrupted task");
        ok(AgentDirectSubmissionPolicy.explicitInterruptedResume("Please resume my previous migration"), "resume migration");
        ok(AgentDirectSubmissionPolicy.explicitInterruptedResume("Continue the paused run"), "resume paused run");
        for (String message : List.of("", "continue", "fix the timeout and verify", "implement migration now",
                "My plan is to resume old tests", "resume the interrupted task and create a different project",
                "Resume the interrupted task\nImplement a different task", "create prompt for task recovery")) {
            ok(!AgentDirectSubmissionPolicy.explicitInterruptedResume(message), "fresh task must not inherit: " + message);
        }
        String error = AgentDirectSubmissionPolicy.actionableFailure("Fix the UI", "workspace permission denied");
        ok(error.contains("Fix the UI") && error.contains("workspace") && error.contains("access rights"), "workspace error actionable");
        ok(!error.toLowerCase().contains("verified complete"), "no fabricated completion");
        ok(AgentDirectSubmissionPolicy.actionableFailure("Migrate", "Provider timeout").contains("model"), "provider recovery recommendation");
        ok(AgentDirectSubmissionPolicy.actionableFailure("Inspect", "File not found").contains("attachment"), "missing file");
        Path dir = Files.createTempDirectory("eliya-direct-qa-");
        AgentRunService baseline = new AgentRunService(dir);
        AgentRunService.AgentRun original = baseline.start("conv", "workspace-a");
        original.setObjective("Migrate module A");
        original.initializeWorkItems(List.of("Migrate class Foo", "Migrate class Bar"), 2);
        // Restart the service: real loadPersistedRuns marks unfinished work interrupted.
        AgentRunService service = new AgentRunService(dir);
        AgentRunService.AgentRun interrupted = service.require(original.id());
        ok("interrupted".equals(interrupted.status()), "interrupted baseline");
        AgentRunService.AgentRun fresh = service.start("conv", "workspace-a");
        fresh.setObjective("Create a completely different application");
        ok(!fresh.largeTaskMode(), "fresh direct task not contaminated");
        ok(fresh.workItemsSnapshot(20).isEmpty(), "fresh run cannot reuse old work items");
        ok(fresh.originalTaskContract().contains("completely different application"), "fresh scope preserved");
        AgentRunService.AgentRun resumed = service.start("conv", "workspace-a", true);
        resumed.setObjective("Resume the interrupted task");
        ok(resumed.largeTaskMode(), "explicit resume inherits task ledger");
        ok(resumed.workItemsSnapshot(20).size() == 2, "work item count preserved");
        ok(resumed.originalTaskContract().equals("Migrate module A"), "original contract preserved on resume");
        AgentRunService.AgentRun otherWorkspace = service.start("conv", "workspace-b", true);
        ok(!otherWorkspace.largeTaskMode(), "do not cross workspace boundary");
        AgentRunService.AgentRun inferred = service.start("external", null);
        inferred.bindInferredProject("inferred-project");
        ok("inferred-project".equals(inferred.projectId()), "run scope bound after discovery");
        inferred.bindInferredProject("inferred-project");
        ok("inferred-project".equals(service.status(inferred.id()).get("projectId")), "scope in snapshot");
        try { inferred.bindInferredProject("unrelated-project"); throw new AssertionError("workspace was switched"); }
        catch (IllegalStateException expected) { count++; }
        try { inferred.bindInferredProject(" "); throw new AssertionError("empty project accepted"); }
        catch (IllegalArgumentException expected) { count++; }
        AgentRunService restored = new AgentRunService(dir);
        ok("inferred-project".equals(restored.require(inferred.id()).projectId()), "bound scope survives restart");

        AgentQuestionService questions = new AgentQuestionService();
        AgentRunService.AgentRun paused = service.start("question", "workspace-a");
        questions.enable(paused.id());
        AtomicReference<String> response = new AtomicReference<>();
        AtomicReference<Throwable> issue = new AtomicReference<>();
        Thread waiter = new Thread(() -> {
            try { response.set(questions.ask(paused.id(), "Provider unavailable. Retry safely?",
                    List.of("Retry after fixing provider", "Stop and keep current work", "Cancel"), paused)); }
            catch (Throwable e) { issue.set(e); }
        });
        waiter.start();
        for (int i = 0; i < 200 && questions.pending(paused.id()).isEmpty(); i++) Thread.sleep(10);
        ok(!questions.pending(paused.id()).isEmpty(), "question is visible to a poller");
        String qId = String.valueOf(questions.pending(paused.id()).get("id"));
        ok(!questions.answer(paused.id(), qId, "Change scope", ""), "arbitrary choice rejected");
        ok(questions.answer(paused.id(), qId, "Retry after fixing provider", ""), "explicit retry answer accepted");
        waiter.join(3000);
        ok(issue.get() == null && !waiter.isAlive(), "question releases worker");
        ok("User selected: Retry after fixing provider".equals(response.get()), "retry is exact not guessed");
        ok(questions.pending(paused.id()).isEmpty(), "question removed after answer");
        questions.disable(paused.id());

        AgentRunService.AgentRun cancelling = service.start("cancel-question", "workspace-a");
        AtomicReference<Throwable> cancelledIssue = new AtomicReference<>();
        Thread waiting = new Thread(() -> {
            try { questions.ask(cancelling.id(), "Stop now?", List.of("Continue", "Cancel"), cancelling); }
            catch (Throwable e) { cancelledIssue.set(e); }
        });
        waiting.start();
        for (int i = 0; i < 200 && questions.pending(cancelling.id()).isEmpty(); i++) Thread.sleep(10);
        ok(service.cancel(cancelling.id()), "stop accepted during provider question");
        questions.cancel(cancelling.id());
        waiting.join(3000);
        ok(!waiting.isAlive(), "cancelled question exits promptly");
        ok(cancelledIssue.get() instanceof AgentCancelledException, "cancelled is not converted to retry");
        cancelling.finish("cancelled");
        System.out.println("PASS direct Agent lifecycle: " + count + " runtime assertions");
    }
}
