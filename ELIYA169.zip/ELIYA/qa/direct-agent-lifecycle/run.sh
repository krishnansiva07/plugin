#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/org/springframework/stereotype" "$TMP/src/com/llmart/llm/service"
cat > "$TMP/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype;
public @interface Service {}
JAVA
cat > "$TMP/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
public final class OpenAiCompatibleClient {
 public record Usage(long inputTokens,long outputTokens,long totalTokens,long cachedInputTokens,long cacheWriteTokens,boolean providerReported) {}
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" <<'JAVA'
package com.llmart.llm.service;
public class ProtectedRunSnapshotService { public void discard(String id) {} }
JAVA
SRC="$ROOT/src/main/java/com/llmart/llm/service"
javac --release 17 -d "$TMP/classes" \
  "$TMP/src/org/springframework/stereotype/Service.java" \
  "$TMP/src/com/llmart/llm/service/OpenAiCompatibleClient.java" \
  "$TMP/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" \
  "$SRC/AgentDirectSubmissionPolicy.java" "$SRC/AgentCancelledException.java" \
  "$SRC/AgentStageMetrics.java" "$SRC/TokenActivityLedger.java" \
  "$SRC/AgentRunService.java" "$SRC/AgentQuestionService.java" \
  "$ROOT/qa/direct-agent-lifecycle/DirectAgentSmoke.java"
java -ea -cp "$TMP/classes" com.llmart.llm.service.DirectAgentSmoke
python3 "$ROOT/qa/direct-agent-lifecycle/source_contracts.py"
