#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."

# Direct submission and recovery semantics (production classes, limited Spring stubs)
bash qa/direct-agent-lifecycle/run.sh
# Hand-off remains independent: no regression to Analyse->Agent
bash qa/agent-continuation-smoke/run.sh
bash qa/conversational-agent/run.sh
bash qa/eliya120-handoff/run.sh
bash qa/eliya121-handoff-hardening/run.sh
bash qa/agent-recovery-decision/run.sh
# Cancellation, retrieval and general Agent safety invariants
bash qa/stop-lifecycle-smoke.sh
bash qa/answer-first/run.sh
bash qa/agent-reliability/run.sh
bash qa/outcome-review-smoke/run.sh
bash qa/large-artifacts/run.sh
bash qa/prompt-deliverable/run.sh
node --test src/test/js/*.test.js qa/*.test.js

echo 'PASS offline direct Agent acceptance suite (live app/provider still required)'
