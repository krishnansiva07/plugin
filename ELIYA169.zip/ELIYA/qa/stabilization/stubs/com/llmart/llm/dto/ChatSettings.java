package com.llmart.llm.dto;
public record ChatSettings(String baseUrl) {
  public boolean semanticRetrievalEnabled() { return true; }
  public String embeddingModelName() { return "local-embedding-model"; }
}
