package com.llmart.llm.service;
public class ProtectedRunSnapshotService {public void discard(String id) {} }
