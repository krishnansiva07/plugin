package com.llmart.llm.service;
import java.util.*;
import java.util.function.*;
public class OpenAiCompatibleClient {
  public record Usage(long inputTokens,long outputTokens,long totalTokens,long cachedInputTokens,
      long cacheWriteTokens,boolean providerReported) {}
  public List<double[]> embed(String key,String base,String model,List<String> items,BooleanSupplier stopped) {
    List<double[]> vectors=new ArrayList<>();
    for(String item:items) vectors.add(new double[]{1,0,0});
    return vectors;
  }
}
