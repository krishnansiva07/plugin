package org.apache.tika;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class Tika {
  public void setMaxStringLength(int n) {}
  public String parseToString(InputStream in) throws IOException { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }
}
