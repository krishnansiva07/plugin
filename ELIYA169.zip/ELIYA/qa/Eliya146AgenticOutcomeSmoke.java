package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Standalone JDK regression for short-command multi-plan evidence delivery. */
public final class Eliya146AgenticOutcomeSmoke {
    private static void check(boolean value, String detail) {
        if (!value) throw new AssertionError(detail);
    }
    public static void main(String[] ignored) throws Exception {
        Path root = Files.createTempDirectory("eliya146-");
        Files.createDirectories(root.resolve("plans"));
        try {
            Files.writeString(root.resolve("plans/PlanA.md"), "# Plan A\n\nReuse the existing in-memory filter and keep changes minimal.\n" +
                    "## Pros\nNo new dependencies.\n## Cons\nMemory use grows.\n");
            Files.writeString(root.resolve("plans/PlanB.md"), "# Plan B\n\nUse an H2 database and JPA repositories.\n" +
                    "## Pros\nMatches JPA requirements.\n## Cons\nMore code changes.\n");
            Files.writeString(root.resolve("plans/comparison.md"), "# Plan comparison\n\nPlan A retains the original storage; " +
                    "Plan B introduces H2 and JPA.\n## Recommendation\nConsider Plan A when dependencies must remain unchanged.\n");
            String status = "A  plans/PlanA.md\nA  plans/PlanB.md\nA  plans/comparison.md";
            var verification = AgentArtifactVerificationPolicy.inspect(root, status, "launch planner", false, false);
            check(verification.eligible() && verification.passed(),
                    "Short natural-language planner commands must verify real Markdown read-back: " + verification);
            var mixed = AgentArtifactVerificationPolicy.inspect(root, status + "\nA  app/src/Main.java", "launch planner", false, false);
            check(!mixed.eligible(), "Markdown structural verifier must not greenlight code changes");
            check(AgentArtifactResultEvidence.hasPlanningArtifacts(
                    List.of("plans/PlanA.md", "plans/PlanB.md", "plans/comparison.md")),
                    "Actual generated plan documents should trigger richer final analysis");
            check(AgentResultPresentation.needsArtifactAnswer(
                    "## Summary\n\nGenerated PlanA.md and PlanB.md in the workspace, and wrote a comparison.md " +
                    "for the user to review before selecting a plan.", 3, true),
                    "A file list alone does not satisfy the Planner analysis contract");
            var evidence = AgentArtifactResultEvidence.collect(root,
                    List.of("plans/PlanA.md", "plans/PlanB.md", "plans/comparison.md", "../secret.md"));
            check(evidence.contains("ARTIFACT: plans/comparison.md") && evidence.contains("ARTIFACT: plans/PlanA.md") &&
                    evidence.contains("ARTIFACT: plans/PlanB.md"), "All generated plans must be read back");
            check(evidence.indexOf("ARTIFACT: plans/comparison.md") < evidence.indexOf("ARTIFACT: plans/PlanA.md"),
                    "Comparison should be prioritized to minimize context cost");
            check(!evidence.contains("../secret.md"), "No workspace traversal");
            check(AgentResultPresentation.needsArtifactAnswer("The Agent could not independently verify the approved outcome", 3),
                    "Blocked file creation must still explain the generated result");
            check(AgentResultPresentation.needsArtifactAnswer("All approved plan steps completed successfully", 3),
                    "Generic success message must not suppress outcome explanation");
            check(!AgentResultPresentation.needsArtifactAnswer(
                    "## Plan comparison\n\nPlan A retains the current architecture. Plan B requires a new database and " +
                    "additional JPA entities. Both introduce different performance risks, documented in plans/comparison.md.", 3),
                    "Do not pay for a redundant final model response when substantive answer exists");
            System.out.println("PASS: planner artifacts verified, compared, scoped and summarized by policy");
        } finally {
            for (String file : List.of("plans/PlanA.md", "plans/PlanB.md", "plans/comparison.md")) {
                Files.deleteIfExists(root.resolve(file));
            }
            Files.deleteIfExists(root.resolve("plans"));
            Files.deleteIfExists(root);
        }
    }
}
