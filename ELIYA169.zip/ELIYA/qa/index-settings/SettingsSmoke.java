import com.llmart.llm.service.WorkspaceIndexingSettings;
import java.nio.file.*;

public class SettingsSmoke {
    private static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); }
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("eliya-index-settings-smoke-");
        Path settings = root.resolve("settings.properties");
        System.setProperty("app.data-dir", root.toString());
        WorkspaceIndexingSettings configured = new WorkspaceIndexingSettings();
        check(configured.current().maxFiles() == 150000, "default 150k");
        check(configured.current().maxScannedFiles() == 300000, "default 300k");
        WorkspaceIndexingSettings.Limits updated = new WorkspaceIndexingSettings.Limits(
            175000, 400000, 3000000, 64000, 5000, 1024);
        configured.save(updated);
        WorkspaceIndexingSettings reloaded = new WorkspaceIndexingSettings();
        check(reloaded.current().equals(updated), "restart persistence");
        check(Files.isRegularFile(root.resolve("workspace-indexing.properties")), "saved in data dir");
        boolean bad = false;
        try { configured.save(new WorkspaceIndexingSettings.Limits(170000, 150000, 3000000, 64000, 5000, 1024)); }
        catch (IllegalArgumentException expected) { bad = true; }
        check(bad, "reject scan cap below index cap");
        check(configured.current().equals(updated), "invalid save must not alter settings");
        var linesOnly = new WorkspaceIndexingSettings.Limits(175000, 400000, 3000000, 64000, 8000, 4096);
        check(WorkspaceIndexingSettings.indexFingerprint(updated) == WorkspaceIndexingSettings.indexFingerprint(linesOnly),
                "line read changes do not force reindex");
        check(WorkspaceIndexingSettings.indexFingerprint(updated) !=
                WorkspaceIndexingSettings.indexFingerprint(WorkspaceIndexingSettings.DEFAULTS), "index changes force reindex");
        Files.deleteIfExists(root.resolve("workspace-indexing.properties"));
        Files.deleteIfExists(root);
        System.out.println("Workspace indexing settings persistence, bounds, fingerprint PASS");
    }
}
