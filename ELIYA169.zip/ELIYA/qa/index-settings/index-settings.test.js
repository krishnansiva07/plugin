'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const root='src/main/resources/static/';
const html=fs.readFileSync(root+'index.html','utf8');
const app=fs.readFileSync(root+'app.js','utf8');
const idx=fs.readFileSync('src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java','utf8');
const reader=fs.readFileSync('src/main/java/com/llmart/llm/service/AgentWorkspaceService.java','utf8');
const service=fs.readFileSync('src/main/java/com/llmart/llm/service/WorkspaceIndexingSettings.java','utf8');
const controller=fs.readFileSync('src/main/java/com/llmart/llm/controller/WorkspaceIndexingSettingsController.java','utf8');
const jobs=fs.readFileSync('src/main/java/com/llmart/llm/service/LocalProjectIndexService.java','utf8');
test('settings render all six bounded controls and remove verified memory controls',()=>{
  for(const id of ['indexMaxFiles','indexMaxScannedFiles','indexMaxFileBytes','indexMaxSourceChars','indexMaxReadLines','indexMaxFullReadKb','applyIndexingSettings'])
    assert.match(html,new RegExp(`id="${id}"`));
  assert.doesNotMatch(html,/Verified learning memory/i);
  assert.doesNotMatch(html,/id="learningCandidate"/);
});
test('UI loads and persists server settings and responds to errors',()=>{
  assert.match(app,/api\('\/api\/settings\/indexing'\)/);
  assert.match(app,/method:'PUT'/);
  assert.match(app,/persistIndexingSettings\(\)/);
  assert.match(app,/Invalid /);
});
test('backend enforces persisted settings across index read and run APIs',()=>{
  assert.match(service,/Files\.move\(temp, location/);
  assert.match(service,/synchronized Limits save/);
  assert.match(idx,/limits\(\)\.maxScannedFiles\(\)/);
  assert.match(idx,/limits\(\)\.maxFiles\(\)/);
  assert.match(idx,/limits\(\)\.maxSourceChars\(\)/);
  assert.match(reader,/readBoundedLines/);
  assert.match(reader,/readWholeTextBounded/);
  assert.match(reader,/hasMore/);
  assert.match(controller,/jobs\.rebuildTrackedWorkspaces\(\)/);
  assert.match(jobs,/worker\.execute/);
});
