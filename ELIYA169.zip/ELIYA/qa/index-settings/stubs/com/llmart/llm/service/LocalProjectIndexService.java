package com.llmart.llm.service;
public class LocalProjectIndexService {
    public int rescans;
    public void rebuildTrackedWorkspaces() { rescans++; }
}
