package org.springframework.web.bind.annotation;
public @interface PutMapping { }
