import com.llmart.llm.service.WorkspaceIndexingSettings;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.controller.WorkspaceIndexingSettingsController;
import java.nio.file.*;
public class ControllerSmoke {
  public static void main(String[] args) throws Exception {
    Path root=Files.createTempDirectory("eliya-settings-controller-");
    System.setProperty("app.data-dir",root.toString());
    var preferences=new WorkspaceIndexingSettings();
    var jobs=new LocalProjectIndexService();
    var controller=new WorkspaceIndexingSettingsController(preferences,jobs);
    if(controller.get().maxFiles()!=150000)throw new AssertionError("GET default");
    controller.save(new WorkspaceIndexingSettings.Limits(180000,300000,1500000,48000,2500,256));
    if(controller.get().maxFiles()!=180000 || jobs.rescans!=1)throw new AssertionError("PUT must schedule rescan");
    controller.save(new WorkspaceIndexingSettings.Limits(180000,300000,1500000,48000,5000,1024));
    if(jobs.rescans!=1)throw new AssertionError("read-only change must not rescan");
    controller.save(controller.get());
    if(jobs.rescans!=1)throw new AssertionError("unchanged must not rescan");
    Files.deleteIfExists(root.resolve("workspace-indexing.properties"));Files.delete(root);
    System.out.println("Index settings REST controller GET/PUT and conditional rescan PASS");
  }
}
