from pathlib import Path
import os,re,shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[2]/'src/main/resources/static'
markup=(root/'index.html').read_text(encoding='utf-8')
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',lambda m:'<script>'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
shim="""<script>
  window.__limits = {maxFiles:150000,maxScannedFiles:300000,maxFileBytes:1500000,maxSourceChars:48000,maxReadLines:2500,maxFullReadKb:256};
  window.__saves=[];
  window.fetch = async (url,opts={})=>{
    const path=String(url).split('?')[0];
    let result={};
    if(path==='/api/settings/indexing') {
      if((opts.method||'GET')==='PUT') {
        const payload=JSON.parse(opts.body);window.__saves.push(payload);window.__limits=payload;
      }
      result=window.__limits;
    } else if(path==='/api/conversations' || path==='/api/terminal/sessions' || path==='/api/agent/runs/recent' || path==='/api/projects') result=[];
    else if(path==='/api/cli/setup-state')result={readyInNewTerminals:true};
    return new Response(JSON.stringify(result),{status:200,headers:{'Content-Type':'application/json'}});
  };
</script>"""
markup=markup.replace('</head>',shim+'</head>',1)
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1440,'height':900})
    errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.set_content(markup,wait_until='domcontentloaded',timeout=30000)
    page.locator('#topSettingsBtn').click(timeout=10000)
    page.wait_for_function("document.querySelector('#indexMaxFiles').value==='150000'")
    assert page.locator('#indexMaxFiles').is_visible()
    assert page.get_by_text('Verified learning memory').count()==0
    page.locator('#indexMaxFiles').fill('175000')
    page.locator('#indexMaxReadLines').fill('5000')
    page.locator('#applyIndexingSettings').click()
    page.wait_for_function('window.__saves.length===1')
    saved=page.evaluate('window.__saves[0]')
    assert saved['maxFiles']==175000 and saved['maxReadLines']==5000, saved
    assert page.locator('#indexingSettingsStatus').is_visible()
    page.locator('#closeSettings').click()
    page.locator('#topSettingsBtn').click()
    page.wait_for_function("document.querySelector('#indexMaxFiles').value==='175000'")
    assert not errors, errors
    page.locator('#indexMaxFiles').scroll_into_view_if_needed()
    page.screenshot(path='/mnt/data/eliya_work/settings_indexing_preview.png')
    browser.close()
    print('Chromium PASS: settings load, edit, PUT, reopen, verified learning removed')
