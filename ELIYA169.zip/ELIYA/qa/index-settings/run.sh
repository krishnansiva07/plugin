#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -d "$TEMP" \
 qa/eliya145-java-stubs/org/springframework/stereotype/Service.java \
 src/main/java/com/llmart/llm/service/WorkspaceIndexingSettings.java \
 qa/index-settings/SettingsSmoke.java
java -cp "$TEMP" SettingsSmoke
javac --release 17 -cp "$TEMP" -d "$TEMP" \
  qa/index-settings/stubs/org/springframework/web/bind/annotation/*.java \
  qa/index-settings/stubs/com/llmart/llm/service/LocalProjectIndexService.java \
  src/main/java/com/llmart/llm/controller/WorkspaceIndexingSettingsController.java \
  qa/index-settings/ControllerSmoke.java
java -cp "$TEMP" ControllerSmoke
node --test qa/index-settings/index-settings.test.js
