#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -d "$OUT" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentTestOutcomeEvidence.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentResultPresentation.java" \
  "$BASE/qa/Eliya147TestOutcomeSmoke.java"
java -cp "$OUT" com.llmart.llm.service.Eliya147TestOutcomeSmoke
bash "$BASE/qa/eliya146-source-parser-smoke.sh"
