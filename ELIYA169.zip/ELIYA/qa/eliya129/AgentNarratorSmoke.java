package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectPatchRequest;
import java.util.List;
public class AgentNarratorSmoke {
    static int checks = 0;
    static void ok(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var changed = List.of(new ProjectPatchRequest.ProjectPatchFile("src/test/java/CheckoutTest.java", "test", Hashing.ABSENT, "write"),
                new ProjectPatchRequest.ProjectPatchFile("src/main/java/CheckoutPage.java", "code", "old-hash", "write"));
        String report = AgentCompletionNarrator.complete("All approved plan steps completed successfully and the latest workspace revision passed verification.",
                "Add checkout tests and update checkout page", changed, 2, "mvn test: 25 passed", true, "completed");
        ok(report.contains("2 tracked workspace file changes"), "count should use tracked workspace");
        ok(report.contains("Created `src/test/java/CheckoutTest.java`"), "created file absent");
        ok(report.contains("Updated `src/main/java/CheckoutPage.java`"), "updated file absent");
        ok(!report.contains("All approved plan steps completed successfully"), "generic auto status should not be a conversational answer");
        ok(report.contains("25 passed"), "actual verifier detail missing");
        ok(!report.contains("Would you like me to do that?"), "no fabricated follow-up question");
        ok(AgentCompletionNarrator.acceptedNextInstruction("yes", report).isBlank(),
                "yes must not execute without a grounded suggested action");
        String explicit = report + "\n\n**Suggested next step:** run the broader regression suite";
        String accepted = AgentCompletionNarrator.acceptedNextInstruction("yes", explicit);
        ok(accepted.contains("run the broader regression suite"), "yes uses the exact suggestion");
        ok(accepted.contains("same completed task") || accepted.contains("SAME completed task"), "continue same task");
        String refined = AgentCompletionNarrator.acceptedNextInstruction("yes, and exclude smoke tests", explicit);
        ok(refined.contains("User's additional constraint: exclude smoke tests"), "user refinement missing");
        ok(AgentCompletionNarrator.acceptedNextInstruction("no", report).isEmpty(), "no must not start work");
        ok(AgentCompletionNarrator.acceptedNextInstruction("yes", "I created some files. What next?").isEmpty(), "yes without recorded exact action must not execute");
        String withPlan = AgentCompletionNarrator.complete("Done", "Create service", changed, 2, "mvn test", true,
                "completed", List.of(java.util.Map.of("text", "Added API service and data models", "status", "completed"),
                    java.util.Map.of("text", "Future optional improvement", "status", "pending")));
        ok(withPlan.contains("Added API service and data models"), "verified completed steps should explain the work");
        ok(withPlan.contains("- Unfinished plan step: Future optional improvement"), "pending step must be labelled unfinished, never delivered");
        String unverified = AgentCompletionNarrator.complete("Done", "Create service", changed, 2, "", false, "completed");
        ok(unverified.contains("No successful verification"), "do not fabricate verifier success");
        ok(unverified.contains("missing verification") || unverified.contains("No successful verification"),
                "next step should address missing verifier");
        String analysis = "## Detailed analysis\n\nThe endpoint routes requests through auth, then calls the service layer for validation. This is grounded in the file inspection.";
        String noChange = AgentCompletionNarrator.complete(analysis, "Explain flow", List.of(), 0, "", false, "completed");
        ok(noChange.contains("The endpoint routes requests"), "preserve useful analysis");
        ok(!noChange.contains("Suggested next step"), "read-only completion must not invent task continuation");
        String failed = AgentCompletionNarrator.complete("Tests failed", "Create service", changed, 2, "", false, "failed");
        ok(failed.contains("Tests failed") && !failed.contains("## Outcome: completed"),
                "do not overwrite failure with success");
        String sparse = AgentCompletionNarrator.complete("Task completed.", "Create service", List.of(), 0, "", false, "completed");
        ok(sparse.contains("No tracked local workspace changes"), "zero changes must be disclosed");
        System.out.println("ELIYA129 completion narrator: " + checks + " checks passed");
    }
}
