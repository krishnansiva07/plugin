#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
context=(root/'src/main/java/com/llmart/llm/service/ContextService.java').read_text()
agent=(root/'src/main/java/com/llmart/llm/service/AgentService.java').read_text()
segment=context.split('public void includeReferences(',1)[1].split('int lastIndex = context.size()',1)[0]
assert segment.count('int budget = 24_000;') == 1, 'duplicate reference budget in includeReferences'
assert 'private String artifactAnswerFallback(' in agent, 'fallback must be an instance method'
assert 'private static String artifactAnswerFallback(' not in agent, 'static instance-method call regression'
assert 'private String clipHeadTail(' in agent, 'expected clipHeadTail helper not found'
print('PASS: no duplicate ContextService budget; fallback uses instance clipHeadTail')
PY
out="$(mktemp -d)"; trap 'rm -rf "$out"' EXIT
javac --release 17 -d "$out" "$ROOT/qa/eliya149-workspace-intent/JavaParseSmoke.java"
java -cp "$out" JavaParseSmoke \
  "$ROOT/src/main/java/com/llmart/llm/service/ContextService.java" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentService.java"
