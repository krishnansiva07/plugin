import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;

/** External fake executable, intentionally mimics ONLY the contract used by ELIYA, not a real provider. */
public class MockOpenCodeV2 {
    private static void send(com.sun.net.httpserver.HttpExchange x, int status, String body) throws java.io.IOException {
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type","application/json");
        x.sendResponseHeaders(status,data.length);
        try(var out=x.getResponseBody()){out.write(data);}
    }
    public static void main(String[] args) throws Exception {
        int port=-1;
        for(int i=0;i<args.length-1;i++) if("--port".equals(args[i])) port=Integer.parseInt(args[i+1]);
        if(port<0) throw new IllegalArgumentException("Missing --port");
        String json=Files.readString(Path.of(System.getenv("OPENCODE_CONFIG")));
        String key=System.getenv("ELIYA_OPENCODE_MODEL_API_KEY");
        String selectedModel = json.contains("qwen3.8-27b") ? "qwen3.8-27b" :
                json.contains("agent-model-v1") ? "agent-model-v1" : "force-mismatch";
        boolean configured = key!=null && key.equals("top-secret-do-not-log") &&
                !json.contains(key) && json.contains("eliya-ui/"+selectedModel) &&
                json.contains("@opencode/ai/providers/openai-compatible") &&
                json.contains("https://company.example/v1") &&
                json.contains("{env:ELIYA_OPENCODE_MODEL_API_KEY}");
        boolean wrongDefault=json.contains("force-mismatch");
        var selected=new java.util.concurrent.atomic.AtomicBoolean();
        var failed=new java.util.concurrent.atomic.AtomicBoolean();
        var bodyFailure=new java.util.concurrent.atomic.AtomicBoolean();
        var completedTask=new java.util.concurrent.atomic.AtomicBoolean();
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",port),0);
        server.createContext("/api/",x->{
            try {
                String path=x.getRequestURI().getPath();
                String body=new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
                if(path.equals("/api/info")) send(x,200,"{\"data\":{\"version\":\"2.2.2\"}}");
                else if(path.equals("/api/model")) send(x,200,
                        "{\"data\":[{\"id\":\"eliya-ui/" + selectedModel + "\",\"capabilities\":{\"tools\":true}}]}");
                else if(path.equals("/api/model/default")) send(x,200,
                        configured && !wrongDefault ? "{\"data\":{\"providerID\":\"eliya-ui\",\"modelID\":\"" + selectedModel + "\"}}" :
                                "{\"data\":{\"providerID\":\"opencode\",\"modelID\":\"flint-40b-free\"}}");
                else if(path.equals("/api/session") && x.getRequestMethod().equals("POST")) {
                    // Require configured model at creation, not just the later switch.
                    boolean withModel = body.contains("\"id\":\"" + selectedModel + "\"")
                            && body.contains("\"providerID\":\"eliya-ui\"")
                            && !body.contains("\"id\":\"eliya-ui/" + selectedModel + "\"");
                    send(x,withModel ? 200 : 400,withModel
                            ? "{\"data\":{\"id\":\"ses_mock\",\"agent\":\"build\"}}"
                            : "{\"error\":{\"message\":\"Session model is missing\"}}");
                }
                else if(path.equals("/api/session/ses_mock/model")){
                    // Mock MUST enforce the documented OpenCode v2 Model.Ref schema.
                    // Earlier ELIYA102 mock incorrectly accepted {providerID, model}, which
                    // masked the real server's HTTP 400 (missing `model.id`).
                    boolean hasId = body.contains("\"id\":\""+selectedModel+"\"")
                            && !body.contains("\"id\":\"eliya-ui/"+selectedModel+"\"");
                    boolean hasProvider = body.contains("\"providerID\":\"eliya-ui\"");
                    boolean noLegacyKey = !body.contains("\"model\":\""+selectedModel+"\"");
                    boolean valid=configured && !wrongDefault && hasId && hasProvider && noLegacyKey;
                    selected.set(valid);
                    if(valid) {x.sendResponseHeaders(204,-1);x.close();}
                    else send(x,400,"{\"error\":{\"message\":\"Missing key at [\\\"model\\\"][\\\"id\\\"]\"}}");
                } else if(path.equals("/api/session/ses_mock/prompt")) {
                    if(body.contains("MAKE_FOLDER_AND_FILE")) {
                        String sandbox = System.getenv("ELIYA_QA_WORKSPACE");
                        if (sandbox == null) throw new IllegalStateException("QA workspace unavailable");
                        Path directory = Files.createDirectories(Path.of(sandbox, "demo"));
                        Files.writeString(directory.resolve("hello.txt"), "HELLO_ELIYA\n");
                        completedTask.set(true);
                    }
                    if(body.contains("FORCE_PROVIDER_FAILURE")) failed.set(true);
                    if(body.contains("FORCE_GATEWAY_BODY_FAILURE")) bodyFailure.set(true);
                    send(x,selected.get()?200:400, selected.get()?"{\"data\":{\"id\":\"usr_mock\"}}":"{}");
                } else if(path.equals("/api/session/active")) send(x,200,failed.get() || completedTask.get()?"{\"data\":{}}":"{\"data\":{\"ses_mock\":{\"status\":\"busy\"}}}");
                else if(path.equals("/api/session/ses_mock/message")) send(x,200,completedTask.get()?
                       "{\"data\":[{\"info\":{\"id\":\"asst_mock\",\"type\":\"assistant\",\"tokens\":{\"input\":120,\"output\":35,\"reasoning\":5,\"cache\":{\"read\":10,\"write\":0}}},\"parts\":[{\"type\":\"text\",\"text\":\"Created demo/hello.txt successfully\"}]},{\"info\":{\"id\":\"usr_mock\",\"type\":\"user\"}}]}" : "{\"data\":[]}");
                else if(path.equals("/api/session/ses_mock/diff")) send(x,200,completedTask.get()?
                       "{\"data\":[{\"status\":\"added\",\"file\":\"demo/hello.txt\",\"additions\":1,\"deletions\":0}]}" : "{\"data\":[]}");
                else if(path.equals("/api/experimental/session/ses_mock/log")) {
                    String entry = "event: execution.failed\n" +
                            "data: {\"type\":\"execution.failed\",\"properties\":{\"promptID\":\"usr_mock\",\"error\":{\"data\":{\"message\":\"HTTP 401 upstream rejected token top-secret-do-not-log\"}}}}\n\n";
                    String failedBody = "event: execution.failed\n" +
                            "data: {\"type\":\"execution.failed\",\"properties\":{\"promptID\":\"usr_mock\",\"error\":{\"name\":\"ProviderRequestError\",\"data\":{\"statusCode\":400,\"responseBody\":\"Invalid max_completion_tokens private-key-for-test\"}}}}\n\n";
                    send(x,200,bodyFailure.get()?failedBody:failed.get()?entry:"");
                }
                else if(path.equals("/api/session/ses_mock/interrupt")) send(x,200,"{\"data\":{\"interrupted\":true}}");
                else if(path.equals("/api/session/ses_mock")) send(x,200, (failed.get() || bodyFailure.get()) ? "{\"data\":{\"outcome\":\"failed\"}}" : completedTask.get() ?
                        "{\"data\":{\"outcome\":\"succeeded\",\"tokens\":{\"input\":120,\"output\":35,\"reasoning\":5,\"cache\":{\"read\":10,\"write\":0}}}}" : "{\"data\":{\"outcome\":null}}");
                else send(x,404,"{}");
            }catch(Exception e){try{send(x,500,"{}");}catch(Exception ignored){}}
        });
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        System.out.println("ELIYA OpenCode mock server started");
    }
}
