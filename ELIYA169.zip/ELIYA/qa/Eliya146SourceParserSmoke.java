import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class Eliya146SourceParserSmoke {
    public static void main(String[] args) throws Exception {
        var compiler = ToolProvider.getSystemJavaCompiler();
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try (var fm = compiler.getStandardFileManager(diagnostics, null, null)) {
            List<File> sources = new ArrayList<>();
            for (String arg : args) sources.add(new File(arg));
            var files = fm.getJavaFileObjectsFromFiles(sources);
            var task = (JavacTask) compiler.getTask(null, fm, diagnostics, List.of("--release", "17"), null, files);
            int parsed = 0;
            for (var tree : task.parse()) parsed++;
            var errors = diagnostics.getDiagnostics().stream()
                    .filter(d -> d.getKind() == Diagnostic.Kind.ERROR).toList();
            if (!errors.isEmpty()) {
                for (var diagnostic : errors) System.err.println(diagnostic);
                throw new AssertionError("Java syntax error(s): " + errors.size());
            }
            if (parsed != sources.size()) throw new AssertionError("Parsed " + parsed + "/" + sources.size());
            System.out.println("PASS: parsed " + parsed + " changed Java sources (syntax-only)");
        }
    }
}
