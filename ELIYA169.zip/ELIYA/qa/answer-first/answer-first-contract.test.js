'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../../src/main/java/com/llmart/llm/service');
const agent = fs.readFileSync(path.join(root,'AgentService.java'),'utf8');
const narrator = fs.readFileSync(path.join(root,'AgentCompletionNarrator.java'),'utf8');
const policy = fs.readFileSync(path.join(root,'AgentResultPresentation.java'),'utf8');
test('read-only question finalizer uses grounded answer-first policy', () => {
  assert.match(narrator,/if\s*\(AgentResultPresentation\.isAnswerFirstQuery\(objective, totalChanged\)\)/);
  assert.match(narrator,/return AgentResultPresentation\.answerFirst\(prior, status, verification\)/);
  assert.match(policy,/No missing matches, successful tests, or completed/);
});
test('detailed execution receipts are kept out of Agent conversation', () => {
  assert.doesNotMatch(agent,/if\s*\(!universalReceipt\.isBlank\(\).*?finalMessage/);
  assert.doesNotMatch(agent,/if\s*\(!externalReceipt\.isBlank\(\).*?finalMessage/);
  assert.match(agent,/run\.markFinalAnswer\(finalMessage\)/);
});
test('late verification gates do not erase the answer', () => {
  assert.match(agent,/if \(AgentResultPresentation\.isAnswerFirstQuery\(run\.objective\(\), totalWorkspaceChanges\)\)\s*\{\s*finalMessage = AgentResultPresentation\.answerFirst/);
  assert.match(agent,/run\.finish\(completionStatus\)/);
});
