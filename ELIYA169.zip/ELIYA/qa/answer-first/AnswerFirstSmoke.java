package com.llmart.llm.service;

import java.util.List;
import java.util.Map;

/** Regression for answer-first finalization and truthful partial analysis. */
public final class AnswerFirstSmoke {
    static int count;
    static void check(boolean value, String explanation) {
        count++;
        if (!value) throw new AssertionError(explanation);
    }
    public static void main(String[] args) {
        String audit = "Run the verification greps in Migration/prompt-*.md and report missing matches";
        check(AgentResultPresentation.isAnswerFirstQuery(audit, 0), "grep audit should produce a direct answer");
        check(AgentResultPresentation.isAnswerFirstQuery("Why is the API failing?", 0), "why question");
        check(AgentResultPresentation.isAnswerFirstQuery("Analyse workspace architecture", 0), "analysis query");
        check(AgentResultPresentation.isAnswerFirstQuery("Check whether the migration is complete", 0), "verification question");
        check(!AgentResultPresentation.isAnswerFirstQuery("Run integration tests and report failures", 0), "tests are execution, not read-only");
        check(!AgentResultPresentation.isAnswerFirstQuery("Fix the framework then explain", 0), "mutating request must not be silently treated as analysis");
        check(!AgentResultPresentation.isAnswerFirstQuery("Analyse and write report.md", 0), "requested artifact must retain artifact report");
        check(!AgentResultPresentation.isAnswerFirstQuery("Why does the service fail?", 1), "changed files must retain change summary");
        String details = "## Verification findings\n\nMigration/prompt-1.md has the required grep. Migration/prompt-3.md has no matching command. " +
                "The first search was successful; the third has zero matches. No files were edited.";
        String success = AgentCompletionNarrator.complete(details, audit, List.of(), 0, "", false,
                "completed", List.of(Map.of("text","Plan steps complete", "status","completed")));
        check(success.equals(details), "completed answer must be exactly findings, not plan bookkeeping");
        String blocked = AgentCompletionNarrator.complete(details, audit, List.of(), 0, "grep coverage not complete", false,
                "blocked", List.of(Map.of("text","Plan steps complete", "status","completed")));
        check(blocked.startsWith(details), "blocked analysis retains findings first");
        check(blocked.contains("Coverage limitation"), "partial analysis must disclose coverage limits");
        check(!blocked.contains("What was completed"), "plan steps belong in activity not answer");
        check(!blocked.contains("Outcome: blocked"), "do not replace findings with failure heading");
        String shortAnswer = AgentCompletionNarrator.complete("No matches found in `prompt-3.md`.", audit,
                List.of(), 0, "", true, "completed");
        check(shortAnswer.equals("No matches found in `prompt-3.md`."), "short grounded answer is valid");
        String missing = AgentCompletionNarrator.complete("Agent run completed", "Analyse the workspace", List.of(), 0,
                "No source files were inspected", false, "blocked");
        check(missing.contains("Answer not established"), "must not invent analysis from a generic success label");
        check(missing.contains("No source files were inspected"), "show actual missing-evidence reason");
        String failed = AgentCompletionNarrator.complete(details, "Analyse the workspace", List.of(), 0,
                "Read permission denied for the remaining module", false, "failed");
        check(failed.startsWith(details), "actual findings survive tool failure");
        check(failed.contains("Read permission denied"), "unverified portion disclosed");
        String unverified = AgentResultPresentation.answerFirst(details + "\n\n**Coverage limitation:** partial coverage", "blocked", "");
        check(unverified.indexOf("Coverage limitation") == unverified.lastIndexOf("Coverage limitation"), "no duplicate limit warnings");
        String handoff = "Implement the following prompt in the mapped workspace.\n\n" +
                "# Implementation Prompt\n" + "Generate a prompt only as an example, not as a deliverable.\n" +
                "Build the framework and run verification tests.\n".repeat(16);
        String directPasted = "# Migration Implementation Prompt\n\n## Objective\n" +
                "Execute the following migration changes in the workspace.\n" +
                "## Steps\nGenerate a prompt only as a sample in the documentation.\n" +
                "## Acceptance\nRun tests and report exact results.\n".repeat(11);
        check(AgentConversationIntent.isPastedExecutionPrompt(directPasted), "directly pasted executable prompt recognized");
        check(!AgentConversationIntent.isPromptGenerationRequest(directPasted), "pasted Markdown not confused for prompt generation");
        check(AgentImplementationOutcome.isImplementation(directPasted), "raw Markdown implementation prompt recognized");
        check(!AgentConversationIntent.isPromptGenerationRequest(handoff),
                "pasted implementation prompt must not become prompt-generation request");
        check(AgentImplementationOutcome.isImplementation(handoff), "agent task must be classified as implementation");
        check(AgentImplementationOutcome.isPromptEcho(handoff, handoff), "full prompt echo detected");
        check(AgentImplementationOutcome.isPromptEcho(handoff, handoff.substring(0, 310)), "partial prompt echo detected");
        check(!AgentImplementationOutcome.isPromptEcho(handoff,
                "Updated `src/main/java/demo/DriverFactory.java`, validated using Maven and recorded " +
                "five passing assertions in the test report. No other files changed."),
                "real implementation findings should not be treated as echoed instructions");
        String summary = AgentCompletionNarrator.complete(handoff, handoff, List.of(), 2,
                "mvn test completed: 6 passed", true, "completed",
                List.of(Map.of("text","Implement Selenium framework support", "status","completed")));
        check(summary.contains("Implementation result"), "completed Agent task must return consolidated result");
        check(summary.contains("2 tracked workspace file changes"), "consolidation must use actual change count");
        check(summary.contains("mvn test completed: 6 passed"), "summary must include observed verifier evidence");
        check(summary.contains("Remaining work and next steps"), "summary must include next steps");
        check(summary.length() < handoff.length(), "model prompt echo must not be published as result");
        check(!summary.contains("Generate a prompt only as an example"), "copied prompt instructions suppressed");
        String unverifiedWork = AgentCompletionNarrator.complete("Task completed", handoff, List.of(), 0,
                "", false, "completed", List.of());
        check(unverifiedWork.contains("No tracked local workspace changes"), "zero changes cannot claim implementation");
        check(unverifiedWork.contains("No successful verification"), "a completed plan does not prove tests ran");
        String blockedWork = AgentCompletionNarrator.complete("Error: test runner unavailable", handoff,
                List.of(), 1, "mvn not found", false, "blocked",
                List.of(Map.of("text","Run regression suite", "status","blocked")));
        check(blockedWork.contains("Resolve the last recorded blocker"), "blocked task must provide continuation path");
        check(blockedWork.contains("Run regression suite"), "unfinished step must remain visible");
        String realFindings = "Implemented the requested migration wrapper and updated `pom.xml`. " +
                "The recorded test runner passed 22 checks; configuration compatibility remains untested.";
        String findingsSummary = AgentCompletionNarrator.complete(realFindings, handoff, List.of(), 1,
                "22 checks passed", true, "completed", List.of());
        check(findingsSummary.contains(realFindings), "non-echo model findings should be preserved");
        check(!AgentImplementationOutcome.isImplementation("Why does this Java framework fail?"),
                "questions must retain the answer-first behavior");
        check(!AgentImplementationOutcome.isImplementation("Generate 5 implementation prompts for migration"),
                "actual prompt requests must remain prompt requests");
        System.out.println("ELIYA answer-first: " + count + " assertions passed");
    }
}
