'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const app = require('../../src/main/resources/static/response-artifacts.js');
const source = fs.readFileSync(path.join(__dirname,'../../src/main/resources/static/app.js'),'utf8');
const prompt = 'Implement the following prompt in my workspace.\n\n# Implementation Prompt\nGenerate a prompt as an example only.\n' + 'Build Java Selenium migration tools.\n'.repeat(100);
test('pasted Analyse implementation prompt is execution input, not prompt output', () => {
  assert.equal(app.isPromptRequest(prompt), false);
  assert.equal(app.sourceView(prompt, '## Implementation result\n\n2 files changed.').kind, '');
  assert.equal(app.requestedFormat(prompt + '\nGenerate an HTML presentation as an optional example'), '');
});
test('directly pasted executable Markdown prompt is not output generation', () => {
  const raw = '# Migration Implementation Prompt\n\n## Objective\nExecute migration.\n## Steps\nGenerate a prompt as a sample only.\n'.repeat(12);
  assert.equal(app.isPromptRequest(raw), false);
  assert.equal(app.sourceView(raw, '## Implementation result\n1 file created').kind, '');
});
test('an explicit generated prompt remains a source artifact', () => {
  const q='Generate one full implementation prompt for migration';
  assert.equal(app.isPromptRequest(q), true);
  assert.equal(app.sourceView(q,'# Prompt\nExecute the migrations.').kind, 'prompt');
});
test('UI fetches durable final run response and a separate execution report', () => {
  assert.match(source, /applyCompletedChatMessage\(assistant, \{content:runSnapshot\.finalAnswer\}\)/);
  assert.match(source, /fetchAgentCompletionReport\(assistant\)/);
  assert.match(source, /agentCompletionReportHtml\(message\)/);
});
