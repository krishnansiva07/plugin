'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = name => fs.readFileSync(path.resolve(__dirname, '..', 'src/main', name), 'utf8');
const agent = source('java/com/llmart/llm/service/AgentService.java');
const ui = source('resources/static/app.js');
const evidence = source('java/com/llmart/llm/service/AgentCompletionEvidence.java');
const lineCount = source('java/com/llmart/llm/service/AgentPortableInspection.java');
test('grep audit routes through genuine read-only investigation', () => {
  assert.match(agent, /AgentReadOnlySearchPolicy\.isAudit\(run\.objective\(\)\)/);
  assert.match(agent, /AUDIT RECOVERY: No actual grep\/search results/);
  assert.match(agent, /!outcomeEvidence\.hasSearchEvidence\(\)/);
  assert.match(agent, /outcomeEvidence\.hasSuccessfulInvestigationEvidence\(\)/);
});
test('line count falls back only for safe relative workspace paths', () => {
  assert.match(agent, /AgentPortableInspection\.execute\(ws\.root\(\), command\)/);
  assert.match(lineCount, /Files\.isRegularFile\(file, LinkOption\.NOFOLLOW_LINKS\)/);
  assert.match(lineCount, /workspaceChanged=false/);
});
test('blocked UI does not confuse plan bookkeeping with task success', () => {
  assert.match(ui, /summaryBase/);
  assert.match(ui, /outcome not verified/);
  assert.match(ui, /terminalRunStatus/);
});
test('real grep search is required, file reading alone cannot satisfy audit', () => {
  assert.match(evidence, /boolean hasSearchEvidence\(\) \{ return searchEvidenceCount > 0; \}/);
  assert.match(evidence, /"resource_grep"/);
  assert.match(evidence, /observedSearch/);
});
