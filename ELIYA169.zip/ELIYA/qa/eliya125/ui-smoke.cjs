const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync('src/main/resources/static/index.html', 'utf8');
const js = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
for (const id of ['refreshLearning', 'learningCandidate', 'learningSummary', 'learningSources',
             'learningCategory', 'learningApproved', 'approveLearning', 'learningStatus', 'learningLessons'])
  assert.doesNotMatch(html, new RegExp(`id="${id}"`));
assert.doesNotMatch(html, /Verified learning memory/);
assert.doesNotMatch(js, /loadVerifiedLearning\(/);
assert.match(html, /id="indexMaxFiles"/);
assert.match(js, /persistIndexingSettings/);
console.log('Learning settings panel removed; indexing settings controls present');
