#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$BASE/src/main/java"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
mkdir -p "$OUT/src/org/springframework/stereotype" "$OUT/src/com/llmart/llm/service" "$OUT/classes"
cat > "$OUT/src/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype;
public @interface Service {}
EOF
cat > "$OUT/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" <<'EOF'
package com.llmart.llm.service;
public class ProtectedRunSnapshotService { public void discard(String id) {} }
EOF
cat > "$OUT/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'EOF'
package com.llmart.llm.service;
public class OpenAiCompatibleClient {
 public record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens, long cacheWriteTokens, boolean providerReported) {}
}
EOF
cat > "$OUT/src/com/llmart/llm/service/StopLifecycleSmoke.java" <<'EOF'
package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public final class StopLifecycleSmoke {
 static int cases=0;
 static void ok(boolean condition, String message){cases++;if(!condition)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception {
  Path root=Files.createTempDirectory("agent-stop-regression-");
  AgentRunService service=new AgentRunService(root);
  AgentRunService.AgentRun run=service.start("conv","project");
  ok(service.activeExecutionRuns().size()==1,"running listed");
  CountDownLatch started=new CountDownLatch(1);
  CountDownLatch done=new CountDownLatch(1);
  AtomicBoolean interrupted=new AtomicBoolean(false);
  Thread worker=new Thread(()->{
   try{
    run.registerWorker(Thread.currentThread());started.countDown();
    Thread.sleep(120_000);
   }catch(InterruptedException e){interrupted.set(true);}
    finally{run.finish("completed");run.unregisterWorker(Thread.currentThread());done.countDown();}
  },"mock-provider-blocked");
  worker.start();ok(started.await(3,TimeUnit.SECONDS),"started");
  ok(service.cancel(run.id()),"accepted first stop");
  ok(service.cancel(run.id()),"accepted repeated stop");
  ok(done.await(3,TimeUnit.SECONDS),"slow provider interrupted promptly");
  ok(interrupted.get(),"worker interrupt delivered");
  ok("cancelled".equals(run.status()),"late completed did not overwrite cancelled");
  ok(run.finished(),"stop confirmed finished");
  ok(service.activeExecutionRuns().isEmpty(),"stopped not counted active");
  ok("cancelled".equals(service.status(run.id()).get("status")),"durable status available");
  AgentRunService restored=new AgentRunService(root);
  ok("cancelled".equals(restored.status(run.id()).get("status")),"restart preserves cancellation");
  AgentRunService.AgentRun completed=service.start("other","project");
  completed.finish("completed");ok(!service.cancel(completed.id()),"completed not cancellable");
  AgentRunService.AgentRun pending=service.start("pending","project");
  ok(service.cancel(pending.id()),"pre-registration stop accepted");
  ok("cancelling".equals(pending.status()),"stop requested not falsely finished");
  ok(!pending.finished(),"pending not terminal without unwind");
  AtomicBoolean prevented=new AtomicBoolean(false);
  Thread late=new Thread(()->{try{pending.registerWorker(Thread.currentThread());}
    catch(AgentCancelledException e){prevented.set(true);}
    finally{Thread.interrupted();pending.finish("cancelled");pending.unregisterWorker(Thread.currentThread());}});
  late.start();late.join(3000);
  ok(prevented.get(),"late worker cannot ignore stop");
  ok(pending.finished(),"late worker finalized stop");
  AgentRunService.AgentRun progress=service.start("progress","project");
  progress.updateProgress(8,"planning","Discovering workspace");
  service.cancel(progress.id());
  progress.updateProgress(80,"execute","Stale progress update");
  ok("cancelling".equals(progress.progressPhase()),"stale callbacks do not erase stop");
  progress.finish("failed");
  ok("cancelled".equals(progress.status()),"failed after interrupt remains cancelled");
  AgentRunService.AgentRun processRun=service.start("process","project");
  Process proc=new ProcessBuilder("sh","-c","sleep 30").start();
  processRun.registerProcess(proc);
  ok(service.cancel(processRun.id()),"process stop accepted");
  ok(proc.waitFor(3,TimeUnit.SECONDS),"process terminated");
  processRun.finish("cancelled");
  System.out.println("PASS: "+cases+" live Java backend assertions");
 }
}
EOF
javac --release 17 -d "$OUT/classes" \
 "$OUT/src/org/springframework/stereotype/Service.java" \
 "$OUT/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" \
 "$OUT/src/com/llmart/llm/service/OpenAiCompatibleClient.java" \
 "$SRC/com/llmart/llm/service/AgentCancelledException.java" \
 "$SRC/com/llmart/llm/service/AgentStageMetrics.java" \
 "$SRC/com/llmart/llm/service/TokenActivityLedger.java" \
 "$SRC/com/llmart/llm/service/AgentRunService.java" \
 "$OUT/src/com/llmart/llm/service/StopLifecycleSmoke.java"
java -ea -cp "$OUT/classes" com.llmart.llm.service.StopLifecycleSmoke
