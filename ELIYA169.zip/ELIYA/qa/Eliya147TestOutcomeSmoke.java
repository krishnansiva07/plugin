package com.llmart.llm.service;

import java.util.Map;

/** Exercises the core risk: fabricated PASSES, missing runner commands and misleading final responses. */
public final class Eliya147TestOutcomeSmoke {
    static void yes(boolean value, String reason) {
        if (!value) throw new AssertionError(reason);
    }
    static Map<String,Object> event(String tool, String args, String output, String state) {
        return Map.of("tool", tool, "args", args, "output", output, "status", state);
    }
    public static void main(String[] args) {
        var run = new AgentTestOutcomeEvidence("run integration tests for TestCaseFilterService");
        yes(run.requested() && run.missingExecutionEvidence(), "Should block a run request with no runner");
        run.observe(event("read", "{\"path\":\"README.md\"}", "8 passed", "success"));
        yes(run.missingExecutionEvidence(), "Source reads cannot count as executed tests");
        run.observe(event("bash", "{\"command\":\"npm test\"}", "exitCode=0; 8 passed, 2 skipped\nAC-202", "success"));
        yes(!run.missingExecutionEvidence(), "Real runner with parseable counts must be captured");
        String report = run.report();
        yes(report.contains("8 passed") && report.contains("2 skipped") && report.contains("AC-202"), "Capture test counts and observed IDs");
        yes(report.contains("not a proven traceability map"), "IDs in logs are not proven assertion mapping");

        var zero = new AgentTestOutcomeEvidence("Run integration test");
        zero.observe(event("bash", "{\"command\":\"npx playwright test\"}", "exitCode=0; No tests found", "success"));
        yes(zero.missingExecutionEvidence() && zero.report().contains("NO_TESTS"), "A green command with zero tests cannot pass");
        var shellNoSummary = new AgentTestOutcomeEvidence("Run integration tests");
        shellNoSummary.observe(event("bash", "{\"command\":\"./mvnw verify\"}", "exitCode=0; BUILD SUCCESS", "success"));
        yes(shellNoSummary.missingExecutionEvidence() && shellNoSummary.report().contains("UNVERIFIED"),
                "Maven BUILD SUCCESS without tests is not passing integration tests");

        var failed = new AgentTestOutcomeEvidence("Execute integration tests");
        failed.observe(event("test", "{}", "exitCode=1; Tests run: 5, Failures: 2, Errors: 0, Skipped: 1", "error"));
        yes(failed.hasFailedTests() && failed.report().contains("2 failed"), "Record failing test runner explicitly");

        // A successful rerun of the SAME command clears an earlier failure verdict,
        // but preserves history in the final evidence table.
        var rerun = new AgentTestOutcomeEvidence("Run integration tests");
        rerun.observe(event("bash", "{\"command\":\"mvn test\"}",
                "exitCode=1; Tests run: 3, Failures: 1, Errors: 0, Skipped: 0\nAssertionError: expected true", "error"));
        yes(rerun.hasFailedTests() && rerun.report().contains("AssertionError"),
                "Failed assertions should be shown with bounded runner output");
        rerun.observe(event("bash", "{\"command\":\"mvn test\"}",
                "exitCode=0; Tests run: 3, Failures: 0, Errors: 0, Skipped: 0", "success"));
        yes(!rerun.hasFailedTests() && rerun.report().contains("Earlier attempts"),
                "Passing rerun should supersede its earlier failure without hiding it");
        yes(rerun.report().contains("3 passed, 0 failed, 0 skipped"),
                "Rerun totals must not double count the first run");

        var jest = new AgentTestOutcomeEvidence("Run unit tests");
        jest.observe(event("bash", "{\"command\":\"npm run test\"}",
                "exitCode=0; Tests: 1 skipped, 5 passed, 6 total", "success"));
        yes(jest.report().contains("5 passed, 0 failed, 1 skipped"), "Capture Jest-style summary");

        var noRunner = new AgentTestOutcomeEvidence("Analyse the integration-test report");
        yes(!noRunner.requested() && !noRunner.missingExecutionEvidence(),
                "A read-only analysis request must not be blocked for failing to launch a runner");

        yes(AgentResultPresentation.needsTestAnswer("Run integration tests", "Done"),
                "Short final answer should require test analysis");
        yes(!AgentResultPresentation.needsTestAnswer("Run integration tests", "## Integration test result\n" +
                "Tests passed using the runner command, with evidence from actual runner output. " +
                "One manual browser check remains and the next activity is to inspect UI evidence."),
                "Real result should not trigger duplicate model synthesis");
        System.out.println("PASS: 147 test runner evidence, zero-test/false PASS guard, failed tests, summarization and synthesis policy");
    }
}
