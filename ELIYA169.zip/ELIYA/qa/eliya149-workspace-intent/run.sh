#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
out="$(mktemp -d)"; trap 'rm -rf "$out"' EXIT
javac --release 17 -d "$out" \
  src/main/java/com/llmart/llm/service/WorkspaceIntentPolicy.java \
  qa/eliya149-workspace-intent/WorkspaceIntentSmoke.java
java -cp "$out" com.llmart.llm.service.WorkspaceIntentSmoke
javac --release 17 -d "$out" qa/eliya149-workspace-intent/JavaParseSmoke.java
java -cp "$out" JavaParseSmoke \
  src/main/java/com/llmart/llm/service/ContextService.java \
  src/main/java/com/llmart/llm/service/ChatService.java \
  src/main/java/com/llmart/llm/service/AgentWorkspaceService.java \
  src/main/java/com/llmart/llm/service/WorkspaceIntentPolicy.java
node --check src/main/resources/static/app.js
