package com.llmart.llm.service;

import java.util.Map;
import java.util.Set;

public class WorkspaceIntentSmoke {
    private static int checks;
    private static void check(boolean value, String detail) {
        checks++;
        if (!value) throw new AssertionError(detail);
    }
    public static void main(String[] args) {
        for (String query : new String[] {
                "Analyse", "review it", "Please inspect the design", "Analyse the architecture", 
                "Review the framework", "Analyse the solution", "Check the existing implementation", "Analyse migration gaps",
                "Trace the execution flow", "Assess our tests", "Review the integration"
        }) check(WorkspaceIntentPolicy.implicitProjectInvestigation(query), "mapped workspace skipped: " + query);
        for (String query : new String[] {
                "Hello", "Thanks!", "What is Java?", "Tell me a children's story", "What is the weather today?",
                "What does architecture mean?", "How do I cook pasta?"
        }) check(!WorkspaceIntentPolicy.implicitProjectInvestigation(query), "false workspace retrieval: " + query);
        Map<String,String> refs = Map.of("ref1","LegacySelenium", "ref2","API_Base", "ref3","Other-API");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("Review LegacySelenium", refs).equals(Set.of("ref1")), "alias mention");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("Review legacyselenium", refs).equals(Set.of("ref1")), "case insensitive alias");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("compare @API_Base and Other-API", refs).equals(Set.of("ref2","ref3")), "multiple alias");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("API_Base2", refs).isEmpty(), "prefix false positive");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("NotLegacySelenium", refs).isEmpty(), "substring false positive");
        check(WorkspaceIntentPolicy.mentionedReferenceIds("Compare workspace and reference LegacySelenium", refs).equals(Set.of("ref1")), "targeted compare");
        check(!WorkspaceIntentPolicy.includePrimaryForQuery("Review LegacySelenium", refs), "reference-only query");
        check(!WorkspaceIntentPolicy.includePrimaryForQuery("Compare API_Base and Other-API", refs), "two-reference query");
        check(WorkspaceIntentPolicy.includePrimaryForQuery("Compare current workspace with LegacySelenium", refs), "cross-project compare");
        check(WorkspaceIntentPolicy.includePrimaryForQuery("Migrate from LegacySelenium", refs), "migration target");
        check(WorkspaceIntentPolicy.includePrimaryForQuery("Review the architecture", refs), "default primary");
        check(!WorkspaceIntentPolicy.includePrimaryForQuery("Analyse Main", Map.of("special", "Main")), "alias Main not primary");
        check(WorkspaceIntentPolicy.includePrimaryForQuery("Compare Main with our project", Map.of("special", "Main")), "alias Main and primary");
        check(WorkspaceIntentPolicy.requestsAllReferences("Compare all references"), "all refs request");
        check(!WorkspaceIntentPolicy.requestsAllReferences("Review main project"), "spurious all refs");
        check(WorkspaceIntentPolicy.sourceRetrievalQuery("Analyse LegacySelenium", "LegacySelenium").contains("architecture"), "alias-only retrieval boost");
        System.out.println("ELIYA149 workspace/alias intent: " + checks + " checks passed");
    }
}
