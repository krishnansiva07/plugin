package com.llmart.llm.dto;
// Standalone harness dependency only; the project build uses the real class.
public class ProjectPatchRequest {
  public record ProjectPatchFile(String path, String operation, String baselineHash) {}
}
