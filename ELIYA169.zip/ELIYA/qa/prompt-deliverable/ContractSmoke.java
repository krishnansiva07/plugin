package com.llmart.llm.service;

import java.util.List;
import java.util.Map;

public class ContractSmoke {
    private static int count=0;
    static void eq(Object expected, Object actual, String name) {
        count++;
        if (!expected.equals(actual)) throw new AssertionError(name+": expected="+expected+" actual="+actual);
    }
    static void yes(boolean value, String name) { eq(true, value, name); }
    static void no(boolean value, String name) { eq(false, value, name); }
    public static void main(String[] args) {
        String five="Analyze the attached requirements and generate 5 different prompts.";
        eq(AgentConversationIntent.Kind.DIRECT, AgentConversationIntent.classify(five), "prompts do not preview");
        yes(AgentConversationIntent.isPromptGenerationRequest(five), "prompt output detected");
        eq(5, AgentConversationIntent.requestedPromptCount(five), "five different prompts");
        eq(5, AgentConversationIntent.requestedPromptCount("Generate FIVE distinct standalone prompts"), "case insensitive");
        eq(5, AgentConversationIntent.requestedPromptCount("Create five separate, standalone prompts"), "comma-separated attributes");
        eq(4, AgentConversationIntent.requestedPromptCount("Create prompt 1, prompt 2, prompt 3 and prompt 4"), "numbered prompts");
        eq(1, AgentConversationIntent.requestedPromptCount("Prepare one complete prompt"), "single prompt");
        eq(0, AgentConversationIntent.requestedPromptCount("Generate some prompts from the attached requirements"), "unspecified plural prompt count is dynamic");
        eq(0, AgentConversationIntent.requestedPromptCount("Generate some one-time prompts and one reusable prompt"), "mixed dynamic one-time and reusable");
        eq(4, AgentConversationIntent.requestedPromptCount("Generate 3 one-time prompts and one reusable prompt"), "explicit three plus one reusable");
        yes(AgentConversationIntent.mixedOneTimeReusablePrompts("Generate some one-time prompts and one reusable prompt"), "mixed type recognized");
        eq(AgentConversationIntent.Kind.PLAN_PREVIEW, AgentConversationIntent.classify("Create an implementation plan for this work"), "genuine plan preview");
        no(AgentConversationIntent.isPromptGenerationRequest("Generate test code based on this prompt"), "existing prompt is source");
        no(AgentConversationIntent.isPromptGenerationRequest("Implement ONLY the selected prompt"), "execute prompt not generate another");
        yes(AgentConversationIntent.isFastReadOnly(five), "chat prompts never edit");
        String toFile="Analyse the attachment and generate 5 separate prompts in the workspace";
        yes(AgentConversationIntent.promptFilesRequested(toFile), "workspace prompt files requested");
        no(AgentConversationIntent.isFastReadOnly(toFile), "written prompts need protected execution");
        yes(AgentCompletionContract.requiresLocalEvidence(toFile), "written prompts need readback proof");
        no(AgentCompletionContract.requiresLocalEvidence(five), "text prompts must not require file edits");
        no(AgentAnalysisOutcome.isAnalysis(toFile), "prompt files must not masquerade as analysis report");
        yes(AgentAnalysisOutcome.isAnalysis("Analyse the test framework architecture"), "normal analysis still detected");
        List<Map<String,Object>> ctx=List.of(Map.of("role","user","content",five));
        eq(5,ChatAnswerContinuation.promptCount(ctx),"chat model contract count");
        yes(String.valueOf(ChatAnswerContinuation.withPromptContract(ctx).get(0).get("content")).contains("exactly 5"),"strong multi-prompt instruction");
        String marker=ChatAnswerContinuation.PROMPT_DONE;
        no(ChatAnswerContinuation.hasPromptCompletion("## Prompt 1\nfirst\n"+marker,5),"premature marker rejected");
        no(ChatAnswerContinuation.hasPromptCompletion("## Prompt 1\nfirst\n"+marker,0),"dynamic plurality requires at least two prompts");
        StringBuilder fiveBodies=new StringBuilder();
        for (int i=1;i<=5;i++) fiveBodies.append("## Prompt ").append(i).append(" — title\nObjective: stage ").append(i).append("\nVerify acceptance and all acceptance criteria with real evidence. ".repeat(5)).append("\n");
        yes(ChatAnswerContinuation.hasPromptCompletion(fiveBodies+marker,5),"five sections accepted");
        no(ChatAnswerContinuation.hasPromptCompletion("## Prompt 1\n## Prompt 2\n## Prompt 4\n## Prompt 5\n## Prompt 5\n"+marker,5),"duplicate or skipped prompt rejected");
        yes(AgentPromptDeliveryGate.validateAnswer(fiveBodies.toString(),5).ready(),"five complete headings validated");
        yes(AgentPromptDeliveryGate.validateAnswer(fiveBodies.toString(),0).ready(),"dynamic count validates independent prompts");
        no(AgentPromptDeliveryGate.validateAnswer("## Prompt 1\n"+"Verify acceptance. ".repeat(25),0).ready(),"dynamic plurality rejects single result");
        no(AgentPromptDeliveryGate.validateAnswer(fiveBodies.toString(),4).ready(),"cannot mislabel count");
        no(AgentPromptDeliveryGate.validateAnswer("## Prompt 1\nonly outline",5).ready(),"outline rejected");
        no(AgentPromptDeliveryGate.validateAnswer("## Prompt 1\n"+"Do a thing ".repeat(30),1).ready(),"no acceptance criteria");
        try {
            java.nio.file.Path workspace=java.nio.file.Files.createTempDirectory("eliya-prompt-contract-");
            java.util.List<com.llmart.llm.dto.ProjectPatchRequest.ProjectPatchFile> changes = new java.util.ArrayList<>();
            for (int i=1;i<=5;i++) {
                String name="prompt-"+i+".md";
                java.nio.file.Files.writeString(workspace.resolve(name),"## Prompt "+i+"\nObjective: stage "+i+" for independent migration. "+
                        ("Inspect the requested source and test the expected result with verification evidence. ").repeat(5));
                changes.add(new com.llmart.llm.dto.ProjectPatchRequest.ProjectPatchFile(name,"write","not-absent"));
            }
            yes(AgentPromptDeliveryGate.validate(toFile,"",workspace,changes).ready(),"five files verified from disk");
            changes.remove(4);
            no(AgentPromptDeliveryGate.validate(toFile,"",workspace,changes).ready(),"missing fifth file caught");
            for (java.nio.file.Path file : java.nio.file.Files.list(workspace).toList()) java.nio.file.Files.delete(file);
            java.nio.file.Files.delete(workspace);
        } catch (Exception problem) { throw new AssertionError(problem); }
        System.out.println("PASS "+count+" Java deliverable-contract checks");
    }
}
