package com.llmart.llm.service;
// Standalone harness dependency only; the project build uses the real class.
final class AgentPlanRelevance { static boolean isReadOnlyAnalysisRequest(String s) { return s != null && s.toLowerCase().contains("analyse"); } }
