'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../../src/main/resources/static');
const artifacts=require(path.join(root,'response-artifacts.js'));
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const body=n=>`Objective: stage ${n} differs from every other stage. Use selected legacy read-only reference and writable target workspace. `+
  `Inspect current project first, make only the changes for stage ${n}, verify output files, test criteria, and concrete acceptance evidence. `.repeat(5);
const sample=count=>Array.from({length:count},(_,i)=>`## Prompt ${i+1} — Stage ${i+1}\n${body(i+1)}`).join('\n\n');

test('five DIFFERENT prompts are recognized even with case and adjectives',()=>{
  for(const q of ['Generate 5 different prompts','Generate FIVE DISTINCT prompts',
    'Analyse attached files then create five separate, standalone prompts',
    'Prepare 5 complete markdown prompts for migration']) {
      assert.equal(artifacts.isPromptRequest(q),true,q);
      assert.equal(artifacts.expectedPromptCount(q),5,q);
    }
});
test('five prompts are split into five independent cards and downloads',()=>{
  const q='Analyse workspace and attached files; generate 5 different prompts';
  const parts=artifacts.promptSections(q,sample(5));
  assert.equal(parts.length,5);
  assert.ok(parts.every(part=>part.ready),parts.map(part=>part.reason).join('; '));
  assert.equal(new Set(parts.map((part,index)=>artifacts.promptFileName(part,index))).size,5);
  for(let i=0;i<5;i++)for(let j=0;j<5;j++)if(i!==j)assert.doesNotMatch(parts[i].content,new RegExp(`Objective: stage ${j+1} `));
});
test('combined answer cannot be handed off as five prompts',()=>{
  const q='Generate 5 different prompts';
  const combined=artifacts.promptSections(q,`## Prompt 1 — All stages\n${body(1)}${body(2)}`);
  assert.equal(combined.length,1);
  assert.equal(combined[0].ready,false);
  assert.match(combined[0].reason,/Expected 5/);
});
test('premature completion markers do not pollute separate prompt Markdown',()=>{
  const q='Generate 5 different prompts';
  const answer=sample(5).replace('## Prompt 4', '<!-- ELIYA_PROMPT_COMPLETE -->\n## Prompt 4')+'\n<!-- ELIYA_PROMPT_COMPLETE -->';
  const parts=artifacts.promptSections(q,answer);
  assert.equal(parts.length,5);
  assert.ok(parts.every(part=>!part.content.includes('ELIYA_PROMPT_COMPLETE')));
});
test('incomplete UI actions retry original scope, not recursively generate a meta-prompt',()=>{
  assert.match(app,/Retry original prompt request/);
  assert.doesNotMatch(app,/data-prompt-complete|data-recover-prompt/);
  assert.match(app,/Retry original file request/);
  assert.doesNotMatch(app,/>Generate complete (?:prompt|file)</);
  assert.match(app,/ORIGINAL REQUEST:/);
  assert.match(app,/expectedPromptCount\(prior\)/);
});

test('unspecified plural and mixed one-time/reusable prompts are not hardcoded to one',()=>{
  const mixed='Generate some one-time prompts and one reusable prompt';
  assert.equal(artifacts.singlePromptRequested(mixed),false);
  assert.equal(artifacts.expectedPromptCount(mixed),0);
  const parts=artifacts.promptSections(mixed,sample(4));
  assert.equal(parts.length,4);
  assert.ok(parts.every(p=>p.ready));
  assert.equal(artifacts.expectedPromptCount('Generate 3 one-time prompts and one reusable prompt'),4);
  assert.equal(artifacts.expectedPromptCount('Generate 5 different prompts'),5);
  assert.equal(artifacts.expectedPromptCount('Generate some prompts'),0);
});

test('completed Agent artifacts can be downloaded independently of preview limitations',()=>{
  assert.match(app,/data-download-agent-artifact/);
  assert.match(app,/artifacts\/\$\{fileIndex\}\/download/);
});
