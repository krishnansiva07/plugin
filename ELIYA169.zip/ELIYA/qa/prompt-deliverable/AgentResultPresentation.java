package com.llmart.llm.service;
// Standalone harness dependency only; the project build uses the real class.
final class AgentResultPresentation {
 static boolean isVerificationRequest(String s) { return s.toLowerCase().contains("verify"); }
 static boolean isDeepAnalysis(String s) { return s.toLowerCase().contains("architecture"); }
 static boolean hasSubstantiveAnswer(String s) { return s != null && s.length() > 100; }
}
