package com.llmart.llm.service;

import java.util.HashMap;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Functional acceptance scenarios for new and previously supported Agent workflows.
 * Uses completed events, not fictional model prose or plan activity.
 */
public final class Eliya148UniversalOutcomeSmoke {
    private static void check(boolean result, String reason) {
        if (!result) throw new AssertionError(reason);
    }
    private static Map<String,Object> event(String name, String state, String args, String output) {
        Map<String,Object> event = new HashMap<>();
        event.put("tool", name);
        event.put("status", state);
        if (args != null) event.put("args", args);
        if (output != null) event.put("output", output);
        return event;
    }
    public static void main(String[] args) throws Exception {
        var empty = new AgentUniversalOutcomeEvidence();
        empty.observe(event("finish", "success", null, null));
        empty.observe(event("plan_step_complete", "success", null, null));
        empty.observe(event("model_retry", "error", null, "transient model error"));
        empty.observe(event("read", "running", "{\"path\":\"src/A.java\"}", "file content"));
        check(!empty.observed(), "UI status, model and in-progress steps are not independent tool evidence");
        check(empty.report("completed", 0, false, "").isBlank(), "No fabricated receipt for an empty run");

        var planner = new AgentUniversalOutcomeEvidence();
        planner.observe(event("read", "success", "{\"path\":\"spec.md\"}", "requirement text"));
        planner.observe(event("write", "success", "{\"path\":\"plans/planA.md\"}", "saved"));
        planner.observe(event("write", "success", "{\"path\":\"plans/comparison.md\"}", "saved"));
        check(planner.hasReadEvidence() && planner.hasWriteEvidence(), "Planner evidence is recorded generically");
        String planReport = planner.report("completed", 2, false, "Markdown read-back only");
        check(planReport.contains("planA.md") && planReport.contains("comparison.md"), "Generated artifact paths visible");
        check(planReport.contains("no passing current-revision verifier"), "Writes cannot masquerade as functional verification");
        check(AgentResultPresentation.needsUniversalOutcome("Done", 2, 3), "Thin planner result requires analysis");
        check(!AgentResultPresentation.needsUniversalOutcome(
                "## Planner results\nCreated and compared the plan files. Evidence: read-back paths were verified; " +
                "the plans still require human selection and are unverified for execution.", 2, 3),
                "Substantive analysis should avoid expensive redundant synthesis");

        var development = new AgentUniversalOutcomeEvidence();
        development.observe(event("edit", "success", "{\"path\":\"src/UserService.java\"}", "patched"));
        development.observe(event("test", "error", "{}", "exitCode=1; 2 failed"));
        check(development.hasUnresolvedToolFailures(), "Failed tests must not disappear");
        check(development.report("failed", 1, false, "Unit test failed").contains("Observed failure"),
                "Failure visible in final report");
        development.observe(event("test", "success", "{}", "exitCode=0; 2 passed"));
        check(!development.hasUnresolvedToolFailures(), "A rerun of the same tool+target can resolve a failure");
        check(development.report("completed", 1, true, "Tests: 2 passed").contains("current workspace revision"),
                "Verified current revision called out accurately");

        // Status gate: a different successful suite must not conceal failing or
        // unexecuted suites. Successful rerun of an identical command may clear it.
        var tests = new AgentTestOutcomeEvidence("Run integration tests");
        tests.observe(event("bash", "success", "{\"command\":\"npm test\"}",
                "exitCode=0; 3 passed"));
        tests.observe(event("bash", "success", "{\"command\":\"npx playwright test\"}",
                "exitCode=0; No tests found"));
        check(tests.hasUnverifiedLatestRuns(), "Unexecuted suite cannot be hidden by a different passing suite");
        tests.observe(event("bash", "success", "{\"command\":\"npx playwright test\"}",
                "exitCode=0; 2 passed"));
        check(!tests.hasUnverifiedLatestRuns(), "Verified rerun supersedes the earlier zero-test attempt");
        tests.observe(event("bash", "error", "{\"command\":\"npm test\"}",
                "exitCode=1; 1 failed"));
        check(tests.hasFailedTests(), "A failing latest runner must prevent a final Completed status");

        var unverified = new AgentUniversalOutcomeEvidence();
        unverified.observe(event("bash", "success", "{\"command\":\"./mvnw verify\"}",
                "exitCode=0; BUILD SUCCESS"));
        check(!unverified.hasCheckEvidence(), "Shell command alone is not an independent verifier result in generic ledger");
        check(unverified.report("completed", 0, false, "").contains("tool success does not establish"),
                "A successful shell command is not proof of requirement coverage");
        unverified.observe(event("bash", "success", "{\"command\":\"npm test\"}",
                "exitCode=1; FAIL"));
        check(unverified.hasUnresolvedToolFailures(), "Exit code overrides a misleading tool-success status");

        var thirdParty = new AgentUniversalOutcomeEvidence();
        thirdParty.observe(event("mcp__jira__get_issue", "success", "{\"issueKey\":\"QA-12\"}", "record retrieved"));
        thirdParty.observe(event("custom_automation_tool", "success", "{\"target\":\"file\"}", "created artifact"));
        thirdParty.observe(event("subagent:tester→read", "success", "{\"path\":\"tests/FooTest.java\"}", "found"));
        check(thirdParty.completedToolEvents() == 3, "MCP, future tools and subagent tools all tracked");
        check(thirdParty.report("completed", 0, false, "").contains("MCP"), "External workflows covered");

        var secrets = new AgentUniversalOutcomeEvidence();
        secrets.observe(event("bash", "success", "{\"command\":\"curl -H api_key=abc123 --silent https://example.org\"}",
                "exitCode=0; response"));
        check(!secrets.report("completed", 0, false, "").contains("abc123"), "Secrets must be redacted in tool receipt");

        var readOnly = new AgentUniversalOutcomeEvidence();
        readOnly.observe(event("grep", "success", "{\"pattern\":\"@GetMapping\"}", "3 matches"));
        check(readOnly.report("completed", 0, false, "").contains("inspections"), "Read-only queries show evidence");
        check(!AgentResultPresentation.needsUniversalOutcome("One finding", 0, 1),
                "A single cheap read should not automatically require a new model call");

        check(AgentResultPresentation.needsUniversalOutcome("The work is complete.", 4, 5),
                "Generic success-only response cannot finish substantive development task");

        // 148 artifact read-back is cross-workflow, not limited to .md Planner files.
        Path temp = Files.createTempDirectory("eliya148-");
        try {
            Files.writeString(temp.resolve("NewService.java"), "class NewService { void work() {} }\n");
            Files.writeString(temp.resolve("settings.json"), "{\"feature\":true}");
            Files.writeString(temp.resolve(".env"), "TOKEN=DO_NOT_READ");
            Files.writeString(temp.resolve("credentials.json"), "{\"private\":true}");
            String readBack = AgentArtifactResultEvidence.collect(temp,
                    List.of("NewService.java", "settings.json", ".env", "credentials.json", "../outside.java"));
            check(readBack.contains("NewService.java") && readBack.contains("NewService"),
                    "Read-back must include newly generated code");
            check(readBack.contains("settings.json") && readBack.contains("feature"),
                    "Read-back must include bounded JSON files");
            check(!readBack.contains("DO_NOT_READ") && !readBack.contains("credentials.json") &&
                    !readBack.contains("../outside.java"), "Do not reveal common secret stores or leave workspace");
        } finally {
            for (String file : List.of("NewService.java", "settings.json", ".env", "credentials.json"))
                Files.deleteIfExists(temp.resolve(file));
            Files.deleteIfExists(temp);
        }
        System.out.println("PASS: ELIYA148 generic outcomes, read/write, planner, developer, testing, MCP, custom tools, " +
                "subagents, failures, rerun, safety and synthesis economy");
    }
}
