#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -d "$OUT" "$BASE/qa/Eliya146SourceParserSmoke.java"
java -cp "$OUT" Eliya146SourceParserSmoke \
  "$BASE/src/main/java/com/llmart/llm/service/AgentService.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentArtifactVerificationPolicy.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentArtifactResultEvidence.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentResultPresentation.java"
