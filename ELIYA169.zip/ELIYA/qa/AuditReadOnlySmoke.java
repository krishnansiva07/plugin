package com.llmart.llm.service;

import java.util.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** No Spring/Maven/model dependency: live Java assertions against the runtime policies. */
public final class AuditReadOnlySmoke {
    static int passed;
    static void check(String label, boolean condition) {
        if (!condition) throw new AssertionError(label);
        passed++;
    }

    public static void main(String[] args) {
        String request = "run the verification greps on Migration/prompt-*.md and report which (if any) are missing";
        check("Audit request detected", AgentReadOnlySearchPolicy.isAudit(request));
        check("Read-only routing", AgentConversationIntent.isFastReadOnly(request));
        check("Audit with execute verb", AgentConversationIntent.isFastReadOnly(
                "Execute each extracted grep against the workspace and compare matches, report missing"));
        check("Implementation not audit", !AgentReadOnlySearchPolicy.isAudit(
                "fix missing greps in Migration/prompt-1.md and run verification"));
        check("Build remains protected", !AgentConversationIntent.isFastReadOnly(
                "Run the integration tests, repair failures and report the final status"));
        check("Requested file remains protected", !AgentConversationIntent.isFastReadOnly(
                "Run grep and export the results as an Excel file"));

        Set<String> tools = Set.of("grep", "bash", "read", "write", "test", "tool_search");
        Set<String> audit = AgentToolPalettePolicy.select(request, true, tools);
        check("Safe audit shell available", audit.contains("bash"));
        check("Read available", audit.contains("read"));
        check("Grep available", audit.contains("grep"));
        check("No mutating tool", !audit.contains("write"));
        check("No test tool in read-only palette", !audit.contains("test"));

        String[] accepted = {"rg -n foo Migration/", "grep -rn 'abc' Migration/", "git grep -n foo -- Migration/",
                "findstr /S /N /I abc Migration\\*.md", "rg -l --glob '*.md' foo Migration/"};
        for (String cmd : accepted) check("Safe search " + cmd, AgentReadOnlySearchPolicy.isSafeSearchCommand(cmd));
        String[] rejected = {"mvn test", "rg foo; rm -rf Migration/", "rg foo && rm Migration/a",
                "rg foo | tee out.txt", "rg foo > output.txt", "rg foo `whoami`", "rg foo $(date)",
                "rg --pre='sh -c echo hi' foo", "rg foo ../secrets", "rg foo /etc", "rg foo C:\\Windows",
                "rg foo ~\\Documents", "rg foo\nrm notes.txt", "rg foo %USERPROFILE%"};
        for (String cmd : rejected) check("Unsafe search rejected " + cmd, !AgentReadOnlySearchPolicy.isSafeSearchCommand(cmd));
        check("rg 1 is no match", AgentReadOnlySearchPolicy.isNoMatch("bash", "rg -n absent Migration/", "exitCode=1; elapsed=12ms; output="));
        check("rg 2 is real failure", !AgentReadOnlySearchPolicy.isNoMatch("bash", "rg -n absent Migration/", "exitCode=2; output=permission denied"));
        check("rg 1 path error is not valid miss", !AgentReadOnlySearchPolicy.isNoMatch("bash", "rg -n absent Migration/", "exitCode=1; No such file or directory"));
        check("build exit1 is real failure", !AgentReadOnlySearchPolicy.isNoMatch("build", "rg -n absent Migration/", "exitCode=1;"));
        check("mutation-command exit1 is real failure", !AgentReadOnlySearchPolicy.isNoMatch("bash", "rg foo && rm a", "exitCode=1;"));

        AgentCompletionEvidence auditEvidence = new AgentCompletionEvidence();
        auditEvidence.observe(Map.of("tool", "read", "status", "success", "output", "sample"));
        check("Reads alone do not prove grep audit", !auditEvidence.hasSearchEvidence());
        auditEvidence.observe(Map.of("tool", "bash", "status", "error", "args", "{\"command\":\"rg absent Migration/\"}", "output", "exitCode=1;"));
        check("Zero-match search counts as observed audit", auditEvidence.hasSearchEvidence());
        AgentCompletionEvidence noExecution = new AgentCompletionEvidence();
        noExecution.observe(Map.of("tool", "bash", "status", "error", "args", "{\"command\":\"wc -l Migration/prompt-1.md\"}", "output", "exitCode=1;"));
        check("Failed line count cannot prove grep audit", !noExecution.hasSearchEvidence());
        AgentCompletionEvidence structured = new AgentCompletionEvidence();
        structured.observe(Map.of("tool", "resource_grep", "status", "success", "output", "[]"));
        check("Reference grep qualifies as audit search", structured.hasSearchEvidence());
        AgentUniversalOutcomeEvidence report = new AgentUniversalOutcomeEvidence();
        report.observe(Map.of("tool", "bash", "status", "error",
                "args", "{\"command\":\"rg -n missing Migration/\"}",
                "output", "exitCode=1; result="));
        check("Search miss recorded", report.observed());
        check("Search miss recognized as read", report.hasReadEvidence());
        check("Miss not unresolved shell error", !report.hasUnresolvedToolFailures());
        check("Miss is not shell execution", !report.hasActionEvidence());
        String receipt = report.report("completed", 0, false, "", List.of());
        check("Receipt says no matches", receipt.contains("zero matches"));
        check("No bogus required build verifier", receipt.contains("code-build verifier is not required"));
        check("Receipt retains coverage disclaimer", receipt.contains("full request coverage"));
        report.observe(Map.of("tool", "test", "status", "error",
                "args", "{\"command\":\"mvn test\"}", "output", "exitCode=1;"));
        check("Actual failed test recorded", report.hasUnresolvedToolFailures());
        check("Specific failure is available", report.latestUnresolvedToolFailure().contains("mvn test"));
        try {
            Path root = Files.createTempDirectory("eliya-audit-smoke-");
            Path migration = Files.createDirectories(root.resolve("Migration"));
            Files.writeString(migration.resolve("prompt-1.md"), "first\nsecond\n", StandardCharsets.UTF_8);
            Files.writeString(migration.resolve("prompt-2.md"), "one line without final newline", StandardCharsets.UTF_8);
            String cmd = "wc -l Migration/prompt-1.md Migration/prompt-2.md";
            check("Portable line-count recognized", AgentPortableInspection.supports(cmd));
            String counted = AgentPortableInspection.execute(root, cmd);
            check("Portable count succeeds", counted.startsWith("exitCode=0;"));
            check("First file counted exactly", counted.contains("2 Migration/prompt-1.md"));
            check("Second counts newline characters", counted.contains("0 Migration/prompt-2.md"));
            check("Total present", counted.contains("2 total"));
            check("Portable count did not mutate", counted.contains("workspaceChanged=false"));
            check("Missing file is failure", AgentPortableInspection.execute(root, "wc -l Migration/missing.md").startsWith("exitCode=1;"));
            check("Traversal rejected", !AgentPortableInspection.supports("wc -l ../secrets"));
            check("Absolute rejected", !AgentPortableInspection.supports("wc -l C:\\Windows\\secret"));
            check("Shell chain rejected", !AgentPortableInspection.supports("wc -l Migration/prompt-1.md && del file"));
            check("Unrecognized command is not rewritten", AgentPortableInspection.execute(root, "wc -c Migration/prompt-1.md") == null);
            try {
                Path symlink = migration.resolve("shortcut.md");
                Files.createSymbolicLink(symlink, migration.resolve("prompt-1.md"));
                check("Symlink is not followed", AgentPortableInspection.execute(root, "wc -l Migration/shortcut.md").startsWith("exitCode=1;"));
                Files.deleteIfExists(symlink);
            } catch (UnsupportedOperationException | java.nio.file.AccessDeniedException unsupported) {
                // Filesystem-level symlink creation may be prohibited; never lower the policy itself.
            }
            Files.delete(migration.resolve("prompt-1.md"));
            Files.delete(migration.resolve("prompt-2.md"));
            Files.delete(migration);
            Files.delete(root);
        } catch (Exception error) { throw new AssertionError("Portable line-count smoke setup", error); }
        System.out.println("PASS " + passed + " Java assertions: read-only routing, search safety, negative matches, reporting, verifier isolation");
    }
}
