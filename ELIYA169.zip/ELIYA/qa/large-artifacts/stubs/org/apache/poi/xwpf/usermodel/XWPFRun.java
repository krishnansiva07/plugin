package org.apache.poi.xwpf.usermodel;
public class XWPFRun {
    public void setText(String text) {}
    public void setBold(boolean bold) {}
    public void setFontSize(int fontSize) {}
}
