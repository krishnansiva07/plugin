package org.apache.poi.xwpf.usermodel;
import java.util.*;
public class XWPFTable {
    private final List<XWPFTableRow> rows = new ArrayList<>();
    public XWPFTable(int r, int c) {for(int i=0;i<r;i++)rows.add(new XWPFTableRow(c));}
    public XWPFTableRow getRow(int i) {return rows.get(i);}
}
