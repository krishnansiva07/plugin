package org.apache.poi.xwpf.usermodel;
import java.io.*;import java.util.*;
public class XWPFDocument implements AutoCloseable {
    private final List<XWPFParagraph> paragraphs=new ArrayList<>();
    public XWPFDocument() {}
    public XWPFDocument(InputStream in) throws IOException {if(in.read()<0)throw new IOException("empty");paragraphs.add(new XWPFParagraph());}
    public XWPFParagraph createParagraph() {XWPFParagraph p=new XWPFParagraph();paragraphs.add(p);return p;}
    public List<XWPFParagraph> getParagraphs() {return paragraphs;}
    public List<Object> getTables() {return List.of();}
    public XWPFTable createTable(int rows, int cols) {return new XWPFTable(rows, cols);}
    public void write(OutputStream out) throws IOException {out.write("FAKE_DOCX_FOR_OFFLINE_SMOKE_ONLY".getBytes());}
    public void close() {}
}
