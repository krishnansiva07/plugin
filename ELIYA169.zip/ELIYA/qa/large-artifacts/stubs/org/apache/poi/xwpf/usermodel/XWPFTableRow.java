package org.apache.poi.xwpf.usermodel;
import java.util.*;
public class XWPFTableRow {
    private final List<XWPFTableCell> cells = new ArrayList<>();
    public XWPFTableRow(int c) {for(int i=0;i<c;i++)cells.add(new XWPFTableCell());}
    public XWPFTableCell getCell(int i) {return cells.get(i);}
}
