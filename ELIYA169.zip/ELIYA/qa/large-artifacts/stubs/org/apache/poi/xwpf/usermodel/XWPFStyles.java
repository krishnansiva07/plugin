package org.apache.poi.xwpf.usermodel;
public class XWPFStyles {}
