package org.apache.poi.xwpf.usermodel;
public enum ParagraphAlignment {LEFT}
