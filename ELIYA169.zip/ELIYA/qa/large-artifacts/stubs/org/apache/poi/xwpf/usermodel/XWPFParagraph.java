package org.apache.poi.xwpf.usermodel;
public class XWPFParagraph {
    public void setStyle(String s) {}
    public void setIndentationLeft(int n) {}
    public XWPFRun createRun() {return new XWPFRun();}
}
