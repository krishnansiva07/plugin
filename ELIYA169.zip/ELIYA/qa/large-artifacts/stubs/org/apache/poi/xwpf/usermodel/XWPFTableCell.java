package org.apache.poi.xwpf.usermodel;
public class XWPFTableCell {public void setText(String t) {}}
