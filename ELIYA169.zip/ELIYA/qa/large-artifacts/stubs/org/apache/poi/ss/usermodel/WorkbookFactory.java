package org.apache.poi.ss.usermodel;
import java.io.*;
public class WorkbookFactory {
    public static Workbook create(InputStream in)throws IOException {if(in.read()<0) throw new IOException("empty");return new Workbook();}
    public static class Workbook implements AutoCloseable {
        public int getNumberOfSheets(){return 1;}
        public Sheet getSheetAt(int i){return new Sheet();}
        public void close(){}
    }
    public static class Sheet {public int getPhysicalNumberOfRows(){return 1;}}
}
