package com.fasterxml.jackson.databind;
import java.io.*;import java.util.*;
/** Test-only file-backed Java serialization stand-in; not shipped to the application classpath. */
public class ObjectMapper {
    public void writeValue(File target,Object value) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(target))) {out.writeObject(value);}
    }
    @SuppressWarnings("unchecked")
    public <T> T readValue(File source, Class<T> type) throws IOException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(source))) {return (T)in.readObject();}
        catch (ClassNotFoundException error){throw new IOException(error);}
    }
    public Object readTree(String json) throws IOException {
        if(json == null || json.isBlank() || !json.stripLeading().matches("(?s)^[{\\[].*"))
            throw new IOException("Invalid JSON fixture");
        return json;
    }
}
