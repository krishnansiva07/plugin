package com.llmart.llm.service;
import java.io.*;import java.nio.file.*;
/** Test-only workspace writer to check the service API; real writer uses guarded baseline+rollback. */
public class AgentWorkspaceService {
    public record Workspace(Path root){}
    public String writeFileBytes(Workspace w,String rel,byte[] bytes,boolean overwrite)throws IOException {
        Path path=w.root.resolve(rel).normalize();
        if(!path.startsWith(w.root))throw new SecurityException("escaping path");
        if(Files.exists(path) && !overwrite)throw new FileAlreadyExistsException(rel);
        Files.createDirectories(path.getParent());
        Files.write(path,bytes);
        return "workspaceChanged=true; Wrote " + rel;
    }
}
