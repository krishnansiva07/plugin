package com.llmart.llm.service;
public class ExcelExportService {
    public byte[] fromMarkdown(String title, String markdown) {return ("FAKE_XLSX_" + markdown.length()).getBytes();}
}
