package com.llmart.llm.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;import java.util.*;
public class ContractSmoke {
    private static int tests=0;
    static void check(boolean okay, String context){tests++;if(!okay)throw new AssertionError(context);}
    static void fail(RunnableThrowing action,String context)throws Exception{
        tests++;try{action.run();}catch(Exception expected){return;}throw new AssertionError("Expected failure: "+context);
    }
    interface RunnableThrowing {void run()throws Exception;}
    static String id(String response) {return response.split("id=")[1].split(" ")[0];}
    static String source(int lines) {StringBuilder content=new StringBuilder("# Complete migration plan\n");
        for(int i=1;i<=lines;i++)content.append("Step ").append(i).append(": Implement and verify requirement ").append(i).append(".\n");
        return content.toString();}
    public static void main(String[] args)throws Exception {
        Path work=Files.createTempDirectory("eliya-artifact-live-");
        System.setProperty("eliya.artifacts.staging",Files.createTempDirectory("eliya-artifact-stage-").toString());
        LargeArtifactService generation=new LargeArtifactService(new ObjectMapper(),new ExcelExportService());
        AgentWorkspaceService files=new AgentWorkspaceService();
        var ws=new AgentWorkspaceService.Workspace(work);
        String content=source(5_000);
        int chunk=40_000;
        int chunks=(content.length()+chunk-1)/chunk;
        String marker=generation.start(work,"prompts/migration.md",chunks,5000,List.of("Step 5000"),false);
        String job=id(marker);
        check(!Files.exists(work.resolve("prompts/migration.md")),"staging must not touch workspace");
        fail(()->generation.finalizeArtifact(files,ws,job,"prompts/migration.md"),"missing chunks are a hard blocker");
        for(int n=0;n<chunks;n++) {
            String part=content.substring(n*chunk,Math.min(content.length(),(n+1)*chunk));
            generation.append(work,job,n,part);
            if(n==0) {
                check(generation.append(work,job,n,part).contains("CHUNK_REUSED"),"idempotent retry");
                fail(()->generation.append(work,job,0,"conflicting content"),"conflicting chunk retry");
            }
        }
        check(generation.status(work,job).contains("missing=[]"),"all parts present");
        // Restart simulation: metadata and chunks are file-backed rather than instance state.
        LargeArtifactService restarted=new LargeArtifactService(new ObjectMapper(),new ExcelExportService());
        String verified=restarted.finalizeArtifact(files,ws,job,"prompts/migration.md");
        check(verified.contains("ARTIFACT_VERIFIED"),"5k-line finalizer passed");
        check(Files.readString(work.resolve("prompts/migration.md")).equals(content),"5k-line source read back exactly");
        check(restarted.verify(work,job).contains("ARTIFACT_VERIFIED"),"receipt hash matches");
        check(restarted.finalizeArtifact(files,ws,job,"prompts/migration.md").contains("idempotent finalize retry"),
                "replayed finalize does not overwrite or falsely fail");
        fail(()->restarted.append(work,job,0,"new contents"),"completed session cannot be changed");
        fail(()->restarted.extend(work,job,chunks+1),"completed session cannot be extended");
        fail(()->generation.start(work,"prompts/migration.md",1,0,List.of(),false),"no implicit overwrite");
        fail(()->generation.start(work,"../escape.md",1,0,List.of(),false),"traversal rejected");
        String invalidId=id(generation.start(work,"bad.html",1,0,List.of(),false));
        generation.append(work,invalidId,0,"<html><body>missing close");
        fail(()->generation.finalizeArtifact(files,ws,invalidId,"bad.html"),"invalid HTML blocked");
        check(!Files.exists(work.resolve("bad.html")),"invalid artifact not committed");
        String html="<!doctype html><html><body>"+"<p>Content</p>\n".repeat(5_000)+"</body></html>";
        int parts=(html.length()+chunk-1)/chunk;
        String h=id(generation.start(work,"site.html",parts,5000,List.of("</html>"),false));
        for(int i=0;i<parts;i++)generation.append(work,h,i,html.substring(i*chunk,Math.min(html.length(),(i+1)*chunk)));
        generation.finalizeArtifact(files,ws,h,"site.html");
        check(Files.readString(work.resolve("site.html")).equals(html),"5k-line HTML round trip");
        String extended=id(generation.start(work,"extended.txt",1,0,List.of(),false));
        generation.append(work,extended,0,"one ");
        check(generation.extend(work,extended,2).contains("PLAN_EXTENDED"),"extend plan on demand");
        fail(()->generation.finalizeArtifact(files,ws,extended,"extended.txt"),"extended missing chunk blocked");
        generation.append(work,extended,1,"two");
        generation.finalizeArtifact(files,ws,extended,"extended.txt");
        check(Files.readString(work.resolve("extended.txt")).equals("one two"),"extended content preserved");
        String d=id(generation.start(work,"document.docx",1,0,List.of(),false));
        generation.append(work,d,0,"# Heading\nParagraph\n\n| Name | Status |\n| --- | --- |\n| Unit | Passed |\n");
        generation.finalizeArtifact(files,ws,d,"document.docx");
        check(generation.verify(work,d).contains("ARTIFACT_VERIFIED"),"DOCX adapter invocation verified by stub; not native POI");
        String x=id(generation.start(work,"table.xlsx",1,0,List.of(),false));
        generation.append(work,x,0,"| A | B |\n| --- | --- |\n| 1 | 2 |\n");
        generation.finalizeArtifact(files,ws,x,"table.xlsx");
        check(generation.verify(work,x).contains("ARTIFACT_VERIFIED"),"XLSX adapter invocation verified by stub; not native POI");
        check(generation.pending(work).contains("ARTIFACT_STATUS id="+invalidId),"unfinished sessions recoverable");
        System.out.println("PASS " + tests + " offline large-artifact Java contract checks (Office adapters stubbed)");
    }
}
