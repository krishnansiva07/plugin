#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
classes="$(mktemp -d)"
trap 'rm -rf "$classes"' EXIT
find qa/large-artifacts/stubs -name '*.java' -print > "$classes/sources.txt"
printf '%s\n' src/main/java/com/llmart/llm/service/LargeArtifactService.java qa/large-artifacts/ContractSmoke.java >> "$classes/sources.txt"
javac -encoding UTF-8 -d "$classes" @"$classes/sources.txt"
java -cp "$classes" com.llmart.llm.service.ContractSmoke
