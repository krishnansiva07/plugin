#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" \
 "$BASE/src/main/java/com/llmart/llm/service/AgentRecoveryEscalationPolicy.java" \
 "$BASE/qa/agent-recovery-decision/RecoveryDecisionSmoke.java"
java -cp "$TMP" com.llmart.llm.service.RecoveryDecisionSmoke
