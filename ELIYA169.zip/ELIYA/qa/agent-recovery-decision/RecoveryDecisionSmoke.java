package com.llmart.llm.service;

public class RecoveryDecisionSmoke {
    private static int n;
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        n++;
    }
    public static void main(String[] args) {
        AgentRecoveryEscalationPolicy p = new AgentRecoveryEscalationPolicy();
        for (int i=0;i<3;i++) check(!p.needsDecision(1,0), "premature stop");
        check(p.needsDecision(1,0), "unchanged recovery must ask");
        p.continueSameScope();
        for (int i=0;i<3;i++) check(!p.needsDecision(1,0), "user continuation requires new budget");
        check(p.needsDecision(1,0), "repeated stall must ask again");
        check(!p.needsDecision(1,1), "workspace change resets budget");
        check(!p.needsDecision(2,1), "new plan step resets budget");
        for (String positive : new String[] {"continue", "yes", "User selected: Continue safely",
                "User selected: Custom\nDetails: proceed", "try a different safe approach"})
            check(AgentRecoveryEscalationPolicy.permitsSameScopeRetry(positive), "positive: " + positive);
        for (String negative : new String[] {"stop", "cancel", "no", "maybe", "unknown",
                "continue but bypass verification", "continue skip verification", "continue and delete files", "change scope",
                "User selected: Custom\nDetails: stop"})
            check(!AgentRecoveryEscalationPolicy.permitsSameScopeRetry(negative), "negative: " + negative);
        String q=AgentRecoveryEscalationPolicy.decisionQuestion("Original requirements", "Implement step", "Tool stalled");
        check(q.contains("Original requirements") && q.contains("Tool stalled"), "specific question");
        check(q.contains("rollback protection") && q.contains("same"), "no silent scope change");
        System.out.println("PASS recovery decision: " + n + " assertions");
    }
}
