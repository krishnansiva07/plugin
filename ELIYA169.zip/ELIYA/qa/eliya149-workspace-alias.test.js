const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const src = fs.readFileSync(path.join(__dirname, '../src/main/resources/static/app.js'), 'utf8');
const a = src.indexOf('const verifiedReferencePaths = new Map();');
const b = src.indexOf('\nfunction referenceWriteAccess()', a);
assert.ok(a >= 0 && b > a);
const code = src.slice(a, b);
function fixture(refs, respond) {
  const logs = [];
  const box = {
    state: { conversationId:'conv1', referenceProjects:refs },
    api:async (url, options) => { logs.push([url,options]); return respond(url,options); },
    saveReferenceFolders:()=>logs.push(['saved']),
    renderReferenceFolders:()=>logs.push(['rendered']),
    watchFolderIndex:async ()=>{},
    console,
  };
  vm.createContext(box);
  vm.runInContext(code, box);
  return {box, logs};
}
test('mapped reference alias survives case changes and does not match partial names', () => {
  const {box} = fixture([],()=>{});
  assert.equal(box.promptUsesReferenceAlias('Analyse @LEGACYSELENIUM','LegacySelenium'),true);
  assert.equal(box.promptUsesReferenceAlias('Analyse OtherLegacySelenium','LegacySelenium'),false);
  assert.equal(box.promptUsesReferenceAlias('Analyse API_Base2','API_Base'),false);
});
test('reference mapping uses same saved path, preserves writable permission and caches valid ID', async () => {
  const ref={id:'r1', name:'LegacySelenium', path:'C:\\src\\legacy', writable:true};
  const {box,logs}=fixture([ref],async (url)=>({id:'r1', localWorkspace:true, localPath:'c:\\SRC\\legacy'}));
  const first=await box.resolvedReferencesForMessage('Analyse LegacySelenium');
  assert.equal(first.length,1);
  assert.equal(first[0].name,'LegacySelenium');
  assert.equal(first[0].writable,true);
  assert.equal(logs.filter(e=>e[0]?.startsWith('/api')).length,1);
  await box.resolvedReferencesForMessage('Review LegacySelenium');
  assert.equal(logs.filter(e=>e[0]?.startsWith('/api')).length,1);
});
test('stale ref ID reconnects to exact configured path without losing alias or access permission', async () => {
  const ref={id:'stale', name:'API_Base', path:'C:\\src\\api', writable:false};
  const {box,logs}=fixture([ref],async (url, options)=>{
    if (url.includes('stale')) throw new Error('missing');
    if (url === '/api/projects/local') {
      assert.equal(JSON.parse(options.body).path,ref.path);
      return {id:'recovered', localWorkspace:true, localPath:'C:\\src\\api'};
    }
    throw new Error('unexpected api call');
  });
  const result=await box.resolvedReferencesForMessage('Compare API_Base with main');
  assert.equal(result[0].id,'recovered');
  assert.equal(result[0].writable,false);
  assert.equal(result[0].name,'API_Base');
  assert.ok(logs.some(e=>e[0]==='saved'));
});
test('named missing reference fails explicitly rather than using a different project', async () => {
  const ref={id:'stale', name:'OldCode', path:'/projects/old', writable:false};
  const {box}=fixture([ref],async (url)=>{
    if (url === '/api/projects/local') return {id:'wrong', localWorkspace:true, localPath:'/projects/unrelated'};
    throw new Error('missing');
  });
  await assert.rejects(box.resolvedReferencesForMessage('Review OldCode'), /Reference alias unavailable: OldCode/);
  assert.equal(ref.id,'stale');
  const noAlias=await box.resolvedReferencesForMessage('Hello');
  assert.equal(noAlias.length,0);
});
test('path equality remains case-sensitive on Unix and tolerant of Windows letter case', () => {
  const {box}=fixture([],()=>{});
  assert.equal(box.sameMappedFolder('/Project/Source','/project/Source'),false);
  assert.equal(box.sameMappedFolder('C:\\Old\\Work','c:/old/work'),true);
  assert.equal(box.sameMappedFolder('C:/old/work','C:/different/work'),false);
});
test('Analyse and Agent send both restore configured primary workspace automatically', () => {
  assert.match(src, /Both Analyse and Agent inherit the last explicitly selected primary workspace/);
  assert.match(src, /selectedMappedReferences\.map\(reference => reference\.id\)/);
});
