# ELIYA

ELIYA is a local Java/Spring Boot AI development assistant with browser Chat/Analyse/Agent,
terminal sessions, mapped workspaces, reference projects, lexical and semantic retrieval,
change verification, cancellation, and durable run history.

## Analyse prompt → Agent execution: consolidated final outcome

When an implementation prompt is pasted from Analyse into Agent, the instruction is
**input**, not a request to generate another prompt. The final conversation answer
is a persisted, evidence-grounded Markdown result containing **run status, what
was completed, deliverable file paths, recorded verification, pending work, and
next steps**. The raw submitted prompt and individual plan/tool events stay in
conversation/activity history, not in the completion answer. This also covers
pasted Markdown prompt headings containing example instructions to generate
prompts or HTML; they must not switch the response to a source-file viewer.

The completion summary does not promote plan-step bookkeeping into independent
verification. It does not invent file paths, claim tests passed without an
observed verifier, or hide failures behind a completed status. A model that
echoes the submitted prompt triggers additional evidence-grounded synthesis and
is filtered from the final execution summary. Unverified output remains clearly
unverified even if the execution status reports completed.

**Offline checks in this package:** `bash qa/answer-first/run.sh` (40 Java
assertions), `bash qa/eliya129/run-completion-smoke.sh` (20),
`bash qa/eliya130/run.sh` (29), `bash qa/eliya75-answer-integrity/run.sh`
(11 cases), `node --test src/test/js/*.test.js qa/*.test.js
qa/answer-first/*.test.js` (232 tests), and `bash qa/agent-reliability/run.sh`
(185 Java sources parsed). The direct-Agent offline acceptance suite passed.
These are *not* a substitute for a complete Maven build, live Windows/model
execution, and browser verification of a real pasted-prompt implementation.

## Release/certification status

**This is a source stabilization package, not a production-certified executable.** Do not
replace a running installation until the full Maven verification and live-model end-to-end
acceptance succeed on the intended host. A passing source-level test is not proof that a
live provider/tool/browser workflow is correct.

## Answer-first questions and analysis

- A question or read-only analysis now returns the **grounded answer** in the chat; run counters, step lists, and the independent tool ledger are available in **Agent activity / View detailed task report**, rather than appended to the response.
- For read-only checks that have partial findings, the response preserves the findings first and explains unverified coverage afterward. A negative grep match is a valid finding, but a failed/missing command is never silently counted as checked.
- A provider or tool failure does not discard source-backed findings. If no source-backed answer exists, ELIYA explicitly says the answer was **not established**; it does not invent results or turn plan completion into evidence.
- A read-only answer is not proof that missing requested checks ran. Runtime `blocked` remains possible when a task contract has no adequate evidence; status and detail are in the activity view and must not be masked as success.
- For explicit mutations, edits, tests and artifact creation, existing verification and rollback gates remain enforced. These workflows still report deliverable paths and verification in the answer.
- A Java syntax defect in the read-only verification branch of `AgentService.java` was corrected to restore a parsable compilation unit.

**Offline validation:** `bash qa/answer-first/run.sh` (19 assertions); `bash qa/eliya129/run-completion-smoke.sh` (20); `bash qa/eliya130/run.sh` (29); `bash qa/eliya148-universal-outcome-smoke.sh` (source parser and suite); and `node --test src/test/js/*.test.js qa/*.test.js` (221 tests). Full Maven build, live-model answer synthesis and Windows browser acceptance remain unverified in this environment.

## Agent stop / planning stabilization — validation evidence (19 Nov 2026)

This checkpoint fixes a reproducible Agent planning failure and hardens cancellation:

- The `AgentToolPalettePolicy` code-tool `Set.of` formerly contained duplicate `artifact_status`, `artifact_pending`, and `artifact_check` entries. Java threw `IllegalArgumentException` during static initialization, preventing the Agent tool selection policy from loading. Duplicate entries were removed.
- The tracked Agent worker is now registered early (before expensive workspace and context preparation). Explicit Stop interrupts the worker, signals waiting approval/question handlers, stops run-owned subprocesses, and records a `cancelling` state until the worker actually exits. Repeated Stop requests are idempotent. A race with late completion cannot change a cancelled run to `completed`.
- The browser Stop control prefers the active message's run ID, does not discard the stream if the backend refuses or cannot acknowledge cancellation, and distinguishes **Stop accepted** from **backend worker finished**.
- A cancelled Agent attempts to persist a visible conversation outcome, allowing conversation reload to recover the cancellation result. A database failure is disclosed, not silently reported as success.
- Three legacy isolated Java/shell test harnesses were updated so their compile stubs include newly required production types.

**Executed offline regression:** 217/217 JavaScript checks; 21/21 live Java lifecycle assertions for the real `AgentRunService` compiled in isolation; and 22/22 focused shell QA suites, including tool-policy initialization, source parsing, terminal cancellation/typechecking, large artifact staging, and prompt-deliverable checks. See `validation/positive-negative-test-cases.csv` and `validation/positive-negative-test-matrix.xlsx` for **134 positive and negative cases spanning 67 modules**. Each scenario distinguishes isolated coverage from unexecuted integration acceptance.

**Remaining release gates:** Maven dependencies were not accessible in the validation environment, so the complete Spring Boot application/JAR could not be compiled or launched here. Before replacing a running deployment, execute `./mvnw -Pfull-tests clean verify` on the intended host, launch the packaged JAR, and run the P0 browser/provider/Windows terminal acceptance cases (especially Stop during planning, model network stall, question/approval, subprocess execution, and recovery after reload). The ZIP is a complete corrected **source** package, not a certified binary.

## Workspace analysis and rollback safety limits

- **Indexing** limits (indexed/scanned files and source read bounds) remain independent of
  **Agent rollback protection**. Neither setting is a guarantee that all code was reviewed.
- `Settings → Workspace indexing & large source files` persists index settings locally.
- `Settings → Agent rollback protection` persists the maximum baseline file count,
  total byte size (entered in MiB), and snapshot deadline. These apply to the next Agent
  run without JVM launch flags or an index rescan. Changing them never disables rollback.
- Read-only analysis of attached source documents, including `.md` inputs, skips the
  backup and is restricted to read/search tools. Explicit file creation, implementation,
  migration or test execution remains subject to the protected rollback baseline.
- The rollback baseline includes the primary writable workspace and any **explicitly
  writable** reference/secondary workspace. Ordinary read-only reference repositories
  are excluded from snapshots. Do not widen protection limits just to copy an enormous
  legacy reference that is only being read for a migration.
- Snapshot preparation must fit the configured file, size and deadline limits and
  available local disk. A failed baseline stops before modifications and reports which
  independent safety limit was exceeded.

## What changed in this checkpoint

- **Human-readable task outcomes:** completed, blocked and failed Agent tasks now include a grounded account of finished steps, tracked changes, unfinished work, verification, improvement opportunities and the next action. Operational exceptions are saved as assistant turns instead of only emitting a transient stream error.
- **Correct failure-stage display:** the durable backend preserves the stage where a run stopped, including across restarts. The UI uses that stage instead of falsely coloring Plan red; if no stage is known, it avoids inventing one. Blocked/failed progress is clearly labeled as *not complete* even if activity reached a high percentage.
- **Recovered conversation outcomes:** saved runs with empty/generic responses reconstruct a cautious summary from their recorded evidence, and detailed reports load automatically after the run ends.
- **Autonomous run recovery:** every unfinished queued/running/cancelling/waiting state is
  marked interrupted after service restart; terminal states are finalized. Retains durable
  original task contract across resumed large tasks, together with work items and verification
  history. Does not silently resume an interrupted command.
- **Execution monitor:** terminal and browser runs are aggregated by run ID. An active browser
  SSE stream awaiting backend confirmation is shown as `connecting`, not falsely as `0 running`
  or asserted as a verified backend execution.
- **Index recovery:** a restored project index-status request can initiate the single bounded
  background index worker even if no earlier project GET occurred. Failed scans do not cause
  an infinite auto-retry on subsequent status polls.
- **Incomplete indexes:** scans hitting filesystem/file-count limits are explicitly marked
  failed, not falsely advertised as a complete index. Previous results stay fenced.
- **Semantic retrieval:** credential-free embedding requests are allowed only to HTTP
  loopback endpoints; external endpoints still require credentials. Semantic failures keep
  lexical search available and are not treated as verified semantic success.
- **Large repositories:** graph enrichment is bounded to the top-scoring 1,600 nearby files
  above 10,000 indexed files; large-workspace overviews avoid an unbounded series of fresh
  filesystem-stat calls and clearly mark the cached file manifest as not fully rechecked.
- **Build discipline:** build scripts now run `clean verify` with the Maven full-test profile;
  compilation/test failure and missing/non-executable JAR fail the build instead of claiming
  release success.
- **Regression:** updated outdated source and UI assertions, preserving complete long-prompt
  handoffs and testing honest active-run reporting.

## Workspace indexing and source-read settings

In the browser, open **Settings → Workspace indexing & large source files**. The
controls are stored under the per-user application data directory as
`workspace-indexing.properties`; they do not depend on `-D` flags or browser storage.
Use **Apply indexing limits & rescan** independently of model/provider settings.

| Limit | Default | Allowed range |
| --- | ---: | ---: |
| Maximum indexed files | 150,000 | 2,000–200,000 |
| Maximum files scanned | 300,000 | indexed-file cap–500,000 |
| Indexed source file size | 1,500,000 bytes | 32,000–8,000,000 bytes |
| Indexed source sample | 48,000 characters | 8,000–200,000 characters |
| Source lines per read request | 2,500 | 100–10,000 |
| Full-file read size | 256 KB | 64–8,192 KB |

File-count/size/sample changes invalidate the saved index fingerprint and queue a
background rebuild of currently tracked primary and reference projects. The browser
shows indexing status while the scan is in progress. Source-read settings take
effect immediately, without a full index rebuild. Source reads that reach the line
limit provide an explicit next-line continuation. These controls do not increase
model context/output token capacity and are not a cure for interrupted long-form
model generation or partial file writes. Large repositories may still hit memory,
filesystem, document parsing or embedding constraints.

The Verified Learning Memory editor was removed from Settings, but existing
learning records, their approval protections and the underlying service remain
unchanged. No learning data is deleted by this UI cleanup.

**Additional offline checks:** 202/202 JavaScript tests; three indexing-settings UI
contract tests; compiled Java persistence and REST-controller smoke tests;
12,051-file synthetic indexing/restart smoke; intelligence/rescan/watch smoke;
Chromium Settings save/reopen and long-output rendering checks. Maven/JAR startup
and a real 125,000-file reference workspace were not tested here.

## Offline validation evidence

For these completion-reporting changes, Java 17 syntax parsing of the modified Java files and an executable narrator harness passed. Offline checks of verification, stage restoration, rollback gating, browser rendering, and source safety passed. **The new JUnit tests have been added but have not been run using Maven** because the dependency repository is unavailable here.

See `validation/acceptance-results.txt` for the repeatable verification commands and results.
The executed checks included:

- JavaScript tests, including QA test files: **200 passed, 0 failed**.
- Chromium browser tests for 5,000-line Markdown/HTML exports, mobile rendering, UI progress,
  approvals, chat history and client-side recovery: **passed**.
- Agent policies, protected snapshot checks, cancellation/deadline, strict completion,
  autonomous artifact verification and token comparison policy: **passed**.
- An executable offline Java test compiling the real indexing, retrieval, checkpoint,
  token-ledger and agent-run persistence classes with isolated annotation/provider stubs:
  **12,051 synthetic TypeScript files indexed**; recent isolated replay approximately 922 ms indexing and 99 ms retrieval
  in one recorded run at a 768 MB heap limit. Incremental deletion, persisted-index refresh,
  live source filtering, restart recovery and large-task contract preservation passed.
  Synthetic throughput must not be extrapolated to a production workspace.

## Read-only test inventory in Analyse

- Plain questions such as "How many test cases are present?" automatically use the currently
  mapped workspace; the user does not need to say "workspace". A named reference alias
  selects that reference instead.
- The system reads **actual test source files**, selected from the already loaded workspace
  index, without running tests or changing code. It counts Playwright/Jest-style
  `test()`/`it()` declarations, Java JUnit/TestNG annotations, Cucumber scenario
  declarations, and Python `test_` functions, and supplies file-path evidence. README
  descriptions and the number of spec files are not used to invent a count.
- This is a **static declaration count**, not the full runner-expanded number of cases.
  `test.each`, Java data providers, Cucumber Example rows, loops, configuration projects,
  skips, and other dynamic expansion may change the runtime count. Use
  `npx playwright test --list` on a suitable host for Playwright's actual discovery.
- A missing/incomplete index, unreadable/oversized tests or inventory safety limit
  produces an **explicit incomplete/lower-bound** result, not a false confirmed count.
  The operation is read-only, bounded and cancellation-aware; it does not start a full
  workspace filesystem rescan. This fixes this count workflow, not every possible
  Analyse source-retrieval question.
- The UI treats a test-count inventory question as an inventory, not as an assertion
  about test execution or migration success; a true verification question retains
  the evidence warning.

**Validation for this additional change:** 202/202 JavaScript and QA tests passed;
Java source inventory compiled and a 5-assertion standalone Java harness passed.
The new JUnit test source is included, but JUnit/Maven execution and a full JAR build
remain unverified on this offline host (Maven is not installed).

## Still required for full release certification

1. **Maven and JAR:** the build could not run here because Maven is not installed and the
   environment cannot resolve `repo.maven.apache.org`. A full Spring Boot compile, test,
   packaged `target/eliya.jar` and start-up check remain unverified. Build on a network-enabled
   host with Java 17+ and Maven, using `./build-jar.sh` or `build-jar-windows.cmd`.
2. **Live Agent and Analyse:** verify successful and failed tasks through both terminal and
   browser, including cancellation, retries, file changes and final evidence after completion.
3. **Model and MCP:** test real LLM, embedding and explicitly requested MCP endpoints with
   valid credentials; source-policy tests do not substitute for live integrations.
4. **Performance:** benchmark actual same-prompt, same-model, same-provider tasks against
   OpenCode using provider-reported tokens and verified output equivalence. Existing
   token-comparison QA runs contain synthetic fixture records.
5. **Actual JVM restart:** verify session recovery by stopping and starting the production JAR
   mid-task, restoring the browser conversation and checking that interrupted work is not
   misrepresented as completed.
6. **Large real repository:** run 10k-100k files on the target OS with its symlinks, document
   formats, ignore rules, memory profile and embedding model. The synthetic test isolates the
   indexing implementation, not real-world variability.

**No claim of complete implementation or production readiness is made for these unverified items.**

## Reproduce

```bash
bash qa/stabilization/run.sh
node --test src/test/js/*.test.js qa/*.test.js
bash qa/agent-reliability/run.sh
bash qa/eliya145-validate.sh
bash qa/eliya68-autonomous-verification.sh
bash qa/eliya65-verification-smoke.sh
bash qa/eliya83-token-economy/run.sh
./build-jar.sh
```

On Windows use `build-jar-windows.cmd` to invoke a full Maven verification. Starting the
resulting Spring Boot application is done with `java -jar target/eliya.jar`, normally served
at `http://localhost:8090` unless port settings are changed. Keep model keys out of logs
and packages. Workspace configuration and agent permissions belong to the running instance.

## Large-artifact generation and recovery

Agent's new large-file workflow is **file-first** rather than one long chat response:

1. Resolve the writable primary workspace and references. Read-only analysis does not write.
2. Call `artifact_start` for **each** requested output, specifying a relative filename,
   number of initial chunks, and user-grounded content constraints. Unspecified plural
   prompt counts are determined from the requirements; an explicit count remains binding.
3. Use numbered `artifact_append` calls. Each chunk is persisted separately outside
   the workspace; re-sending identical content is safe, conflicting content fails.
4. Use `artifact_status` to inspect missing chunks, `artifact_pending` to find
   interrupted sessions, and `artifact_extend` when more chunks are required.
5. Call `artifact_finalize` only with the **original** destination path. Missing
   chunks, required content, malformed structure or unauthorized overwrites are
   blocking errors. On success, data is committed using the normal protected workspace
   baseline and an integrity receipt is persisted. Repeated finalization is safe.
6. Call `artifact_check` for an independent checksum and native-format recheck; a
   structural check is **not** proof the content satisfies every requirement.

Supported staged outputs: `.md`, `.txt`, `.html`, `.htm`, `.json`, `.xml`, `.csv`,
`.tsv`, `.docx`, `.xlsx`. Word files are native Office files built from Markdown
headings, paragraphs, bullets and pipe tables; Excel workbooks are native `.xlsx`
files from Markdown tables, or a line-based fallback. Advanced layout, formula
logic, charts and workbook-specific structures require separate workflows and
end-to-end tests. No text file is merely renamed to an Office extension.

Stages default to `~/.eliya/artifact-staging` and allow 64 MiB of UTF-8 source
and up to 1,024 numbered chunks;
these are resource protections, **not** line-count truncation rules.
The staging path, byte budget and maximum chunks are configurable through
`eliya.artifacts.staging`, `eliya.artifacts.generationMaxBytes`, and
`eliya.artifacts.maxChunks`. A chunk may
contain up to 100,000 characters. Excel's 32,767-character cell limit is enforced
with an error instead of silently shortening content; callers must split oversized
cells. Generated files can be downloaded from their sealed Agent completion record
without loading their entire content into the browser preview (configured download
limit defaults to 128 MiB). Overwrite/rollback protections remain mandatory.

Validation in this source package:

```bash
bash qa/large-artifacts/run.sh
bash qa/prompt-deliverable/run.sh
node --test src/test/js/*.test.js
```

`qa/large-artifacts` tests Java generation, 5,000-line Markdown/HTML round-trips,
checkpoint recovery, idempotency and incomplete-content failures **using stubs** for
Spring, Jackson and Apache POI. It does **not** validate the real `.docx`/`.xlsx`
serialization libraries or full application execution. These remain mandatory
for release acceptance, along with live LLM generation, an intentional interruption,
Word/Excel open/reopen, and browser file download on the target machine.

## Prompt generation and Agent completion contract

- **Prompt generation is a deliverable, not a plan preview.** An explicit request for one or more prompts is executed as a prompt-output task. It does not authorize implementation of the instructions inside those prompts.
- **Prompt counts are binding.** For example, "5 different prompts" must produce five individually headed, independently executable prompts. Chat/Analyse continuation checks that all five sections were produced before accepting the generated completion marker.
- **Output location matters.** A chat-only prompt request is read-only. A request to save prompts in the mapped workspace uses protected Agent file writes; completion requires separate Markdown files to exist and pass read-back content checks.
- **Independent final outcomes.** A generated prompt file is not substituted for an analysis result, and the Agent does not append an execution receipt to the end of a conversational prompt. Incomplete deliverables cannot be labelled completed.
- **Recovery UI is scoped.** Incomplete prompt sets have one retry action from the original request. Individual complete prompts can be downloaded or handed off to Agent one at a time. The old recursive "generate complete prompt/file" actions are removed.

Run the focused regression checks with `bash qa/prompt-deliverable/run.sh` (Java and Node.js) and UI checks with `node --test qa/*.test.js qa/prompt-deliverable/prompt-deliverable.test.js`. The complete Spring Boot executable still requires an available Maven installation, resolved dependencies and live-model integration tests. Do not treat the focused checks as full application certification.

## Evidence-based grep audits and runtime recovery

A request such as `run the verification greps on Migration/prompt-*.md and report which are missing` is a **read-only audit**, not a request for code changes or a Maven build. The Agent's fast read-only path skips implementation-style outcome review, keeps its workspace write guard, and requires **actual grep/search tool evidence** before completing the audit. If only file reads or an auxiliary command were observed, it automatically steers the Agent back to searching instead of marking the audit complete. The final answer must disclose which patterns/targets were checked and their matches or misses; a plan item being marked complete is not proof of coverage.

- A direct, safe `rg`, `grep`, `git grep`, or `findstr` command may execute within the read-only audit's usual tool permission gate. Shell chains, redirection, command substitution, ripgrep preprocessors, absolute and parent-traversing paths are rejected for this snapshot-free fast path. The read-only `grep` tool remains available and preferred for complex search patterns.
- A safe standalone `wc -l` file-count command is handled by a bounded Java reader, so Windows `cmd` does not need to have GNU `wc`. It operates only on relative workspace files, rejects symlinks and missing files, reports exact newline counts and never changes the workspace. It honors the configured command permission.
- Search exit code 1, with no filesystem or command error, is a valid **no matches** finding. Exit code 2, invalid command, missing path, test/build failure, and genuine permission errors remain errors; none is silently converted to a passing verifier.
- A blocked/failed Agent now displays plan-step counts as **bookkeeping**, alongside a clear **outcome not verified** status. The final narrative includes the last unresolved tool command and exit evidence, without claiming it is necessarily the underlying cause.

### Offline verification and live acceptance

Run the dependency-free policy regression from the repository root with a Java JDK:

```bash
mkdir -p target/eliya-policy-smoke
javac -d target/eliya-policy-smoke src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java src/main/java/com/llmart/llm/service/{AgentPortableInspection,AgentReadOnlySearchPolicy,AgentUniversalOutcomeEvidence,AgentToolPalettePolicy,AgentPlanRelevance,AgentConversationIntent,AgentCompletionEvidence,McpPromptGate}.java qa/AuditReadOnlySmoke.java
java -cp target/eliya-policy-smoke com.llmart.llm.service.AuditReadOnlySmoke
node --test src/test/js/*.test.js qa/*.test.js
```

On Windows, build and run using `build-jar-windows.cmd` after Java and Maven dependencies are available. Linux/macOS uses `./mvnw -Pfull-tests clean verify`. These builds and live browser/model acceptance **must be performed in the target runtime**; passing the offline tests alone is not deployment certification.

For live acceptance, map a workspace containing real `Migration/prompt-*.md` files, run the grep-audit request above, and assert: (1) every expected pattern is extracted and searched against its actual target; (2) zero hits are reported as missing matches, not shell crashes; (3) missing files and command errors are reported precisely and retried only when safe; (4) no files are changed; (5) the run does not claim completion without actual grep evidence; (6) Cancel/Stop works during recovery; and (7) unrelated implementation tasks retain their stronger build/test and rollback gates.

## Agent task lifecycle, recovery and user-intent safeguards

The Agent executes the approved original request; an Analyse-to-Agent handoff is *not* permission to broaden its scope. The selected analysis source, message ID, workspace and current user refinements must remain tied together throughout the task.

**Sequence:** (1) accept and bind original request, selected Analyse source and attachments; (2) validate primary/reference workspace permissions and migration backup/preflight; (3) generate or load the exact approved plan; (4) create protected checkpoint; (5) execute one current plan step with evidence; (6) recover transient problems using safe alternatives and model fallback; (7) if an unchanged step repeatedly stalls, pause and ask for a same-scope decision; (8) verify files, tests, deliverables and completion contract; (9) give the requested answer before optional tool/activity details.

**Safe automatic recovery:** retry temporary provider errors when configured; repair a correctable command/path/tool usage failure using live evidence; select a portable read-only command rather than an unavailable shell utility; re-read stale file content; compact overly large model context; fail over to a configured model; rerun focused tests after a verified code fix. None of these operations grants new write, deletion or network permissions.

**When to ask the user:** if required information is genuinely missing, if source/target permissions or scope would change, if a destructive action needs approval, if a mandatory safe preflight cannot be completed, or if the same unchanged execution step exhausts the initial recovery approaches. Users can reply to the existing Agent question with `continue` (same intention and safeguards), `stop` (retain work and report the limitation), or `cancel`. The question does not authorize bypassing an approval, backup or verification rule. The Agent must not loop indefinitely while waiting for an impossible condition to improve.

### Source-observed failure and recovery matrix

| Stage | Potential blocker | Required behavior | Current source review |
|---|---|---|---|
| Analyse to Agent handoff | stale/missing message, truncated selected prompt, switched workspace | reject partial/foreign scope, request exact source if needed | Handoff validation and source fetch exist; offline handoff tests pass |
| Request/attachments | input or attachment unavailable | disclose missing input; ask rather than invent facts | Request validation exists; live attachment recovery not tested |
| Workspace selection | unreadable/unwritable root, alias mismatch | preserve selected paths and access scope; ask for correct permission | Workspace gate exists; large workspace integration not tested |
| Index/search | incomplete index or semantic provider unavailable | bounded lexical fallback with coverage disclosure; never pretend files were examined | Not end-to-end validated |
| Migration safety | missing ledger, backup, writable target or changed approved source | refuse unsafe edits, show actionable decision | Mandatory preflight remains enforced |
| Model/provider | wrong API key, rate limit, timeout, context exhaustion, missing tools | retry or fail over when possible; explain external configuration dependency | Retry/failover paths exist; live-provider behavior not tested |
| Planning | malformed/empty plan or invented scope | recover deterministically from original user request when safe; never approve partial source | Recovery policy exists; full planner E2E not tested |
| Implementation tool | OS-specific command, wrong file path, stale patch, nonzero exit | try compatible tool after inspecting real errors; retain failed execution evidence | Tool recovery paths exist; Windows live execution not tested |
| Recovery loop | repeated identical no-progress attempts on same step/revision | allow three focused recovery cycles, then ask to continue safely or stop | **New bounded user-decision escalation; Java/JS checks passed** |
| Approval | deletion or access needs consent, approval times out | do not auto-approve or bypass; ask/stop safely | Scoped approval protection exists; live modal E2E not tested |
| Long prompt/artifact | truncated generation, missing file or read-back | generate format-native file, confirm exact content, disclose incomplete output | Verification contracts exist; large-output E2E not tested |
| Verification | compilation/test failure, no focused tests or missing artifact evidence | repair in scope if possible; never mark verified with no evidence | Completion gates exist; live verification E2E not tested |
| Cancellation/session | browser disconnect, backend stop, process hangs | preserve run state, cancel worker/process, reject late completion | Backend stop smoke tests pass; Windows browser E2E not tested |
| Final response | plan done but actual question unanswered | show evidence-grounded answer first; keep detailed activity separately | Answer-first source verified; live model quality not tested |

### Recovery decision acceptance tests

The new gate is scoped to the **unchanged active plan step and workspace mutation revision**. After three consecutive focused recovery cycles without a step change or a recorded mutation, the next cycle pauses in the existing Agent chat question path. A new step or mutation resets the budget; the user can approve another bounded epoch. The Agent UI shows choices *Continue safely*, *Stop and keep current work*, and *Cancel*. The backend checks that the response is clear same-scope consent; arbitrary text is not treated as permission. Opting to stop preserves existing changes and reports incomplete status, not success.

Offline tests: `qa/agent-recovery-decision/run.sh`; `node --test src/test/js/*.test.js`; `qa/stop-lifecycle-smoke.sh`; `qa/eliya120-handoff/run.sh`; `qa/eliya121-handoff-hardening/run.sh`; `qa/eliya115-handoff-watchdog/run.sh`; `qa/outcome-review-smoke/run.sh`; `qa/eliya148-universal-outcome-smoke.sh`. Full Maven tests require installed Maven/dependencies, and Windows + live-model E2E is still mandatory before production release.

## Direct Agent submission: original-task preservation and recovery

These source corrections apply when a user submits a task **directly in Agent mode**, without first using Analyse. They do not remove mandatory permissions, independent verification or rollback safeguards.

- **Immediate durable run:** allocate the Agent run and record its original objective before expensive workspace/context preparation, so Stop and recovery status have a usable run ID.
- **Fresh vs resumed tasks:** a new direct submission starts with a clean task ledger; only an explicit, short request to resume previous interrupted work can inherit a same-conversation/same-project *large-task* ledger. A different selected project cannot inherit that ledger. Generic messages such as "continue" cannot inadvertently resume an unrelated interrupted run. Exact task disambiguation and ordinary non-large-task resume still require live acceptance and further work.
- **Inferred workspace scope:** when a prompt is allowed to supply an initial local workspace, bind that resolved project to the already-created run. Reject switching an active run to a different root; persist the binding for history and restart recovery.
- **Pre-execution errors:** model/context/workspace/preparation errors occurring after a run is created now attempt to save one actionable Agent answer in the conversation, even if the SSE connection drops. They remain failed/incomplete, not successful. If the message store is down, durable run history retains the final error message.
- **Exhausted model failover:** during planning, execution, and no-workspace external analysis, ELIYA asks whether to **Retry after fixing provider**, **Stop and keep current work**, or **Cancel**. Retrying does not change the original scope, configured model, tool permissions, or verification. A cancel racing with the question is rejected by the question bridge. If the provider is permanently unavailable, user action or a new run is unavoidable; this is not guaranteed automatic repair.
- **No false completion:** actual tool observations and independent verification remain authoritative. A completed plan is not proof of a completed task. The question-specific answer belongs in the conversation; activity metadata belongs in the execution monitor.

### Positive and negative coverage

The isolated Java direct-lifecycle smoke runs 37 assertions covering clean direct starts, explicit/implicit resume differentiation, cross-workspace isolation, restart persistence, inferred-project binding, recovery-question display, invalid responses, accepted retry, and cancellation. A separate source-contract check verifies 16 direct-path invariants. Existing Stop, recovery-decision, answer-first, handoff, outcome, and large-output tests remain in `qa`. Run all applicable offline checks using:

```bash
bash qa/direct-agent-lifecycle/run-all.sh
```

**Certification gap:** These checks do not prove a successful end-to-end Agent implementation in a real Windows JAR or live model environment. A full Maven build and browser/provider execution are still unverified here because Maven is not installed and its download endpoint cannot be resolved. Run `mvnw.cmd -Pfull-tests clean verify` in the intended Windows environment. Then validate direct submission (simple coding task, read-only question, prompt or HTML artifact, full migration), provider outage during planning and execution, approval/refusal, snapshot exhaustion, stop at each stage, resumed long task, verification failure and repair, and final answer/artifact persistence before replacing the running application.

For safety: a failed rollback baseline, invalid workspace access, unapproved destructive operation, or missing required source must **never** be bypassed under an instruction to “never stop.” ELIYA must give a concrete reason and a safe action, pause for required input, and never claim an unverified result.
