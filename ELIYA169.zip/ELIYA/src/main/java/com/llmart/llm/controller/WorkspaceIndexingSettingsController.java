package com.llmart.llm.controller;

import com.llmart.llm.service.WorkspaceIndexingSettings;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;

/** Local-only settings. API is bound to loopback by application.properties. */
@RestController
@RequestMapping("/api/settings/indexing")
public class WorkspaceIndexingSettingsController {
    private final WorkspaceIndexingSettings settings;
    private final com.llmart.llm.service.LocalProjectIndexService jobs;
    public WorkspaceIndexingSettingsController(WorkspaceIndexingSettings settings,
                                               com.llmart.llm.service.LocalProjectIndexService jobs) {
        this.settings = settings;
        this.jobs = jobs;
    }
    @GetMapping public WorkspaceIndexingSettings.Limits get() { return settings.current(); }
    @PutMapping public WorkspaceIndexingSettings.Limits save(@RequestBody WorkspaceIndexingSettings.Limits values) throws IOException {
        var before = settings.current();
        var saved = settings.save(values);
        if (WorkspaceIndexingSettings.indexFingerprint(before)
                != WorkspaceIndexingSettings.indexFingerprint(saved)) jobs.rebuildTrackedWorkspaces();
        return saved;
    }
}
