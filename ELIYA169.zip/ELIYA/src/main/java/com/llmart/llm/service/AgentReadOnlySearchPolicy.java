package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Negative search results are findings, not automatically failures. This policy applies
 * ONLY to explicit read-only grep audits, never tests, builds, edits, or shell chains.
 * No command is executed by the policy; the normal workspace/approval boundary remains.
 */
final class AgentReadOnlySearchPolicy {
    private static final Pattern SEARCH = Pattern.compile(
            "(?i)\\b(?:grep|greps|ripgrep|rg|findstr|search patterns?|search commands?)\\b");
    private static final Pattern REPORT = Pattern.compile(
            "(?i)\\b(?:report|which|missing|match(?:es|ing)?|compare|audit|check|verify|verification|identify|list|find)\\b");
    private static final Pattern CHANGES = Pattern.compile(
            "(?i)\\b(?:implement|fix|repair|modify|edit|delete|remove|create|generate|build|save|write|update|migrate|refactor|deploy|commit|push|patch|install)\\b");
    private static final Pattern COMMAND = Pattern.compile(
            "(?i)^\\s*(?:(?:git\\s+grep)|(?:rg|grep|findstr))\\s+\\S.*$");
    private static final Pattern NO_MATCH = Pattern.compile("(?i)^\\s*exitCode=1\\s*;");
    private static final Pattern COMMAND_ERROR = Pattern.compile(
            "(?i)(?:no such file or directory|access is denied|permission denied|" +
            "cannot find (?:the )?(?:path|file)|failed to open|not recognized as|command not found|" +
            "\\berror:|\\bIO error|\\bsyntax error|\\binvalid option|\\bunknown option)");

    private AgentReadOnlySearchPolicy() { }

    static boolean isAudit(String objective) {
        if (objective == null || objective.isBlank()) return false;
        return SEARCH.matcher(objective).find() && REPORT.matcher(objective).find() &&
                !CHANGES.matcher(objective).find();
    }

    /** Reject shell metacharacters, redirections, command substitution and chaining. */
    static boolean isSafeSearchCommand(String command) {
        if (command == null || !COMMAND.matcher(command).matches()) return false;
        if (command.contains("\n") || command.contains("\r") || command.contains("\t") ||
                command.contains("`") || command.contains("$(") || command.contains("${")) return false;
        for (char ch : command.toCharArray())
            if (ch == ';' || ch == '|' || ch == '&' || ch == '<' || ch == '>' ||
                    ch == '\n' || ch == '\r') return false;
        // Do not allow ripgrep preprocessors (which can execute arbitrary programs),
        // shell expansion or paths outside the mapped workspace in snapshot-free mode.
        String low = command.toLowerCase(Locale.ROOT);
        return !Pattern.compile("(?i)(?:^|\\s)--pre(?:=|\\s|$)").matcher(command).find() &&
                !Pattern.compile("(?:^|[\\s\"'])\\.\\.(?:[/\\\\]|[\\s\"']|$)").matcher(command).find() &&
                !Pattern.compile("(?:^|\\s)(?:~[/\\\\]|[a-zA-Z]:[/\\\\])").matcher(command).find() &&
                (low.startsWith("findstr ") || !Pattern.compile("(?:^|\\s)[/\\\\]").matcher(command).find()) &&
                !low.contains("powershell -") && !low.contains("cmd /c") &&
                !command.contains("%") && !command.contains("^") && !command.contains("!");
    }

    static boolean isNoMatch(String tool, String command, String output) {
        return "bash".equals(tool) && isSafeSearchCommand(command) && output != null &&
                NO_MATCH.matcher(output).find() && !COMMAND_ERROR.matcher(output).find();
    }
}
