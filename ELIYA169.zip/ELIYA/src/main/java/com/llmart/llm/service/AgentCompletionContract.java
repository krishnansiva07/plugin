package com.llmart.llm.service;

import java.util.regex.Pattern;

/** Evidence-only gate: a requested local deliverable cannot be called complete without a change.
 * Read-only questions and explicitly external/MCP tasks are excluded.
 */
final class AgentCompletionContract {
    private static final Pattern LOCAL_DELIVERABLE = Pattern.compile(
        "(?is)\\b(?:create|generate|implement|modify|refactor|rewrite|fix|add|update|delete|remove)\\b" +
        ".{0,120}\\b(?:file|folder|directory|class|method|framework|script|feature|test|module|endpoint|code|package|component|report|document|markdown)\\b");
    private AgentCompletionContract() { }
    static boolean requiresLocalEvidence(String objective) {
        if (objective == null || objective.isBlank()) return false;
        // A multi-prompt request saved to the workspace is a real local artifact contract.
        // It must not complete merely because the model described files it never wrote.
        if (AgentConversationIntent.promptFilesRequested(objective)) return true;
        if (AgentConversationIntent.isPromptGenerationRequest(objective)) return false;
        if (!LOCAL_DELIVERABLE.matcher(objective).find()) return false;
        // An external-only report is not a local deliverable. Mentioning an MCP source
        // does not excuse a requested local Java file or workspace test from verification.
        boolean explicitLocal = objective.matches("(?is).*\\b(?:local|workspace|project|file|folder|directory|class|code|framework|script|test|markdown)\\b.*");
        boolean external = objective.matches("(?is).*\\b(?:MCP|Jira|Confluence|ServiceNow|external service)\\b.*");
        return explicitLocal || !external;
    }
}
