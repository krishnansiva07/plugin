package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * User-visible answers are deliverables, not a side effect of execution bookkeeping.
 * Keep this policy deterministic: no model or filesystem access is needed to decide
 * whether a verified run still owes the user its requested analysis.
 */
final class AgentResultPresentation {
    private static final Pattern DEEP_ANALYSIS = Pattern.compile(
            "\\b(?:architecture|architectural|e2e|end.to.end|deep.search|deep.analysis|" +
            "data.flow|request.flow|execution.flow|working.principle|sequence.diagram|" +
            "component.diagram|dependency.flow|technical.flow|code.flow|system.design|" +
            "trace.the.flow|explain.the.flow)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern VERIFICATION = Pattern.compile(
            "(?i)\\b(?:check|verify|validation|validate|confirm|audit|assess)\\b.{0,125}" +
            "\\b(?:migrat(?:ion|ed|e)|framework|coverage|test|release|deployment|complete|success|correct)\\b");
    private static final Pattern VERDICT = Pattern.compile(
            "(?im)^\\s*(?:\\*\\*)?(?:verdict|verification status|result|outcome)(?:\\*\\*)?\\s*[:\\-]\\s*(?:\\*\\*)?\\s*" +
            "(?:verified|partially verified|not verified|inconclusive|complete|incomplete|passed|failed|blocked)\\b");
    private static final Pattern GENERIC = Pattern.compile(
            "(?i)^(?:agent run (?:completed|finished)|all approved plan steps completed|" +
            "the requested workspace changes completed|the approved task is complete|" +
            "verified task completed|external analysis completed|task completed|" +
            "execution completed|completed successfully|done\\.?|" +
            "i completed the requested workspace changes|i created \\d+ files? in the workspace)\\b");

    private AgentResultPresentation() { }

    static boolean isDeepAnalysis(String request) {
        return request != null && DEEP_ANALYSIS.matcher(request).find();
    }

    static boolean isVerificationRequest(String request) {
        return request != null && VERIFICATION.matcher(request).find();
    }

    static boolean needsVerificationResult(String request, String answer) {
        if (!isVerificationRequest(request)) return false;
        String value = answer == null ? "" : answer.strip();
        // A model's intention to inspect is not a completed validation result.
        return !VERDICT.matcher(value).find() || value.length() < 130 ||
                !Pattern.compile("(?i)\\b(?:evidence|inspected|source|file|tested|unverified|limitations?)\\b").matcher(value).find();
    }

    /** The final answer must be descriptive for an investigative prompt, irrespective of plan success. */
    static boolean needsAnalysisAnswer(String request, String answer) {
        if (!isDeepAnalysis(request)) return false;
        String text = answer == null ? "" : answer.strip();
        return text.isBlank() || GENERIC.matcher(text).find() ||
                (text.length() < 240 && !text.contains("\n") && !text.contains("`"));
    }

    /** Any inspected workspace question deserves a real answer, not a successful-run label.
     * Short factual results (including verified zero matches) are valid; only recover
     * empty, generic or obvious bookkeeping-only responses. Deep analysis requires depth.
     */
    /** Completed writes still owe a substantive answer, even for short commands like
     * "Launch Planner" or "Implement plan A" that do not say "analyse". Read-only
     * analysis is handled separately. This only requests presentation; it never
     * upgrades a blocked/failed run to completed.
     */
    static boolean needsArtifactAnswer(String answer, int actualChangedFiles) {
        return needsArtifactAnswer(answer, actualChangedFiles, false);
    }

    static boolean needsArtifactAnswer(String answer, int actualChangedFiles, boolean planningArtifacts) {
        if (actualChangedFiles <= 0) return false;
        if (!hasSubstantiveAnswer(answer)) return true;
        if (!planningArtifacts) return false;
        String text = answer.toLowerCase(Locale.ROOT);
        // A list of generated filenames is not a comparison or justified recommendation.
        return !(text.contains("plan") && (text.contains("compar") || text.contains("difference")) &&
                (text.contains("recommend") || text.contains("trade-off") || text.contains("tradeoff")) &&
                (text.contains("risk") || text.contains("evidence") || text.contains("limitation")));
    }

    /** Every test-execution task owes a useful test outcome, not a generic success label. */
    static boolean needsTestAnswer(String request, String answer) {
        if (request == null || !java.util.regex.Pattern.compile(
                "(?i)\\b(?:run|execute|rerun|perform|launch|start)\\b.{0,75}\\b(?:tests?|scenarios?|specs?)\\b|\\b(?:integration|unit|regression|smoke|e2e)\\s+tests?\\b")
                .matcher(request).find()) return false;
        if (!hasSubstantiveAnswer(answer)) return true;
        String lower = answer.toLowerCase(Locale.ROOT);
        return !(lower.contains("test") &&
                (lower.contains("pass") || lower.contains("fail") || lower.contains("unverified") || lower.contains("blocked")) &&
                (lower.contains("evidence") || lower.contains("runner") || lower.contains("command")) &&
                (lower.contains("remaining") || lower.contains("manual") || lower.contains("limitation") || lower.contains("next")));
    }

    static boolean needsInvestigationAnswer(String request, String answer, boolean readOnly) {
        if (needsAnalysisAnswer(request, answer) || needsVerificationResult(request, answer)) return true;
        if (!readOnly) return false;
        String text = answer == null ? "" : answer.strip();
        return text.isBlank() || GENERIC.matcher(text).find() ||
                (text.length() < 60 && !text.contains("`") && !text.contains("/"));
    }

    /**
     * ELIYA148: the need for a real outcome is driven by observed work, not the
     * literal words 'planner', 'integration test' or 'architecture'. A useful
     * final answer may be short for a single read-only command; change-making
     * workflows must explain the effect and the evidence/limitations.
     */
    static boolean needsUniversalOutcome(String answer, int changedFiles, int completedToolEvents) {
        if (changedFiles <= 0 && completedToolEvents <= 0) return false;
        String value = answer == null ? "" : answer.strip();
        if (!hasSubstantiveAnswer(value)) return changedFiles > 0 || completedToolEvents >= 2;
        String lower = value.toLowerCase(Locale.ROOT);
        boolean outcome = lower.contains("result") || lower.contains("completed") ||
                lower.contains("created") || lower.contains("updated") || lower.contains("changed") ||
                lower.contains("found") || lower.contains("implemented") || lower.contains("analysis") ||
                lower.contains("failed") || lower.contains("blocked");
        boolean basis = lower.contains("evidence") || lower.contains("verified") ||
                lower.contains("unverified") || lower.contains("tested") || lower.contains("runner") ||
                lower.contains("log") || lower.contains("source") || lower.contains("file");
        if (changedFiles > 0) return !(outcome && basis);
        return completedToolEvents >= 3 && !(outcome && basis);
    }

    /**
     * A question or read-only investigation is an answer deliverable. Plan status,
     * tool counts and a zero-change inventory are already available in the run UI.
     * Do not mistake a read-only search command ("run the greps") for a code edit.
     */
    static boolean isAnswerFirstQuery(String request, int changedFiles) {
        if (changedFiles != 0 || request == null || request.isBlank()) return false;
        String text = request.strip();
        boolean inquiry = Pattern.compile(
                "(?i)\\b(?:what|which|why|how|where|who|can you|could you|tell me|explain|" +
                "analys[ei]s?|analy[sz]e|review|investigate|inspect|verify|check|audit|" +
                "find|identify|compare|summari[sz]e|describe|trace|report)\\b")
                .matcher(text).find();
        boolean searchAudit = Pattern.compile(
                "(?i)\\b(?:run|execute|perform)\\b.{0,95}\\b(?:greps?|search(?:es)?|" +
                "read.only|inspection|audit|verification checks?|file checks?)\\b")
                .matcher(text).find();
        if (!inquiry && !searchAudit) return false;
        // A code modification, generated file, or test execution is an operation,
        // not an answer-only request, even if it also mentions analysis.
        boolean action = Pattern.compile(
                "(?i)\\b(?:implement|fix|repair|patch|modify|edit|delete|remove|" +
                "refactor|migrate|deploy|commit|push|create|generate|write|save|" +
                "build|compile|(?:run|execute|rerun|perform)\\s+" +
                "(?:(?:the|all|relevant|integration|unit|smoke|e2e|regression)\\s+){0,4}tests?)\\b")
                .matcher(text).find();
        return !action;
    }

    /** Never make the user read execution bookkeeping to locate the answer. */
    static String answerFirst(String prior, String status, String verification) {
        String answer = prior == null ? "" : prior.strip();
        String state = status == null ? "unknown" : status.toLowerCase(Locale.ROOT);
        boolean useful = !answer.isBlank() && !GENERIC.matcher(answer).find() &&
                !answer.matches("(?is)^(?:task|agent run|analysis)\\s+(?:blocked|failed|completed|finished)[.! ]*$") &&
                !answer.startsWith("## Outcome:") && !answer.startsWith("### Independent execution evidence");
        if (!useful) {
            String detail = verification == null ? "" : verification.strip();
            return "**Answer not established.** I could not obtain sufficient source evidence to answer " +
                    "this question reliably. No missing matches, successful tests, or completed " +
                    "checks can be inferred from the run status." +
                    (detail.isBlank() ? "" : "\n\n**Recorded limitation:** " +
                            detail.replaceAll("[\\r\\n]+", " ").strip());
        }
        // A complete read-only answer does not need an appended report or suggestion.
        if ("completed".equals(state)) return answer;
        // Preserve findings, then be candid about the outstanding verification.
        if (Pattern.compile("(?i)(?:not fully verified|not independently verified|" +
                "verification incomplete|partial(?:ly)? verified|coverage limitation)")
                .matcher(answer).find()) return answer;
        String detail = verification == null ? "" : verification.strip();
        String note = "**Coverage limitation:** The available findings above are not " +
                "fully verified; the run ended " + state + ".";
        if (!detail.isBlank()) note += " " + detail.replaceAll("[\\r\\n]+", " ").strip();
        return answer + "\n\n" + note;
    }

    /** A missing-evidence fallback is not proof of a successfully delivered analysis. */
    static boolean isUnfulfilledAnalysis(String answer) {
        if (answer == null) return true;
        String text = answer.strip();
        return text.isBlank() ||
                text.startsWith("The investigation finished without a substantive") ||
                text.startsWith("## Investigation result\n\nThe investigation completed, but Eliya could not");
    }

    /** Don't replace a useful model-produced explanation with a generated success template. */
    static boolean hasSubstantiveAnswer(String answer) {
        if (answer == null) return false;
        String text = answer.strip();
        if (text.length() < 100 || GENERIC.matcher(text).find()) return false;
        return text.contains("\n") || text.contains("`") || text.contains("**");
    }

    static String addFileReport(String answer, String fileSummary) {
        if (fileSummary == null || fileSummary.isBlank()) return answer == null ? "" : answer;
        if (!hasSubstantiveAnswer(answer)) return fileSummary;
        String summary = fileSummary.strip();
        // File reports are evidence, not permission to append a generic question.
        summary = summary.replaceFirst("(?is)\\s*Do you want to add anything\\?\\s*$", "");
        return answer.strip() + "\n\n---\n\n### Files and verification\n\n" + summary;
    }

    static String analysisSynthesisFallback(String previous, String evidence) {
        if (hasSubstantiveAnswer(previous)) return previous.strip();
        String trace = evidence == null ? "" : evidence.strip();
        if (!trace.isBlank()) {
            return "## Investigation result\n\nThe investigation completed, but Eliya could not " +
                    "produce a fully grounded architecture explanation from the recorded evidence. " +
                    "These are the available observations (not a verified end-to-end flow):\n\n" + trace;
        }
        return "The investigation finished without a substantive architecture answer or " +
                "accessible source evidence. I can't confirm the end-to-end flow from this run. " +
                "No implementation changes were inferred from that result.";
    }
}
