package com.llmart.llm.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.regex.Pattern;

/**
 * A platform-independent, strictly read-only fallback for the common shell `wc -l`
 * inspection. It runs inside Java, requires simple relative workspace paths, follows
 * no symlinks, and never executes a shell command or touches another workspace.
 */
final class AgentPortableInspection {
    private static final Pattern LINE_COUNT = Pattern.compile("(?i)^\\s*wc\\s+-l\\s+[\\w./\\\\-]+(?:\\s+[\\w./\\\\-]+)*\\s*$");
    private static final int MAX_FILES = 128;
    private static final long MAX_FILE_BYTES = 100_000_000L;

    private AgentPortableInspection() { }

    static boolean supports(String command) {
        if (command == null || !LINE_COUNT.matcher(command).matches()) return false;
        String[] parts = command.strip().split("\\s+");
        if (parts.length < 3 || parts.length > MAX_FILES + 2) return false;
        for (int i = 2; i < parts.length; i++) {
            String name = parts[i].replace('\\', '/');
            if (name.isBlank() || name.startsWith("/") || name.contains(":") || name.contains("//") ||
                    name.equals(".") || name.equals("..") || name.startsWith("../") ||
                    name.contains("/../") || name.endsWith("/..") || name.contains("%") || name.contains("$"))
                return false;
        }
        return true;
    }

    /** Returns null if not a recognized safe command; otherwise a normal tool-style receipt. */
    static String execute(Path workspaceRoot, String command) {
        if (!supports(command)) return null;
        if (workspaceRoot == null) return "exitCode=1; output=Portable line count: workspace not mapped; workspaceChanged=false";
        StringBuilder text = new StringBuilder();
        long total = 0;
        int errors = 0;
        try {
            Path root = workspaceRoot.toRealPath();
            String[] parts = command.strip().split("\\s+");
            for (int i = 2; i < parts.length; i++) {
                String name = parts[i].replace('\\', '/');
                Path file = root.resolve(name).normalize();
                try {
                    if (!file.startsWith(root) || !Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) ||
                            !file.toRealPath().startsWith(root) || Files.size(file) > MAX_FILE_BYTES) {
                        errors++;
                        text.append("INVALID OR UNREADABLE: ").append(name).append('\n');
                        continue;
                    }
                    long lines = 0;
                    try (InputStream in = Files.newInputStream(file)) {
                        byte[] buffer = new byte[8192];
                        int read;
                        while ((read = in.read(buffer)) >= 0) {
                            if (Thread.currentThread().isInterrupted()) throw new IOException("Interrupted");
                            for (int b = 0; b < read; b++) if (buffer[b] == (byte)'\n') lines++;
                        }
                    }
                    text.append(lines).append(' ').append(name).append('\n');
                    total += lines;
                } catch (IOException fileError) {
                    errors++;
                    text.append("READ ERROR: ").append(name).append(" (unavailable)\n");
                }
            }
            if (parts.length > 3) text.append(total).append(" total\n");
        } catch (IOException rootError) {
            return "exitCode=1; output=Portable line count: workspace unavailable; workspaceChanged=false";
        }
        return "exitCode=" + (errors == 0 ? 0 : 1) +
                "; output=Portable read-only wc -l fallback (no shell required):\n" + text +
                "; workspaceChanged=false";
    }
}
