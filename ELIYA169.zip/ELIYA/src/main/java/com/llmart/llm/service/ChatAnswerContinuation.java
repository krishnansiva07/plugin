package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Model-output continuation for read-only Chat answers. Neither filesystem, MCP, nor Agent is invoked here.
 * General Chat answers continue on provider output-limit signals; long generated prompts
 * also require an explicit full-document completion marker before being deemed complete.
 * System properties allow immediate rollback if a gateway behaves unexpectedly.
 */
final class ChatAnswerContinuation {
    private static final int PREFIX_BUFFER = 512;
    private static final int RETAINED_TAIL = 8_000;

    static final String PROMPT_DONE = "<!-- ELIYA_PROMPT_COMPLETE -->";

    static boolean promptRequested(String request) {
        if (request == null) return false;
        String text = request.toLowerCase(java.util.Locale.ROOT);
        return text.matches("(?s).*(?:\\b(?:generate|create|write|draft|produce|prepare|give|provide|make|build)\\b.{0,650}\\bprompts?\\b|\\b(?:one|single|all-in-one)\\s+(?:[a-z-]+\\s+){0,5}prompt\\b).*"
                ) && !text.matches("(?s)^\\s*(?:review|check|run|fix|explain)\\b.*");
    }

    static List<Map<String,Object>> withPromptContract(List<Map<String,Object>> original) {
        ArrayList<Map<String,Object>> prepared = new ArrayList<>(original.size() + 1);
        int count = promptCount(original);
        String countScope = count > 0 ? "exactly " + count + " fully distinct, standalone sections headed ## Prompt 1 through ## Prompt " + count
                : "a requirements-driven number (at least 2) of fully distinct, standalone prompts headed ## Prompt 1, ## Prompt 2, etc.";
        prepared.add(Map.of("role", "system", "content",
                "The user requests an executable prompt deliverable, NOT a proposal to generate one later. " +
                "If the user requested multiple prompts, return " + countScope + ". Do NOT merge the sections " +
                "into a single prompt, and do not wrap all sections in a single code block. Each prompt " +
                "must repeat its own objective, source/target workspace roles, concrete tasks, constraints, " +
                "acceptance checks and verification; do not refer to 'same as above'. " +
                "Produce ALL requested instructions completely, " +
                "including the final verification and acceptance criteria. Only when the entire prompt " +
                "is finished, append the exact final line " + PROMPT_DONE +
                ". Do not write that final line while any requested section is incomplete. " +
                "Continue normally across token limits; never silently truncate. " +
                "If requested, include exactly one reusable prompt and keep one-time prompts distinct."));
        prepared.addAll(original);
        return prepared;
    }

    static int promptCount(List<Map<String,Object>> context) {
        if (context == null) return 1;
        for (int i = context.size()-1; i >= 0; i--) {
            Map<String,Object> row = context.get(i);
            if (!"user".equals(row.get("role"))) continue;
            int count = AgentConversationIntent.requestedPromptCount(String.valueOf(row.getOrDefault("content", "")));
            return count;
        }
        return 1;
    }

    static boolean hasPromptCompletion(String text) { return hasPromptCompletion(text, 1); }

    static boolean hasPromptCompletion(String text, int expected) {
        if (text == null || !text.stripTrailing().endsWith(PROMPT_DONE)) return false;
        if (expected == 1) return true;
        // A model may prematurely emit the completion marker after one combined
        // prompt. The count contract must be checked before accepting its finish.
        java.util.regex.Matcher heading = java.util.regex.Pattern.compile(
                "(?im)^\\s*(?:#{1,6}\\s+)?prompt\\s*#?\\s*(\\d{1,2})\\b[^\\n]*$").matcher(text);
        int next = 1;
        while (heading.find()) {
            if (Integer.parseInt(heading.group(1)) != next) return false;
            next++;
        }
        return expected == 0 ? next >= 3 : next == expected + 1;
    }

    static boolean enabled() {
        return !"false".equalsIgnoreCase(System.getProperty("eliya.chat.autoContinue.enabled", "true"));
    }

    static int maximumParts() {
        try {
            return Math.max(1, Math.min(20, Integer.parseInt(System.getProperty("eliya.chat.autoContinue.maxParts", "8"))));
        } catch (NumberFormatException ignored) { return 8; }
    }

    static List<Map<String,Object>> nextContext(List<Map<String,Object>> original, String generated) {
        // New list, never modify the original messages or change a user-provided request/source excerpt.
        ArrayList<Map<String,Object>> next = new ArrayList<>(original.size() + 2);
        for (Map<String,Object> message : original) next.add(new LinkedHashMap<>(message));
        String tail = generated == null ? "" : generated;
        if (tail.length() > RETAINED_TAIL) tail = tail.substring(tail.length() - RETAINED_TAIL);
        next.add(Map.of("role", "assistant", "content", tail));
        next.add(Map.of("role", "user", "content",
                "[ELIYA INTERNAL ANSWER CONTINUATION] Your previous reply was stopped by the model's " +
                "output-token limit, not by the user. Continue answering the ORIGINAL user request directly " +
                "from the last unfinished sentence. Do not restart, repeat sections, invent evidence or " +
                "change any requirement. Finish all remaining requested analysis, with caveats and source " +
                "paths intact. Only output the missing continuation; do not mention this internal message."));
        return next;
    }

    static void reportIncomplete(StringBuilder output, Consumer<String> onToken, String reason) {
        String message = "\n\n[ELIYA: response incomplete] " + reason;
        output.append(message);
        if (onToken != null) onToken.accept(message);
    }

    /** Delays only the first 512 characters of a continuation for bounded overlap removal. */
    static final class TokenMerger {
        private final StringBuilder answer;
        private final Consumer<String> onToken;
        private final boolean deduplicate;
        private final StringBuilder pending = new StringBuilder();
        private boolean prefixProcessed;

        TokenMerger(StringBuilder answer, Consumer<String> onToken, boolean deduplicate) {
            this.answer = answer;
            this.onToken = onToken;
            this.deduplicate = deduplicate;
            this.prefixProcessed = !deduplicate;
        }

        void accept(String token) {
            if (token == null || token.isEmpty()) return;
            if (prefixProcessed) { append(token); return; }
            pending.append(token);
            if (pending.length() >= PREFIX_BUFFER) flushPrefix();
        }

        void finish() { if (!prefixProcessed) flushPrefix(); }

        private void flushPrefix() {
            if (prefixProcessed) return;
            prefixProcessed = true;
            String prefix = pending.toString();
            pending.setLength(0);
            if (deduplicate) {
                int overlap = suffixPrefixOverlap(answer, prefix);
                prefix = prefix.substring(overlap);
            }
            append(prefix);
        }

        private void append(String value) {
            if (value.isEmpty()) return;
            answer.append(value);
            onToken.accept(value);
        }
    }

    static int suffixPrefixOverlap(CharSequence existing, CharSequence incoming) {
        int max = Math.min(Math.min(existing.length(), incoming.length()), PREFIX_BUFFER);
        // A handful of matching punctuation characters is normal across paragraphs and must not be stripped.
        for (int size = max; size >= 24; size--) {
            boolean matches = true;
            for (int j = 0; j < size; j++) {
                if (existing.charAt(existing.length() - size + j) != incoming.charAt(j)) {
                    matches = false;
                    break;
                }
            }
            if (matches) return size;
        }
        return 0;
    }

    private ChatAnswerContinuation() { }
}
