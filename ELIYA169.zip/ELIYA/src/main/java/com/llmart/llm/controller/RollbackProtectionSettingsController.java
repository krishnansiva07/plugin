package com.llmart.llm.controller;

import com.llmart.llm.service.RollbackProtectionSettings;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;

/** Local loopback settings endpoint; rollback limits never disable the protective baseline. */
@RestController
@RequestMapping("/api/settings/rollback")
public class RollbackProtectionSettingsController {
    private final RollbackProtectionSettings settings;
    public RollbackProtectionSettingsController(RollbackProtectionSettings settings) { this.settings = settings; }
    @GetMapping public RollbackProtectionSettings.Limits get() { return settings.current(); }
    @PutMapping public RollbackProtectionSettings.Limits save(@RequestBody RollbackProtectionSettings.Limits limits) throws IOException {
        return settings.save(limits);
    }
}
