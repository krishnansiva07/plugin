package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.ProxySelector;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * OpenCode 2 HTTP execution adapter. No OpenCode classes or OS-specific shell commands enter ELIYA's core.
 * Remote tool/model work is performed by OpenCode, not reimplemented in this service.
 * The adapter is opt-in, and the existing ELIYA executor remains available for rollback.
 *
 * OpenCode 2 contract: POST /api/session, POST /api/session/{id}/prompt,
 * GET /api/experimental/session/{id}/log?follow=true, POST /api/session/{id}/interrupt.
 */
@Service
public class OpenCodeExecutionService {
    private static final int MAX_EVENTS = 450, MAX_TURNS = 30, MAX_TEXT = 80_000;
    private final ObjectMapper mapper;
    // Private managed OpenCode process follows ELIYA Settings, never OpenCode's public default.
    private volatile OpenCodeUiProviderConfig activeUiProvider;
    private volatile String activeUiProviderJson;

    private final ProjectService projects;
    // Connect directly to the managed loopback server. Do not inherit proxy settings
    // from the desktop or corporate Java process. Pin HTTP/1.1 for this local API.
    private final HttpClient http = localHttpClient();
    private static HttpClient localHttpClient() {
        return HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
                .proxy(ProxySelector.of(null))
                .connectTimeout(Duration.ofSeconds(3)).build();
    }
    private final ExecutorService readers = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "eliya-opencode-event"); t.setDaemon(true); return t;
    });
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final ScheduledExecutorService processCleanup = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "eliya-opencode-process-cleanup"); t.setDaemon(true); return t;
    });
    private final AtomicLong processCleanupGeneration = new AtomicLong();
    // Startup probing and model-specific prewarming NEVER block Spring Boot/UI startup.
    private final ExecutorService prewarmExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "eliya-opencode-prewarm"); t.setDaemon(true); return t;
    });
    private volatile OpenCodeLocalRuntime.Command installedCommand;
    private volatile String installationState = "not-checked";
    private volatile String installationReason = "";
    private volatile String readinessState = "waiting-for-settings";
    private volatile String readinessReason = "OpenCode requires ELIYA Agent model settings";
    private volatile boolean modelVerified;

    private final Path store = Path.of(System.getProperty("eliya.opencode.sessionStore", "./data/opencode-sessions"))
            .toAbsolutePath().normalize();
    private volatile URI base;
    private volatile String authorization;
    private final String executable;
    private final boolean autoStart;
    private volatile int port;
    private final boolean enabled;
    private final boolean managedLocal;
    private final OpenCodeLocalRuntime localRuntime = new OpenCodeLocalRuntime();
    private volatile String connectionStatus = "not-started";
    private volatile Process managedProcess;
    private final Object startLock = new Object();

    public OpenCodeExecutionService(ObjectMapper mapper, ProjectService projects,
            @Value("${eliya.execution.engine:legacy}") String engine,
            @Value("${eliya.opencode.url:http://127.0.0.1:4096}") String url,
            @Value("${eliya.opencode.password:}") String password,
            @Value("${eliya.opencode.executable:opencode}") String executable,
            @Value("${eliya.opencode.auto-start:false}") boolean autoStart) {
        this.mapper = mapper;
        this.projects = projects;
        this.enabled = "opencode".equalsIgnoreCase(engine);
        URI parsed = URI.create(this.enabled ? url : "http://127.0.0.1:4096");
        String host = parsed.getHost();
        if (!"http".equals(parsed.getScheme()) || host == null || parsed.getUserInfo() != null ||
                parsed.getRawQuery() != null || parsed.getRawFragment() != null ||
                !Set.of("localhost", "127.0.0.1", "[::1]", "::1").contains(host.toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("OpenCode server must use loopback HTTP. Remote tool execution is disabled.");
        }
        this.port = parsed.getPort() < 0 ? 80 : parsed.getPort();
        this.base = URI.create("http://127.0.0.1:" + port);
        this.authorization = basicAuth(password);
        this.executable = executable;
        this.autoStart = autoStart;
        this.managedLocal = this.enabled && autoStart && (password == null || password.isBlank());
        try {
            Files.createDirectories(store);
            try (var files = Files.list(store)) {
                files.filter(p -> p.getFileName().toString().endsWith(".json")).limit(300).forEach(p -> {
                    try {
                        JsonNode obj = mapper.readTree(p.toFile());
                        String id = obj.path("id").asText();
                        String remote = obj.path("remoteId").asText();
                        if (!id.matches("oc-[0-9a-f-]{36}") || remote.isBlank()) return;
                        Session session = new Session(id, remote, obj.path("conversationId").asText(),
                                obj.path("projectId").asText(), obj.path("model").asText(),
                                obj.path("fullPrompt").asText());
                        String savedStatus = obj.path("status").asText("interrupted");
                        session.status = Set.of("completed", "failed", "cancelled").contains(savedStatus)
                                ? savedStatus : "interrupted"; // running tasks cannot be assumed complete after restart
                        session.createdAt = obj.path("createdAt").asText(session.createdAt);
                        session.startedAt = obj.path("startedAt").asText(session.createdAt);
                        session.finishedAt = obj.path("finishedAt").asText("");
                        session.lastPromptId = obj.path("lastPromptId").asText("");
                        session.turnCount = obj.path("turnCount").asInt(session.lastPromptId.isBlank() ? 0 : 1);
                        session.question = obj.path("question").isObject()
                                ? mapper.convertValue(obj.path("question"), Map.class) : Map.of();
                        session.updatedAt = obj.path("updatedAt").asText(Instant.now().toString());
                        session.retiredFromRescan = Boolean.parseBoolean(obj.path("retiredFromRescan").asText("false"));
                        session.referenceSignature = obj.path("referenceSignature").asText("");
                        session.referenceRoots = readStrings(obj.path("referenceRoots"));
                        session.writableReferenceRoots = readStrings(obj.path("writableReferenceRoots"));
                        session.referenceProjectIds = readStrings(obj.path("referenceProjectIds"));
                        if (obj.path("referenceProjectNames").isObject())
                            session.referenceProjectNames = mapper.convertValue(obj.path("referenceProjectNames"), Map.class);
                        if (obj.path("referenceProjectWriteAccess").isObject())
                            session.referenceProjectWriteAccess = mapper.convertValue(obj.path("referenceProjectWriteAccess"), Map.class);
                        if (obj.path("changeReport").isObject()) {
                            @SuppressWarnings("unchecked") Map<String,Object> persistedReport =
                                    mapper.convertValue(obj.path("changeReport"), Map.class);
                            session.changeReport = persistedReport;
                        }
                        if (obj.path("events").isArray()) for (JsonNode item : obj.path("events")) {
                            if (!item.isObject()) continue;
                            @SuppressWarnings("unchecked") Map<String,Object> historyEvent = mapper.convertValue(item, Map.class);
                            session.events.addLast(historyEvent);
                            if (session.events.size() > MAX_EVENTS) session.events.removeFirst();
                            session.sequence = Math.max(session.sequence, item.path("seq").asInt(0));
                        }
                        session.tokenLedger.restoreCalls(obj.path("usageCalls"));
                        session.tokenLedger.restoreAggregate(obj.path("usageAggregate"));
                        sessions.put(id, session);
                    } catch (Exception ignored) { /* corrupt history cannot disable the app */ }
                });
            }
        } catch (Exception ignored) { /* in-memory sessions still supported */ }
    }

    private static List<String> readStrings(JsonNode values) {
        List<String> result = new ArrayList<>();
        if (values.isArray()) for (JsonNode value : values) if (!value.asText("").isBlank()) result.add(value.asText());
        return List.copyOf(result);
    }

    private static String basicAuth(String password) {
        return "Basic " + Base64.getEncoder().encodeToString(
                ("opencode:" + (password == null ? "" : password)).getBytes(StandardCharsets.UTF_8));
    }

    // Being installed is not sufficient to use a model. The prewarm path checks
    // /api/info, /api/model/default and /api/model WITHOUT a paid model prompt.
    private volatile boolean executionProven;
    public boolean availableForAuto() {
        return enabled && (executionProven || modelVerified)
                && (!managedLocal || (managedProcess != null && managedProcess.isAlive()
                && "connected".equals(connectionStatus)));
    }

    public String automaticSelectionReason() {
        if (!enabled) return "OpenCode integration disabled";
        if (availableForAuto()) return "OpenCode ready with ELIYA's selected Agent model";
        return switch (readinessState) {
            case "unsupported" -> "OpenCode not supported on this system: " + installationReason;
            case "starting", "checking" -> "OpenCode initialization is in progress; ELIYA is available";
            case "waiting-for-settings" -> "Configure ELIYA Agent model settings to enable OpenCode";
            default -> "OpenCode not ready: " + readinessReason;
        };
    }

    /** Triggered after Spring Boot is ready. Only checks the executable, no model tokens. */
    public void initializeOnStartup() {
        if (!enabled || !autoStart) return;
        readinessState = "checking";
        prewarmExecutor.execute(() -> {
            try {
                discoverInstalledCommand();
                if ("checking".equals(readinessState)) readinessState = "waiting-for-settings";
            } catch (Exception e) {
                readinessState = "unsupported";
                readinessReason = installationReason;
            }
        });
    }

    /** UI calls this on first load and whenever the active Agent model changes.
     * No workspace is opened, no prompt sent, and no user request is blocked. */
    public Map<String,Object> prewarm(String baseUrl, String model, String key) {
        if (!enabled || !managedLocal) return Map.of("status", "unavailable",
                "reason", "A managed OpenCode runtime is not enabled");
        if (key == null || key.isBlank() || baseUrl == null || baseUrl.isBlank()
                || model == null || model.isBlank()) return Map.of("status", "waiting-for-settings");
        // Validate up front, but do not store credentials or log them in a request queue.
        new OpenCodeUiProviderConfig(baseUrl, model, key);
        readinessState = "starting";
        prewarmExecutor.execute(() -> {
            try {
                synchronized (startLock) {
                    prepareUiProvider(baseUrl, model, key, null);
                    ensureServer();
                    requireUiModel();
                    modelVerified = true;
                    readinessState = "ready";
                    readinessReason = "OpenCode is ready with the selected Agent model";
                }
            } catch (Exception e) {
                String safe = activeUiProvider == null ? safeError(e) : activeUiProvider.scrub(safeError(e));
                readinessState = "unsupported".equals(installationState) ? "unsupported" : "failed";
                readinessReason = safe;
            }
        });
        return Map.of("status", "starting");
    }

    private OpenCodeLocalRuntime.Command discoverInstalledCommand() throws IOException {
        OpenCodeLocalRuntime.Command ready = installedCommand;
        if (ready != null) return ready;
        synchronized (localRuntime) {
            if (installedCommand != null) return installedCommand;
            if ("unsupported".equals(installationState))
                throw new IOException(installationReason);
            installationState = "checking";
            try {
                installedCommand = localRuntime.findV2(executable);
                installationState = "supported";
                installationReason = "OpenCode executable detected";
                return installedCommand;
            } catch (IOException e) {
                installationState = "unsupported";
                installationReason = "OpenCode 2.2+ is required. Install or upgrade OpenCode to 2.2 or newer, then restart Eliya. Auto mode uses Eliya until then.";
                throw e;
            }
        }
    }

    public boolean enabled() { return enabled; }
    public boolean owns(String id) { return id != null && id.startsWith("oc-") && sessions.containsKey(id); }
    public Map<String,Object> engineInfo() {
        Map<String,Object> info = new LinkedHashMap<>();
        info.put("engine", enabled ? "opencode" : "legacy");
        info.put("platform", System.getProperty("os.name"));
        info.put("configured", enabled);
        info.put("installationStatus", installationState);
        info.put("requiredVersion", "2.2+");
        if (!localRuntime.detectedVersion().isBlank()) info.put("detectedVersion", localRuntime.detectedVersion());
        info.put("status", readinessState);
        if (!managedLocal && enabled) {
            try {
                requireVersion(request("GET", "/api/info", null));
                connectionStatus = "connected";
                readinessState = "ready";
            } catch (Exception e) {
                connectionStatus = "unavailable";
                readinessReason = safeError(e);
            }
        }
        info.put("connected", managedLocal
                ? managedProcess != null && managedProcess.isAlive() && "connected".equals(connectionStatus)
                : "connected".equals(connectionStatus));
        info.put("autoEligible", availableForAuto());
        info.put("autoReason", automaticSelectionReason());
        if (!enabled) return info;
        info.put("startupMode", managedLocal ? "background-prewarm" : "configured-service");
        info.put("modelSource", "ELIYA Settings");
        info.put("reason", "unsupported".equals(readinessState) ? installationReason : readinessReason);
        if (activeUiProvider != null) info.put("defaultModel", activeUiProvider.model());
        if (Boolean.TRUE.equals(info.get("connected"))) {
            info.put("endpoint", base.toString());
            info.put("connection", managedLocal ? "managed" : "external");
        }
        // Never call ensureServer or issue network requests from a UI status poll.
        return info;
    }

    /** We deliberately keep ELIYA's attachment/MCP workflow on its existing backend until mapped natively. */
    public boolean accepts(ChatRequest request) {
        return enabled && request != null && request.chatMode() == com.llmart.llm.dto.ChatMode.AGENT
                && (request.attachmentIds() == null || request.attachmentIds().isEmpty())
                && (request.message() == null || !request.message().toLowerCase(Locale.ROOT).matches("(?s).*\\bmcp\\b.*"));
    }

    private static void progress(java.util.function.Consumer<String> notice, String detail) {
        if (notice != null) notice.accept(detail);
    }

    private void ensureServer() throws Exception { ensureServer(null); }

    /** Bind a managed OpenCode runtime to the exact current UI settings before starting it. */
    private void prepareUiProvider(ChatRequest request, String apiKey,
            java.util.function.Consumer<String> notice) throws Exception {
        if (request == null || request.settings() == null)
            throw new IllegalArgumentException("ELIYA Settings are missing from the execution request");
        prepareUiProvider(request.settings().baseUrl(), request.settings().model(), apiKey, notice);
    }

    private void prepareUiProvider(String baseUrl, String model, String apiKey,
            java.util.function.Consumer<String> notice) throws Exception {
        OpenCodeUiProviderConfig target = new OpenCodeUiProviderConfig(baseUrl, model, apiKey);
        synchronized (startLock) {
            if (!managedLocal) {
                throw new IllegalStateException("ELIYA model handoff requires a managed local OpenCode server");
            }
            if (activeUiProvider == null || !activeUiProvider.fingerprint().equals(target.fingerprint())) {
                boolean busy = sessions.values().stream().anyMatch(OpenCodeExecutionService::stillOwnsActiveTask);
                if (busy && activeUiProvider != null) {
                    throw new IllegalStateException("ELIYA model settings changed while an OpenCode task is running. "
                            + "Finish or cancel existing tasks before switching settings.");
                }
                stopManagedProcess();
                activeUiProvider = target;
                activeUiProviderJson = mapper.writeValueAsString(target.config());
                executionProven = false;
                modelVerified = false;
                connectionStatus = "not-started";
                progress(notice, "Using ELIYA Settings: " + target.model() + " @ " + target.endpointHost());
            }
        }
    }

    private void requireUiModel() throws Exception {
        OpenCodeUiProviderConfig current = activeUiProvider;
        if (current == null) throw new IllegalStateException("ELIYA UI provider has not been configured");
        String actual = requireDefaultModel();
        // Compare provider + exact UI model ID; never confuse the old "agent" alias
        // with Model.Info.modelID (the upstream ID returned by OpenCode v2).
        // Fail closed: NEVER send an implementation prompt to an external/free model.
        if (!current.modelReference().equals(actual)) {
            throw new IllegalStateException("OpenCode ignored ELIYA's selected model: expected "
                    + current.modelReference() + " (" + current.model() + "), got " + actual
                    + ". No prompt was submitted. Confirm the OpenCode provider uses ELIYA Settings; "
                    + "the managed model key must match the UI Agent model ID.");
        }
        // Zero-token readiness check. The local server's /api/info 200 response
        // alone does not mean the selected model can perform agentic tool actions.
        JsonNode models = unwrap(request("GET", "/api/model", null));
        if (models.isArray()) for (JsonNode item : models) {
            String id = item.path("id").asText("");
            if (id.isBlank()) id = OpenCodeNetworkDiagnostics.modelName("",
                    item.path("providerID").asText(""), item.path("modelID").asText(""));
            if (!current.modelReference().equals(id)) continue;
            JsonNode tools = item.path("capabilities").path("tools");
            if ("false".equalsIgnoreCase(tools.asText("")))
                throw new IllegalStateException("OpenCode model " + id
                        + " declares tools unsupported. File migrations require tool calling; "
                        + "select a tools-capable model in ELIYA Settings or use Eliya.");
            break;
        }
        modelVerified = true;
        readinessState = "ready";
        readinessReason = "OpenCode Agent model verified";
    }

    private void ensureServer(java.util.function.Consumer<String> notice) throws Exception {
        if (managedLocal) {
            synchronized (startLock) {
                if (managedProcess != null && managedProcess.isAlive()) {
                    try { requireVersion(request("GET", "/api/info", null)); return; }
                    catch (Exception e) { stopManagedProcess(); }
                }
                // Always use a private process/port instead of accidentally taking over another
                // user's OpenCode server on 4096. The password never needs to be typed.
                if (activeUiProvider == null || activeUiProviderJson == null)
                    throw new IllegalStateException("OpenCode cannot start without ELIYA model settings");
                progress(notice, "Checking the installed OpenCode 2.2+ executable");
                OpenCodeLocalRuntime.Command installed = discoverInstalledCommand();
                Exception last = null;
                for (int retry=0;retry<2;retry++) {
                    port = localRuntime.availableLoopbackPort();
                    base = URI.create("http://127.0.0.1:" + port);
                    String generated = localRuntime.randomPassword();
                    authorization = basicAuth(generated);
                    progress(notice, "Starting authenticated local OpenCode server" + (retry > 0 ? " (retry)" : ""));
                    managedProcess = localRuntime.start(installed, port, generated,
                            activeUiProvider.processEnvironment(), activeUiProviderJson);
                    long readyDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(9);
                    for (int i=0;i<25 && System.nanoTime()<readyDeadline;i++) {
                        Thread.sleep(240);
                        if (i == 10) progress(notice, "Waiting for OpenCode server readiness");
                        try {
                            requireVersion(request("GET", "/api/info", null));
                            connectionStatus = "connected";
                            progress(notice, "OpenCode server authenticated and ready");
                            return;
                        } catch (Exception e) {
                            last = e;
                            if (!managedProcess.isAlive()) {
                                int exit = managedProcess.exitValue();
                                last = new IllegalStateException("OpenCode process exited during startup (code " + exit + ")", e);
                                break;
                            }
                        }
                    }
                    stopManagedProcess();
                }
                connectionStatus = "unavailable";
                readinessState = "failed";
                progress(notice, "OpenCode startup failed");
                throw new IllegalStateException("OpenCode 2.2+ failed to start its local API: " + safeError(last)
                        + ". Local OpenCode output: " + localRuntime.lastOutput()
                        + ". Check that 'opencode --version' works in the environment launching ELIYA", last);
            }
        }
        // Explicitly configured external server: preserve the ELIYA89 integration behavior.
        try { requireVersion(request("GET", "/api/info", null)); return; }
        catch (Exception e) { if (!autoStart) throw e; }
        synchronized (startLock) {
            try { requireVersion(request("GET", "/api/info", null)); return; }
            catch (Exception ignored) { /* optional manually configured server startup */ }
            if (managedProcess != null && managedProcess.isAlive())
                throw new IllegalStateException("OpenCode started but is not responding on " + base);
            String pass = configuredPassword();
            OpenCodeLocalRuntime.Command installed = discoverInstalledCommand();
            managedProcess = localRuntime.start(installed, port, pass);
            for (int i=0;i<35;i++) {
                Thread.sleep(200);
                try { requireVersion(request("GET", "/api/info", null)); return; }
                catch (Exception ignored) { if (!managedProcess.isAlive()) break; }
            }
            throw new IllegalStateException("OpenCode 2 could not start with the configured settings. "
                    + localRuntime.lastOutput());
        }
    }

    private void stopManagedProcess() {
        Process process = managedProcess;
        managedProcess = null;
        if (process == null) return;
        // Snapshot descendants BEFORE terminating the parent; otherwise children
        // are re-parented and Windows can retain handles to workspace directories.
        List<ProcessHandle> children = process.descendants().toList();
        try {
            for (ProcessHandle child : children) child.destroy();
            process.destroy();
            if (!process.waitFor(1200, TimeUnit.MILLISECONDS)) process.destroyForcibly();
            for (ProcessHandle child : children) if (child.isAlive()) child.destroyForcibly();
            if (System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")
                    && (process.isAlive() || children.stream().anyMatch(ProcessHandle::isAlive))) {
                // Only the exact PID of this JAR-owned child. Never taskkill by image
                // name: other OpenCode terminals must not be stopped.
                try {
                    Process killer = new ProcessBuilder("taskkill.exe", "/PID", Long.toString(process.pid()),
                            "/T", "/F").redirectOutput(ProcessBuilder.Redirect.DISCARD)
                            .redirectError(ProcessBuilder.Redirect.DISCARD).start();
                    if (!killer.waitFor(3, TimeUnit.SECONDS)) killer.destroyForcibly();
                } catch (Exception ignored) { /* provider process already gone */ }
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            for (ProcessHandle child : children) if (child.isAlive()) child.destroyForcibly();
            process.destroyForcibly();
        } catch (Exception ignored) {
            for (ProcessHandle child : children) if (child.isAlive()) child.destroyForcibly();
            process.destroyForcibly();
        }
    }

    private static boolean stillOwnsActiveTask(Session session) {
        return Set.of("queued", "running", "cancelling", "needs_input").contains(session.status)
                || ("stalled".equals(session.status) && !session.remoteVerifiedIdle);
    }

    /** A managed OpenCode server is a persistent process even after its prompt
     * finishes. On Windows it can hold filesystem watcher and shell handles, so
     * release the *JAR-owned* process after all its sessions become terminal.
     * An external, user-managed server is NEVER terminated. */
    private void releaseManagedProcessWhenIdle() {
        if (managedProcess == null) return;
        long generation = processCleanupGeneration.incrementAndGet();
        if (processCleanup.isShutdown()) return;
        try {
            processCleanup.schedule(() -> {
                synchronized (startLock) {
                    if (generation != processCleanupGeneration.get() || managedProcess == null) return;
                    if (sessions.values().stream().anyMatch(OpenCodeExecutionService::stillOwnsActiveTask)) return;
                    stopManagedProcess();
                    connectionStatus = "not-started";
                    modelVerified = false;
                    readinessState = "starting";
                    // Restart in the background with NO project session loaded. The old
                    // process and its directory handles are gone before next task.
                    if (managedLocal && activeUiProvider != null) {
                        prewarmExecutor.execute(() -> {
                            try {
                                synchronized (startLock) {
                                    if (generation != processCleanupGeneration.get()
                                            || sessions.values().stream().anyMatch(OpenCodeExecutionService::stillOwnsActiveTask)) return;
                                    ensureServer();
                                    requireUiModel();
                                    readinessState = "ready";
                                    readinessReason = "OpenCode reinitialized after workspace cleanup";
                                }
                            } catch (Exception e) {
                                readinessState = "failed";
                                readinessReason = activeUiProvider == null ? safeError(e)
                                        : activeUiProvider.scrub(safeError(e));
                            }
                        });
                    }
                }
            }, 2, TimeUnit.SECONDS);
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            // Application shutdown already owns process termination.
        }
    }

    /** Never kill an external OpenCode service or another tab's shared process. */
    private boolean stopOwnedProcessFor(Session requestingSession) {
        synchronized (startLock) {
            if (managedProcess == null) return false;
            boolean anotherTask = sessions.values().stream().anyMatch(other ->
                    other != requestingSession && stillOwnsActiveTask(other));
            if (anotherTask) return false;
            processCleanupGeneration.incrementAndGet();
            stopManagedProcess();
            connectionStatus = "stopped by user; private OpenCode process released";
            return true;
        }
    }

    private String configuredPassword() {
        // Only auto-start with a nonempty configured secret. Avoid launching an exposed unauthenticated executor.
        String raw = new String(Base64.getDecoder().decode(authorization.substring(6)), StandardCharsets.UTF_8);
        String pass = raw.substring("opencode:".length());
        if (pass.length() < 16) throw new IllegalStateException("Set ELIYA_OPENCODE_PASSWORD (16+ characters) before auto-starting OpenCode");
        return pass;
    }

    /** Read the effective OpenCode default only to VERIFY ELIYA's selected model.
     * A mismatched provider is a hard error before prompt admission. */
    private String requireDefaultModel() throws Exception {
        JsonNode model = unwrap(request("GET", "/api/model/default", null));
        if (model.isMissingNode() || "null".equals(model.toString()) ||
                (model.isObject() && model.path("id").asText("").isBlank()
                        && model.path("modelID").asText("").isBlank())) {
            throw new IllegalStateException("OpenCode 2 has no configured default model from ELIYA Settings. "
                    + "Check the managed OpenCode provider configuration or select Eliya");
        }
        // Show the *actual* selected provider, not ELIYA's separately configured LLM.
        String provider = model.path("providerID").asText(model.path("provider").asText(""));
        String modelID = model.path("modelID").asText("");
        String id = model.path("id").asText("");
        if (provider.isBlank() && model.path("provider").isObject())
            provider = model.path("provider").path("id").asText("");
        return OpenCodeNetworkDiagnostics.modelName(id, provider, modelID);
    }

    private static void requireVersion(JsonNode response) {
        JsonNode data = response.path("data").isMissingNode() ? response : response.path("data");
        String version = data.path("version").asText("");
        if (!OpenCodeLocalRuntime.isSupportedVersion(version))
            throw new IllegalStateException("OpenCode 2.2 or newer is required, found "
                    + (version.isBlank() ? "unknown version" : version) + ". Select Eliya or upgrade OpenCode.");
    }

    private JsonNode request(String method, String path, Object body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(base.resolve(path))
                .timeout(Duration.ofSeconds("/api/info".equals(path) ? 2 : "/api/model/default".equals(path) ? 6
                        : path.equals("/api/session/active") ? 4
                        : path.endsWith("/interrupt?resume=false") ? 6
                        : ("GET".equals(method) && path.startsWith("/api/session/")
                           && !path.contains("/message")) ? 6 : 30))
                .header("Authorization", authorization)
                .header("Accept", "application/json");
        if (body != null) b.header("Content-Type", "application/json");
        if ("GET".equals(method)) b.GET();
        else b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() :
                HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
        HttpRequest call = b.build();
        HttpResponse<String> result;
        try {
            result = http.send(call, HttpResponse.BodyHandlers.ofString());
        } catch (IOException closed) {
            // Java HttpClient can reuse a socket that OpenCode closed between health and
            // model checks. Retry read-only GET on a fresh connection; never automatically
            // retry POST because OpenCode may have accepted a mutating instruction.
            if (!"GET".equals(method)) throw new IOException(
                    "Connection ended during OpenCode " + method + " " + path
                    + "; task acceptance is unknown. Do not resubmit automatically.", closed);
            try {
                Thread.sleep(180);
                result = localHttpClient().send(call, HttpResponse.BodyHandlers.ofString());
            } catch (IOException again) {
                throw new IOException("OpenCode API " + path
                        + " closed the connection without an HTTP response (retried once). "
                        + "The OpenCode server may have crashed or restarted; use Eliya for the demo.", again);
            }
        }
        if (result.statusCode() >= 300 || result.statusCode() < 200) {
            String reason = "";
            try {
                JsonNode problem = mapper.readTree(result.body());
                JsonNode issue = problem.path("error").isObject() ? problem.path("error") : problem;
                reason = issue.path("data").path("message").asText(
                        issue.path("message").asText(issue.path("name").asText("")));
            } catch (Exception ignored) { /* HTTP status remains authoritative */ }
            throw new IllegalStateException("OpenCode HTTP " + result.statusCode() + " on " + path
                    + (reason.isBlank() ? "" : ": " + shortText(reason.replaceAll(
                    "(?i)(password|token|secret)=\\S+", "$1=[REDACTED]"), 250)));
        }
        if (result.body() == null || result.body().isBlank()) return mapper.createObjectNode();
        return mapper.readTree(result.body());
    }

    private static JsonNode unwrap(JsonNode result) { return result.has("data") ? result.path("data") : result; }
    private static String safeError(Exception e) {
        if (e == null) return "No response from the OpenCode server";
        String message = e.getClass().getSimpleName();
        if (e instanceof java.net.ConnectException) return "OpenCode 2 is not running on loopback";
        if (e instanceof java.net.http.HttpTimeoutException) return "OpenCode connection timed out";
        if (String.valueOf(e.getMessage()).contains("HTTP/1.1 header parser received no bytes"))
            return "OpenCode closed its HTTP connection before responding. Restart OpenCode or select Eliya; no execution was confirmed";
        return shortText(message + ": " + String.valueOf(e.getMessage())
                .replaceAll("(?i)(password|token|secret)=\\S+", "$1=[REDACTED]"), 700);
    }

    public Map<String,Object> launch(ChatRequest request, String handoff, String apiKey) {
        return launch(request, handoff, apiKey, null);
    }

    public Map<String,Object> launch(ChatRequest request, String handoff, String apiKey,
            java.util.function.Consumer<String> notice) {
        if (!accepts(request)) throw new IllegalArgumentException("This instruction requires the ELIYA execution engine");
        if (request.message() == null || request.message().isBlank()) throw new IllegalArgumentException("Instruction is required");
        if (request.projectId() == null || request.projectId().isBlank())
            throw new IllegalArgumentException("Choose a mapped workspace");
        try {
            long launchBeginNanos = System.nanoTime();
            var project = projects.require(request.projectId());
            if (!project.hasLocalPath()) throw new IllegalArgumentException("Local workspace required");
            Path root = Path.of(project.getLocalPath()).toRealPath();
            if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace is not a directory");
            // Atomic across concurrent tabs: no other tab may swap provider credentials
            // between model verification, session creation and prompt admission.
            synchronized (startLock) {
            prepareUiProvider(request, apiKey, notice);
            boolean alreadyWarm = managedLocal && modelVerified && managedProcess != null
                    && managedProcess.isAlive() && "connected".equals(connectionStatus);
            if (!alreadyWarm) ensureServer(notice);
            long serverReadyNanos = System.nanoTime();
            if (!alreadyWarm) {
                progress(notice, "Verifying OpenCode is using ELIYA's selected Agent model");
                requireUiModel();
            } else {
                progress(notice, "Using pre-initialized OpenCode; server and model already verified");
            }
            long modelVerifiedNanos = System.nanoTime();
            String selectedModel = activeUiProvider.model();
            progress(notice, "OpenCode model verified from ELIYA Settings: " + selectedModel);
            progress(notice, "Opening an OpenCode session for the selected workspace");
            // Enforce project-only access at OpenCode's tool boundary, not merely by prompt instruction.
            List<Map<String,String>> permissions = new ArrayList<>();
            permissions.add(rule("*", "*", "allow"));
            permissions.add(rule("external_directory", "*", "deny"));
            // V2 has no built-in `delete` permission action: file patch removal
            // is governed by `edit` and shell removals by `shell` permissions.
            // Ask for one-time operator confirmation for ordinary shell deletion;
            // never permanently deny every rm/del command (which prevented
            // explicit "delete this file" migration instructions from working).
            // Deliberately retain hard blocks on broad recursive cleanup and Git
            // history-destructive commands. The user sees the command in the
            // OpenCode permission question before deciding.
            for (String cmd : List.of("rm *", "rmdir *", "del *", "Remove-Item *"))
                permissions.add(rule("shell", cmd, "ask"));
            for (String cmd : List.of("rm -rf *", "rm -fr *", "rm -r /*", "rm -R /*",
                    "rmdir /s *", "del /s *", "Remove-Item * -Recurse*",
                    "git push *", "git reset --hard *", "git clean *", "sudo *"))
                permissions.add(rule("shell", cmd, "deny"));
            permissions.add(rule("*mcp*", "*", "deny")); // gate MCP tools without blocking unrelated underscore-named tools
            permissions.add(rule("opencode_list_mcp_resources", "*", "deny"));
            permissions.add(rule("opencode_read_mcp_resource", "*", "deny"));
            ReferenceAccess references = referenceAccess(request, root);
            permissions.addAll(references.permissions());
            JsonNode created = unwrap(request("POST", "/api/session", Map.of(
                    "title", shortText(request.message(), 90),
                    "agent", "build", // Execute must not inherit a user's read-only default Plan agent
                    "model", activeUiProvider.selectedModel(),
                    "location", Map.of("directory", root.toString()))));
            String remoteId = created.path("id").asText();
            if (!remoteId.matches("[A-Za-z0-9_-]{3,128}")) throw new IllegalStateException("Missing OpenCode session ID");
            // OpenCode must not silently substitute a read-only Plan agent for Execute.
            String selectedAgent = created.path("agent").asText("");
            if (!selectedAgent.isBlank() && !"build".equals(selectedAgent))
                throw new IllegalStateException("OpenCode selected agent '" + selectedAgent
                    + "' instead of executable 'build' agent. Check its workspace agent configuration.");
            // OpenCode v2 creates a session without an inline permissions field.
            // PATCH is the documented session-specific permission update endpoint;
            // apply it before model selection and BEFORE admitting any instruction.
            request("PATCH", "/api/session/" + remoteId, Map.of("permissions", permissions));
            // V2 switch-model endpoint establishes session identity independently of defaults.
            request("POST", "/api/session/" + remoteId + "/model",
                    Map.of("model", activeUiProvider.selectedModel()));
            String localId = "oc-" + UUID.randomUUID();
            Session session = new Session(localId, remoteId,
                    request.conversationId() == null ? UUID.randomUUID().toString() : request.conversationId(), request.projectId(),
                    selectedModel, request.message());
            session.referenceSignature = references.signature();
            session.referenceRoots = references.readableRoots();
            session.writableReferenceRoots = references.writableRoots();
            session.referenceProjectIds = references.ids();
            session.referenceProjectNames = references.names();
            session.referenceProjectWriteAccess = references.writeAccess();
            session.startupMs = TimeUnit.NANOSECONDS.toMillis(serverReadyNanos-launchBeginNanos);
            session.modelCheckMs = TimeUnit.NANOSECONDS.toMillis(modelVerifiedNanos-serverReadyNanos);
            session.sessionCreationMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-modelVerifiedNanos);
            sessions.put(localId, session);
            persist(session);
            progress(notice, "Submitting the instruction to OpenCode");
            String instruction = instructionWithHandoff(request.message(), handoff)
                    + references.promptGuidance();
            submit(session, instruction);
            return session.snapshot();
            }
        } catch (Exception e) {
            // A session-specific 4xx or tool error must not mark an otherwise live
            // OpenCode server as disconnected; health probes determine readiness.
            if (managedLocal && (managedProcess == null || !managedProcess.isAlive())) connectionStatus = "failed";
            throw new IllegalStateException("OpenCode launch failed: " + safeError(e)
                    + ". Select Eliya to continue safely; no new OpenCode task should be presumed completed.", e);
        }
    }

    private static String instructionWithHandoff(String instruction, String handoff) {
        if (handoff == null || handoff.isBlank()) return instruction
                + "\n\nWorkspace freshness rule: Treat prior Chat/Agent statements as history, not "
                + "proof of current files. Check live filesystem existence before reporting an artifact exists; "
                + "do not recreate deleted files unless explicitly requested.";
        return "Context from the preceding ELIYA analysis (for historical reference, NOT current filesystem evidence):\n" + handoff
                + "\n\nWorkspace freshness rule: Before claiming a prior generated file or folder still exists, "
                + "check it with a live filesystem operation. Deleted or moved paths are absent even when earlier "
                + "conversation messages or a previous OpenCode session mention them. Never recreate deleted artifacts "
                + "unless the CURRENT user explicitly asks.\n\nCurrent user instruction (authoritative):\n" + instruction;
    }

    /** Resolve reference paths afresh on every launch. A prompt alone cannot authorize
     * external-directory access: only explicitly selected, mapped local projects may. */
    private ReferenceAccess referenceAccess(ChatRequest request, Path primary) throws IOException {
        List<String> ids = new ArrayList<>();
        Map<String,String> names = new LinkedHashMap<>();
        Map<String,Boolean> writableFlags = new LinkedHashMap<>();
        List<String> readable = new ArrayList<>(), writable = new ArrayList<>();
        List<Map<String,String>> permissions = new ArrayList<>();
        StringBuilder guidance = new StringBuilder();
        Set<String> aliases = new HashSet<>();
        if (request.referenceProjectIds() != null) for (String id : request.referenceProjectIds().stream()
                .filter(Objects::nonNull).distinct().limit(5).toList()) {
            if (id.equals(request.projectId())) continue;
            projects.requireConversation(id, request.conversationId());
            var project = projects.require(id);
            if (!project.hasLocalPath()) throw new IllegalArgumentException("Reference must be a mapped local directory");
            Path reference = Path.of(project.getLocalPath()).toRealPath();
            if (!Files.isDirectory(reference)) throw new IllegalArgumentException("Reference folder unavailable: " + reference);
            if (reference.equals(primary)) continue;
            // Nested references are not allowed to expand access through the root.
            if (reference.startsWith(primary) || primary.startsWith(reference))
                throw new IllegalArgumentException("Reference and primary workspace must not overlap: " + reference);
            String alias = request.referenceProjectNames() == null ? null : request.referenceProjectNames().get(id);
            if (alias == null || alias.isBlank()) alias = "Reference" + (ids.size() + 1);
            if (!alias.matches("[A-Za-z][A-Za-z0-9_-]{0,39}") || alias.equalsIgnoreCase("workspace")
                    || !aliases.add(alias.toLowerCase(Locale.ROOT)))
                throw new IllegalArgumentException("Reference aliases must be unique simple names");
            boolean edit = request.referenceWritable(id);
            ids.add(id);names.put(id,alias);writableFlags.put(id,edit);
            readable.add(reference.toString());
            if (edit) writable.add(reference.toString());
            // External paths are denied by default. Narrowly authorize each selected root.
            // Rules are ordered: scoped allow overrides the earlier global external deny.
            String boundary = reference.toString().replace('\\', '/') + "/*";
            permissions.add(rule("external_directory", boundary, "allow"));
            permissions.add(rule("read", boundary, "allow"));
            permissions.add(rule("edit", boundary, edit ? "allow" : "deny"));
            guidance.append("\nReference [").append(alias).append("] (")
                    .append(edit ? "writable" : "read-only").append("): ").append(reference);
        }
        StringJoiner signature = new StringJoiner(";");
        for (String id : ids) signature.add(id + "=" + names.get(id) + ":" + writableFlags.get(id)
                + ":" + readable.get(ids.indexOf(id)));
        return new ReferenceAccess(signature.toString(), List.copyOf(ids), Map.copyOf(names),
                Map.copyOf(writableFlags), List.copyOf(readable), List.copyOf(writable),
                List.copyOf(permissions), guidance.length() == 0 ? "" :
                "\n\nSelected reference access (verified against ELIYA's mapped folders):" + guidance
                + "\nWrite only inside the primary workspace and explicitly writable references."
                + " Never modify a read-only reference. Confirm generated skill/agent files on disk.");
    }

    private record ReferenceAccess(String signature, List<String> ids, Map<String,String> names,
                                   Map<String,Boolean> writeAccess, List<String> readableRoots,
                                   List<String> writableRoots, List<Map<String,String>> permissions,
                                   String promptGuidance) { }

    private static Map<String,String> rule(String action, String resource, String effect) {
        return Map.of("action", action, "resource", resource, "effect", effect);
    }

    private void submit(Session session, String prompt) throws Exception {
        synchronized (session) {
            if (session.turnCount > 0 && Set.of("running", "queued", "needs_input").contains(session.status)) {
                throw new IllegalStateException("This OpenCode tab already has an active instruction. "
                        + "Open a separate Terminal tab for parallel work, or wait for this turn to finish. "
                        + "The running task has not been replaced or duplicated.");
            }
            processCleanupGeneration.incrementAndGet(); // a new turn supersedes any pending idle cleanup
            session.status = "running";
            session.remoteVerifiedIdle = false;
            session.startedAt = Instant.now().toString();
            session.finishedAt = "";
            session.changeReport = Map.of();
            session.currentPrompt = prompt;
            session.events.clear(); // displayed action counts/reports belong to the new turn only
            session.seenIds.clear(); // dedup belongs to the new turn; retained cursors are session-scoped
            session.question = Map.of();
            session.directoryBaseline = workspaceDirectories(session.projectId, session.writableReferenceRoots);
            session.referenceFileBaseline = referenceFileSnapshot(session.writableReferenceRoots);
            // Record the existing lifetime tokens BEFORE dispatch: later aggregate
            // snapshots can recover accurate per-task usage even when the provider
            // doesn't emit per-message counters on its event stream.
            JsonNode beforeTokens = mapper.createObjectNode();
            try {
                JsonNode metadata = unwrap(request("GET", "/api/session/" + session.remoteId, null));
                beforeTokens = metadata.path("tokens").isObject() ? metadata.path("tokens") : metadata.path("usage");
            }
            catch (Exception ignored) { /* individual assistant messages remain authoritative */ }
            session.tokenLedger.nextTask(beforeTokens, session.turnCount == 0);
            session.toolTraces.clear();
            session.lastToolActivityNanos = System.nanoTime();
            session.lastEvidenceNanos = System.nanoTime();
            session.lastWarningNanos = 0;
            session.lastPromptId = "";
            if (session.turnCount > 0) {
                session.startupMs=-1; session.modelCheckMs=-1; session.sessionCreationMs=-1;
            }
            session.promptAdmissionMs = -1;
            session.firstModelEventMs = -1;
            session.verificationMs = -1;
            session.admissionStartNanos = System.nanoTime();
            session.turnCount++;
            session.lastRemoteStatus = "Submitting prompt to OpenCode";
            session.answer = "";
            session.turns.addLast(Map.of("role", "user", "content", shortText(prompt, MAX_TEXT)));
            while (session.turns.size() > MAX_TURNS) session.turns.removeFirst();
            session.push("turn_start", Map.of("detail", "Submitting task to OpenCode"));
        }
        persist(session);
        try {
            JsonNode admission = unwrap(request("POST", "/api/session/" + session.remoteId + "/prompt", Map.of("text", prompt)));
            session.promptAdmissionMs = TimeUnit.NANOSECONDS.toMillis(
                    System.nanoTime()-session.admissionStartNanos);
            session.lastPromptId = admission.path("id").asText("");
            if (session.lastPromptId.isBlank())
                throw new IllegalStateException("OpenCode returned no admitted message ID; execution cannot be tracked safely");
            session.lastActivityNanos = System.nanoTime();
            session.lastRemoteStatus = "accepted; awaiting execution evidence";
            session.push("agent_step", Map.of("tool", "OpenCode", "step", "admission", "status", "success",
                    "detail", "OpenCode accepted the instruction and returned its message ID"));
            beginReader(session);
            beginLiveUsageReader(session);
            beginMonitor(session); // reconnect if a previous event stream closed while the tab was idle
        } catch (IOException unknownAcceptance) {
            // A dropped POST connection does NOT establish whether the remote server
            // admitted the prompt. Keep the session/remote ID recoverable and offer
            // interrupt, rather than letting a user accidentally duplicate edits.
            session.status = "stalled";
            executionProven = false;
            session.error = "OpenCode prompt acceptance is unknown because its HTTP connection closed. "
                    + "The remote process may be executing. Stop this OpenCode session before retrying. "
                    + safeError(unknownAcceptance);
            session.lastRemoteStatus = "Prompt acceptance unknown; remote interruption recommended";
            session.push("agent_step", Map.of("tool", "connection", "step", "admission", "status", "warning",
                    "detail", session.error));
            persist(session);
        } catch (Exception e) {
            session.status = "failed";
            executionProven = false;
            session.error = safeError(e);
            session.push("error", Map.of("detail", session.error));
            persist(session);
            throw e;
        }
    }
    public Map<String,Object> message(String id, ChatRequest request, String apiKey) {
        return message(id, request, apiKey, null);
    }

    public Map<String,Object> message(String id, ChatRequest request, String apiKey, String handoff) {
        Session session = require(id);
        if (request == null || request.message() == null || request.message().isBlank())
            throw new IllegalArgumentException("Message required");
        if (!Objects.equals(session.projectId, request.projectId()))
            throw new IllegalArgumentException("OpenCode session belongs to another workspace. Open a new tab.");
        if (!accepts(request)) throw new IllegalArgumentException("Use ELIYA Analyse or MCP workflow in a separate tab");
        try {
            Path root = Path.of(projects.require(session.projectId).getLocalPath()).toRealPath();
            ReferenceAccess nextReferences = referenceAccess(request, root);
            if (!Objects.equals(session.referenceSignature, nextReferences.signature())) {
                if (stillOwnsActiveTask(session))
                    throw new IllegalStateException("Cannot change reference write permissions while this session is running. Stop it first.");
                // Permissions are pinned per-session; new grants require a new session.
                return launch(request, handoff, apiKey);
            }
        } catch (IOException error) {
            throw new IllegalStateException("Reference access check failed: " + safeError(error), error);
        }
        OpenCodeUiProviderConfig requested = new OpenCodeUiProviderConfig(
                request.settings().baseUrl(), request.settings().model(), apiKey);
        try {
            synchronized (startLock) {
                if (activeUiProvider == null || !activeUiProvider.fingerprint().equals(requested.fingerprint())
                        || !session.model.equals(requested.model()))
                    throw new IllegalStateException("ELIYA model settings changed. Start a new OpenCode session with the new settings.");
                boolean alreadyWarm = managedLocal && modelVerified && managedProcess != null
                        && managedProcess.isAlive() && "connected".equals(connectionStatus);
                if (!alreadyWarm) {
                    ensureServer(null);
                    requireUiModel();
                }
                request("POST", "/api/session/" + session.remoteId + "/model",
                        Map.of("model", requested.selectedModel()));
                submit(session, instructionWithHandoff(request.message(), handoff)
                        + referenceAccess(request, Path.of(projects.require(session.projectId).getLocalPath()).toRealPath()).promptGuidance());
                return session.snapshot();
            }
        } catch (IllegalStateException e) { throw e; }
        catch (Exception e) { throw new IllegalStateException("Could not send instruction to OpenCode: " + safeError(e), e); }
    }

    /** Safe OpenCode undo: use provider's reversible file snapshot, never an LLM prompt.
     * Only the most recent finished turn can be reverted and only after verifying
     * its exact per-turn diff and local workspace state. No git reset/clean. */
    public Map<String,Object> rollbackPreview(String id) {
        Session s = require(id);
        if (!Set.of("completed", "failed").contains(s.status))
            throw new IllegalStateException("Finish or stop and verify the OpenCode execution before rollback (status: " + s.status + ")");
        if (s.lastPromptId == null || s.lastPromptId.isBlank())
            throw new IllegalStateException("This historical session has no saved prompt boundary. Automatic rollback is unsafe.");
        if (remoteState(s) != RemoteState.IDLE)
            throw new IllegalStateException("Cannot confirm OpenCode is idle. No files were changed; reconnect before rollback.");
        captureChangeReport(s);
        Map<String,Object> report = s.changeReport;
        if (!Boolean.TRUE.equals(report.get("filesVerified")) ||
                !Boolean.TRUE.equals(report.get("workspaceFilesVerified")))
            throw new IllegalStateException("Workspace changes could not be verified against OpenCode's last turn. No rollback was performed.");
        @SuppressWarnings("unchecked") List<Map<String,Object>> files =
                (List<Map<String,Object>>)report.getOrDefault("files", List.of());
        if (files.size() >= 100 && report.get("fileReportWarning") != null)
            throw new IllegalStateException("Diff contains over 100 files. Review the full diff before reverting.");
        return Map.of("available", !files.isEmpty(), "sessionId", s.id,
                "promptId", s.lastPromptId, "fileCount", files.size(), "files", files,
                "detail", files.isEmpty() ? "No file changes are recorded for the last OpenCode task" :
                        "Preview verified. Confirm to restore files from this task only.");
    }

    public Map<String,Object> rollback(String id, String confirmedPromptId) {
        Session s = require(id);
        synchronized (s) {
            Map<String,Object> preview = rollbackPreview(id);
            if (!Boolean.TRUE.equals(preview.get("available")))
                throw new IllegalStateException("The selected OpenCode task has no changes to undo.");
            if (confirmedPromptId == null || !confirmedPromptId.equals(s.lastPromptId))
                throw new IllegalStateException("Task changed after rollback preview; nothing was reverted.");
            try {
                // Provider-managed reversible snapshots preserve untracked and unrelated files.
                request("POST", "/api/session/" + s.remoteId + "/revert/stage",
                        Map.of("messageID", s.lastPromptId, "files", true));
                // Do not repeat a stage operation on an unknown HTTP outcome.
                request("POST", "/api/session/" + s.remoteId + "/revert/commit", null);
                s.status = "rolled_back";
                s.finishedAt = Instant.now().toString();
                s.lastRemoteStatus = "OpenCode reversible file rollback committed";
                s.push("agent_step", Map.of("tool", "rollback", "step", "revert", "status", "success",
                        "detail", "Restored changes for OpenCode prompt " + shortText(s.lastPromptId, 50)));
                s.changeReport = Map.of("status","rolled_back","rolledBack",true,
                        "files",preview.get("files"),"filesVerified",true,
                        "verification","OpenCode revert/stage and revert/commit acknowledged");
                persist(s);
                return s.snapshot();
            } catch (Exception failure) {
                s.push("agent_step", Map.of("tool","rollback","step","revert","status","warning",
                        "detail","Rollback was not confirmed. Inspect OpenCode's staged revert and workspace before another attempt."));
                persist(s);
                throw new IllegalStateException("OpenCode rollback was not confirmed: " + safeError(failure)
                        + ". Do not retry until the workspace/staged revert is inspected.", failure);
            }
        }
    }

    public Map<String,Object> cancel(String id) {
        Session s = require(id);
        if (Set.of("completed", "cancelled", "rolled_back").contains(s.status)) {
            releaseManagedProcessWhenIdle();
            return s.snapshot();
        }
        synchronized (s) {
            s.status = "cancelling";
            s.lastRemoteStatus = "Interrupting OpenCode and checking child-process exit";
            s.push("agent_step", Map.of("tool", "OpenCode", "step", "stop", "status", "running",
                    "detail", "Interrupt requested; checking that the remote task actually stops"));
        }
        try {
            request("POST", "/api/session/" + s.remoteId + "/interrupt?resume=false", null);
            RemoteState state = remoteState(s);
            for (int attempt=0; state == RemoteState.ACTIVE && attempt<4; attempt++) {
                Thread.sleep(350);
                state = remoteState(s);
            }
            boolean stopped = state == RemoteState.IDLE;
            s.remoteVerifiedIdle = stopped;
            // Stop is stronger than cancelling a prompt: if the dedicated server
            // still has a running child, release ONLY the JAR-owned process tree,
            // and ONLY when no other local OpenCode tab is active.
            if (!stopped) stopped = stopOwnedProcessFor(s);
            synchronized (s) {
                s.status = stopped ? "cancelled" : "stalled";
                s.finishedAt = stopped ? Instant.now().toString() : "";
                executionProven = false;
                s.lastRemoteStatus = stopped ? "OpenCode execution stopped; owned process handles released"
                        : "Stop not confirmed; another task may be active or OpenCode is externally managed";
                s.error = stopped ? "" : "OpenCode did not confirm idle. Its process may still hold workspace files. "
                        + "Stop the external OpenCode process before deleting the folder.";
                s.push(stopped ? "stopped" : "agent_step", stopped
                        ? Map.of("detail", s.lastRemoteStatus)
                        : Map.of("tool", "OpenCode", "step", "stop", "status", "warning", "detail", s.error));
            }
        } catch (Exception e) {
            // A timed-out interrupt may still have been accepted. When ELIYA
            // owns the *sole* active OpenCode process, end that process tree
            // rather than leaving Windows shell handles open indefinitely.
            boolean stopped = stopOwnedProcessFor(s);
            s.status = stopped ? "cancelled" : "stalled";
            s.finishedAt = stopped ? Instant.now().toString() : "";
            s.error = stopped ? "" : "OpenCode stop failed or is unverified: " + safeError(e);
            s.lastRemoteStatus = stopped ? "OpenCode-owned process tree stopped after interrupt error"
                    : s.error;
            s.push(stopped ? "stopped" : "agent_step", stopped
                    ? Map.of("detail", s.lastRemoteStatus)
                    : Map.of("tool", "OpenCode", "step", "stop", "status", "warning", "detail", s.error));
        }
        persist(s);
        if ("cancelled".equals(s.status)) releaseManagedProcessWhenIdle();
        return s.snapshot();
    }

    /** Independent remote-state reconciler. A quiet SSE stream is NOT a stalled task:
     * model calls can legitimately take minutes and the durable log can be unavailable.
     * Active sessions remain running until OpenCode reports a terminal event or the
     * session is confirmed idle with an attributable completed reply.
     */
    private void beginMonitor(Session s) {
        synchronized (s) {
            if (s.monitoring) return;
            s.monitoring = true;
        }
        readers.execute(() -> {
            final long inactiveSeconds = Math.max(20L, Long.getLong("eliya.opencode.stallSeconds", 90L));
            long lastCheckNanos = 0, lastNoticeNanos = 0, lastReconnectNanos = 0;
            long lastLogRecoveryNanos = 0, lastHistoryRecoveryNanos = 0;
            long lastLiveReconnectNanos = 0, lastUsageRecoveryNanos = 0;
            try {
                while (!Thread.currentThread().isInterrupted() && "running".equals(s.status)) {
                    Thread.sleep(2000);
                    if (!"running".equals(s.status)) break;
                    long now = System.nanoTime();
                    if (!s.reading && now-lastReconnectNanos >= TimeUnit.SECONDS.toNanos(12)) {
                        lastReconnectNanos = now;
                        beginReader(s); // transient disconnects must not permanently blind the UI
                    }
                    if (!s.liveUsageReading && now-lastLiveReconnectNanos >= TimeUnit.SECONDS.toNanos(12)) {
                        lastLiveReconnectNanos = now;
                        beginLiveUsageReader(s);
                    }
                    if (now-lastCheckNanos < TimeUnit.SECONDS.toNanos(5)) continue;
                    lastCheckNanos = now;
                    // This is a best-effort source of live tool events, NOT a success oracle.
                    // Stream-first operation: repeated durable-log reads on a healthy SSE
                    // connection can replay large history and compete with model/tools.
                    // If SSE is disconnected, retain fast 5-second recovery.
                    long recoveryInterval = s.reading ? 25L : 5L;
                    if (now-s.lastActivityNanos > TimeUnit.SECONDS.toNanos(recoveryInterval)
                            && now-lastLogRecoveryNanos >= TimeUnit.SECONDS.toNanos(recoveryInterval)) {
                        lastLogRecoveryNanos = now;
                        try { recoverLog(s); } catch (Exception ignored) { /* optional endpoint */ }
                    }
                    if (!"running".equals(s.status)) break;
                    RemoteState state = remoteState(s);
                    boolean currentTurnFinished = refreshRemoteUsageAndIdleProof(s);
                    // The durable log is not the live session usage stream. Reconcile
                    // projected assistant messages periodically so a lost volatile event
                    // never leaves the token counter blank for the whole run.
                    if (now-lastUsageRecoveryNanos >= TimeUnit.SECONDS.toNanos(12)
                            && !s.lastPromptId.isBlank()) {
                        lastUsageRecoveryNanos = now;
                        try { recoverUsageHistory(s); } catch (Exception ignored) { /* optional projection */ }
                    }
                    if (state != RemoteState.UNKNOWN || currentTurnFinished) s.lastRemoteContactNanos = now;
                    if (currentTurnFinished) state = RemoteState.IDLE;
                    s.remoteVerifiedIdle = state == RemoteState.IDLE;
                    if (state == RemoteState.ACTIVE) {
                        // OpenCode being "busy" is not evidence that the model or a tool
                        // progressed. Report that distinction; avoid fake 82%-complete
                        // heartbeats indefinitely concealing an upstream provider hang.
                        long quietSeconds = TimeUnit.NANOSECONDS.toSeconds(
                                Math.max(0, now - s.lastEvidenceNanos));
                        long warnSeconds = Math.max(15L, Long.getLong("eliya.opencode.noProgressWarnSeconds", 60L));
                        if (quietSeconds >= warnSeconds && now - s.lastWarningNanos >= TimeUnit.SECONDS.toNanos(30)) {
                            s.lastWarningNanos = now;
                            s.lastRemoteStatus = "OpenCode busy, but no verified model/tool progress for "
                                    + quietSeconds + "s; possible provider, proxy or unanswered permission wait";
                            s.push("agent_step", Map.of("tool", "watchdog", "step", "no-progress",
                                    "status", "warning", "detail", s.lastRemoteStatus));
                        }
                        // A bounded default prevents a fully silent process retaining
                        // workspace handles forever. Teams running exceptionally long
                        // single model calls can raise this property in the JAR.
                        long cutoff = Long.getLong("eliya.opencode.noProgressTimeoutSeconds", 0L);
                        // Disabled by default: a long gateway inference, build or migration
                        // is not a failure while OpenCode still reports the session ACTIVE.
                        // Operators can configure a positive hard timeout if required.
                        if (cutoff > 0 && quietSeconds >= cutoff) {
                            // Before touching the execution, consult the projected
                            // tool history: SSE delivery may be broken even while a
                            // real command is progressing. Never cancel on missing
                            // SSE alone if history contains fresh tool evidence.
                            try { recoverMessages(s); } catch (Exception ignored) { /* optional projection */ }
                            quietSeconds = TimeUnit.NANOSECONDS.toSeconds(
                                    Math.max(0,System.nanoTime() - s.lastEvidenceNanos));
                            if (quietSeconds >= cutoff && "running".equals(s.status)) {
                                s.push("agent_step", Map.of("tool", "watchdog", "step", "timeout",
                                        "status", "warning", "detail", "No verified model/tool progress for "
                                        + quietSeconds + "s. Requesting OpenCode interruption; partial changes are not marked complete."));
                                cancel(s.id);
                                synchronized (s) {
                                    s.error = "No verified model/tool progress for " + quietSeconds
                                            + "s; ELIYA requested an interrupt. Partial workspace edits may exist. "
                                            + ("cancelled".equals(s.status)
                                            ? "OpenCode confirmed idle; execution is not complete."
                                            : "Remote stop remains unverified; do not delete the workspace until the process exits.");
                                    s.lastRemoteStatus = s.error;
                                    s.push("agent_step", Map.of("tool", "watchdog", "step", "timeout",
                                            "status", "cancelled".equals(s.status) ? "warning" : "error",
                                            "detail", s.error));
                                }
                                persist(s);
                                break;
                            }
                        }
                        // Even a busy OpenCode task may expose tools in projected message history
                        // while the experimental event stream remains silent.
                        // The event stream can carry step/heartbeat events but no tool
                        // details; recover message tool projections in that case too.
                        long toolRecoverySeconds = s.toolTraces.isEmpty() ? 8L : recoveryInterval;
                        if (now-s.lastToolActivityNanos > TimeUnit.SECONDS.toNanos(toolRecoverySeconds)
                                && now-lastHistoryRecoveryNanos >= TimeUnit.SECONDS.toNanos(toolRecoverySeconds)) {
                            lastHistoryRecoveryNanos = now;
                            try { recoverMessages(s); } catch (Exception ignored) { /* optional projection */ }
                        }
                        if (quietSeconds < warnSeconds) {
                            s.lastRemoteStatus = "OpenCode reports active; last verified progress " + quietSeconds + "s ago";
                        }
                        continue;
                    }
                    // If SSE was lost, reconcile actual assistant tool steps and answer.
                    if (now-s.lastActivityNanos > TimeUnit.SECONDS.toNanos(recoveryInterval)
                            && now-lastHistoryRecoveryNanos >= TimeUnit.SECONDS.toNanos(recoveryInterval)) {
                        lastHistoryRecoveryNanos = now;
                        try { recoverMessages(s); } catch (Exception ignored) { /* try again later */ }
                    }
                    if (!"running".equals(s.status)) break;
                    if (state != RemoteState.ACTIVE && reconcileRemoteOutcome(s)) break;
                    if (state == RemoteState.IDLE) {
                        reconcileCompletion(s);
                        if (!"running".equals(s.status)) break;
                    }
                    long quiet = now-s.lastActivityNanos;
                    if (state == RemoteState.IDLE && quiet >= TimeUnit.SECONDS.toNanos(inactiveSeconds)) {
                        // Distinguish a proven idle session with no assistant completion from
                        // an active or unreachable session. Do not pretend it succeeded.
                        String remoteError = remoteErrorForCurrentTurn(s);
                        synchronized (s) {
                            if (!"running".equals(s.status)) break;
                            s.status = "stalled";
                            executionProven = false;
                            s.error = remoteError.isBlank()
                                    ? "OpenCode is idle but no reply for the admitted instruction was found. "
                                      + "No tool work was confirmed. Check the selected OpenCode model/provider and "
                                      + "the session error log; do not assume the edits occurred. "
                                      + "Local server: " + shortText(localRuntime.lastOutput(), 220)
                                    : remoteError;
                            s.lastRemoteStatus = "OpenCode idle without verified completion";
                            s.push("agent_step", Map.of("tool", "OpenCode", "step", "watchdog", "status", "warning", "detail", s.error));
                        }
                        persist(s); break;
                    }
                    if (state == RemoteState.UNKNOWN) {
                        long disconnectSeconds = Math.max(45L, Long.getLong("eliya.opencode.disconnectSeconds", 90L));
                        if (now - s.lastRemoteContactNanos >= TimeUnit.SECONDS.toNanos(disconnectSeconds)) {
                            s.status = "stalled";
                            s.error = "OpenCode has been unreachable for " + disconnectSeconds + " seconds. "
                                    + "The remote task may still be executing; ELIYA will not resubmit it automatically. "
                                    + "Reconnect or interrupt the original session before retrying.";
                            s.lastRemoteStatus = "Connection lost; remote execution unverified";
                            s.push("agent_step", Map.of("tool", "connection", "step", "watchdog",
                                    "status", "warning", "detail", s.error));
                            persist(s);
                            break;
                        }
                        s.lastRemoteStatus = "OpenCode status temporarily unavailable; reconnecting without resubmission";
                        if (now-lastNoticeNanos >= TimeUnit.SECONDS.toNanos(20)) {
                            lastNoticeNanos = now;
                            s.push("agent_step", Map.of("tool", "connection", "status", "warning", "step", "reconnecting",
                                    "detail", "Could not confirm remote status; original task may still be running. No duplicate prompt sent."));
                        }
                    } else {
                        s.lastRemoteStatus = "OpenCode idle; checking message history for current prompt";
                    }
                }
            } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            finally {
                closeLiveUsageStream(s);
                s.monitoring = false;
                // A following turn can arrive while the previous monitor is exiting.
                // Never leave the new turn without its own reconciler.
                if ("running".equals(s.status) && !readers.isShutdown()) beginMonitor(s);
                else if (!stillOwnsActiveTask(s)) releaseManagedProcessWhenIdle();
            }
        });
    }

    /** Completion requires a reply tied to this specific user prompt, not merely an
     * execution.succeeded event replayed from an earlier turn. An implementation
     * request also requires independently observed file changes. */
    private void reconcileCompletion(Session s) {
        if (!"running".equals(s.status) || !remoteHasAssistant(s)) return;
        synchronized (s) {
            if (!"running".equals(s.status) || s.verificationInProgress) return;
            s.verificationInProgress = true;
            s.lastRemoteStatus = "Verifying OpenCode completion and workspace changes";
            s.finishTurn();
        }
        long verifyStartNanos = System.nanoTime();
        captureChangeReport(s);
        s.verificationMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-verifyStartNanos);
        boolean mutation = requestsFileChanges(s.currentPrompt);
        // OpenCode may expose only its active worktree diff. For an external writable
        // reference, independent bounded before/after on-disk evidence is sufficient
        // to verify that a requested migration actually changed a reference file.
        boolean verifiedProviderDiff = Boolean.TRUE.equals(s.changeReport.get("filesVerified"))
                && Boolean.TRUE.equals(s.changeReport.get("workspaceFilesVerified"));
        boolean verifiedReferenceEdits = Boolean.TRUE.equals(s.changeReport.get("referenceScanVerified"))
                && ((Number)s.changeReport.getOrDefault("referenceChangesVerified", 0)).intValue() > 0;
        int changes = ((Number)s.changeReport.getOrDefault("created", 0)).intValue()
                + ((Number)s.changeReport.getOrDefault("modified", 0)).intValue()
                + ((Number)s.changeReport.getOrDefault("deleted", 0)).intValue();
        boolean verifiedDirectoryChange = Boolean.TRUE.equals(s.changeReport.get("directoriesVerified"))
                && (((Number)s.changeReport.getOrDefault("createdDirectories",0)).intValue()
                    + ((Number)s.changeReport.getOrDefault("deletedDirectories",0)).intValue() > 0)
                && java.util.regex.Pattern.compile("(?i)\\b(folder|directory|mkdir|rmdir)\\b")
                       .matcher(s.currentPrompt).find();
        synchronized (s) {
            s.verificationInProgress = false;
            if (!"running".equals(s.status)) return;
            if (mutation && !((verifiedProviderDiff || verifiedReferenceEdits) && changes > 0)
                    && !verifiedDirectoryChange) {
                s.status = "stalled";
                executionProven = false;
                s.error = !verifiedProviderDiff && !verifiedReferenceEdits
                        ? "OpenCode returned a response, but neither its file diff nor reference-file changes "
                          + "could be verified. Inspect the workspace before retrying."
                        : "OpenCode returned a response without any observed changed files for a requested implementation. "
                          + "The requested edits are not verified; inspect its response and workspace.";
                s.lastRemoteStatus = "Implementation not verified";
                Map<String,Object> incompleteReport = new LinkedHashMap<>(s.changeReport);
                incompleteReport.put("status", "stalled");
                incompleteReport.put("verificationWarning", s.error);
                s.changeReport = incompleteReport;
                s.push("agent_step", Map.of("tool", "verification", "step", "file-evidence",
                        "status", "warning", "detail", s.error));
            } else {
                s.status = "completed";
                s.finishedAt = Instant.now().toString();
                s.lastRemoteStatus = "OpenCode response and workspace verification completed";
                executionProven = executionProven || verifiedDirectoryChange
                        || ((verifiedProviderDiff || verifiedReferenceEdits) && changes > 0)
                        || !((List<?>)s.changeReport.getOrDefault("steps", List.of())).isEmpty();
                s.push("done", Map.of("status", "completed", "detail", s.lastRemoteStatus));
                if (verifiedDirectoryChange) s.push("agent_step", Map.of("tool", "verification", "step", "directories",
                        "status", "success", "detail", "Verified workspace directory changes before and after execution"));
            }
            Map<String,Object> finalReport = new LinkedHashMap<>(s.changeReport);
            finalReport.put("status", s.status);
            s.changeReport = finalReport;
        }
        persist(s);
    }

    /** Validate empty-folder creation too: git-style file diffs do not list
     * directories. Scan directory names only, bounded in depth and count.
     * Do not follow symlinks or recurse through build/dependency caches. */
    private Set<String> workspaceDirectories(String projectId, List<String> referenceRoots) {
        try {
            Path primary = Path.of(projects.require(projectId).getLocalPath()).toRealPath();
            Set<String> directories = new HashSet<>();
            List<Path> roots = new ArrayList<>();
            roots.add(primary);
            for (String source : referenceRoots) roots.add(Path.of(source).toRealPath());
            Set<String> excluded = Set.of(".git", ".gradle", ".idea", ".next", ".venv",
                    "node_modules", "target", "build", "dist", "vendor", "__pycache__");
            for (int i = 0; i < roots.size(); i++) {
            Path root = roots.get(i);
            String prefix = i == 0 ? "workspace/" : "reference-" + i + "/";
            Files.walkFileTree(root, EnumSet.noneOf(FileVisitOption.class), 6, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path directory, java.nio.file.attribute.BasicFileAttributes attributes)
                        throws IOException {
                    if (directory.equals(root)) return FileVisitResult.CONTINUE;
                    if (excluded.contains(directory.getFileName().toString())) return FileVisitResult.SKIP_SUBTREE;
                    if (directories.size() >= 2500) throw new IOException("Directory verification limit reached");
                    directories.add(prefix + root.relativize(directory).toString().replace('\\','/'));
                    return FileVisitResult.CONTINUE;
                }
            });
            }
            return directories;
        } catch (Exception ignored) { return null; }
    }

    private static boolean requestsFileChanges(String prompt) {
        return prompt != null && java.util.regex.Pattern.compile(
                "(?i)\\b(implement|create|write|fix|update|modify|refactor|generate|add|remove|"
                + "migrate|repair|patch|build|develop|edit|integrate|install|replace)\\b")
                .matcher(prompt).find();
    }

    /** OpenCode v2 persists the terminal outcome on the session itself. An idle server
     * with zero streamed events is not enough information to diagnose a failed task. */
    private boolean reconcileRemoteOutcome(Session s) {
        if (!"running".equals(s.status)) return false;
        try {
            JsonNode remote = unwrap(request("GET", "/api/session/" + s.remoteId, null));
            String outcome = remote.path("outcome").asText("");
            if (!Set.of("failed", "interrupted").contains(outcome)) return false;
            // OpenCode may terminate before projecting an assistant message. Read its
            // durable log BEFORE finalizing, otherwise the browser sees a generic
            // provider error even when OpenCode recorded the actual failing request.
            String reason = remoteErrorForCurrentTurn(s);
            if (reason.isBlank()) {
                // Some OpenCode versions record the terminal provider exception on
                // the session itself, not as an assistant message or SSE error.
                for (String field : List.of("error", "failure", "lastError", "reason")) {
                    reason = failureDetail(remote.path(field));
                    if (!reason.isBlank()) break;
                }
            }
            if (reason.isBlank() && "failed".equals(outcome)) {
                try { recoverLog(s); } catch (Exception ignored) { /* log is experimental */ }
                // readEvent may already have extracted the failure and changed status.
                if ("failed".equals(s.status) && !s.error.isBlank()) {
                    persist(s);
                    return true;
                }
                reason = remoteErrorForCurrentTurn(s);
                if (reason.isBlank()) reason = failureFromDurableLog(s);
            }
            if (reason.isBlank()) {
                String processEvidence = localRuntime.lastOutput();
                String fallback = "failed".equals(outcome)
                        ? "OpenCode's session failed before it produced an assistant reply. "
                          + "The OpenCode provider or selected model may have rejected the request. "
                          + "Model: " + s.model + ". Check company gateway compatibility "
                          + "with streaming tool calls and OpenAI Chat Completions."
                        : "OpenCode interrupted the execution.";
                reason = fallback + ("failed".equals(outcome)
                        ? " Last OpenCode process output: " + shortText(processEvidence, 450) : "");
            }
            reason = scrubProviderSecrets(reason);
            synchronized (s) {
                if (!"running".equals(s.status)) return false;
                s.status = "failed".equals(outcome) ? "failed" : "cancelled";
                s.error = shortText(reason, 1100);
                s.lastRemoteStatus = "OpenCode session outcome: " + outcome;
                executionProven = false;
                s.push("error", Map.of("detail", s.error, "source", "OpenCode session outcome"));
            }
            persist(s);
            return true;
        } catch (Exception unavailable) {
            // This diagnostic is supplemental; a network error is not a failed run.
            return false;
        }
    }

    /** Parse the durable log as a read-only fallback when OpenCode writes no assistant
     * message and its SSE reader disconnected. Never infer task success from log text. */
    private String failureFromDurableLog(Session s) {
        try {
            HttpRequest req = HttpRequest.newBuilder(base.resolve(
                    "/api/experimental/session/" + s.remoteId + "/log?follow=false"))
                    .timeout(Duration.ofSeconds(4)).header("Authorization", authorization)
                    .header("Accept", "text/event-stream").GET().build();
            HttpResponse<String> response = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) return "";
            String type = "", candidate = "";
            StringBuilder data = new StringBuilder();
            for (String line : response.body().split("\\r?\\n", -1)) {
                if (line.isBlank()) {
                    String found = failureLogEvent(s, type, data.toString());
                    if (!found.isBlank()) candidate = found;
                    data.setLength(0); type = "";
                } else if (line.startsWith("event:")) type = line.substring(6).trim();
                else if (line.startsWith("data:") && data.length() < 400_000) {
                    if (!data.isEmpty()) data.append('\n');
                    data.append(line.substring(5).trim());
                }
            }
            String found = failureLogEvent(s, type, data.toString());
            return !found.isBlank() ? found : candidate;
        } catch (Exception ignored) { return ""; }
    }

    private String failureLogEvent(Session s, String eventType, String raw) {
        if (raw.isBlank()) return "";
        try {
            JsonNode outer = mapper.readTree(raw);
            if (outer.isTextual()) outer = mapper.readTree(outer.asText());
            JsonNode node = outer.path("properties").isObject() ? outer.path("properties") :
                    outer.path("data").isObject() ? outer.path("data") : outer;
            String type = outer.path("type").asText(outer.path("event").asText(eventType));
            if (node.path("event").isObject()) {
                JsonNode nested = node.path("event");
                type = nested.path("type").asText(type);
                node = nested.path("properties").isObject() ? nested.path("properties") : nested;
            }
            if (!type.endsWith("execution.failed") && !type.endsWith("session.error")) return "";
            String eventPrompt = node.path("promptID").asText(node.path("userMessageID").asText(""));
            if (s.turnCount > 1 && (eventPrompt.isBlank() || !eventPrompt.equals(s.lastPromptId))) return "";
            JsonNode error = node.path("error");
            String detail = failureDetail(error);
            if (detail.isBlank()) detail = node.path("message").asText("");
            return detail.isBlank() ? "" : scrubProviderSecrets("OpenCode provider/agent failure: " + detail);
        } catch (Exception ignored) { return ""; }
    }

    private static String failureDetail(JsonNode error) {
        if (error == null || "null".equals(error.toString()) || error.isMissingNode()) return "";
        if (error.isTextual()) return error.asText("");
        JsonNode data = error.path("data");
        // ProviderRequestError can contain HTTP status and the gateway's response
        // body without any data.message. The old decoder discarded that evidence.
        String status = data.path("statusCode").asText(
                data.path("status").asText(error.path("statusCode").asText("")));
        String response = data.path("responseBody").asText("");
        if (response.isBlank()) response = data.path("response").asText("");
        if (response.isBlank()) response = error.path("responseBody").asText("");
        if (response.isBlank() && data.path("body").isTextual()) response = data.path("body").asText("");
        if (!response.isBlank()) {
            return (status.isBlank() ? "OpenCode provider response: " : "Provider HTTP " + status + ": ")
                    + shortText(response, 650);
        }
        String detail = data.path("message").asText("");
        if (detail.isBlank()) detail = error.path("message").asText("");
        if (detail.isBlank()) detail = data.path("error").asText("");
        if (detail.isBlank()) detail = error.path("cause").path("message").asText("");
        if (detail.isBlank()) detail = error.path("details").path("message").asText("");
        if (detail.isBlank()) detail = error.path("name").asText(error.path("type").asText(""));
        return status.isBlank() ? detail : "Provider HTTP " + status + ": " + detail;
    }

    private String scrubProviderSecrets(String raw) {
        String result = raw == null ? "" : raw;
        OpenCodeUiProviderConfig config = activeUiProvider;
        if (config != null) {
            result = config.scrub(result);
        }
        return shortText(result.replaceAll("(?i)((?:bearer|basic)\\s+)[^\\s]+", "$1[REDACTED]")
                .replaceAll("(?i)(https?://)[^/@\\s]+:[^/@\\s]+@", "$1[REDACTED]@")
                .replaceAll("(?i)((?:password|token|apikey|api_key|secret)[=:\"\\s]+)[^\\s]+", "$1[REDACTED]"), 1100);
    }

    /** Show operator-safe command/file context without exposing provider credentials,
     * raw environment variables, or entire source files in activity telemetry. */
    private String safeToolInput(JsonNode value) {
        JsonNode input = value;
        if (value != null && value.isTextual()) {
            try { input = mapper.readTree(value.asText()); }
            catch (Exception ignored) { return scrubProviderSecrets(shortText(value.asText(), 900)); }
        }
        if (input == null || !input.isObject()) return "";
        Map<String,String> visible = new LinkedHashMap<>();
        // No unrestricted dumps of tool input: these can contain API keys or full files.
        for (String key : List.of("description", "command", "path", "filePath", "file_path",
                "pattern", "glob", "query", "url", "workingDirectory", "workdir")) {
            JsonNode field = input.path(key);
            if (field.isTextual() && !field.asText().isBlank())
                visible.put(key, scrubProviderSecrets(shortText(field.asText(), 900)));
        }
        return visible.isEmpty() ? "" : visible.toString();
    }

    private String safeToolOutput(JsonNode node) {
        StringBuilder output = new StringBuilder();
        JsonNode content = node.path("content");
        if (content.isArray()) {
            for (JsonNode item : content) {
                if (output.length() >= 1800) break;
                if (item.isTextual()) output.append(item.asText()).append('\n');
                else if ("text".equals(item.path("type").asText()))
                    output.append(item.path("text").asText()).append('\n');
            }
        }
        if (output.isEmpty()) {
            JsonNode value = node.path("output");
            if (value.isTextual()) output.append(value.asText());
            else if (value.path("text").isTextual()) output.append(value.path("text").asText());
        }
        return scrubProviderSecrets(shortText(output.toString(), 1800));
    }

    /** One stable action ID follows a real OpenCode tool from input -> running -> result.
     * The UI can update the same row as output arrives instead of displaying
     * anonymous lifecycle event names as fake terminal commands. */
    private void captureToolActivity(Session s, String type, JsonNode node) {
        String toolId = node.path("id").asText("");
        if (toolId.isBlank()) return;
        ToolTrace trace = s.toolTraces.computeIfAbsent(toolId, ignored -> new ToolTrace());
        if (type.endsWith("tool.input.started")) trace.name = node.path("name").asText(trace.name);
        if (type.endsWith("tool.input.ended")) trace.input = safeToolInput(node.path("text"));
        if (type.endsWith("tool.called")) {
            trace.input = safeToolInput(node.path("input"));
            if (trace.name.isBlank()) trace.name = node.path("input").path("name").asText("");
        }
        if (type.endsWith("tool.progress")) {
            String progressOutput = safeToolOutput(node.path("metadata"));
            if (!progressOutput.isBlank()) trace.output = progressOutput;
        }
        if (type.endsWith("tool.success")) trace.output = safeToolOutput(node);
        if (type.endsWith("tool.failed")) {
            String reason = failureDetail(node.path("error"));
            trace.output = scrubProviderSecrets(shortText(reason, 1400));
        }
        String status = type.endsWith("tool.failed") ? "error" : type.endsWith("tool.success") ? "success" : "running";
        // Input chunks are emitted only when complete, and high-frequency progress
        // updates must not stall agent execution or flood the browser.
        if (type.endsWith("tool.input.delta") || type.endsWith("tool.input.started")) return;
        long now = System.nanoTime();
        if (type.endsWith("tool.progress") && now - trace.lastProgressNanos < TimeUnit.SECONDS.toNanos(1)) return;
        if (type.endsWith("tool.progress")) trace.lastProgressNanos = now;
        Map<String,Object> step = new LinkedHashMap<>();
        step.put("actionId", shortText(toolId, 130));
        step.put("tool", shortText(trace.name.isBlank() ? "OpenCode tool" : trace.name, 80));
        step.put("step", "tool");step.put("status", status);
        step.put("detail", trace.input.isBlank() ? "OpenCode tool " + status : trace.input);
        if (!trace.input.isBlank()) step.put("args", trace.input);
        if (!trace.output.isBlank()) step.put("output", trace.output);
        s.push("agent_step", step);
        s.lastToolActivityNanos = now;
    }

    /** Read only this turn's assistant errors; never attribute a previous prompt's
     * provider failure to the current prompt. */
    private String remoteErrorForCurrentTurn(Session s) {
        try {
            TurnHistory history = historyForPrompt(s);
            if (!history.found()) return "";
            for (JsonNode message : history.messages()) {
                JsonNode meta = message.path("info").isObject() ? message.path("info") : message;
                if (!"assistant".equals(meta.path("type").asText(meta.path("role").asText()))) continue;
                JsonNode error = meta.path("error");
                if (!error.isMissingNode() && !"null".equals(error.toString())) {
                    String detail = error.path("data").path("message").asText(
                            error.path("message").asText(error.path("name").asText(
                            error.path("type").asText(error.asText("")))));
                    if (!detail.isBlank()) return scrubProviderSecrets("OpenCode provider/agent error: "
                            + OpenCodeNetworkDiagnostics.explain(detail, s.model, System.getenv()));
                }
                String finish = meta.path("finish").asText("");
                if ("error".equals(finish)) return "OpenCode finished the assistant turn with an error";
            }
        } catch (Exception ignored) { /* best-effort diagnostic; not a success signal */ }
        return "";
    }

    private boolean refreshRemoteUsageAndIdleProof(Session s) {
        try {
            JsonNode remote = unwrap(request("GET", "/api/session/" + s.remoteId, null));
            boolean usageChanged = s.tokenLedger.acceptSessionAggregate(remote.path("tokens").isObject()
                    ? remote.path("tokens") : remote.path("usage"));
            if (usageChanged) {
                s.lastEvidenceNanos = System.nanoTime();
                s.push("usage", Map.of("detail", "Provider token totals refreshed from OpenCode session"));
                persist(s);
            }
            JsonNode clock = remote.path("time");
            long idle = Long.parseLong(clock.path("idle").asText("0"));
            long busy = Long.parseLong(clock.path("busy").asText("0"));
            long started = Instant.parse(s.startedAt).toEpochMilli();
            // Proves this exact turn reached the idle boundary. A prior turn's
            // persisted "succeeded" outcome must never be misread as this one.
            return "succeeded".equals(remote.path("outcome").asText())
                    && idle >= started && busy >= started && idle >= busy;
        } catch (Exception ignored) { return false; }
    }

    private enum RemoteState { ACTIVE, IDLE, UNKNOWN }

    private RemoteState remoteState(Session s) {
        try {
            // OpenCode 2 explicitly defines /session/active as foreground drains.
            // If this API succeeds and the ID is absent, execution is not active.
            JsonNode active = unwrap(request("GET", "/api/session/active", null));
            if (active.isObject()) return active.has(s.remoteId) ? RemoteState.ACTIVE : RemoteState.IDLE;
            if (active.isArray()) {
                for (JsonNode item : active) {
                    if (s.remoteId.equals(item.asText(item.path("id").asText()))) return RemoteState.ACTIVE;
                }
                return RemoteState.IDLE;
            }
        } catch (Exception ignored) { /* do not infer idle on errors */ }
        return RemoteState.UNKNOWN;
    }

    /** Read OpenCode 2's cursor-based message history until the admitted user message.
     * A multi-step execution can generate hundreds of assistant/tool messages; a
     * single fixed-size page is not sufficient to prove completion or recover progress.
     * Bounded pagination prevents runaway requests against a damaged server. */
    private record TurnHistory(boolean found, List<JsonNode> messages) {}
    private TurnHistory historyForPrompt(Session s) throws Exception {
        if (s.lastPromptId.isBlank()) return new TurnHistory(false, List.of());
        List<JsonNode> currentTurn = new ArrayList<>();
        Set<String> usedCursors = new HashSet<>();
        String next = "";
        for (int page=0; page<8; page++) {
            String path = "/api/session/" + s.remoteId + "/message?limit=100";
            if (next.isBlank()) path += "&order=desc";
            else path += "&cursor=" + java.net.URLEncoder.encode(next, StandardCharsets.UTF_8);
            JsonNode response = request("GET", path, null);
            JsonNode body = unwrap(response);
            JsonNode items = body.isArray() ? body : body.path("items");
            if (!items.isArray()) items = body.path("messages");
            if (!items.isArray()) return new TurnHistory(false, currentTurn);
            for (JsonNode item : items) {
                JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
                if (s.lastPromptId.equals(meta.path("id").asText()))
                    return new TurnHistory(true, currentTurn);
                currentTurn.add(item);
            }
            JsonNode cursor = response.path("cursor");
            if (!cursor.isObject()) cursor = response.path("data").path("cursor");
            next = cursor.path("next").asText("");
            if (next.isBlank() || !usedCursors.add(next) || items.size() == 0) break;
        }
        return new TurnHistory(false, currentTurn);
    }

    /** Per-turn token recovery independent of tool activity / completion.
     *  Only messages AFTER this turn's admitted user message are accepted. */
    private void recoverUsageHistory(Session s) throws Exception {
        TurnHistory history = historyForPrompt(s);
        if (!history.found()) return;
        boolean changed = false;
        for (JsonNode message : history.messages()) {
            JsonNode meta = message.path("info").isObject() ? message.path("info") : message;
            if (!"assistant".equals(meta.path("type").asText(meta.path("role").asText()))) continue;
            String id = meta.path("id").asText("");
            if (s.tokenLedger.record(id, s.model, "OpenCode model call", meta.path("tokens"))) changed = true;
        }
        if (changed) {
            s.lastEvidenceNanos = System.nanoTime();
            s.push("usage", Map.of("detail", "Provider usage recovered from assistant history"));
            persist(s);
        }
    }

    /** Recovers tool activity from projected messages when the SSE endpoint is absent,
     * and makes report details observable without fabricating steps or mutations. */
    private void recoverMessages(Session s) throws Exception {
        TurnHistory history = historyForPrompt(s);
        if (!history.found()) return; // Never attach an older task's actions.
        List<JsonNode> currentTurn = new ArrayList<>(history.messages());
        Collections.reverse(currentTurn);
        for (JsonNode item : currentTurn) {
            JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
            if (!"assistant".equals(meta.path("role").asText(meta.path("type").asText()))) continue;
            String msgId = meta.path("id").asText("");
            s.tokenLedger.reconcileHistory(msgId,s.model,meta.path("tokens"));
            JsonNode parts = item.path("content").isArray() ? item.path("content") : item.path("parts");
            if (!parts.isArray()) continue;
            for (JsonNode part : parts) {
                if (!"tool".equals(part.path("type").asText())) continue;
                String toolName = part.path("name").asText(part.path("tool").asText("tool"));
                String phase = part.path("state").path("status").asText("running");
                String partId = part.path("id").asText(Integer.toHexString(part.toString().hashCode()));
                String key = "history:" + msgId + ":" + partId + ":" + phase;
                synchronized (s) {
                    if (!s.seenIds.add(key)) continue;
                    s.lastActivityNanos = System.nanoTime();
                    s.lastEvidenceNanos = s.lastActivityNanos;
                    JsonNode toolState=part.path("state");
                    String arguments = safeToolInput(toolState.path("input"));
                    String output = safeToolOutput(toolState);
                    String detail = toolState.path("title").asText("");
                    if (detail.isBlank()) detail = arguments;
                    if (detail.isBlank()) detail = toolState.path("error").path("message").asText("");
                    if (detail.isBlank()) detail = "OpenCode " + toolName + ": " + phase;
                    Map<String,Object> trace=new LinkedHashMap<>();
                    trace.put("tool",shortText(toolName,80));trace.put("step","tool");
                    trace.put("status","completed".equals(phase)?"success":phase);
                    trace.put("detail",shortText(detail,500));
                    trace.put("actionId",shortText(msgId+":"+partId,130));
                    if (!arguments.isBlank()) trace.put("args",arguments);
                    if (!output.isBlank()) trace.put("output",output);
                    s.push("agent_step",trace);
                    s.lastToolActivityNanos=System.nanoTime();
                }
            }
        }
    }

    private boolean remoteHasAssistant(Session s) {
        // A previous assistant reply in a reused session is NOT evidence for
        // this task. Walk the OpenCode 2 paged, newest-first message history
        // back to the exact user message admitted for this turn.
        if (s.lastPromptId.isBlank()) return false;
        try {
            TurnHistory history = historyForPrompt(s);
            if (!history.found()) return false;
            String candidate = "";
            String candidateError = "";
            for (JsonNode item : history.messages()) {
                JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
                if (!"assistant".equals(meta.path("type").asText(meta.path("role").asText()))) continue;
                s.tokenLedger.reconcileHistory(meta.path("id").asText(""),s.model,meta.path("tokens"));
                JsonNode problem = meta.path("error");
                if (problem.isObject()) {
                    candidateError = problem.path("message").asText(
                            problem.path("data").path("message").asText(
                            problem.path("data").path("error").asText(
                            problem.path("name").asText(problem.path("type").asText("Model request failed")))));
                    break;
                } else if (problem.isTextual()) {
                    candidateError = problem.asText();
                    break;
                }
                JsonNode content = item.path("content").isArray() ? item.path("content") : item.path("parts");
                StringBuilder output = new StringBuilder();
                if (content.isArray()) for (JsonNode part : content) {
                    if ("text".equals(part.path("type").asText())) output.append(part.path("text").asText());
                }
                if (!output.isEmpty()) { candidate = output.toString(); break; }
            }
            if (!candidateError.isBlank()) {
                s.status = "failed";
                executionProven = false;
                s.error = scrubProviderSecrets("OpenCode model/provider error: " + candidateError);
                s.push("error", Map.of("detail", s.error));
                persist(s);
                return false;
            }
            if (candidate.isBlank()) return false;
            if (!candidate.equals(s.answer)) {
                s.answer = shortText(candidate, MAX_TEXT);
                s.push("agent_step", Map.of("tool", "OpenCode", "step", "answer", "status", "success",
                        "detail", "Assistant response retrieved from OpenCode message history"));
            }
            s.finishTurn();
            return true;
        } catch (Exception ignored) { /* no remote completion evidence */ }
        return false;
    }

    private void recoverLog(Session s) throws Exception {
        String cursor = s.lastLogEventId.isBlank() ? "" : "&after=" + java.net.URLEncoder.encode(s.lastLogEventId, StandardCharsets.UTF_8);
        HttpRequest req = HttpRequest.newBuilder(base.resolve("/api/experimental/session/" + s.remoteId + "/log?follow=false" + cursor))
                .timeout(Duration.ofSeconds(6)).header("Authorization", authorization)
                .header("Accept", "text/event-stream").GET().build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) return;
        String type = "", id = "";
        StringBuilder data = new StringBuilder();
        int count = 0;
        for (String line : res.body().split("\\r?\\n", -1)) {
            if (++count > 12000) break;
            if (line.isBlank()) {
                if (!data.isEmpty()) readEvent(s, type, id, data.toString());
                type = ""; id = ""; data.setLength(0);
            } else if (line.startsWith("event:")) type = line.substring(6).trim();
            else if (line.startsWith("id:")) id = line.substring(3).trim();
            else if (line.startsWith("data:") && data.length() < 500_000) {
                if (!data.isEmpty()) data.append('\n');
                data.append(line.substring(5).trim());
            }
            if (!"running".equals(s.status)) break;
        }
        if (!data.isEmpty() && "running".equals(s.status)) readEvent(s,type,id,data.toString());
    }

    /** Volatile OpenCode v2 event stream: session.usage.updated is not in the durable
     *  session log. Use this for quick updates, plus metadata/history recovery for
     *  disconnected clients. The stream is read-only and never issues prompts. */
    private void beginLiveUsageReader(Session s) {
        synchronized (s) {
            if (s.liveUsageReading || s.liveUsageUnsupported || !"running".equals(s.status) || readers.isShutdown()) return;
            s.liveUsageReading = true;
        }
        readers.execute(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(base.resolve(
                                "/api/event?types=session.usage.updated&types=session.step.ended&types=session.step.failed"))
                        .timeout(Duration.ofHours(2))
                        .header("Authorization", authorization)
                        .header("Accept", "text/event-stream").GET().build();
                HttpResponse<InputStream> response = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
                if (response.statusCode() != 200) {
                    // Unsupported endpoint/query: do not retry every 12 seconds.
                    // The durable stream and bounded REST reconciler remain active.
                    if (response.statusCode() == 404 || response.statusCode() == 400)
                        s.liveUsageUnsupported = true;
                    try {response.body().close();} catch (IOException ignored) {}
                    return;
                }
                try (InputStream stream = response.body()) {
                    s.liveUsageStream = stream;
                    BufferedReader in = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                    String line, type = "", id = "";
                    StringBuilder data = new StringBuilder();
                    while ("running".equals(s.status) && !Thread.currentThread().isInterrupted()
                            && (line = in.readLine()) != null) {
                        if (line.isEmpty()) {
                            if (!data.isEmpty()) readEvent(s, type, id, data.toString(), false);
                            type=""; id=""; data.setLength(0);
                        } else if (line.startsWith("event:")) type=line.substring(6).trim();
                        else if (line.startsWith("id:")) id=line.substring(3).trim();
                        else if (line.startsWith("data:") && data.length()<1_000_000) {
                            if (!data.isEmpty()) data.append('\n');
                            data.append(line.substring(5).trim());
                        }
                    }
                }
            } catch (Exception ignored) { /* /api/event is optional; history reconcilers remain active */ }
            finally {s.liveUsageStream = null; s.liveUsageReading = false;}
        });
    }

    private void closeLiveUsageStream(Session s) {
        InputStream stream = s.liveUsageStream;
        if (stream != null) {
            try { stream.close(); } catch (IOException ignored) { }
        }
    }

    private void beginReader(Session s) {
        if (s.reading) return;
        s.reading = true;
        readers.execute(() -> {
            try {
                // This experimental endpoint replays durable history then follows new events.
                String cursor = s.lastLogEventId.isBlank() ? "" : "&after=" + java.net.URLEncoder.encode(s.lastLogEventId, StandardCharsets.UTF_8);
                HttpRequest req = HttpRequest.newBuilder(base.resolve("/api/experimental/session/" + s.remoteId + "/log?follow=true" + cursor))
                        .timeout(Duration.ofHours(12)).header("Authorization", authorization)
                        .header("Accept", "text/event-stream").GET().build();
                HttpResponse<InputStream> response = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
                if (response.statusCode() != 200) throw new IllegalStateException("OpenCode events HTTP " + response.statusCode());
                try (BufferedReader in = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
                    String line, type = "", id = "";
                    StringBuilder data = new StringBuilder();
                    while (!Thread.currentThread().isInterrupted() && (line=in.readLine()) != null) {
                        if (line.isEmpty()) {
                            if (!data.isEmpty()) readEvent(s, type, id, data.toString());
                            type = ""; id = ""; data.setLength(0);
                        } else if (line.startsWith("event:")) type=line.substring(6).trim();
                        else if (line.startsWith("id:")) id=line.substring(3).trim();
                        else if (line.startsWith("data:") && data.length() < 2_000_000) {
                            if (!data.isEmpty()) data.append('\n'); data.append(line.substring(5).trim());
                        }
                    }
                }
            } catch (Exception e) {
                if ("running".equals(s.status)) {
                    s.push("agent_step", Map.of("tool", "connection", "status", "warning",
                            "detail", "Event stream disconnected; OpenCode execution may still be running"));
                    persist(s);
                }
            } finally { s.reading = false; }
        });
    }

    private void readEvent(Session s, String eventType, String eventId, String raw) {
        readEvent(s, eventType, eventId, raw, true);
    }

    /** A volatile /api/event cursor must never replace the durable session-log cursor. */
    private void readEvent(Session s, String eventType, String eventId, String raw, boolean durableLog) {
        try {
            JsonNode outer = mapper.readTree(raw);
            // OpenCode 2 SessionLogItemEncoded is a JSON string (not a JSON object).
            if (outer.isTextual()) outer = mapper.readTree(outer.asText());
            JsonNode node = outer.path("properties").isObject() ? outer.path("properties") :
                    outer.path("data").isObject() ? outer.path("data") : outer;
            String type = outer.path("type").asText(outer.path("event").isTextual()
                    ? outer.path("event").asText() : eventType);
            if (type.isBlank() || "message".equals(type) || "log".equals(type))
                type = node.path("type").asText(node.path("event").asText(eventType));
            if (type.equals("message") || type.equals("log") || type.isBlank())
                type = node.path("type").asText(node.path("event").asText(eventType));
            // Durable log envelopes can carry the actual event inside an `event` object.
            if (node.path("event").isObject()) {
                JsonNode nested = node.path("event");
                type = nested.path("type").asText(type);
                node = nested.path("properties").isObject() ? nested.path("properties") : nested;
            }
            if (eventId.isBlank()) eventId = outer.path("id").asText("");
            // /api/event is global to the OpenCode server. Never let another tab's
            // token counters, completion or error contaminate this session.
            String owner = node.path("sessionID").asText(
                    node.path("info").path("sessionID").asText(
                    node.path("message").path("sessionID").asText("")));
            if (!owner.isBlank() && !owner.equals(s.remoteId)) return;
            if (!durableLog && owner.isBlank()) return; // unscoped events cannot be attributed safely
            synchronized (s) {
                if (eventId.isBlank() && !type.endsWith("text.delta"))
                    eventId = "hash:" + Integer.toHexString(raw.hashCode()) + ":" + raw.length();
                // A volatile event may precede its durable replay. Advance only the
                // durable cursor before deduplication, or reconnects replay forever.
                if (durableLog && !eventId.isBlank() && !eventId.startsWith("hash:")) s.lastLogEventId = eventId;
                if (!eventId.isBlank() && !s.seenIds.add(eventId)) return;
                if (s.seenIds.size() > 20000) s.seenIds.clear();
                // A server heartbeat must not reset the no-progress watchdog.
                if (type.endsWith("text.delta") || type.endsWith("session.step.ended")
                        || type.endsWith("session.step.started") || type.endsWith("tool.called")
                        || type.endsWith("tool.success") || type.endsWith("tool.failed")
                        || type.endsWith("tool.progress") || type.endsWith("tool.input.ended")
                        || type.endsWith("message.part.updated")) {
                    s.lastEvidenceNanos = System.nanoTime();
                }
                if (type.contains("execution.") || type.contains("step.") ||
                    type.contains("tool.") || type.contains("text.delta") ||
                    type.contains("message.") || type.contains("part.") ||
                    type.contains("permission.") || type.contains("form.")) {
                    s.lastActivityNanos = System.nanoTime();
                    if (s.firstModelEventMs < 0 && s.admissionStartNanos > 0 &&
                        (type.contains("tool.") || type.contains("text.delta") ||
                         type.contains("step.") || type.contains("reasoning."))) {
                        s.firstModelEventMs = TimeUnit.NANOSECONDS.toMillis(
                                s.lastActivityNanos-s.admissionStartNanos);
                    }
                    s.lastRemoteStatus = "Last verified activity: " + shortText(type, 80);
                }
                // OpenCode v2 step.ended is per-assistant-call; session.usage.updated is cumulative.
                // Durable replay and SSE may deliver the same step; the ledger deduplicates by message ID.
                if (type.endsWith("session.step.ended") || type.endsWith("session.step.failed")) {
                    String messageId = node.path("assistantMessageID").asText(
                            node.path("messageID").asText(node.path("message").path("id").asText("")));
                    JsonNode tokens = node.path("tokens").isObject() ? node.path("tokens") : node.path("usage");
                    if (s.tokenLedger.record(messageId,s.model,"OpenCode model call",tokens)) {
                        s.push("usage", Map.of("detail","Model usage reported", "messageId",shortText(messageId,80)));
                        persist(s);
                    }
                }
                if (type.endsWith("text.delta")) {
                    String delta = node.path("text").asText(node.path("delta").asText(""));
                    if (delta.isBlank()) delta = node.path("content").asText("");
                    if (!delta.isEmpty()) {
                        s.answer = shortText(s.answer + delta, MAX_TEXT);
                        s.push("token", Map.of("text", shortText(delta, 8000)));
                    }
                } else if (type.endsWith("message.part.updated") || type.endsWith("part.updated")) {
                    JsonNode part = node.path("part").isObject() ? node.path("part") : node;
                    String partType = part.path("type").asText("");
                    if ("text".equals(partType) && part.path("text").isTextual()) {
                        String full = shortText(part.path("text").asText(), MAX_TEXT);
                        if (!full.isBlank() && !full.equals(s.answer)) {
                            s.answer = full;
                            s.push("agent_step", Map.of("tool", "OpenCode", "step", "response", "status", "running",
                                    "detail", "Receiving assistant response"));
                        }
                    } else if ("tool".equals(partType)) {
                        String toolName = part.path("name").asText(part.path("tool").asText("tool"));
                        String state = part.path("state").path("status").asText("running");
                        String actionId = part.path("id").asText("");
                        Map<String,Object> step = new LinkedHashMap<>();
                        step.put("tool", shortText(toolName, 80));step.put("step", "tool");
                        step.put("status", "completed".equals(state) ? "success" : state);
                        if (!actionId.isBlank()) step.put("actionId", shortText(actionId, 130));
                        String args = safeToolInput(part.path("state").path("input"));
                        String output = safeToolOutput(part.path("state"));
                        step.put("detail", args.isBlank() ? "OpenCode tool " + shortText(state, 70) : args);
                        if (!args.isBlank()) step.put("args", args);
                        if (!output.isBlank()) step.put("output", output);
                        s.push("agent_step", step);
                        s.lastToolActivityNanos = System.nanoTime();
                    }
                } else if (type.endsWith("message.updated") || type.endsWith("session.status")) {
                    JsonNode msg = node.path("info").isObject() ? node.path("info") : node.path("message");
                    if ("assistant".equals(msg.path("role").asText(msg.path("type").asText()))) {
                        String messageId = msg.path("id").asText("");
                        if (s.tokenLedger.record(messageId,s.model,"OpenCode model call",msg.path("tokens")))
                            s.push("usage", Map.of("detail", "Assistant usage reconciled from OpenCode", "messageId",shortText(messageId,80)));
                    }
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "state", "status", "running",
                            "detail", shortText(type, 100)));
                } else if (type.endsWith("session.error")) {
                    s.status = "failed";
                    executionProven = false;
                    JsonNode issue = node.path("error");
                    s.error = scrubProviderSecrets(node.path("message").asText(issue.path("data").path("message")
                            .asText(issue.path("message").asText(issue.path("type")
                            .asText(issue.asText("OpenCode provider execution failed"))))));
                    s.push("error", Map.of("detail", s.error));
                } else if (type.contains("usage.updated")) {
                    boolean changed = s.tokenLedger.acceptSessionAggregate(node.path("tokens"));
                    if (changed) {
                        s.lastEvidenceNanos = System.nanoTime();
                        s.push("usage", Map.of("detail", "Live OpenCode session token totals updated"));
                        persist(s);
                    }
                } else if (type.endsWith("usage.recorded")) {
                    // Title/compaction usage is separate from assistant steps.
                    // It is already reflected in the authoritative aggregate.
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "usage", "status", "success",
                            "detail", "Provider reported auxiliary model usage (included in session total)"));
                } else if (type.endsWith("execution.succeeded")) {
                    // Durable logs replay earlier turns. The success event is a hint,
                    // never proof of this instruction's completion or edits.
                    s.lastRemoteStatus = "OpenCode reported execution success; verifying current prompt and files";
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "verification", "status", "running",
                            "detail", "Checking the current reply and workspace changes"));
                } else if (type.endsWith("execution.failed")) {
                    // Do not let a delayed event change an already verified turn.
                    if (!"running".equals(s.status) || s.lastPromptId.isBlank()) return;
                    if (s.turnCount > 1 && !s.lastPromptId.equals(node.path("promptID")
                            .asText(node.path("userMessageID").asText("")))) return;
                    s.status = "failed";
                    executionProven = false;
                    JsonNode failure = node.path("error");
                    String explanation = failureDetail(failure);
                    s.error = scrubProviderSecrets(node.path("message").asText(explanation.isBlank()
                            ? "OpenCode reported execution.failed; inspect the selected provider/model"
                            : explanation));
                    s.push("error", Map.of("detail", s.error));
                } else if (type.endsWith("execution.interrupted")) {
                    s.status = "cancelled";
                    executionProven = false;
                    s.push("stopped", Map.of("detail", "Execution interrupted"));
                } else if (type.startsWith("session.tool.")) {
                    captureToolActivity(s, type, node);
                } else if (type.startsWith("session.shell.") || type.startsWith("pty.")) {
                    String status = type.endsWith("ended") || type.endsWith("exited") ? "success" : "running";
                    String detail = node.path("command").asText(node.path("title").asText(type));
                    s.push("agent_step", Map.of("tool", "terminal", "step", "shell", "status", status,
                            "detail", scrubProviderSecrets(shortText(detail, 500))));
                } else if (type.contains("step.")) {
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "reasoning", "status", "running",
                            "detail", shortText(type, 120)));
                } else if (type.equals("form.created") || type.equals("permission.asked")) {
                    boolean permission = type.equals("permission.asked");
                    JsonNode payload = node.path("request").isObject() ? node.path("request") : node;
                    String questionId = payload.path("id").asText(node.path("id").asText(""));
                    String reason = payload.path("title").asText("");
                    if (reason.isBlank() && permission) reason = "Allow " + payload.path("action").asText("this action")
                            + " on " + shortText(payload.path("resources").toString(), 200) + "?";
                    if (reason.isBlank()) reason = "OpenCode requires your input before continuing";
                    if (!questionId.isBlank()) {
                        s.status = "needs_input";
                        s.question = Map.of("kind", "clarification", "source", permission ? "permission" : "form",
                                "id", questionId, "reason", shortText(reason, 500));
                        s.lastRemoteStatus = "Waiting for your answer: " + shortText(reason, 100);
                        s.push("agent_step", Map.of("tool", "question", "status", "approval",
                                "detail", shortText(reason, 500)));
                    }
                } else if (type.equals("form.replied") || type.equals("form.cancelled") || type.equals("permission.replied")) {
                    if ("needs_input".equals(s.status)) {
                        s.question = Map.of(); s.status = "running";
                        s.push("agent_step", Map.of("tool","question","step","reply","status","success",
                                "detail","OpenCode received the response; execution resumed"));
                        beginMonitor(s);
                    }
                }
            }
            if (type.endsWith("execution.succeeded")) {
                // An event is not proof that child tools have exited. The monitor
                // requires an idle session (or attributable idle timestamp) before
                // finalizing completion and releasing filesystem handles.
                s.lastRemoteStatus = "OpenCode reported success; confirming that all tools have exited";
            } else if (type.endsWith("execution.failed")) {
                captureChangeReport(s);
            }
            // Do not synchronously write a session JSON file for every streamed token.
            // The file stores only resumable references, not token-level transcripts.
            if (type.endsWith("execution.succeeded") || type.endsWith("execution.failed") ||
                type.endsWith("session.error") || type.endsWith("execution.interrupted") || type.equals("form.created") ||
                type.equals("permission.asked") || type.endsWith("tool.success") || type.endsWith("tool.failed") ||
                type.endsWith("tool.called") || type.endsWith("tool.input.ended")) {
                long now = System.nanoTime();
                if (!type.endsWith("tool.input.ended") || now - s.lastActivityPersistNanos > TimeUnit.SECONDS.toNanos(2)) {
                    s.lastActivityPersistNanos=now;
                    persist(s);
                }
            }
        } catch (Exception ignored) { /* invalid/non-session events never break activity rendering */ }
    }

    private void refreshAnswer(Session s) {
        try {
            JsonNode response = unwrap(request("GET", "/api/session/" + s.remoteId + "/message?type=assistant&order=desc&limit=5", null));
            JsonNode items = response.isArray() ? response : response.path("items");
            if (!items.isArray()) items = response.path("messages");
            for (JsonNode item : items) {
                JsonNode message = item.path("info").isObject() ? item.path("info") : item;
                if (!"assistant".equals(message.path("role").asText(message.path("type").asText()))) continue;
                JsonNode parts = item.path("content").isArray() ? item.path("content") : item.path("parts");
                StringBuilder answer = new StringBuilder();
                if (parts.isArray()) for (JsonNode part : parts) {
                    if ("text".equals(part.path("type").asText())) answer.append(part.path("text").asText());
                }
                if (answer.length()>0) { s.answer = shortText(answer.toString(), MAX_TEXT); s.finishTurn(); }
                break;
            }
        } catch (Exception ignored) { /* live text stream remains available */ }
    }

    /** Independent evidence for changes in writable references. OpenCode's per-session
     * VCS diff may include only the primary project worktree, not external references.
     * This uses cheap file metadata, skips caches/symlinks and imposes a hard scan cap. */
    private record FileStamp(long size, long modifiedNanos) { }
    private static final Set<String> REFERENCE_SCAN_IGNORES = Set.of(
            ".git", ".gradle", ".idea", "node_modules", "target", "build", "dist", "out",
            "vendor", "coverage", ".venv", "__pycache__", ".next", ".terraform", "bin", "obj");

    private static Map<String,FileStamp> referenceFileSnapshot(List<String> readableRoots) {
        if (readableRoots == null || readableRoots.isEmpty()) return Map.of();
        Map<String,FileStamp> result = new LinkedHashMap<>();
        try {
            for (String rootName : readableRoots) {
                Path root = Path.of(rootName).toRealPath();
                if (!Files.isDirectory(root)) return null;
                Files.walkFileTree(root, EnumSet.noneOf(FileVisitOption.class), 12, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult preVisitDirectory(Path dir,
                            java.nio.file.attribute.BasicFileAttributes a) throws IOException {
                        if (!dir.equals(root) && REFERENCE_SCAN_IGNORES.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT)))
                            return FileVisitResult.SKIP_SUBTREE;
                        if (result.size() > 8000) throw new IOException("Reference verification scan limit reached");
                        return FileVisitResult.CONTINUE;
                    }
                    @Override public FileVisitResult visitFile(Path file,
                            java.nio.file.attribute.BasicFileAttributes a) throws IOException {
                        if (a.isRegularFile()) {
                            if (result.size() >= 8000) throw new IOException("Reference verification scan limit reached");
                            result.put(file.toAbsolutePath().normalize().toString(),
                                    new FileStamp(a.size(), a.lastModifiedTime().to(TimeUnit.NANOSECONDS)));
                        }
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
        } catch (IOException badScope) { return null; } // incomplete scan must never count as verified mutation
        return result;
    }

    private record ReferenceChange(Path path, String action) { }
    private static List<ReferenceChange> referenceFileChanges(Map<String,FileStamp> before,
                                                                 Map<String,FileStamp> after) {
        if (before == null || after == null) return List.of();
        List<ReferenceChange> changes = new ArrayList<>();
        for (var item : after.entrySet()) {
            FileStamp prior = before.get(item.getKey());
            if (prior == null || !prior.equals(item.getValue()))
                changes.add(new ReferenceChange(Path.of(item.getKey()), prior == null ? "added" : "modified"));
        }
        for (String path : before.keySet()) if (!after.containsKey(path))
            changes.add(new ReferenceChange(Path.of(path), "deleted"));
        return changes;
    }

    private static String referencePathLabel(Session s, Path candidate) {
        for (int i=0;i<s.referenceRoots.size();i++) {
            Path root = Path.of(s.referenceRoots.get(i));
            if (!candidate.startsWith(root)) continue;
            String alias = i < s.referenceProjectIds.size()
                    ? s.referenceProjectNames.getOrDefault(s.referenceProjectIds.get(i),"Reference"+(i+1))
                    : "Reference"+(i+1);
            return "@" + alias + "/" + root.relativize(candidate).toString().replace('\\','/');
        }
        return candidate.toString();
    }

    private static boolean permittedChangedPath(Path candidate, Path primary, List<String> writableReferences) {
        if (candidate.startsWith(primary)) return true;
        for (String root : writableReferences) if (candidate.startsWith(Path.of(root))) return true;
        return false;
    }

    /** Use OpenCode's recorded per-turn file diffs rather than inventing files from a model narrative.
     * Diff retrieval failures do not change the execution result, but remain visible to the user. */
    private void captureChangeReport(Session s) {
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("status", s.status);
        result.put("objective", shortText(s.originalPrompt, 1200));
        result.put("verification", "File-change evidence from OpenCode session diff plus bounded writable-reference disk snapshots; build/test and source content review are separate");
        List<Map<String,Object>> evidenceSteps = new ArrayList<>();
        synchronized (s) {
            for (Map<String,Object> event : s.events) {
                if (evidenceSteps.size() >= 60) break;
                if (!"agent_step".equals(event.get("type"))) continue;
                Object raw = event.get("data");
                if (!(raw instanceof Map<?,?> entry)) continue;
                String stepType = String.valueOf(entry.get("step"));
                if (!"tool".equals(stepType)) continue;
                String status = String.valueOf(entry.get("status"));
                String tool = String.valueOf(entry.get("tool"));
                String detail = String.valueOf(entry.get("detail"));
                evidenceSteps.add(Map.of("status", Set.of("completed", "success").contains(status) ? "completed" : status,
                        "text", shortText(tool + " · " + detail, 300), "note", "Observed from OpenCode activity"));
            }
        }
        result.put("steps", evidenceSteps);
        result.put("planType", "opencode-observed-actions");
        List<Map<String,Object>> files = new ArrayList<>();
        int created=0, modified=0, deleted=0;
        boolean onDiskVerified = true;
        List<String> onDiskWarnings = new ArrayList<>();
        Set<Path> diffReportedFiles = new HashSet<>();
        try {
            Path workspace = Path.of(projects.require(s.projectId).getLocalPath()).toRealPath();
            // Bind diffs explicitly to this prompt ID so a different turn's changes
            // cannot be presented as evidence for the current instruction.
            String from = java.net.URLEncoder.encode(s.lastPromptId, StandardCharsets.UTF_8);
            JsonNode diffs = unwrap(request("GET", "/api/session/" + s.remoteId
                    + "/diff?from=" + from + "&context=3", null));
            if (!diffs.isArray()) throw new IllegalStateException("OpenCode returned no per-file diff list");
            for (JsonNode diff : diffs) {
                if (files.size() >= 100) break;
                String action = diff.path("status").asText("modified");
                String relative = diff.path("file").asText("");
                // Verify OpenCode's claimed changes against the actual, mapped
                // workspace; never traverse outside it or follow escaping symlinks.
                try {
                    if (relative.isBlank()) throw new IOException("Diff file path is empty");
                    Path candidate = workspace.resolve(relative).normalize();
                    diffReportedFiles.add(candidate);
                    if (!permittedChangedPath(candidate, workspace, s.writableReferenceRoots))
                        throw new IOException("Diff path is outside the selected writable workspace/reference roots");
                    if ("deleted".equals(action)) {
                        if (Files.exists(candidate, LinkOption.NOFOLLOW_LINKS))
                            throw new IOException("Deleted file remains on disk");
                    } else {
                        if (!Files.isRegularFile(candidate, LinkOption.NOFOLLOW_LINKS))
                            throw new IOException("Changed file missing on disk");
                        Path real = candidate.toRealPath();
                        if (!permittedChangedPath(real, workspace, s.writableReferenceRoots))
                            throw new IOException("Changed file points outside the selected writable roots");
                        if (diff.path("additions").asInt(0) > 0 && Files.size(real) == 0)
                            throw new IOException("Changed file has no content");
                    }
                } catch (Exception fileProblem) {
                    onDiskVerified = false;
                    onDiskWarnings.add(shortText(relative + ": " + fileProblem.getMessage(), 350));
                }
                if ("added".equals(action)) created++;
                else if ("deleted".equals(action)) deleted++;
                else modified++;
                Map<String,Object> file = new LinkedHashMap<>();
                file.put("action", action);
                file.put("relativePath", shortText(relative, 450));
                file.put("detail", "+" + diff.path("additions").asInt(0) + " / -" + diff.path("deletions").asInt(0) + " lines");
                file.put("reason", "Modified during execution of the requested task; specific intent must be confirmed against the diff");
                file.put("excerpt", shortText(diff.path("patch").asText(""), 2000));
                files.add(file);
            }
            result.put("filesVerified", true);
            if (diffs.size() > files.size()) {
                onDiskVerified = false;
                result.put("fileReportWarning", "Showing first 100 changed files only; inspect the repository for the full diff");
            }
        } catch (Exception e) {
            result.put("filesVerified", false);
            onDiskVerified = false;
            result.put("fileReportWarning", "OpenCode per-file diff could not be retrieved: " + safeError(e));
        }
        // Reconcile independently observed reference changes. OpenCode only tracks
        // worktree diffs for its active project on some v2 builds.
        Map<String,FileStamp> afterReferences = referenceFileSnapshot(s.writableReferenceRoots);
        boolean referenceScanVerified = s.referenceFileBaseline != null && afterReferences != null;
        List<ReferenceChange> referenceChanges = referenceScanVerified
                ? referenceFileChanges(s.referenceFileBaseline, afterReferences) : List.of();
        int verifiedReferenceChanges = 0;
        for (ReferenceChange change : referenceChanges) {
            if (diffReportedFiles.contains(change.path())) continue;
            // This is a live metadata comparison and an existence check, not a model claim.
            try {
                if (!permittedChangedPath(change.path(),
                        Path.of(projects.require(s.projectId).getLocalPath()).toRealPath(), s.writableReferenceRoots))
                    continue;
                if (!"deleted".equals(change.action()) &&
                        !Files.isRegularFile(change.path(), LinkOption.NOFOLLOW_LINKS)) continue;
                if ("deleted".equals(change.action()) && Files.exists(change.path(), LinkOption.NOFOLLOW_LINKS)) continue;
                verifiedReferenceChanges++;
                if ("added".equals(change.action())) created++;
                else if ("deleted".equals(change.action())) deleted++;
                else modified++;
                if (files.size() < 100) {
                    files.add(Map.of("action", change.action(),
                            "relativePath", shortText(referencePathLabel(s, change.path()), 450),
                            "detail", "Verified local reference-file metadata change",
                            "reason", "Change occurred during the current OpenCode task; review content to confirm intent",
                            "excerpt", ""));
                }
            } catch (Exception ignored) { /* uncertain evidence is never counted as verified */ }
        }
        result.put("referenceChangesVerified", verifiedReferenceChanges);
        result.put("referenceScanVerified", referenceScanVerified);
        if (verifiedReferenceChanges > 0 && !Boolean.TRUE.equals(result.get("filesVerified"))) {
            result.put("filesVerified", true);
            result.put("fileReportWarning", "OpenCode diff unavailable; changed reference files were verified on disk "
                    + "using bounded metadata snapshots (content review is still required)");
        }
        if (!referenceScanVerified && !s.writableReferenceRoots.isEmpty()) {
            result.put("referenceScanWarning", "Reference snapshot could not be completed; no reference edits are claimed as verified");
        }
        Set<String> afterDirectories = workspaceDirectories(s.projectId, s.writableReferenceRoots);
        Set<String> beforeDirectories = s.directoryBaseline;
        List<Map<String,Object>> directoryChanges = new ArrayList<>();
        boolean directoriesVerified = afterDirectories != null && beforeDirectories != null;
        int addedDirectories=0, deletedDirectories=0;
        if (directoriesVerified) {
            Set<String> additions=new TreeSet<>(afterDirectories);additions.removeAll(beforeDirectories);
            Set<String> removals=new TreeSet<>(beforeDirectories);removals.removeAll(afterDirectories);
            addedDirectories=additions.size();deletedDirectories=removals.size();
            for (String path : additions) {
                if (directoryChanges.size() >= 100) break;
                directoryChanges.add(Map.of("relativePath",shortText(path,450), "action","added_directory",
                        "detail","Directory exists after OpenCode execution and was absent before"));
            }
            for (String path : removals) {
                if (directoryChanges.size() >= 100) break;
                directoryChanges.add(Map.of("relativePath",shortText(path,450), "action","deleted_directory",
                        "detail","Directory absent after OpenCode execution and present before"));
            }
        }
        result.put("directoriesVerified", directoriesVerified);
        result.put("createdDirectories", addedDirectories);
        result.put("deletedDirectories", deletedDirectories);
        result.put("directoryChanges", directoryChanges);
        if (addedDirectories+deletedDirectories > directoryChanges.size())
            result.put("directoryReportWarning", "Showing first 100 changed directories only");
        result.put("workspaceFilesVerified", onDiskVerified);
        if (!onDiskWarnings.isEmpty()) result.put("workspaceWarnings", onDiskWarnings);
        result.put("created", created); result.put("modified", modified); result.put("deleted", deleted);
        result.put("files", files);
        s.changeReport = result;
        synchronized (s) { s.push("change_report", Map.of("files", files.size(), "verified", Boolean.TRUE.equals(result.get("filesVerified")))); }
    }

    public Map<String,Object> answer(String id, String questionId, String choice, String detail) {
        Session s = require(id);
        if (questionId == null || !questionId.equals(s.question.get("id")))
            throw new IllegalArgumentException("Question has expired");
        try {
            String remote = s.remoteId;
            String answer = detail == null || detail.isBlank() ? choice : detail;
            if (answer == null || answer.isBlank()) throw new IllegalArgumentException("Answer is required");
            // Form replies and permission responses use different documented endpoints.
            if ("permission".equals(s.question.get("source"))) {
                // A natural-language yes/no reply to ELIYA's question maps to a one-time
                // permission decision, never blanket future approval.
                String normalized = answer.trim().toLowerCase(Locale.ROOT);
                String decision = Set.of("reject", "no", "n", "deny", "cancel").contains(normalized) ||
                        !Set.of("yes", "y", "allow", "approve", "once", "always").contains(normalized)
                        && !Set.of("once","always","reject").contains(String.valueOf(choice).toLowerCase(Locale.ROOT))
                        ? "reject" : "always".equalsIgnoreCase(choice) ? "always" : "once";
                request("POST", "/api/session/" + remote + "/permission/" + questionId + "/reply",
                        Map.of("decision", decision));
            } else {
                JsonNode info = unwrap(request("GET", "/api/session/" + remote + "/form/" + questionId, null));
                String fieldKey = "answer";
                JsonNode fields = info.path("fields");
                if (fields.isArray()) for (JsonNode field : fields) {
                    if ("string".equals(field.path("type").asText())) {
                        fieldKey = field.path("key").asText("answer"); break;
                    }
                }
                request("POST", "/api/session/" + remote + "/form/" + questionId + "/reply",
                        Map.of("answer", Map.of(fieldKey, answer)));
            }
            s.status = "running"; s.question = Map.of();
            s.lastActivityNanos = System.nanoTime();
            s.push("agent_step", Map.of("tool", "OpenCode", "step", "clarification", "status", "success",
                    "detail", "User response delivered to OpenCode; resuming execution"));
            persist(s);
            beginReader(s);
            beginLiveUsageReader(s);
            beginMonitor(s);
            return Map.of("answered", true);
        } catch (Exception e) { throw new IllegalStateException("OpenCode question response failed: " + safeError(e), e); }
    }

    /** A question stays bound to the same session. The next natural-language response
     * must answer it rather than accidentally start another remote execution. */
    public Optional<String> pendingQuestionSession(String conversationId, String projectId) {
        if (conversationId == null || projectId == null) return Optional.empty();
        return sessions.values().stream().filter(s -> conversationId.equals(s.conversationId)
                && projectId.equals(s.projectId) && !s.retiredFromRescan && "needs_input".equals(s.status)
                && !s.question.getOrDefault("id", "").isBlank())
                .max(Comparator.comparing(s -> s.updatedAt)).map(s -> s.id);
    }

    /** Explicit Rescan invalidates only future reuse of this workspace's historical
     * OpenCode conversation state. Existing sessions remain readable and rollbackable;
     * active tasks are not forcefully stopped. The next task starts with clean model context. */
    public void retireWorkspaceSessions(String projectId) {
        if (projectId == null || projectId.isBlank()) return;
        for (Session session : sessions.values()) {
            if (!projectId.equals(session.projectId)) continue;
            session.retiredFromRescan = true;
            persist(session);
        }
    }

    /** Resume a conversation's own OpenCode session; never cross workspace boundaries. */
    public Optional<String> latestSession(String conversationId, String projectId) {
        if (conversationId == null || projectId == null) return Optional.empty();
        return sessions.values().stream().filter(s -> conversationId.equals(s.conversationId)
                && projectId.equals(s.projectId) && !s.retiredFromRescan && !Set.of("running","queued","needs_input","stalled").contains(s.status))
                .max(Comparator.comparing(s -> s.updatedAt)).map(s -> s.id);
    }

    public Map<String,Object> get(String id) { return require(id).snapshot(); }
    public List<Map<String,Object>> list() {
        return sessions.values().stream().sorted(Comparator.comparing((Session s)->s.updatedAt).reversed())
                .map(Session::snapshot).toList();
    }
    public Map<String,Object> activity(String id, Long before, Integer limit) {
        Session s = require(id);
        List<Map<String,Object>> events;
        synchronized (s) {
            events = s.events.stream().filter(e -> before == null || ((Number)e.get("seq")).longValue() < before).toList();
        }
        int count = Math.min(Math.max(limit == null ? 150 : limit, 1), 500);
        boolean more = events.size()>count;
        return Map.of("events", more ? events.subList(events.size()-count,events.size()) : events,
                "hasMore", more, "truncated", false, "journalError", false);
    }
    public SseEmitter stream(String id) {
        Session s = require(id);
        SseEmitter emitter = new SseEmitter(0L);
        if (s.viewers.size() >= 6) throw new IllegalStateException("Too many OpenCode viewers");
        s.viewers.add(emitter);
        emitter.onCompletion(() -> s.viewers.remove(emitter));
        emitter.onTimeout(() -> s.viewers.remove(emitter));
        emitter.onError(err -> s.viewers.remove(emitter));
        try { emitter.send(SseEmitter.event().name("terminal").data(Map.of("type", "resync"))); }
        catch (Exception ignored) { s.viewers.remove(emitter); }
        return emitter;
    }
    private Session require(String id) {
        Session s = sessions.get(id);
        if (s == null) throw new NoSuchElementException("OpenCode session not found");
        return s;
    }
    private void persist(Session s) {
        try {
            Files.createDirectories(store);
            Path temp = store.resolve(s.id + ".json.tmp");
            synchronized (s) { mapper.writeValue(temp.toFile(), s.snapshotForDisk()); }
            try { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { /* log failure must not interrupt OpenCode */ }
    }
    private static String shortText(String value,int max) { return value == null ? "" : value.length() <= max ? value : value.substring(value.length()-max); }

    private static final class ToolTrace {
        String name="", input="", output="";
        long lastProgressNanos;
    }
    private static final class Session {
        final String id, remoteId, conversationId, projectId, model, originalPrompt;
        String createdAt=Instant.now().toString();
        String startedAt=createdAt, finishedAt="";
        final Deque<Map<String,String>> turns = new ArrayDeque<>();
        final Deque<Map<String,Object>> events = new ArrayDeque<>();
        final Map<String,ToolTrace> toolTraces = new HashMap<>();
        final Set<String> seenIds = new HashSet<>();
        final CopyOnWriteArrayList<SseEmitter> viewers = new CopyOnWriteArrayList<>();
        volatile String status="queued", error="", answer="", updatedAt=createdAt;
        volatile boolean retiredFromRescan;
        volatile String lastPromptId = "";
        // Best-effort timing measurements; no prompts, credentials, or provider URLs.
        volatile long startupMs=-1, modelCheckMs=-1, sessionCreationMs=-1;
        volatile long promptAdmissionMs=-1, firstModelEventMs=-1, verificationMs=-1;
        volatile long admissionStartNanos=0;
        volatile String currentPrompt;
        volatile String lastRemoteStatus = "Request submitted, awaiting first model/tool event";
        volatile boolean reading, liveUsageReading, liveUsageUnsupported, monitoring, verificationInProgress, remoteVerifiedIdle;
        volatile InputStream liveUsageStream;
        volatile long lastActivityNanos = System.nanoTime();
        volatile long lastToolActivityNanos = System.nanoTime();
        // Verified model/tool evidence, not UI heartbeat or API connection health.
        volatile long lastEvidenceNanos = System.nanoTime();
        volatile long lastWarningNanos;
        volatile long lastActivityPersistNanos;
        volatile long lastRemoteContactNanos = System.nanoTime();
        volatile Map<String,String> question=Map.of();
        final OpenCodeTokenLedger tokenLedger = new OpenCodeTokenLedger();
        volatile Map<String,Object> changeReport = Map.of();
        volatile Set<String> directoryBaseline;
        volatile Map<String,FileStamp> referenceFileBaseline;
        volatile String referenceSignature = "";
        volatile List<String> referenceRoots = List.of(), writableReferenceRoots = List.of();
        volatile List<String> referenceProjectIds = List.of();
        volatile Map<String,String> referenceProjectNames = Map.of();
        volatile Map<String,Boolean> referenceProjectWriteAccess = Map.of();
        long sequence;
        int turnCount;
        volatile String lastLogEventId = "";
        Session(String id, String remoteId, String conversationId, String projectId, String model, String prompt) {
            this.id=id;this.remoteId=remoteId;this.conversationId=conversationId;
            this.projectId=projectId;this.model=model;this.originalPrompt=prompt;this.currentPrompt=prompt;
        }
        synchronized void finishTurn() {
            if (!answer.isBlank() && (turns.isEmpty() || !"assistant".equals(turns.peekLast().get("role")))) {
                turns.addLast(Map.of("role","assistant","content",shortText(answer,MAX_TEXT)));
                while(turns.size()>MAX_TURNS) turns.removeFirst();
            }
        }
        synchronized void push(String type, Map<String,Object> data) {
            sequence++; updatedAt=Instant.now().toString();
            Map<String,Object> event = new LinkedHashMap<>();
            event.put("seq",sequence);event.put("type",type);
            if ("token".equals(type)) event.put("text",data.getOrDefault("text",""));
            else event.put("data",data);
            if (!"token".equals(type)) {
                events.addLast(event);
                while(events.size()>MAX_EVENTS) events.removeFirst();
            }
            // Only sanitized activity is sent to ELIYA, no provider headers or raw tool arguments.
            for (SseEmitter emitter : viewers) {
                try { emitter.send(SseEmitter.event().name("terminal").data(event)); }
                catch (Exception ignored) { viewers.remove(emitter); emitter.complete(); }
            }
        }
        synchronized Map<String,Object> snapshotForDisk() {
            Map<String,Object> disk = new LinkedHashMap<>(Map.of("id",id,"remoteId",remoteId,"conversationId",conversationId,"projectId",projectId,
                    "model",model==null?"":model,"fullPrompt",shortText(originalPrompt,MAX_TEXT),"updatedAt",updatedAt));
            disk.put("status", status);
            disk.put("retiredFromRescan", retiredFromRescan);
            disk.put("createdAt",createdAt);
            disk.put("startedAt",startedAt);
            disk.put("finishedAt",finishedAt);
            disk.put("changeReport",changeReport);
            // Store only the already-sanitized activity journal; never raw provider
            // payloads or credentials. Reopening a tab or restarting the JAR retains the trace.
            disk.put("events",List.copyOf(events));
            disk.put("sequence",sequence);
            disk.put("lastPromptId",lastPromptId);
            disk.put("turnCount",turnCount);
            disk.put("referenceSignature",referenceSignature);
            disk.put("referenceRoots",referenceRoots);
            disk.put("writableReferenceRoots",writableReferenceRoots);
            disk.put("referenceProjectIds",referenceProjectIds);
            disk.put("referenceProjectNames",referenceProjectNames);
            disk.put("referenceProjectWriteAccess",referenceProjectWriteAccess);
            disk.put("question",question);
            disk.put("usageCalls", tokenLedger.exportCalls());
            disk.put("usageAggregate", tokenLedger.exportAggregate());
            return disk;
        }
        synchronized Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>();
            boolean running = Set.of("queued", "running", "cancelling", "needs_input").contains(status);
            if (!running && finishedAt.isBlank()) finishedAt = Instant.now().toString();
            long elapsedMs=0;
            try {
                elapsedMs=Math.max(0,Duration.between(Instant.parse(startedAt),
                        running ? Instant.now() : Instant.parse(finishedAt)).toMillis());
            } catch (Exception ignored) { /* old session timestamps may be malformed */ }
            Set<String> observedIds = new HashSet<>();
            for (Map<String,Object> event : events) {
                if (!"agent_step".equals(event.get("type"))) continue;
                Object raw=event.get("data");
                if (raw instanceof Map<?,?> data
                        && !Set.of("connection", "OpenCode").contains(String.valueOf(data.get("tool")))
                        && !Set.of("heartbeat", "admission", "state", "watchdog", "reconnecting").contains(String.valueOf(data.get("step")))) {
                    String key=String.valueOf(data.containsKey("actionId") ? data.get("actionId") : "");
                    observedIds.add(key.isBlank() ? "event:" + event.get("seq") : "tool:" + key);
                }
            }
            int observedActions=observedIds.size();
            // OpenCode does not expose total work units. This estimate uses observed
            // activity milestones, never an invented percent of a known plan.
            int progressPercent="completed".equals(status) ? 100
                    : observedActions <= 0 ? 0
                    : Math.min(90, 10 + (int)Math.round(80 * (1 - Math.exp(-observedActions / 12.0))));
            long evidenceAgeSeconds = TimeUnit.NANOSECONDS.toSeconds(
                    Math.max(0,System.nanoTime()-lastEvidenceNanos));
            boolean indeterminate = running && (observedActions==0 ||
                    evidenceAgeSeconds >= Math.max(15L, Long.getLong("eliya.opencode.noProgressWarnSeconds",60L)));
            result.put("id",id); result.put("engine","opencode"); result.put("remoteId",remoteId);
            result.put("conversationId",conversationId); result.put("projectId",projectId);
            result.put("mode","agent");result.put("model",model);result.put("prompt",shortText(originalPrompt,120));
            result.put("fullPrompt",originalPrompt);result.put("createdAt",createdAt);result.put("updatedAt",updatedAt);
            result.put("startedAt",startedAt); result.put("finishedAt",finishedAt.isBlank()?null:finishedAt);
            result.put("elapsedMs",elapsedMs); result.put("progressPercent",progressPercent);
            result.put("progressEstimated",running && !indeterminate); result.put("progressPhase",status);
            result.put("lastVerifiedProgressSecondsAgo",evidenceAgeSeconds);
            result.put("status",status);result.put("error",error);result.put("answer",answer);
            result.put("lastRemoteStatus", lastRemoteStatus);
            result.put("turns",List.copyOf(turns));result.put("events",List.copyOf(events));
            result.put("sequence",sequence);result.put("question",question);result.put("queue",List.of());
            result.put("queueCount",0);result.put("queuePaused",false);result.put("runId","");
            result.put("referenceProjectIds",referenceProjectIds);
            result.put("referenceProjectNames",referenceProjectNames);
            result.put("referenceProjectWriteAccess",referenceProjectWriteAccess);
            result.put("progress",Map.of("progressPhase",status,
                    "progressDetail",running ? (lastRemoteStatus + " · " + observedActions + " observed events · progress is estimated, not verified")
                            : (status.equals("stalled") ? error : status),
                    "progressPercent",progressPercent,
                    "indeterminate",indeterminate,
                    "estimated",running && !indeterminate,
                    "observedActions",observedActions,
                    "lastVerifiedProgressSecondsAgo",evidenceAgeSeconds));
            Map<String,Long> timings = new LinkedHashMap<>();
            if (startupMs >= 0) timings.put("startup", startupMs);
            if (modelCheckMs >= 0) timings.put("modelValidation", modelCheckMs);
            if (sessionCreationMs >= 0) timings.put("sessionCreation", sessionCreationMs);
            if (promptAdmissionMs >= 0) timings.put("promptAdmission", promptAdmissionMs);
            if (firstModelEventMs >= 0) timings.put("firstModelOrToolEvent", firstModelEventMs);
            if (verificationMs >= 0) timings.put("fileVerification", verificationMs);
            result.put("timingsMs", timings);
            result.put("usage",tokenLedger.taskSnapshot(elapsedMs,"opencode",model));
            result.put("sessionUsage",tokenLedger.sessionSnapshot(elapsedMs,"opencode",model));
            result.put("changeReport", changeReport);
            return result;
        }
    }

    @PreDestroy public void shutdown() {
        prewarmExecutor.shutdownNow();
        processCleanup.shutdownNow();
        readers.shutdownNow();
        stopManagedProcess();
        for (Session s : sessions.values()) for (SseEmitter e : s.viewers) e.complete();
    }
}
