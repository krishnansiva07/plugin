package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Durable, resumable, FILE-FIRST artifact assembly. A model produces bounded numbered chunks;
 * chunks are persisted and checked BEFORE any workspace mutation. A finalized file is written
 * through AgentWorkspaceService to preserve its existing baseline/rollback protection.
 * The service checks structural integrity, never guesses that a generated document meets every
 * semantic requirement in the original task. IDs remain resumable across application restarts.
 */
@Service
public class LargeArtifactService {
    private static final int MAX_CHUNK_CHARS = 100_000;
    private static final int MAX_CHUNKS = Integer.getInteger("eliya.artifacts.maxChunks", 1024);
    private static final long MAX_SOURCE_BYTES = Long.getLong("eliya.artifacts.generationMaxBytes", 64L * 1024 * 1024);
    private static final Pattern ID = Pattern.compile("[a-f0-9-]{36}");
    private static final Set<String> FORMATS = Set.of("md", "txt", "html", "htm", "json", "xml", "csv", "tsv", "docx", "xlsx");
    // Stage outside the normal application working directory, so a user workspace
    // coinciding with that directory does not unexpectedly absorb these checkpoints.
    private final Path storage = Path.of(System.getProperty("eliya.artifacts.staging",
            Path.of(System.getProperty("user.home"), ".eliya", "artifact-staging").toString()))
            .toAbsolutePath().normalize();
    private final ObjectMapper mapper;
    private final ExcelExportService excel;

    public LargeArtifactService(ObjectMapper mapper, ExcelExportService excel) {
        this.mapper = mapper;
        this.excel = excel;
    }

    public record Session(String id, String workspace, String path, String format,
                          int expectedChunks, int minimumLines, List<String> requiredText,
                          boolean overwrite, long startedAt) implements java.io.Serializable {}

    private Path folder(String id) {
        if (id == null || !ID.matcher(id).matches()) throw new IllegalArgumentException("Invalid artifact session ID");
        return storage.resolve(id);
    }
    private Session read(String id, Path root) throws IOException {
        Path dir = folder(id);
        Path manifest = dir.resolve("manifest.json");
        if (!Files.isRegularFile(manifest, LinkOption.NOFOLLOW_LINKS)) throw new FileNotFoundException("Unknown artifact session " + id);
        Session session = mapper.readValue(manifest.toFile(), Session.class);
        if (!root.toRealPath().toString().equals(session.workspace()))
            throw new SecurityException("Artifact session is bound to a different workspace");
        return session;
    }
    private static Path safeDestination(Path root, String raw) throws IOException {
        if (raw == null || raw.isBlank() || raw.indexOf('\0') >= 0) throw new IllegalArgumentException("A relative output path is required");
        Path rel = Path.of(raw.replace('\\', '/'));
        if (rel.isAbsolute() || rel.normalize().startsWith("..") || rel.toString().equals("."))
            throw new SecurityException("Artifact output must remain inside the active workspace");
        Path resolved = root.resolve(rel).normalize();
        if (!resolved.startsWith(root)) throw new SecurityException("Artifact output escapes workspace");
        for (Path cursor = resolved; cursor != null && cursor.startsWith(root); cursor = cursor.getParent()) {
            if (Files.isSymbolicLink(cursor)) throw new SecurityException("Artifact destination traverses a symbolic link");
            if (cursor.equals(root)) break;
        }
        return resolved;
    }
    private static String extension(String path) {
        int dot = path.lastIndexOf('.');
        return dot < 0 ? "" : path.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    public synchronized String start(Path workspace, String path, int expectedChunks, int minimumLines,
                                     List<String> requiredText, boolean overwrite) throws IOException {
        Path root = workspace.toRealPath();
        Path dest = safeDestination(root, path);
        String format = extension(path);
        if (!FORMATS.contains(format)) throw new IllegalArgumentException("Unsupported artifact format: " + format);
        if (expectedChunks < 1 || expectedChunks > MAX_CHUNKS) throw new IllegalArgumentException("Expected chunk count must be between 1 and " + MAX_CHUNKS);
        if (minimumLines < 0) throw new IllegalArgumentException("Minimum lines must be nonnegative");
        if (Files.exists(dest, LinkOption.NOFOLLOW_LINKS) && !overwrite)
            throw new FileAlreadyExistsException("Existing destination requires explicit overwrite permission: " + path);
        String id = UUID.randomUUID().toString();
        Path dir = folder(id);
        Files.createDirectories(dir);
        Session session = new Session(id, root.toString(), root.relativize(dest).toString().replace('\\','/'), format,
                expectedChunks, minimumLines, requiredText == null ? List.of() : List.copyOf(requiredText),
                overwrite, System.currentTimeMillis());
        Path temp = dir.resolve("manifest.json.tmp");
        mapper.writeValue(temp.toFile(), session);
        atomic(temp, dir.resolve("manifest.json"));
        return "ARTIFACT_STARTED id=" + id + " path=" + session.path() + " expectedChunks=" + expectedChunks +
                "; append chunks 0 through " + (expectedChunks-1) + ", then finalize. No workspace modifications yet.";
    }

    public synchronized String extend(Path workspace, String id, int newChunkCount) throws IOException {
        Session s = read(id, workspace);
        if (Files.exists(folder(id).resolve("receipt.json"), LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Finalized artifact is immutable; start a new artifact session");
        if (newChunkCount <= s.expectedChunks() || newChunkCount > MAX_CHUNKS)
            throw new IllegalArgumentException("Chunk count must increase and cannot exceed " + MAX_CHUNKS);
        Session extended = new Session(s.id(), s.workspace(), s.path(), s.format(), newChunkCount,
                s.minimumLines(), s.requiredText(), s.overwrite(), s.startedAt());
        Path tmp = folder(id).resolve("manifest.json.tmp");
        mapper.writeValue(tmp.toFile(), extended);
        atomic(tmp, folder(id).resolve("manifest.json"));
        return "ARTIFACT_PLAN_EXTENDED id=" + id + " expectedChunks=" + newChunkCount +
                "; existing chunks preserved; missing chunks still block finalization.";
    }

    /** Workspace-bound lookup allows resuming a staged ID even when the previous Agent tool trace was lost. */
    public synchronized String pending(Path workspace) throws IOException {
        Path root = workspace.toRealPath();
        if (!Files.isDirectory(storage)) return "No staged artifact sessions found.";
        List<String> matches = new ArrayList<>();
        try (var entries = Files.list(storage)) {
            for (Path entry : entries.limit(4000).toList()) {
                if (!Files.isDirectory(entry, LinkOption.NOFOLLOW_LINKS)) continue;
                String id = entry.getFileName().toString();
                if (!ID.matcher(id).matches() || Files.isRegularFile(entry.resolve("receipt.json"))) continue;
                try {
                    Session s = read(id, root);
                    matches.add(status(root, id));
                    if (matches.size() == 50) break;
                } catch (Exception ignored) { /* Other workspaces / incomplete manifests are not exposed. */ }
            }
        }
        return matches.isEmpty() ? "No unfinished staged artifact sessions in this workspace." : String.join("\n", matches);
    }

    public synchronized String append(Path workspace, String id, int sequence, String text) throws IOException {
        Session session = read(id, workspace);
        if (Files.exists(folder(id).resolve("receipt.json"), LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Finalized artifact is immutable; start a new artifact session");
        if (sequence < 0 || sequence >= session.expectedChunks()) throw new IllegalArgumentException("Chunk sequence outside planned range");
        if (text == null || text.isEmpty() || text.length() > MAX_CHUNK_CHARS)
            throw new IllegalArgumentException("Chunk must contain 1.." + MAX_CHUNK_CHARS + " characters");
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        Path dir = folder(id);
        Path finalPart = dir.resolve(String.format(Locale.ROOT, "%05d.part", sequence));
        if (Files.exists(finalPart, LinkOption.NOFOLLOW_LINKS)) {
            if (!MessageDigest.isEqual(hash(Files.readAllBytes(finalPart)).getBytes(StandardCharsets.US_ASCII),
                    hash(bytes).getBytes(StandardCharsets.US_ASCII)))
                throw new IOException("Chunk conflict at sequence " + sequence + "; refusing to overwrite a different checkpoint");
            return "ARTIFACT_CHUNK_REUSED id=" + id + " sequence=" + sequence + " sha256=" + hash(bytes);
        }
        long existing = 0;
        try (var pieces = Files.list(dir)) {
            for (Path p : pieces.filter(x -> x.getFileName().toString().endsWith(".part")).toList()) existing += Files.size(p);
        }
        if (existing + bytes.length > MAX_SOURCE_BYTES) throw new IOException("Staged artifact exceeds configured byte capacity; no truncation occurred");
        Path temp = Files.createTempFile(dir, "chunk-", ".tmp");
        try { Files.write(temp, bytes); atomic(temp, finalPart); }
        finally { Files.deleteIfExists(temp); }
        return "ARTIFACT_CHUNK_SAVED id=" + id + " sequence=" + sequence + " bytes=" + bytes.length + " sha256=" + hash(bytes);
    }

    public synchronized String status(Path workspace, String id) throws IOException {
        Session s = read(id, workspace);
        List<Integer> missing = new ArrayList<>();
        long bytes = 0;
        for (int i=0; i<s.expectedChunks(); i++) {
            Path p = folder(id).resolve(String.format(Locale.ROOT, "%05d.part", i));
            if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS)) missing.add(i);
            else bytes += Files.size(p);
        }
        return "ARTIFACT_STATUS id=" + id + " path=" + s.path() + " chunks=" + (s.expectedChunks()-missing.size()) +
                "/" + s.expectedChunks() + " bytes=" + bytes + " missing=" + missing;
    }

    public synchronized String finalizeArtifact(AgentWorkspaceService workspaces, AgentWorkspaceService.Workspace workspace,
                                                 String id, String path) throws Exception {
        Path root = workspace.root().toRealPath();
        Session s = read(id, root);
        if (!s.path().equals(path.replace('\\','/')))
            throw new SecurityException("Finalize destination must match the staged artifact path");
        // A tool retry after a lost response must be safe. An existing receipt
        // is accepted only after rechecking the exact final bytes and format.
        if (Files.isRegularFile(folder(id).resolve("receipt.json"), LinkOption.NOFOLLOW_LINKS))
            return verify(root, id) + "; workspaceChanged=false; idempotent finalize retry";
        Path dest = safeDestination(root, s.path());
        List<Integer> missing = new ArrayList<>();
        for (int i=0; i<s.expectedChunks(); i++)
            if (!Files.isRegularFile(folder(id).resolve(String.format(Locale.ROOT, "%05d.part", i)), LinkOption.NOFOLLOW_LINKS)) missing.add(i);
        if (!missing.isEmpty()) throw new IOException("ARTIFACT_INCOMPLETE id=" + id + " missingChunks=" + missing);
        if (Files.exists(dest, LinkOption.NOFOLLOW_LINKS) && !s.overwrite())
            throw new FileAlreadyExistsException("Destination appeared after staging began; not overwriting " + s.path());
        // Reassembly is streamed to a staging file; the model never needs to replay previous chunks.
        Path source = folder(id).resolve("assembled.source");
        Path tmp = Files.createTempFile(folder(id), "assemble-", ".tmp");
        try (OutputStream out = Files.newOutputStream(tmp)) {
            for (int i=0; i<s.expectedChunks(); i++)
                Files.copy(folder(id).resolve(String.format(Locale.ROOT,"%05d.part", i)), out);
        }
        atomic(tmp, source);
        long size = Files.size(source);
        if (size == 0 || size > MAX_SOURCE_BYTES) throw new IOException("Artifact is empty or exceeds allowed size; no file was written");
        String content = Files.readString(source, StandardCharsets.UTF_8);
        int lines = content.isEmpty() ? 0 : (int)content.lines().count();
        if (lines < s.minimumLines()) throw new IOException("ARTIFACT_INCOMPLETE expected at least " + s.minimumLines() + " lines, found " + lines);
        for (String item : s.requiredText()) {
            if (item != null && !item.isBlank() && !content.contains(item))
                throw new IOException("ARTIFACT_INCOMPLETE missing required content: " + item);
        }
        byte[] result;
        if (s.format().equals("docx")) result = docx(content);
        else if (s.format().equals("xlsx")) result = excel.fromMarkdown(s.path(), content);
        else {
            validateText(s.format(), content);
            result = Files.readAllBytes(source);
        }
        validateNative(s.format(), result);
        // The workspace's guarded writer records the baseline BEFORE any mutation and verifies readback.
        String write = workspaces.writeFileBytes(workspace, s.path(), result, s.overwrite());
        byte[] readBack = Files.readAllBytes(dest);
        if (!MessageDigest.isEqual(MessageDigest.getInstance("SHA-256").digest(result),
                                   MessageDigest.getInstance("SHA-256").digest(readBack)))
            throw new IOException("ARTIFACT_INVALID: persisted file checksum mismatch");
        Path receipt = folder(id).resolve("receipt.json");
        mapper.writeValue(receipt.toFile(), Map.of("path", s.path(), "bytes", result.length, "sha256", hash(result),
                "sourceLines", lines, "chunks", s.expectedChunks(), "structuralValidation", "passed"));
        return "ARTIFACT_VERIFIED path=" + s.path() + " bytes=" + result.length + " sha256=" + hash(result) +
                " sourceLines=" + lines + " chunks=" + s.expectedChunks() + "; " + write +
                "; semantic requirement coverage still requires independent review.";
    }
    /** Independently recheck a finalized artifact against the persisted receipt and native format. */
    public synchronized String verify(Path workspace, String id) throws Exception {
        Session s = read(id, workspace);
        Path receipt = folder(id).resolve("receipt.json");
        if (!Files.isRegularFile(receipt, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("ARTIFACT_INCOMPLETE: no successful finalization receipt for " + id);
        @SuppressWarnings("unchecked")
        Map<String,Object> checks = mapper.readValue(receipt.toFile(), Map.class);
        Path target = safeDestination(workspace.toRealPath(), s.path());
        if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS))
            throw new FileNotFoundException("Finalized artifact is missing: " + s.path());
        if (Files.size(target) != ((Number) checks.get("bytes")).longValue())
            throw new IOException("Artifact size differs from sealed receipt: " + s.path());
        byte[] data = Files.readAllBytes(target);
        if (!hash(data).equals(checks.get("sha256")))
            throw new IOException("Artifact SHA-256 differs from sealed receipt: " + s.path());
        validateNative(s.format(), data);
        return "ARTIFACT_VERIFIED id=" + id + " path=" + s.path() + " sha256=" + hash(data) +
                " sourceLines=" + checks.get("sourceLines") + "; structural verification only.";
    }

    private void validateText(String format, String content) throws Exception {
        if (content.isBlank() || content.indexOf('\0') >= 0) throw new IOException("Empty/invalid artifact source");
        if (format.equals("json")) mapper.readTree(content);
        if (format.equals("xml")) {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.newDocumentBuilder().parse(new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8)));
        }
        if (format.equals("html") || format.equals("htm")) {
            String low = content.toLowerCase(Locale.ROOT);
            if (!low.contains("<html") || !low.contains("</html>") || !low.contains("<body") || !low.contains("</body>"))
                throw new IOException("HTML artifact has no complete HTML/body structure");
        }
        if (format.equals("md")) {
            long fences = content.lines().filter(line -> line.stripLeading().startsWith("```")).count();
            if (fences % 2 != 0) throw new IOException("Markdown has an unclosed code fence");
        }
    }
    private static void validateNative(String format, byte[] bytes) throws Exception {
        if (bytes.length == 0) throw new IOException("Generated file is empty");
        if (format.equals("docx")) {
            try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(bytes))) {
                if (doc.getParagraphs().isEmpty() && doc.getTables().isEmpty()) throw new IOException("Word document has no content");
            }
        }
        if (format.equals("xlsx")) {
            try (var wb = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
                if (wb.getNumberOfSheets() == 0 || wb.getSheetAt(0).getPhysicalNumberOfRows() == 0)
                    throw new IOException("Excel workbook has no populated worksheets");
            }
        }
    }
    /** Native Word export from staged Markdown, preserving headings, lists and simple tables. */
    private static byte[] docx(String source) throws Exception {
        try (XWPFDocument doc = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            String[] lines = source.split("\\R", -1);
            for (int i = 0; i < lines.length; i++) {
                String text = lines[i];
                if (i + 1 < lines.length && text.contains("|") &&
                        lines[i + 1].strip().matches("\\|?\\s*:?-{3,}:?(?:\\s*\\|\\s*:?-{3,}:?)+\\s*\\|?")) {
                    List<String> headings = tableCells(text);
                    if (headings.size() >= 2) {
                        List<List<String>> rows = new ArrayList<>();
                        rows.add(headings);
                        i++;
                        while (i + 1 < lines.length && lines[i + 1].contains("|")) {
                            List<String> values = tableCells(lines[++i]);
                            if (values.size() < 2) break;
                            rows.add(values);
                        }
                        XWPFTable table = doc.createTable(rows.size(), headings.size());
                        for (int r = 0; r < rows.size(); r++) {
                            XWPFTableRow row = table.getRow(r);
                            for (int c = 0; c < headings.size(); c++) {
                                String cell = c < rows.get(r).size() ? rows.get(r).get(c) : "";
                                row.getCell(c).setText(cell);
                            }
                        }
                        continue;
                    }
                }
                XWPFParagraph p = doc.createParagraph();
                int level = 0;
                while (level < 6 && level < text.length() && text.charAt(level) == '#') level++;
                boolean heading = level > 0 && level < text.length() && text.charAt(level) == ' ';
                if (heading) {
                    p.setStyle("Heading" + level);
                    text = text.substring(level + 1);
                } else if (text.matches("^\\s*[-*+]\\s+.*")) {
                    p.setIndentationLeft(360);
                    text = "• " + text.replaceFirst("^\\s*[-*+]\\s+", "");
                }
                XWPFRun run = p.createRun();
                if (heading) {
                    run.setBold(true);
                    run.setFontSize(Math.max(11, 22 - 2 * level));
                }
                run.setText(text);
            }
            doc.write(out);
            return out.toByteArray();
        }
    }
    private static List<String> tableCells(String raw) {
        String row = raw.strip();
        if (row.startsWith("|")) row = row.substring(1);
        if (row.endsWith("|")) row = row.substring(0, row.length() - 1);
        String[] pieces = row.split("(?<!\\\\)\\|", -1);
        List<String> cells = new ArrayList<>(pieces.length);
        for (String piece : pieces) cells.add(piece.strip().replace("\\|", "|"));
        return cells;
    }
    private static void atomic(Path from, Path to) throws IOException {
        try { Files.move(from, to, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException e) { Files.move(from, to, StandardCopyOption.REPLACE_EXISTING); }
    }
    private static String hash(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }
}
