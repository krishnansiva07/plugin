package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deliverable-level, source-backed prompt-count verification.
 * Distinct prompts in one chat response require independent top-level sections.
 * Distinct prompts requested as workspace files require real, readable, individual MD files.
 * This is never a planner/implementation request and never writes or guesses missing content.
 */
final class AgentPromptDeliveryGate {
    private static final Pattern HEADER = Pattern.compile(
            "(?im)^\\s*(?:#{1,6}\\s+)?prompt\\s*#?\\s*(\\d{1,2})\\b[^\\n]*$");
    private static final Pattern VERIFICATION = Pattern.compile(
            "(?i)\\b(?:verify|validate|acceptance|test|check|evidence|confirm)\\b");
    private static final Pattern OMISSION = Pattern.compile(
            "(?i)\\b(?:same as above|omitted for brevity|remaining steps omitted|fill in later)\\b");

    record Verdict(boolean ready, String reason) {
        static Verdict pass() { return new Verdict(true, ""); }
        static Verdict fail(String reason) { return new Verdict(false, reason); }
    }

    static Verdict validate(String userRequest, String answer, Path workspace,
                            List<ProjectPatchRequest.ProjectPatchFile> changedFiles) {
        if (!AgentConversationIntent.isPromptGenerationRequest(userRequest)) return Verdict.pass();
        int count = AgentConversationIntent.requestedPromptCount(userRequest);
        if (!AgentConversationIntent.promptFilesRequested(userRequest))
            return validateAnswer(answer, count);
        if (workspace == null || changedFiles == null)
            return Verdict.fail("No workspace file inventory exists for the requested prompt files.");
        try {
            Path root = workspace.toRealPath();
            List<String> observed = new ArrayList<>();
            Set<String> distinct = new HashSet<>();
            for (ProjectPatchRequest.ProjectPatchFile item : changedFiles) {
                if (item == null || item.path() == null || "delete".equalsIgnoreCase(item.operation()) ||
                        !item.path().toLowerCase(java.util.Locale.ROOT).endsWith(".md")) continue;
                Path target = root.resolve(item.path()).normalize();
                if (!target.startsWith(root) || !Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) ||
                        !target.toRealPath().startsWith(root) || Files.size(target) > Long.getLong("eliya.agent.promptVerifyMaxBytes", 32L * 1024 * 1024)) continue;
                String source = Files.readString(target, StandardCharsets.UTF_8);
                Verdict single = validateAnswer(source, 1);
                // For one file per prompt we reject nested bundles and reused text.
                if (!single.ready() || numberedHeadings(source).size() > 1) continue;
                String body = source.strip();
                if (distinct.add(body)) observed.add(item.path());
            }
            if ((count > 0 && observed.size() != count) || (count == 0 && observed.size() < 2))
                return Verdict.fail("Expected " + (count > 0 ? count : "at least 2 dynamically decomposed") +
                        " separate, distinct, verified Markdown prompt files, but only " + observed.size() +
                        " changed files met the prompt-content checks. File creation is not completion.");
            if (AgentConversationIntent.mixedOneTimeReusablePrompts(userRequest)) {
                long reusable = observed.stream().filter(path -> path.toLowerCase(java.util.Locale.ROOT).contains("reusable")).count();
                if (reusable != 1)
                    return Verdict.fail("Expected exactly one separately named reusable prompt file, found " + reusable);
            }
            return Verdict.pass();
        } catch (Exception error) {
            return Verdict.fail("Could not read back and verify all prompt files: " + error.getClass().getSimpleName());
        }
    }

    private static List<Integer> numberedHeadings(String source) {
        ArrayList<Integer> numbers = new ArrayList<>();
        Matcher headers = HEADER.matcher(source);
        while (headers.find()) numbers.add(Integer.parseInt(headers.group(1)));
        return numbers;
    }

    static Verdict validateAnswer(String response, int expected) {
        String text = response == null ? "" : response.replace(ChatAnswerContinuation.PROMPT_DONE, "").strip();
        if (text.length() < 180 || OMISSION.matcher(text).find())
            return Verdict.fail("Prompt generation returned an outline, placeholder, or incomplete response.");
        List<Integer> labels = numberedHeadings(text);
        if (expected == 0) {
            if (labels.size() < 2) return Verdict.fail("Unspecified plural prompt request requires at least two independently numbered prompts.");
            expected = labels.size();
        }
        if (expected <= 1) {
            if (labels.size() > 1)
                return Verdict.fail("A requested single prompt contains multiple numbered prompts.");
            return VERIFICATION.matcher(text).find() ? Verdict.pass() :
                    Verdict.fail("The prompt has no acceptance or verification instructions.");
        }
        if (labels.size() != expected)
            return Verdict.fail("Expected " + expected + " independent prompts but found " + labels.size() +
                    " numbered top-level prompt sections.");
        for (int index = 0; index < labels.size(); index++) {
            if (labels.get(index) != index + 1)
                return Verdict.fail("Prompt sections must be numbered 1 through " + expected + " in order.");
        }
        Matcher matcher = HEADER.matcher(text);
        ArrayList<Integer> offsets = new ArrayList<>();
        while (matcher.find()) offsets.add(matcher.start());
        offsets.add(text.length());
        HashSet<String> distinct = new HashSet<>();
        for (int i=0; i<expected; i++) {
            String part = text.substring(offsets.get(i), offsets.get(i+1)).strip();
            if (part.length() < 180 || !VERIFICATION.matcher(part).find())
                return Verdict.fail("Prompt " + (i+1) + " lacks complete instructions or verification criteria.");
            if (!distinct.add(part.replaceFirst("(?i)prompt\\s*#?\\s*\\d+", "Prompt N")))
                return Verdict.fail("Two or more prompts duplicate the same instructions.");
        }
        return Verdict.pass();
    }
    private AgentPromptDeliveryGate() { }
}
