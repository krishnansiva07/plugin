package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.*;
import java.util.Properties;

/** Persisted, local safety limits for Agent rollback snapshots, independent of source indexing. */
@Service
public class RollbackProtectionSettings {
    public record Limits(long maxFiles, long maxSizeMb, long timeoutSeconds) {
        public long maxBytes() { return Math.multiplyExact(maxSizeMb, 1024L * 1024L); }
    }

    private static final long MIB = 1024L * 1024L;
    private static final long FALLBACK_FILES = 100_000L;
    private static final long FALLBACK_BYTES = 2L * 1024L * 1024L * 1024L;
    public static final Limits DEFAULTS = validatedDefaults();
    private final Path location;
    private volatile Limits current;

    public RollbackProtectionSettings() {
        this(Path.of(System.getProperty("app.data-dir", "./data"), "rollback-protection.properties"));
    }

    RollbackProtectionSettings(Path location) {
        this.location = location.toAbsolutePath().normalize();
        this.current = load();
    }

    private static Limits validatedDefaults() {
        try {
            long files = Long.getLong("eliya.rollback.maxFiles", FALLBACK_FILES);
            long bytes = Long.getLong("eliya.rollback.maxBytes", FALLBACK_BYTES);
            long timeout = Long.getLong("eliya.agent.snapshotTimeoutSeconds", 180L);
            return validate(new Limits(files, (bytes + MIB - 1) / MIB, timeout));
        } catch (RuntimeException ignored) { return new Limits(FALLBACK_FILES, FALLBACK_BYTES / MIB, 180L); }
    }

    public Limits current() { return current; }

    public static Limits validate(Limits value) {
        if (value == null) throw new IllegalArgumentException("Rollback protection settings are required");
        require("Maximum rollback files", value.maxFiles(), 1_000L, 300_000L);
        require("Maximum rollback size (MB)", value.maxSizeMb(), 256L, 32768L);
        require("Rollback snapshot timeout (seconds)", value.timeoutSeconds(), 60L, 3600L);
        return value;
    }

    private static void require(String label, long value, long min, long max) {
        if (value < min || value > max) throw new IllegalArgumentException(label + " must be between " + min + " and " + max);
    }

    public synchronized Limits save(Limits value) throws IOException {
        Limits accepted = validate(value);
        Properties props = new Properties();
        props.setProperty("maxFiles", Long.toString(accepted.maxFiles()));
        props.setProperty("maxSizeMb", Long.toString(accepted.maxSizeMb()));
        props.setProperty("timeoutSeconds", Long.toString(accepted.timeoutSeconds()));
        Files.createDirectories(location.getParent());
        Path temp = Files.createTempFile(location.getParent(), "rollback-", ".tmp");
        try {
            try (OutputStream out = Files.newOutputStream(temp)) {
                props.store(out, "ELIYA Agent rollback protection limits; manage through Settings");
            }
            try { Files.move(temp, location, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temp, location, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
        current = accepted;
        return accepted;
    }

    private Limits load() {
        if (!Files.isRegularFile(location)) return DEFAULTS;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(location)) {
            props.load(in);
            return validate(new Limits(Long.parseLong(props.getProperty("maxFiles")),
                    Long.parseLong(props.getProperty("maxSizeMb")),
                    Long.parseLong(props.getProperty("timeoutSeconds"))));
        } catch (Exception invalid) { return DEFAULTS; }
    }
}
