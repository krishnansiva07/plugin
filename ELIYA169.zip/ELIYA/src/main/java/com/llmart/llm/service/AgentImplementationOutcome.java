package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Evidence-first post-execution summary for prompts pasted from Analyse into Agent.
 * The source prompt is an instruction, never the completion answer. This class
 * deliberately uses no model calls and never converts plan status into verified work.
 */
final class AgentImplementationOutcome {
    private static final Pattern EXECUTION = Pattern.compile(
            "(?i)\\b(?:implement|execute|apply|perform|carry out|migrate|fix|repair|refactor|" +
            "modify|update|develop|build|create|write|make the changes)\\b");
    private static final Pattern PROMPT_SOURCE = Pattern.compile(
            "(?im)^\\s*(?:#{1,6}\\s*)?(?:(?:universal|complete|full|detailed)\\s+)?" +
            "(?:(?:agent|implementation|execution|migration)\\s+){0,3}prompt\\b");
    private static final Pattern STANDALONE_INSTRUCTION = Pattern.compile(
            "(?i)^(?:(?:please|now|go ahead and|can you|could you|i want you to)\\s+){0,3}" +
            "(?:implement|execute|apply|perform|carry out|migrate|fix|repair|refactor|" +
            "modify|update|develop|build|make the changes|create|write)\\b");
    private static final Pattern INSTRUCTION_OUTPUT = Pattern.compile(
            "(?i)\\b(?:you must|you should|must implement|implement all|do not skip|" +
            "acceptance criteria|implementation instructions|execution instructions)\\b");

    private AgentImplementationOutcome() { }

    static boolean isImplementation(String objective) {
        if (objective == null || objective.isBlank() || AgentConversationIntent.isPromptGenerationRequest(objective)) return false;
        String start = objective.strip();
        if (STANDALONE_INSTRUCTION.matcher(start).find()) return true;
        // Long prompt-as-task documents may start with a title, not a verb.
        // Do not infer authorization to edit from incidental verbs in a short question.
        return start.length() > 380 && PROMPT_SOURCE.matcher(start.substring(0, Math.min(700, start.length()))).find()
                && EXECUTION.matcher(start.substring(0, Math.min(1600, start.length()))).find();
    }

    static boolean isPromptEcho(String objective, String candidate) {
        if (objective == null || candidate == null) return false;
        String input = normalize(objective);
        String answer = normalize(candidate);
        if (answer.length() < 160 || input.length() < 160) return false;
        if (input.equals(answer)) return true;
        // A model can return a large prefix of the pasted instructions instead of
        // reporting a single observed change or passing test. Ignore such echoes.
        if (answer.length() >= 220 && input.contains(answer.substring(0, Math.min(220, answer.length()))))
            return true;
        if (answer.length() >= 350 && answer.contains(input.substring(0, Math.min(260, input.length()))))
            return true;
        return answer.length() > 500 && input.contains(answer.substring(0, 180))
                && INSTRUCTION_OUTPUT.matcher(candidate).find();
    }

    static String summarize(String prior, String objective,
            List<ProjectPatchRequest.ProjectPatchFile> changes, int totalChanged,
            String verification, boolean verified, String status, List<Map<String,Object>> plan) {
        String state = status == null || status.isBlank() ? "unknown" : status.toLowerCase(Locale.ROOT);
        List<ProjectPatchRequest.ProjectPatchFile> files = changes == null ? List.of() : changes;
        List<Map<String,Object>> steps = plan == null ? List.of() : plan;
        String reply = prior == null ? "" : prior.strip();
        boolean echoed = isPromptEcho(objective, reply);
        boolean useful = !echoed && AgentResultPresentation.hasSubstantiveAnswer(reply) &&
                !reply.matches("(?is)^(?:done|task completed|agent run completed|completed successfully)[.! ]*$");
        StringBuilder out = new StringBuilder("## Implementation result\n\n");
        out.append("**Run status:** ").append(state).append(". ");
        if (!"completed".equals(state)) out.append("This run did not reach verified completion.");
        else if (verified) out.append("A successful verifier was recorded for the latest workspace revision.");
        else out.append("Completion was recorded, but a passing latest-revision verification was not recorded.");
        out.append("\n\n### What was completed\n\n");
        if (totalChanged > 0) {
            out.append(totalChanged).append(totalChanged == 1 ? " tracked workspace file change" : " tracked workspace file changes")
                    .append(" recorded.\n\n");
            if (!files.isEmpty()) {
                out.append("**Deliverables / changed files**\n\n");
                int shown = 0;
                for (ProjectPatchRequest.ProjectPatchFile f : files) {
                    if (f == null || f.path() == null || f.path().isBlank()) continue;
                    String action = "delete".equalsIgnoreCase(f.operation()) ? "Deleted" :
                            Hashing.ABSENT.equals(f.baselineHash()) ? "Created" : "Updated";
                    out.append("- ").append(action).append(" `")
                            .append(f.path().replace("`", "'")).append("`\n");
                    if (++shown == 30) break;
                }
                if (totalChanged > shown) out.append("- ").append(totalChanged - shown).append(" additional tracked change(s); see the file report\n");
                out.append('\n');
            } else out.append("The file path inventory is unavailable; the activity report must be inspected.\n\n");
        } else {
            out.append("No tracked local workspace changes were confirmed. This alone cannot establish that the requested implementation occurred.\n\n");
        }
        List<String> completed = steps.stream().filter(s -> "completed".equals(s.get("status")))
                .map(s -> safe(String.valueOf(s.getOrDefault("text", "")), 170))
                .filter(s -> !s.isBlank()).limit(7).toList();
        if (!completed.isEmpty()) {
            out.append("**Plan actions reported complete (not independent test evidence)**\n\n");
            for (String step : completed) out.append("- ").append(step).append('\n');
            out.append('\n');
        }
        if (useful) out.append("### Agent findings\n\n").append(reply).append("\n\n");
        else if (echoed) out.append("The model repeated the submitted instructions; that text is not an implementation result and was omitted.\n\n");
        else if (!"completed".equals(state) && !reply.isBlank() &&
                !reply.matches("(?is)^(?:task|agent run)\\s+(?:failed|blocked|cancelled)[.! ]*$"))
            out.append("### Recorded execution issue\n\n").append(safe(reply, 1200)).append("\n\n");
        out.append("### Verification\n\n");
        out.append(verified ? "A passing check was recorded on the latest revision." :
                "No successful verification of the latest workspace revision was recorded.");
        if (verification != null && !verification.isBlank()) out.append(" Evidence: ")
                .append(safe(verification, 650));
        out.append("\n\n### Remaining work and next steps\n\n");
        List<String> pending = steps.stream().filter(s -> !"completed".equals(s.get("status")))
                .map(s -> safe(String.valueOf(s.getOrDefault("text", "")), 160))
                .filter(s -> !s.isBlank()).limit(6).toList();
        if (!pending.isEmpty()) {
            for (String step : pending) out.append("- Unfinished plan step: ").append(step).append('\n');
        }
        if (!"completed".equals(state))
            out.append("- Resolve the last recorded blocker and resume from the saved work before rerunning verification.\n");
        else if (!verified)
            out.append("- Run the missing build, tests, or acceptance checks for the current revision before treating it as verified.\n");
        else if (totalChanged == 0)
            out.append("- Confirm whether the requested changes already existed; this run did not record new edits.\n");
        else if (pending.isEmpty())
            out.append("- No unfinished plan step is recorded. Review the deliverables against the original acceptance criteria before requesting additional changes.\n");
        if (pending.isEmpty() && !"completed".equals(state))
            out.append("- No specific unfinished plan step was recorded; inspect the last error event in the work record.\n");
        return out.toString().strip();
    }

    private static String normalize(String text) { return text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").strip(); }
    private static String safe(String text, int max) {
        String one = text.replaceAll("[\\r\\n]+", " ").replace('`', '\'').strip();
        return one.length() > max ? one.substring(0, max - 1) + "…" : one;
    }
}
