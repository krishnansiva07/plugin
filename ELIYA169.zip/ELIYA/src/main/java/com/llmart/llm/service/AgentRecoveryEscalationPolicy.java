package com.llmart.llm.service;

import java.util.Locale;

/**
 * Limits repeated autonomous recovery on an UNCHANGED plan step and workspace revision.
 * A new step or a real file mutation starts a fresh budget. After the threshold, the
 * existing AgentQuestionService asks for an explicit user decision instead of burning
 * unlimited tokens. This class never relaxes permissions or the accepted task scope.
 */
final class AgentRecoveryEscalationPolicy {
    static final int MAX_UNCHANGED_RECOVERIES = 3;
    private int step = -1;
    private long revision = -1;
    private int unchangedRecoveries;

    synchronized boolean needsDecision(int activeStep, long mutationRevision) {
        if (step != activeStep || revision != mutationRevision) {
            step = activeStep;
            revision = mutationRevision;
            unchangedRecoveries = 0;
        }
        return ++unchangedRecoveries > MAX_UNCHANGED_RECOVERIES;
    }

    synchronized void continueSameScope() { unchangedRecoveries = 0; }

    synchronized int recoveryCount() { return unchangedRecoveries; }

    /** Fail closed: arbitrary prose is not permission for a new strategy or scope. */
    static boolean permitsSameScopeRetry(String answer) {
        if (answer == null || answer.isBlank()) return false;
        String text = answer.strip().toLowerCase(Locale.ROOT);
        if (text.startsWith("user selected:")) {
            text = text.substring("user selected:".length()).strip();
            if (text.startsWith("custom")) text = text.replaceFirst("(?s)^custom\\s*details:\\s*", "").strip();
        }
        // Explicit short consent ONLY. Do not interpret extra instructions embedded
        // in an answer as blanket authorization to change files, permissions or scope.
        text = text.replaceAll("[.!]+$", "").strip();
        return java.util.Set.of("yes", "y", "continue", "continue safely", "proceed", "retry",
                "try again", "try a different safe approach", "try another safe approach",
                "use a safe alternative", "use another safe alternative").contains(text);
    }

    static String decisionQuestion(String objective, String activeStep, String failure) {
        return "I hit the same runtime obstacle repeatedly without a verified change. " +
                "The approved task and completed changes are preserved.\n\n" +
                "Original objective: " + clip(objective, 360) + "\n" +
                "Current step: " + clip(activeStep, 270) + "\n" +
                "Observed issue: " + clip(failure, 370) + "\n\n" +
                "I can try another safe method within the EXACT original scope, with the same " +
                "permissions, rollback protection and verification. Reply 'continue' to authorize " +
                "that retry, or 'stop' to keep the current work and receive the findings. " +
                "I will not skip any requirement or alter your intention.";
    }

    private static String clip(String text, int limit) {
        String cleaned = text == null ? "" : text.replaceAll("\\s+", " ").strip();
        return cleaned.length() <= limit ? cleaned : cleaned.substring(0, limit) + "…";
    }
}
