package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/** Scope-preserving preflight and failure reporting for browser/terminal direct Agent tasks.
 * This class never approves an edit or treats a failed run as successful.
 */
final class AgentDirectSubmissionPolicy {
    private static final Pattern EXPLICIT_RESUME = Pattern.compile(
            "(?i)^(?:please\\s+)?(?:resume|continue|recover)\\s+(?:the\\s+|my\\s+|our\\s+)?" +
            "(?:previous\\s+|last\\s+|interrupted\\s+|unfinished\\s+|paused\\s+)?" +
            "(?:interrupted\\s+|unfinished\\s+|paused\\s+)?(?:agent\\s+)?(?:run|task|work|migration)\\b(?:\\s+from\\s+(?:the\\s+)?(?:last\\s+)?(?:checkpoint|step))?[.!?]*$");

    static boolean explicitInterruptedResume(String message) {
        if (message == null) return false;
        String text = message.strip();
        // A new implementation prompt containing the word resume is still a new contract.
        if (text.length() > 240 || text.contains("\n")) return false;
        return EXPLICIT_RESUME.matcher(text).matches();
    }

    static String actionableFailure(String objective, String error) {
        String issue = error == null || error.isBlank() ? "The runtime did not provide an error message."
                : clip(error.replaceAll("[\r\n]+", " "), 460);
        String lower = issue.toLowerCase(Locale.ROOT);
        String action;
        if (lower.contains("model") || lower.contains("provider") || lower.contains("api key") ||
                lower.contains("401") || lower.contains("429") || lower.contains("token") ||
                lower.contains("connection refused")) {
            action = "Check the configured Agent model, credentials and provider connectivity; then retry the original task. " +
                    "Changing providers or relaxing permissions requires your decision.";
        } else if (lower.contains("workspace") || lower.contains("project") || lower.contains("directory") ||
                lower.contains("path") || lower.contains("access denied") || lower.contains("permission")) {
            action = "Check the selected workspace/reference paths and access rights. " +
                    "ELIYA must not silently choose another writable workspace or bypass permission controls.";
        } else if (lower.contains("attachment") || lower.contains("file not found")) {
            action = "Verify that the requested source/attachment is available and readable, then resume the original request.";
        } else {
            action = "Review the error in Agent activity, correct the failing dependency, and rerun or explicitly resume the original task.";
        }
        return "**Agent could not finish the submitted task.** No successful result or verification is claimed.\n\n" +
                "**Issue:** " + issue + "\n\n" +
                "**Safe next step:** " + action + "\n\n" +
                "**Original intention preserved:** " + clip(objective == null ? "" : objective, 380) +
                "\n\nAny completed workspace changes must be independently checked before continuing.";
    }

    private static String clip(String text, int max) {
        String value = text == null ? "" : text.replaceAll("\\s+", " ").strip();
        return value.length() <= max ? value : value.substring(0, max) + "…";
    }
}
