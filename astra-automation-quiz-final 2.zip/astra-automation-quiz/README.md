# Astra Automation Quiz

Astra Automation Quiz is a Spring Boot + single-page UI application for running a live automation quiz in a Microsoft Teams screen-share session.

The admin creates teams, selects technologies, configures difficulty counts, and runs the quiz from one browser. Questions are generated dynamically by LLM when configured, with demo fallback enabled by default.

## Features

- Single admin-host UI
- Teams screen-share friendly flow
- Configurable teams and technologies
- Per-team question pattern, for example 3 simple, 2 medium, 1 complex
- Choose-the-best-option questions
- Hidden Quiz Master answer panel
- Reveal answer to audience option
- Central Pool / steal mechanism
- Live leaderboard
- Question history
- Final winner celebration screen
- Demo mode fallback questions, so the app runs without an LLM key

## Requirements

- Java 17
- Maven 3.8+

## Build and Run

### Option 1: Maven

```bash
cd astra-automation-quiz
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

### Option 2: Windows

Double-click or run:

```bat
run.bat
```

### Option 3: Linux / Mac

```bash
chmod +x run.sh
./run.sh
```

## LLM Configuration

By default, demo mode is enabled:

```properties
astra.llm.demo-mode=true
```

To connect your OpenAI-compatible LLM gateway, update `src/main/resources/application.properties`:

```properties
astra.llm.demo-mode=false
astra.llm.api-key=${LLM_API_KEY}
astra.llm.base-url=https://your-llm-gateway/v1/chat/completions
astra.llm.model-name=your-model-name
```

Then set your key as an environment variable before running:

Windows PowerShell:

```powershell
$env:LLM_API_KEY="your-key"
```

Linux / Mac:

```bash
export LLM_API_KEY="your-key"
```

## Quiz Rules

- Each team receives equal number of questions.
- Default is 3 simple, 2 medium, 1 complex per team.
- All questions are choose-the-best-answer with A/B/C/D options.
- Admin can view the answer in Quiz Master Mode.
- If assigned team answers correctly, it gets full points.
- If assigned team answers wrong or no answer, the question moves to Central Pool.
- In Central Pool, another team can steal the points.
- Final winner screen shows the champion team and complete leaderboard.
