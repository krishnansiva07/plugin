let quizId = null;
let currentQuestion = null;
let currentQuiz = null;
let answerVisible = false;
let audienceAnswerVisible = false;
let quizMasterVisible = true;

const api = async (url, method='GET', body=null) => {
  const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: body ? JSON.stringify(body) : null});
  const data = await res.json();
  if(!res.ok) throw new Error(data.message || 'Request failed');
  return data;
};

function lines(id){ return document.getElementById(id).value.split('\n').map(x=>x.trim()).filter(Boolean); }
function toast(msg){ const t=document.getElementById('toast'); t.innerText=msg; t.style.display='block'; setTimeout(()=>t.style.display='none',3500); }

async function createQuiz(){
  try{
    const req = {
      quizName: document.getElementById('quizName').value,
      teamNames: lines('teamNames'),
      technologies: lines('technologies'),
      simplePerTeam: +document.getElementById('simplePerTeam').value,
      mediumPerTeam: +document.getElementById('mediumPerTeam').value,
      complexPerTeam: +document.getElementById('complexPerTeam').value,
      simplePoints: +document.getElementById('simplePoints').value,
      mediumPoints: +document.getElementById('mediumPoints').value,
      complexPoints: +document.getElementById('complexPoints').value
    };
    currentQuiz = await api('/api/quiz/create','POST',req);
    quizId = currentQuiz.quizId;
    document.getElementById('setupPanel').classList.add('hidden');
    document.getElementById('quizPanel').classList.remove('hidden');
    document.getElementById('liveTitle').innerText = currentQuiz.quizName;
    renderMeta(); renderLeaderboard(currentQuiz.teams); fillStealTeams();
    toast('Quiz created: ' + quizId);
  }catch(e){ toast(e.message); }
}

function renderMeta(){
  const qCount = currentQuiz.teams.length * (currentQuiz.simplePerTeam + currentQuiz.mediumPerTeam + currentQuiz.complexPerTeam);
  document.getElementById('quizMeta').innerHTML = `Quiz ID: <b>${currentQuiz.quizId}</b> | Teams: ${currentQuiz.teams.length} | Total Questions: ${qCount} | Tech: ${currentQuiz.technologies.join(', ')}`;
}

async function nextQuestion(){
  try{
    audienceAnswerVisible = false;
    currentQuestion = await api(`/api/quiz/${quizId}/next-question`,'POST',{});
    renderQuestion(); fillStealTeams(); answerVisible=false; renderAnswerPanel(); toast('Question generated for ' + currentQuestion.assignedTeam);
  }catch(e){
    if(e.message && e.message.toLowerCase().includes('quiz completed')) showWinnerScreen(); else toast(e.message);
  }
}

function renderQuestion(){
  const q = currentQuestion;
  document.getElementById('questionBox').classList.remove('empty');
  document.getElementById('questionBox').innerHTML = `
    <div class="meta">
      <span class="pill">Turn: ${q.assignedTeam}</span>
      <span class="pill">${q.difficulty}</span>
      <span class="pill">${q.technology}</span>
      <span class="pill">${q.points} Points</span>
    </div>
    <h2>${q.questionText}</h2>
    ${Object.entries(q.options).map(([k,v])=>`<div class="option"><b>${k}.</b> ${v}</div>`).join('')}
    ${audienceAnswerVisible ? `<div class="audienceAnswer"><b>Correct Answer: ${q.correctOption}</b><br>${q.explanation}</div>` : ''}
  `;
  document.getElementById('assignedTeamLabel').innerHTML = `<b>${q.assignedTeam}</b> should answer this question.`;
}

function toggleQuizMasterMode(){
  quizMasterVisible = !quizMasterVisible;
  document.getElementById('quizMasterCard').classList.toggle('hidden', !quizMasterVisible);
  toast(quizMasterVisible ? 'Quiz Master Mode visible' : 'Quiz Master Mode hidden for audience view');
}
function toggleAnswer(){ answerVisible = !answerVisible; renderAnswerPanel(); }
function revealAudienceAnswer(){
  if(!currentQuestion) return toast('Generate a question first');
  audienceAnswerVisible = !audienceAnswerVisible;
  renderQuestion();
}
function renderAnswerPanel(){
  const panel=document.getElementById('answerPanel');
  if(!currentQuestion || !answerVisible){ panel.classList.add('hidden'); panel.innerHTML=''; return; }
  panel.classList.remove('hidden');
  panel.innerHTML = `<h3>Correct Answer: ${currentQuestion.correctOption}</h3><p>${currentQuestion.explanation}</p><p><b>Status:</b> ${currentQuestion.status}</p>`;
}

async function submitPrimary(answer){
  if(!currentQuestion) return toast('Generate a question first');
  try{
    const res = await api(`/api/quiz/${quizId}/submit-primary`,'POST',{teamName:currentQuestion.assignedTeam, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ toast(e.message); }
}

async function submitSteal(answer){
  if(!currentQuestion) return toast('Generate a question first');
  const teamName=document.getElementById('stealTeam').value;
  if(!teamName) return toast('Select stealing team');
  try{
    const res = await api(`/api/quiz/${quizId}/submit-steal`,'POST',{teamName, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ toast(e.message); }
}

function refreshFromSnapshot(snapshot){
  currentQuiz = snapshot.quiz;
  currentQuestion = currentQuiz.questions[currentQuiz.questions.length-1];
  renderLeaderboard(snapshot.leaderboard); renderHistory(); fillStealTeams(); renderQuestion(); renderAnswerPanel();
}
function renderLeaderboard(teams){
  const sorted=[...teams].sort((a,b)=>b.score-a.score);
  document.getElementById('leaderboard').innerHTML = sorted.map((t,i)=>`<li>${i===0?'🏆 ':''}<b>${t.name}</b> — ${t.score} pts</li>`).join('');
}
function renderHistory(){
  document.getElementById('history').innerHTML = currentQuiz.questions.slice().reverse().map((q,i)=>`
    <div class="historyItem">
      <b>${currentQuiz.questions.length-i}. ${q.assignedTeam}</b> | ${q.difficulty} | ${q.points} pts<br>
      Status: ${q.status}${q.winnerTeam ? ' | Winner: '+q.winnerTeam : ''}<br>
      Correct Answer: ${q.correctOption}
    </div>`).join('');
}
function fillStealTeams(){
  const sel=document.getElementById('stealTeam');
  if(!currentQuiz) return;
  const assigned = currentQuestion ? currentQuestion.assignedTeam : '';
  sel.innerHTML = currentQuiz.teams.filter(t=>t.name!==assigned).map(t=>`<option>${t.name}</option>`).join('');
}
function showWinnerScreen(){
  if(!currentQuiz) return toast('Create quiz first');
  const sorted=[...currentQuiz.teams].sort((a,b)=>b.score-a.score);
  const winner=sorted[0];
  document.getElementById('winnerName').innerText = winner ? winner.name : 'No Winner';
  document.getElementById('winnerScore').innerText = winner ? `${winner.score} points` : '';
  document.getElementById('finalLeaderboard').innerHTML = sorted.map((t,i)=>`<div class="finalRow"><b>${i+1}. ${t.name}</b><span>${t.score} pts</span></div>`).join('');
  document.getElementById('winnerOverlay').classList.remove('hidden');
}
function hideWinnerScreen(){ document.getElementById('winnerOverlay').classList.add('hidden'); }
