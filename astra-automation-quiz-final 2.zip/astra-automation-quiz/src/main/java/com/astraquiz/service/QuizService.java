package com.astraquiz.service;

import com.astraquiz.dto.*;
import com.astraquiz.model.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class QuizService {
    private final LlmQuizService llmQuizService;
    private final Map<String, QuizSession> sessions = new ConcurrentHashMap<>();

    public QuizService(LlmQuizService llmQuizService) { this.llmQuizService = llmQuizService; }

    public QuizSession create(CreateQuizRequest req) {
        if (req.teamNames == null || req.teamNames.isEmpty()) throw new IllegalArgumentException("At least one team is required");
        QuizSession s = new QuizSession();
        s.setQuizId("ASTRA-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        s.setQuizName(req.quizName == null || req.quizName.isBlank() ? "Astra Automation Quiz" : req.quizName);
        s.setTeams(req.teamNames.stream().filter(x -> x != null && !x.isBlank()).map(String::trim).map(Team::new).toList());
        s.setTechnologies(req.technologies == null || req.technologies.isEmpty() ? List.of("Selenium Java") : req.technologies);
        s.setSimplePerTeam(req.simplePerTeam); s.setMediumPerTeam(req.mediumPerTeam); s.setComplexPerTeam(req.complexPerTeam);
        s.setSimplePoints(req.simplePoints); s.setMediumPoints(req.mediumPoints); s.setComplexPoints(req.complexPoints);
        s.setStatus("LIVE"); sessions.put(s.getQuizId(), s); return s;
    }

    public QuizSession get(String id) { return Optional.ofNullable(sessions.get(id)).orElseThrow(() -> new IllegalArgumentException("Quiz not found: " + id)); }

    public QuizQuestion nextQuestion(String quizId) {
        QuizSession s = get(quizId);
        Optional<TeamDifficulty> next = findNextTurn(s);
        if (next.isEmpty()) { s.setStatus("ENDED"); throw new IllegalStateException("Quiz completed. No more questions."); }
        Team team = next.get().team;
        Difficulty difficulty = next.get().difficulty;
        int points = points(s, difficulty);
        String tech = s.getTechnologies().get(s.getQuestions().size() % s.getTechnologies().size());
        List<String> asked = s.getQuestions().stream().map(QuizQuestion::getQuestionText).limit(20).toList();
        QuizQuestion q = llmQuizService.generateQuestion(team.getName(), tech, difficulty, points, asked);
        team.increment(difficulty);
        s.getQuestions().add(q);
        return q;
    }

    public ActionResponse submitPrimary(String quizId, AnswerRequest req) {
        QuizSession s = get(quizId); QuizQuestion q = current(s);
        q.setPrimaryAnswer(normalize(req.answer));
        boolean correct = q.getCorrectOption().equalsIgnoreCase(q.getPrimaryAnswer());
        if (correct) {
            team(s, q.getAssignedTeam()).addScore(q.getPoints());
            q.setStatus(QuestionStatus.PRIMARY_CORRECT); q.setWinnerTeam(q.getAssignedTeam());
            return new ActionResponse(true, q.getAssignedTeam() + " correct. +" + q.getPoints(), snapshot(s));
        }
        q.setStatus(QuestionStatus.CENTRAL_POOL);
        return new ActionResponse(false, q.getAssignedTeam() + " wrong/no answer. Question moved to Central Pool.", snapshot(s));
    }

    public ActionResponse submitSteal(String quizId, AnswerRequest req) {
        QuizSession s = get(quizId); QuizQuestion q = current(s);
        if (q.getStatus() != QuestionStatus.CENTRAL_POOL) throw new IllegalStateException("Central pool is not open for this question");
        String stealingTeam = req.teamName;
        if (stealingTeam.equalsIgnoreCase(q.getAssignedTeam())) throw new IllegalArgumentException("Assigned team cannot steal its own question");
        q.setStealAnswer(normalize(req.answer));
        boolean correct = q.getCorrectOption().equalsIgnoreCase(q.getStealAnswer());
        if (correct) {
            team(s, stealingTeam).addScore(q.getPoints());
            q.setStatus(QuestionStatus.STOLEN); q.setWinnerTeam(stealingTeam);
            return new ActionResponse(true, stealingTeam + " stole the question. +" + q.getPoints(), snapshot(s));
        }
        q.setStatus(QuestionStatus.CLOSED);
        return new ActionResponse(false, "Steal answer wrong. No points awarded.", snapshot(s));
    }

    public Object snapshot(QuizSession s) {
        Map<String, Object> out = new LinkedHashMap<>(); out.put("quiz", s); out.put("leaderboard", leaderboard(s)); return out;
    }
    public List<Team> leaderboard(QuizSession s) { return s.getTeams().stream().sorted(Comparator.comparingInt(Team::getScore).reversed()).toList(); }

    private Optional<TeamDifficulty> findNextTurn(QuizSession s) {
        Difficulty[] order = {Difficulty.SIMPLE, Difficulty.MEDIUM, Difficulty.COMPLEX};
        for (Difficulty d : order) {
            for (int i = 0; i < s.getTeams().size(); i++) {
                int idx = (s.getCurrentTeamIndex() + i) % s.getTeams().size(); Team t = s.getTeams().get(idx);
                if (remaining(s, t, d)) { s.setCurrentTeamIndex((idx + 1) % s.getTeams().size()); return Optional.of(new TeamDifficulty(t, d)); }
            }
        }
        return Optional.empty();
    }
    private boolean remaining(QuizSession s, Team t, Difficulty d) {
        return switch (d) { case SIMPLE -> t.getSimpleAsked() < s.getSimplePerTeam(); case MEDIUM -> t.getMediumAsked() < s.getMediumPerTeam(); case COMPLEX -> t.getComplexAsked() < s.getComplexPerTeam(); };
    }
    private int points(QuizSession s, Difficulty d) { return switch (d) { case SIMPLE -> s.getSimplePoints(); case MEDIUM -> s.getMediumPoints(); case COMPLEX -> s.getComplexPoints(); }; }
    private Team team(QuizSession s, String name) { return s.getTeams().stream().filter(t -> t.getName().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new IllegalArgumentException("Team not found: " + name)); }
    private QuizQuestion current(QuizSession s) { if (s.getQuestions().isEmpty()) throw new IllegalStateException("Generate a question first"); return s.getQuestions().get(s.getQuestions().size() - 1); }
    private String normalize(String a) { return a == null ? "" : a.trim().toUpperCase().substring(0, Math.min(1, a.trim().length())); }
    private record TeamDifficulty(Team team, Difficulty difficulty) {}
}
