package com.astraquiz.service;

import com.astraquiz.model.Difficulty;
import com.astraquiz.model.QuizQuestion;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmQuizService {
    @Value("${astra.llm.demo-mode:true}") private boolean demoMode;
    @Value("${astra.llm.base-url:}") private String baseUrl;
    @Value("${astra.llm.api-key:}") private String apiKey;
    @Value("${astra.llm.model-name:gpt-oss-120b}") private String modelName;

    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();
    private int demoCounter = 0;

    public QuizQuestion generateQuestion(String team, String technology, Difficulty difficulty, int points, List<String> asked) {
        if (demoMode || apiKey == null || apiKey.isBlank() || baseUrl.contains("your-llm")) {
            return demoQuestion(team, technology, difficulty, points);
        }
        try {
            String prompt = buildPrompt(technology, difficulty, points, asked);
            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("model", modelName);
            payload.put("temperature", 0.7);
            payload.put("messages", List.of(
                    Map.of("role", "system", "content", "You are an expert automation testing quiz master. Return JSON only."),
                    Map.of("role", "user", "content", prompt)
            ));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(apiKey);
            ResponseEntity<String> response = restTemplate.exchange(baseUrl, HttpMethod.POST, new HttpEntity<>(payload, headers), String.class);
            JsonNode root = mapper.readTree(response.getBody());
            String content = root.at("/choices/0/message/content").asText();
            return parseQuestion(content, team, technology, difficulty, points);
        } catch (Exception ex) {
            QuizQuestion q = demoQuestion(team, technology, difficulty, points);
            q.setExplanation(q.getExplanation() + " [Fallback demo question used because LLM call failed: " + ex.getMessage() + "]");
            return q;
        }
    }

    private String buildPrompt(String technology, Difficulty difficulty, int points, List<String> asked) {
        return """
                Generate one live automation quiz question.
                App: Astra Automation Quiz
                Technology: %s
                Difficulty: %s
                Type: CHOOSE_BEST with four options A/B/C/D
                Points: %d
                Already asked concepts: %s
                Do not repeat existing concepts.
                Return valid JSON only:
                {
                  "questionText":"",
                  "options":{"A":"","B":"","C":"","D":""},
                  "correctOption":"A/B/C/D",
                  "explanation":"short explanation"
                }
                """.formatted(technology, difficulty, points, String.join(" | ", asked));
    }

    private QuizQuestion parseQuestion(String content, String team, String technology, Difficulty difficulty, int points) throws Exception {
        String json = content.substring(content.indexOf('{'), content.lastIndexOf('}') + 1);
        JsonNode n = mapper.readTree(json);
        QuizQuestion q = base(team, technology, difficulty, points);
        q.setQuestionText(n.path("questionText").asText());
        LinkedHashMap<String, String> options = new LinkedHashMap<>();
        options.put("A", n.path("options").path("A").asText());
        options.put("B", n.path("options").path("B").asText());
        options.put("C", n.path("options").path("C").asText());
        options.put("D", n.path("options").path("D").asText());
        q.setOptions(options);
        q.setCorrectOption(n.path("correctOption").asText().trim().toUpperCase());
        q.setExplanation(n.path("explanation").asText());
        return q;
    }

    private QuizQuestion demoQuestion(String team, String technology, Difficulty difficulty, int points) {
        demoCounter++;
        String tech = technology == null || technology.isBlank() ? "Automation" : technology;
        List<QuizQuestion> bank = new ArrayList<>();
        bank.add(make(team, tech, difficulty, points, "A Selenium test fails randomly because a button is not clickable immediately after page load. What is the best solution?", "Use Thread.sleep(10000)", "Use WebDriverWait with elementToBeClickable", "Refresh the page every time", "Increase implicit wait to 5 minutes", "B", "WebDriverWait waits for the exact clickable condition and reduces flaky timing failures."));
        bank.add(make(team, tech, difficulty, points, "In Cucumber automation, what is the best reason to keep step definitions reusable and business-readable?", "To make feature files longer", "To avoid duplicate automation code and improve maintainability", "To remove all assertions", "To replace page objects", "B", "Reusable steps reduce duplication and keep BDD scenarios maintainable."));
        bank.add(make(team, tech, difficulty, points, "For API automation using RestAssured, which validation gives the fastest confidence that the API request succeeded?", "Only print response body", "Validate HTTP status code and key response fields", "Add Thread.sleep after request", "Check browser title", "B", "Status code plus key fields confirms contract and business response basics."));
        bank.add(make(team, tech, difficulty, points, "A test passes locally but fails in Jenkins due to timing issues. What is the best first improvement?", "Increase global implicit wait to 5 minutes", "Use condition-based waits and capture failure evidence", "Disable Jenkins execution", "Run only one test forever", "B", "Condition-based waits and evidence help fix CI instability properly."));
        bank.add(make(team, tech, difficulty, points, "Which approach is best for Page Object Model design?", "Keep locators and actions inside page classes", "Put all locators in test class", "Duplicate login code in every test", "Avoid methods and use raw XPath everywhere", "A", "Page objects encapsulate locators and page actions, making tests cleaner."));
        bank.add(make(team, tech, difficulty, points, "A dropdown automation is failing because visible text changes slightly by environment. What is the best approach?", "Hardcode Thread.sleep", "Use a stable value/id when available", "Click random option", "Skip the test", "B", "Stable attributes are better than environment-dependent display text."));
        return bank.get(demoCounter % bank.size());
    }

    private QuizQuestion make(String team, String tech, Difficulty d, int p, String text, String a, String b, String c, String dd, String correct, String exp) {
        QuizQuestion q = base(team, tech, d, p);
        q.setQuestionText(text);
        LinkedHashMap<String, String> opts = new LinkedHashMap<>();
        opts.put("A", a); opts.put("B", b); opts.put("C", c); opts.put("D", dd);
        q.setOptions(opts); q.setCorrectOption(correct); q.setExplanation(exp); return q;
    }
    private QuizQuestion base(String team, String tech, Difficulty d, int p) {
        QuizQuestion q = new QuizQuestion();
        q.setId(UUID.randomUUID().toString()); q.setAssignedTeam(team); q.setTechnology(tech); q.setDifficulty(d); q.setPoints(p); return q;
    }
}
