# GPT10 validation report

Validation performed on the packaged V10 source tree.

## Passed in the packaging environment

- `src/main/resources/static/app.js`: `node --check` passed.
- `src/main/resources/static/markdown.js`: `node --check` passed.
- `pom.xml`: XML parse passed.
- Java 17-targeted compilation of dependency-free project DTO/core utility classes: passed with `javac --release 17`.
- Agent tool registry + run-state standalone Java 17 smoke: passed.
  - 29 canonical agent tools exposed.
  - native tool definitions and canonical tool names have matching counts.
  - no `git_*` tool is exposed.
  - 1,001 mutation revisions were tracked without a fixed step/action ceiling.
  - verification-required and run-scoped approval state behaved as expected.
- DOCX WordprocessingML extraction standalone Java 17 smoke: passed against a DOCX containing paragraphs and table cells.
- Direct-workspace path-scoping standalone Java 17 smoke: passed.
  - normal in-workspace path accepted.
  - `../` traversal rejected.
  - symlink escape rejected on the validation host.
- Source scan found no syntax-style Java diagnostics (`illegal start`, missing delimiter, unexpected end, etc.) when `javac` parsed the full source tree; unresolved diagnostics were external Spring/Jackson/POI/Tika classes because Maven dependencies are not installed here.
- No fixed Agent model-step ceiling is used by the runtime loop.
- No fixed tool-action-per-turn ceiling is used by the runtime.
- `maxTokens=0` omits the application-side `max_tokens` request field.
- `contextChars=0` uses provider context first and compacts only after an actual provider context-window failure.
- Shell command timeout defaults to unlimited (`timeoutSeconds=0`).
- Spring async/SSE request timeout is disabled for long Agent runs.
- Spring multipart upload/request fixed-size limits are disabled.
- Active local workspace ID is persisted in browser local storage and restored on page load.
- Agent workspace service resolves and edits the canonical user-selected path directly; there is no temporary project mirror/apply stage in Agent mode.
- Managed process tools and HTTP runtime verification tools are present in the native tool registry.
- Dedicated test-case generation UI/prompts are not present.
- Package ZIP integrity test passed after creation.

## Environment limitation

Maven is not installed in this execution environment and there is no usable local Maven dependency cache. Therefore a truthful full `mvn clean test` / Spring Boot package run could not be executed here.

Run `validate-local.sh` (Linux/macOS) or `validate-local.bat` (Windows) on the target machine. Those scripts perform Java/frontend checks, `mvn clean test`, and JAR packaging.

## Important parity boundary

This V10 package contains the rebuilt direct-workspace, native-tool, unlimited productive-loop agent core. Git is intentionally excluded. Full OpenCode feature parity is **not** claimed yet: MCP/dynamic tools, LSP, subagent delegation, and PTY-style interactive terminal remain separate parity modules.
