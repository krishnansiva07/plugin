# Agent architecture

## Live-workspace runtime

```text
Browser UI
  ├─ Chat
  ├─ Analyze
  └─ Agent
       │
       ├─ persistent mapped local path
       ├─ uploaded attachments
       └─ permissions / cancellation
                    │
                    ▼
              Spring Boot / Java 17
                    │
            durable conversation state
                    │
                    ▼
             Agent model-turn loop
                    │
          native tool calling first
             fallback only if needed
                    │
       ┌────────────┼─────────────┐
       ▼            ▼             ▼
  workspace      execution      context
  tools          tools          tools
       │            │             │
       ├ read       ├ build       ├ attachments
       ├ search     ├ test        ├ skills
       ├ edit       ├ check       └ todos
       ├ write      ├ bash
       ├ patch      ├ processes
       └ move/etc.  └ HTTP
       │            │
       └──────┬─────┘
              ▼
       exact mapped path
              │
              ▼
       real observations
              │
              ▼
     model diagnoses / fixes
              │
              └─────────────── repeat until verified
```

There is no agent workspace mirror. File tools mutate the canonical user-selected directory directly.

## No application action ceiling

The loop is `while (true)` and stops only on verified completion, user cancellation, permission denial/blocker, provider refusal, unrecoverable environment failure, or a final blocked result. A model turn may emit multiple native tool calls and all are executed before the next turn.

There is no fixed model-turn count, tool-call-per-turn count, build retry count, command timeout, approval timeout or SSE request timeout.

When output/context exceeds the selected provider's real context window, the runtime compacts older observations only after the provider reports the overflow and then retries.

## Verification state

Every relevant code/config mutation increments a workspace revision. A completed final response is rejected while that revision requires verification.

Built-in verifiers are `build`, `test`, and `check`. `bash` and `http_request` can explicitly act as verifiers using `verification=true`.

For long-running applications the model can start a managed process, inspect logs/status, issue live HTTP checks, modify code, restart and repeat.

## Attachments

Uploads are extracted eagerly and stored with explicit extraction status. The current turn's documents are inserted directly into Chat/Analyze context; Agent mode can additionally retrieve full extracted text through tools.

## Filesystem scope

File tools resolve relative to the active canonical workspace and reject escape outside that workspace. Git is not exposed as an agent capability. `bash` is a normal shell under the selected working directory and is controlled by the shell permission.
