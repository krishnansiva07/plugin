# OpenCode-style capability comparison

Git is intentionally excluded from this product, so Git-specific behavior is not counted as a gap.

| Capability | Current build |
|---|---|
| Persistent conversation/session UI | Yes |
| Chat / Analyze / Agent modes | Yes |
| Direct user-selected live workspace | Yes |
| Native OpenAI-compatible tool calling | Yes, primary |
| Compatibility fallback when tools are unsupported | Yes |
| Multiple tool calls in one model turn | Yes |
| No fixed model-step/action ceiling | Yes |
| Provider-max output/context mode | Yes (`0`) |
| Read/list/glob/grep/file metadata | Yes |
| Edit/write/copy/move/delete/apply-patch | Yes |
| Full workspace shell with pipes/chaining/redirection | Yes |
| No default shell timeout | Yes |
| Build/test/check auto-detection | Yes |
| Long-running managed processes | Yes |
| Runtime process logs/status | Yes |
| Real HTTP runtime verification | Yes |
| Build/run/failure/fix/retry completion guard | Yes |
| Allow / Ask / Deny + approve-once / allow-run | Yes |
| Project-local SKILL.md loading | Yes |
| Current-message document attachments in Chat/Analyze | Yes |
| Attachment tools in Agent mode | Yes |
| Workspace status/diff without Git | Yes |
| User cancellation | Yes |
| Git operations | No — explicitly out of scope |
| MCP servers / dynamically exposed MCP tools | Not yet |
| LSP diagnostics / definition / references | Not yet |
| Subagent/task delegation | Not yet |
| PTY interactive terminal | Not yet |
