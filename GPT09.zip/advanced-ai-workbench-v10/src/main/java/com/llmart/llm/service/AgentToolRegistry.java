package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Small OpenCode-style tool surface presented to the model.  The runtime still accepts the older
 * GPT06/GPT08 tool names as aliases so saved conversations and compatibility JSON responses keep
 * working, but new native-tool turns see the simpler canonical names below.
 */
@Service
public class AgentToolRegistry {
    private final List<Map<String, Object>> nativeDefinitions;
    private final Set<String> canonicalNames;
    private final Map<String, String> aliases;

    public AgentToolRegistry() {
        List<Map<String, Object>> tools = new ArrayList<>();

        tools.add(tool("inspect_workspace", "Inspect the active local workspace, important descriptors and likely toolchains.", emptyObject()));
        tools.add(tool("list", "List files under an optional relative workspace path.", objectSchema(
                prop("path", stringSchema("Optional relative path prefix")))));
        tools.add(tool("glob", "Find workspace files using a glob pattern.", objectSchema(
                prop("pattern", stringSchema("Glob such as src/**/*.java")),
                prop("maxMatches", integerSchema("Maximum matches; 0 or omitted returns all matches")), required("pattern"))));
        tools.add(tool("grep", "Search text files in the workspace. Use regex=true only when a regular expression is needed.", objectSchema(
                prop("pattern", stringSchema("Literal text or Java regular expression")),
                prop("regex", booleanSchema("Interpret pattern as a Java regular expression")),
                prop("maxMatches", integerSchema("Maximum matches; 0 or omitted returns all matches")), required("pattern"))));
        tools.add(tool("file_info", "Return metadata for a workspace file or directory.", objectSchema(
                prop("path", stringSchema("Relative workspace path")), required("path"))));
        tools.add(tool("read", "Read a text/source file. Optional line bounds reduce context usage for large files.", objectSchema(
                prop("path", stringSchema("Relative workspace file path")),
                prop("startLine", integerSchema("Optional first line, 1-based")),
                prop("endLine", integerSchema("Optional last line, inclusive")), required("path"))));
        tools.add(tool("read_many", "Read several text/source files in one tool call.", objectSchema(
                prop("paths", arrayOf(stringSchema("Relative workspace file path"))), required("paths"))));

        tools.add(tool("attachment_list", "List files uploaded in the current chat, including extraction status and file IDs.", emptyObject()));
        tools.add(tool("attachment_read", "Read extracted text from an uploaded document. Use attachment_list first if the file ID is unknown; use offset to continue large documents.", objectSchema(
                prop("fileId", stringSchema("Uploaded attachment ID")),
                prop("offset", integerSchema("Character offset, normally 0 on first read")),
                prop("maxChars", integerSchema("Maximum characters to return; 0 or omitted returns all remaining extracted text")), required("fileId"))));
        tools.add(tool("skill", "Load a project-local SKILL.md by name when reusable project instructions are relevant.", objectSchema(
                prop("name", stringSchema("Skill directory name discovered in .opencode/skills, .agents/skills or .claude/skills")), required("name"))));

        tools.add(tool("edit", "Make a targeted exact-text replacement in an existing file.", objectSchema(
                prop("path", stringSchema("Relative workspace file path")),
                prop("oldText", stringSchema("Exact existing text including enough surrounding context to be unique")),
                prop("newText", stringSchema("Replacement text")),
                prop("replaceAll", booleanSchema("Replace all exact occurrences")),
                required("path", "oldText", "newText"))));
        tools.add(tool("write", "Create or replace a text file with complete final content.", objectSchema(
                prop("path", stringSchema("Relative workspace file path")),
                prop("content", stringSchema("Complete final file content")), required("path", "content"))));
        tools.add(tool("copy", "Copy a workspace file.", objectSchema(
                prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")),
                prop("overwrite", booleanSchema("Replace destination when it exists")), required("from", "to"))));
        tools.add(tool("move", "Move or rename a workspace file.", objectSchema(
                prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")),
                prop("overwrite", booleanSchema("Replace destination when it exists")), required("from", "to"))));
        tools.add(tool("delete", "Delete one workspace file. This does not delete directories.", objectSchema(
                prop("path", stringSchema("Relative workspace file path")), required("path"))));
        tools.add(tool("apply_patch", "Apply multiple complete file writes/deletions in one operation. Changes are written directly to the active workspace.", objectSchema(
                prop("changes", arrayOf(objectSchema(
                        prop("path", stringSchema("Relative workspace file path")),
                        prop("operation", enumSchema("write", "delete")),
                        prop("content", stringSchema("Complete file content for write")),
                        required("path", "operation")
                ))), required("changes"))));

        tools.add(tool("build", "Detect and run the normal project build in the active workspace. Use after code changes when a build descriptor exists.", objectSchema(
                prop("cwd", stringSchema("Optional relative working directory within the workspace")))));
        tools.add(tool("test", "Detect and run the normal project test suite in the active workspace.", objectSchema(
                prop("cwd", stringSchema("Optional relative working directory within the workspace")))));
        tools.add(tool("check", "Detect and run the normal lint/typecheck/static verification command in the active workspace.", objectSchema(
                prop("cwd", stringSchema("Optional relative working directory within the workspace")))));
        tools.add(tool("bash", "Run a shell command directly in the active local workspace. Pipes, redirects and command chaining are supported. By default there is no application timeout; set timeoutSeconds only when the command is expected to be bounded. Set verification=true when this command verifies the current fix. Git operations are intentionally out of scope.", objectSchema(
                prop("command", stringSchema("Shell command")),
                prop("cwd", stringSchema("Optional relative working directory within the workspace")),
                prop("timeoutSeconds", integerSchema("Optional timeout in seconds; 0 or omitted means no application timeout")),
                prop("verification", booleanSchema("True when this command is a verifier for the current workspace revision")), required("command"))));
        tools.add(tool("process_start", "Start a long-running application/server in the background so the agent can continue checking it. The process is cleaned up when the agent run ends unless stopped earlier.", objectSchema(
                prop("command", stringSchema("Shell command used to start the application/server")),
                prop("cwd", stringSchema("Optional relative working directory within the workspace")), required("command"))));
        tools.add(tool("process_status", "Check whether a managed background process is still running and return its exit code when finished.", objectSchema(
                prop("processId", stringSchema("Managed process ID returned by process_start")), required("processId"))));
        tools.add(tool("process_output", "Read current captured stdout/stderr from a managed background process.", objectSchema(
                prop("processId", stringSchema("Managed process ID returned by process_start")),
                prop("offset", integerSchema("Optional character offset for continuing through long output")),
                prop("maxChars", integerSchema("Optional chunk size; 0 means return all currently captured output")), required("processId"))));
        tools.add(tool("process_stop", "Stop a managed background process and its descendants.", objectSchema(
                prop("processId", stringSchema("Managed process ID returned by process_start")), required("processId"))));
        tools.add(tool("http_request", "Call an HTTP/HTTPS endpoint and return real status, headers and body. Useful for verifying a running local web/API application after process_start.", objectSchema(
                prop("method", stringSchema("HTTP method, default GET")),
                prop("url", stringSchema("Full http:// or https:// URL")),
                prop("headers", arrayOf(stringSchema("Header in 'Name: value' form"))),
                prop("body", stringSchema("Optional request body")),
                prop("timeoutSeconds", integerSchema("Optional timeout; 0 or omitted uses the HTTP client's/provider default")),
                prop("verification", booleanSchema("True when this request verifies the current fix")), required("url"))));
        tools.add(tool("workspace_status", "List files changed by explicit agent file tools during the current run. This is not Git.", emptyObject()));
        tools.add(tool("workspace_diff", "Review changes made by explicit agent file tools during the current run relative to their first-seen contents. This is not Git.", objectSchema(
                prop("path", stringSchema("Optional changed relative path")))));

        // OpenCode-style todos are optional helpers, never a completion precondition.
        tools.add(tool("todowrite", "Create or replace an optional task/todo list for longer work. Do not use for trivial tasks.", objectSchema(
                prop("items", arrayOf(stringSchema("Concise todo item"))), required("items"))));
        tools.add(tool("todoread", "Read the current optional todo list.", emptyObject()));

        nativeDefinitions = List.copyOf(tools);
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (Map<String, Object> item : nativeDefinitions) {
            Object function = item.get("function");
            if (function instanceof Map<?, ?> map) found.add(String.valueOf(map.get("name")));
        }
        canonicalNames = Set.copyOf(found);

        Map<String, String> legacy = new LinkedHashMap<>();
        legacy.put("list_project", "list");
        legacy.put("glob_project", "glob");
        legacy.put("search_project", "grep");
        legacy.put("regex_search", "grep");
        legacy.put("read_file", "read");
        legacy.put("read_file_range", "read");
        legacy.put("read_files", "read_many");
        legacy.put("edit_file", "edit");
        legacy.put("write_file", "write");
        legacy.put("copy_file", "copy");
        legacy.put("move_file", "move");
        legacy.put("delete_file", "delete");
        legacy.put("run_command", "bash");
        legacy.put("set_plan", "todowrite");
        legacy.put("get_plan", "todoread");
        // Convenience tools from earlier builds still execute if an older model prompt emits them.
        legacy.put("run_build", "build");
        legacy.put("run_tests", "test");
        legacy.put("run_check", "check");
        legacy.put("changed_files", "workspace_status");
        legacy.put("update_plan", "update_plan");
        aliases = Map.copyOf(legacy);
    }

    public List<Map<String, Object>> nativeDefinitions() { return nativeDefinitions; }

    public String canonical(String tool) {
        if (tool == null) return "";
        String value = tool.trim();
        if (canonicalNames.contains(value)) return value;
        return aliases.getOrDefault(value, value);
    }

    public boolean isKnown(String tool) {
        String canonical = canonical(tool);
        return canonicalNames.contains(canonical) || "update_plan".equals(canonical);
    }

    public Set<String> names() { return canonicalNames; }

    private static Map<String, Object> tool(String name, String description, Map<String, Object> parameters) {
        return Map.of("type", "function", "function", Map.of(
                "name", name,
                "description", description,
                "parameters", parameters
        ));
    }

    @SafeVarargs
    private static Map<String, Object> objectSchema(Map.Entry<String, Object>... entries) {
        LinkedHashMap<String, Object> properties = new LinkedHashMap<>();
        List<String> required = new ArrayList<>();
        for (Map.Entry<String, Object> entry : entries) {
            if ("__required__".equals(entry.getKey())) {
                Object value = entry.getValue();
                if (value instanceof Collection<?> collection) {
                    for (Object item : collection) required.add(String.valueOf(item));
                }
            } else properties.put(entry.getKey(), entry.getValue());
        }
        LinkedHashMap<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        schema.put("properties", properties);
        schema.put("additionalProperties", false);
        if (!required.isEmpty()) schema.put("required", required);
        return schema;
    }

    private static Map<String, Object> emptyObject() {
        return Map.of("type", "object", "properties", Map.of(), "additionalProperties", false);
    }

    private static Map.Entry<String, Object> prop(String name, Object schema) { return Map.entry(name, schema); }
    private static Map.Entry<String, Object> required(String... names) { return Map.entry("__required__", List.of(names)); }
    private static Map<String, Object> stringSchema(String description) { return Map.of("type", "string", "description", description); }
    private static Map<String, Object> integerSchema(String description) { return Map.of("type", "integer", "description", description); }
    private static Map<String, Object> booleanSchema(String description) { return Map.of("type", "boolean", "description", description); }
    private static Map<String, Object> enumSchema(String... values) { return Map.of("type", "string", "enum", List.of(values)); }
    private static Map<String, Object> arrayOf(Object itemSchema) { return Map.of("type", "array", "items", itemSchema); }
}
