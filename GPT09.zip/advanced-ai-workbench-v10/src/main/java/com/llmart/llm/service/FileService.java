package com.llmart.llm.service;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.repository.FileRepository;
import org.apache.tika.Tika;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

@Service
public class FileService {
    private final FileRepository repository;
    private final ConversationService conversations;
    private final Path uploadRoot;
    private final Tika tika = new Tika();

    public FileService(FileRepository repository, ConversationService conversations,
                       @Value("${app.upload-dir:./data/uploads}") String uploadDir) {
        this.repository = repository;
        this.conversations = conversations;
        this.uploadRoot = Paths.get(uploadDir).toAbsolutePath().normalize();
        this.tika.setMaxStringLength(Integer.MAX_VALUE);
    }

    public FileDto save(String conversationId, MultipartFile file) throws Exception {
        conversations.require(conversationId);
        if (file == null || file.isEmpty()) throw new IllegalArgumentException("Empty file");
        Files.createDirectories(uploadRoot.resolve(conversationId));

        String id = UUID.randomUUID().toString();
        String original = sanitizeName(Optional.ofNullable(file.getOriginalFilename()).orElse("upload.bin"));
        Path target = uploadRoot.resolve(conversationId).resolve(id + "-" + original).normalize();
        if (!target.startsWith(uploadRoot)) throw new SecurityException("Invalid file path");
        file.transferTo(target);

        String mime = file.getContentType();
        if (mime == null || mime.isBlank() || "application/octet-stream".equalsIgnoreCase(mime)) {
            try { mime = tika.detect(target); } catch (Exception e) { mime = "application/octet-stream"; }
        }
        // Browser MIME metadata is not always reliable. Prefer content detection when it identifies an image.
        try {
            String detected = tika.detect(target);
            if (detected != null && !detected.isBlank() && (mime == null || mime.isBlank() ||
                    "application/octet-stream".equalsIgnoreCase(mime) || detected.startsWith("image/"))) {
                mime = detected;
            }
        } catch (Exception ignored) {}
        if (mime == null || mime.isBlank()) mime = "application/octet-stream";
        String extracted = "";
        String extractionStatus = "not_applicable";
        String extractionMessage = "Binary/media attachment";
        if (!mime.startsWith("image/") && !mime.startsWith("audio/") && !mime.startsWith("video/")) {
            try {
                // Current-message attachments are first-class context. Extraction therefore happens eagerly
                // at upload time and its outcome is reported explicitly instead of being silently swallowed.
                if (isPlainTextFile(original, mime)) {
                    extracted = Files.readString(target);
                } else if (isDocx(original, mime)) {
                    // DOCX first uses a dependency-independent WordprocessingML reader. Tika is only fallback.
                    extracted = extractDocxText(target);
                    if (extracted.isBlank()) extracted = parseWithTika(target);
                } else if (isXlsx(original, mime)) {
                    extracted = extractWorkbookText(target);
                    if (extracted.isBlank()) extracted = parseWithTika(target);
                } else if (isPptx(original, mime)) {
                    extracted = extractPresentationText(target);
                    if (extracted.isBlank()) extracted = parseWithTika(target);
                } else {
                    // Tika standard parsers cover PDF, legacy Office, RTF, OpenDocument, HTML and many others.
                    extracted = parseWithTika(target);
                }
                extracted = normalizeExtractedText(extracted);
                if (extracted.isBlank()) {
                    extractionStatus = "empty";
                    extractionMessage = "The file uploaded successfully, but no readable text was found";
                } else {
                    extractionStatus = "ready";
                    extractionMessage = "Text extracted successfully";
                }
            } catch (Exception extractionFailure) {
                extracted = "";
                extractionStatus = "failed";
                extractionMessage = safeExtractionError(extractionFailure);
            }
        }

        FileEntity entity = repository.save(new FileEntity(id, conversationId, original, target.toString(),
                mime, file.getSize(), extracted, extractionStatus, extractionMessage));
        return dto(entity);
    }


    public List<FileDto> listForConversation(String conversationId) {
        conversations.require(conversationId);
        return repository.findByConversationId(conversationId).stream()
                .sorted(Comparator.comparing(FileEntity::getCreatedAt))
                .map(this::dto)
                .toList();
    }

    public List<FileEntity> entitiesForConversation(String conversationId) {
        conversations.require(conversationId);
        return repository.findByConversationId(conversationId).stream()
                .sorted(Comparator.comparing(FileEntity::getCreatedAt))
                .toList();
    }

    public FileEntity require(String id) {
        return repository.findById(id).orElseThrow(() -> new NoSuchElementException("File not found"));
    }

    public void cacheExtractedText(String id, String text) {
        FileEntity entity = require(id);
        String value = text == null ? "" : text;
        entity.updateExtractedText(value);
        repository.save(entity);
    }

    public List<FileEntity> requireForConversation(String conversationId, List<String> ids) {
        if (ids == null || ids.isEmpty()) return List.of();
        List<FileEntity> out = new ArrayList<>();
        for (String id : ids) {
            FileEntity f = require(id);
            if (!Objects.equals(f.getConversationId(), conversationId)) throw new SecurityException("File belongs to another conversation");
            out.add(f);
        }
        return out;
    }

    public FileSystemResource resource(String id) {
        FileEntity f = require(id);
        return new FileSystemResource(f.getStoredPath());
    }

    public FileDto dto(FileEntity f) {
        String extracted = f.getExtractedText() == null ? "" : f.getExtractedText();
        String status = f.getExtractionStatus();
        if (status == null || status.isBlank()) status = extracted.isBlank() ? "unknown" : "ready";
        String message = f.getExtractionMessage();
        if (message == null || message.isBlank()) message = extracted.isBlank() ? "Extraction status unavailable" : "Text extracted successfully";
        return new FileDto(f.getId(), f.getOriginalName(), f.getMimeType(), f.getSizeBytes(),
                extracted.length(), status, message);
    }


    public String attachmentListForAgent(String conversationId) {
        List<FileEntity> list = entitiesForConversation(conversationId);
        if (list.isEmpty()) return "[No uploaded attachments in this conversation]";
        StringBuilder out = new StringBuilder();
        for (FileEntity file : list) {
            String extracted = file.getExtractedText() == null ? "" : file.getExtractedText();
            out.append("id=").append(file.getId())
                    .append("; name=").append(file.getOriginalName())
                    .append("; mime=").append(file.getMimeType())
                    .append("; extractedChars=").append(extracted.length())
                    .append("; status=").append(file.getExtractionStatus() == null ? "unknown" : file.getExtractionStatus())
                    .append('\n');
        }
        return out.toString().stripTrailing();
    }

    public String attachmentTextForAgent(String conversationId, String id, int offset, int maxChars) {
        FileEntity file = require(id);
        if (!Objects.equals(file.getConversationId(), conversationId)) throw new SecurityException("Attachment belongs to another conversation");
        String extracted = file.getExtractedText() == null ? "" : file.getExtractedText();
        if (extracted.isBlank()) {
            return "Attachment '" + file.getOriginalName() + "' has no extracted text. extractionStatus=" +
                    (file.getExtractionStatus() == null ? "unknown" : file.getExtractionStatus()) +
                    "; message=" + (file.getExtractionMessage() == null ? "unavailable" : file.getExtractionMessage());
        }
        int start = Math.max(0, Math.min(offset, extracted.length()));
        int cap = maxChars <= 0 ? extracted.length() - start : Math.max(1, maxChars);
        int end = Math.min(extracted.length(), start + cap);
        return "ATTACHMENT: " + file.getOriginalName() + "\nOFFSET: " + start + ".." + end + " of " + extracted.length() + "\n\n" +
                extracted.substring(start, end) + (end < extracted.length() ? "\n\n[More attachment text remains; call attachment_read with offset=" + end + "]" : "");
    }

    private String safeExtractionError(Exception error) {
        String message = error == null ? "Unknown document extraction error" : error.getMessage();
        if (message == null || message.isBlank()) message = error == null ? "Unknown document extraction error" : error.getClass().getSimpleName();
        message = message.replace('\n', ' ').replace('\r', ' ').replaceAll("\\s+", " ").trim();
        return message.length() > 900 ? message.substring(0, 900) : message;
    }

    private String parseWithTika(Path target) throws Exception {
        try (InputStream in = Files.newInputStream(target)) {
            return tika.parseToString(in);
        }
    }

    private boolean isDocx(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        return n.endsWith(".docx") || m.contains("wordprocessingml.document");
    }

    private boolean isXlsx(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        return n.endsWith(".xlsx") || n.endsWith(".xlsm") || m.contains("spreadsheetml.sheet");
    }

    private boolean isPptx(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        return n.endsWith(".pptx") || n.endsWith(".pptm") || m.contains("presentationml.presentation");
    }

    private String extractWorkbookText(Path target) throws Exception {
        StringBuilder out = new StringBuilder();
        DataFormatter formatter = new DataFormatter();
        try (InputStream in = Files.newInputStream(target); Workbook workbook = WorkbookFactory.create(in)) {
            for (int s = 0; s < workbook.getNumberOfSheets(); s++) {
                Sheet sheet = workbook.getSheetAt(s);
                if (!out.isEmpty()) out.append("\n\n");
                out.append("SHEET: ").append(sheet.getSheetName()).append('\n');
                for (Row row : sheet) {
                    boolean first = true;
                    for (Cell cell : row) {
                        if (!first) out.append('\t');
                        first = false;
                        out.append(formatter.formatCellValue(cell));
                    }
                    out.append('\n');
                }
            }
        }
        return out.toString();
    }

    private String extractPresentationText(Path target) throws Exception {
        StringBuilder out = new StringBuilder();
        try (InputStream in = Files.newInputStream(target); XMLSlideShow show = new XMLSlideShow(in)) {
            int slideNo = 1;
            for (var slide : show.getSlides()) {
                if (!out.isEmpty()) out.append("\n\n");
                out.append("SLIDE ").append(slideNo++).append(':').append('\n');
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFTextShape textShape) {
                        String value = textShape.getText();
                        if (value != null && !value.isBlank()) out.append(value.strip()).append('\n');
                    }
                }
            }
        }
        return out.toString();
    }

    /**
     * Minimal, dependency-independent DOCX text reader. It extracts document body, tables, headers, footers,
     * footnotes, endnotes and comments while preserving useful paragraph/tab boundaries.
     */
    private String extractDocxText(Path target) throws Exception {
        List<String> parts = new ArrayList<>();
        try (ZipFile zip = new ZipFile(target.toFile())) {
            List<? extends ZipEntry> entries = Collections.list(zip.entries()).stream()
                    .filter(e -> !e.isDirectory())
                    .filter(e -> {
                        String n = e.getName().toLowerCase(Locale.ROOT);
                        return n.equals("word/document.xml")
                                || n.matches("word/header\\d+\\.xml")
                                || n.matches("word/footer\\d+\\.xml")
                                || n.equals("word/footnotes.xml")
                                || n.equals("word/endnotes.xml")
                                || n.equals("word/comments.xml");
                    })
                    .sorted(Comparator.comparingInt(e -> e.getName().equalsIgnoreCase("word/document.xml") ? 0 : 1))
                    .toList();
            for (ZipEntry entry : entries) {
                try (InputStream in = zip.getInputStream(entry)) {
                    String value = extractWordXml(in);
                    if (!value.isBlank()) parts.add(value);
                }
            }
        }
        return String.join("\n\n", parts);
    }

    private String extractWordXml(InputStream in) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newFactory();
        try { factory.setProperty(XMLInputFactory.SUPPORT_DTD, false); } catch (Exception ignored) {}
        try { factory.setProperty("javax.xml.stream.isSupportingExternalEntities", false); } catch (Exception ignored) {}
        XMLStreamReader reader = factory.createXMLStreamReader(in);
        StringBuilder out = new StringBuilder();
        boolean inText = false;
        while (reader.hasNext()) {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                String local = reader.getLocalName();
                if ("t".equals(local) || "instrText".equals(local)) inText = true;
                else if ("tab".equals(local)) out.append('\t');
                else if ("br".equals(local) || "cr".equals(local)) out.append('\n');
            } else if ((event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA) && inText) {
                out.append(reader.getText());
            } else if (event == XMLStreamConstants.END_ELEMENT) {
                String local = reader.getLocalName();
                if ("t".equals(local) || "instrText".equals(local)) inText = false;
                else if ("p".equals(local)) out.append('\n');
                else if ("tc".equals(local)) out.append('\t');
            }
        }
        reader.close();
        return out.toString();
    }

    private String normalizeExtractedText(String value) {
        if (value == null || value.isBlank()) return "";
        return value.replace("\r\n", "\n")
                .replace('\r', '\n')
                .replaceAll("[ \t]+\n", "\n")
                .replaceAll("\n{4,}", "\n\n\n")
                .strip();
    }

    private boolean isPlainTextFile(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("text/") || m.contains("json") || m.contains("xml") || m.contains("yaml")) return true;
        return n.matches(".*\\.(json|jsonl|txt|md|csv|xml|html?|css|js|jsx|ts|tsx|java|kt|py|sql|ya?ml|properties|feature|robot|sh|ps1|bat|cmd)$");
    }

    private String sanitizeName(String name) {
        return name.replaceAll("[^a-zA-Z0-9._ -]", "_").replace("..", "_");
    }
}
