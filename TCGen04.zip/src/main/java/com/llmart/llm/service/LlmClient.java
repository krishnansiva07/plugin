package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.config.ChatConfig;
import com.llmart.llm.exception.TcgenException;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Service
public class LlmClient {

    private static final String PROVIDER_LLM_CIB = "LLM_CIB";

    private final ChatConfig chatConfig;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    @Value("${llm.llm-cib.api-key:}")
    private String llmCibApiKey;

    @Value("${llm.llm-cib.model-name:gpt-oss-120b-ITG}")
    private String llmCibModelName;

    @Value("${llm.llm-cib.chat-url:https://api.llm.cib.echonet/v1/openai/chat/completions}")
    private String llmCibChatUrl;

    @Value("${llm.llm-cib.completions-url:https://api.llm.cib.echonet/v1/openai/completions}")
    private String llmCibCompletionsUrl;

    @Value("${llm.temperature:0.7}")
    private Double temperature;

    @Value("${llm.max-tokens:512}")
    private Integer maxTokens;

    public LlmClient(ChatConfig chatConfig, ObjectMapper objectMapper) {
        this.chatConfig = chatConfig;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    public String generate(String prompt,
                           String provider,
                           String userApiKey,
                           String userModelName,
                           String userBaseUrl) {
        if (isLlmCib(provider)) {
            return generateWithLlmCib(prompt, userApiKey, userModelName, userBaseUrl);
        }

        // Keep the existing AI4Dev / legacy LangChain4j flow unchanged.
        try {
            ChatLanguageModel chatModel = chatConfig.chatLanguageModel(provider, userApiKey, userModelName, userBaseUrl);
            return chatModel.generate(prompt);
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("LLM request failed. Check provider, API key, model name, base URL and network connectivity.", ex);
        }
    }

    /**
     * LLM@CIB publishes explicit OpenAI-style endpoints. Using the exact endpoint here avoids
     * client-library URL rewriting/concatenation issues and also lets TCGen support both:
     *   /v1/openai/chat/completions
     *   /v1/openai/completions
     */
    private String generateWithLlmCib(String prompt,
                                      String userApiKey,
                                      String userModelName,
                                      String userEndpointOrBaseUrl) {
        String apiKey = firstNonBlank(userApiKey, llmCibApiKey);
        String modelName = firstNonBlank(userModelName, llmCibModelName);
        String endpoint = resolveLlmCibEndpoint(userEndpointOrBaseUrl);

        if (!StringUtils.hasText(apiKey)) {
            throw new TcgenException("API key is required for LLM@CIB. Enter the key/token in the UI or configure LLM_CIB_API_KEY.");
        }
        if (!StringUtils.hasText(modelName)) {
            throw new TcgenException("Model name is required for LLM@CIB.");
        }

        boolean legacyCompletions = isLegacyCompletionsEndpoint(endpoint);

        try {
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("model", modelName);
            if (temperature != null) {
                payload.put("temperature", temperature);
            }
            if (maxTokens != null && maxTokens > 0) {
                payload.put("max_tokens", maxTokens);
            }

            if (legacyCompletions) {
                payload.put("prompt", prompt);
            } else {
                ArrayNode messages = payload.putArray("messages");
                ObjectNode message = messages.addObject();
                message.put("role", "user");
                message.put("content", prompt);
            }

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(endpoint))
                    .timeout(Duration.ofMinutes(3))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(payload)))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new TcgenException(buildCibError(response.statusCode(), endpoint, response.body()));
            }

            return extractGeneratedText(response.body(), legacyCompletions);
        } catch (TcgenException ex) {
            throw ex;
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new TcgenException("LLM@CIB request was interrupted.", ex);
        } catch (Exception ex) {
            throw new TcgenException("LLM@CIB request failed for endpoint " + endpoint
                    + ". Check the endpoint, API key, model name and network access.", ex);
        }
    }

    private String resolveLlmCibEndpoint(String requestEndpointOrBaseUrl) {
        String configured = firstNonBlank(requestEndpointOrBaseUrl, llmCibChatUrl);
        String cleaned = trimTrailingSlash(configured);

        if (cleaned.endsWith("/chat/completions")) {
            return cleaned;
        }
        if (cleaned.endsWith("/completions")) {
            return cleaned;
        }
        if (cleaned.endsWith("/openai")) {
            return cleaned + "/chat/completions";
        }

        // If a CIB OpenAI base path was supplied without the final resource, route to chat.
        return cleaned + "/chat/completions";
    }

    private boolean isLegacyCompletionsEndpoint(String endpoint) {
        return endpoint.endsWith("/completions") && !endpoint.endsWith("/chat/completions");
    }

    private String extractGeneratedText(String responseBody, boolean legacyCompletions) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode choices = root.path("choices");
            if (!choices.isArray() || choices.isEmpty()) {
                throw new TcgenException("LLM@CIB returned HTTP 200 but no choices were present in the response.");
            }

            JsonNode firstChoice = choices.get(0);
            JsonNode contentNode = legacyCompletions
                    ? firstChoice.path("text")
                    : firstChoice.path("message").path("content");

            String content = nodeToText(contentNode);
            if (!StringUtils.hasText(content) && !legacyCompletions) {
                content = nodeToText(firstChoice.path("text"));
            }
            if (!StringUtils.hasText(content)) {
                throw new TcgenException("LLM@CIB returned HTTP 200 but the generated content was empty.");
            }
            return content;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Unable to parse the LLM@CIB response.", ex);
        }
    }

    private String nodeToText(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }
        if (node.isTextual()) {
            return node.asText();
        }
        if (node.isArray()) {
            StringBuilder builder = new StringBuilder();
            for (JsonNode item : node) {
                String part = item.isTextual() ? item.asText() : item.path("text").asText("");
                if (StringUtils.hasText(part)) {
                    if (!builder.isEmpty()) {
                        builder.append('\n');
                    }
                    builder.append(part);
                }
            }
            return builder.toString();
        }
        return node.asText("");
    }

    private String buildCibError(int statusCode, String endpoint, String responseBody) {
        String body = responseBody == null ? "" : responseBody.trim();
        if (body.length() > 1200) {
            body = body.substring(0, 1200) + "...";
        }

        String reason;
        if (statusCode == 401 || statusCode == 403) {
            reason = "Authentication/authorization was rejected";
        } else if (statusCode == 404) {
            reason = "Endpoint was not found";
        } else if (statusCode == 429) {
            reason = "Rate limit or quota was reached";
        } else if (statusCode >= 500) {
            reason = "LLM@CIB server returned an error";
        } else {
            reason = "LLM@CIB request was rejected";
        }

        return reason + " (HTTP " + statusCode + ") at " + endpoint
                + (StringUtils.hasText(body) ? ". Response: " + body : ".");
    }

    private boolean isLlmCib(String provider) {
        if (!StringUtils.hasText(provider)) {
            return false;
        }
        String normalized = provider.trim().toUpperCase().replace('-', '_').replace('@', '_');
        return PROVIDER_LLM_CIB.equals(normalized) || "LLMCIB".equals(normalized);
    }

    private String firstNonBlank(String first, String fallback) {
        if (StringUtils.hasText(first)) {
            return first.trim();
        }
        return fallback == null ? "" : fallback.trim();
    }

    private String trimTrailingSlash(String value) {
        String result = value == null ? "" : value.trim();
        while (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }
        return result;
    }
}
