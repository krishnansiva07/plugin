package com.llmart.llm.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import java.awt.AWTError;
import java.awt.GraphicsEnvironment;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Chooses a folder on the computer running the ELIYA JVM, not the remote browser's computer.
 * Expected desktop failures return a structured, actionable response rather than HTTP 500.
 */
@RestController
@RequestMapping("/api/local-folders")
public class LocalFolderPickerController {
    private static final Logger LOG = Logger.getLogger(LocalFolderPickerController.class.getName());
    private static final String UNAVAILABLE = "The folder picker could not open on this computer. "
            + "Use Enter path (or Reference path) and provide a folder on the computer running ELIYA.";

    @PostMapping("/browse")
    public ResponseEntity<Map<String, Object>> browse(HttpServletRequest request) {
        if (!isLocalRequest(request.getRemoteAddr())) {
            return error(HttpStatus.FORBIDDEN, "LOCAL_ONLY",
                    "Browse is only available when your browser and ELIYA run on the same computer. "
                    + "Use Enter path for a folder on the ELIYA machine.");
        }
        if (!isSameOrigin(request.getHeader("Origin"), request.getHeader("Host"), request.getScheme())) {
            return error(HttpStatus.FORBIDDEN, "ORIGIN_MISMATCH",
                    "Folder selection was blocked because the browser origin differs from ELIYA's address. "
                    + "Open ELIYA using the same address as the current page and try again.");
        }
        try {
            Optional<Path> selection = chooseDirectory();
            if (selection.isEmpty()) return ResponseEntity.ok(Map.of("cancelled", true));
            Path folder = selection.get().toRealPath();
            if (!Files.isDirectory(folder)) {
                return error(HttpStatus.BAD_REQUEST, "INVALID_FOLDER", "Choose an existing directory.");
            }
            return ResponseEntity.ok(Map.of("path", folder.toString()));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            return error(HttpStatus.SERVICE_UNAVAILABLE, "PICKER_UNAVAILABLE", UNAVAILABLE);
        } catch (Exception | AWTError exception) {
            LOG.log(Level.WARNING, "ELIYA local folder selection failed", exception);
            return error(HttpStatus.SERVICE_UNAVAILABLE, "PICKER_UNAVAILABLE", UNAVAILABLE);
        }
    }

    static boolean isLocalRequest(String remoteAddress) {
        if (remoteAddress == null || remoteAddress.isBlank()) return false;
        try { return InetAddress.getByName(remoteAddress).isLoopbackAddress(); }
        catch (Exception ex) { return false; }
    }

    static boolean isSameOrigin(String origin, String host, String scheme) {
        if (origin == null) return true; // non-browser/older same-origin clients need not send Origin
        if (origin.isBlank() || host == null || host.isBlank()) return false;
        try {
            URI originUri = URI.create(origin);
            URI serverUri = URI.create(scheme + "://" + host);
            return originUri.getUserInfo() == null && originUri.getRawQuery() == null
                    && originUri.getRawFragment() == null
                    && originUri.getHost() != null && serverUri.getHost() != null
                    && originUri.getHost().equalsIgnoreCase(serverUri.getHost())
                    && originUri.getScheme().equalsIgnoreCase(serverUri.getScheme())
                    && effectivePort(originUri) == effectivePort(serverUri);
        } catch (IllegalArgumentException | NullPointerException ex) {
            return false;
        }
    }

    private static int effectivePort(URI uri) {
        if (uri.getPort() >= 0) return uri.getPort();
        return "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80;
    }

    private static ResponseEntity<Map<String, Object>> error(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(Map.of("code", code, "message", message));
    }

    static Optional<Path> chooseDirectory() throws Exception {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        // Apple's native chooser is more reliable than opening Swing from a Spring HTTP thread.
        if (os.contains("mac")) {
            Optional<Optional<Path>> mac = tryNativePicker(List.of("osascript", "-e",
                    "POSIX path of (choose folder with prompt \"Select ELIYA folder\")"));
            if (mac.isPresent()) return mac.get();
        }
        if (!GraphicsEnvironment.isHeadless()) {
            try { return chooseWithSwing(); }
            catch (Exception | AWTError ex) {
                LOG.log(Level.WARNING, "Swing folder picker failed; trying OS picker", ex);
            }
        }
        if (os.contains("win")) {
            Optional<Optional<Path>> windows = tryNativePicker(List.of("powershell.exe", "-NoProfile", "-STA", "-Command",
                    "Add-Type -AssemblyName System.Windows.Forms; "
                    + "$OutputEncoding = [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); "
                    + "$dialog = New-Object System.Windows.Forms.FolderBrowserDialog; "
                    + "$dialog.Description = 'Select ELIYA folder'; "
                    + "if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) "
                    + "{ [Console]::WriteLine($dialog.SelectedPath) }"));
            if (windows.isPresent()) return windows.get();
        } else if (os.contains("linux") && (System.getenv("DISPLAY") != null || System.getenv("WAYLAND_DISPLAY") != null)) {
            Optional<Optional<Path>> linux = tryNativePicker(List.of("zenity", "--file-selection", "--directory",
                    "--title=Select ELIYA folder"));
            if (linux.isPresent()) return linux.get();
        }
        throw new IllegalStateException("No usable graphical folder chooser in this environment");
    }

    private static Optional<Path> chooseWithSwing() throws InvocationTargetException, InterruptedException {
        AtomicReference<Path> selected = new AtomicReference<>();
        Runnable show = () -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select ELIYA folder");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setMultiSelectionEnabled(false);
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) {
                selected.set(chooser.getSelectedFile().toPath().toAbsolutePath().normalize());
            }
        };
        if (SwingUtilities.isEventDispatchThread()) show.run();
        else SwingUtilities.invokeAndWait(show);
        return Optional.ofNullable(selected.get());
    }

    /** Outer empty = tool cannot launch; inner empty = user cancelled. */
    private static Optional<Optional<Path>> tryNativePicker(List<String> command) throws InterruptedException {
        Process process;
        try { process = new ProcessBuilder(command).redirectErrorStream(true).start(); }
        catch (java.io.IOException | SecurityException ex) { return Optional.empty(); }
        try {
            if (!process.waitFor(5, TimeUnit.MINUTES)) {
                process.destroyForcibly();
                return Optional.empty();
            }
            String result = new String(process.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            if (process.exitValue() != 0) {
                if (result.toLowerCase(Locale.ROOT).contains("user canceled")
                        || result.toLowerCase(Locale.ROOT).contains("user cancelled")
                        || process.exitValue() == 1 && command.get(0).equals("zenity")) {
                    return Optional.of(Optional.empty());
                }
                LOG.warning("Native folder picker exited with status " + process.exitValue());
                return Optional.empty();
            }
            if (result.isBlank()) return Optional.of(Optional.empty());
            return Optional.of(Optional.of(Path.of(result).toAbsolutePath().normalize()));
        } catch (java.io.IOException | IllegalArgumentException ex) {
            return Optional.empty();
        } finally {
            if (process.isAlive()) process.destroyForcibly();
        }
    }
}
