package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class PlaywrightMcpExecutionEngine implements ExecutionEngine {
    private static final Pattern XPATH = Pattern.compile("(?i)xpath\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']|using\\s+xpath\\s+[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern CSS = Pattern.compile("(?i)css\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']|using\\s+css\\s+[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");

    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;

    public PlaywrightMcpExecutionEngine(LlmClient llmClient,
                                        ReportService reportService,
                                        RunStore runStore,
                                        @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                                        @Value("${itps.playwright.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
    }

    @Override public String name() { return "PLAYWRIGHT_MCP"; }

    @Override
    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        status.setStatus("RUNNING");
        status.setStartedAt(Instant.now());
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        McpClient mcp = null;
        try {
            Files.createDirectories(screenshotDir);
            List<String> args = buildArgs(config, runDir);
            mcp = new McpClient(config.getMcpCommand(), args, Duration.ofSeconds(requestTimeoutSeconds), false);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(tools);
            Set<String> toolNames = adapter.names();
            requireTools(toolNames, "browser_navigate", "browser_snapshot", "browser_click", "browser_type", "browser_wait_for");
            mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("mcp-tools.json").toFile(), tools);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) results.add(executeScenario(mcp, adapter, scenario, config, screenshotDir));
            completeStatus(status, results);
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Playwright MCP execution failed: " + rootMessage(e));
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.callTool("browser_close", Map.of()); } catch (Exception ignored) { }
                try { mcp.close(); } catch (Exception ignored) { }
            }
            status.setFinishedAt(Instant.now());
            runStore.put(status);
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage(join(status.getMessage(), "Report generation failed: " + reportError.getMessage()));
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) { }
            }
        }
    }

    private List<String> buildArgs(RunConfig config, Path runDir) {
        List<String> args = new ArrayList<>(splitArgs(config.getMcpArgs()));
        addIfMissing(args, "--isolated");
        addOptionIfMissing(args, "--output-dir", runDir.toAbsolutePath().toString());
        addOptionIfMissing(args, "--timeout-action", String.valueOf(config.getStepTimeoutSeconds() * 1000));
        addOptionIfMissing(args, "--timeout-navigation", String.valueOf(Math.max(60000, config.getStepTimeoutSeconds() * 3000)));
        if (config.isHeadless()) addIfMissing(args, "--headless");
        String browser = browserChannel(config);
        if (!browser.isBlank()) addOptionIfMissing(args, "--browser", browser);
        return args;
    }

    private String browserChannel(RunConfig config) {
        String id = Optional.ofNullable(config.getBrowserId()).orElse("").toLowerCase(Locale.ROOT);
        String name = Optional.ofNullable(config.getBrowserName()).orElse("").toLowerCase(Locale.ROOT);
        if (id.contains("edge") || name.contains("edge")) return "msedge";
        if (id.contains("firefox") || name.contains("firefox")) return "firefox";
        if (id.contains("webkit") || name.contains("webkit")) return "webkit";
        return "chrome";
    }

    private ScenarioResult executeScenario(McpClient mcp, PlaywrightToolAdapter adapter, TestScenario scenario,
                                           RunConfig config, Path screenshotDir) {
        long started = System.currentTimeMillis();
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        result.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        result.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (!blank(result.getUrl())) steps.add("Navigate to " + result.getUrl());
        if (scenario.getSteps() != null) steps.addAll(scenario.getSteps());
        if (!blank(scenario.getExpected())) steps.add("Verify \"" + substitute(scenario.getExpected(), scenario.getData()) + "\" is displayed");

        boolean failed = false;
        int stepNo = 1;
        for (String raw : steps) {
            StepResult step = executeStep(mcp, adapter, substitute(raw, scenario.getData()), scenario.getId(), stepNo, config, screenshotDir);
            result.getSteps().add(step);
            if (!String.valueOf(step.getStatus()).startsWith("PASSED")) {
                failed = true;
                result.setErrorMessage(step.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        boolean healed = result.getSteps().stream().anyMatch(StepResult::isHealed);
        result.setStatus(failed ? "FAILED" : (healed ? "PASSED_HEALED" : "PASSED"));
        result.setDurationMs(System.currentTimeMillis() - started);
        return result;
    }

    private StepResult executeStep(McpClient mcp, PlaywrightToolAdapter adapter, String instruction, String scenarioId,
                                   int stepNo, RunConfig config, Path screenshotDir) {
        long started = System.currentTimeMillis();
        StepResult out = new StepResult();
        out.setStepNo(stepNo);
        out.setInstruction(instruction);
        out.setPlanSource("PLAYWRIGHT_MCP_DETERMINISTIC");
        Exception last = null;
        int attempts = Math.max(1, config.getRetryCount() + 1);

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                ToolCall call = deterministicCall(instruction, adapter);
                JsonNode response = mcp.callTool(call.tool(), call.arguments());
                assertToolSuccess(call.tool(), response);
                populate(out, call, response);
                out.setStatus("PASSED");
                last = null;
                break;
            } catch (Exception e) {
                last = e;
                if (attempt < attempts) {
                    try { mcp.callTool("browser_wait_for", adapter.waitSeconds(config.getRetryDelayMs() / 1000.0)); }
                    catch (Exception ignored) { }
                }
            }
        }

        if (last != null && config.isEnableSelfHealing() && config.isUseLlm() && llmClient.isConfigured(config)) {
            try {
                JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
                String plan = llmClient.healPlaywrightMcpCall(
                        "Instruction: " + instruction + "\nFailure: " + rootMessage(last) +
                                "\nAvailable tools: " + String.join(",", adapter.names()) +
                                "\nCurrent accessibility snapshot/tool result: " + compact(snapshot.toString(), 18000), config);
                JsonNode root = mapper.readTree(plan);
                double confidence = root.path("confidence").asDouble(0.0);
                if (confidence < config.getHealingConfidenceThreshold())
                    throw new IllegalStateException("Healing confidence " + confidence + " is below threshold " + config.getHealingConfidenceThreshold());
                JsonNode calls = root.path("calls");
                if (!calls.isArray() || calls.isEmpty()) throw new IllegalStateException("LLM returned no Playwright MCP healing calls");
                List<String> history = new ArrayList<>();
                for (JsonNode callNode : calls) {
                    String tool = callNode.path("tool").asText();
                    if (!adapter.names().contains(tool)) throw new IllegalStateException("LLM selected unavailable Playwright MCP tool: " + tool);
                    Map<String,Object> rawArgs = mapper.convertValue(callNode.path("arguments"), Map.class);
                    Map<String,Object> args = adapter.normalizeGenerated(tool, rawArgs);
                    JsonNode response = mcp.callTool(tool, args);
                    assertToolSuccess(tool, response);
                    history.add(tool + " " + compact(args.toString(), 600));
                    out.setToolName(tool);
                    out.setToolArguments(args.toString());
                    out.setMcpResult(compact(response.toString(), 4000));
                }
                out.setHealed(true);
                out.setHealingAttempts(1);
                out.setHealingHistory(String.join("\n", history));
                out.setPlanSource("PLAYWRIGHT_MCP_LLM_HEALING");
                out.setStatus("PASSED_HEALED");
                out.setEvidence("Recovered using fresh Playwright accessibility snapshot and MCP tool retry.");
                last = null;
            } catch (Exception healError) {
                last = new IllegalStateException(rootMessage(last) + " | Playwright MCP healing failed: " + rootMessage(healError), healError);
            }
        }

        if (last != null) {
            out.setStatus("FAILED");
            out.setErrorMessage(rootMessage(last));
            try {
                JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
                out.setPageInventory(compact(snapshot.toString(), 10000));
            } catch (Exception ignored) { }
        }
        if (shouldScreenshot(config, out) && adapter.names().contains("browser_take_screenshot")) {
            try {
                String filename = "screenshots/" + safeName(scenarioId) + "-step-" + stepNo + ".png";
                mcp.callTool("browser_take_screenshot", adapter.screenshot(filename));
                out.setScreenshot(Path.of(filename).getFileName().toString());
            } catch (Exception ignored) { }
        }
        out.setDurationMs(System.currentTimeMillis() - started);
        return out;
    }

    private ToolCall deterministicCall(String instruction, PlaywrightToolAdapter adapter) {
        String text = instruction.trim();
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> q = quotedValues(text);
        String target = explicitTarget(text);
        if (lower.startsWith("navigate to ") || lower.startsWith("open ") || lower.startsWith("go to ")) {
            String url = text.replaceFirst("(?i)^(navigate to|open|go to)\\s+", "").trim();
            return new ToolCall("browser_navigate", adapter.navigate(stripQuotes(url)));
        }
        if (lower.startsWith("verify ") || lower.startsWith("assert ") || lower.startsWith("validate ")) {
            String expected = q.isEmpty() ? text.replaceFirst("(?i)^(verify|assert|validate)\\s+", "").replaceFirst("(?i)\\s+is displayed.*$", "").trim() : q.get(0);
            return new ToolCall("browser_wait_for", adapter.waitForText(expected));
        }
        if (lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ")) {
            if (q.isEmpty()) throw new IllegalArgumentException("Type step needs a quoted value");
            String field = q.size() > 1 ? q.get(1) : "focused input";
            return new ToolCall("browser_type", adapter.type(field, blank(target) ? selectorForText(field) : target, q.get(0)));
        }
        if (lower.startsWith("select ")) {
            if (q.isEmpty()) throw new IllegalArgumentException("Select step needs a quoted option");
            String field = q.size() > 1 ? q.get(1) : "dropdown";
            return new ToolCall("browser_select_option", adapter.select(field, blank(target) ? selectorForText(field) : target, q.get(0)));
        }
        if (lower.startsWith("press ")) {
            String key = q.isEmpty() ? text.replaceFirst("(?i)^press\\s+", "").split("\\s+on\\s+")[0].trim() : q.get(0);
            return new ToolCall("browser_press_key", adapter.pressKey(key));
        }
        if (lower.startsWith("upload ")) {
            if (q.isEmpty()) throw new IllegalArgumentException("Upload step needs a quoted absolute file path");
            return new ToolCall("browser_file_upload", adapter.upload(q.get(0)));
        }
        if (lower.startsWith("hover ")) {
            String label = q.isEmpty() ? text.replaceFirst("(?i)^hover(?: over)?\\s+", "").trim() : q.get(0);
            return new ToolCall("browser_hover", adapter.hover(label, blank(target) ? selectorForText(label) : target));
        }
        if (lower.startsWith("double-click") || lower.startsWith("double click") || lower.startsWith("click ") || lower.startsWith("click on ")) {
            String label = q.isEmpty() ? text.replaceFirst("(?i)^(double[- ]click|click)(?: on)?\\s+", "").trim() : q.get(0);
            return new ToolCall("browser_click", adapter.click(label, blank(target) ? selectorForText(label) : target, lower.startsWith("double")));
        }
        throw new IllegalArgumentException("Unsupported Playwright MCP step: " + instruction);
    }

    private String explicitTarget(String text) {
        Matcher x = XPATH.matcher(text);
        if (x.find()) return "xpath=" + firstNonBlank(x.group(1), x.group(2));
        Matcher c = CSS.matcher(text);
        if (c.find()) return firstNonBlank(c.group(1), c.group(2));
        return "";
    }

    private String selectorForText(String text) {
        String escaped = stripQuotes(text).replace("\\", "\\\\").replace("\"", "\\\"");
        return "text=\"" + escaped + "\"";
    }

    private void populate(StepResult out, ToolCall call, JsonNode response) {
        out.setToolName(call.tool());
        out.setToolArguments(call.arguments().toString());
        out.setActionJson("{\"tool\":\"" + call.tool() + "\",\"arguments\":" + call.arguments() + "}");
        out.setMcpResult(compact(response.toString(), 4000));
        out.setEvidence("Playwright MCP tool completed successfully.");
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) throw new IllegalStateException(tool + " returned no result");
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException(tool + " failed: " + compact(result.toString(), 3000));
    }

    private void requireTools(Set<String> tools, String... required) {
        for (String tool : required) if (!tools.contains(tool)) throw new IllegalStateException("Playwright MCP tool not available: " + tool);
    }

    private List<String> splitArgs(String raw) {
        if (blank(raw)) return new ArrayList<>();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|(\\S+)").matcher(raw);
        while (m.find()) out.add(firstNonBlank(m.group(1), m.group(2), m.group(3)));
        return out;
    }
    private void addIfMissing(List<String> args, String flag) { if (!args.contains(flag)) args.add(flag); }
    private void addOptionIfMissing(List<String> args, String option, String value) {
        if (!args.contains(option)) { args.add(option); args.add(value); }
    }
    private List<String> quotedValues(String text) { List<String> out = new ArrayList<>(); Matcher m = QUOTED.matcher(text); while (m.find()) out.add(m.group(1)); return out; }
    private String substitute(String value, Map<String,Object> data) { String out = value == null ? "" : value; if (data != null) for (var e : data.entrySet()) out = out.replace("${" + e.getKey() + "}", String.valueOf(e.getValue())); return out; }
    private String resolveUrl(String url, String base) { return !blank(url) ? url.trim() : (blank(base) ? "" : base.trim()); }
    private void completeStatus(RunStatus status, List<ScenarioResult> results) { status.setScenarios(results); status.setTotal(results.size()); int p=(int)results.stream().filter(r->String.valueOf(r.getStatus()).startsWith("PASSED")).count(); status.setPassed(p); status.setFailed(results.size()-p); status.setStatus(status.getFailed()==0?"PASSED":"COMPLETED_WITH_FAILURES"); status.setMessage(""); }
    private boolean shouldScreenshot(RunConfig c, StepResult r) { String mode=Optional.ofNullable(c.getScreenshotMode()).orElse("ALL").toUpperCase(Locale.ROOT); return "ALL".equals(mode)||("FAILURE_ONLY".equals(mode)&&!String.valueOf(r.getStatus()).startsWith("PASSED")); }
    private String safeName(String s) { return Optional.ofNullable(s).orElse("test").replaceAll("[^A-Za-z0-9._-]", "_"); }
    private String stripQuotes(String s) { return s == null ? "" : s.trim().replaceAll("^[\\\"']|[\\\"']$", ""); }
    private String firstNonBlank(String... values) { for (String v: values) if (!blank(v)) return v; return ""; }
    private String rootMessage(Throwable e) { Throwable t=e; while(t.getCause()!=null)t=t.getCause(); return t.getMessage()==null?t.getClass().getSimpleName():t.getMessage(); }
    private String compact(String s,int max){ if(s==null)return""; String one=s.replaceAll("\\s+"," ").trim(); return one.length()<=max?one:one.substring(0,max)+"..."; }
    private String join(String a,String b){ return blank(a)?b:a+" | "+b; }
    private boolean blank(String s){ return s==null||s.trim().isEmpty(); }
    private record ToolCall(String tool, Map<String,Object> arguments) { }
}
