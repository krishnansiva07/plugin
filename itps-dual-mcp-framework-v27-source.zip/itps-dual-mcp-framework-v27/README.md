# ITPS Dual MCP Framework V27 — Windows Setup

This application runs the same Excel scenarios through either **Vibium MCP** or **Playwright MCP**. Vibium uses the portable folder configured in `application.properties`. Playwright MCP is started automatically with `npx` only when the Playwright runner is selected.

## 1. Windows prerequisites

Install:

- Windows 10 or Windows 11, 64-bit
- Java JDK 17
- Node.js 18 or later; Node.js 20 LTS is recommended
- Google Chrome or Microsoft Edge
- Maven 3.9.x only on the machine used to build the JAR

Verify in a new Command Prompt:

```cmd
java -version
javac -version
node -v
npm -v
npx -v
mvn -version
```

Java must report version 17. Maven is not required after the executable JAR has been built.

## 2. Vibium portable setup

Vibium alone needs a tools folder. Copy the complete working portable installation to:

```text
C:\tools\vibium-portable
```

Confirm this file exists:

```cmd
dir C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
```

Playwright MCP does not need a tools folder. When selected, the JAR launches:

```cmd
npx.cmd -y @playwright/mcp@latest --isolated
```

The first Playwright run needs npm network access, or the package must already exist in the npm cache.

## 3. Configuration

The default file is `src\main\resources\application.properties`. For deployment, place an external `application.properties` beside the JAR:

```properties
spring.application.name=ITPSDualMcpFramework
server.port=8090
spring.servlet.multipart.max-file-size=20MB
spring.servlet.multipart.max-request-size=25MB

runner.output-dir=target/itps-vibium-runs

itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
itps.vibium.mcp.startup-timeout-seconds=20
itps.vibium.mcp.request-timeout-seconds=90
itps.vibium.skip-browser-download=true

itps.playwright.mcp.command=npx.cmd
itps.playwright.mcp.args=-y @playwright/mcp@latest --isolated
itps.playwright.mcp.request-timeout-seconds=120

recorder.output-dir=target/itps-vibium-recordings
```

## 4. Build the executable JAR

Open Command Prompt in the extracted project folder:

```cmd
mvn clean package -DskipTests
```

The executable JAR is created as:

```text
target\itps-vibium-mcp-framework-27.0.0-DUAL-MCP.jar
```

Do not distribute a `.jar.original` file.

## 5. Run the application

```cmd
java -jar target\itps-vibium-mcp-framework-27.0.0-DUAL-MCP.jar
```

For an external properties file beside the JAR:

```cmd
java -jar itps-vibium-mcp-framework-27.0.0-DUAL-MCP.jar --spring.config.additional-location=file:./application.properties
```

Open:

```text
http://localhost:8090
```

Stop with `Ctrl+C`.

## 6. Excel format

The workbook supports multiple worksheets. After upload, select one or more sheets with the checkboxes.

Supported headers are:

| Header | Purpose |
|---|---|
| `Run` | `true`, `yes`, `1`, `run`, `execute`, or `enabled` |
| `Id` | Unique test ID |
| `Name` | Test name |
| `URL` | Application URL |
| `Steps` | Actions separated by a new line or `|` |
| `Expected` | Text to verify after the steps |
| `Data.*` | Optional test-data columns |
| `TestDataJson` | Optional JSON test data |

Example `Steps` cell:

```text
Click "NEW-IP" capsule | Click "Search" icon | Wait for "New search" | Click "New search" | Type "BCEF" in "Search" using xpath="//input[@name='search']" | Click "BCEF" using xpath="//*[normalize-space()='BCEF']"
```

Explicit XPath or CSS is preferred for complex Angular controls:

```text
Click "BCEF" using xpath="//*[normalize-space()='BCEF']"
Type "11/07/2026" in "Start date" using css="input[name='startDate']"
```

## 7. Runner behaviour

- **Vibium MCP selected:** starts the configured portable `vibium.cmd`, executes the selected sheets, applies Vibium deterministic handling and optional LLM healing, writes reports, then stops the MCP process.
- **Playwright MCP selected:** starts `npx @playwright/mcp@latest`, reads the live tool schemas using `tools/list`, validates every call before sending it, executes selected sheets, uses a fresh accessibility snapshot for optional LLM healing, writes reports, closes the browser, then stops the MCP process.

Single input steps use `browser_type`; `browser_fill_form` is not used for individual Excel steps. Click, type, hover, select, wait, press-key and upload arguments are generated according to the live Playwright MCP schema.

## 8. Reports and diagnostics

Each run is stored under:

```text
target\itps-vibium-runs\<run-id>\
```

Important files include:

```text
report.html
logs.html
report.xlsx
report.json
mcp-tools.json
mcp-transcript.json
mcp-process.log
screenshots\
```

When Playwright fails, first inspect `mcp-transcript.json`. The outgoing `tools/call` must contain required fields such as `target` for `browser_click`, `target` and `text` for `browser_type`, and `values` for `browser_select_option`.

## 9. Common Windows errors

### `node`, `npm`, or `npx` is not recognized

Add this to the system `Path`, then open a new Command Prompt:

```text
C:\Program Files\nodejs
```

### Vibium command not found

Confirm the configured path and file:

```cmd
dir C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
```

### Playwright package cannot be downloaded

Run once on a network-enabled machine:

```cmd
npx.cmd -y @playwright/mcp@latest --help
```

Then retry the application. Corporate npm proxy and certificate settings may be required.

### Port 8090 is already used

```cmd
netstat -ano | findstr :8090
```

Change `server.port` in `application.properties`, for example to `8091`.
