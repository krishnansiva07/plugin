package com.astra.ai.model;

import com.astra.ai.model.Enums.*;
import java.util.HashMap;
import java.util.Map;

public class WorkbenchRequest {
    private String projectPath;
    private FrameworkType frameworkType = FrameworkType.AUTO;
    private ActionType actionType = ActionType.GENERATE_AUTOMATION;
    private AgentMode agentMode = AgentMode.GENERATE_VALIDATE;
    private ReplacementStrategy replacementStrategy = ReplacementStrategy.ASK_EVERY_TIME_BEFORE_REPLACE;
    private ValidationLevel validationLevel = ValidationLevel.STATIC_STRUCTURE_CHECK;
    private String inputType;
    private String selectedAction;
    private String prompt;
    private String gherkin;
    private String domFolder;
    private String recordedJsonPath;
    private String targetFilePath;
    private String failedLocator;
    private String stackTrace;
    private boolean applyChanges = false;
    private boolean approvalGranted = false;
    private boolean generateReport = true;
    private boolean includeFileReferences = true;
    private Map<String, Object> options = new HashMap<>();

    public String getProjectPath() { return projectPath; }
    public void setProjectPath(String projectPath) { this.projectPath = projectPath; }
    public FrameworkType getFrameworkType() { return frameworkType; }
    public void setFrameworkType(FrameworkType frameworkType) { this.frameworkType = frameworkType; }
    public ActionType getActionType() { return actionType; }
    public void setActionType(ActionType actionType) { this.actionType = actionType; }
    public AgentMode getAgentMode() { return agentMode; }
    public void setAgentMode(AgentMode agentMode) { this.agentMode = agentMode; }
    public ReplacementStrategy getReplacementStrategy() { return replacementStrategy; }
    public void setReplacementStrategy(ReplacementStrategy replacementStrategy) { this.replacementStrategy = replacementStrategy; }
    public ValidationLevel getValidationLevel() { return validationLevel; }
    public void setValidationLevel(ValidationLevel validationLevel) { this.validationLevel = validationLevel; }
    public String getInputType() { return inputType; }
    public void setInputType(String inputType) { this.inputType = inputType; }
    public String getSelectedAction() { return selectedAction; }
    public void setSelectedAction(String selectedAction) { this.selectedAction = selectedAction; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getGherkin() { return gherkin; }
    public void setGherkin(String gherkin) { this.gherkin = gherkin; }
    public String getDomFolder() { return domFolder; }
    public void setDomFolder(String domFolder) { this.domFolder = domFolder; }
    public String getRecordedJsonPath() { return recordedJsonPath; }
    public void setRecordedJsonPath(String recordedJsonPath) { this.recordedJsonPath = recordedJsonPath; }
    public String getTargetFilePath() { return targetFilePath; }
    public void setTargetFilePath(String targetFilePath) { this.targetFilePath = targetFilePath; }
    public String getFailedLocator() { return failedLocator; }
    public void setFailedLocator(String failedLocator) { this.failedLocator = failedLocator; }
    public String getStackTrace() { return stackTrace; }
    public void setStackTrace(String stackTrace) { this.stackTrace = stackTrace; }
    public boolean isApplyChanges() { return applyChanges; }
    public void setApplyChanges(boolean applyChanges) { this.applyChanges = applyChanges; }
    public boolean isApprovalGranted() { return approvalGranted; }
    public void setApprovalGranted(boolean approvalGranted) { this.approvalGranted = approvalGranted; }
    public boolean isGenerateReport() { return generateReport; }
    public void setGenerateReport(boolean generateReport) { this.generateReport = generateReport; }
    public boolean isIncludeFileReferences() { return includeFileReferences; }
    public void setIncludeFileReferences(boolean includeFileReferences) { this.includeFileReferences = includeFileReferences; }
    public Map<String, Object> getOptions() { return options; }
    public void setOptions(Map<String, Object> options) { this.options = options; }
}
