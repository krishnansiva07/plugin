package com.astra.ai.model;

import com.astra.ai.model.Enums.FrameworkType;
import java.util.ArrayList;
import java.util.List;

public class AgentResponse {
    private String status;
    private String message;
    private FrameworkType frameworkDetected;
    private String plan;
    private String answer;
    private boolean applied;
    private boolean approvalRequired;
    private final List<String> filesAnalyzed = new ArrayList<>();
    private final List<String> proposedFiles = new ArrayList<>();
    private final List<String> impactedFiles = new ArrayList<>();
    private final List<String> warnings = new ArrayList<>();
    private final List<String> safetyChecks = new ArrayList<>();
    private final List<String> validationResults = new ArrayList<>();
    private final List<String> suggestedChanges = new ArrayList<>();
    private final List<String> reusableMethods = new ArrayList<>();
    private final List<String> duplicateSteps = new ArrayList<>();
    private String generatedFeaturePreview;
    private String generatedStepDefinitionPreview;
    private String generatedPageObjectPreview;
    private String generatedDocumentationPath;
    private String reportPath;

    public static AgentResponse ok(String message) { AgentResponse r = new AgentResponse(); r.setStatus("SUCCESS"); r.setMessage(message); return r; }
    public static AgentResponse failed(String message) { AgentResponse r = new AgentResponse(); r.setStatus("FAILED"); r.setMessage(message); return r; }

    public String getStatus() { return status; } public void setStatus(String status) { this.status = status; }
    public String getMessage() { return message; } public void setMessage(String message) { this.message = message; }
    public FrameworkType getFrameworkDetected() { return frameworkDetected; } public void setFrameworkDetected(FrameworkType frameworkDetected) { this.frameworkDetected = frameworkDetected; }
    public String getPlan() { return plan; } public void setPlan(String plan) { this.plan = plan; }
    public String getAnswer() { return answer; } public void setAnswer(String answer) { this.answer = answer; }
    public boolean isApplied() { return applied; } public void setApplied(boolean applied) { this.applied = applied; }
    public boolean isApprovalRequired() { return approvalRequired; } public void setApprovalRequired(boolean approvalRequired) { this.approvalRequired = approvalRequired; }
    public List<String> getFilesAnalyzed() { return filesAnalyzed; }
    public List<String> getProposedFiles() { return proposedFiles; }
    public List<String> getImpactedFiles() { return impactedFiles; }
    public List<String> getWarnings() { return warnings; }
    public List<String> getSafetyChecks() { return safetyChecks; }
    public List<String> getValidationResults() { return validationResults; }
    public List<String> getSuggestedChanges() { return suggestedChanges; }
    public List<String> getReusableMethods() { return reusableMethods; }
    public List<String> getDuplicateSteps() { return duplicateSteps; }
    public String getGeneratedFeaturePreview() { return generatedFeaturePreview; } public void setGeneratedFeaturePreview(String generatedFeaturePreview) { this.generatedFeaturePreview = generatedFeaturePreview; }
    public String getGeneratedStepDefinitionPreview() { return generatedStepDefinitionPreview; } public void setGeneratedStepDefinitionPreview(String generatedStepDefinitionPreview) { this.generatedStepDefinitionPreview = generatedStepDefinitionPreview; }
    public String getGeneratedPageObjectPreview() { return generatedPageObjectPreview; } public void setGeneratedPageObjectPreview(String generatedPageObjectPreview) { this.generatedPageObjectPreview = generatedPageObjectPreview; }
    public String getGeneratedDocumentationPath() { return generatedDocumentationPath; } public void setGeneratedDocumentationPath(String generatedDocumentationPath) { this.generatedDocumentationPath = generatedDocumentationPath; }
    public String getReportPath() { return reportPath; } public void setReportPath(String reportPath) { this.reportPath = reportPath; }
}
