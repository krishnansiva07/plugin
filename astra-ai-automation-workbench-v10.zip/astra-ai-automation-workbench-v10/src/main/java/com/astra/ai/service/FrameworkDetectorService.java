package com.astra.ai.service;

import com.astra.ai.model.Enums.FrameworkType;
import org.springframework.stereotype.Service;
import java.nio.file.*;

@Service
public class FrameworkDetectorService {
    public FrameworkType detect(String projectPath, FrameworkType requested) {
        if (requested != null && requested != FrameworkType.AUTO) return requested;
        if (projectPath == null || projectPath.isBlank()) return FrameworkType.UNKNOWN;
        Path root = Path.of(projectPath);
        boolean hasPom = Files.exists(root.resolve("pom.xml"));
        boolean hasPackage = Files.exists(root.resolve("package.json"));
        boolean hasPlaywright = Files.exists(root.resolve("playwright.config.ts")) || Files.exists(root.resolve("playwright.config.js"));
        boolean hasCypress = Files.exists(root.resolve("cypress.config.ts")) || Files.exists(root.resolve("cypress.config.js"));
        boolean hasPytest = Files.exists(root.resolve("pytest.ini")) || Files.exists(root.resolve("requirements.txt"));
        boolean hasJavaFeatures = Files.exists(root.resolve("src/test/resources/features"));
        boolean hasFeatures = Files.exists(root.resolve("features")) || Files.exists(root.resolve("src/features"));
        if (hasPom && hasJavaFeatures) return FrameworkType.JAVA_SELENIUM_CUCUMBER;
        if (hasPom) return FrameworkType.JAVA_SELENIUM_TESTNG;
        if (hasPackage && hasPlaywright && hasFeatures) return FrameworkType.PLAYWRIGHT_TYPESCRIPT_CUCUMBER;
        if (hasPackage && hasPlaywright) return FrameworkType.PLAYWRIGHT_TYPESCRIPT;
        if (hasPackage && hasCypress) return FrameworkType.CYPRESS_TYPESCRIPT;
        if (hasPytest && hasFeatures) return FrameworkType.PYTHON_SELENIUM_BEHAVE;
        if (hasPytest) return FrameworkType.PYTHON_SELENIUM_PYTEST;
        return FrameworkType.UNKNOWN;
    }
}
