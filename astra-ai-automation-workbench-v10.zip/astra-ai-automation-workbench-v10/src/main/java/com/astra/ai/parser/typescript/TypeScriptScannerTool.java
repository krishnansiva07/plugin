package com.astra.ai.parser.typescript;

import com.astra.ai.model.IndexModels.TsClassInfo;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.*;
import java.util.Optional;
import java.util.regex.*;

@Component
public class TypeScriptScannerTool {
    private static final Pattern CLASS = Pattern.compile("(export\\s+)?class\\s+(\\w+)");
    private static final Pattern METHOD = Pattern.compile("(async\\s+)?(\\w+)\\s*\\([^)]*\\)\\s*[:\\w<>\\[\\]\\s|]*\\{");
    private static final Pattern STEP = Pattern.compile("(Given|When|Then|And|But)\\s*\\(([^,]+),");
    private static final Pattern LOCATOR = Pattern.compile("(getByRole|getByLabel|getByPlaceholder|getByTestId|locator)\\s*\\(");

    public Optional<TsClassInfo> parse(Path root, Path file) {
        try {
            String content = Files.readString(file);
            TsClassInfo info = new TsClassInfo();
            info.filePath = root.relativize(file).toString().replace("\\", "/");
            Matcher c = CLASS.matcher(content);
            if (c.find()) info.className = c.group(2);
            info.usesPlaywrightPage = content.contains("Page") || content.contains("@playwright/test");
            info.usesCustomWorld = content.contains("CustomWorld") || content.contains("this.page") || content.contains("this.context");
            content.lines().filter(l -> l.trim().startsWith("import ")).forEach(l -> info.imports.add(l.trim()));
            Matcher m = METHOD.matcher(content);
            while (m.find()) {
                String name = m.group(2);
                if (!name.matches("if|for|while|switch|catch|function")) info.methods.add((m.group(1) == null ? "" : "async ") + name + "()");
            }
            Matcher s = STEP.matcher(content);
            while (s.find()) info.cucumberSteps.add(s.group(1) + "(" + s.group(2).replace("'", "").replace("\"", "") + ")");
            Matcher l = LOCATOR.matcher(content);
            while (l.find()) info.locators.add(l.group(1) + "(...) in " + info.filePath);
            return Optional.of(info);
        } catch (IOException e) { return Optional.empty(); }
    }
}
