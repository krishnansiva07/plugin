package com.astra.ai.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class LlmService {
    @Value("${astra.llm.enabled:false}")
    private boolean enabled;

    public String ask(String systemInstruction, String userPrompt) {
        if (!enabled) return "LLM disabled. Set astra.llm.enabled=true and wire ChatLanguageModel.generate(...) here.";
        return "LLM placeholder: connect your LangChain4j ChatLanguageModel/OpenAIChatModel implementation here.";
    }
}
