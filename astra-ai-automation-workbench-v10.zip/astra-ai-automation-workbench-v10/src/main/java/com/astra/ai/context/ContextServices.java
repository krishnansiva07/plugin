package com.astra.ai.context;

import com.astra.ai.model.IndexModels.*;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class ContextServices {
    public List<String> findReusableMethods(String prompt, ProjectIndex index) {
        String p = prompt == null ? "" : prompt.toLowerCase(Locale.ROOT);
        Set<String> result = new LinkedHashSet<>();
        for (String m : index.getMethodCandidates()) {
            String mm = m.toLowerCase(Locale.ROOT);
            if ((p.contains("login") && mm.contains("login")) || (p.contains("user") && mm.contains("user")) ||
                (p.contains("password") && mm.contains("password")) || (p.contains("search") && mm.contains("search")) ||
                (p.contains("click") && mm.contains("click")) || (p.contains("verify") && (mm.contains("verify") || mm.contains("display") || mm.contains("visible"))) ||
                (p.contains("dashboard") && mm.contains("dashboard"))) result.add(m);
        }
        return result.stream().limit(60).collect(Collectors.toList());
    }

    public List<String> findDuplicateSteps(String prompt, ProjectIndex index) {
        String p = prompt == null ? "" : prompt.toLowerCase(Locale.ROOT);
        Set<String> result = new LinkedHashSet<>();
        for (FeatureInfo f : index.getFeatures()) for (String step : f.steps) {
            int match = 0;
            for (String w : step.split("\\s+")) if (w.length() > 4 && p.contains(w)) match++;
            if (p.contains(step) || match >= 2) result.add(f.filePath + " :: " + step);
        }
        return result.stream().limit(40).collect(Collectors.toList());
    }

    public String detectWorldContext(ProjectIndex index) {
        boolean customWorld = index.getTsClasses().stream().anyMatch(t -> t.usesCustomWorld);
        boolean page = index.getTsClasses().stream().anyMatch(t -> t.usesPlaywrightPage);
        if (customWorld) return "CustomWorld / this.page pattern detected";
        if (page) return "Playwright Page constructor/import pattern detected";
        return "No Playwright context pattern detected";
    }
}
