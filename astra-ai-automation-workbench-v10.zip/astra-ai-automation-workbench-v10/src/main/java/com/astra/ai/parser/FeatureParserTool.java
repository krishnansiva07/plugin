package com.astra.ai.parser;

import com.astra.ai.model.IndexModels.FeatureInfo;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.*;
import java.util.Optional;

@Component
public class FeatureParserTool {
    public Optional<FeatureInfo> parse(Path root, Path file) {
        try {
            FeatureInfo info = new FeatureInfo();
            info.filePath = root.relativize(file).toString().replace("\\", "/");
            for (String raw : Files.readAllLines(file)) {
                String line = raw.trim();
                if (line.startsWith("@")) info.tags.add(line);
                if (line.startsWith("Feature:")) info.featureName = line.substring("Feature:".length()).trim();
                if (line.startsWith("Scenario:") || line.startsWith("Scenario Outline:")) info.scenarios.add(line);
                if (line.matches("^(Given|When|Then|And|But)\\s+.*")) info.steps.add(normalizeStep(line));
            }
            return Optional.of(info);
        } catch (IOException e) { return Optional.empty(); }
    }
    public String normalizeStep(String step) { return step.replaceFirst("^(Given|When|Then|And|But)\\s+", "").trim().toLowerCase(); }
}
