package com.astra.ai.failure;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class FailureAnalysisService {
    public List<String> analyze(String stackTrace) {
        List<String> out = new ArrayList<>();
        String s = stackTrace == null ? "" : stackTrace.toLowerCase();
        if (s.contains("nosuchelement") || s.contains("strict mode violation")) out.add("Failure category: Locator issue");
        else if (s.contains("timeout")) out.add("Failure category: Wait / application slowness");
        else if (s.contains("assert")) out.add("Failure category: Assertion mismatch");
        else if (s.contains("nullpointer")) out.add("Failure category: Code/data setup issue");
        else out.add("Failure category: Unknown; provide stack trace/report for better analysis.");
        out.add("Retry recommendation: retry only for transient timeout/environment issues, not locator/assertion issues.");
        return out;
    }
}
