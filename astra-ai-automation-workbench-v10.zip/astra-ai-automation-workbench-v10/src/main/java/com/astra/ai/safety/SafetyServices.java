package com.astra.ai.safety;

import com.astra.ai.model.*;
import com.astra.ai.model.Enums.*;
import com.astra.ai.model.IndexModels.ProjectIndex;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class SafetyServices {
    public void addSafetyChecks(WorkbenchRequest req, AgentResponse res) {
        res.getSafetyChecks().add("Project must be indexed before every action.");
        res.getSafetyChecks().add("Reuse existing methods/classes before creating new ones.");
        res.getSafetyChecks().add("Duplicate step detection must run before step generation.");
        res.getSafetyChecks().add("No method/class/locator replacement without reference and impact check.");
        res.getSafetyChecks().add("Backup is mandatory before file write.");
        res.getSafetyChecks().add("Preview and report generated before apply.");
        res.setApprovalRequired(req.isApplyChanges() && !req.isApprovalGranted());
    }

    public List<String> impactWarnings(String target, ProjectIndex index) {
        List<String> out = new ArrayList<>();
        if (target == null || target.isBlank()) { out.add("No target provided. Direct replacement blocked."); return out; }
        long refs = index.getMethodCandidates().stream().filter(m -> m.toLowerCase().contains(target.toLowerCase())).count();
        if (refs > 1) out.add("Possible shared method/class detected. References found: " + refs + ". Prefer wrapper/new method.");
        else out.add("No high reference risk from index. Compile validation still required.");
        return out;
    }

    public boolean canApply(WorkbenchRequest req, AgentResponse res) {
        if (!req.isApplyChanges()) { res.getWarnings().add("Preview mode: applyChanges=false."); return false; }
        if (!req.isApprovalGranted()) { res.getWarnings().add("Approval not granted. File write blocked."); return false; }
        if (req.getReplacementStrategy() == ReplacementStrategy.NEVER_REPLACE_ONLY_SUGGEST) { res.getWarnings().add("Replacement strategy blocks changes."); return false; }
        if (req.getAgentMode() != AgentMode.GENERATE_VALIDATE_APPLY) { res.getWarnings().add("Agent mode is not GENERATE_VALIDATE_APPLY. File write blocked."); return false; }
        return true;
    }
}
