package com.astra.ai.controller;

import com.astra.ai.model.*;
import com.astra.ai.model.Enums.ActionType;
import com.astra.ai.model.IndexModels.ProjectIndex;
import com.astra.ai.service.AgentOrchestratorService;
import com.astra.ai.service.ProjectIndexService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class WorkbenchController {
    private final AgentOrchestratorService orchestrator;
    private final ProjectIndexService indexer;

    public WorkbenchController(AgentOrchestratorService orchestrator, ProjectIndexService indexer) {
        this.orchestrator = orchestrator; this.indexer = indexer;
    }

    @PostMapping("/project/index")
    public ProjectIndex index(@RequestBody WorkbenchRequest request) {
        return indexer.index(request.getProjectPath(), request.getFrameworkType());
    }

    @PostMapping("/agent/execute")
    public AgentResponse execute(@RequestBody WorkbenchRequest request) {
        return orchestrator.execute(request);
    }

    @PostMapping("/framework/chat")
    public AgentResponse frameworkChat(@RequestBody WorkbenchRequest request) {
        request.setActionType(ActionType.FRAMEWORK_CHAT);
        return orchestrator.execute(request);
    }

    @PostMapping("/documentation/generate")
    public AgentResponse documentation(@RequestBody WorkbenchRequest request) {
        request.setActionType(ActionType.GENERATE_DOCUMENTATION);
        return orchestrator.execute(request);
    }
}
