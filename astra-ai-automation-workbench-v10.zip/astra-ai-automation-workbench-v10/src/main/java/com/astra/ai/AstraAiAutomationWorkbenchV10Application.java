package com.astra.ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AstraAiAutomationWorkbenchV10Application {
    public static void main(String[] args) {
        SpringApplication.run(AstraAiAutomationWorkbenchV10Application.class, args);
    }
}
