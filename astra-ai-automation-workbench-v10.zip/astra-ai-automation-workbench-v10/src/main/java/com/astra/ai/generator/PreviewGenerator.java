package com.astra.ai.generator;

import com.astra.ai.model.Enums.FrameworkType;
import com.astra.ai.model.WorkbenchRequest;
import org.springframework.stereotype.Component;

@Component
public class PreviewGenerator {
    public String generateFeature(WorkbenchRequest r) {
        String title = title(r.getPrompt());
        return "Feature: " + title + "\n\n" +
               "  @generated @preview\n" +
               "  Scenario: Validate " + title + "\n" +
               "    Given user is on the application login page\n" +
               "    When user performs the requested business flow\n" +
               "    Then expected result should be displayed\n";
    }

    public String generateSteps(FrameworkType type) {
        return switch (type) {
            case PLAYWRIGHT_TYPESCRIPT, PLAYWRIGHT_TYPESCRIPT_CUCUMBER -> """
                    import { Given, When, Then } from '@cucumber/cucumber';

                    Given('user is on the application login page', async function () {
                      // TODO: Reuse existing navigation/login method from project index.
                    });

                    When('user performs the requested business flow', async function () {
                      // TODO: Reuse existing page object methods. Keep async/await.
                    });

                    Then('expected result should be displayed', async function () {
                      // TODO: Reuse existing assertion method or Playwright expect.
                    });
                    """;
            case PYTHON_SELENIUM_PYTEST, PYTHON_SELENIUM_BEHAVE -> """
                    from behave import given, when, then

                    @given('user is on the application login page')
                    def step_user_on_login_page(context):
                        # TODO: Reuse existing page object method
                        pass

                    @when('user performs the requested business flow')
                    def step_user_performs_flow(context):
                        # TODO: Reuse existing page object methods
                        pass

                    @then('expected result should be displayed')
                    def step_expected_result(context):
                        # TODO: Add assertion using existing utilities
                        pass
                    """;
            default -> """
                    package com.generated.steps;

                    import io.cucumber.java.en.Given;
                    import io.cucumber.java.en.When;
                    import io.cucumber.java.en.Then;

                    public class GeneratedFlowSteps {
                        @Given("user is on the application login page")
                        public void userIsOnApplicationLoginPage() {
                            // TODO: Reuse existing navigation/login page object method.
                        }

                        @When("user performs the requested business flow")
                        public void userPerformsRequestedBusinessFlow() {
                            // TODO: Reuse existing page object methods found by Astra index.
                        }

                        @Then("expected result should be displayed")
                        public void expectedResultShouldBeDisplayed() {
                            // TODO: Add assertion by reusing existing verification method.
                        }
                    }
                    """;
        };
    }

    public String generatePageObject(FrameworkType type) {
        return switch (type) {
            case PLAYWRIGHT_TYPESCRIPT, PLAYWRIGHT_TYPESCRIPT_CUCUMBER -> """
                    import { Page, expect } from '@playwright/test';

                    export class GeneratedFlowPage {
                      constructor(private page: Page) {}

                      // TODO: Add only missing actions. Prefer getByRole/getByLabel/getByTestId.
                    }
                    """;
            case PYTHON_SELENIUM_PYTEST, PYTHON_SELENIUM_BEHAVE -> """
                    class GeneratedFlowPage:
                        def __init__(self, driver):
                            self.driver = driver

                        # TODO: Add only missing actions. Reuse existing base page/wait utilities.
                    """;
            default -> """
                    package com.generated.pages;

                    import org.openqa.selenium.WebDriver;
                    import org.openqa.selenium.support.ui.WebDriverWait;
                    import java.time.Duration;

                    public class GeneratedFlowPage {
                        private final WebDriver driver;
                        private final WebDriverWait wait;

                        public GeneratedFlowPage(WebDriver driver) {
                            this.driver = driver;
                            this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
                        }

                        // TODO: Add only missing page actions. Reuse existing methods first.
                    }
                    """;
        };
    }

    private String title(String prompt) {
        if (prompt == null || prompt.isBlank()) return "Generated Automation Flow";
        String cleaned = prompt.replaceAll("[^a-zA-Z0-9 ]", " ").trim();
        return cleaned.length() > 70 ? cleaned.substring(0, 70) : cleaned;
    }
}
