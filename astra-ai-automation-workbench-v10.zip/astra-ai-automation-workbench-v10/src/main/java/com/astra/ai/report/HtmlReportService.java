package com.astra.ai.report;

import com.astra.ai.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class HtmlReportService {
    @Value("${astra.output.report-folder:astra-reports}")
    private String reportFolder;

    public String writeReport(WorkbenchRequest req, AgentResponse res) {
        try {
            Path root = Path.of(req.getProjectPath() == null || req.getProjectPath().isBlank() ? "." : req.getProjectPath());
            Path dir = root.resolve(reportFolder); Files.createDirectories(dir);
            Path report = dir.resolve("astra-v10-report-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".html");
            String html = """
            <!doctype html><html><head><meta charset='utf-8'><title>Astra V10 Report</title>
            <style>body{font-family:Arial;margin:24px;background:#f8fafc;color:#0f172a}.card{background:white;border-radius:12px;padding:18px;margin:14px 0;box-shadow:0 2px 8px #dbe3ef}h1{color:#0f766e}pre{background:#0f172a;color:#d1fae5;padding:12px;border-radius:8px;white-space:pre-wrap}li{margin:4px 0}</style></head><body>
            <h1>Astra AI Automation Workbench V10 Report</h1>
            <div class='card'><b>Status:</b> %s<br><b>Framework:</b> %s<br><b>Action:</b> %s<br><b>Applied:</b> %s<br><b>Approval Required:</b> %s</div>
            <div class='card'><h2>Plan</h2><pre>%s</pre></div>
            <div class='card'><h2>Answer</h2><pre>%s</pre></div>
            <div class='card'><h2>Reusable Methods</h2><ul>%s</ul></div>
            <div class='card'><h2>Duplicate Steps</h2><ul>%s</ul></div>
            <div class='card'><h2>Generated Feature Preview</h2><pre>%s</pre></div>
            <div class='card'><h2>Generated Step Preview</h2><pre>%s</pre></div>
            <div class='card'><h2>Generated Page Preview</h2><pre>%s</pre></div>
            <div class='card'><h2>Safety Checks</h2><ul>%s</ul></div>
            <div class='card'><h2>Validation Results</h2><ul>%s</ul></div>
            <div class='card'><h2>Warnings</h2><ul>%s</ul></div>
            </body></html>
            """.formatted(s(res.getStatus()), s(String.valueOf(res.getFrameworkDetected())), s(String.valueOf(req.getActionType())), res.isApplied(), res.isApprovalRequired(), s(res.getPlan()), s(res.getAnswer()), list(res.getReusableMethods()), list(res.getDuplicateSteps()), s(res.getGeneratedFeaturePreview()), s(res.getGeneratedStepDefinitionPreview()), s(res.getGeneratedPageObjectPreview()), list(res.getSafetyChecks()), list(res.getValidationResults()), list(res.getWarnings()));
            Files.writeString(report, html);
            return report.toString();
        } catch (IOException e) { return "Report generation failed: " + e.getMessage(); }
    }

    private String list(java.util.List<String> values) { StringBuilder sb = new StringBuilder(); for (String v: values) sb.append("<li>").append(s(v)).append("</li>"); return sb.toString(); }
    private String s(String x) { if (x == null) return ""; return x.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }
}
