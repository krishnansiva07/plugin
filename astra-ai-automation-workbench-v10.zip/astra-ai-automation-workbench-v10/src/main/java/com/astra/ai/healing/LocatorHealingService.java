package com.astra.ai.healing;

import com.astra.ai.model.IndexModels.ProjectIndex;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LocatorHealingService {
    public List<String> suggest(String failedLocator, ProjectIndex index) {
        List<String> suggestions = new ArrayList<>();
        suggestions.add("Healing mode: preview-only.");
        suggestions.add("Failed locator: " + (failedLocator == null ? "not provided" : failedLocator));
        suggestions.add("Preferred order: getByRole/getByLabel/getByPlaceholder/getByTestId/id/name/stable CSS/XPath last.");
        if (!index.getLocatorCandidates().isEmpty()) {
            suggestions.add("Existing locator candidates found: " + index.getLocatorCandidates().size());
            index.getLocatorCandidates().stream().limit(10).forEach(l -> suggestions.add("Candidate: " + l));
        } else suggestions.add("No locator candidates indexed.");
        return suggestions;
    }
}
