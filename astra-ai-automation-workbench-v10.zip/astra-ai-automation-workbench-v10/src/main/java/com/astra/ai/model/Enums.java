package com.astra.ai.model;

public class Enums {
    public enum FrameworkType {
        AUTO,
        JAVA_SELENIUM_CUCUMBER,
        JAVA_SELENIUM_TESTNG,
        PLAYWRIGHT_TYPESCRIPT,
        PLAYWRIGHT_TYPESCRIPT_CUCUMBER,
        CYPRESS_TYPESCRIPT,
        CYPRESS_JAVASCRIPT,
        PYTHON_SELENIUM_PYTEST,
        PYTHON_SELENIUM_BEHAVE,
        REST_ASSURED_CUCUMBER,
        ROBOT_FRAMEWORK,
        UNKNOWN
    }

    public enum ActionType {
        INDEX_PROJECT,
        GENERATE_AUTOMATION,
        GENERATE_CUCUMBER_PREVIEW,
        FIX_LOCATOR,
        ANALYZE_FAILURE,
        GENERATE_DOCUMENTATION,
        FRAMEWORK_CHAT,
        SAFE_CHANGE_PREVIEW,
        RUN_VALIDATION
    }

    public enum AgentMode {
        ASK_ONLY,
        ANALYZE_ONLY,
        PLAN_ONLY,
        GENERATE_ONLY,
        GENERATE_VALIDATE,
        GENERATE_VALIDATE_APPLY,
        FULL_AGENTIC_ACTION_WITH_APPROVAL
    }

    public enum ReplacementStrategy {
        NEVER_REPLACE_ONLY_SUGGEST,
        REPLACE_ONLY_IF_NO_REFERENCES,
        CREATE_NEW_METHOD_INSTEAD_OF_REPLACE,
        REPLACE_WITH_BACKUP_AND_REPORT,
        ASK_EVERY_TIME_BEFORE_REPLACE
    }

    public enum ValidationLevel {
        BASIC,
        STATIC_STRUCTURE_CHECK,
        COMPILE_CHECK,
        FULL_BUILD_VALIDATION
    }
}
