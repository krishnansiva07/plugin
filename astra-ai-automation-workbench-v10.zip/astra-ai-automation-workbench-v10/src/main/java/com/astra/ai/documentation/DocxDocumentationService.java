package com.astra.ai.documentation;

import com.astra.ai.model.IndexModels.ProjectIndex;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.nio.file.*;

@Service
public class DocxDocumentationService {
    @Value("${astra.output.doc-folder:astra-docs}")
    private String docFolder;

    public String generateDocx(String projectPath, ProjectIndex index) {
        try {
            Path root = Path.of(projectPath == null || projectPath.isBlank() ? "." : projectPath);
            Path dir = root.resolve(docFolder);
            Files.createDirectories(dir);
            Path file = dir.resolve("astra-framework-documentation-v10.docx");

            XWPFDocument doc = new XWPFDocument();
            addTitle(doc, "Astra Framework Documentation V10");
            addPara(doc, "Framework: " + index.getFrameworkType());
            addPara(doc, "Build Tool: " + index.getBuildTool());
            addPara(doc, "Language: " + index.getLanguage());
            addHeading(doc, "Architecture");
            addPara(doc, "Requirement / Gherkin / Recorded JSON -> Steps/Specs -> Page Objects -> Driver/Browser -> Application -> Reports");
            addHeading(doc, "Indexed Summary");
            addPara(doc, "Files: " + index.getImportantFiles().size());
            addPara(doc, "Java classes: " + index.getJavaClasses().size());
            addPara(doc, "TypeScript files/classes: " + index.getTsClasses().size());
            addPara(doc, "Python files/classes: " + index.getPyClasses().size());
            addPara(doc, "Feature files: " + index.getFeatures().size());
            addPara(doc, "Methods: " + index.getMethodCandidates().size());
            addPara(doc, "Locators: " + index.getLocatorCandidates().size());
            addHeading(doc, "Safe Agentic Rules");
            addPara(doc, "No direct replace. No blind file write. Always index, plan, impact-check, preview, approve, backup, apply and report.");

            try (FileOutputStream fos = new FileOutputStream(file.toFile())) { doc.write(fos); }
            doc.close();
            return file.toString();
        } catch (Exception e) {
            return "DOCX generation failed: " + e.getMessage();
        }
    }

    private void addTitle(XWPFDocument doc, String text) {
        XWPFParagraph p = doc.createParagraph(); p.setStyle("Title");
        XWPFRun r = p.createRun(); r.setBold(true); r.setFontSize(20); r.setText(text);
    }
    private void addHeading(XWPFDocument doc, String text) {
        XWPFParagraph p = doc.createParagraph();
        XWPFRun r = p.createRun(); r.setBold(true); r.setFontSize(15); r.setText(text);
    }
    private void addPara(XWPFDocument doc, String text) {
        XWPFParagraph p = doc.createParagraph(); p.createRun().setText(text);
    }
}
