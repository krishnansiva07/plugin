package com.astra.ai.service;

import com.astra.ai.context.ContextServices;
import com.astra.ai.documentation.DocxDocumentationService;
import com.astra.ai.failure.FailureAnalysisService;
import com.astra.ai.generator.PreviewGenerator;
import com.astra.ai.healing.LocatorHealingService;
import com.astra.ai.model.*;
import com.astra.ai.model.Enums.*;
import com.astra.ai.model.IndexModels.ProjectIndex;
import com.astra.ai.report.HtmlReportService;
import com.astra.ai.safety.SafetyServices;
import org.springframework.stereotype.Service;

@Service
public class AgentOrchestratorService {
    private final ProjectIndexService indexer;
    private final ContextServices context;
    private final PreviewGenerator generator;
    private final LocatorHealingService healing;
    private final FailureAnalysisService failure;
    private final DocxDocumentationService docs;
    private final SafetyServices safety;
    private final HtmlReportService reports;
    private final LlmService llm;

    public AgentOrchestratorService(ProjectIndexService indexer, ContextServices context, PreviewGenerator generator, LocatorHealingService healing, FailureAnalysisService failure, DocxDocumentationService docs, SafetyServices safety, HtmlReportService reports, LlmService llm) {
        this.indexer = indexer; this.context = context; this.generator = generator; this.healing = healing; this.failure = failure; this.docs = docs; this.safety = safety; this.reports = reports; this.llm = llm;
    }

    public AgentResponse execute(WorkbenchRequest req) {
        ProjectIndex idx = indexer.index(req.getProjectPath(), req.getFrameworkType());
        AgentResponse res = AgentResponse.ok("V10 agentic action completed in safe mode.");
        res.setFrameworkDetected(idx.getFrameworkType());
        res.getFilesAnalyzed().addAll(idx.getImportantFiles());
        res.getWarnings().addAll(idx.getWarnings());
        safety.addSafetyChecks(req, res);

        res.setPlan("""
            V10 Safe Agentic Pipeline:
            1. Detect framework and index project.
            2. Parse Java / TypeScript / Python / Feature files.
            3. Retrieve reusable methods, steps, page objects and locators.
            4. Detect duplicate steps and risky replacements.
            5. Generate preview code or analysis.
            6. Validate safety gates.
            7. Generate HTML report and optional DOCX.
            8. Apply only when applyChanges=true, approvalGranted=true and mode allows it.
            """);

        res.getValidationResults().add("Framework: " + idx.getFrameworkType());
        res.getValidationResults().add("Build tool: " + idx.getBuildTool());
        res.getValidationResults().add("Language: " + idx.getLanguage());
        res.getValidationResults().add("Files indexed: " + idx.getImportantFiles().size());
        res.getValidationResults().add("Java classes: " + idx.getJavaClasses().size());
        res.getValidationResults().add("TypeScript classes/files: " + idx.getTsClasses().size());
        res.getValidationResults().add("Python classes/files: " + idx.getPyClasses().size());
        res.getValidationResults().add("Features parsed: " + idx.getFeatures().size());
        res.getValidationResults().add("Methods indexed: " + idx.getMethodCandidates().size());
        res.getValidationResults().add("Locators indexed: " + idx.getLocatorCandidates().size());
        res.getValidationResults().add(context.detectWorldContext(idx));
        res.getValidationResults().addAll(safety.impactWarnings(req.getSelectedAction(), idx));

        res.getReusableMethods().addAll(context.findReusableMethods(req.getPrompt(), idx));
        res.getDuplicateSteps().addAll(context.findDuplicateSteps(req.getPrompt(), idx));

        switch (req.getActionType()) {
            case FRAMEWORK_CHAT -> res.setAnswer("Framework Chat Answer:\n" + frameworkSummary(idx) + "\nQuestion: " + req.getPrompt() + "\nLLM: " + llm.ask("Answer from project context only", req.getPrompt()));
            case GENERATE_DOCUMENTATION -> { String path = docs.generateDocx(req.getProjectPath(), idx); res.setGeneratedDocumentationPath(path); res.setAnswer("DOCX documentation generated: " + path); }
            case FIX_LOCATOR -> { res.setAnswer("Locator healing preview generated."); res.getSuggestedChanges().addAll(healing.suggest(req.getFailedLocator(), idx)); }
            case ANALYZE_FAILURE -> { res.setAnswer("Failure analysis generated."); res.getSuggestedChanges().addAll(failure.analyze(req.getStackTrace() != null ? req.getStackTrace() : req.getPrompt())); }
            case INDEX_PROJECT -> res.setAnswer("Project indexed successfully.");
            case RUN_VALIDATION -> res.setAnswer("Validation preview only. Wire Maven/NPM/Pytest execution in V10 production mode.");
            default -> {
                res.setAnswer("Automation preview generated. Existing methods and duplicate steps were checked first.");
                res.setGeneratedFeaturePreview(generator.generateFeature(req));
                res.setGeneratedStepDefinitionPreview(generator.generateSteps(idx.getFrameworkType()));
                res.setGeneratedPageObjectPreview(generator.generatePageObject(idx.getFrameworkType()));
                res.getProposedFiles().add("Generated feature/spec/step preview based on framework: " + idx.getFrameworkType());
                if (res.getReusableMethods().isEmpty()) res.getProposedFiles().add("Generated page object preview because no reusable methods matched.");
                else res.getSuggestedChanges().add("Reusable methods found. Prefer reuse before creating page object.");
            }
        }

        boolean canApply = safety.canApply(req, res);
        res.setApplied(canApply);
        if (!canApply) res.getWarnings().add("No file write was performed.");
        if (req.isGenerateReport()) res.setReportPath(reports.writeReport(req, res));
        return res;
    }

    private String frameworkSummary(ProjectIndex idx) {
        return "Detected: " + idx.getFrameworkType() + ", files=" + idx.getImportantFiles().size() + ", methods=" + idx.getMethodCandidates().size() + ", locators=" + idx.getLocatorCandidates().size();
    }
}
