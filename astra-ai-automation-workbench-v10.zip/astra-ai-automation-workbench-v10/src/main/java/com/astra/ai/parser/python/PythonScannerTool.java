package com.astra.ai.parser.python;

import com.astra.ai.model.IndexModels.PyClassInfo;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.*;
import java.util.Optional;
import java.util.regex.*;

@Component
public class PythonScannerTool {
    private static final Pattern CLASS = Pattern.compile("^class\\s+(\\w+)", Pattern.MULTILINE);
    private static final Pattern DEF = Pattern.compile("^\\s*def\\s+(\\w+)\\s*\\(", Pattern.MULTILINE);
    private static final Pattern LOCATOR = Pattern.compile("(find_element|By\\.|locator\\()");
    public Optional<PyClassInfo> parse(Path root, Path file) {
        try {
            String content = Files.readString(file);
            PyClassInfo info = new PyClassInfo();
            info.filePath = root.relativize(file).toString().replace("\\", "/");
            Matcher c = CLASS.matcher(content);
            if (c.find()) info.className = c.group(1);
            Matcher d = DEF.matcher(content);
            while (d.find()) info.methods.add(d.group(1) + "()");
            int lineNo = 0;
            for (String line : content.split("\\R")) {
                lineNo++;
                if (LOCATOR.matcher(line).find()) info.locators.add(info.filePath + ": line " + lineNo + ": " + line.trim());
            }
            return Optional.of(info);
        } catch (IOException e) { return Optional.empty(); }
    }
}
