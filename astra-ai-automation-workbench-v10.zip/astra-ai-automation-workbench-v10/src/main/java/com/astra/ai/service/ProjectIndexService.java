package com.astra.ai.service;

import com.astra.ai.model.Enums.FrameworkType;
import com.astra.ai.model.IndexModels.*;
import com.astra.ai.parser.FeatureParserTool;
import com.astra.ai.parser.java.JavaParserTool;
import com.astra.ai.parser.typescript.TypeScriptScannerTool;
import com.astra.ai.parser.python.PythonScannerTool;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.Locale;
import java.util.stream.Stream;

@Service
public class ProjectIndexService {
    private final FrameworkDetectorService detector;
    private final JavaParserTool javaParser;
    private final TypeScriptScannerTool tsParser;
    private final PythonScannerTool pyParser;
    private final FeatureParserTool featureParser;

    public ProjectIndexService(FrameworkDetectorService detector, JavaParserTool javaParser, TypeScriptScannerTool tsParser, PythonScannerTool pyParser, FeatureParserTool featureParser) {
        this.detector = detector; this.javaParser = javaParser; this.tsParser = tsParser; this.pyParser = pyParser; this.featureParser = featureParser;
    }

    public ProjectIndex index(String projectPath, FrameworkType requestedType) {
        ProjectIndex index = new ProjectIndex();
        index.setProjectPath(projectPath);
        if (projectPath == null || projectPath.isBlank()) { index.getWarnings().add("Project path is empty."); return index; }
        Path root = Path.of(projectPath);
        if (!Files.exists(root)) { index.getWarnings().add("Project path does not exist: " + projectPath); return index; }
        index.setFrameworkType(detector.detect(projectPath, requestedType));
        index.setBuildTool(resolveBuildTool(root));
        index.setLanguage(resolveLanguage(index.getFrameworkType()));

        try (Stream<Path> paths = Files.walk(root, 16)) {
            paths.filter(Files::isRegularFile).filter(this::isUsefulFile).limit(3000).forEach(path -> classifyAndParse(root, path, index));
        } catch (IOException e) { index.getWarnings().add("Failed to scan project: " + e.getMessage()); }
        return index;
    }

    private String resolveBuildTool(Path root) {
        if (Files.exists(root.resolve("pom.xml"))) return "MAVEN";
        if (Files.exists(root.resolve("build.gradle")) || Files.exists(root.resolve("build.gradle.kts"))) return "GRADLE";
        if (Files.exists(root.resolve("package.json"))) return "NPM";
        if (Files.exists(root.resolve("pytest.ini")) || Files.exists(root.resolve("requirements.txt"))) return "PYTEST";
        return "UNKNOWN";
    }

    private String resolveLanguage(FrameworkType type) {
        return switch(type) {
            case JAVA_SELENIUM_CUCUMBER, JAVA_SELENIUM_TESTNG, REST_ASSURED_CUCUMBER -> "JAVA";
            case PLAYWRIGHT_TYPESCRIPT, PLAYWRIGHT_TYPESCRIPT_CUCUMBER, CYPRESS_TYPESCRIPT -> "TYPESCRIPT";
            case CYPRESS_JAVASCRIPT -> "JAVASCRIPT";
            case PYTHON_SELENIUM_PYTEST, PYTHON_SELENIUM_BEHAVE -> "PYTHON";
            default -> "UNKNOWN";
        };
    }

    private boolean isUsefulFile(Path path) {
        String s = path.toString().toLowerCase(Locale.ROOT);
        if (s.contains("/target/") || s.contains("\\target\\") || s.contains("node_modules") || s.contains(".git") || s.contains("__pycache__")) return false;
        return s.endsWith(".java") || s.endsWith(".ts") || s.endsWith(".js") || s.endsWith(".py") || s.endsWith(".feature")
                || s.endsWith(".xml") || s.endsWith(".json") || s.endsWith(".properties") || s.endsWith(".yml") || s.endsWith(".yaml");
    }

    private void classifyAndParse(Path root, Path path, ProjectIndex index) {
        String rel = root.relativize(path).toString().replace("\\", "/");
        String lower = rel.toLowerCase(Locale.ROOT);
        index.getImportantFiles().add(rel);
        if (lower.endsWith(".feature")) { index.getFeatureFiles().add(rel); featureParser.parse(root, path).ifPresent(index.getFeatures()::add); }
        if (lower.contains("step") || lower.contains("steps") || lower.endsWith(".cy.ts") || lower.endsWith(".cy.js") || lower.endsWith(".spec.ts") || lower.endsWith(".spec.js")) index.getStepDefinitions().add(rel);
        if (lower.contains("page") || lower.contains("pages") || lower.endsWith("_page.py")) index.getPageObjects().add(rel);
        if (lower.endsWith(".properties") || lower.endsWith(".yml") || lower.endsWith(".yaml") || lower.equals("pom.xml") || lower.equals("package.json") || lower.contains("config")) index.getConfigFiles().add(rel);
        if (lower.contains("runner") || lower.contains("cucumber") || lower.contains("playwright.config") || lower.contains("cypress.config") || lower.contains("pytest.ini") || lower.contains("hooks") || lower.contains("world")) index.getRunnerFiles().add(rel);

        if (lower.endsWith(".java")) javaParser.parse(root, path).ifPresent(cls -> { index.getJavaClasses().add(cls); cls.methods.forEach(m -> index.getMethodCandidates().add(cls.filePath+" :: "+cls.className+"."+m)); cls.locators.forEach(l -> index.getLocatorCandidates().add(cls.filePath+" :: "+l)); });
        if (lower.endsWith(".ts") || lower.endsWith(".js")) tsParser.parse(root, path).ifPresent(cls -> { index.getTsClasses().add(cls); cls.methods.forEach(m -> index.getMethodCandidates().add(cls.filePath+" :: "+cls.className+"."+m)); cls.locators.forEach(l -> index.getLocatorCandidates().add(cls.filePath+" :: "+l)); cls.cucumberSteps.forEach(s -> index.getMethodCandidates().add(cls.filePath+" :: STEP "+s)); });
        if (lower.endsWith(".py")) pyParser.parse(root, path).ifPresent(cls -> { index.getPyClasses().add(cls); cls.methods.forEach(m -> index.getMethodCandidates().add(cls.filePath+" :: "+cls.className+"."+m)); cls.locators.forEach(index.getLocatorCandidates()::add); });
    }
}
