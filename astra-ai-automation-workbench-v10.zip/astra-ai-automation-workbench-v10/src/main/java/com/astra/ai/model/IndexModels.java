package com.astra.ai.model;

import com.astra.ai.model.Enums.FrameworkType;
import java.util.ArrayList;
import java.util.List;

public class IndexModels {
    public static class ProjectIndex {
        private String projectPath;
        private FrameworkType frameworkType = FrameworkType.UNKNOWN;
        private String buildTool = "UNKNOWN";
        private String language = "UNKNOWN";
        private final List<String> importantFiles = new ArrayList<>();
        private final List<String> featureFiles = new ArrayList<>();
        private final List<String> pageObjects = new ArrayList<>();
        private final List<String> stepDefinitions = new ArrayList<>();
        private final List<String> configFiles = new ArrayList<>();
        private final List<String> runnerFiles = new ArrayList<>();
        private final List<String> methodCandidates = new ArrayList<>();
        private final List<String> locatorCandidates = new ArrayList<>();
        private final List<JavaClassInfo> javaClasses = new ArrayList<>();
        private final List<TsClassInfo> tsClasses = new ArrayList<>();
        private final List<PyClassInfo> pyClasses = new ArrayList<>();
        private final List<FeatureInfo> features = new ArrayList<>();
        private final List<String> warnings = new ArrayList<>();

        public String getProjectPath() { return projectPath; }
        public void setProjectPath(String projectPath) { this.projectPath = projectPath; }
        public FrameworkType getFrameworkType() { return frameworkType; }
        public void setFrameworkType(FrameworkType frameworkType) { this.frameworkType = frameworkType; }
        public String getBuildTool() { return buildTool; }
        public void setBuildTool(String buildTool) { this.buildTool = buildTool; }
        public String getLanguage() { return language; }
        public void setLanguage(String language) { this.language = language; }
        public List<String> getImportantFiles() { return importantFiles; }
        public List<String> getFeatureFiles() { return featureFiles; }
        public List<String> getPageObjects() { return pageObjects; }
        public List<String> getStepDefinitions() { return stepDefinitions; }
        public List<String> getConfigFiles() { return configFiles; }
        public List<String> getRunnerFiles() { return runnerFiles; }
        public List<String> getMethodCandidates() { return methodCandidates; }
        public List<String> getLocatorCandidates() { return locatorCandidates; }
        public List<JavaClassInfo> getJavaClasses() { return javaClasses; }
        public List<TsClassInfo> getTsClasses() { return tsClasses; }
        public List<PyClassInfo> getPyClasses() { return pyClasses; }
        public List<FeatureInfo> getFeatures() { return features; }
        public List<String> getWarnings() { return warnings; }
    }

    public static class JavaClassInfo {
        public String filePath;
        public String packageName;
        public String className;
        public String extendedClass;
        public final List<String> imports = new ArrayList<>();
        public final List<String> methods = new ArrayList<>();
        public final List<String> fields = new ArrayList<>();
        public final List<String> locators = new ArrayList<>();
        public final List<String> annotations = new ArrayList<>();
    }

    public static class TsClassInfo {
        public String filePath;
        public String className;
        public boolean usesPlaywrightPage;
        public boolean usesCustomWorld;
        public final List<String> imports = new ArrayList<>();
        public final List<String> methods = new ArrayList<>();
        public final List<String> locators = new ArrayList<>();
        public final List<String> cucumberSteps = new ArrayList<>();
    }

    public static class PyClassInfo {
        public String filePath;
        public String className;
        public final List<String> methods = new ArrayList<>();
        public final List<String> locators = new ArrayList<>();
    }

    public static class FeatureInfo {
        public String filePath;
        public String featureName;
        public final List<String> tags = new ArrayList<>();
        public final List<String> scenarios = new ArrayList<>();
        public final List<String> steps = new ArrayList<>();
    }
}
