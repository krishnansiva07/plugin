package com.astra.ai.parser.java;

import com.astra.ai.model.IndexModels.JavaClassInfo;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.util.Optional;

@Component
public class JavaParserTool {
    public Optional<JavaClassInfo> parse(Path root, Path file) {
        try {
            CompilationUnit cu = StaticJavaParser.parse(file);
            JavaClassInfo info = new JavaClassInfo();
            info.filePath = root.relativize(file).toString().replace("\\", "/");
            cu.getPackageDeclaration().ifPresent(pd -> info.packageName = pd.getNameAsString());
            cu.getImports().forEach(i -> info.imports.add(i.getNameAsString()));
            cu.findAll(ClassOrInterfaceDeclaration.class).stream().findFirst().ifPresent(cls -> {
                info.className = cls.getNameAsString();
                cls.getExtendedTypes().stream().findFirst().ifPresent(ex -> info.extendedClass = ex.getNameAsString());
                cls.getAnnotations().forEach(a -> info.annotations.add(a.toString()));
            });
            for (MethodDeclaration m : cu.findAll(MethodDeclaration.class)) {
                info.methods.add(m.getNameAsString() + "(" + m.getParameters() + ") : " + m.getTypeAsString());
                m.getAnnotations().forEach(a -> {
                    String an = a.toString();
                    if (an.startsWith("@Given") || an.startsWith("@When") || an.startsWith("@Then") || an.startsWith("@And") || an.startsWith("@But")) info.annotations.add(an);
                });
            }
            for (FieldDeclaration f : cu.findAll(FieldDeclaration.class)) {
                String txt = f.toString().replace("\n", " ").trim();
                info.fields.add(txt);
                if (txt.contains("@FindBy") || txt.contains("By.")) info.locators.add(txt);
            }
            return Optional.of(info);
        } catch (Exception e) { return Optional.empty(); }
    }
}
