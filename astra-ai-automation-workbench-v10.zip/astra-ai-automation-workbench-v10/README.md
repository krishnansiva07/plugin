# Astra AI Automation Workbench V10

This is a production-style **safe starter** that combines the planned V1–V10 architecture into one Spring Boot application.

## What V10 covers

- Single dropdown-driven UI
- Java Selenium Cucumber parsing using JavaParser
- Playwright TypeScript / Cucumber lightweight parser
- Cypress TypeScript / JavaScript lightweight parser
- Python Selenium / Pytest / Behave lightweight parser
- Feature file parser
- Reusable method finder
- Duplicate step detector
- Framework chat service
- Automation preview generator
- Locator self-healing preview
- Failure analysis preview
- DOCX documentation generator
- HTML agent report generator
- Safety gates: approval, backup-required design, replacement strategy, no blind write

## Run

```bash
mvn spring-boot:run
```

Open:

```text
http://localhost:8088
```

## Safe by default

V10 intentionally does **not blindly modify framework files**.

File write is blocked unless all are true:

```text
applyChanges = true
approvalGranted = true
agentMode = GENERATE_VALIDATE_APPLY
replacementStrategy != NEVER_REPLACE_ONLY_SUGGEST
```

## Recommended test

```text
Project Path: your framework path
Framework Type: AUTO
Action: Generate Automation
Prompt: Create automation for login with valid user and verify dashboard
Change Mode: Preview Only
```

## Endpoints

```text
POST /api/project/index
POST /api/agent/execute
POST /api/framework/chat
POST /api/documentation/generate
```

## What still needs production wiring

- Real file writer with diff and backup execution
- Maven/NPM/Pytest command runner
- DOM capture parser and locator uniqueness validation
- Real LLM integration inside LlmService
- Authentication/user roles/audit log if used by team
