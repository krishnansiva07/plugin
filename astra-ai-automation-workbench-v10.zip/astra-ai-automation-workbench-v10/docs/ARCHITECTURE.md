# Astra AI Automation Workbench V10 Architecture

```text
Single UI
  -> WorkbenchController
  -> AgentOrchestratorService
  -> ProjectIndexService
  -> JavaParserTool / TypeScriptScannerTool / PythonScannerTool / FeatureParserTool
  -> ContextServices
  -> SafetyServices
  -> PreviewGenerator
  -> LocatorHealingService
  -> FailureAnalysisService
  -> DocxDocumentationService
  -> HtmlReportService
```

## Safe Lifecycle

```text
Index -> Parse -> Retrieve -> Reuse Check -> Duplicate Check -> Impact Check -> Generate Preview -> Report -> Approval -> Backup -> Apply
```

## Supported adapters in V10 starter

```text
Java Selenium Cucumber
Java Selenium TestNG
Playwright TypeScript
Playwright TypeScript Cucumber
Cypress TypeScript / JavaScript
Python Selenium Pytest
Python Selenium Behave
RestAssured Cucumber
Robot Framework
```
