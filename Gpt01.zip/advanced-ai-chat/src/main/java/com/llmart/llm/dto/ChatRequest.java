package com.llmart.llm.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record ChatRequest(
        String conversationId,
        String message,
        List<String> attachmentIds,
        Boolean regenerate,
        @Valid @NotNull ChatSettings settings
) {
    public boolean isRegenerate() { return Boolean.TRUE.equals(regenerate); }
}
