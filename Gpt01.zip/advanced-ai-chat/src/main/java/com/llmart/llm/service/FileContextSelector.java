package com.llmart.llm.service;

import com.llmart.llm.entity.FileEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
public class FileContextSelector {
    private static final Pattern WORD = Pattern.compile("[^a-zA-Z0-9_]+");

    public String select(String query, List<FileEntity> files, int maxChars) {
        if (files == null || files.isEmpty() || maxChars <= 0) return "";
        Set<String> terms = terms(query);
        List<Chunk> chunks = new ArrayList<>();

        for (FileEntity f : files) {
            String text = f.getExtractedText();
            if (text == null || text.isBlank()) continue;
            for (String chunk : chunk(text, 2600, 250)) {
                double score = score(chunk, terms);
                chunks.add(new Chunk(f.getOriginalName(), chunk, score));
            }
        }
        chunks.sort(Comparator.comparingDouble(Chunk::score).reversed());

        StringBuilder out = new StringBuilder();
        for (Chunk c : chunks) {
            String block = "\n--- File context: " + c.fileName() + " ---\n" + c.text() + "\n";
            if (out.length() + block.length() > maxChars) break;
            out.append(block);
            if (out.length() >= maxChars) break;
        }
        return out.toString();
    }

    private Set<String> terms(String q) {
        Set<String> t = new HashSet<>();
        if (q == null) return t;
        for (String s : WORD.split(q.toLowerCase(Locale.ROOT))) if (s.length() > 2) t.add(s);
        return t;
    }

    private double score(String text, Set<String> terms) {
        if (terms.isEmpty()) return 0.1;
        String low = text.toLowerCase(Locale.ROOT);
        double score = 0;
        for (String term : terms) {
            int idx = 0, count = 0;
            while ((idx = low.indexOf(term, idx)) >= 0 && count < 8) { count++; idx += term.length(); }
            score += count;
        }
        return score;
    }

    private List<String> chunk(String text, int size, int overlap) {
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(text.length(), start + size);
            out.add(text.substring(start, end));
            if (end == text.length()) break;
            start = Math.max(start + 1, end - overlap);
        }
        return out;
    }

    private record Chunk(String fileName, String text, double score) {}
}
