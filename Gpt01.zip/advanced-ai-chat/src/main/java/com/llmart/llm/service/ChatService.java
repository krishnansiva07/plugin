package com.llmart.llm.service;

import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class ChatService {
    private final ConversationService conversations;
    private final FileService files;
    private final ContextService contextService;
    private final OpenAiCompatibleClient llm;

    public ChatService(ConversationService conversations, FileService files,
                       ContextService contextService, OpenAiCompatibleClient llm) {
        this.conversations = conversations;
        this.files = files;
        this.contextService = contextService;
        this.llm = llm;
    }

    public SseEmitter stream(String apiKey, ChatRequest request) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required");
        SseEmitter emitter = new SseEmitter(300_000L);

        CompletableFuture.runAsync(() -> {
            try {
                ConversationEntity conversation = conversations.getOrCreate(request.conversationId());
                MessageEntity userMessage;

                if (request.isRegenerate()) {
                    userMessage = conversations.lastUserMessage(conversation.getId());
                    conversations.removeMessagesAfter(conversation.getId(), userMessage.getId());
                } else {
                    if (request.message() == null || request.message().isBlank()) throw new IllegalArgumentException("Message is required");
                    files.requireForConversation(conversation.getId(), request.attachmentIds());
                    userMessage = conversations.addMessage(conversation.getId(), "user", request.message().trim(), request.attachmentIds());
                }

                emitter.send(SseEmitter.event().name("meta").data(Map.of("conversationId", conversation.getId(), "userMessageId", userMessage.getId())));
                List<Map<String, Object>> context = contextService.build(conversation.getId(), userMessage, request.settings());
                String answer = llm.stream(apiKey, request.settings(), context, token -> {
                    try { emitter.send(SseEmitter.event().name("token").data(token)); }
                    catch (Exception e) { throw new RuntimeException(e); }
                });

                MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                MessageDto dto = conversations.messageDto(assistant);
                emitter.send(SseEmitter.event().name("done").data(dto));
                emitter.complete();
            } catch (Exception e) {
                try { emitter.send(SseEmitter.event().name("error").data(Map.of("message", safeMessage(e)))); }
                catch (Exception ignored) {}
                emitter.completeWithError(e);
            }
        });
        return emitter;
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isBlank()) return e.getClass().getSimpleName();
        return m.length() > 1500 ? m.substring(0, 1500) : m;
    }
}
