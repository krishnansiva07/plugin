package com.llmart.llm.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "uploaded_files", indexes = @Index(name = "idx_file_conversation", columnList = "conversation_id"))
public class FileEntity {
    @Id
    @Column(length = 40)
    private String id;

    @Column(name = "conversation_id", nullable = false, length = 40)
    private String conversationId;

    @Column(nullable = false, length = 500)
    private String originalName;

    @Column(nullable = false, length = 1000)
    private String storedPath;

    @Column(length = 200)
    private String mimeType;

    private long sizeBytes;

    @Lob
    private String extractedText;

    @Column(nullable = false)
    private Instant createdAt;

    public FileEntity() {}

    public FileEntity(String id, String conversationId, String originalName, String storedPath,
                      String mimeType, long sizeBytes, String extractedText) {
        this.id = id;
        this.conversationId = conversationId;
        this.originalName = originalName;
        this.storedPath = storedPath;
        this.mimeType = mimeType;
        this.sizeBytes = sizeBytes;
        this.extractedText = extractedText;
        this.createdAt = Instant.now();
    }

    public String getId() { return id; }
    public String getConversationId() { return conversationId; }
    public String getOriginalName() { return originalName; }
    public String getStoredPath() { return storedPath; }
    public String getMimeType() { return mimeType; }
    public long getSizeBytes() { return sizeBytes; }
    public String getExtractedText() { return extractedText; }
    public Instant getCreatedAt() { return createdAt; }
}
