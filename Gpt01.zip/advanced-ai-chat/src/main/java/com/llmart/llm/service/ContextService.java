package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@Service
public class ContextService {
    private final ConversationService conversations;
    private final FileService files;
    private final FileContextSelector fileContextSelector;
    private final ObjectMapper objectMapper;

    public ContextService(ConversationService conversations, FileService files,
                          FileContextSelector fileContextSelector, ObjectMapper objectMapper) {
        this.conversations = conversations;
        this.files = files;
        this.fileContextSelector = fileContextSelector;
        this.objectMapper = objectMapper;
    }

    public List<Map<String, Object>> build(String conversationId, MessageEntity currentUser, ChatSettings settings) {
        List<MessageEntity> history = conversations.messageEntities(conversationId);
        List<Map<String, Object>> result = new ArrayList<>();

        String system = settings.systemPrompt();
        if (system == null || system.isBlank()) {
            system = "You are a capable, concise AI assistant. Use Markdown. Put code in fenced code blocks with a language tag. " +
                    "When you provide a complete file, put the filename on the first line inside the code block as a comment when practical.";
        }
        result.add(Map.of("role", "system", "content", system));

        int budget = settings.safeContextChars();
        int used = system.length();
        LinkedList<Map<String, Object>> recent = new LinkedList<>();

        for (int i = history.size() - 1; i >= 0; i--) {
            MessageEntity m = history.get(i);
            String content = m.getContent();
            int cost = content == null ? 0 : content.length();
            if (!recent.isEmpty() && used + cost > budget) break;

            Map<String, Object> payload;
            if (Objects.equals(m.getId(), currentUser.getId())) {
                payload = currentUserPayload(m, settings, Math.max(4000, budget / 3));
            } else {
                payload = Map.of("role", m.getRole(), "content", content == null ? "" : content);
            }
            recent.addFirst(payload);
            used += cost;
        }
        result.addAll(recent);
        return result;
    }

    private Map<String, Object> currentUserPayload(MessageEntity m, ChatSettings settings, int fileBudget) {
        List<String> attachmentIds = parseIds(m.getAttachmentIdsJson());
        List<FileEntity> attached = files.requireForConversation(m.getConversationId(), attachmentIds);
        if (attached.isEmpty()) return Map.of("role", "user", "content", m.getContent());

        List<Map<String, Object>> multi = new ArrayList<>();
        StringBuilder text = new StringBuilder(m.getContent() == null ? "" : m.getContent());

        if (settings.fileContextEnabled()) {
            String selected = fileContextSelector.select(m.getContent(), attached, fileBudget);
            if (!selected.isBlank()) text.append("\n\nUse the following uploaded file excerpts when relevant:").append(selected);
        }
        multi.add(Map.of("type", "text", "text", text.toString()));

        for (FileEntity f : attached) {
            if (f.getMimeType() != null && f.getMimeType().startsWith("image/") && f.getSizeBytes() <= 8_000_000) {
                try {
                    byte[] bytes = Files.readAllBytes(Path.of(f.getStoredPath()));
                    String dataUrl = "data:" + f.getMimeType() + ";base64," + Base64.getEncoder().encodeToString(bytes);
                    multi.add(Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
                } catch (Exception ignored) {}
            }
        }

        // OpenAI-compatible providers accept either a string or this multimodal content array.
        return Map.of("role", "user", "content", multi);
    }

    private List<String> parseIds(String json) {
        if (json == null || json.isBlank()) return List.of();
        try { return objectMapper.readValue(json, new TypeReference<>() {}); }
        catch (Exception e) { return List.of(); }
    }
}
