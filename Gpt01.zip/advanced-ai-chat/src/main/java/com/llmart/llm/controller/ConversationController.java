package com.llmart.llm.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.service.ConversationService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/api/conversations")
public class ConversationController {
    private final ConversationService service;
    private final ObjectMapper objectMapper;

    public ConversationController(ConversationService service, ObjectMapper objectMapper) {
        this.service = service;
        this.objectMapper = objectMapper;
    }

    @GetMapping
    public List<ConversationDto> list() { return service.list(); }

    @PostMapping
    public ConversationDto create() {
        ConversationEntity c = service.create();
        return new ConversationDto(c.getId(), c.getTitle(), c.getCreatedAt(), c.getUpdatedAt());
    }

    @GetMapping("/{id}/messages")
    public List<MessageDto> messages(@PathVariable String id) { return service.listMessages(id); }

    @PatchMapping("/{id}")
    public ConversationDto rename(@PathVariable String id, @RequestBody Map<String, String> body) {
        return service.rename(id, body.get("title"));
    }

    @PostMapping("/{id}/rewind/{messageId}")
    public void rewind(@PathVariable String id, @PathVariable Long messageId) { service.rewindFrom(id, messageId); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) { service.delete(id); }

    @GetMapping("/{id}/export")
    public ResponseEntity<byte[]> export(@PathVariable String id,
                                         @RequestParam(defaultValue = "md") String format) throws Exception {
        ConversationEntity c = service.require(id);
        List<MessageDto> messages = service.listMessages(id);
        String fileName;
        byte[] bytes;
        MediaType type;

        if ("json".equalsIgnoreCase(format)) {
            String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(messages);
            bytes = json.getBytes(StandardCharsets.UTF_8);
            type = MediaType.APPLICATION_JSON;
            fileName = safe(c.getTitle()) + ".json";
        } else {
            StringBuilder md = new StringBuilder("# ").append(c.getTitle()).append("\n\n");
            for (MessageDto m : messages) md.append("## ").append("user".equals(m.role()) ? "You" : "Assistant").append("\n\n").append(m.content()).append("\n\n");
            bytes = md.toString().getBytes(StandardCharsets.UTF_8);
            type = new MediaType("text", "markdown", StandardCharsets.UTF_8);
            fileName = safe(c.getTitle()) + ".md";
        }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(bytes);
    }

    private String safe(String s) { return s.replaceAll("[^a-zA-Z0-9._ -]", "_"); }
}
