package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

@Service
public class OpenAiCompatibleClient {
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public OpenAiCompatibleClient(HttpClient httpClient, ObjectMapper objectMapper) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
    }

    public String stream(String apiKey, ChatSettings settings, List<Map<String, Object>> messages,
                         Consumer<String> onToken) throws Exception {
        validate(settings);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", settings.model());
        body.put("messages", messages);
        body.put("temperature", settings.safeTemperature());
        body.put("max_tokens", settings.safeMaxTokens());
        body.put("stream", true);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(chatCompletionsUrl(settings.baseUrl())))
                .timeout(Duration.ofMinutes(5))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("Accept", "text/event-stream, application/json")
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                .build();

        HttpResponse<Stream<String>> response = httpClient.send(request, HttpResponse.BodyHandlers.ofLines());
        StringBuilder complete = new StringBuilder();
        List<String> errorLines = new ArrayList<>();

        try (Stream<String> lines = response.body()) {
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                lines.limit(30).forEach(errorLines::add);
                throw new IllegalStateException("LLM HTTP " + response.statusCode() + ": " + String.join(" ", errorLines));
            }

            Iterator<String> iterator = lines.iterator();
            while (iterator.hasNext()) {
                String line = iterator.next();
                if (line == null || line.isBlank() || line.startsWith(":")) continue;
                String data = line.startsWith("data:") ? line.substring(5).trim() : line.trim();
                if ("[DONE]".equals(data)) break;

                JsonNode json;
                try { json = objectMapper.readTree(data); }
                catch (Exception ignored) { continue; }

                JsonNode choices = json.path("choices");
                if (!choices.isArray() || choices.isEmpty()) continue;
                JsonNode choice = choices.get(0);
                JsonNode content = choice.path("delta").path("content");
                if (content.isMissingNode() || content.isNull()) content = choice.path("message").path("content");

                if (content.isTextual()) append(content.asText(), complete, onToken);
                else if (content.isArray()) {
                    for (JsonNode item : content) {
                        String token = item.path("text").asText("");
                        if (!token.isEmpty()) append(token, complete, onToken);
                    }
                }
            }
        }
        return complete.toString();
    }

    private void append(String token, StringBuilder complete, Consumer<String> onToken) {
        complete.append(token);
        onToken.accept(token);
    }

    private void validate(ChatSettings s) {
        if (s.baseUrl() == null || s.baseUrl().isBlank()) throw new IllegalArgumentException("Base URL is required");
        if (s.model() == null || s.model().isBlank()) throw new IllegalArgumentException("Model name is required");
    }

    private String chatCompletionsUrl(String baseUrl) {
        String base = baseUrl.trim().replaceAll("/+$", "");
        if (base.endsWith("/chat/completions")) return base;
        return base + "/chat/completions";
    }
}
