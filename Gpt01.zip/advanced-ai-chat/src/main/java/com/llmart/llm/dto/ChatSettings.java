package com.llmart.llm.dto;

public record ChatSettings(
        String baseUrl,
        String model,
        Double temperature,
        Integer maxTokens,
        Integer contextChars,
        String systemPrompt,
        Boolean useFileContext
) {
    public double safeTemperature() { return temperature == null ? 0.7 : Math.max(0.0, Math.min(2.0, temperature)); }
    public int safeMaxTokens() { return maxTokens == null ? 2048 : Math.max(64, Math.min(32768, maxTokens)); }
    public int safeContextChars() { return contextChars == null ? 48000 : Math.max(4000, Math.min(500000, contextChars)); }
    public boolean fileContextEnabled() { return useFileContext == null || useFileContext; }
}
