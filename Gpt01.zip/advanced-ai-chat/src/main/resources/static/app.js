const state = {
  conversationId: null,
  conversations: [],
  messages: [],
  attachments: [],
  streaming: false,
  abortController: null,
  config: {
    apiKey: sessionStorage.getItem('llm.apiKey') || localStorage.getItem('llm.apiKey') || '',
    baseUrl: localStorage.getItem('llm.baseUrl') || '',
    model: localStorage.getItem('llm.model') || '',
    temperature: Number(localStorage.getItem('llm.temperature') || 0.7),
    maxTokens: Number(localStorage.getItem('llm.maxTokens') || 2048),
    contextChars: Number(localStorage.getItem('llm.contextChars') || 48000),
    systemPrompt: localStorage.getItem('llm.systemPrompt') || '',
    useFileContext: localStorage.getItem('llm.useFileContext') !== 'false',
    rememberKey: !!localStorage.getItem('llm.apiKey')
  }
};

const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(url, options={}) {
  const r = await fetch(url, options);
  if (!r.ok) {
    let m = `HTTP ${r.status}`;
    try { const j = await r.json(); m = j.message || m; } catch {}
    throw new Error(m);
  }
  const ct = r.headers.get('content-type') || '';
  return ct.includes('application/json') ? r.json() : r;
}

function toast(text) {
  const t = $('toast'); t.textContent = text; t.classList.remove('hidden');
  clearTimeout(toast.timer); toast.timer = setTimeout(()=>t.classList.add('hidden'), 2200);
}

function saveConfig() {
  localStorage.setItem('llm.baseUrl', state.config.baseUrl);
  localStorage.setItem('llm.model', state.config.model);
  localStorage.setItem('llm.temperature', state.config.temperature);
  localStorage.setItem('llm.maxTokens', state.config.maxTokens);
  localStorage.setItem('llm.contextChars', state.config.contextChars);
  localStorage.setItem('llm.systemPrompt', state.config.systemPrompt);
  localStorage.setItem('llm.useFileContext', state.config.useFileContext);
  if (state.config.rememberKey) {
    localStorage.setItem('llm.apiKey', state.config.apiKey);
    sessionStorage.removeItem('llm.apiKey');
  } else {
    localStorage.removeItem('llm.apiKey');
    sessionStorage.setItem('llm.apiKey', state.config.apiKey);
  }
  updateModelBadge();
}

function updateModelBadge() { $('modelBadge').textContent = state.config.model || 'Model not configured'; }

function syncSettingsUi() {
  $('apiKey').value = state.config.apiKey;
  $('baseUrl').value = state.config.baseUrl;
  $('modelName').value = state.config.model;
  $('temperature').value = state.config.temperature;
  $('maxTokens').value = state.config.maxTokens;
  $('contextChars').value = state.config.contextChars;
  $('systemPrompt').value = state.config.systemPrompt;
  $('useFileContext').checked = state.config.useFileContext;
  $('rememberKey').checked = state.config.rememberKey;
  $('homeApiKey').value = state.config.apiKey;
  $('homeBaseUrl').value = state.config.baseUrl;
  $('homeModel').value = state.config.model;
  $('homeRemember').checked = state.config.rememberKey;
}

async function loadConversations() {
  state.conversations = await api('/api/conversations');
  renderHistory();
}

function renderHistory(filter='') {
  const q = filter.trim().toLowerCase();
  $('historyList').innerHTML = state.conversations.filter(c => !q || c.title.toLowerCase().includes(q)).map(c => `
    <div class="history-item ${c.id===state.conversationId?'active':''}" data-id="${c.id}" title="${esc(c.title)}">
      ${esc(c.title)}<button class="history-menu" data-menu="${c.id}">⋯</button>
    </div>`).join('');
}

async function newChat(showWelcome=true) {
  const c = await api('/api/conversations', {method:'POST'});
  state.conversationId = c.id; state.messages = []; state.attachments=[];
  $('conversationTitle').textContent = c.title;
  renderMessages(); renderAttachmentTray();
  if (showWelcome) $('welcome').classList.remove('hidden');
  await loadConversations();
  $('messageInput').focus();
}

async function openConversation(id) {
  state.conversationId = id;
  state.messages = await api(`/api/conversations/${id}/messages`);
  const c = state.conversations.find(x=>x.id===id);
  $('conversationTitle').textContent = c?.title || 'Chat';
  $('welcome').classList.add('hidden');
  renderMessages(); renderHistory(); scrollBottom();
  $('sidebar').classList.remove('open');
}

function renderMessages() {
  const box = $('messages');
  box.innerHTML = state.messages.map((m, idx) => messageHtml(m, idx)).join('');
  $('welcome').classList.toggle('hidden', state.messages.length > 0 || !!state.conversationId && state.messages.length > 0);
}

function messageHtml(m, idx) {
  const assistant = m.role === 'assistant';
  const lastAssistant = assistant && idx === state.messages.length - 1;
  const body = assistant ? renderAssistant(m.content) : `<div>${renderInline(m.content)}</div>`;
  const actions = assistant
    ? `<button class="mini-btn" data-copy-msg="${idx}">Copy</button><button class="mini-btn" data-download-msg="${idx}">Download</button>${lastAssistant?`<button class="mini-btn" data-regenerate="1">Regenerate</button>`:''}`
    : `<button class="mini-btn" data-edit-msg="${idx}">Edit</button><button class="mini-btn" data-copy-msg="${idx}">Copy</button>`;
  return `<article class="message ${m.role}"><div class="avatar">${assistant?'AI':'You'}</div><div class="message-body"><div class="message-content ${m.streaming?'typing':''}">${body}</div><div class="message-actions">${actions}</div></div></article>`;
}

function renderInline(text) {
  let s = esc(text).replace(/`([^`]+)`/g,'<code class="inline-code">$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
  return s.replace(/\n/g,'<br>');
}

function renderAssistant(text) {
  const parts = [];
  const re = /```([^\n`]*)\n([\s\S]*?)```/g;
  let last=0, match, index=0;
  while ((match = re.exec(text || '')) !== null) {
    parts.push(renderProse((text||'').slice(last, match.index)));
    const label = (match[1] || 'code').trim();
    const lang = label.split(/\s+/)[0] || 'code';
    const code = match[2];
    const encoded = encodeURIComponent(code);
    parts.push(`<div class="code-block"><div class="code-head"><span>${esc(label || 'code')}</span><div class="code-actions"><button class="code-btn" data-code-copy="${encoded}">Copy</button><button class="code-btn" data-code-download="${encoded}" data-lang="${esc(lang)}">Download</button></div></div><pre><code>${esc(code)}</code></pre></div>`);
    last = re.lastIndex; index++;
  }
  parts.push(renderProse((text||'').slice(last)));
  return parts.join('');
}

function renderProse(text) {
  if (!text) return '';
  const lines = text.split('\n');
  let html='', listType=null;
  const closeList = ()=>{ if(listType){html += `</${listType}>`; listType=null;} };
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (!line.trim()) { closeList(); continue; }
    let m;
    if ((m=line.match(/^(#{1,4})\s+(.+)/))) { closeList(); const n=m[1].length+1; html += `<h${n} class="md-h">${renderInline(m[2])}</h${n}>`; continue; }
    if ((m=line.match(/^>\s?(.*)/))) { closeList(); html += `<div class="md-quote">${renderInline(m[1])}</div>`; continue; }
    if ((m=line.match(/^[-*]\s+(.+)/))) { if(listType!=='ul'){closeList();listType='ul';html+='<ul class="md-list">';} html += `<li>${renderInline(m[1])}</li>`; continue; }
    if ((m=line.match(/^\d+[.)]\s+(.+)/))) { if(listType!=='ol'){closeList();listType='ol';html+='<ol class="md-list">';} html += `<li>${renderInline(m[1])}</li>`; continue; }
    closeList(); html += `<p class="md-p">${renderInline(line)}</p>`;
  }
  closeList();
  return html;
}

function scrollBottom() { const v=$('chatView'); requestAnimationFrame(()=>v.scrollTop=v.scrollHeight); }

async function ensureConversation() { if (!state.conversationId) await newChat(false); return state.conversationId; }

async function sendMessage({regenerate=false, overrideMessage=null}={}) {
  if (state.streaming) return;
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) { openSettings(); toast('Configure API key, base URL and model'); return; }
  await ensureConversation();
  let text = overrideMessage ?? $('messageInput').value.trim();
  if (!regenerate && !text && state.attachments.length===0) return;
  if (!regenerate) {
    state.messages.push({role:'user',content:text,attachmentIds:state.attachments.map(a=>a.id),createdAt:new Date().toISOString()});
    $('messageInput').value=''; autoGrow();
  }
  const assistant = {role:'assistant',content:'',streaming:true};
  state.messages.push(assistant); renderMessages(); scrollBottom();
  setStreaming(true);
  const attachmentIds = regenerate ? [] : state.attachments.map(a=>a.id);
  if (!regenerate) { state.attachments=[]; renderAttachmentTray(); }

  const payload = {
    conversationId: state.conversationId,
    message: text,
    attachmentIds,
    regenerate,
    settings: {
      baseUrl: state.config.baseUrl, model: state.config.model,
      temperature: state.config.temperature, maxTokens: state.config.maxTokens,
      contextChars: state.config.contextChars, systemPrompt: state.config.systemPrompt,
      useFileContext: state.config.useFileContext
    }
  };

  state.abortController = new AbortController();
  try {
    const response = await fetch('/api/chat/stream', {
      method:'POST', signal:state.abortController.signal,
      headers:{'Content-Type':'application/json','Authorization':'Bearer '+state.config.apiKey},
      body:JSON.stringify(payload)
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    await consumeSse(response, (event, data)=>{
      if (event==='meta') { try { const meta=JSON.parse(data); state.conversationId=meta.conversationId; for(let i=state.messages.length-1;i>=0;i--){if(state.messages[i].role==='user'&&!state.messages[i].id){state.messages[i].id=meta.userMessageId;break;}} } catch{} }
      if (event==='token') { assistant.content += data; throttleRender(); }
      if (event==='done') { try { const saved=JSON.parse(data); Object.assign(assistant,saved,{streaming:false}); } catch {assistant.streaming=false;} }
      if (event==='error') { let m=data; try{m=JSON.parse(data).message}catch{}; throw new Error(m); }
    });
    assistant.streaming=false; renderMessages(); await loadConversations();
    const c=state.conversations.find(x=>x.id===state.conversationId); if(c)$('conversationTitle').textContent=c.title;
  } catch(e) {
    assistant.streaming=false;
    if (e.name==='AbortError') assistant.content += '\n\n*Generation stopped.*';
    else assistant.content += `\n\n**Error:** ${e.message}`;
    renderMessages();
  } finally { setStreaming(false); state.abortController=null; scrollBottom(); }
}

let renderTimer=null;
function throttleRender(){ if(renderTimer)return; renderTimer=setTimeout(()=>{renderTimer=null;renderMessages();scrollBottom();},55); }

async function consumeSse(response, onEvent) {
  const reader=response.body.getReader(), decoder=new TextDecoder(); let buffer='', event='message', data=[];
  while(true){ const {value,done}=await reader.read(); if(done)break; buffer+=decoder.decode(value,{stream:true});
    let idx; while((idx=buffer.indexOf('\n'))>=0){ let line=buffer.slice(0,idx).replace(/\r$/,''); buffer=buffer.slice(idx+1);
      if(!line){ if(data.length){onEvent(event,data.join('\n'));} event='message';data=[];continue; }
      if(line.startsWith('event:')) event=line.slice(6).trim(); else if(line.startsWith('data:')) data.push(line.slice(5).trimStart());
    }
  }
  if(data.length) onEvent(event,data.join('\n'));
}

function setStreaming(v){state.streaming=v;$('sendBtn').classList.toggle('hidden',v);$('stopBtn').classList.toggle('hidden',!v);}

async function uploadFiles(fileList) {
  await ensureConversation();
  for (const file of fileList) {
    const fd=new FormData(); fd.append('conversationId',state.conversationId); fd.append('file',file);
    try { const uploaded=await api('/api/files',{method:'POST',body:fd}); state.attachments.push(uploaded); renderAttachmentTray(); }
    catch(e){toast(`Upload failed: ${e.message}`)}
  }
}

function renderAttachmentTray(){ $('attachmentTray').innerHTML=state.attachments.map(a=>`<div class="attachment-chip">📎 <span title="${esc(a.name)}">${esc(a.name.length>28?a.name.slice(0,28)+'…':a.name)}</span><button class="chip-remove" data-remove-file="${a.id}">×</button></div>`).join(''); }

function openSettings(){syncSettingsUi();$('modalBackdrop').classList.remove('hidden');}
function closeSettings(){$('modalBackdrop').classList.add('hidden');}
function autoGrow(){const t=$('messageInput');t.style.height='auto';t.style.height=Math.min(t.scrollHeight,180)+'px';}

function downloadText(name,text,type='text/plain'){const b=new Blob([text],{type});const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function extensionFor(lang){return ({java:'java',javascript:'js',js:'js',typescript:'ts',ts:'ts',python:'py',py:'py',json:'json',xml:'xml',html:'html',css:'css',sql:'sql',bash:'sh',sh:'sh',yaml:'yml',yml:'yml',markdown:'md',md:'md'})[lang.toLowerCase()]||'txt';}

$('newChatBtn').onclick=()=>newChat(true);
$('sendBtn').onclick=()=>sendMessage();
$('stopBtn').onclick=()=>state.abortController?.abort();
$('attachBtn').onclick=()=>$('fileInput').click();
$('fileInput').onchange=e=>{uploadFiles([...e.target.files]);e.target.value='';};
$('messageInput').addEventListener('input',autoGrow);
$('messageInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}});
$('historySearch').addEventListener('input',e=>renderHistory(e.target.value));
$('settingsBtn').onclick=openSettings;$('topSettingsBtn').onclick=openSettings;$('closeSettings').onclick=closeSettings;
$('modalBackdrop').addEventListener('click',e=>{if(e.target===$('modalBackdrop'))closeSettings();});
$('themeBtn').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('theme',next);};
$('openSidebar').onclick=()=>$('sidebar').classList.add('open');$('closeSidebar').onclick=()=>$('sidebar').classList.remove('open');
$('exportBtn').onclick=()=>{if(!state.conversationId)return toast('No chat to export');window.location=`/api/conversations/${state.conversationId}/export?format=md`;};

$('homeSave').onclick=()=>{
  state.config.apiKey=$('homeApiKey').value.trim();state.config.baseUrl=$('homeBaseUrl').value.trim();state.config.model=$('homeModel').value.trim();state.config.rememberKey=$('homeRemember').checked;
  if(!state.config.apiKey||!state.config.baseUrl||!state.config.model)return toast('Enter API key, base URL and model');
  saveConfig();$('welcome').classList.add('hidden');$('messageInput').focus();toast('Configuration saved');
};

$('saveSettings').onclick=()=>{
  state.config.apiKey=$('apiKey').value.trim();state.config.baseUrl=$('baseUrl').value.trim();state.config.model=$('modelName').value.trim();state.config.temperature=Number($('temperature').value||0.7);state.config.maxTokens=Number($('maxTokens').value||2048);state.config.contextChars=Number($('contextChars').value||48000);state.config.systemPrompt=$('systemPrompt').value;state.config.useFileContext=$('useFileContext').checked;state.config.rememberKey=$('rememberKey').checked;saveConfig();closeSettings();toast('Settings saved');
};
$('clearKey').onclick=()=>{state.config.apiKey='';state.config.rememberKey=false;sessionStorage.removeItem('llm.apiKey');localStorage.removeItem('llm.apiKey');$('apiKey').value='';toast('API key cleared');};

$('historyList').addEventListener('click',async e=>{
  const menu=e.target.closest('[data-menu]'); if(menu){e.stopPropagation();const id=menu.dataset.menu;const c=state.conversations.find(x=>x.id===id);const action=prompt(`Type RENAME to rename or DELETE to delete:\n${c?.title||''}`,'');if(action==='DELETE'){if(confirm('Delete this chat?')){await api(`/api/conversations/${id}`,{method:'DELETE'});if(state.conversationId===id){state.conversationId=null;state.messages=[];renderMessages();$('conversationTitle').textContent='New chat';$('welcome').classList.remove('hidden');}await loadConversations();}}else if(action==='RENAME'){const title=prompt('New title',c?.title||'');if(title){await api(`/api/conversations/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({title})});await loadConversations();if(state.conversationId===id)$('conversationTitle').textContent=title;}}return;}
  const item=e.target.closest('.history-item');if(item)openConversation(item.dataset.id);
});

$('attachmentTray').addEventListener('click',e=>{const b=e.target.closest('[data-remove-file]');if(!b)return;state.attachments=state.attachments.filter(a=>a.id!==b.dataset.removeFile);renderAttachmentTray();});

$('messages').addEventListener('click',async e=>{
  let b=e.target.closest('[data-copy-msg]'); if(b){navigator.clipboard.writeText(state.messages[Number(b.dataset.copyMsg)].content);toast('Copied');return;}
  b=e.target.closest('[data-download-msg]'); if(b){const i=Number(b.dataset.downloadMsg);downloadText(`assistant-${i+1}.md`,state.messages[i].content,'text/markdown');return;}
  b=e.target.closest('[data-code-copy]'); if(b){navigator.clipboard.writeText(decodeURIComponent(b.dataset.codeCopy));toast('Code copied');return;}
  b=e.target.closest('[data-code-download]'); if(b){downloadText(`code.${extensionFor(b.dataset.lang||'txt')}`,decodeURIComponent(b.dataset.codeDownload));return;}
  b=e.target.closest('[data-regenerate]'); if(b){state.messages=state.messages.slice(0,-1);await sendMessage({regenerate:true});return;}
  b=e.target.closest('[data-edit-msg]'); if(b){const i=Number(b.dataset.editMsg),m=state.messages[i];if(!m.id)return toast('Wait until message is saved');const edited=prompt('Edit message',m.content);if(edited==null||!edited.trim())return;await api(`/api/conversations/${state.conversationId}/rewind/${m.id}`,{method:'POST'});state.messages=state.messages.slice(0,i);$('messageInput').value=edited;autoGrow();await sendMessage();}
});

(function init(){const theme=localStorage.getItem('theme');if(theme)document.documentElement.dataset.theme=theme;syncSettingsUi();updateModelBadge();loadConversations().catch(e=>toast(e.message));if(state.config.apiKey&&state.config.baseUrl&&state.config.model)$('welcome').querySelector('p').textContent='Start a new conversation or open one from history.';})();
