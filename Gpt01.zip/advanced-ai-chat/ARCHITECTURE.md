# Architecture

## Request path

1. Browser keeps API key in session storage by default.
2. `ChatController` accepts the message and Authorization header.
3. `ChatService` creates/loads a conversation and stores the user message.
4. `ContextService` keeps full history in H2 but only sends the newest messages that fit the configured context budget.
5. `FileContextSelector` injects only query-relevant chunks from uploaded text documents.
6. Images are included as multimodal `image_url` data for compatible models.
7. `OpenAiCompatibleClient` streams `/chat/completions` tokens.
8. UI renders tokens live and detects fenced code blocks for copy/download.
9. Final assistant output is stored in H2.

## Future agent / LangGraph nodes

The clean insertion point is between `ContextService` and `OpenAiCompatibleClient`:

- intent router
- web/search tool
- SQL/API tool
- calculator
- document RAG retriever
- code execution sandbox
- approval node
- response synthesizer

Keep history, UI and file handling unchanged while the orchestration layer grows.
