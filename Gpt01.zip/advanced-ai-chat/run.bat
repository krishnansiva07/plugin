@echo off
setlocal
if not exist target\advanced-ai-chat-1.0.0-SNAPSHOT.jar (
  echo JAR not found. Building...
  call mvn clean package
  if errorlevel 1 exit /b 1
)
java -jar target\advanced-ai-chat-1.0.0-SNAPSHOT.jar
