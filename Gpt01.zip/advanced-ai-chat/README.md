# Advanced AI Chat — Java 17 / Spring Boot

A ChatGPT-style application built from the supplied Spring Boot + LangChain4j base.

## What is included

- Home-page API key, base URL and model configuration
- API key is **not persisted by the backend**
- OpenAI-compatible `/chat/completions` streaming
- Persistent chat history in local H2 database
- New chat, open history, search, rename and delete
- Regenerate last response
- Edit a user message and rewind the later conversation
- Full-history persistence + bounded context window sent to the LLM
- System prompt, temperature, max output token and context controls
- File upload scoped to each conversation
- Apache Tika extraction for PDF, DOC/DOCX, PPT/PPTX, XLS/XLSX, TXT, HTML and many other formats
- Query-relevant chunk selection for large uploaded documents
- Image attachments sent as OpenAI-compatible multimodal `image_url` data when the selected model supports vision
- Markdown-style assistant rendering
- Fenced code blocks identified with language labels
- Copy code, download code, copy message and download response
- Export complete chat to Markdown or JSON
- Dark/light theme
- Responsive layout
- No npm, Node or CDN dependency; frontend is packaged inside the JAR

## Important design choice

The original project used `ChatLanguageModel` from LangChain4j 0.29.0. This project keeps those dependencies so your existing code can be extended with AI Services/tools later, but the active streaming client uses the standard OpenAI-compatible HTTP contract directly. This avoids tying streaming, multimodal files and custom internal endpoints to one LangChain4j API version.

The chat flow is intentionally split into graph-like stages:

`UI -> ChatController -> ChatService -> ContextService -> FileContextSelector -> OpenAiCompatibleClient -> persist history`

That gives you the orchestration points where LangGraph4j or another agent graph can be inserted later without rewriting the UI/history/file layers.

## Build

Requirements: Java 17 and Maven.

```bash
mvn clean package
```

Run:

```bash
java -jar target/advanced-ai-chat-1.0.0-SNAPSHOT.jar
```

Then open:

```text
http://localhost:8090
```

Windows helper:

```bat
run.bat
```

## LLM settings

On the home page enter:

- **API key**: your token
- **Base URL**: the OpenAI-compatible version root, for example `https://host/api/v1`
- **Model**: the deployed model name

The app automatically calls:

`{baseUrl}/chat/completions`

If you already enter a URL ending in `/chat/completions`, it uses it as-is.

## Security

Do not hard-code API keys in `application.properties` or source code. The UI defaults to `sessionStorage`; “Remember key” uses browser `localStorage`. The key is forwarded to the backend only as the Authorization header for the current request and is not written to H2.

Because an API key is visible in the screenshots supplied for the original project, rotate it if it is a real active credential.

## Data

Runtime data is created under:

```text
./data/chatdb.*
./data/uploads/<conversation-id>/
```

Delete the `data` directory to reset all local conversations and uploads.

## Notes / extension points

The UI implements the core ChatGPT-like chat experience. Product-specific capabilities such as OpenAI web browsing, proprietary voice mode, image generation, connector access, remote code execution and hosted file creation are not automatically available from an arbitrary OpenAI-compatible model endpoint. Add these as explicit tools/graph nodes behind `ChatService`.
