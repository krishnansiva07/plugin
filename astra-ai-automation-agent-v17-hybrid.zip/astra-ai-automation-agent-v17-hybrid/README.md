# Astra AI Automation Agent

This build changes the execution model from raw LLM-driven MCP tool calls to a deterministic safe-action executor.

## Important change

The LLM no longer sends raw MCP tool calls such as `browser_click`, `browser_type`, `target`, `ref`, or empty `browser_wait_for` arguments.

The LLM now returns only safe intent actions:

- TYPE
- CLICK
- CLICK_TEXT
- WAIT
- WAIT_FOR_TEXT
- PRESS_KEY
- ASSERT_TEXT_VISIBLE

Java resolves those safe actions against the current Playwright MCP snapshot and only then calls MCP.

## Why this is better

This prevents the earlier failures:

- empty `browser_wait_for` arguments
- wrong raw MCP JSON
- stale refs guessed by the LLM
- row click instead of exact visible cell text
- sequence reset
- overlay click interception without recovery

## Run

```powershell
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

Do not manually start Playwright MCP. The Spring Boot app starts MCP in stdio mode.

## Recommended settings for first real-app run

```text
Validate generated code = unchecked
Close browser after run = unchecked
Show browser live = checked
Action delay = 2000
Max agent steps = 20
Min confidence = 60
Plan before execution = checked
No guessing = checked
```

## Recommended pre-action instruction for enterprise grid/table apps

```text
Wait after every search or tab change. If the result row appears, click the exact visible cell text from test data, not the full table row. If overlay, toast, modal, or loading layer appears, wait before clicking.
```

## Test data example

```json
{
  "username": "standard_user",
  "password": "secret_sauce",
  "agreementReference": "0002011/001 EUR"
}
```

## Execution model

```text
Scenario + Test Data
  -> LLM creates high-level plan
  -> LLM returns safe action intent only
  -> Java validates data and action
  -> Java resolves element from current MCP snapshot
  -> Java calls MCP with correct arguments
  -> Java retries/recoveries for overlay/timing issues
  -> Successful trace goes to code generation
```


## Controlled data parsing improvement

The Test Data field now accepts both JSON and key-value style input.

Examples:

```json
{
  "username": "standard_user",
  "password": "secret_sauce",
  "agreementReference": "0002011/001 EUR"
}
```

or:

```properties
username=standard_user
password=secret_sauce
agreementReference=0002011/001 EUR
```

Common aliases such as `user id`, `userid`, `email`, `pwd`, `passcode`, `reference`, and `agreementRef` are mapped safely. The agent still does not guess missing passwords, OTPs, transaction IDs, or business values.
