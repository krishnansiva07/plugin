# Astra Automation Quiz

A single-screen LLM-powered automation quiz host app for Teams screen-share quiz sessions.

## Run

```bash
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

## LLM Setup

Edit `src/main/resources/application.properties` before packaging, or edit the extracted config and restart if running from IDE.

```properties
astra.llm.demo-mode=false
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
astra.llm.api-key=YOUR_KEY
astra.llm.model-name=gpt-oss-120b
astra.llm.timeout-ms=60000
```

Important: `astra.llm.base-url` is called directly by `LlmQuizService`. The app does not append `/chat/completions`.

When you click **Generate Next Question**, console should print:

```text
[Astra Quiz] Calling configured LLM endpoint directly: https://ai4devs.group.echonet/api/v1
```

## Quiz Rules

- Each team gets configured number of Simple, Medium and Complex questions.
- All questions are Choose Best Answer with A/B/C/D options.
- Admin sees correct answer and explanation in the Quiz Master panel.
- If assigned team is wrong, question moves to Central Pool.
- Another team can steal the points.
- Leaderboard updates after every question.
