package com.astraquiz.service;

import com.astraquiz.model.Difficulty;
import com.astraquiz.model.QuizQuestion;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmQuizService {
    @Value("${astra.llm.demo-mode:true}")
    private boolean demoMode;

    /**
     * IMPORTANT:
     * This is the EXACT LLM endpoint configured in application.properties.
     * Example:
     * astra.llm.base-url=https://ai4devs.group.echonet/api/v1
     *
     * As requested, Astra Automation Quiz posts directly to this configured endpoint.
     * We do NOT append /chat/completions here.
     */
    @Value("${astra.llm.base-url:}")
    private String baseUrl;

    @Value("${astra.llm.api-key:}")
    private String apiKey;

    @Value("${astra.llm.model-name:gpt-oss-120b}")
    private String modelName;

    @Value("${astra.llm.timeout-ms:60000}")
    private int timeoutMs;

    private final ObjectMapper mapper = new ObjectMapper();
    private int demoCounter = 0;

    public QuizQuestion generateQuestion(String team, String technology, Difficulty difficulty, int points, List<String> asked) {
        if (demoMode) {
            System.out.println("[Astra Quiz] Demo mode is ON. LLM will not be called.");
            return demoQuestion(team, technology, difficulty, points);
        }

        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException("astra.llm.base-url is empty. Configure your LLM endpoint first.");
        }

        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("astra.llm.api-key is empty. Configure your LLM API key first.");
        }

        try {
            String prompt = buildPrompt(technology, difficulty, points, asked);
            String rawResponse = callConfiguredLlmEndpoint(prompt);
            String content = extractAssistantContent(rawResponse);
            return parseQuestion(content, team, technology, difficulty, points);
        } catch (Exception ex) {
            System.err.println("[Astra Quiz] LLM call failed. Error: " + ex.getMessage());
            throw new IllegalStateException("LLM call failed. Check endpoint, key, model and network. Details: " + ex.getMessage(), ex);
        }
    }

    private String callConfiguredLlmEndpoint(String prompt) {
        String endpoint = normalizeEndpoint(baseUrl);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("model", modelName);
        payload.put("temperature", 0.9);
        payload.put("max_tokens", 900);
        payload.put("messages", List.of(
                Map.of("role", "system", "content", "You are an expert automation testing quiz master. Return valid JSON only."),
                Map.of("role", "user", "content", prompt)
        ));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        System.out.println("[Astra Quiz] Demo mode: " + demoMode);
        System.out.println("[Astra Quiz] Calling configured LLM endpoint directly: " + endpoint);
        System.out.println("[Astra Quiz] Model: " + modelName);

        RestTemplate restTemplate = restTemplate();
        ResponseEntity<String> response = restTemplate.exchange(
                endpoint,
                HttpMethod.POST,
                new HttpEntity<>(payload, headers),
                String.class
        );

        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new IllegalStateException("LLM returned HTTP " + response.getStatusCode());
        }

        return response.getBody();
    }

    private RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(timeoutMs);
        factory.setReadTimeout(timeoutMs);
        return new RestTemplate(factory);
    }

    private String normalizeEndpoint(String configuredEndpoint) {
        String url = configuredEndpoint == null ? "" : configuredEndpoint.trim();
        while (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }
        return url;
    }

    private String extractAssistantContent(String rawResponse) throws Exception {
        JsonNode root = mapper.readTree(rawResponse);

        // OpenAI-compatible response
        String content = root.at("/choices/0/message/content").asText(null);
        if (content != null && !content.isBlank()) {
            return content;
        }

        // Some gateways return text/content directly
        content = root.path("content").asText(null);
        if (content != null && !content.isBlank()) {
            return content;
        }

        content = root.path("response").asText(null);
        if (content != null && !content.isBlank()) {
            return content;
        }

        content = root.path("answer").asText(null);
        if (content != null && !content.isBlank()) {
            return content;
        }

        // If endpoint already returns the quiz JSON itself
        if (root.has("questionText") && root.has("options")) {
            return rawResponse;
        }

        throw new IllegalStateException("Unable to extract LLM content from response: " + rawResponse);
    }

    private String buildPrompt(String technology, Difficulty difficulty, int points, List<String> asked) {
        return """
                Generate one fresh live automation quiz question for Astra Automation Quiz.

                Technology: %s
                Difficulty: %s
                Question Type: CHOOSE_BEST
                Points: %d

                Rules:
                - Create only one question.
                - It must be practical for automation testers.
                - It must have exactly 4 options: A, B, C, D.
                - Only one option should be the best answer.
                - Do not repeat these already asked concepts/questions: %s
                - Return JSON only. No markdown. No explanation outside JSON.

                JSON format:
                {
                  "questionText": "",
                  "options": {
                    "A": "",
                    "B": "",
                    "C": "",
                    "D": ""
                  },
                  "correctOption": "A",
                  "explanation": ""
                }
                """.formatted(technology, difficulty, points, String.join(" | ", asked == null ? List.of() : asked));
    }

    private QuizQuestion parseQuestion(String content, String team, String technology, Difficulty difficulty, int points) throws Exception {
        String json = extractJson(content);
        JsonNode n = mapper.readTree(json);

        QuizQuestion q = base(team, technology, difficulty, points);
        q.setQuestionText(n.path("questionText").asText());

        LinkedHashMap<String, String> options = new LinkedHashMap<>();
        options.put("A", n.path("options").path("A").asText());
        options.put("B", n.path("options").path("B").asText());
        options.put("C", n.path("options").path("C").asText());
        options.put("D", n.path("options").path("D").asText());
        q.setOptions(options);

        q.setCorrectOption(n.path("correctOption").asText().trim().toUpperCase());
        q.setExplanation(n.path("explanation").asText());

        if (q.getQuestionText().isBlank() || q.getCorrectOption().isBlank()) {
            throw new IllegalStateException("LLM returned incomplete question JSON: " + json);
        }
        return q;
    }

    private String extractJson(String text) {
        if (text == null || text.isBlank()) {
            throw new IllegalStateException("LLM returned empty content");
        }
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end < start) {
            throw new IllegalStateException("LLM response does not contain JSON object: " + text);
        }
        return text.substring(start, end + 1);
    }

    private QuizQuestion demoQuestion(String team, String technology, Difficulty difficulty, int points) {
        demoCounter++;
        String tech = technology == null || technology.isBlank() ? "Automation" : technology;
        List<QuizQuestion> bank = new ArrayList<>();
        bank.add(make(team, tech, difficulty, points, "A Selenium test fails randomly because a button is not clickable immediately after page load. What is the best solution?", "Use Thread.sleep(10000)", "Use WebDriverWait with elementToBeClickable", "Refresh the page every time", "Increase implicit wait to 5 minutes", "B", "WebDriverWait waits for the exact clickable condition and reduces flaky timing failures."));
        bank.add(make(team, tech, difficulty, points, "In Cucumber automation, what is the best reason to keep step definitions reusable and business-readable?", "To make feature files longer", "To avoid duplicate automation code and improve maintainability", "To remove all assertions", "To replace page objects", "B", "Reusable steps reduce duplication and keep BDD scenarios maintainable."));
        bank.add(make(team, tech, difficulty, points, "For API automation using RestAssured, which validation gives the fastest confidence that the API request succeeded?", "Only print response body", "Validate HTTP status code and key response fields", "Add Thread.sleep after request", "Check browser title", "B", "Status code plus key fields confirms contract and business response basics."));
        bank.add(make(team, tech, difficulty, points, "A test passes locally but fails in Jenkins due to timing issues. What is the best first improvement?", "Increase global implicit wait to 5 minutes", "Use condition-based waits and capture failure evidence", "Disable Jenkins execution", "Run only one test forever", "B", "Condition-based waits and evidence help fix CI instability properly."));
        bank.add(make(team, tech, difficulty, points, "Which approach is best for Page Object Model design?", "Keep locators and actions inside page classes", "Put all locators in test class", "Duplicate login code in every test", "Avoid methods and use raw XPath everywhere", "A", "Page objects encapsulate locators and page actions, making tests cleaner."));
        return bank.get(demoCounter % bank.size());
    }

    private QuizQuestion make(String team, String tech, Difficulty d, int p, String text, String a, String b, String c, String dd, String correct, String exp) {
        QuizQuestion q = base(team, tech, d, p);
        q.setQuestionText(text);
        LinkedHashMap<String, String> opts = new LinkedHashMap<>();
        opts.put("A", a);
        opts.put("B", b);
        opts.put("C", c);
        opts.put("D", dd);
        q.setOptions(opts);
        q.setCorrectOption(correct);
        q.setExplanation(exp);
        return q;
    }

    private QuizQuestion base(String team, String tech, Difficulty d, int p) {
        QuizQuestion q = new QuizQuestion();
        q.setId(UUID.randomUUID().toString());
        q.setAssignedTeam(team);
        q.setTechnology(tech);
        q.setDifficulty(d);
        q.setPoints(p);
        return q;
    }
}
