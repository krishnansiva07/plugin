# ITPS VIBIUM MCP Framework — Windows and macOS Setup

This guide installs and runs the Java Spring Boot UI, Vibium MCP browser service, Excel/JSON scenario execution, multi-sheet selection, reporting, screenshots and the optional UI recorder.

## 1. Prerequisites

Install the following before starting:

- Java JDK 17 (not only a JRE)
- Apache Maven 3.9 or later
- Node.js 20 LTS or later, including npm
- Google Chrome or Microsoft Edge
- Network access to the configured LLM endpoint
- A valid LLM token

Verify:

```bash
java -version
mvn -version
node -v
npm -v
```

Java and Maven must report Java 17 or newer. If a command is not found, close and reopen the terminal after installation.

## 2. Extract the framework

Extract the ZIP into a local writable directory without special permission requirements.

Recommended locations:

Windows:

```text
C:\itps\itps-vibium-mcp-framework
```

macOS:

```text
~/itps/itps-vibium-mcp-framework
```

Avoid running directly from Downloads, OneDrive/iCloud synchronized folders, or a read-only corporate share.

## 3. Install Vibium locally

From a terminal, create a portable/local tools directory and install Vibium. Use the Vibium package/version approved for your environment.

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force C:\tools\vibium-portable | Out-Null
Set-Location C:\tools\vibium-portable
npm init -y
npm install vibium
```

macOS Terminal:

```bash
mkdir -p ~/tools/vibium-portable
cd ~/tools/vibium-portable
npm init -y
npm install vibium
```

Confirm the MCP command can start:

Windows:

```powershell
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd mcp
```

macOS:

```bash
~/tools/vibium-portable/node_modules/.bin/vibium mcp
```

Stop the manual verification with `Ctrl+C`. The Spring Boot application starts the MCP process automatically during execution.

## 4. Configure the Vibium path

Edit:

```text
src/main/resources/application.properties
```

Windows example:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
```

macOS example:

```properties
itps.vibium.mcp.command=/Users/YOUR_USERNAME/tools/vibium-portable/node_modules/.bin/vibium
itps.vibium.mcp.args=mcp
```

Replace `YOUR_USERNAME` with the macOS account name. Do not use `~` inside `application.properties`; use the complete absolute path.

For locked networks where the browser package/cache is already copied locally:

```properties
itps.vibium.skip-browser-download=true
```

If first-time browser download is permitted and required, temporarily change it to `false`.

## 5. Build and run

### Windows PowerShell

```powershell
Set-Location C:\itps\itps-vibium-mcp-framework
$env:VIBIUM_SKIP_BROWSER_DOWNLOAD="1"
mvn clean test
mvn spring-boot:run
```

### Windows Command Prompt

```cmd
cd /d C:\itps\itps-vibium-mcp-framework
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean test
mvn spring-boot:run
```

### macOS Terminal

```bash
cd ~/itps/itps-vibium-mcp-framework
export VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean test
mvn spring-boot:run
```

Open:

```text
http://localhost:8090
```

To stop the application, press `Ctrl+C` in the terminal.

## 6. Build and run as an executable JAR

Build:

```bash
mvn clean package
```

The generated JAR is under `target/` and normally resembles:

```text
target/itps-vibium-mcp-framework-25.0.0-MCP.jar
```

Run:

Windows:

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
java -jar target\itps-vibium-mcp-framework-25.0.0-MCP.jar
```

macOS:

```bash
export VIBIUM_SKIP_BROWSER_DOWNLOAD=1
java -jar target/itps-vibium-mcp-framework-25.0.0-MCP.jar
```

## 7. Run scenarios from multiple Excel worksheets

1. Open `http://localhost:8090`.
2. Upload an `.xlsx` or `.xls` scenario file.
3. The application reads all worksheet names and displays one checkbox per worksheet.
4. Check one or more worksheets. Use **Select all** or **Clear all** when needed.
5. Enter the LLM token.
6. Select the detected browser and execution settings.
7. Click **Run tests**.

All enabled rows from all checked worksheets are combined into the same run. A row runs only when its optional `Run` column contains one of:

```text
true, yes, y, 1, run, execute, enabled
```

When two selected worksheets contain the same test ID, the first ID is retained and later duplicates are safely prefixed with the worksheet name. The source worksheet is also stored as `sourceSheet` in scenario test data.

## 8. Recommended Excel structure

Each selected worksheet should use row 1 as the header row.

| Column | Required | Purpose |
|---|---:|---|
| Run | No | Enables/disables the scenario row |
| Id | Recommended | Unique test ID |
| Name | Recommended | Test name |
| Url | No | Application URL for the scenario |
| Steps | Yes | Steps separated by new lines or `|` |
| Expected | No | Expected result description |
| TestDataJson / TestData / Data | No | JSON test-data object |
| data.<key> | No | Individual test-data values |

Example `Steps` cell:

```text
Open the application
Click "New-IP" using visible text
Verify New-IP page is displayed
```

## 9. Reports and technical evidence

Every execution writes to:

```text
target/itps-vibium-runs/<RUN-ID>/
```

Main outputs:

- `report.html` — execution report
- `logs.html` — technical logs
- `report.xlsx` — Excel result
- `report.json` — machine-readable result
- `screenshots.zip` — captured screenshots
- `elements/` — page/DOM evidence
- `mcp-transcript.json` — MCP requests and responses
- `mcp-process.log` — MCP process logs

The UI opens HTML reports in a new tab and keeps the framework page open.

## 10. Optional UI recorder

1. Enable **Record UI actions and generate Excel steps**.
2. Enter the full application URL.
3. Select an installed browser.
4. Click **Start recording**.
5. Perform the actions in the launched headed browser.
6. Click **Stop recording**.
7. Review, delete, copy, or download generated steps.

Recorder outputs are written under:

```text
target/itps-vibium-recordings/<SESSION-ID>/
```

Sensitive fields such as passwords, OTPs, CVVs and tokens are masked as variables.

## 11. Common troubleshooting

### Port 8090 already in use

Find and stop the existing process, or change:

```properties
server.port=8091
```

Then open `http://localhost:8091`.

### `mvn` is not recognized

Install Maven and add its `bin` directory to `PATH`. Confirm with `mvn -version` in a newly opened terminal.

### `JAVA_HOME` error

Set `JAVA_HOME` to the JDK 17 installation directory, not its `bin` directory.

### Vibium command not found

Confirm the configured file exists:

Windows:

```powershell
Test-Path C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
```

macOS:

```bash
ls -l ~/tools/vibium-portable/node_modules/.bin/vibium
chmod +x ~/tools/vibium-portable/node_modules/.bin/vibium
```

### Browser launches but execution does not continue

Check:

- `target/itps-vibium-runs/<RUN-ID>/mcp-process.log`
- `target/itps-vibium-runs/<RUN-ID>/mcp-transcript.json`
- Browser executable shown in the UI
- Corporate proxy/firewall access to the LLM endpoint
- Token validity

### Worksheets are not displayed

Confirm the file extension is `.xlsx` or `.xls`, the workbook is not password-protected, and it contains at least one worksheet.

### No scenarios found

Confirm selected worksheets have a header row and scenario rows. When a `Run` column exists, at least one row must contain an enabled value.

## 12. Clean generated outputs

Windows:

```cmd
rmdir /s /q target
```

macOS:

```bash
rm -rf target
```

Run `mvn clean package` again after cleaning.
